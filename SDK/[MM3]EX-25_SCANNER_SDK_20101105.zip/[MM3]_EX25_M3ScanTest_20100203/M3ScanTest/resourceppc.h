//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by M3ScanTestppc.rc
//
#define IDD_M3SCANTEST_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDB_M3LOGO                      129
#define IDR_WAVE_SCAN                   130
#define IDR_WAVE_BEEP                   131
#define IDD_1DBARCODE_DLG               132
#define IDD_2DBARCODE_DLG               133
#define IDD_OPTION_DLG                  134
#define IDC_STATIC_1                    200
#define IDC_STATIC_BARCODE              1000
#define IDC_LIST_SCANDATA               1001
#define IDC_BTN_SCAN                    1002
#define IDC_BTN_SCANCANCEL              1003
#define IDC_BTN_1DBARCODE               1004
#define IDC_BTN_OPTION                  1005
#define IDC_BTN_CLEAR                   1006
#define IDC_BTN_2DSYM                   1007
#define IDC_BTN_2DBARCODE               1007
#define IDC_CHECK_CODABAR               1008
#define IDC_CHECK_CODE11                1009
#define IDC_CHECK_CODE39                1010
#define IDC_CHECK_CODE93                1011
#define IDC_CHECK_CODE128               1012
#define IDC_CHECK_GS1128                1013
#define IDC_CHECK_UPCA                  1014
#define IDC_CHECK_UPCE                  1015
#define IDC_CHECK_EAN8                  1016
#define IDC_CHECK_EAN13                 1017
#define IDC_CHECK_UPCE1                 1018
#define IDC_CHECK_GS1                   1019
#define IDC_CHECK_I2OF5                 1020
#define IDC_CHECK_MATRIX2OF5            1021
#define IDC_CHECK_MSI                   1022
#define IDC_CHECK_PLESSEY               1023
#define IDC_CHECK_STANDARD2OF5          1024
#define IDC_CHECK_TELEPEN               1025
#define IDC_CHECK_AZTEC                 1028
#define IDC_CHECK_BPO                   1029
#define IDC_CHECK_DATAMATRIX            1030
#define IDC_CHECK_MAXICODE              1031
#define IDC_CHECK_PDF417                1032
#define IDC_CHECK_MICROPDF417           1033
#define IDC_CHECK_PLANET                1034
#define IDC_CHECK_QRCODE                1035
#define IDC_CHECK_AUSPOST               1036
#define IDC_CHECK_CANADAPOST            1037
#define IDC_CHECK_TLC39                 1038
#define IDC_CHECK_POST_NET              1039
#define IDC_CHECK_DUTCHPOST             1040
#define IDC_CHECK_JAPANPOST             1041
#define IDC_CHECK_SWEDENPOST            1042
#define IDC_RADIO_ASYNC                 1043
#define IDC_RADIO_SYNC                  1044
#define IDC_COMBO_TIMEOUT               1045
#define IDC_COMBO_SECURITYLEVEL         1046
#define IDC_CHECK_XCD                   1047
#define IDC_CHECK_CENTERDECODE          1048
#define IDC_CHECK_BEEP                  1049
#define IDC_CHECK4                      1050
#define IDC_CHECK_1DDECODE              1050

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1051
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
