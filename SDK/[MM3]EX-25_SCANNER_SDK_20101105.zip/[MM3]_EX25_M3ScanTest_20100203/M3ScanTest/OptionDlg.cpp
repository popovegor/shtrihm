// OptionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "OptionDlg.h"
#include "M3ScanTestDlg.h"


// COptionDlg dialog

IMPLEMENT_DYNAMIC(COptionDlg, CDialog)

COptionDlg::COptionDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COptionDlg::IDD, pParent)
	, m_nSyncMode(0)
	, m_bXcd(FALSE)
	, m_bCenterDecode(FALSE)
	, m_bBeep(FALSE)
	, m_b1DDecode(FALSE)
{

}

COptionDlg::~COptionDlg()
{
}

void COptionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_RADIO_ASYNC, m_nSyncMode);
	DDX_Control(pDX, IDC_COMBO_TIMEOUT, m_ctrlComboTimeOut);
	DDX_Control(pDX, IDC_COMBO_SECURITYLEVEL, m_ctrlComboSecurityLevel);
	DDX_Check(pDX, IDC_CHECK_XCD, m_bXcd);
	DDX_Check(pDX, IDC_CHECK_CENTERDECODE, m_bCenterDecode);
	DDX_Check(pDX, IDC_CHECK_BEEP, m_bBeep);
	DDX_Check(pDX, IDC_CHECK_1DDECODE, m_b1DDecode);
}


BEGIN_MESSAGE_MAP(COptionDlg, CDialog)
	ON_BN_CLICKED(IDOK, &COptionDlg::OnBnClickedOk)
END_MESSAGE_MAP()


// COptionDlg message handlers

BOOL COptionDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void COptionDlg::GetOption(void)
{
	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();
	
	m_nSyncMode		= dlg->m_nSyncMode;
	m_bXcd			= dlg->m_bXCD;
	m_bCenterDecode	= dlg->m_bCenterDecode;
	m_bBeep			= dlg->m_bBeep;
	m_b1DDecode		= dlg->m_b1DDecode;

	UpdateData(FALSE);

	m_ctrlComboTimeOut.InsertString(0, L"1");
	m_ctrlComboTimeOut.InsertString(1, L"2");
	m_ctrlComboTimeOut.InsertString(2, L"3");
	m_ctrlComboTimeOut.InsertString(3, L"4");
	m_ctrlComboTimeOut.InsertString(4, L"5");
	m_ctrlComboTimeOut.InsertString(5, L"6");
	m_ctrlComboTimeOut.InsertString(6, L"7");
	m_ctrlComboTimeOut.InsertString(7, L"8");
	m_ctrlComboTimeOut.InsertString(8, L"9");
	m_ctrlComboTimeOut.InsertString(9, L"10");
	m_ctrlComboTimeOut.SetCurSel(dlg->m_nTimeOut - 1);

	m_ctrlComboSecurityLevel.InsertString(0, L"1");
	m_ctrlComboSecurityLevel.InsertString(1, L"2");
	m_ctrlComboSecurityLevel.InsertString(2, L"3");
	m_ctrlComboSecurityLevel.InsertString(3, L"4");
	m_ctrlComboSecurityLevel.SetCurSel(dlg->m_nSecurityLevel - 1);
}

void COptionDlg::SetOption(void)
{
	UpdateData(TRUE);

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	dlg->m_nSyncMode	= m_nSyncMode;
	dlg->m_bXCD			= m_bXcd;
	dlg->m_bCenterDecode= m_bCenterDecode;
	dlg->m_bBeep		= m_bBeep;
	dlg->m_b1DDecode	= m_b1DDecode;
	dlg->m_nTimeOut			= (DWORD)(m_ctrlComboTimeOut.GetCurSel()+1);
	dlg->m_nSecurityLevel	= (DWORD)(m_ctrlComboSecurityLevel.GetCurSel()+1);
}

void COptionDlg::OnBnClickedOk()
{
	SetOption();
	OnOK();
}
