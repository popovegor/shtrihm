// Reg.h: interface for the CReg class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_REG_H__5C64BB48_E448_4759_851C_0690B81F8368__INCLUDED_)
#define AFX_REG_H__5C64BB48_E448_4759_851C_0690B81F8368__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CReg  
{
public:
	BOOL SetRegStr(HKEY hKeyRoot, WCHAR *wszRegPath, WCHAR *wszValue, WCHAR *wszData);
	BOOL GetRegStr(HKEY hKeyRoot, WCHAR * wszRegPath, WCHAR * wszValue, TCHAR *wsGetData);
	DWORD GetRegValue(HKEY hKeyRoot, WCHAR *wszRegPath, WCHAR *wszValue);
	BOOL SetRegValue(HKEY hKeyRoot, WCHAR *wszRegPath, WCHAR * wszValue, DWORD wszData);

	CReg();
	virtual ~CReg();

//	WCHAR m_wszRegString[512];
	int   m_nRegValue;
};

#endif // !defined(AFX_REG_H__5C64BB48_E448_4759_851C_0690B81F8368__INCLUDED_)
