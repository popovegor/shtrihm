/********************************************************************
created		:	2010/02/10
file base	: 	M3ScanTest.exe

file ext	:	cpp
author		:	Dong-Hyun, Eum(vision7901) - ���밳����

purpose		:	MM3
Report		:	2010. 02. 10 [02/10/2010 vision7901] v1.0.0 - �ʱ� ���߿Ϸ� ����

*********************************************************************/
// M3ScanTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "M3ScanTestDlg.h"

#include "1DBarCodeDlg.h"
#include "2DBarCodeDlg.h"
#include "OptionDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CM3ScanTestDlg dialog

KSCANREAD	kRead;
KSCANREADEX kReadEx;

int		 KSCANAPI KScanReadCallBack(LPVOID pRead);

CM3ScanTestDlg::CM3ScanTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CM3ScanTestDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CM3ScanTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_SCANDATA, m_ctrlListScanData);
}

BEGIN_MESSAGE_MAP(CM3ScanTestDlg, CDialog)
#if defined(_DEVICE_RESOLUTION_AWARE) && !defined(WIN32_PLATFORM_WFSP)
	ON_WM_SIZE()
#endif
	//}}AFX_MSG_MAP

	ON_BN_CLICKED(IDC_BTN_OPTION, &CM3ScanTestDlg::OnBnClickedBtnOption)
	ON_BN_CLICKED(IDC_BTN_1DBARCODE, &CM3ScanTestDlg::OnBnClickedBtn1dbarcode)
	ON_BN_CLICKED(IDC_BTN_2DBARCODE, &CM3ScanTestDlg::OnBnClickedBtn2dbarcode)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BTN_SCAN, &CM3ScanTestDlg::OnBnClickedBtnScan)
	ON_BN_CLICKED(IDC_BTN_CLEAR, &CM3ScanTestDlg::OnBnClickedBtnClear)
	ON_BN_CLICKED(IDC_BTN_SCANCANCEL, &CM3ScanTestDlg::OnBnClickedBtnScancancel)
END_MESSAGE_MAP()


// CM3ScanTestDlg message handlers

BOOL CM3ScanTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_bKeyFlag	= FALSE;
	m_bReading	= FALSE;

	m_nDisplayType	= m_Reg.GetRegValue(HKEY_LOCAL_MACHINE, L"\\Drivers\\Display\\PXA27x\\Config", L"CyScreen");

	ListView_SetExtendedListViewStyle(m_ctrlListScanData.GetSafeHwnd(),LVS_EX_FULLROWSELECT);
	if(m_nDisplayType == 640)
	{
		m_ctrlListScanData.InsertColumn(0,L"BarCode Type",LVCFMT_LEFT,180);
		m_ctrlListScanData.InsertColumn(1,L"BarCode Number",LVCFMT_LEFT,286);
	}
	else
	{
		m_ctrlListScanData.InsertColumn(0,L"BarCode Type",LVCFMT_LEFT,90);
		m_ctrlListScanData.InsertColumn(1,L"BarCode Number",LVCFMT_LEFT,143);
	}

	BeginWaitCursor();
	M3ScanInit();
	EndWaitCursor();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CM3ScanTestDlg::OnDestroy()
{
	CDialog::OnDestroy();

	M3ScanClose();
}


BOOL CM3ScanTestDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_F14)
	{
		if(m_bKeyFlag == FALSE)
		{
			M3ScanRead();
			Sleep(10);

			m_bKeyFlag = TRUE;
		}
		

		return	TRUE;

	}
	else if(pMsg->message == WM_KEYUP && pMsg->wParam == VK_F14)
	{
		if(m_bKeyFlag == TRUE)
		{
			m_bKeyFlag = FALSE;
			//ASync Mode
			if(m_nSyncMode == 0)
			{		
				KScanReadCancel();
				Sleep(10);

				m_bReading = FALSE;						
			}			
			return	TRUE;
		}
	}

	return CDialog::PreTranslateMessage(pMsg);
}

void CM3ScanTestDlg::OnBnClickedBtnScan()
{	
	KScanRead();
}

void CM3ScanTestDlg::OnBnClickedBtnClear()
{
	m_ctrlListScanData.DeleteAllItems();
}

void CM3ScanTestDlg::OnBnClickedBtnScancancel()
{
	KScanReadCancel();
}


void CM3ScanTestDlg::OnBnClickedBtn1dbarcode()
{
	C1DBarCodeDlg dlg;
	
	if(IDOK == dlg.DoModal())
	{
		SetScanOption();
	}
}

void CM3ScanTestDlg::OnBnClickedBtn2dbarcode()
{
	C2DBarCodeDlg dlg;
	
	if(IDOK == dlg.DoModal())
	{
		SetScanOption();
	}
}


void CM3ScanTestDlg::OnBnClickedBtnOption()
{
	COptionDlg dlg;
	
	if(IDOK == dlg.DoModal())
	{
		SetScanOption();
	}
}

void CM3ScanTestDlg::M3ScanInit(void)
{
	HKEY hKey;
	int nRet;
	DWORD dwDisp;
	DWORD wszData = 3;

	nRet = RegCreateKeyEx(HKEY_LOCAL_MACHINE, L"ControlPanel\\KeyPad\\SideKey", 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, &dwDisp);
	if(nRet != ERROR_SUCCESS)
	{
		::MessageBox(NULL, L"Reg Create Error", L"Registry", MB_OK);
		return;
	}

	nRet = RegSetValueEx(hKey, L"RightDownKey", 0, REG_DWORD, (LPBYTE)&wszData, sizeof(DWORD));
	if(nRet != ERROR_SUCCESS)
	{
		return;
	}
	RegCloseKey(hKey);

	BOOL bRet = KScanOpen(6, FALSE,	57600,	FALSE, NULL);
	if(bRet == FALSE)
	{
		SetDlgItemText(IDC_STATIC_BARCODE,L"Scanner open Failed");
		KScanClose();
		Sleep(100);
	}
	else
		SetDlgItemText(IDC_STATIC_BARCODE,L"Scanner opened");


	SetDefaultOption();	
}

void CM3ScanTestDlg::M3ScanClose(void)
{
	int i;
	HKEY hKey;
	int nRet;
	DWORD dwDisp;
	DWORD wszData = 0;

	nRet = RegCreateKeyEx(HKEY_LOCAL_MACHINE, L"ControlPanel\\KeyPad\\SideKey", 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, &dwDisp);
	if(nRet != ERROR_SUCCESS)
	{
		return;
	}

	nRet = RegSetValueEx(hKey, L"RightDownKey", 0, REG_DWORD, (LPBYTE)&wszData, sizeof(DWORD));
	if(nRet != ERROR_SUCCESS)
	{
		return;
	}
	RegCloseKey(hKey);

	for(i=0;i<3;i++)
	{		
		if(KScanClose())
			break;
		Sleep(100);
	}
}

void CM3ScanTestDlg::M3ScanRead(void)
{
	BOOL		bRet;	

	if(m_bKeyFlag == FALSE)
	{
		if (m_bReading) 
		{	// Reading already in progress, now cancel it.
			bRet = KScanReadCancel();

			if (bRet) 
			{
				m_bReading = FALSE;
				return;
			} 
		}

		m_bKeyFlag = TRUE;
		m_bReading = FALSE;


		bRet =	KScanRead();	
		if (!bRet) {
			m_bReading = FALSE;
		}		
	}
}


int KSCANAPI KScanReadCallBack(LPVOID pRead)
{
	CM3ScanTestDlg * lpCls = (CM3ScanTestDlg *)((PKSCANREAD)pRead)->pUserData;

	CString  strData = _T("SCAN DATA");
	CString	 strtype;
	unsigned long type= 0;

	//	char BarCodeName[128]={0,};
	type = ((PKSCANREAD)pRead)->out_Type;
	strtype = KScanSetBarCodeString(type);
	lpCls->SetDlgItemText(IDC_STATIC_BARCODE, strData);
	strData = ((PKSCANREAD)pRead)->out_Barcode;	

	lpCls->GetScanData(strtype, strData);
	lpCls->LoadResSound();
	return TRUE;

}

void CM3ScanTestDlg::SetDefaultOption(void)
{
	// ReadOption
	m_nTimeOut			= 2;
	m_nSecurityLevel	= 1;

	// Option
	m_nSyncMode		= 0;
	m_bXCD			= 1;
	m_bBeep			= FALSE;
	m_bCenterDecode	= 0;
	m_b1DDecode		= 0;

	// 1D BarCode 18
	m_1DBarCode.bCodabar		= FALSE;
	m_1DBarCode.bCode11			= FALSE;
	m_1DBarCode.bCode39			= TRUE;
	m_1DBarCode.bCode93			= FALSE;
	m_1DBarCode.bCode128		= TRUE;
	m_1DBarCode.bGs1_128		= TRUE;
	m_1DBarCode.bUpca			= TRUE;
	m_1DBarCode.bUpce			= TRUE;
	m_1DBarCode.bUpce1			= FALSE;
	m_1DBarCode.bEan8			= TRUE;
	m_1DBarCode.bEan13			= TRUE;
	m_1DBarCode.bGs1			= FALSE;
	m_1DBarCode.bI2of5			= FALSE;
	m_1DBarCode.bMatrix2of5		= FALSE;
	m_1DBarCode.bMsi			= FALSE;
	m_1DBarCode.bPlessey		= FALSE;
	m_1DBarCode.bStandard2of5	= FALSE;
	m_1DBarCode.bTelepen		= FALSE;
	
	// 2D BarCode 14
	m_2DBarCode.bBpo			= FALSE;
	m_2DBarCode.bDatamatrix		= TRUE;
	m_2DBarCode.bMaxicode		= FALSE;
	m_2DBarCode.bPdf417			= TRUE;
	m_2DBarCode.bMicroPdf417	= FALSE;
	m_2DBarCode.bPlanet			= FALSE;
	m_2DBarCode.bQrCode			= FALSE;
	m_2DBarCode.bTlc39			= FALSE;
	m_2DBarCode.bPostnet		= FALSE;
	m_2DBarCode.bAusPost		= FALSE;
	m_2DBarCode.bCanadaPost		= FALSE;
	m_2DBarCode.bDutchPost		= FALSE;
	m_2DBarCode.bJapanPost		= FALSE;
	m_2DBarCode.bSwedenPost		= FALSE;

	SetScanOption();
}


void CM3ScanTestDlg::GetScanData(CString strType, CString strData)
{
	m_ctrlListScanData.InsertItem(0, strType,0);
	m_ctrlListScanData.SetItemText(0, 1, strData);
}

void CM3ScanTestDlg::LoadResSound(void)
{
	HINSTANCE hInst = AfxGetInstanceHandle();
	if(m_bBeep == TRUE)
		PlaySound(MAKEINTRESOURCE(IDR_WAVE_BEEP), hInst, SND_RESOURCE|SND_ASYNC);	
	else
		PlaySound(MAKEINTRESOURCE(IDR_WAVE_SCAN), hInst, SND_RESOURCE|SND_ASYNC);	
}

void CM3ScanTestDlg::SetScanOption(void)
{
	BeginWaitCursor();

	memset(&kRead, 0, sizeof(kRead));						// initialization
	kRead.nSize				= sizeof(kRead);				// initialization

	// KScanReadCallBack
	kRead.pUserData = this;	
	kRead.fnCallBack = KScanReadCallBack;

	// ReadOption
	kRead.nTimeInSeconds	= m_nTimeOut;		
	kRead.nSecurity			= m_nSecurityLevel; 

	// Option
	if(m_bXCD == TRUE)
		kRead.dwFlags |= KSCAN_FLAG_RETURNCHECK;
	if(m_bCenterDecode == TRUE)
		kRead.dwFlags |= KSCAN_FLAG_CENTERDECODE;
	if(m_b1DDecode == TRUE)
		kRead.dwFlags |= KSCAN_FLAG_1DDECODEMODE;

	// 1D BarCode 18
	if(m_1DBarCode.bCodabar)
		kRead.dwReadType |= KSCAN_READ_TYPE_CODABAR;
	if(m_1DBarCode.bCode11)
		kRead.dwReadType |= KSCAN_READ_TYPE_CODE11;
	if(m_1DBarCode.bCode39)
		kRead.dwReadType |= KSCAN_READ_TYPE_CODE39;
	if(m_1DBarCode.bCode93)
		kRead.dwReadType |= KSCAN_READ_TYPE_CODE93;
	if(m_1DBarCode.bCode128)
		kRead.dwReadType |= KSCAN_READ_TYPE_CODE128;
	if(m_1DBarCode.bGs1_128)
		kRead.dwReadType |= KSCAN_READ_TYPE_GS1_128;
	if(m_1DBarCode.bUpca)
		kRead.dwReadType |= KSCAN_READ_TYPE_UPCA;
	if(m_1DBarCode.bUpce)
		kRead.dwReadType |= KSCAN_READ_TYPE_UPCE;
	if(m_1DBarCode.bUpce1)
		kRead.dwReadType |= KSCAN_READ_TYPE_UPCE1;
	if(m_1DBarCode.bEan8)
		kRead.dwReadType |= KSCAN_READ_TYPE_EAN8;
	if(m_1DBarCode.bEan13)
		kRead.dwReadType |= KSCAN_READ_TYPE_EAN13;
	if(m_1DBarCode.bGs1)
		kRead.dwReadType |= KSCAN_READ_TYPE_GS1;
	if(m_1DBarCode.bI2of5)
		kRead.dwReadType |= KSCAN_READ_TYPE_I2OF5;
	if(m_1DBarCode.bMatrix2of5)
		kRead.dwReadType |= KSCAN_READ_TYPE_MATRIX2OF5;
	if(m_1DBarCode.bMsi)
		kRead.dwReadType |= KSCAN_READ_TYPE_MSI;
	if(m_1DBarCode.bPlessey)
		kRead.dwReadType |= KSCAN_READ_TYPE_PLESSEY;
	if(m_1DBarCode.bStandard2of5)
		kRead.dwReadType |= KSCAN_READ_TYPE_STANDARD2OF5;
	if(m_1DBarCode.bTelepen)
		kRead.dwReadType |= KSCAN_READ_TYPE_TELEPEN;

	// 2D BarCode 14
	if(m_2DBarCode.bBpo)
		kRead.dwReadType |= KSCAN_READ_TYPE_BPO;
	if(m_2DBarCode.bDatamatrix)
		kRead.dwReadType |= KSCAN_READ_TYPE_DATAMATRIX;
	if(m_2DBarCode.bMaxicode)
		kRead.dwReadType |= KSCAN_READ_TYPE_MAXICODE;
	if(m_2DBarCode.bPdf417)
		kRead.dwReadType |= KSCAN_READ_TYPE_PDF417;
	if(m_2DBarCode.bMicroPdf417)
		kRead.dwReadType |= KSCAN_READ_TYPE_MICROPDF417;
	if(m_2DBarCode.bPlanet)
		kRead.dwReadType |= KSCAN_READ_TYPE_PLANET;
	if(m_2DBarCode.bQrCode)
		kRead.dwReadType |= KSCAN_READ_TYPE_QRCODE;
	if(m_2DBarCode.bTlc39)
		kRead.dwReadType |= KSCAN_READ_TYPE_TLC39;
	if(m_2DBarCode.bPostnet)
		kRead.dwReadType |= KSCAN_READ_TYPE_POSTNET;
	if(m_2DBarCode.bAusPost)
		kRead.dwReadType |= KSCAN_READ_TYPE_AUSPOST;
	if(m_2DBarCode.bCanadaPost)
		kRead.dwReadType |= KSCAN_READ_TYPE_CANADAPOST;
	if(m_2DBarCode.bDutchPost)
		kRead.dwReadType |= KSCAN_READ_TYPE_DUTCHPOST;
	if(m_2DBarCode.bJapanPost)
		kRead.dwReadType |= KSCAN_READ_TYPE_JAPANPOST;
	if(m_2DBarCode.bSwedenPost)
		kRead.dwReadType |= KSCAN_READ_TYPE_SWEDENPOST;

	SetOption(&kRead);
	SetReturn(1, *KScanReadCallBack);

	EndWaitCursor();
}
