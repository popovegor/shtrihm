// 2DBarCodeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "2DBarCodeDlg.h"

#include "M3ScanTestDlg.h"


// C2DBarCodeDlg dialog

IMPLEMENT_DYNAMIC(C2DBarCodeDlg, CDialog)

C2DBarCodeDlg::C2DBarCodeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(C2DBarCodeDlg::IDD, pParent)
	, m_bBpo(FALSE)
	, m_bDataMatrix(FALSE)
	, m_bMaxiCode(FALSE)
	, m_bPdf417(FALSE)
	, m_bMicroPdf417(FALSE)
	, m_bPlanet(FALSE)
	, m_bQrCode(FALSE)
	, m_bTlc39(FALSE)
	, m_bPostnet(FALSE)
	, m_bAusPost(FALSE)
	, m_bCanadaPost(FALSE)
	, m_bDutchPost(FALSE)
	, m_bJapanPost(FALSE)
	, m_bSwedenPost(FALSE)
{

}

C2DBarCodeDlg::~C2DBarCodeDlg()
{
}

void C2DBarCodeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_BPO, m_bBpo);
	DDX_Check(pDX, IDC_CHECK_DATAMATRIX, m_bDataMatrix);
	DDX_Check(pDX, IDC_CHECK_MAXICODE, m_bMaxiCode);
	DDX_Check(pDX, IDC_CHECK_PDF417, m_bPdf417);
	DDX_Check(pDX, IDC_CHECK_MICROPDF417, m_bMicroPdf417);
	DDX_Check(pDX, IDC_CHECK_PLANET, m_bPlanet);
	DDX_Check(pDX, IDC_CHECK_QRCODE, m_bQrCode);
	DDX_Check(pDX, IDC_CHECK_TLC39, m_bTlc39);
	DDX_Check(pDX, IDC_CHECK_POST_NET, m_bPostnet);
	DDX_Check(pDX, IDC_CHECK_AUSPOST, m_bAusPost);
	DDX_Check(pDX, IDC_CHECK_CANADAPOST, m_bCanadaPost);
	DDX_Check(pDX, IDC_CHECK_DUTCHPOST, m_bDutchPost);
	DDX_Check(pDX, IDC_CHECK_JAPANPOST, m_bJapanPost);
	DDX_Check(pDX, IDC_CHECK_SWEDENPOST, m_bSwedenPost);
}


BEGIN_MESSAGE_MAP(C2DBarCodeDlg, CDialog)
	ON_BN_CLICKED(IDOK, &C2DBarCodeDlg::OnBnClickedOk)
END_MESSAGE_MAP()


// C2DBarCodeDlg message handlers

BOOL C2DBarCodeDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void C2DBarCodeDlg::GetOption(void)
{
	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	m_bBpo			= dlg->m_2DBarCode.bBpo;
	m_bDataMatrix	= dlg->m_2DBarCode.bDatamatrix;
	m_bMaxiCode		= dlg->m_2DBarCode.bMaxicode;
	m_bPdf417		= dlg->m_2DBarCode.bPdf417;
	m_bMicroPdf417	= dlg->m_2DBarCode.bMicroPdf417;
	m_bPlanet		= dlg->m_2DBarCode.bPlanet;
	m_bQrCode		= dlg->m_2DBarCode.bQrCode;
	m_bTlc39		= dlg->m_2DBarCode.bTlc39;
	m_bPostnet		= dlg->m_2DBarCode.bPostnet;
	m_bAusPost		= dlg->m_2DBarCode.bAusPost;
	m_bCanadaPost	= dlg->m_2DBarCode.bCanadaPost;
	m_bDutchPost	= dlg->m_2DBarCode.bDutchPost;
	m_bJapanPost	= dlg->m_2DBarCode.bJapanPost;
	m_bSwedenPost	= dlg->m_2DBarCode.bSwedenPost;

	UpdateData(FALSE);
}

void C2DBarCodeDlg::SetOption(void)
{
	UpdateData(TRUE);

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	dlg->m_2DBarCode.bBpo			= m_bBpo;
	dlg->m_2DBarCode.bDatamatrix	= m_bDataMatrix;
	dlg->m_2DBarCode.bMaxicode		= m_bMaxiCode;
	dlg->m_2DBarCode.bPdf417		= m_bPdf417;
	dlg->m_2DBarCode.bMicroPdf417	= m_bMicroPdf417;
	dlg->m_2DBarCode.bPlanet		= m_bPlanet;
	dlg->m_2DBarCode.bQrCode		= m_bQrCode;
	dlg->m_2DBarCode.bTlc39			= m_bTlc39;
	dlg->m_2DBarCode.bPostnet		= m_bPostnet;
	dlg->m_2DBarCode.bAusPost		= m_bAusPost;
	dlg->m_2DBarCode.bCanadaPost	= m_bCanadaPost;
	dlg->m_2DBarCode.bDutchPost		= m_bDutchPost;
	dlg->m_2DBarCode.bJapanPost		= m_bJapanPost;
	dlg->m_2DBarCode.bSwedenPost	= m_bSwedenPost;
}

void C2DBarCodeDlg::OnBnClickedOk()
{
	SetOption();
	OnOK();
}
