#pragma once


// C1DBarCodeDlg dialog

class C1DBarCodeDlg : public CDialog
{
	DECLARE_DYNAMIC(C1DBarCodeDlg)

public:
	C1DBarCodeDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~C1DBarCodeDlg();

// Dialog Data
	enum { IDD = IDD_1DBARCODE_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	void GetOption(void);
	void SetOption(void);
	afx_msg void OnBnClickedOk();
	BOOL m_bCodabar;
	BOOL m_bCode11;
	BOOL m_bCode39;
	BOOL m_bCode93;
	BOOL m_bCode128;
	BOOL m_bGs1_128;
	BOOL m_bUpca;
	BOOL m_bUpce;
	BOOL m_bUpce1;
	BOOL m_bEan8;
	BOOL m_bEan13;
	BOOL m_bGs1;
	BOOL m_bI2of5;
	BOOL m_bMatrix2of5;
	BOOL m_bMsi;
	BOOL m_bPlessey;
	BOOL m_bStandard2of5;
	BOOL m_bTelepen;
};
