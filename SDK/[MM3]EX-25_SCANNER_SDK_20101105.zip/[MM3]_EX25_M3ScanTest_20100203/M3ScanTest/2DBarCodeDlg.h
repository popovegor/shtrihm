#pragma once


// C2DBarCodeDlg dialog

class C2DBarCodeDlg : public CDialog
{
	DECLARE_DYNAMIC(C2DBarCodeDlg)

public:
	C2DBarCodeDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~C2DBarCodeDlg();

// Dialog Data
	enum { IDD = IDD_2DBARCODE_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	void GetOption(void);
	void SetOption(void);
	afx_msg void OnBnClickedOk();
	BOOL m_bBpo;
	BOOL m_bDataMatrix;
	BOOL m_bMaxiCode;
	BOOL m_bPdf417;
	BOOL m_bMicroPdf417;
	BOOL m_bPlanet;
	BOOL m_bQrCode;
	BOOL m_bTlc39;
	BOOL m_bPostnet;
	BOOL m_bAusPost;
	BOOL m_bCanadaPost;
	BOOL m_bDutchPost;
	BOOL m_bJapanPost;
	BOOL m_bSwedenPost;
};
