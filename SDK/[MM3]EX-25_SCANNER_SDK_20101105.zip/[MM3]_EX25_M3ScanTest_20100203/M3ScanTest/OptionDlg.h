#pragma once
#include "afxwin.h"


// COptionDlg dialog

class COptionDlg : public CDialog
{
	DECLARE_DYNAMIC(COptionDlg)

public:
	COptionDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~COptionDlg();

// Dialog Data
	enum { IDD = IDD_OPTION_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	void GetOption(void);
	void SetOption(void);
	afx_msg void OnBnClickedOk();
	int m_nSyncMode;
	CComboBox m_ctrlComboTimeOut;
	CComboBox m_ctrlComboSecurityLevel;
	BOOL m_bXcd;
	BOOL m_bCenterDecode;
	BOOL m_bBeep;
	BOOL m_b1DDecode;
};
