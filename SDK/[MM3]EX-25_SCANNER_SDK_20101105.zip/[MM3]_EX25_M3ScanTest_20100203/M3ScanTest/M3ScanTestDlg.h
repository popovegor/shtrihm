// M3ScanTestDlg.h : header file
//

#pragma once

// CM3ScanTestDlg dialog
#include "KScanBar.h"
#include "afxcmn.h"
#include "Reg.h"
typedef struct _MC1DBarCodeType
{	
	// 1D BarCode 18
	BOOL bCodabar;
	BOOL bCode11;
	BOOL bCode39;
	BOOL bCode93;
	BOOL bCode128;
	BOOL bGs1_128;
	BOOL bUpca;
	BOOL bUpce;
	BOOL bUpce1;
	BOOL bEan8;
	BOOL bEan13;
	BOOL bGs1;
	BOOL bI2of5;
	BOOL bMatrix2of5;
	BOOL bMsi;
	BOOL bPlessey;
	BOOL bStandard2of5;
	BOOL bTelepen;

}MC1DBarCodeType,* P1DBarCodeType;

typedef struct _MC2DBarCodeType
{	
	//2D BarCode 14
	BOOL bBpo;
	BOOL bDatamatrix;
	BOOL bMaxicode;
	BOOL bPdf417;
	BOOL bMicroPdf417;
	BOOL bPlanet;
	BOOL bQrCode;
	BOOL bTlc39;
	BOOL bPostnet;
	BOOL bAusPost;
	BOOL bCanadaPost;
	BOOL bDutchPost;
	BOOL bJapanPost;
	BOOL bSwedenPost;
}MC2DBarCodeType,* P2DBarCodeType;

class CM3ScanTestDlg : public CDialog
{
// Construction
public:
	CM3ScanTestDlg(CWnd* pParent = NULL);	// standard constructor

	CReg	m_Reg;
	DWORD	m_nDisplayType;
	BOOL	m_bKeyFlag;
	BOOL	m_bReading;
	BOOL	m_bBeep;
	DWORD	m_nSyncMode;
	DWORD	m_nTimeOut;
	DWORD	m_nSecurityLevel;
	BOOL	m_bXCD;
	BOOL	m_bCenterDecode;
	BOOL	m_b1DDecode;	

	MC1DBarCodeType m_1DBarCode;
	MC2DBarCodeType m_2DBarCode;

// Dialog Data
	enum { IDD = IDD_M3SCANTEST_DIALOG };


	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedBtnOption();
	afx_msg void OnBnClickedBtn1dbarcode();
	afx_msg void OnBnClickedBtn2dbarcode();
	void M3ScanInit(void);
	void M3ScanClose(void);
	void SetDefaultOption(void);
	void M3ScanRead(void);
	afx_msg void OnDestroy();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	void GetScanData(CString strType, CString strData);
	void LoadResSound(void);
	CListCtrl m_ctrlListScanData;
	void SetScanOption(void);
	afx_msg void OnBnClickedBtnScan();
	afx_msg void OnBnClickedBtnClear();
	afx_msg void OnBnClickedBtnScancancel();
};
