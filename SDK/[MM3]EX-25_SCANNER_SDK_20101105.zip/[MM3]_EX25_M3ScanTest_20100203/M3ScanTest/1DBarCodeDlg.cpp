// 1DBarCodeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "1DBarCodeDlg.h"

#include "M3ScanTestDlg.h"


// C1DBarCodeDlg dialog

IMPLEMENT_DYNAMIC(C1DBarCodeDlg, CDialog)

C1DBarCodeDlg::C1DBarCodeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(C1DBarCodeDlg::IDD, pParent)
	, m_bCodabar(FALSE)
	, m_bCode11(FALSE)
	, m_bCode39(FALSE)
	, m_bCode93(FALSE)
	, m_bCode128(FALSE)
	, m_bGs1_128(FALSE)
	, m_bUpca(FALSE)
	, m_bUpce(FALSE)
	, m_bUpce1(FALSE)
	, m_bEan8(FALSE)
	, m_bEan13(FALSE)
	, m_bGs1(FALSE)
	, m_bI2of5(FALSE)
	, m_bMatrix2of5(FALSE)
	, m_bMsi(FALSE)
	, m_bPlessey(FALSE)
	, m_bStandard2of5(FALSE)
	, m_bTelepen(FALSE)
{

}

C1DBarCodeDlg::~C1DBarCodeDlg()
{
}

void C1DBarCodeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_CODABAR, m_bCodabar);
	DDX_Check(pDX, IDC_CHECK_CODE11, m_bCode11);
	DDX_Check(pDX, IDC_CHECK_CODE39, m_bCode39);
	DDX_Check(pDX, IDC_CHECK_CODE93, m_bCode93);
	DDX_Check(pDX, IDC_CHECK_CODE128, m_bCode128);
	DDX_Check(pDX, IDC_CHECK_GS1128, m_bGs1_128);
	DDX_Check(pDX, IDC_CHECK_UPCA, m_bUpca);
	DDX_Check(pDX, IDC_CHECK_UPCE, m_bUpce);
	DDX_Check(pDX, IDC_CHECK_UPCE1, m_bUpce1);
	DDX_Check(pDX, IDC_CHECK_EAN8, m_bEan8);
	DDX_Check(pDX, IDC_CHECK_EAN13, m_bEan13);
	DDX_Check(pDX, IDC_CHECK_GS1, m_bGs1);
	DDX_Check(pDX, IDC_CHECK_I2OF5, m_bI2of5);
	DDX_Check(pDX, IDC_CHECK_MATRIX2OF5, m_bMatrix2of5);
	DDX_Check(pDX, IDC_CHECK_MSI, m_bMsi);
	DDX_Check(pDX, IDC_CHECK_PLESSEY, m_bPlessey);
	DDX_Check(pDX, IDC_CHECK_STANDARD2OF5, m_bStandard2of5);
	DDX_Check(pDX, IDC_CHECK_TELEPEN, m_bTelepen);
}


BEGIN_MESSAGE_MAP(C1DBarCodeDlg, CDialog)
	ON_BN_CLICKED(IDOK, &C1DBarCodeDlg::OnBnClickedOk)
END_MESSAGE_MAP()


// C1DBarCodeDlg message handlers

BOOL C1DBarCodeDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void C1DBarCodeDlg::GetOption(void)
{
	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	m_bCodabar		= dlg->m_1DBarCode.bCodabar;
	m_bCode11		= dlg->m_1DBarCode.bCode11;
	m_bCode39		= dlg->m_1DBarCode.bCode39;
	m_bCode93		= dlg->m_1DBarCode.bCode93;
	m_bCode128		= dlg->m_1DBarCode.bCode128;
	m_bGs1_128		= dlg->m_1DBarCode.bGs1_128;
	m_bUpca			= dlg->m_1DBarCode.bUpca;
	m_bUpce			= dlg->m_1DBarCode.bUpce;
	m_bUpce1		= dlg->m_1DBarCode.bUpce1;
	m_bEan8			= dlg->m_1DBarCode.bEan8;
	m_bEan13		= dlg->m_1DBarCode.bEan13;
	m_bGs1			= dlg->m_1DBarCode.bGs1;
	m_bI2of5		= dlg->m_1DBarCode.bI2of5;
	m_bMatrix2of5	= dlg->m_1DBarCode.bMatrix2of5;
	m_bMsi			= dlg->m_1DBarCode.bMsi;
	m_bPlessey		= dlg->m_1DBarCode.bPlessey;
	m_bStandard2of5 = dlg->m_1DBarCode.bStandard2of5;
	m_bTelepen		= dlg->m_1DBarCode.bTelepen;

	UpdateData(FALSE);
}

void C1DBarCodeDlg::SetOption(void)
{
	UpdateData(TRUE);
	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	dlg->m_1DBarCode.bCodabar		= m_bCodabar;
	dlg->m_1DBarCode.bCode11		= m_bCode11;
	dlg->m_1DBarCode.bCode39		= m_bCode39;
	dlg->m_1DBarCode.bCode93		= m_bCode93;
	dlg->m_1DBarCode.bCode128		= m_bCode128;
	dlg->m_1DBarCode.bGs1_128		= m_bGs1_128;
	dlg->m_1DBarCode.bUpca			= m_bUpca;
	dlg->m_1DBarCode.bUpce			= m_bUpce;
	dlg->m_1DBarCode.bUpce1			= m_bUpce1;
	dlg->m_1DBarCode.bEan8			= m_bEan8;
	dlg->m_1DBarCode.bEan13			= m_bEan13;
	dlg->m_1DBarCode.bGs1			= m_bGs1;
	dlg->m_1DBarCode.bI2of5			= m_bI2of5;
	dlg->m_1DBarCode.bMatrix2of5	= m_bMatrix2of5;
	dlg->m_1DBarCode.bMsi			= m_bMsi;
	dlg->m_1DBarCode.bPlessey		= m_bPlessey;
	dlg->m_1DBarCode.bStandard2of5	= m_bStandard2of5;
	dlg->m_1DBarCode.bTelepen		= m_bTelepen;
}

void C1DBarCodeDlg::OnBnClickedOk()
{
	SetOption();
	OnOK();
}
