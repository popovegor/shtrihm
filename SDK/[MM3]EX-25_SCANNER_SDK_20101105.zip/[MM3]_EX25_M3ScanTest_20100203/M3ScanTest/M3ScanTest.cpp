// M3ScanTest.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "M3ScanTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CM3ScanTestApp

BEGIN_MESSAGE_MAP(CM3ScanTestApp, CWinApp)
END_MESSAGE_MAP()


// CM3ScanTestApp construction
CM3ScanTestApp::CM3ScanTestApp()
	: CWinApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only CM3ScanTestApp object
CM3ScanTestApp theApp;

// CM3ScanTestApp initialization

BOOL CM3ScanTestApp::InitInstance()
{
    // SHInitExtraControls should be called once during your application's initialization to initialize any
    // of the Windows Mobile specific controls such as CAPEDIT and SIPPREF.
    SHInitExtraControls();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	///////////////////////////////////////  �ߺ����� ����//////////////////////////////////////
	HANDLE hMutexOneInstance  = ::CreateMutex(NULL, TRUE, _T("M3SCANNER")); 

	BOOL bFound = FALSE; 
	// ���� �̹� ������� �ִٸ� Instance�� �̹� ������
	if(::GetLastError() == ERROR_ALREADY_EXISTS) 
		bFound = TRUE; 
	if(hMutexOneInstance) 
	{
		ReleaseMutex(hMutexOneInstance); 	
	}
	// �̹� �ϳ��� Instance�� �����ϸ� ���α׷� ����
	if(bFound)
	{
		AfxMessageBox(L"Scanner Engine is already running!");
		return FALSE;
	}
	////////////////////////////////////////////////////////////////////////////////////////////////

	CM3ScanTestDlg dlg;
	m_pMainWnd = &dlg;
	INT_PTR nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
