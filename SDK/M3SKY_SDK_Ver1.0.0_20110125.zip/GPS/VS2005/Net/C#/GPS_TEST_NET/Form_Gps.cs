﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.WindowsCE.Forms;
using System.Runtime.InteropServices;

namespace GpsParseDemoNet
{
    public partial class Form_GPS : Form
    {
        Class_Gps_Parse cGps;
        MsgWindow MsgWin;
        IntPtr m_hWnd;

        private bool m_bOpenGps = false;

        public Form_GPS()
        {
            InitializeComponent();

            button_disconnect.Enabled = false;
            cGps = new Class_Gps_Parse();
            MsgWin = new MsgWindow(this);
            m_hWnd = MsgWin.Hwnd;

            label_altitude.Text = "";
            label_latitude.Text = "";
            label_heading.Text = "";
            label_longitude.Text = "";
            label_satellite.Text = "";
            label_time.Text = "";
            label_status.Text = "";
            label_snr.Text = "";
            label_velocity.Text = "";

            comboBox_com.Items.Add("COM0:");
            comboBox_com.Items.Add("COM1:");
            comboBox_com.Items.Add("COM2:");
            comboBox_com.Items.Add("COM3:");
            comboBox_com.Items.Add("COM4:");
            comboBox_com.Items.Add("COM5:");
            comboBox_com.Items.Add("COM6:");
            comboBox_com.Items.Add("COM7:");
            comboBox_com.Items.Add("COM8:");
            comboBox_com.Items.Add("COM9:");

            comboBox_com.SelectedIndex = 2;
        }

        private void button_connect_Click(object sender, EventArgs e)
        {
            if(m_bOpenGps == false)
            {
                string strCom = comboBox_com.Text;

                if (cGps.Gps_Open(MsgWin.Hwnd, strCom, 9600))
                {
                    button_connect.Enabled = false;
                    button_disconnect.Enabled = true;

                    m_bOpenGps = true;
                }
                else
                {
                    MessageBox.Show("Open Fail");
                }

            }
        }

        private void button_disconnect_Click(object sender, EventArgs e)
        {
            if(m_bOpenGps == true)
            {
                if(cGps.Gps_Close())
                {
                    button_connect.Enabled = true;
                    button_disconnect.Enabled = false;

                    m_bOpenGps = false;

                }
                else
                {
                    MessageBox.Show("Close Fail");
                }

            }
        }

            
        public long OnRecvGpsData(IntPtr wParam, IntPtr lParam)
        {
            Class_Gps_Parse.GPS_PARSE_INFO info = new Class_Gps_Parse.GPS_PARSE_INFO();

            try
            {
                info = (Class_Gps_Parse.GPS_PARSE_INFO)Marshal.PtrToStructure(wParam, typeof(Class_Gps_Parse.GPS_PARSE_INFO));

                GpsInfoParse(info);
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
                cGps.Gps_Close();
                this.Close();
                return 0;
            }

            return 0;
        }


        public void GpsInfoParse(Class_Gps_Parse.GPS_PARSE_INFO info)
        {
            try
            {
                int nUTChour, nUTCmin, nUTCsec;
                int nDeg = 0, nMin = 0, nSec = 0;

                // status
                if (info.nPosFix > 0)
                {
                    label_status.Text = "GPS On";
                }
                else
                {
                    label_status.Text = "Waiting...";
                }

                // Time
                nUTChour = (int)(info.dUTCTime / 10000);
                nUTCmin = (int)(info.dUTCTime / 100) - nUTChour * 100;
                nUTCsec = (int)(info.dUTCTime / 1) - nUTChour * 10000 - nUTCmin * 100;
                nUTChour += 9; // Korea Time GMT + 9

                if (nUTChour > 24) nUTChour -= 24;
                label_time.Text = String.Format("{0}:{1}:{2}", nUTChour, nUTCmin, nUTCsec);

                // Latitude
                nDeg = (int)(info.dLatitude / 100);
                nMin = (int)(info.dLatitude / 1) - nDeg * 100;
                nSec = (int)((info.dLatitude - nDeg * 100 - nMin) * 60);

                if (info.bNorthLatitude) label_latitude.Text = String.Format("N {0}, {1}, {2}", nDeg, nMin, nSec);
                else label_latitude.Text = String.Format("S {0}, {1}, {2}", nDeg, nMin, nSec);

                // Longitude
                nDeg = (int)(info.dLongitude / 100);
                nMin = (int)(info.dLongitude / 1) - nDeg * 100;
                nSec = (int)((info.dLongitude - nDeg * 100 - nMin) * 60);

                if (info.bEastLongitude) label_longitude.Text = String.Format("E {0}, {1}, {2}", nDeg, nMin, nSec);
                else label_longitude.Text = String.Format("W {0}, {1}, {2}", nDeg, nMin, nSec);

                // Altitude
                label_altitude.Text = String.Format("{0} m", info.dAltitude);

                // Satellite
                label_satellite.Text = String.Format("{0} / {1}", info.nSatInUse, info.nSatNum);

                // SNR
                string szSnr = "";
                for (int i = 0; i < info.nSatNum; i++)
                {
                    szSnr = String.Format("[{0}:{1}] {2}", info.mSat[i].nID, info.mSat[i].nSNR, szSnr);
                }

                label_snr.Text = szSnr;

                // Velocity
                label_velocity.Text = String.Format("{0} Km", info.dVelocity);

                // Heading 
                label_heading.Text = String.Format("{0}", info.dHeading);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }


    }
    


    public class MsgWindow : MessageWindow
    {
        private Form_GPS msgform;

        public MsgWindow(Form_GPS form)
        {
            this.msgform = form;
        }


        protected override void WndProc(ref Message msg)
        {
            switch (msg.Msg)
            {
                case Class_Gps_Parse.WM_USER_RECVDATA:
                    this.msgform.OnRecvGpsData(msg.WParam, msg.LParam);
                    break;
            }

            base.WndProc(ref msg);
        }

    }
}