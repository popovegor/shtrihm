﻿namespace GpsParseDemoNet
{
    partial class Form_GPS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_connect = new System.Windows.Forms.Button();
            this.button_disconnect = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label_snr = new System.Windows.Forms.Label();
            this.label_satellite = new System.Windows.Forms.Label();
            this.label_heading = new System.Windows.Forms.Label();
            this.label_velocity = new System.Windows.Forms.Label();
            this.label_altitude = new System.Windows.Forms.Label();
            this.label_longitude = new System.Windows.Forms.Label();
            this.label_latitude = new System.Windows.Forms.Label();
            this.label_time = new System.Windows.Forms.Label();
            this.label_status = new System.Windows.Forms.Label();
            this.comboBox_com = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // button_connect
            // 
            this.button_connect.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.button_connect.Location = new System.Drawing.Point(70, 12);
            this.button_connect.Name = "button_connect";
            this.button_connect.Size = new System.Drawing.Size(68, 23);
            this.button_connect.TabIndex = 0;
            this.button_connect.Text = "Connect";
            this.button_connect.Click += new System.EventHandler(this.button_connect_Click);
            // 
            // button_disconnect
            // 
            this.button_disconnect.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.button_disconnect.Location = new System.Drawing.Point(144, 12);
            this.button_disconnect.Name = "button_disconnect";
            this.button_disconnect.Size = new System.Drawing.Size(68, 23);
            this.button_disconnect.TabIndex = 1;
            this.button_disconnect.Text = "Disconnect";
            this.button_disconnect.Click += new System.EventHandler(this.button_disconnect_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.label1.Location = new System.Drawing.Point(14, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 17);
            this.label1.Text = "GPS Status";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.label2.Location = new System.Drawing.Point(15, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 17);
            this.label2.Text = "Time";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.label3.Location = new System.Drawing.Point(14, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 17);
            this.label3.Text = "Latitude";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.label4.Location = new System.Drawing.Point(14, 97);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 17);
            this.label4.Text = "Longitude";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.label5.Location = new System.Drawing.Point(14, 114);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 17);
            this.label5.Text = "Altitude";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.label6.Location = new System.Drawing.Point(15, 131);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 17);
            this.label6.Text = "Velocity";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.label7.Location = new System.Drawing.Point(15, 148);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 17);
            this.label7.Text = "Heading";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.label8.Location = new System.Drawing.Point(14, 165);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 17);
            this.label8.Text = "Satellite";
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.label9.Location = new System.Drawing.Point(14, 182);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 17);
            this.label9.Text = "SNR [ID:SNR]";
            // 
            // label_snr
            // 
            this.label_snr.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.label_snr.Location = new System.Drawing.Point(14, 199);
            this.label_snr.Name = "label_snr";
            this.label_snr.Size = new System.Drawing.Size(197, 63);
            this.label_snr.Text = "SNR";
            // 
            // label_satellite
            // 
            this.label_satellite.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.label_satellite.Location = new System.Drawing.Point(87, 165);
            this.label_satellite.Name = "label_satellite";
            this.label_satellite.Size = new System.Drawing.Size(129, 17);
            this.label_satellite.Text = "satellite";
            // 
            // label_heading
            // 
            this.label_heading.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.label_heading.Location = new System.Drawing.Point(88, 148);
            this.label_heading.Name = "label_heading";
            this.label_heading.Size = new System.Drawing.Size(129, 17);
            this.label_heading.Text = "heading";
            // 
            // label_velocity
            // 
            this.label_velocity.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.label_velocity.Location = new System.Drawing.Point(88, 131);
            this.label_velocity.Name = "label_velocity";
            this.label_velocity.Size = new System.Drawing.Size(129, 17);
            this.label_velocity.Text = "velocity";
            // 
            // label_altitude
            // 
            this.label_altitude.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.label_altitude.Location = new System.Drawing.Point(87, 114);
            this.label_altitude.Name = "label_altitude";
            this.label_altitude.Size = new System.Drawing.Size(129, 17);
            this.label_altitude.Text = "altitude";
            // 
            // label_longitude
            // 
            this.label_longitude.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.label_longitude.Location = new System.Drawing.Point(87, 97);
            this.label_longitude.Name = "label_longitude";
            this.label_longitude.Size = new System.Drawing.Size(129, 17);
            this.label_longitude.Text = "longitude";
            // 
            // label_latitude
            // 
            this.label_latitude.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.label_latitude.Location = new System.Drawing.Point(87, 80);
            this.label_latitude.Name = "label_latitude";
            this.label_latitude.Size = new System.Drawing.Size(129, 17);
            this.label_latitude.Text = "latitude";
            // 
            // label_time
            // 
            this.label_time.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.label_time.Location = new System.Drawing.Point(88, 63);
            this.label_time.Name = "label_time";
            this.label_time.Size = new System.Drawing.Size(129, 17);
            this.label_time.Text = "time";
            // 
            // label_status
            // 
            this.label_status.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.label_status.Location = new System.Drawing.Point(87, 46);
            this.label_status.Name = "label_status";
            this.label_status.Size = new System.Drawing.Size(129, 17);
            this.label_status.Text = "status";
            // 
            // comboBox_com
            // 
            this.comboBox_com.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.comboBox_com.Location = new System.Drawing.Point(8, 13);
            this.comboBox_com.Name = "comboBox_com";
            this.comboBox_com.Size = new System.Drawing.Size(56, 21);
            this.comboBox_com.TabIndex = 18;
            // 
            // Form_GPS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(238, 278);
            this.Controls.Add(this.comboBox_com);
            this.Controls.Add(this.label_satellite);
            this.Controls.Add(this.label_heading);
            this.Controls.Add(this.label_velocity);
            this.Controls.Add(this.label_altitude);
            this.Controls.Add(this.label_longitude);
            this.Controls.Add(this.label_latitude);
            this.Controls.Add(this.label_time);
            this.Controls.Add(this.label_status);
            this.Controls.Add(this.label_snr);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_disconnect);
            this.Controls.Add(this.button_connect);
            this.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.MinimizeBox = false;
            this.Name = "Form_GPS";
            this.Text = "GPS_Parse_Net";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_connect;
        private System.Windows.Forms.Button button_disconnect;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label_snr;
        private System.Windows.Forms.Label label_satellite;
        private System.Windows.Forms.Label label_heading;
        private System.Windows.Forms.Label label_velocity;
        private System.Windows.Forms.Label label_altitude;
        private System.Windows.Forms.Label label_longitude;
        private System.Windows.Forms.Label label_latitude;
        private System.Windows.Forms.Label label_time;
        private System.Windows.Forms.Label label_status;
        private System.Windows.Forms.ComboBox comboBox_com;
    }
}

