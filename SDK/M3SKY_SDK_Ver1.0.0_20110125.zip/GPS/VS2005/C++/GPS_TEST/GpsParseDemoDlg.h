// GpsParseDemoDlg.h : header file
//
#pragma once

#include "afxwin.h"
#include "M3GpsParse.h"

// CGpsParseDemoDlg dialog
class CGpsParseDemoDlg : public CDialog
{
// Construction
public:
	CGpsParseDemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_GPSPARSEDEMO_DIALOG };


	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual void OnOK();
	virtual void OnCancel();

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
#if defined(_DEVICE_RESOLUTION_AWARE) && !defined(WIN32_PLATFORM_WFSP)
	afx_msg void OnSize(UINT /*nType*/, int /*cx*/, int /*cy*/);
#endif
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonConnect();
	afx_msg void OnBnClickedButtonDisconnect();

	void ParseGPSMsg(GPSParseInfo *pInf);
	BOOL WriteToFile(const TCHAR* tszFilePath, CString cstrMsg);
	long OnRecvGPSData(WPARAM wParam, LPARAM lParam);

	static void fnParseGps(GPSParseInfo info);

	CString m_strTime;
	CString m_strLatitude;
	CString m_strLongitude;
	CString m_strAltitude;
	CString m_strSatellite;
	CString m_strVelocity;
	CString m_strHeading;
	CString m_strSNR;
	CString m_strGpsStatus;

	BOOL m_bOpenGps;
	CButton m_chkFileWrite;
	CComboBox m_cmbComPort;
	CComboBox m_cmbStaticMode;
	afx_msg void OnBnClickedButtonRestart();
	afx_msg void OnCbnSelchangeComboStatic();
};
