#define M3GPSPARSE_API __declspec(dllexport)

#define SATELLITE_COUNT	12


struct GPSDop
{
	double dPDop;
	double dHDop;
	double dVDop;
};

struct GPSSatellite
{
	int nID;
	int nElevation;
	int nAzimuth;
	int nSNR;
};

struct GPSParseInfo{
	struct GPSSatellite mSat[SATELLITE_COUNT];
	struct GPSDop mDop;

	int nSatInUse;
	int	nSatNum;
	BOOL bSatInfo;

	double dHeading;
	double dVelocity;

	BOOL bNorthLatitude;
	BOOL bEastLongitude;
	double dLatitude;
	double dLongitude;
	double dAltitude;

	double dUTCDate;
	double dUTCTime;

	int nPosFix;
	int nGPSStatus;

	CString mNMEAMsg;
};

#define WM_USER_RECVDATA		(WM_USER+10000) // You doesn't want using a 'SendMessage' then Function 'M3GPS_Open' hMainWnd set NULL.
typedef void (*M3GetGpsInfoProc)(GPSParseInfo info); // You doesn't want using a Function Pointer then Function 'M3GPS_Open' GetFunc set NULL.

// Restart type
#define GPS_COLD_START	0
#define GPS_WARM_START	1
#define GPS_HOT_START	2
//

EXTERN_C M3GPSPARSE_API BOOL M3GPS_Open(HWND hMainWnd, TCHAR* tzComPort, int nBaudRate, M3GetGpsInfoProc GetFunc = NULL);
EXTERN_C M3GPSPARSE_API BOOL M3GPS_Close();
EXTERN_C M3GPSPARSE_API BOOL M3GPS_ModuleRestart(int nStartType);
EXTERN_C M3GPSPARSE_API BOOL M3GPS_EnableStaticMode(BOOL bEnable);
