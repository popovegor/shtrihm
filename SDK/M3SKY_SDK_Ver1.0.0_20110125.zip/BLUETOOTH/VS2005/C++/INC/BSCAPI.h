/*****< bscapi.h >*************************************************************/
/*      Copyright 2000 - 2008 Stonestreet One, Inc.                           */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  BSCAPI - Stonestreet One Bluetooth Stack Controller API Type Definitions, */
/*           Constants, and Prototypes.                                       */
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   09/11/00  D. Lange       Initial creation.                               */
/*   09/18/08  T. Thomas      Updates for BT 2.1                              */
/******************************************************************************/
#ifndef __BSCAPIH__
#define __BSCAPIH__

#include "BTAPITyp.h"           /* Bluetooth API Type Definitions.            */
#include "BTTypes.h"            /* Bluetooth Type Definitions/Constants.      */
#include "HCITypes.h"           /* Bluetooth HCI Type Definitions/Constants.  */

   /* The following definitions, represent BIT Flags that can be used   */
   /* with the BSC_Initialize() function.  These Bit Flags can be used  */
   /* to inform the Bluetooth Stack Controller of various Requested     */
   /* options.                                                          */
#define BSC_INITIALIZE_FLAG_NO_L2CAP                            0x00000001L
#define BSC_INITIALIZE_FLAG_NO_SCO                              0x00000002L
#define BSC_INITIALIZE_FLAG_NO_SDP                              0x00000004L
#define BSC_INITIALIZE_FLAG_NO_RFCOMM                           0x00000008L
#define BSC_INITIALIZE_FLAG_NO_GAP                              0x00001000L
#define BSC_INITIALIZE_FLAG_NO_SPP                              0x00002000L
#define BSC_INITIALIZE_FLAG_NO_GOEP                             0x00004000L
#define BSC_INITIALIZE_FLAG_NO_OTP                              0x00008000L

   /* The following defines the valid Result Values that can be returned*/
   /* in the Result field of the Authentication Request Event.          */
#define BSC_AUTHENTICATION_REQUEST_RESULT_SUCCESS               0x00
#define BSC_AUTHENTICATION_REQUEST_RESULT_IN_PROGRESS           0x01
#define BSC_AUTHENTICATION_REQUEST_RESULT_REFUSED               0x02
#define BSC_AUTHENTICATION_REQUEST_RESULT_FAILURE               0x03

   /* The following enumerated type represents the BSC Event Reason     */
   /* (and valid Data) and is used with the BSC Event Callback.         */
typedef enum
{
   beAuthenticationRequest
} BSC_Event_Type_t;

   /* The following structure defines the Authentication Request Event  */
   /* data.                                                             */
typedef struct _tagBSC_Authentication_Request_t
{
  BD_ADDR_t  BD_ADDR;
  Byte_t    *Result;
} BSC_Authentication_Request_t;

#define BSC_AUTHENTICATION_REQUEST_SIZE         (sizeof(BSC_Authentication_Request_t))

   /* The following structure represents the container structure that   */
   /* holds all BSC Event Data Data.                                    */
typedef struct _tagBSC_Event_Data_t
{
   BSC_Event_Type_t  Event_Type;
   DWord_t           Event_Data_Length;
   union
   {
      BSC_Authentication_Request_t *BSC_Authentication_Request;
   } Event_Data;
} BSC_Event_Data_t;

#define BSC_EVENT_DATA_SIZE                     (sizeof(BSC_Event_Data_t))

   /* The following definitons represent the BIT Flags that can be used */
   /* with the BSC_BluetoothProfileInfoEntry_t structure.  These Bit    */
   /* Flags are used to define specific information about the Bluetooth */
   /* Profile Information Entry.                                        */
#define BSC_BLUETOOTH_PROFILE_INFORMATION_SERVER_FLAG           0x00000001L
#define BSC_BLUETOOTH_PROFILE_INFORMATION_CONNECTED_FLAG        0x00000002L

   /* The following definition represents the maximum number of         */
   /* connections that shall exist as part of a Bluetooth Profile       */
   /* Information Entry Profile Information Structure that may contain  */
   /* multiple connection entries.                                      */
#define BSC_BLUETOOTH_PROFILE_INFORMATION_MAXIMUM_NUMBER_CONNECTIONS (8)

   /* The following enumerated type represents all categories of        */
   /* Bluetooth Profiles that may be registered with the Bluetooth Stack*/
   /* Controller.                                                       */
typedef enum
{
   sbpSerialPort,
   sbpHeadsetAudioGateway,
   sbpHeadset,
   sbpDialUpNetworking,
   sbpFAX,
   sbpLANAccess,
   sbpOBEXObjectPush,
   sbpOBEXFileTransfer,
   sbpOBEXSynchronization,
   sbpHandsFreeAudioGateway,
   sbpHandsFree,
   sbpPersonalAreaNetworking,
} BSC_BluetoothProfileType_t;

   /* The following constants are used as invalid value for the Local   */
   /* COM Port and Local Baud Rate values with profiles that contain    */
   /* this information.                                                 */
#define BSC_INVALID_LOCAL_COM_PORT_VALUE                ((unsigned int)(-1))
#define BSC_INVALID_LOCAL_BAUD_RATE_VALUE               (0)

   /* The following structure contains all information about a Serial   */
   /* Port Profile in use by the Bluetooth Protocol Stack.              */
typedef struct _tagBSC_SerialPortInfo_t
{
   unsigned int RFCOMMServerPort;
   unsigned int LocalPort;
   unsigned int LocalBaudRate;
} BSC_SerialPortProfileInfo_t;

   /* The following structure contains all information about a Headset  */
   /* Profile Audio Gateway Role in use by the Bluetooth Protocol Stack.*/
typedef struct _tagBSC_HeadsetAudioGatewayInfo_t
{
   unsigned int RFCOMMServerPort;
} BSC_HeadsetAudioGatewayProfileInfo_t;

   /* The following structure contains all information about a Headset  */
   /* Profile Headset Role in use by the Bluetooth Protocol Stack.      */
typedef struct _tagBSC_HeadsetInfo_t
{
   unsigned int RFCOMMServerPort;
} BSC_HeadsetInfo_t;

   /* The following structure contains all information about a Dialup   */
   /* Networking Profile in use by the Bluetooth Protocol Stack.        */
typedef struct _tagBSC_DialupNetworkingInfo_t
{
   unsigned int RFCOMMServerPort;
   unsigned int LocalPort;
   unsigned int LocalBaudRate;
} BSC_DialupNetworkingInfo_t;

   /* The following structure contains all information about a FAX      */
   /* Profile in use by the Bluetooth Protocol Stack.                   */
typedef struct _tagBSC_FAXInfo_t
{
   unsigned int RFCOMMServerPort;
   unsigned int LocalPort;
   unsigned int LocalBaudRate;
} BSC_FAXInfo_t;

   /* The following structure contains all information about a LAN      */
   /* Access Profile in use by the Bluetooth Protocol Stack.            */
typedef struct _tagBSC_LANAccessInfo_t
{
   unsigned int RFCOMMServerPort;
   unsigned int LocalPort;
} BSC_LANAccessInfo_t;

   /* The following structure contains all information about an OBEX    */
   /* Object Push Profile in use by the Bluetooth Protocol Stack.       */
typedef struct _tagBSC_OBEXObjectPushInfo_t
{
   unsigned int RFCOMMServerPort;
} BSC_OBEXObjectPushInfo_t;

   /* The following structure contains all information about an OBEX    */
   /* File Transfer Profile in use by the Bluetooth Protocol Stack.     */
typedef struct _tagBSC_OBEXFileTransferInfo_t
{
   unsigned int RFCOMMServerPort;
} BSC_OBEXFileTransferInfo_t;

   /* The following structure contains all information about an OBEX    */
   /* Synchronization Profile in use by the Bluetooth Protocol Stack.   */
typedef struct _tagBSC_OBEXSynchronizationInfo_t
{
   unsigned int RFCOMMServerPort;
} BSC_OBEXSynchronizationInfo_t;

   /* The following structure contains all information about a Hands    */
   /* Free Profile Audio Gateway Role in use by the Bluetooth Protocol  */
   /* Stack.                                                            */
typedef struct _tagBSC_HandsFreeAudioGatewayInfo_t
{
   unsigned int RFCOMMServerPort;
} BSC_HandsFreeAudioGatewayInfo_t;

   /* The following structure contains all information about a Hands    */
   /* Free Profile Hands Free Role in use by the Bluetooth Protocol     */
   /* Stack.                                                            */
typedef struct _tagBSC_HandsFreeInfo_t
{
   unsigned int RFCOMMServerPort;
} BSC_HandsFreeInfo_t;

   /* The following structure contains all information about a Personal */
   /* Area Networking Profile instance in use by the Bluetooth Protocol */
   /* Stack.                                                            */
typedef struct _tagBSC_PersonalAreaNetworkingInfo_t
{
   unsigned long ServicesMask;
   unsigned int  NumberConnections;
   BD_ADDR_t     ConnectedDevices[BSC_BLUETOOTH_PROFILE_INFORMATION_MAXIMUM_NUMBER_CONNECTIONS];
} BSC_PersonalAreaNetworkingInfo_t;

   /* The following structure contains all information about the        */
   /* profiles that may be registered with the Bluetooth Stack          */
   /* Controller.                                                       */
typedef struct _tagBSC_BluetoothProfileInfoEntry_t
{
   unsigned int               Size;
   BSC_BluetoothProfileType_t BluetoothProfileType;
   unsigned long              Flags;
   BD_ADDR_t                  BD_ADDR;
   union
   {
      BSC_SerialPortProfileInfo_t          SerialPortProfileInfo;
      BSC_HeadsetAudioGatewayProfileInfo_t HeadsetAudioGatewayProfileInfo;
      BSC_HeadsetInfo_t                    HeadsetInfo;
      BSC_DialupNetworkingInfo_t           DialupNetworkingInfo;
      BSC_FAXInfo_t                        FAXInfo; 
      BSC_LANAccessInfo_t                  LANAccessInfo;
      BSC_OBEXObjectPushInfo_t             OBEXObjectPushInfo;
      BSC_OBEXFileTransferInfo_t           OBEXFileTransferInfo;
      BSC_OBEXSynchronizationInfo_t        OBEXSynchronizationInfo;
      BSC_HandsFreeAudioGatewayInfo_t      HandsFreeAudioGatewayInfo;
      BSC_HandsFreeInfo_t                  HandsFreeInfo;
      BSC_PersonalAreaNetworkingInfo_t     PersonalAreaNetworkingInfo;
      Byte_t                               Reserved[128];
   } ProfileInformation;
} BSC_BluetoothProfileInfoEntry_t;

#define BSC_BLUETOOTH_PROFILE_INFO_ENTRY_SIZE           (sizeof(BSC_BluetoothProfileInfoEntry_t))

   /* The following enumerated type is used with the                    */
   /* BSC_Get_Connection_Configuration() and the                        */
   /* BSC_Set_Connection_Configuration() functions.  These types        */
   /* dictate how the Bluetooth Stack will issue connection requests and*/
   /* respond to connection requests.  This function exists to allow    */
   /* Role Switching to take place at the HCI Layer when the stack is   */
   /* controlling the HCI Connection Establishment.  The Connect Request*/
   /* Configuration Types control how the stack will handle the Allow   */
   /* Role Switch parameter for the HCI Connection when the stack       */
   /* physically issues the HCI_Create_Connect() function.  The Connect */
   /* Response Configuration Types control how the stack will handle    */
   /* responding to an HCI_Connect_Request_Event.  The Ignore Request   */
   /* Response type should ONLY be used when some other entity is       */
   /* watching Connection Requests and controlling them (some form of   */
   /* connection manager).  In almost ALL circumstances, the stack can  */
   /* handle all HCI ACL Connection Requests/Responses so it is not     */
   /* envisioned that the Ignore Request will be used in practice.      */
   /* * NOTE * All of the Connect Request/Response parameters below     */
   /*          ONLY Apply to lower level HCI Role Switching parameters. */
   /*          These parameters are only needed in circumstances where  */
   /*          the programmer needs Point to Multi-Point capability     */
   /*          (either client or server).  The defaults for the stack   */
   /*          are                                                      */
   /*             - cqNoRoleSwitch                                      */
   /*             - csMaintainCurrentRole                               */
   /*                                                                   */
typedef enum
{
   bcqNoRoleSwitch,
   bcqAllowRoleSwitch
} BSC_Connect_Request_Configuration_t;

typedef enum
{
   bcsMaintainCurrentRole, 
   bcsRequestRoleSwitch, 
   bcsIgnoreConnectionRequest
} BSC_Connect_Response_Configuration_t;

   /* The following structure represents the structure of the BSC       */
   /* Utility Connection Configuration Parameters.  This structure is   */
   /* used with the BSC_Get_Connection_Configuration() and the          */
   /* BSC_Set_Connection_Configuration() functions.                     */
typedef struct _tagBSC_Connection_Configuration_Parameters_t
{
   BSC_Connect_Request_Configuration_t  BSC_Connect_Request_Configuration;
   BSC_Connect_Response_Configuration_t BSC_Connect_Response_Configuration;
} BSC_Connection_Configuration_Parameters_t;

   /* The following declared type represents the Prototype Function for */
   /* an Bluetooth Stack Timer Callback.  This function will be called  */
   /* whenever an installed Timer has expired (installed via the        */
   /* BSC_StartTimer() function).  This function passes to the caller   */
   /* the Bluetooth Stack ID that the Timer is valid for, the Timer ID  */
   /* of the expired Timer (returned from BSC_StartTimer()) and the     */
   /* Timer Callback Parameter that was specified when this Callback was*/
   /* installed.  This function is guaranteed NOT to be invoked more    */
   /* than once simultaneously for the specified installed callback     */
   /* (i.e. this function DOES NOT have be reentrant).  It should also  */
   /* be noted that this function is called in the Thread Context of a  */
   /* Thread that the User does NOT own.  Therefore, processing in this */
   /* function should be as efficient as possible (this argument holds  */
   /* anyway because no other Timer and/or Stack Callbacks will be      */
   /* issued while function call is outstanding).                       */
   /* ** NOTE ** This function MUST NOT Block and wait for events that  */
   /*            can only be satisfied by Receiving other Stack Events. */
   /*            A Deadlock WILL occur because NO Stack Event Callbacks */
   /*            will be issued while this function is currently        */
   /*            outstanding.                                           */
typedef void (BTPSAPI *BSC_Timer_Callback_t)(unsigned int BluetoothStackID, unsigned int TimerID, unsigned long CallbackParameter);

   /* The following declared type represents the Prototype Function for */
   /* an Bluetooth Stack Debug Data Callback.  This function will be    */
   /* called whenever a complete HCI Packet has been sent or received by*/
   /* the Bluetooth Device that was opened with the Bluetooth Protocol  */
   /* Stack.  This function passes to the caller the HCI Packet that    */
   /* was received and the Debug Callback Parameter that was specified  */
   /* when this Callback was installed.  The caller is free to use the  */
   /* contents of the HCI Packet ONLY in the context of this callback.  */
   /* this callback.  If the caller requires the Data for a longer      */
   /* period of time, then the callback function MUST copy the data     */
   /* into another Data Buffer.  This function is guaranteed NOT to be  */
   /* invoked more than once simultaneously for the specified installed */
   /* callback (i.e. this  function DOES NOT have be reentrant).  It    */
   /* should also be noted that this function is called in the Thread   */
   /* Context of a Thread that the User does NOT own.  Therefore,       */
   /* processing in this function should be as efficient as possible    */
   /* (this argument holds anyway because Packet Processing             */
   /* (Sending/Receiving) will be suspended while function call is      */
   /* outstanding).                                                     */
   /* ** NOTE ** THIS FUNCTION MUST NOT CALL ANY BLUETOOTH STACK        */
   /*            FUNCTIONS !!!!! FAILURE TO FOLLOW THIS GUIDELINE WILL  */
   /*            RESULT IN POTENTIAL DEADLOCKS AND/OR ERRATIC           */
   /*            BEHAVIOR !!!!!!!!!!                                    */
   /*            The Debug Callback is a VERY LOW LEVEL Callback and as */
   /*            such, does NOT allow the Bluetooth Stack to be         */
   /*            re-entrant !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */
typedef void (BTPSAPI *BSC_Debug_Callback_t)(unsigned int BluetoothStackID, BOOLEAN PacketSent, HCI_Packet_t *HCIPacket, unsigned long CallbackParameter);

   /* The following declared type represents the Prototype Function for */
   /* the BSC Event Receive Data Callback.  This function will be called*/
   /* whenever a Callback has been registered for the specified BSC     */
   /* Action that is associated with the specified Bluetooth Stack ID.  */
   /* This function passes to the caller the Bluetooth Stack ID, the BSC*/
   /* Event Data of the specified Event, and the BSC Event Callback     */
   /* Parameter that was specified when this Callback was installed.    */
   /* The caller is free to use the contents of the BSC Event Data ONLY */
   /* in the context of this callback.  If the caller requires the Data */
   /* for a longer period of time, then the callback function MUST copy */
   /* the data into another Data Buffer.  This function is guaranteed   */
   /* NOT to be invoked more than once simultaneously for the specified */
   /* installed callback (i.e.  this function DOES NOT have be          */
   /* reentrant).  Because of this, the processing in this function     */
   /* should be as efficient as possible.  It should also be noted that */
   /* this function is called in the Thread Context of a Thread that the*/
   /* User does NOT own.  Therefore, processing in this function should */
   /* be as efficient as possible (this argument holds anyway because   */
   /* other BSC Events will not be processed while this function call is*/
   /* outstanding).                                                     */
   /* ** NOTE ** This function MUST NOT Block and wait for events that  */
   /*            can only be satisfied by Receiving other BSC Events.  A*/
   /*            Deadlock WILL occur because NO BSC Event Callbacks will*/
   /*            be issued while this function is currently outstanding.*/
typedef void (BTPSAPI *BSC_Event_Callback_t)(unsigned int BluetoothStackID, BSC_Event_Data_t *BSC_Event_Data, unsigned long CallbackParameter);

   /* The following function is responsible for Initializing a Bluetooth*/
   /* Protocol Stack for the specified Bluetooth Device (using the      */
   /* specified HCI Transport).  This function *MUST* be called (and    */
   /* complete successfully) before any function in this module can be  */
   /* called.  The first parameter specifies the Bluetooth HCI Driver   */
   /* Transport Information to use when opening the Bluetooth Device    */
   /* and the second parameter specifies Flags that are to be used to   */
   /* alter the base Bluetooth Protocol Stack Functionality.  The HCI   */
   /* Driver Information parameter is NOT optional and must specify a   */
   /* valid Bluetooth HCI Driver transport provided by this Protocol    */
   /* Stack Implementation.  The flags parameter should be zero unless  */
   /* altered functionality is required.  Upon successfuly completion,  */
   /* this function will return a positive, non-zero, return value.     */
   /* This value will be used as input to functions provided by the     */
   /* Bluetooth Protocol Stack that require a Bluetooth Protocol Stack  */
   /* ID (functions that operate directly on a Bluetooth Device).  If   */
   /* this function fails, the return value will be a negative return   */
   /* code which specifies the error (see error codes defined           */
   /* elsewhere).  Once this function completes the specified Bluetooth */
   /* Protocol Stack ID will remain valid for the specified Bluetooth   */
   /* Device until the Bluetooth Stack is Closed via a call to the      */
   /* BSC_Shutdown() function.                                          */
   /* * NOTE * The Bit Mask values for the Flags Parameter are defined  */
   /*          at the top of this file.                                 */
__DLLMODEF__ int BTPSAPI BSC_Initialize(HCI_DriverInformation_t *HCI_DriverInformation, unsigned long Flags);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_BSC_Initialize_t)(HCI_DriverInformation_t *HCI_DriverInformation, unsigned long Flags);
#endif

   /* The following function is responsible for Closing the Bluetooth   */
   /* Protocol Stack that was opened for the Bluetooth Device specified */
   /* via a successful call to the BSC_Initialize() function.  The Input*/
   /* parameter to this function MUST have been acquired by a successful*/
   /* call to the BSC_Initialize() function.  Once this function        */
   /* completes, the Bluetooth Device that was opened (and the Bluetooth*/
   /* Protocol Stack that is associated with the Device) cannot be      */
   /* accessed again until the Device (and a corresponding Bluetooth    */
   /* Protocol STack is Re-Opened by calling the BSC_Initialize()       */
   /* function.                                                         */
__DLLMODEF__ void BTPSAPI BSC_Shutdown(unsigned int BluetoothStackID);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef void (BTPSAPI *PFN_BSC_Shutdown_t)(unsigned int BluetoothStackID);
#endif

   /* The following function is a Debugging function that allows the    */
   /* caller to register a Debugging Callback that will be called EACH  */
   /* Time a HCI Packet is Sent or Received.  Because this Function will*/
   /* be called every time a Packet is Sent or Received, this function  */
   /* should only be used when debugging is required because of the     */
   /* Performance Penalty that is present when using this mechanism.    */
   /* The first parameter is obtained by a successful call to the      */
   /* BSC_Initialize() function.  The second parameter is a pointer to  */
   /* a function that is to be called when an HCI Packet (of any type)  */
   /* is Sent OR Received on the specified Bluetooth Protocol Stack     */
   /* (specified by the first parameter).  The CallbackParameter        */
   /* Parameter is a User defined value that will passed to the         */
   /* Callback Parameter when it is called.  The return value of this   */
   /* function will be a non-zero, non-negative value on success        */
   /* or a negative return code if there was a failure.  Once a Debug   */
   /* Callback has been installed, it can ONLY be removed via a call to */
   /* the BSC_UnRegisterDebugCallback() function.                       */
__DLLMODEF__ int BTPSAPI BSC_RegisterDebugCallback(unsigned int BluetoothStackID, BSC_Debug_Callback_t BSC_DebugCallback, unsigned long CallbackParameter);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_BSC_RegisterDebugCallback_t)(unsigned int BluetoothStackID, BSC_Debug_Callback_t BSC_DebugCallback, unsigned long CallbackParameter);
#endif

   /* The following function is responsible for Removing a previously   */
   /* installed Debug Callback for the specified Bluetooth Protocol     */
   /* Stack (specified by the specified BluetoothStackID parameter).    */
   /* After this function has completed, the caller will no longer be   */
   /* Notified via the Debug Callback Function when a debug event       */
   /* occurs.                                                           */
__DLLMODEF__ void BTPSAPI BSC_UnRegisterDebugCallback(unsigned int BluetoothStackID);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef void (BTPSAPI *PFN_BSC_UnRegisterDebugCallback_t)(unsigned int BluetoothStackID);
#endif

   /* The following function is provided to allows the caller to        */
   /* register an Event Callback that will be called when an upper layer*/
   /* module requires a specific function that is provided by another   */
   /* layer.  The first parameter is obtained by a successful call to   */
   /* the BSC_Initialize() function.  The second parameter is a pointer */
   /* to a function that is to be called when an BSC Event is           */
   /* dispatched.  The CallbackParameter Parameter is a User defined    */
   /* value that will passed to the Callback Parameter when it is       */
   /* called.  The return value of this function will be a non-zero,    */
   /* non-negative value on success or a negative return code if there  */
   /* was a failure.  Once an Event Callback has been installed, it can */
   /* ONLY be removed via a call to the BSC_UnRegisterEventCallback()   */
   /* function.                                                         */
__DLLMODEF__ int BTPSAPI BSC_RegisterEventCallback(unsigned int BluetoothStackID, BSC_Event_Callback_t BSC_EventCallback, unsigned long CallbackParameter);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_BSC_RegisterEventCallback_t)(unsigned int BluetoothStackID, BSC_Event_Callback_t BSC_EventCallback, unsigned long CallbackParameter);
#endif

   /* The following function is responsible for Removing a previously   */
   /* installed EVent Callback for the specified Bluetooth Protocol     */
   /* Stack (specified by the specified BluetoothStackID parameter).    */
   /* After this function has completed, the caller will no longer be   */
   /* Notified via the Event Callback Function when a BSC event occurs. */
__DLLMODEF__ void BTPSAPI BSC_UnRegisterEventCallback(unsigned int BluetoothStackID);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef void (BTPSAPI *PFN_BSC_UnRegisterEventCallback_t)(unsigned int BluetoothStackID);
#endif

   /* The following function is a low-level primitive that allows the   */
   /* caller the ability to 'Lock' the Bluetooth Protocol Stack so that */
   /* no other thread has access to the specified Bluetooth Protocol    */
   /* Stack.  This functionality is provided to allow the programmer the*/
   /* means to guard against the Bluetooth Protocol Stack calling a     */
   /* Bluetooth Event Callback and potentially leading to a Thread      */
   /* Problem if Mutexes/Semaphores are being used.  This function is   */
   /* completely safe to be called in any context (except Debug         */
   /* Callbacks).  This function accepts as its only parameter the      */
   /* Bluetooth Stack ID of the Bluetooth Protocol Stack to 'Lock'.     */
   /* This function returns zero if the specified Bluetooth Protocol    */
   /* Stack was successfully 'Locked' or a negative return error code if*/
   /* an error occurred.  Once the Bluetooth Stack is successfully      */
   /* Locked it *MUST* be unlocked manually by calling the              */
   /* BSC_UnLockBluetoothStack() function.  Failure to call the UnLock  */
   /* function after successfully locking the Bluetooth Protocol Stack  */
   /* will result in the Bluetooth Stack to quit responding.            */
   /* * NOTE * This function is NOT required to be called before        */
   /*          calling Bluetooth Protocol Stack functions !!!!!!!!!!!!! */
   /* * NOTE * This function is provided for applications that need     */
   /*          require the Bluetooth Protocol Stack to force all        */
   /*          Resource protection.  In many cases (almost all) this    */
   /*          function (and it's counterpart, the                      */
   /*          the BSC_UnLockBluetoothStack() function) will not need   */
   /*          to be used.  This function SHOULD BE USED WITH EXTREME   */
   /*          CAUTION !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!   */
   /* * NOTE * Multiple calls to this function are possible, however    */
   /*          there *MUST* be a corresponding call to the              */
   /*          BSC_UnLockBluetoothStack() function for each successful  */
   /*          call that is made to this function.  Failure to call the */
   /*          BSC_UnLockBluetoothStack() function the same amount of   */
   /*          times will yield the Bluetooth Stack un-usable.          */
   /* * NOTE * The programmer using this function can guard against the */
   /*          case of being interrupted by the Bluetooth Protocol Stack*/
   /*          while issuing more than one Bluetooth Protocol Stack     */
   /*          operation.  This allows the caller some guarantee that   */
   /*          the stack will not cause a non-reentrant operation on    */
   /*          data structures that might need to be protected.  This   */
   /*          function allows the caller to use the same protection    */
   /*          that the Bluetooth Protocol Stack uses to avoid potential*/
   /*          dead-lock conditions.                                    */
__DLLMODEF__ int BTPSAPI BSC_LockBluetoothStack(unsigned int BluetoothStackID);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_BSC_LockBluetoothStack_t)(unsigned int BluetoothStackID);
#endif

   /* The following function is provided to allow the programmer a      */
   /* mechanism for releasing an existing 'Lock' that was acquired on   */
   /* the specified Bluetooth Protocol Stack.  This function accepts as */
   /* its parameter the Bluetooth Protocol Stack ID of the Bluetooth    */
   /* Protocol Stack that is currently 'Locked'.  The Bluetooth         */
   /* Protocol Stack is considered 'Locked' if the the caller called the*/
   /* BSC_LockBluetoothStack() function (and it was successful).  Please*/
   /* see the BSC_LockBluetoothStack() function for more information.   */
__DLLMODEF__ void BTPSAPI BSC_UnLockBluetoothStack(unsigned int BluetoothStackID);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef void (BTPSAPI *PFN_BSC_UnLockBluetoothStack_t)(unsigned int BluetoothStackID);
#endif

   /* The following function is provided to allow the programmer a      */
   /* mechanism to determine the Thread Handle of the Dispatch Event    */
   /* Thread Callback.  This function accepts as its input parameter    */
   /* the Bluetooth Stack ID of the Bluetooth Protocol Stack that the   */
   /* Dispatch Thread Handle is to be retrieved.  This function returns */
   /* a non-NULL Thread Handle if successful, or NULL if there was an   */
   /* error retrieving the Dispatch Thread Handle.                      */
__DLLMODEF__ HANDLE BTPSAPI BSC_QueryDispatchThreadHandle(unsigned int BluetoothStackID);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef HANDLE (BTPSAPI *PFN_BSC_QueryDispatchThreadHandle_t)(unsigned int BluetoothStackID);
#endif

   /* The following function is provided to allow a mechanism to start  */
   /* a Timer of the specified Time out (in Milliseconds and NOT zero), */
   /* and call the specified Timer Callback function when the timer     */
   /* expires.  This function accepts as input the Bluetooth Stack ID   */
   /* of the Bluetooth Stack that the specified Timer is valid for, the */
   /* Timeout value (in Milliseconds) of the Timer, the Timer Callback, */
   /* and Callback Parameter to call when the Timer expires.  The       */
   /* Callback Parameter that is specified is passed to the caller when */
   /* the Timer Callback function is called.  This function returns the */
   /* Timer ID of the newly created Timer if successful (positive AND   */
   /* NON-zero).  This Timer ID can be used when calling BSC_StopTimer()*/
   /* function if the specified Timer has not expired.  The Timer ID's  */
   /* are always greater than zero.  If the Timer was not able to be    */
   /* started, a negative return error code is returned.                */
   /* * NOTE *  All Timers supported by this module are one-shot timers */
   /*           only.  This means that after the Timer expires and the  */
   /*           the caller is notified, no other Timeout will occur.    */
__DLLMODEF__ int BTPSAPI BSC_StartTimer(unsigned int BluetoothStackID, unsigned int Timeout, BSC_Timer_Callback_t BSC_TimerCallback, unsigned long CallbackParameter);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_BSC_StartTimer_t)(unsigned int BluetoothStackID, unsigned int Timeout, BSC_Timer_Callback_t BSC_TimerCallback, unsigned long CallbackParameter);
#endif

   /* The following function is provided to allow a mechanism for       */
   /* stopping a Timer that was previously started with the             */
   /* BSC_StartTimer() function.  This function accepts as input the    */
   /* Bluetooth Stack ID of the Bluetooth Stack that the Timer was      */
   /* started on, and the Timer ID of the specified Timer (returned from*/
   /* a successful call to the BSC_StartTimer() function).  This        */
   /* function returns zero if successful, or a negative return error   */
   /* code if there was error stopping the specified Timer.             */
__DLLMODEF__ int BTPSAPI BSC_StopTimer(unsigned int BluetoothStackID, unsigned int TimerID);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_BSC_StopTimer_t)(unsigned int BluetoothStackID, unsigned int TimerID);
#endif

   /* The following function is provided to allow a mechanism for any   */
   /* layer to request that a connected device be authenticated.  This  */
   /* function accepts as input the Bluetooth Stack ID of the Bluetooth */
   /* Stack that the Device is associated with.  The second parameter is*/
   /* the Bluetooth Address of the connected device that requires       */
   /* Authentication.  The third parameter is a pointer to a Result     */
   /* variable that indicates the state of the request.  This function  */
   /* returns zero if successful, or a negative return error code if the*/
   /* Authentication process was not started.                           */
__DLLMODEF__ int BTPSAPI BSC_AuthenticateDevice(unsigned int BluetoothStackID, BD_ADDR_t BD_ADDR, Byte_t *Result);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_BSC_AuthenticateDevice_t)(unsigned int BluetoothStackID, BD_ADDR_t BD_ADDR, Byte_t *Result);
#endif

   /* The following function is provided to allow a mechanism for adding*/
   /* Bluetooth Profile Information to the Bluetooth Stack Controller.  */
   /* This group of function exists to allow applications a mechanism to*/
   /* determine the Bluetooth Profiles which are currently in use.  This*/
   /* function accepts as input the Bluetooth Stack ID of the Bluetooth */
   /* Stack that the Bluetooth Profile is registered, and the Bluetooth */
   /* Profile Information Entry to register.  This function returns a   */
   /* non-zero, positive, number on success or a negative return value  */
   /* if there was an error.  A successfully return value will be a     */
   /* Bluetooth Profile ID that can be used to reference the registered */
   /* Bluetooth Profile Information Entry.                              */
__DLLMODEF__ int BTPSAPI BSC_RegisterBluetoothProfileInformation(unsigned int BluetoothStackID, BSC_BluetoothProfileInfoEntry_t *BluetoothProfileInfoEntry);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_BSC_RegisterBluetoothProfileInformation_t)(unsigned int BluetoothStackID, BSC_BluetoothProfileInfoEntry_t *BluetoothProfileInfoEntry);
#endif

   /* The following function is provided to allow a mechanism for       */
   /* removing Bluetooth Profile Information Entries from the Bluetooth */
   /* Stack Controller.  This group of functions exists to allow        */
   /* applications a mechanism to determine the Bluetooth Profiles which*/
   /* are currently in use.  This function accepts as input the         */
   /* Bluetooth Stack ID of the Bluetooth Stack that the Bluetooth      */
   /* Profile Information to be removed is registered, and the Bluetooth*/
   /* Profile ID of the Bluetooth Profile Information to be removed.    */
   /* This function returns zero on success and a negative return value */
   /* if there was an error.                                            */
__DLLMODEF__ int BTPSAPI BSC_UnRegisterBluetoothProfileInformation(unsigned int BluetoothStackID, unsigned int BluetoothProfileID);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_BSC_UnregisterBluetoothProfileInformation_t)(unsigned int BluetoothStackID, unsigned int BluetoothProfileID);
#endif

   /* The following function is provided to allow a mechanism for       */
   /* getting a Bluetooth Profile Information Entry that has been       */
   /* registered with the Bluetooth Stack Control.  This group of       */
   /* functions exists to allow applications a mechanism to determine   */
   /* the Bluetooth Profiles which are currently in use.  This function */
   /* accepts as input the Bluetooth Stack ID of the Bluetooth Stack    */
   /* that the Bluetooth Profile Information to be retrieved is         */
   /* registered, the Bluetooth Profile ID of the Bluetooth Profile     */
   /* Information to be retrieved, and a pointer to a buffer that the   */
   /* Bluetooth Profile Information Entry being retrieved may be        */
   /* returned.  This function returns zero on success and a negative   */
   /* return value if there was an error.                               */
   /* ** NOTE ** The Size member of the BluetoothProfileInfoEntry passed*/
   /*            in must be initialized to the current size of a        */
   /*            Bluetooth Profile Information Entry.                   */
__DLLMODEF__ int BTPSAPI BSC_QueryBluetoothProfileInformation(unsigned int BluetoothStackID, unsigned int BluetoothProfileID, BSC_BluetoothProfileInfoEntry_t *BluetoothProfileInfoEntry);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_BSC_QueryBluetoothProfileInformation_t)(unsigned int BluetoothStackID, unsigned int BluetoothProfileID, BSC_BluetoothProfileInfoEntry_t *BluetoothProfileInfoEntry);
#endif

   /* The following function is provided to allow a mechanism for       */
   /* updating Bluetooth Profile Information Entries that have been     */
   /* registered with the Bluetooth Stack Controller.  This group of    */
   /* functions exists to allow applications a mechanism to determine   */
   /* the Bluetooth Profiles which are currently in use.  This function */
   /* accepts as input the Bluetooth Stack ID of the Bluetooth Stack    */
   /* that the Bluetooth Profile Information to be updated is           */
   /* registered, the Bluetooth Profile ID of the Bluetooth Profile     */
   /* Information to be updated, and the Bluetooth Profile Information  */
   /* Entry contains the updated information.  This function returns    */
   /* zero on success and a negative return value if there was an error.*/
__DLLMODEF__ int BTPSAPI BSC_UpdateBluetoothProfileInformation(unsigned int BluetoothStackID, unsigned int BluetoothProfileID, BSC_BluetoothProfileInfoEntry_t *BluetoothProfileInfoEntry);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_BSC_UpdateBluetoothProfileInformation_t)(unsigned int BluetoothStackID, unsigned int BluetoothProfileID, BSC_BluetoothProfileInfoEntry_t *BluetoothProfileInfoEntry);
#endif

   /* The following function is provided to allow a mechanism to        */
   /* retrieve all currently registered Bluetooth Profile ID Entries.   */
   /* This group of functions exists to allow applications a mechanism  */
   /* to determine the Bluetooth Profiles which are currently in use.   */
   /* The first parameter to this function is the Bluetooth Stack ID of */
   /* the Bluetooth Stack in which the Bluetooth Profile ID List is to  */
   /* be queried.  The second parameter to this function is a pointer to*/
   /* the Number of Bluetooth Profile ID Entries which exist as the next*/
   /* parameter.  The third parameter to this function is a pointer to a*/
   /* buffer in which the Bluetooth Profile ID List may be returned.    */
   /* This function returns zero on success and a negative return value */
   /* if there was an error.                                            */
   /* ** NOTE ** Passed a valid pointer to Number Bluetooth Profile ID  */
   /*            Entries and NULL pointer to Bluetooth Profile ID Entry */
   /*            parameters on success will result in the Number        */
   /*            Bluetooth Profile ID Entries containing the Number of  */
   /*            Bluetooth Profile ID Entries which currently exist in  */
   /*            the list.                                              */
   /* ** NOTE ** Upon successfully execution Number Bluetooth Profile ID*/
   /*            Entires shall contain the actual number of Bluetooth   */
   /*            Profile ID Entries that were added to the Bluetooth    */
   /*            Profile ID Entry Buffer that was specified.            */
__DLLMODEF__ int BTPSAPI BSC_QueryBluetoothProfileIDList(unsigned int BluetoothStackID, unsigned int *NumberBluetoothProfileIDEntries, unsigned int *BluetoothProfileIDList);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_BSC_QueryBluetoothProfileIDList_t)(unsigned int BluetoothStackID, unsigned int *NumberBluetoothProfileIDEntries, unsigned int *BluetoothProfileIDList);
#endif

   /* The following function issues a Raw HCI Command to the Bluetooth  */
   /* Device that is associated with the Bluetooth Protocol Stack       */
   /* specified by the BluetoothStackID parameter.  This function       */
   /* returns zero if successful, or a non-zero value if there was an   */
   /* error.  If this function returns zero (success) then the          */
   /* StatusResult variable will contain the Status Result returned from*/
   /* the Bluetooth Device AND the LengthResult variable will contain   */
   /* the Number of Bytes that are valid in the BufferResult variable.  */
   /* The WaitForResponse flag, specifies whether or not this function  */
   /* is to wait for a response from the Bluetooth Device.  This        */
   /* parameter is provided because the Bluetooth Device may not issue  */
   /* any response for this HCI Command.  If you (the caller know that  */
   /* the Bluetooth Device does NOT return data, then set this          */
   /* parameter to FALSE.  If you want to be absolutely sure, you can   */
   /* wait for the Timeout, however the calling therad will block until */
   /* an invalid response OR the Timeout occurs (valid data).           */
   /* The Command_OGF parameter specifies the Bluetooth Command OGF     */
   /* of the Command, wheras the Command_OCF specifies the Bluetooth    */
   /* Command OCF.  The Command_Length parameter specifies the number   */
   /* of bytes to send from the Buffer specified by the Command_Data    */
   /* parameter.  The Command_Data parameter is ignored if              */
   /* Command_Length is zero, and the LengthResult and BufferResult     */
   /* parameters are ignored if the WaitForResponse Flag is FALSE.      */
   /* * NOTE * This function blocks until either a result is returned   */
   /*          from the Bluetooth Device OR the function Times Out      */
   /*          Waiting for a response from the Bluetooth Device.        */
__DLLMODEF__ int BTPSAPI BSC_Send_Raw_Command(unsigned int BluetoothStackID, Byte_t Command_OGF, Word_t Command_OCF, Byte_t Command_Length, Byte_t Command_Data[], Byte_t *StatusResult, Byte_t *LengthResult, Byte_t *BufferResult, BOOLEAN WaitForResponse);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_BSC_Send_Raw_Command_t)(unsigned int BluetoothStackID, Byte_t Command_OGF, Word_t Command_OCF, Byte_t Command_Length, Byte_t Command_Data[], Byte_t *StatusResult, Byte_t *LengthResult, Byte_t *BufferResult, BOOLEAN WaitForResponse);
#endif

   /* The following function issues the HCI_Reset Command to the        */
   /* Bluetooth Device that is associated with the Bluetooth Protocol   */
   /* Stack specified by the BluetoothStackID parameter. In addition,   */
   /* this function will call a device-specific intialization function  */
   /* contained within a platform device module.          This function */
   /* returns zero if successful, or a non-zero value if there was an   */
   /* error.  If this function returns zero (success) then the          */
   /* StatusResult variable will contain the Status Result returned from*/
   /* the Bluetooth Device.                                             */
   /* * NOTE * This function blocks until either a result is returned   */
   /*          from the Bluetooth Device OR the function Times Out      */
   /*          Waiting for a response from the Bluetooth Device.        */
__DLLMODEF__ int BTPSAPI BSC_Reset_Local_Device(unsigned int BluetoothStackID, Byte_t *StatusResult);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_BSC_Reset_Local_Device_t)(unsigned int BluetoothStackID, Byte_t *StatusResult);
#endif

   /* The following function is provided to allow a means to read the   */
   /* difference between the measured Received Signal Strength          */
   /* Indication (RSSI) and the limits of the Golden Receive Power Range*/
   /* for a connected Bluetooth Device.  The first parameter to this    */
   /* function is the Bluetooth Stack ID of the Bluetooth Protocol Stack*/
   /* associated with the Bluetooth Device in which to query the RSSI.  */
   /* The second parameter to this function is the BD_ADDR of a         */
   /* connected (ACL connection must be establshed) remote Bluetooth    */
   /* Device in which Received Signal Strength is to be read.  The final*/
   /* parameter to this function is a pointer to a buffer in which the  */
   /* read RSSI may be returned.  For details on what the RSSI value    */
   /* means see the HCI_Read_RSSI Command in the Bluetooth Specification*/
   /* Version 1.2 or higher.  This function returns zero if successful  */
   /* or a negative return value if an error occurred.                  */
__DLLMODEF__ int BTPSAPI BSC_Read_RSSI(unsigned int BluetoothStackID, BD_ADDR_t BD_ADDR, Byte_t *RSSI);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_BSC_Read_RSSI_t)(unsigned int BluetoothStackID, BD_ADDR_t BD_ADDR, Byte_t *RSSI);
#endif

   /* The following function is provided to allow a means to query the  */
   /* current Link Connection Request/Response Configuration.  The Link */
   /* Request/Response Configuration parameters mandate how the stack is*/
   /* to issue Lower Link Requests and respond to Lower Link Requests   */
   /* during connection setup.  These parameters primarily mandate how  */
   /* Master/Slave Role Switching is to be supported in the stack (if   */
   /* the stack is managing ALL Lower Level Connection                  */
   /* Request/Acceptance (which is the default)).  The first parameter  */
   /* to this function is the Bluetooth Stack ID of the Bluetooth Device*/
   /* that the Link Connection Configuration parameters are to be       */
   /* retrieved.  The second parameter to this function is a pointer to */
   /* a buffer that is to receive the current Link Connection           */
   /* Configuration parameters.  This function returns zero if          */
   /* successful or a negative return value if an error occurred.       */
   /* * NOTE * This function, and it's counterpart, the                 */
   /*          BSC_Set_Connection_Configuration() function, are really  */
   /*          only of use when Point to Multi-Point usage is required  */
   /*          (either Local or Remote).  The default values are:       */
   /*                                                                   */
   /*             cqNoRoleSwitch                                        */
   /*             csMaintainCurrentRole                                 */
   /*                                                                   */
   /*          which means that if a connection is requested by the     */
   /*          stack the Local Device will NOT allow a Role switch and  */
   /*          will remain the Master of the Connection.  If a          */
   /*          connection is responded to by the stack then NO Role     */
   /*          Switch will be attempted (the Local Device will remain   */
   /*          the Slave).                                              */
__DLLMODEF__ int BTPSAPI BSC_Get_Connection_Configuration(unsigned int BluetoothStackID, BSC_Connection_Configuration_Parameters_t *BSC_Connection_Configuration_Parameters);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_BSC_Get_Connection_Configuration_t)(unsigned int BluetoothStackID, BSC_Connection_Configuration_Parameters_t *BSC_Connection_Configuration_Parameters);
#endif

   /* The following function is provided to allow a means to change the */
   /* current Link Connection Request/Response Configuration.  The Link */
   /* Request/Response Configuration parameters mandate how the stack is*/
   /* to issue Lower Link Requests and respond to Lower Link Requests   */
   /* during connection setup.  These parameters primarily mandate how  */
   /* Master/Slave Role Switching is to be supported in the stack (if   */
   /* the stack is managing ALL Lower Level Connection                  */
   /* Request/Acceptance (which is the default).  The first parameter to*/
   /* this function is the Bluetooth Stack ID of the Bluetooth Device   */
   /* that the Link Connection Configuration parameters are to be       */
   /* changed.  The second parameter to this function is a pointer to a */
   /* buffer that contains the new Link Connection Configuration        */
   /* parameters.  This function returns zero if successful or a        */
   /* negative return value if an error occurred.                       */
   /* * NOTE * After this function has completed, the parameters will   */
   /*          ONLY be in effect when the next Lower Level Link Action  */
   /*          occurs (i.e. for future Link Connections).  Any current  */
   /*          Links that are established are un-affected by the action */
   /*          of this function.                                        */
   /* * NOTE * This function, and it's counterpart, the                 */
   /*          BSC_Get_Connection_Configuration() function, are really  */
   /*          only of use when Point to Multi-Point usage is required  */
   /*          (either Local or Remote).  The default values are:       */
   /*                                                                   */
   /*             cqNoRoleSwitch                                        */
   /*             csMaintainCurrentRole                                 */
   /*                                                                   */
   /*          which means that if a connection is requested by the     */
   /*          stack the Local Device will NOT allow a Role switch and  */
   /*          will remain the Master of the Connection.  If a          */
   /*          connection is responded to by the stack then NO Role     */
   /*          Switch will be attempted (the Local Device will remain   */
   /*          the Slave).                                              */
__DLLMODEF__ int BTPSAPI BSC_Set_Connection_Configuration(unsigned int BluetoothStackID, BSC_Connection_Configuration_Parameters_t *BSC_Connection_Configuration_Parameters);

#ifdef INCLUDE_BLUETOOTH_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_BSC_Set_Connection_Configuration_t)(unsigned int BluetoothStackID, BSC_Connection_Configuration_Parameters_t *BSC_Connection_Configuration_Parameters);
#endif

#endif
