/*****< l2captyp.h >***********************************************************/
/*      Copyright 2000, 2001, 2002, 2003, 2004 Stonestreet One, Inc.          */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  L2CAPTYP - Bluetooth L2CAP Type Definitions/Constants.                    */
/*                                                                            */
/*  Author:  Tim Thomas                                                       */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   09/11/00  T. Thomas      Initial creation.                               */
/******************************************************************************/
#ifndef __L2CAPTYPH__
#define __L2CAPTYPH__

   /* Force ALL Structure Declarations to be Byte Packed (noting the    */
   /* current Structure Packing).                                       */
#pragma pack(push, __L2CAPTYPH_PUSH__)
#pragma pack(1)

#include "BTTypes.h"            /* Bluetooth Type Definitions.                */

   /* The following define the values used when enabling Host           */
   /* Controller to Host flow control.                                  */
#define HC_TO_H_FLOW_ACL_PACKETS                                        1
#define HC_TO_H_FLOW_SCO_PACKETS                                        2
#define HC_TO_H_FLOW_ACL_SCO_PACKETS                                    3

   /* The following Constants represent the defined Bluetooth L2CAP     */
   /* Channel Identifier Values.                                        */
#define L2CAP_CHANNEL_IDENTIFIER_NULL_IDENTIFIER                        0x0000
#define L2CAP_CHANNEL_IDENTIFIER_SIGNALLING_CHANNEL                     0x0001
#define L2CAP_CHANNEL_IDENTIFIER_CONNECTIONLESS_CHANNEL                 0x0002

#define L2CAP_CHANNEL_IDENTIFIER_MINIMUM_CHANNEL_IDENTIFIER             0x0040
#define L2CAP_CHANNEL_IDENTIFIER_MAXIMUM_CHANNEL_IDENTIFIER             0xFFFF

   /* The following Constants represent the defined Bluetooth L2CAP PSM */
   /* Minimum and Maximum Values.                                       */
#define L2CAP_PSM_MINIMUM_PSM                                           0x0001
#define L2CAP_PSM_MAXIMUM_PSM                                           0xFEFF

   /* The following Constant represents an Invalid PSM value that can   */
   /* be used by the programmer to initialize an invalid PSM value.     */
#define L2CAP_PSM_INVALID_PSM                                           0x0000

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability of testing whether or not a specified PSM value is    */
   /* valid.  The first parameter to this MACRO is the PSM Value to     */
   /* verify.  This MACRO returns a boolean value based upon whether    */
   /* or not the specified PSM value is valid.  This MACRO returns a    */
   /* boolean TRUE if the specified PSM is valid, or a boolean FALSE    */
   /* if the specified PSM value is invalid.                            */
#define L2CAP_PSM_VALID_PSM(_x)                         (((_x) & 0x0001) && (!((_x) & 0x0100)) && ((_x) >= L2CAP_PSM_MINIMUM_PSM) && ((_x) <= L2CAP_PSM_MAXIMUM_PSM))

   /* The following Constants represent the defined Bluetooth L2CAP     */
   /* Link Timeout Minimum and Maximum Values (in Milliseconds).        */
#define L2CAP_LINK_TIMEOUT_MINIMUM_VALUE                                0x0000
#define L2CAP_LINK_TIMEOUT_MAXIMUM_VALUE                                0x9FC4
#define L2CAP_LINK_TIMEOUT_DEFAULT_VALUE                                0x4E20

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability of testing whether or not a specified LinkTO value is */
   /* valid.  The first parameter to this MACRO is the LinkTO Value to  */
   /* verify.  This MACRO returns a boolean value based upon whether or */
   /* not the specified LinkTO value is valid.  This MACRO returns a    */
   /* boolean TRUE if the specified LinkTO is valid, or a boolean       */
   /* FALSE if the specified LinkTo value is invalid.                   */
#define L2CAP_LINK_TIMEOUT_VALID_LINK_TIMEOUT(_x)       (((_x) >= L2CAP_LINK_TIMEOUT_MINIMUM_VALUE) && ((_x) <= L2CAP_LINK_TIMEOUT_MAXIMUM_VALUE))

   /* The following Constants represent the define Bluetooth L2CAP      */
   /* Minimum and Maximum Values for Signal Identifiers.                */
#define L2CAP_SIGNAL_IDENTIFIER_MINIMUM_SIGNAL_IDENTIFIER               0x0001
#define L2CAP_SIGNAL_IDENTIFIER_MAXIMUM_SIGNAL_IDENTIFIER               0x00FF

   /* The following Constants represent the internally defined L2CAP    */
   /* Minimum and Maximum Values for Data Packet Identifiers.           */
#define L2CAP_DATA_IDENTIFIER_MINIMUM_DATA_IDENTIFIER                   0x0100
#define L2CAP_DATA_IDENTIFIER_MAXIMUM_DATA_IDENTIFIER                   0xFFFF

   /* The following MACROs are utility MACROs that exists to aid code   */
   /* readability of testing whether or not a specified Identifier value*/
   /* is valid.  The first parameter to this MACRO is the Identifier    */
   /* Value to verify.  This MACRO returns a boolean value based upon   */
   /* whether or not the specified Identifier value is valid.  These    */
   /* MACRO's return a boolean TRUE if the specified Identifier is      */
   /* valid, or a boolean FALSE if the specified Identifier value is    */
   /* invalid.                                                          */
#define L2CAP_IDENTIFIER_VALID_SIGNAL_IDENTIFIER(_x)    (((_x) >= L2CAP_SIGNAL_IDENTIFIER_MINIMUM_SIGNAL_IDENTIFIER) && ((_x) <= L2CAP_SIGNAL_IDENTIFIER_MAXIMUM_SIGNAL_IDENTIFIER))
#define L2CAP_IDENTIFIER_VALID_DATA_IDENTIFIER(_x)      ((_x) >= L2CAP_DATA_IDENTIFIER_MINIMUM_DATA_IDENTIFIER)

   /* The following Constants represent the defined Bluetooth L2CAP MTU */
   /* Minimum and Maximum Values.                                       */
#define L2CAP_MINIMUM_CONNECTION_MTU_SIZE                               48
//#define L2CAP_MAXIMUM_CONNECTION_MTU_SIZE                               2048
   /* This was changed to a smaller number as a workaround for the      */
   /* Serial driver problems.  Cranking it back up for possible         */
   /* throughput gains.                                                 */
#define L2CAP_MAXIMUM_CONNECTION_MTU_SIZE                               32768

   /* The following Constants represent the defined Bluetooth L2CAP     */
   /* Flush Timeout Minimum and Maximum Values.                         */
#define L2CAP_FLUSH_TIMEOUT_MINIMUM_VALUE                               0x0000
#define L2CAP_FLUSH_TIMEOUT_MAXIMUM_VALUE                               0x04FF

   /* The following Constant represents the defined Bluetooth L2CAP     */
   /* Flush Timeout Inifinite Value.                                    */
#define L2CAP_FLUSH_TIMEOUT_INFINITE_VALUE                              0xFFFF

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability of testing whether or not a specified Flush Timeout   */
   /* value is valid.  The first parameter to this MACRO is the Flush   */
   /* Timeout Value to verify.  This MACRO returns a boolean value based*/
   /* upon whether or not the specified Flush Timeout value is valid.   */
   /* This MACRO returns a boolean TRUE if the specified Flush Timeout  */
   /* is valid, or a boolean FALSE if the specified Flush Timeout value */
   /* is invalid.                                                       */
#define L2CAP_FLUSH_TIMEOUT_VALID_FLUSH_TIMEOUT(_x)    (((_x) == L2CAP_FLUSH_TIMEOUT_INFINITE_VALUE)  || (((_x) >= L2CAP_FLUSH_TIMEOUT_MINIMUM_VALUE) && ((_x) <= L2CAP_FLUSH_TIMEOUT_MAXIMUM_VALUE)))

   /* The following Constants represent the defined Bluetooth L2CAP     */
   /* Command Reject Reason Values.                                     */
#define L2CAP_COMMAND_REJECT_REASON_NOT_UNDERSTOOD                      0x0000
#define L2CAP_COMMAND_REJECT_REASON_SIGNALING_MTU_EXCEEDED              0x0001
#define L2CAP_COMMAND_REJECT_REASON_INVALID_CID                         0x0002

   /* The following Constants represent the defined Bluetooth L2CAP     */
   /* Connection Result Values.                                         */
#define L2CAP_CONNECT_RESULT_CONNECTION_SUCCESSFUL                      0x0000
#define L2CAP_CONNECT_RESULT_CONNECTION_PENDING                         0x0001
#define L2CAP_CONNECT_RESULT_CONNECTION_REFUSED_PSM_NOT_REGISTERED      0x0002
#define L2CAP_CONNECT_RESULT_CONNECTION_REFUSED_SECURITY_RELATED        0x0003
#define L2CAP_CONNECT_RESULT_CONNECTION_TIMEOUT                         0xEEEE

   /* The following Constants represent the defined Bluetooth L2CAP     */
   /* Connection Status Values.                                         */
#define L2CAP_CONNECT_STATUS_NO_FURTHER_INFORMATION                     0x0000
#define L2CAP_CONNECT_STATUS_AUTHENTICATION_PENDING                     0x0001
#define L2CAP_CONNECT_STATUS_AUTHORIZATION_PENDING                      0x0002

   /* The following Constants represent the defined Bluetooth L2CAP     */
   /* Connection Response Response Values.                              */
#define L2CAP_CONNECT_RESPONSE_RESPONSE_SUCCESSFUL                      0x0000
#define L2CAP_CONNECT_RESPONSE_RESPONSE_PENDING                         0x0001
#define L2CAP_CONNECT_RESPONSE_RESPONSE_REFUSED_PSM_NOT_REGISTERED      0x0002
#define L2CAP_CONNECT_RESPONSE_RESPONSE_REFUSED_SECURITY_BLOCK          0x0003
#define L2CAP_CONNECT_RESPONSE_RESPONSE_REFUSED_NO_RESOURCES            0x0004

   /* The following Constants represent the defined Bluetooth L2CAP     */
   /* Connection Response Status Values.                                */
#define L2CAP_CONNECT_RESPONSE_STATUS_NO_FURTHER_INFORMATION            0x0000
#define L2CAP_CONNECT_RESPONSE_STATUS_AUTHENTICATION_PENDING            0x0001
#define L2CAP_CONNECT_RESPONSE_STATUS_AUTHORIZATION_PENDING             0x0002

   /* The following Constants represent the defined Bluetooth L2CAP     */
   /* Configuarion Flags Values.                                        */
#define L2CAP_CONFIG_FLAGS_CONTINUATION_FLAG                           0x0001

   /* The following Constants represent the defined Bluetooth L2CAP     */
   /* Config Option Type Designator Values.                             */
#define L2CAP_CONFIG_OPTION_TYPE_MTU                                    0x01
#define L2CAP_CONFIG_OPTION_TYPE_FLUSH_TIMEOUT                          0x02
#define L2CAP_CONFIG_OPTION_TYPE_QOS                                    0x03

   /* The following Constants represent the defined Bluetooth L2CAP     */
   /* Config Response Result Values.                                    */
#define L2CAP_CONFIGURE_RESPONSE_RESULT_SUCCESS                         0x0000
#define L2CAP_CONFIGURE_RESPONSE_RESULT_FAILURE_UNACCEPTABLE_PARAMETERS 0x0001
#define L2CAP_CONFIGURE_RESPONSE_RESULT_FAILURE_REJECTED_NO_REASON      0x0002
#define L2CAP_CONFIGURE_RESPONSE_RESULT_FAILURE_UNKNOWN_OPTIONS         0x0003
#define L2CAP_CONFIGURE_RESPONSE_RESULT_TIMEOUT                         0xEEEE

   /* The following Constants represent the defined Bluetooth L2CAP     */
   /* Disconnect Response Result Values.                                */
#define L2CAP_DISCONNECT_RESPONSE_RESULT_SUCCESS                        0x0000
#define L2CAP_DISCONNECT_RESPONSE_RESULT_TIMEOUT                        0xEEEE

   /* The following Constants represent the defined Bluetooth L2CAP     */
   /* Data Read Result Values.                                          */
#define L2CAP_DATA_READ_RESULT_SUCCESS                                  0x0000
#define L2CAP_DATA_READ_RESULT_ERROR                                    0x0001

   /* The following Constants represent the defined Bluetooth L2CAP     */
   /* Data Read Result Values.                                          */
#define L2CAP_DATA_READ_STATUS_MTU_EXCEEDED                             0x0000
#define L2CAP_DATA_READ_STATUS_RECEIVE_TIMEOUT                          0x0001
#define L2CAP_DATA_READ_STATUS_SIZE_ERROR                               0x0002

   /* The following Constants represent the defined Bluetooth L2CAP     */
   /* Echo Response (Ping) Result Values.                               */
#define L2CAP_ECHO_RESPONSE_RESULT_RESPONSE_RECEIVED                    0x0000
#define L2CAP_ECHO_RESPONSE_RESULT_RESPONSE_TIMEOUT                     0x0001

   /* The following Constants represent the defined Bluetooth L2CAP     */
   /* Information Request InfoType Values.                              */
#define L2CAP_INFORMATION_REQUEST_INFOTYPE_CONNECTIONLESS_MTU           0x0001
#define L2CAP_INFORMATION_REQUEST_INFOTYPE_EXTENDED_FEATURE_MASK        0x0002

#define L2CAP_DEFAULT_CONNECTIONLESS_MTU_SIZE                           670
#define L2CAP_DEFAULT_CONNECTION_MTU_SIZE                               672
#define L2CAP_DEFAULT_CONNECTION_FLUSH_TIMEOUT                          0xFFFF
#define L2CAP_DEFAULT_QOS_FLAGS                                         0
#define L2CAP_DEFAULT_QOS_SERVICE_TYPE                                  1
#define L2CAP_DEFAULT_QOS_TOKEN_RATE                                    0
#define L2CAP_DEFAULT_QOS_TOKEN_BUCKET_SIZE                             0
#define L2CAP_DEFAULT_QOS_PEAK_BANDWIDTH                                0
#define L2CAP_DEFAULT_QOS_LATENCY                                       0xFFFFFFFFL
#define L2CAP_DEFAULT_QOS_DELAY_VARIATION                               0xFFFFFFFFL

   /* The following Constants represent the defined Bluetooth L2CAP     */
   /* Information Response Result Values.                               */
#define L2CAP_INFORMATION_RESPONSE_RESULT_SUCCESS                       0x0000
#define L2CAP_INFORMATION_RESPONSE_RESULT_NOT_SUPPORTED                 0x0001
#define L2CAP_INFORMATION_RESPONSE_RESULT_PDU_REJECTED                  0x0002
#define L2CAP_INFORMATION_RESPONSE_RESULT_TIMEOUT                       0x0003

   /* The following are the bit number defines that should be used when */
   /* accessing bit data in the L2CAP_Extended_Feature_Mask_t structure.*/
#define L2CAP_EXTENDED_FEATURE_FLOW_CONTROL_BIT_NUMBER                  0
#define L2CAP_EXTENDED_FEATURE_RETRANSMIT_MODE_BIT_NUMBER               1
#define L2CAP_EXTENDED_FEATURE_BI_DIRECTIONAL_QOS_BIT_NUMBER            2

   /* The following Constants represent the defined Bluetooth L2CAP     */
   /* Group Add Member Response Result Values.                          */
#define L2CAP_GROUP_ADD_MEMBER_RESPONSE_RESULT_SUCCESS                  0x0000
#define L2CAP_GROUP_ADD_MEMBER_RESPONSE_RESULT_FAILURE                  0x0001

   /* The following Constants represent the defined Bluetooth L2CAP     */
   /* Group Membership Result Values.                                   */
#define L2CAP_GROUP_MEMBERSHIP_RESPONSE_RESULT_SUCCESS                  0x0000
#define L2CAP_GROUP_MEMBERSHIP_RESPONSE_RESULT_FAILURE                  0x0001

   /* According to the Bluetooth Specification 1.0B, L2CAP              */
   /* Implementations Signalling packets should not exceed an MTU size  */
   /* of 48 bytes without first testing to see if a larger packet can   */
   /* be supported.                                                     */
#define L2CAP_SIGNALING_MTU_SIZE                                        48

   /* L2CAP Signaling Command Codes */
#define L2CAP_CODE_REJECT_COMMAND                                       0x01
#define L2CAP_CODE_CONNECTION_REQUEST                                   0x02
#define L2CAP_CODE_CONNECTION_RESPONSE                                  0x03
#define L2CAP_CODE_CONFIG_REQUEST                                       0x04
#define L2CAP_CODE_CONFIG_RESPONSE                                      0x05
#define L2CAP_CODE_DISCONNECTION_REQUEST                                0x06
#define L2CAP_CODE_DISCONNECTION_RESPONSE                               0x07
#define L2CAP_CODE_ECHO_REQUEST                                         0x08
#define L2CAP_CODE_ECHO_RESPONSE                                        0x09
#define L2CAP_CODE_INFORMATION_REQUEST                                  0x0A
#define L2CAP_CODE_INFORMATION_RESPONSE                                 0x0B

   /* L2CAP SDP Protocol UUID's.                                        */

   /* The following MACRO is a utility MACRO that assigns the L2CAP     */
   /* Bluetooth Universally Unique Identifier (L2CAP_UUID_16) to the    */
   /* specified UUID_16_t variable.  This MACRO accepts one parameter   */
   /* which is the UUID_16_t variable that is receive the L2CAP_UUID_16 */
   /* Constant value.                                                   */
#define SDP_ASSIGN_L2CAP_UUID_16(_x)            ASSIGN_UUID_16((_x), 0x01, 0x00)

   /* The following MACRO is a utility MACRO that assigns the L2CAP     */
   /* Bluetooth Universally Unique Identifier (L2CAP_UUID_32) to the    */
   /* specified UUID_32_t variable.  This MACRO accepts one parameter   */
   /* which is the UUID_32_t variable that is receive the L2CAP_UUID_32 */
   /* Constant value.                                                   */
#define SDP_ASSIGN_L2CAP_UUID_32(_x)            ASSIGN_UUID_32((_x), 0x00, 0x00, 0x01, 0x00)

   /* The following MACRO is a utility MACRO that assigns the L2CAP     */
   /* Bluetooth Universally Unique Identifier (L2CAP_UID_128) to the    */
   /* specified UUID_128_t variable.  This MACRO accepts one parameter  */
   /* which is the UUID_128_t variable that is receive the              */
   /* L2CAP_UUID_128 Constant value.                                    */
#define SDP_ASSIGN_L2CAP_UUID_128(_x)           ASSIGN_UUID_128((_x), 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x10, 0x00, 0x80, 0x00, 0x00, 0x80, 0x5F, 0x9B, 0x34, 0xFB)

   /* The following structure represents the Header data that is        */
   /* present in all L2CAP Signaling Commands.  The 'Code' parameter    */
   /* identifies the command code, the 'identifier' field holds a unique*/
   /* number that is used to identify a response to the command.  The   */
   /* 'Data Length' field holds the size of the command data.           */
typedef struct _tagL2CAP_Signal_Command_Header_t
{
  NonAlignedByte_t Code;
  NonAlignedByte_t Identifier;
  NonAlignedWord_t DataLength;
} L2CAP_Signal_Command_Header_t;

#define L2CAP_SIGNAL_COMMAND_HEADER_SIZE                (sizeof(L2CAP_Signal_Command_Header_t))

   /* The following structure represents the structure of the L2CAP     */
   /* Reject Command Packet.                                            */
typedef struct _L2CAP_Reject_Command_t
{
  L2CAP_Signal_Command_Header_t CommandHeader;
  NonAlignedWord_t              Reason;
  Byte_t                        Variable_Data[1];
} L2CAP_Reject_Command_t;

   /* The following MACRO is provided to allow the programmer a very    */
   /* simple means of quickly determining the number of Data Bytes that */
   /* will be required to hold a L2CAP Signal Reject Command Packet.    */
   /* The first parameter to this MACRO is the Number of Bytes of       */
   /* Variable Data that are contained/required for the L2CAP Reject    */
   /* Command.                                                          */
#define L2CAP_REJECT_COMMAND_SIZE(_x)                   ((sizeof(L2CAP_Reject_Command_t) - sizeof(Byte_t)) + (unsigned int)(_x))
#define L2CAP_MIN_REJECT_COMMAND_SIZE                   (L2CAP_SIGNALING_MTU_SIZE-L2CAP_REJECT_COMMAND_SIZE(0))
#define L2CAP_MAX_REJECT_COMMAND_VARIABLE_DATA_SIZE     (L2CAP_SIGNALING_MTU_SIZE-L2CAP_REJECT_COMMAND_SIZE(0))


   /* The following structure represents the structure of the L2CAP     */
   /* Connect Command Packet.                                           */
typedef struct _tagL2CAP_Connect_Request_t
{
  L2CAP_Signal_Command_Header_t CommandHeader;
  NonAlignedWord_t              PSM;
  NonAlignedWord_t              SCID;
} L2CAP_Connect_Request_t;

#define L2CAP_CONNECT_REQUEST_SIZE                      (sizeof(L2CAP_Connect_Request_t))

   /* The following structure represents the structure of the L2CAP     */
   /* Connect Response Packet.                                          */
typedef struct _tagL2CAP_Connect_Response_t
{
  L2CAP_Signal_Command_Header_t CommandHeader;
  NonAlignedWord_t              DCID;
  NonAlignedWord_t              SCID;
  NonAlignedWord_t              Result;
  NonAlignedWord_t              Status;
} L2CAP_Connect_Response_t;

#define L2CAP_CONNECT_RESPONSE_SIZE                     (sizeof(L2CAP_Connect_Response_t))

   /* The following structure represents the structure of the L2CAP     */
   /* Config Request Packet.                                            */
typedef struct _tagL2CAP_Config_Request_t
{
  L2CAP_Signal_Command_Header_t CommandHeader;
  NonAlignedWord_t              DCID;
  NonAlignedWord_t              Flags;
  Byte_t                        Variable_Data[1];
} L2CAP_Config_Request_t;

   /* A Config Request can have up to as many bytes of optional data    */
   /* that is allowed by the supported MTU size, thus the               */
   /* MAX_PAYLOAD_SIZE.                                                 */
#define L2CAP_CONFIG_REQUEST_SIZE(_x)                   (sizeof(L2CAP_Config_Request_t)-sizeof(Byte_t)+(unsigned int)(_x))
#define L2CAP_MAX_CONFIG_REQUEST_VARIABLE_DATA_SIZE     (L2CAP_SIGNALING_MTU_SIZE-L2CAP_CONFIG_REQUEST_SIZE(0))

   /* The following structure represents the structure of the L2CAP     */
   /* Config Response Packet.                                           */
typedef struct _tagL2CAP_Config_Response_t
{
  L2CAP_Signal_Command_Header_t CommandHeader;
  NonAlignedWord_t              SCID;
  NonAlignedWord_t              Flags;
  NonAlignedWord_t              Result;
  Byte_t                        Variable_Data[1];
} L2CAP_Config_Response_t;

   /* A Config Response can have up to as many bytes of optional data   */
   /* that is allowed by the supported MTU size, thus the               */
   /* MAX_PAYLOAD_SIZE.                                                 */
#define L2CAP_CONFIG_RESPONSE_SIZE(_x)                  (sizeof(L2CAP_Config_Response_t)-sizeof(Byte_t)+(unsigned int)(_x))
#define L2CAP_MAX_CONFIG_RESPONSE_VARIABLE_DATA_SIZE    (L2CAP_SIGNALING_MTU_SIZE-L2CAP_CONFIG_RESPONSE_SIZE(0))

   /* The following structure represents the Header information that    */
   /* will prefix each Config Parameter.                                */
typedef struct _tagL2CAP_Config_Param_Header_t
{
   Byte_t Type;
   Byte_t Length;
} L2CAP_Config_Param_Header_t;

#define L2CAP_CONFIG_PARAM_HEADER_SIZE                  (sizeof(L2CAP_Config_Param_Header_t))

   /* The following structure represents the L2CAP QoS Flow Spec        */
   /* parameters.                                                       */
typedef struct _tagL2CAP_Flow_Spec_t
{
   Byte_t             Flags;
   Byte_t             ServiceType;
   NonAlignedDWord_t  TokenRate;
   NonAlignedDWord_t  TokenBucketSize;
   NonAlignedDWord_t  PeakBandwidth;
   NonAlignedDWord_t  Latency;
   NonAlignedDWord_t  DelayVariation;
} L2CAP_Flow_Spec_t;

#define L2CAP_FLOW_SPEC_SIZE                            (sizeof(L2CAP_Flow_Spec_t))

   /* The following structure represents the MTU option data contained  */
   /* in a Configuration signaling packet.                              */
typedef struct _tagL2CAP_Config_Param_MTU_t
{
   L2CAP_Config_Param_Header_t ParamHeader;
   NonAlignedWord_t            MTU;
} L2CAP_Config_Param_MTU_t;

#define L2CAP_CONFIG_PARAM_MTU_SIZE                     (sizeof(L2CAP_Config_Param_MTU_t))

   /* The following structure represents an unknown option info from    */
   /* in a Configuration signaling packet.                              */
typedef struct _tagL2CAP_Config_Param_Unknown_t
{
   L2CAP_Config_Param_Header_t ParamHeader;
} L2CAP_Config_Param_Unknown_t;

#define L2CAP_CONFIG_PARAM_UNKNOWN_SIZE                 (sizeof(L2CAP_Config_Param_Unknown_t))

   /* The following structure represents the Flush Timeout option data  */
   /* contained in a Configuration signaling packet.                    */
typedef struct _tagL2CAP_Config_Param_FlushTO_t
{
   L2CAP_Config_Param_Header_t ParamHeader;
   NonAlignedWord_t            FlushTO;
} L2CAP_Config_Param_FlushTO_t;

#define L2CAP_CONFIG_PARAM_FLUSH_TIMEOUT_SIZE           (sizeof(L2CAP_Config_Param_FlushTO_t))

   /* The following structure represents the QoS option data contained  */
   /* in a Configuration signaling packet.                              */
typedef struct _tagL2CAP_Config_Param_QoS_t
{
   L2CAP_Config_Param_Header_t ParamHeader;
   L2CAP_Flow_Spec_t           FlowSpec;
} L2CAP_Config_Param_QoS_t;

#define L2CAP_CONFIG_PARAM_QOS_SIZE                     (sizeof(L2CAP_Config_Param_QoS_t))

   /* The following structure represents the structure of the L2CAP     */
   /* Disconnect Request Packet.                                        */
typedef struct _tagL2CAP_Disconnect_Request_t
{
  L2CAP_Signal_Command_Header_t CommandHeader;
  NonAlignedWord_t              DCID;
  NonAlignedWord_t              SCID;
} L2CAP_Disconnect_Request_t;

#define L2CAP_DISCONNECT_REQUEST_SIZE                   (sizeof(L2CAP_Disconnect_Request_t))

   /* The following structure represents the structure of the L2CAP     */
   /* Disconnect Response Packet.                                       */
typedef struct _tagL2CAP_Disconnect_Response_t
{
  L2CAP_Signal_Command_Header_t CommandHeader;
  NonAlignedWord_t              DCID;
  NonAlignedWord_t              SCID;
} L2CAP_Disconnect_Response_t;

#define L2CAP_DISCONNECT_RESPONSE_SIZE                  (sizeof(L2CAP_Disconnect_Response_t))

   /* The following structure represents the structure of the L2CAP     */
   /* Echo Request Packet.                                              */
typedef struct _tagL2CAP_Echo_Request_t
{
  L2CAP_Signal_Command_Header_t CommandHeader;
  Byte_t                        Variable_Data[1];
} L2CAP_Echo_Request_t;

   /* An Echo Request can have up to as many bytes of optional data that*/
   /* is allowed by the supported MTU size, thus the MAX_PAYLOAD_SIZE.  */
#define L2CAP_ECHO_REQUEST_SIZE(_x)                     (sizeof(L2CAP_Echo_Request_t)-sizeof(Byte_t)+(unsigned int)(_x))
#define L2CAP_MAX_ECHO_REQUEST_VARIABLE_DATA_SIZE       (L2CAP_SIGNALING_MTU_SIZE-L2CAP_ECHO_REQUEST_SIZE(0))

   /* The following structure represents the structure of the L2CAP     */
   /* Echo Response Packet.                                             */
typedef struct _tagL2CAP_Echo_Response_t
{
  L2CAP_Signal_Command_Header_t CommandHeader;
  Byte_t                        Variable_Data[1];
} L2CAP_Echo_Response_t;

   /* An Echo Response can have up to as many bytes of optional data    */
   /* that is allowed by the supported MTU size, thus the               */
   /* MAX_PAYLOAD_SIZE.                                                 */
#define L2CAP_ECHO_RESPONSE_SIZE(_x)    (sizeof(L2CAP_Echo_Response_t)-sizeof(Byte_t)+(unsigned int)(_x))
#define L2CAP_MAX_ECHO_RESPONSE_VARIABLE_DATA_SIZE  (L2CAP_SIGNALING_MTU_SIZE-L2CAP_ECHO_RESPONSE_SIZE(0))

   /* The following structure represents the structure of the L2CAP     */
   /* Information Request Packet.                                       */
typedef struct _tagL2CAP_Information_Request_t
{
  L2CAP_Signal_Command_Header_t CommandHeader;
  NonAlignedWord_t              InfoType;
} L2CAP_Information_Request_t;

#define L2CAP_INFORMATION_REQUEST_SIZE              (sizeof(L2CAP_Information_Request_t))

   /* The following structure represents the structure of the L2CAP     */
   /* Information Response Packet.                                      */
typedef struct _tagL2CAP_Information_Response_t
{
  L2CAP_Signal_Command_Header_t CommandHeader;
  NonAlignedWord_t              InfoType;
  NonAlignedWord_t              Result;
  Byte_t                        Variable_Data[1];
} L2CAP_Information_Response_t;

   /* An Information Response can have up to as many bytes of optional  */
   /* data that is allowed by the supported MTU size, thus the          */
   /* MAX_PAYLOAD_SIZE.                                                 */
#define L2CAP_INFORMATION_RESPONSE_SIZE(_x)    (sizeof(L2CAP_Information_Response_t)-sizeof(Byte_t)+(unsigned int)(_x))
#define L2CAP_MAX_INFORMATION_RESPONSE_VARIABLE_DATA_SIZE  (L2CAP_SIGNALING_MTU_SIZE-L2CAP_INFORMATION_RESPONSE_SIZE(0))

   /* The following type declaration represents the structure of the    */
   /* Header of an L2CAP Data Packet.  This Header Information is       */
   /* contained in Every Defined L2CAP Data Packet.  This structure     */
   /* forms the basis of additional defined L2CAP Data Packets.  Since  */
   /* this structure is present at the beginning of Every Defined L2CAP */
   /* Data Packet, this structure will be the first element of Every    */
   /* Defined L2CAP Data Packet in this file.                           */
typedef struct _tagL2CAP_Data_Packet_Header_t
{
   NonAlignedWord_t Length;
   NonAlignedWord_t ChannelID;
} L2CAP_Data_Packet_Header_t;

#define L2CAP_DATA_PACKET_HEADER_SIZE                   (sizeof(L2CAP_Data_Packet_Header_t))

   /* The following MACRO is provided to allow the programmer a very    */
   /* simple means of quickly determining the number of Data Bytes that */
   /* will be required to hold a L2CAP Signal Command Packet.  The value*/
   /* 'x' should be the Length of the Payload data.                     */
#define L2CAP_CALCULATE_DATA_PACKET_SIZE(_x)  (L2CAP_DATA_PACKET_HEADER_SIZE + (unsigned int)(_x))

   /* The following structure represents the structure of the L2CAP     */
   /* Connectionless Packet.                                            */
typedef struct _tagL2CAP_Connectionless_Packet_t
{
   L2CAP_Data_Packet_Header_t L2CAP_Data_Packet_Header;
   NonAlignedWord_t           PSM;
   Byte_t                     Variable_Data[1];
} L2CAP_Connectionless_Packet_t;

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Determine the size (in Bytes) of an L2CAP          */
   /* Connectionless Data Packet Structure based upon the size of the   */
   /* Connectionless Data associated with the Packet. The first         */
   /* parameter to this MACRO is the size (in Bytes) of the L2CAP Data  */
   /* that is to be part of the L2CAP Connectionless Data.              */
#define L2CAP_CONNECTIONLESS_PACKET_SIZE(_x)            ((sizeof(L2CAP_Connectionless_Packet_t) - sizeof(Byte_t)) + (unsigned int)(_x))

   /* The following structure represents the structure of the L2CAP     */
   /* Connection Oriented Packet.                                       */
typedef struct _tagL2CAP_Connection_Oriented_Packet_t
{
   L2CAP_Data_Packet_Header_t L2CAP_Data_Packet_Header;
   Byte_t                     Variable_Data[1];
} L2CAP_Connection_Oriented_Packet_t;

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Determine the size (in Bytes) of an L2CAP          */
   /* Connection Oriented Data Packet Structure based upon the size of  */
   /* the Connection Oriented Data associated with the Packet. The      */
   /* first parameter to this MACRO is the size (in Bytes) of the L2CAP */
   /* Data that is to be part of the L2CAP Connection Oriented Data.    */
#define L2CAP_CONNECTION_ORIENTED_PACKET_SIZE(_x)       ((sizeof(L2CAP_Connection_Oriented_Packet_t) - sizeof(Byte_t)) + (unsigned int)(_x))

   /* The following structure represents the structure of the L2CAP     */
   /* Signalling Command Packet.                                        */
typedef struct _tagL2CAP_Signalling_Command_Packet_t
{
   L2CAP_Data_Packet_Header_t L2CAP_Data_Packet_Header;
   Byte_t                     Variable_Data[1];
} L2CAP_Signaling_Command_Packet_t;

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Determine the size (in Bytes) of an L2CAP          */
   /* Signalling Command Packet Structure based upon the size of the    */
   /* Signalling Command Data associated with the Packet. The first     */
   /* parameter to this MACRO is the size (in Bytes) of the L2CAP Data  */
   /* that is to be part of the L2CAP Signalling Command Packet.        */
#define L2CAP_SIGNALLING_COMMAND_PACKET_SIZE(_x)        ((sizeof(L2CAP_Signalling_Command_Packet_t) - sizeof(Byte_t)) + (unsigned int)(_x))

   /* Restore Structure Packing.                                        */
#pragma pack(pop, __L2CAPTYPH_PUSH__)

#endif
