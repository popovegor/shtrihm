/*****< hcitypes.h >***********************************************************/
/*      Copyright 2000 - 2008 Stonestreet One, Inc.                           */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  HCITYPES - Bluetooth HCI Type Definitions/Constants.                      */
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   08/25/00  D. Lange       Initial creation.                               */
/*   12/07/07  D. Mason       Changes for BT 2.1                              */
/******************************************************************************/
#ifndef __HCITYPESH__
#define __HCITYPESH__

   /* Force ALL Structure Declarations to be Byte Packed (noting the    */
   /* current Structure Packing).                                       */
#pragma pack(push, __HCITYPESH_PUSH__)
#pragma pack(1)

#include "BTTypes.h"            /* Bluetooth Type Definitions.                */
#include "HCICommT.h"           /* HCI COMM Driver Types/Constants.           */
#include "HCIUSBT.h"            /* HCI USB Driver Types/Constants.            */

   /* The following Type Declaration defines the currently supported    */
   /* Physical Bluetooth HCI Device Interfaces that are supported by    */
   /* the HCI Packet Driver.                                            */
typedef enum
{
   hdtCOMM,                             /* COM/Serial Port HCI          */
                                        /* Connection Type.             */
   hdtUSB                               /* USB HCI Connection Type.     */
} HCI_DriverType_t;

   /* The following structure encapsulates a generic mechanism for      */
   /* Opening Bluetooth HCI Drivers for different Physical Bluetooth    */
   /* HCI Connection types.  This structure is used by the              */
   /* HCI_OpenDriver() function to inform the HCI Driver of what type   */
   /* (and configuration parameters specific to the specified type) of  */
   /* HCI Physical Driver to open.                                      */
typedef struct _tagHCI_DriverInformation_t
{
   HCI_DriverType_t DriverType;
   union
   {
     HCI_COMMDriverInformation_t COMMDriverInformation;
     HCI_USBDriverInformation_t  USBDriverInformation;
   } DriverInformation;
} HCI_DriverInformation_t;

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Set COM/Serial Driver Information in an            */
   /* HCI_DriverInformation_t structure.  The first parameter is a      */
   /* pointer to an HCI_DriverInformation_t structure, the second,      */
   /* third and fourth parameters are the COM Port Number, Baud Rate,   */
   /* and HCI Protocol to use, respectively.  When this MACRO is        */
   /* complete, the pointer that is used as the first argument to this  */
   /* MACRO will be able to be passed to the HCI_OpenDriver() function  */
   /* without any further processing.                                   */
#define HCI_DRIVER_SET_COMM_INFORMATION(_w, _x, _y, _z)                                                                                          \
{                                                                                                                                                \
   (_w)->DriverType                                                                     = hdtCOMM;                                               \
   (_w)->DriverInformation.COMMDriverInformation.DriverInformationSize                  = sizeof((_w)->DriverInformation.COMMDriverInformation); \
   (_w)->DriverInformation.COMMDriverInformation.COMPortNumber                          = (_x);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.BaudRate                               = (_y);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.Protocol                               = (_z);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.InitializationDelay                    = 0;                                                     \
   (_w)->DriverInformation.COMMDriverInformation.InitializationBaudRate                 = (_y);                                                  \
   wcsncpy((_w)->DriverInformation.COMMDriverInformation.DriverName, TEXT("COM"), HCI_COMM_DRIVER_NAME_MAX);                                     \
   (_w)->DriverInformation.COMMDriverInformation.DriverName[HCI_COMM_DRIVER_NAME_MAX-1] = TEXT('\0');                                            \
   (_w)->DriverInformation.COMMDriverInformation.Flags = 0;                                                                                      \
}

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Set COM/Serial Driver Information in an            */
   /* HCI_DriverInformation_t structure.  The first parameter is a      */
   /* pointer to an HCI_DriverInformation_t structure, the second,      */
   /* third and fourth parameters are the COM Port Number, Baud Rate,   */
   /* and HCI Protocol to use, respectively.  The fifth parameter       */
   /* specifies the Initialization Delay Time (in Milliseconds) to      */
   /* wait before sending any data to the Port.  When this MACRO is     */
   /* complete, the pointer that is used as the first argument to this  */
   /* MACRO will be able to be passed to the HCI_OpenDriver() function  */
   /* without any further processing.                                   */
#define HCI_DRIVER_SET_EXTENDED_COMM_INFORMATION_DELAY(_w, _x, _y, _z, _a)                                                                       \
{                                                                                                                                                \
   (_w)->DriverType                                                                     = hdtCOMM;                                               \
   (_w)->DriverInformation.COMMDriverInformation.DriverInformationSize                  = sizeof((_w)->DriverInformation.COMMDriverInformation); \
   (_w)->DriverInformation.COMMDriverInformation.COMPortNumber                          = (_x);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.BaudRate                               = (_y);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.Protocol                               = (_z);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.InitializationDelay                    = (_a);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.InitializationBaudRate                 = (_y);                                                  \
   wcsncpy((_w)->DriverInformation.COMMDriverInformation.DriverName, TEXT("COM"), HCI_COMM_DRIVER_NAME_MAX);                                     \
   (_w)->DriverInformation.COMMDriverInformation.DriverName[HCI_COMM_DRIVER_NAME_MAX-1] = TEXT('\0');                                            \
   (_w)->DriverInformation.COMMDriverInformation.Flags = 0;                                                                                      \
}

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Set COM/Serial Driver Information in an            */
   /* HCI_DriverInformation_t structure.  The first parameter is a      */
   /* pointer to an HCI_DriverInformation_t structure, the second, third*/
   /* and fourth parameters are the COM Port Number, Baud Rate, and HCI */
   /* Protocol to use, respectively.  The fifth parameter allows the    */
   /* caller to set the initialization baud rate.  When this MACRO is   */
   /* complete, the pointer that is used as the first argument to this  */
   /* MACRO will be able to be passed to the HCI_OpenDriver() function  */
   /* without any further processing.                                   */
#define HCI_DRIVER_SET_EXTENDED_COMM_INFORMATION_BAUD_RATE(_w, _x, _y, _z, _a)                                                                   \
{                                                                                                                                                \
   (_w)->DriverType                                                                     = hdtCOMM;                                               \
   (_w)->DriverInformation.COMMDriverInformation.DriverInformationSize                  = sizeof((_w)->DriverInformation.COMMDriverInformation); \
   (_w)->DriverInformation.COMMDriverInformation.COMPortNumber                          = (_x);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.BaudRate                               = (_y);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.Protocol                               = (_z);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.InitializationDelay                    = 0;                                                     \
   (_w)->DriverInformation.COMMDriverInformation.InitializationBaudRate                 = (_a);                                                  \
   wcsncpy((_w)->DriverInformation.COMMDriverInformation.DriverName, TEXT("COM"), HCI_COMM_DRIVER_NAME_MAX);                                     \
   (_w)->DriverInformation.COMMDriverInformation.DriverName[HCI_COMM_DRIVER_NAME_MAX-1] = TEXT('\0');                                            \
   (_w)->DriverInformation.COMMDriverInformation.Flags = 0;                                                                                      \
}

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Set COM/Serial Driver Information in an            */
   /* HCI_DriverInformation_t structure.  The first parameter is a      */
   /* pointer to an HCI_DriverInformation_t structure, the second,      */
   /* third and fourth parameters are the COM Port Number, Baud Rate,   */
   /* and HCI Protocol to use, respectively.  The fifth parameter       */
   /* allows the caller to override the device driver name.  When this  */
   /* MACRO is complete, the pointer that is used as the first argument */
   /* to this MACRO will be able to be passed to the HCI_OpenDriver()   */
   /* function without any further processing.                          */
#define HCI_DRIVER_SET_EXTENDED_COMM_INFORMATION_DRIVER_NAME(_w, _x, _y, _z, _a)                                                                 \
{                                                                                                                                                \
   (_w)->DriverType                                                                     = hdtCOMM;                                               \
   (_w)->DriverInformation.COMMDriverInformation.DriverInformationSize                  = sizeof((_w)->DriverInformation.COMMDriverInformation); \
   (_w)->DriverInformation.COMMDriverInformation.COMPortNumber                          = (_x);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.BaudRate                               = (_y);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.Protocol                               = (_z);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.InitializationDelay                    = 0;                                                     \
   (_w)->DriverInformation.COMMDriverInformation.InitializationBaudRate                 = (_y);                                                  \
   wcsncpy((_w)->DriverInformation.COMMDriverInformation.DriverName, (_a), HCI_COMM_DRIVER_NAME_MAX);                                            \
   (_w)->DriverInformation.COMMDriverInformation.DriverName[HCI_COMM_DRIVER_NAME_MAX-1] = TEXT('\0');                                            \
   (_w)->DriverInformation.COMMDriverInformation.Flags = 0;                                                                                      \
}

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Set COM/Serial Driver Information in an            */
   /* HCI_DriverInformation_t structure.  The first parameter is a      */
   /* pointer to an HCI_DriverInformation_t structure, the second,      */
   /* third and fourth parameters are the COM Device Name, Baud Rate,   */
   /* and HCI Protocol to use, respectively.  The fifth parameter       */
   /* specifies the Initialization Delay Time (in Milliseconds) to      */
   /* wait before sending any data to the Port.  The sixth parameter    */
   /* allows the caller to override the device driver name.  When this  */
   /* MACRO is complete, the pointer that is used as the first argument */
   /* to this MACRO will be able to be passed to the HCI_OpenDriver()   */
   /* function without any further processing.                          */
#define HCI_DRIVER_SET_EXTENDED_COMM_INFORMATION_DELAY_DRIVER_NAME(_w, _x, _y, _z, _a, _b)                                                       \
{                                                                                                                                                \
   (_w)->DriverType                                                                     = hdtCOMM;                                               \
   (_w)->DriverInformation.COMMDriverInformation.DriverInformationSize                  = sizeof((_w)->DriverInformation.COMMDriverInformation); \
   (_w)->DriverInformation.COMMDriverInformation.COMPortNumber                          = (_x);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.BaudRate                               = (_y);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.Protocol                               = (_z);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.InitializationDelay                    = (_a);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.InitializationBaudRate                 = (_y);                                                  \
   wcsncpy((_w)->DriverInformation.COMMDriverInformation.DriverName, (_b), HCI_COMM_DRIVER_NAME_MAX);                                            \
   (_w)->DriverInformation.COMMDriverInformation.DriverName[HCI_COMM_DRIVER_NAME_MAX-1] = TEXT('\0');                                            \
   (_w)->DriverInformation.COMMDriverInformation.Flags = 0;                                                                                      \
}

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Set COM/Serial Driver Information in an            */
   /* HCI_DriverInformation_t structure.  The first parameter is a      */
   /* pointer to an HCI_DriverInformation_t structure, the second, third*/
   /* and fourth parameters are the COM Device Name, Baud Rate, and HCI */
   /* Protocol to use, respectively.  The fifth parameter specifies the */
   /* Initialization Delay Time (in Milliseconds) to wait before sending*/
   /* any data to the Port.  The sixth parameter allows the caller to   */
   /* set the initialization baud rate.  The seventh parameter allows   */
   /* the caller to override the device driver name.  When this MACRO is*/
   /* complete, the pointer that is used as the first argument to this  */
   /* MACRO will be able to be passed to the HCI_OpenDriver() function  */
   /* without any further processing.                                   */
#define HCI_DRIVER_SET_EXTENDED_COMM_INFORMATION_DELAY_DRIVER_NAME_BAUD_RATE(_w, _x, _y, _z, _a, _b, _c)                                             \
{                                                                                                                                                \
   (_w)->DriverType                                                                     = hdtCOMM;                                               \
   (_w)->DriverInformation.COMMDriverInformation.DriverInformationSize                  = sizeof((_w)->DriverInformation.COMMDriverInformation); \
   (_w)->DriverInformation.COMMDriverInformation.COMPortNumber                          = (_x);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.BaudRate                               = (_y);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.Protocol                               = (_z);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.InitializationDelay                    = (_a);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.InitializationBaudRate                 = (_b);                                                  \
   wcsncpy((_w)->DriverInformation.COMMDriverInformation.DriverName, (_c), HCI_COMM_DRIVER_NAME_MAX);                                            \
   (_w)->DriverInformation.COMMDriverInformation.DriverName[HCI_COMM_DRIVER_NAME_MAX-1] = TEXT('\0');                                            \
   (_w)->DriverInformation.COMMDriverInformation.Flags = 0;                                                                                      \
}

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Set COM/Serial Driver Information in an            */
   /* HCI_DriverInformation_t structure.  The first parameter is a      */
   /* pointer to an HCI_DriverInformation_t structure, the second, third*/
   /* and fourth parameters are the COM Device Name, Baud Rate, and HCI */
   /* Protocol to use, respectively.  The fifth parameter specifies the */
   /* Initialization Delay Time (in Milliseconds) to wait before sending*/
   /* any data to the Port.  The sixth parameter allows the caller to   */
   /* set the initialization baud rate.  The seventh parameter allows   */
   /* the caller to override the device driver name.  When this MACRO is*/
   /* complete, the pointer that is used as the first argument to this  */
   /* MACRO will be able to be passed to the HCI_OpenDriver() function  */
   /* without any further processing.                                   */
#define HCI_DRIVER_SET_EXTENDED_COMM_INFORMATION_DELAY_DRIVER_NAME_BAUD_RATE_FLAGS(_w, _x, _y, _z, _a, _b, _c, _d)                                             \
{                                                                                                                                                \
   (_w)->DriverType                                                                     = hdtCOMM;                                               \
   (_w)->DriverInformation.COMMDriverInformation.DriverInformationSize                  = sizeof((_w)->DriverInformation.COMMDriverInformation); \
   (_w)->DriverInformation.COMMDriverInformation.COMPortNumber                          = (_x);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.BaudRate                               = (_y);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.Protocol                               = (_z);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.InitializationDelay                    = (_a);                                                  \
   (_w)->DriverInformation.COMMDriverInformation.InitializationBaudRate                 = (_b);                                                  \
   wcsncpy((_w)->DriverInformation.COMMDriverInformation.DriverName, (_c), HCI_COMM_DRIVER_NAME_MAX);                                            \
   (_w)->DriverInformation.COMMDriverInformation.DriverName[HCI_COMM_DRIVER_NAME_MAX-1] = TEXT('\0');                                            \
   (_w)->DriverInformation.COMMDriverInformation.Flags = _d;                                                                                      \
}

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Set USB Driver Information in an                   */
   /* HCI_DriverInformation_t structure.  The first parameter is a      */
   /* pointer to an HCI_DriverInformation_t structure.  Currently there */
   /* are NO parameters that can be specified for an HCI USB Driver.    */
   /* When this MACRO is complete, the pointer that is used as the      */
   /* first argument to this MACRO will be able to be passed to the     */
   /* HCI_OpenDriver() function without any further processing.         */
#define HCI_DRIVER_SET_USB_INFORMATION(_w)                                                                                    \
{                                                                                                                             \
   (_w)->DriverType                                                   = hdtUSB;                                               \
   (_w)->DriverInformation.USBDriverInformation.DriverInformationSize = sizeof((_w)->DriverInformation.USBDriverInformation); \
   (_w)->DriverInformation.USBDriverInformation.DriverType            = dtStonestreetOne;                                     \
   (_w)->DriverInformation.USBDriverInformation.InitializationDelay   = 0;                                                    \
}

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Set USB Driver Information in an                   */
   /* HCI_DriverInformation_t structure.  The first parameter is a      */
   /* pointer to an HCI_DriverInformation_t structure.  The second      */
   /* parameter represents the USB Driver type of the HCI USB Driver to */
   /* open.  When this MACRO is complete, the pointer that is used as   */
   /* the first argument to this MACRO will be able to be passed to the */
   /* HCI_OpenDriver() function without any further processing.         */
#define HCI_DRIVER_SET_EXTENDED_USB_INFORMATION(_w, _x)                                                                       \
{                                                                                                                             \
   (_w)->DriverType                                                   = hdtUSB;                                               \
   (_w)->DriverInformation.USBDriverInformation.DriverInformationSize = sizeof((_w)->DriverInformation.USBDriverInformation); \
   (_w)->DriverInformation.USBDriverInformation.DriverType            = (_x);                                                 \
   (_w)->DriverInformation.USBDriverInformation.InitializationDelay   = 0;                                                    \
}

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Set USB Driver Information in an                   */
   /* HCI_DriverInformation_t structure.  The first parameter is a      */
   /* pointer to an HCI_DriverInformation_t structure.  The second      */
   /* parameter represents the USB Driver type of the HCI USB Driver to */
   /* open.  The third parameter specifies the Initialization Delay Time*/
   /* (in Milliseconds) to wait before sending any data to the Port.    */
   /* When this MACRO is complete, the pointer that is used as the first*/
   /* argument to this MACRO will be able to be passed to the           */
   /* HCI_OpenDriver() function without any further processing.         */
#define HCI_DRIVER_SET_EXTENDED_USB_INFORMATION_DELAY(_w, _x, _y)                                                             \
{                                                                                                                             \
   (_w)->DriverType                                                   = hdtUSB;                                               \
   (_w)->DriverInformation.USBDriverInformation.DriverInformationSize = sizeof((_w)->DriverInformation.USBDriverInformation); \
   (_w)->DriverInformation.USBDriverInformation.DriverType            = (_x);                                                 \
   (_w)->DriverInformation.USBDriverInformation.InitializationDelay   = (_y);                                                 \
}

   /* The following enumerated type represents Possible SCO             */
   /* Configurations that might have to be configured for a specific    */
   /* Bluetooth HCI Driver.  For example, the USB Bluetooth HCI         */
   /* Interface defines different USB Interfaces (dynamically scales    */
   /* required Bandwidth on the USB Bus) depending upon the required    */
   /* SCO functionality required.                                       */
typedef enum
{
   hscNoChannels,
   hscOneChannel8BitVoice,
   hscOneChannel16BitVoice,
   hscTwoChannel8BitVoice,
   hscTwoChannel16BitVoice,
   hscThreeChannel8BitVoice,
   hscThreeChannel16BitVoice
} HCI_SCOConfiguration_t;

   /* The following Type Definition represents ALL HCI Packet Types that*/
   /* can be passed into and out of the Lower Level HCI Driver Layer    */
   /* Interface.                                                        */
   /* * NOTE * This module does NOT define any HCI Transport Specific   */
   /*          HCI Packet Types.  This module simply defines the        */
   /*          Starting Point for these Additional HCI Commands, and    */
   /*          allows these to be used if the implementation requires   */
   /*          these additional HCI Packet Types.                       */
   /* * NOTE * These Types are the actual HCI Packet Data Type ID's     */
   /*          defined in the Bluetooth Specification Version 1.0b.  If */
   /*          these values change (or more are added/deleted) then     */
   /*          a mapping from these Types to these types will be needed.*/
   /* * NOTE * While the Types are the same numerical value, the size   */
   /*          of the Type MAY NOT be the same as the Size of the       */
   /*          type required in an HCI Packet.                          */
typedef enum
{
   ptHCICommandPacket = 0x01,           /* Simple HCI Command Packet    */
                                        /* Type.                        */
   ptHCIACLDataPacket = 0x02,           /* HCI ACL Data Packet Type.    */
   ptHCISCODataPacket = 0x03,           /* HCI SCO Data Packet Type.    */
   ptHCIeSCODataPacket= 0x03,           /* HCI eSCO Data Packet Type.   */
   ptHCIEventPacket   = 0x04,           /* HCI Event Packet Type.       */
   ptHCIAdditional    = 0x05            /* Starting Point for Additional*/
                                        /* HCI Packet Types that are    */
                                        /* Implementation Specific (for */
                                        /* example RS-232 HCI defines   */
                                        /* two Additional HCI Packet    */
                                        /* Types which are numbered     */
                                        /* 0x05 and 0x06 for RS-232 HCI.*/
} HCI_PacketType_t;

   /* The following structure represents the Data structure that holds  */
   /* the information for a Raw HCI Packet that is to be transmitted or */
   /* that has been received.  The only detail to note is that the      */
   /* Packet Data field is an array of unsigned char's, and NOT a       */
   /* Pointer to an array of unsigned char's.  This is very important,  */
   /* because this mechanism will allow an arbitrary memory buffer to be*/
   /* typecast to this structure and all elements will be accessible in */
   /* the same memory block (i.e. NO other Pointer operation is         */
   /* required).  The side effect of this is that when the memory for a */
   /* Raw HCI Packet is to be allocated, the allocated size required    */
   /* will be (sizeof(HCI_Packet_t)-1) + length of the Packet Data.     */
   /* After this is completed, the data elements in the Packet Data     */
   /* array can be accessed by simply Array Logic, aiding code          */
   /* readability.  It might appear confusing to the user because array */
   /* elements greater than zero will be indexed, however, as long as   */
   /* the programmer is aware of this design decision, the code should  */
   /* be much more simple to read.  MACRO's and Definitions will be     */
   /* provided following this structure definition to alleviate the     */
   /* programmer from having to remember the above formula when         */
   /* allocating memory of the correct size.                            */
typedef struct _tagHCI_Packet_t
{
   HCI_PacketType_t HCIPacketType;
   unsigned int     HCIPacketLength;
   unsigned char    HCIPacketData[1];
} HCI_Packet_t;

   /* The following Constant represents the actual size of the HCI      */
   /* Packet Header Information.  This Constant is to be used instead of*/
   /* simply using sizeof(HCI_Packet_t) to get the size.  The reason for*/
   /* this was explained above, and is primarily to aid in code         */
   /* readability and efficiency.                                       */
#define HCI_PACKET_HEADER_SIZE         (sizeof(HCI_Packet_t)-sizeof(unsigned char))

   /* The following MACRO is provided to allow the programmer a very    */
   /* simple means of quickly determining the number of Data Bytes that */
   /* will be required to hold a HCI Packet Information Header and the  */
   /* Raw HCI Packet Data (of the specified length).  See notes and     */
   /* discussion above for the reason for this MACRO definition.        */
#define HCI_CALCULATE_PACKET_SIZE(_x)  (HCI_PACKET_HEADER_SIZE+(unsigned int)(_x))

   /* The following define determines the maximum fixed size that is    */
   /* is used to define the extended inquiry response returned by the   */
   /* local device.  The size of this buffer is always fixed.           */         
#define EXTENDED_INQUIRY_RESPONSE_DATA_MAXIMUM_SIZE                           (240)

   /* The following type defines the buffer that is used to write or    */
   /* read the extended inquiry response data to be returned by the     */
   /* local device.  The size of this buffer is always fixed.           */
typedef Byte_t Extended_Inquiry_Response_Data_t[EXTENDED_INQUIRY_RESPONSE_DATA_MAXIMUM_SIZE];

   /* HCI Command Declarations/Types/Constants.                         */

   /* The following MACRO is provided to allow the programmer a very    */
   /* simple means of making an HCI Command Packet OpCode.  The OpCode  */
   /* Generated can be directly assigned to the OpCode field, so that   */
   /* the programmer does NOT have to translate Big Endian/Little       */
   /* Endian.  The OpCode itself NEEDS to be stored in the OpCode field */
   /* in Little Endian Format.  The first parameter is the OGF and the  */
   /* second parameter of the MACRO is the OCF of the Command.          */
#define HCI_MAKE_COMMAND_OPCODE(_x, _y) (((((Word_t)(_x)) << 10) & 0xFC00) | (((Word_t)(_y)) & 0x03FF))

   /* HCI Command Code OGF Definitions.                                 */
#define HCI_COMMAND_CODE_NULL_OGF                                       0x00
#define HCI_COMMAND_CODE_LINK_CONTROL_OGF                               0x01
#define HCI_COMMAND_CODE_LINK_POLICY_OGF                                0x02
#define HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF                           0x03
#define HCI_COMMAND_CODE_INFORMATIONAL_PARAMETERS_OGF                   0x04
#define HCI_COMMAND_CODE_STATUS_PARAMETERS_OGF                          0x05
#define HCI_COMMAND_CODE_TESTING_COMMANDS_OGF                           0x06

#define HCI_COMMAND_CODE_BLUETOOTH_LOGO_TESTING_OGF                     0x3E
#define HCI_COMMAND_CODE_VENDOR_SPECIFIC_DEBUG_OGF                      0x3F

   /* HCI Command Code OCF Definitions (NULL OpCode).                   */
#define HCI_COMMAND_CODE_NULL_OCF                                       0x0000

   /* HCI Command Code OCF Definitions (Link Control).                  */
#define HCI_COMMAND_CODE_INQUIRY_OCF                                    0x0001
#define HCI_COMMAND_CODE_INQUIRY_CANCEL_OCF                             0x0002
#define HCI_COMMAND_CODE_PERIODIC_INQUIRY_MODE_OCF                      0x0003
#define HCI_COMMAND_CODE_EXIT_PERIODIC_INQUIRY_MODE_OCF                 0x0004
#define HCI_COMMAND_CODE_CREATE_CONNECTION_OCF                          0x0005
#define HCI_COMMAND_CODE_DISCONNECT_OCF                                 0x0006
#define HCI_COMMAND_CODE_ADD_SCO_CONNECTION_OCF                         0x0007
#define HCI_COMMAND_CODE_ACCEPT_CONNECTION_REQUEST_OCF                  0x0009
#define HCI_COMMAND_CODE_REJECT_CONNECTION_REQUEST_OCF                  0x000A
#define HCI_COMMAND_CODE_LINK_KEY_REQUEST_REPLY_OCF                     0x000B
#define HCI_COMMAND_CODE_LINK_KEY_REQUEST_NEGATIVE_REPLY_OCF            0x000C
#define HCI_COMMAND_CODE_PIN_CODE_REQUEST_REPLY_OCF                     0x000D
#define HCI_COMMAND_CODE_PIN_CODE_REQUEST_NEGATIVE_REPLY_OCF            0x000E
#define HCI_COMMAND_CODE_CHANGE_CONNECTION_PACKET_TYPE_OCF              0x000F
#define HCI_COMMAND_CODE_AUTHENTICATION_REQUESTED_OCF                   0x0011
#define HCI_COMMAND_CODE_SET_CONNECTION_ENCRYPTION_OCF                  0x0013
#define HCI_COMMAND_CODE_CHANGE_CONNECTION_LINK_KEY_OCF                 0x0015
#define HCI_COMMAND_CODE_MASTER_LINK_KEY_OCF                            0x0017
#define HCI_COMMAND_CODE_REMOTE_NAME_REQUEST_OCF                        0x0019
#define HCI_COMMAND_CODE_READ_REMOTE_SUPPORTED_FEATURES_OCF             0x001B
#define HCI_COMMAND_CODE_READ_REMOTE_VERSION_INFORMATION_OCF            0x001D
#define HCI_COMMAND_CODE_READ_CLOCK_OFFSET_OCF                          0x001F

   /* HCI Command Code OCF Definitions (Link Control - Version 1.2).    */
#define HCI_COMMAND_CODE_CREATE_CONNECTION_CANCEL_OCF                   0x0008
#define HCI_COMMAND_CODE_REMOTE_NAME_REQUEST_CANCEL_OCF                 0x001A
#define HCI_COMMAND_CODE_READ_REMOTE_EXTENDED_FEATURES_OCF              0x001C
#define HCI_COMMAND_CODE_READ_LMP_HANDLE_OCF                            0x0020
#define HCI_COMMAND_CODE_SETUP_SYNCHRONOUS_CONNECTION_OCF               0x0028
#define HCI_COMMAND_CODE_ACCEPT_SYNCHRONOUS_CONNECTION_OCF              0x0029
#define HCI_COMMAND_CODE_REJECT_SYNCHRONOUS_CONNECTION_OCF              0x002A

   /* HCI Command Code OCF Definitions (Link Control - Version 2.1).    */
#define HCI_COMMAND_CODE_IO_CAPABILITY_REQUEST_REPLY_OCF                0x002B
#define HCI_COMMAND_CODE_USER_CONFIRMATION_REQUEST_REPLY_OCF            0x002C
#define HCI_COMMAND_CODE_USER_CONFIRMATION_REQUEST_NEGATIVE_REPLY_OCF   0x002D
#define HCI_COMMAND_CODE_USER_PASSKEY_REQUEST_REPLY_OCF                 0x002E
#define HCI_COMMAND_CODE_USER_PASSKEY_REQUEST_NEGATIVE_REPLY_OCF        0x002F
#define HCI_COMMAND_CODE_REMOTE_OOB_DATA_REQUEST_REPLY_OCF              0x0030
#define HCI_COMMAND_CODE_REMOTE_OOB_DATA_REQUEST_NEGATIVE_REPLY_OCF     0x0033
#define HCI_COMMAND_CODE_IO_CAPABILITY_REQUEST_NEGATIVE_REPLY_OCF       0x0034

   /* HCI Command Code OCF Definitions (Link Policy).                   */
#define HCI_COMMAND_CODE_HOLD_MODE_OCF                                  0x0001
#define HCI_COMMAND_CODE_SNIFF_MODE_OCF                                 0x0003
#define HCI_COMMAND_CODE_EXIT_SNIFF_MODE_OCF                            0x0004
#define HCI_COMMAND_CODE_PARK_MODE_OCF                                  0x0005
#define HCI_COMMAND_CODE_EXIT_PARK_MODE_OCF                             0x0006
#define HCI_COMMAND_CODE_QOS_SETUP_OCF                                  0x0007
#define HCI_COMMAND_CODE_ROLE_DISCOVERY_OCF                             0x0009
#define HCI_COMMAND_CODE_SWITCH_ROLE_OCF                                0x000B
#define HCI_COMMAND_CODE_READ_LINK_POLICY_SETTINGS_OCF                  0x000C
#define HCI_COMMAND_CODE_WRITE_LINK_POLICY_SETTINGS_OCF                 0x000D

   /* HCI Command Code OCF Definitions (Link Policy - Version 1.2).     */
#define HCI_COMMAND_CODE_READ_DEFAULT_LINK_POLICY_SETTINGS_OCF          0x000E
#define HCI_COMMAND_CODE_WRITE_DEFAULT_LINK_POLICY_SETTINGS_OCF         0x000F
#define HCI_COMMAND_CODE_FLOW_SPECIFICATION_OCF                         0x0010

   /* HCI Command Code OCF Definitions (Link Policy - Version 2.1).     */
#define HCI_COMMAND_CODE_SNIFF_SUBRATING_OCF                            0x0011

   /* HCI Command Code OCF Definitions (Host Control and Baseband).     */
#define HCI_COMMAND_CODE_SET_EVENT_MASK_OCF                             0x0001
#define HCI_COMMAND_CODE_RESET_OCF                                      0x0003
#define HCI_COMMAND_CODE_SET_EVENT_FILTER_OCF                           0x0005
#define HCI_COMMAND_CODE_FLUSH_OCF                                      0x0008
#define HCI_COMMAND_CODE_READ_PIN_TYPE_OCF                              0x0009
#define HCI_COMMAND_CODE_WRITE_PIN_TYPE_OCF                             0x000A
#define HCI_COMMAND_CODE_CREATE_NEW_UNIT_KEY_OCF                        0x000B
#define HCI_COMMAND_CODE_READ_STORED_LINK_KEY_OCF                       0x000D
#define HCI_COMMAND_CODE_WRITE_STORED_LINK_KEY_OCF                      0x0011
#define HCI_COMMAND_CODE_DELETE_STORED_LINK_KEY_OCF                     0x0012
#define HCI_COMMAND_CODE_CHANGE_LOCAL_NAME_OCF                          0x0013
#define HCI_COMMAND_CODE_WRITE_LOCAL_NAME_OCF                           0x0013
#define HCI_COMMAND_CODE_READ_LOCAL_NAME_OCF                            0x0014
#define HCI_COMMAND_CODE_READ_CONNECTION_ACCEPT_TIMEOUT_OCF             0x0015
#define HCI_COMMAND_CODE_WRITE_CONNECTION_ACCEPT_TIMEOUT_OCF            0x0016
#define HCI_COMMAND_CODE_READ_PAGE_TIMEOUT_OCF                          0x0017
#define HCI_COMMAND_CODE_WRITE_PAGE_TIMEOUT_OCF                         0x0018
#define HCI_COMMAND_CODE_READ_SCAN_ENABLE_OCF                           0x0019
#define HCI_COMMAND_CODE_WRITE_SCAN_ENABLE_OCF                          0x001A
#define HCI_COMMAND_CODE_READ_PAGE_SCAN_ACTIVITY_OCF                    0x001B
#define HCI_COMMAND_CODE_WRITE_PAGE_SCAN_ACTIVITY_OCF                   0x001C
#define HCI_COMMAND_CODE_READ_INQUIRY_SCAN_ACTIVITY_OCF                 0x001D
#define HCI_COMMAND_CODE_WRITE_INQUIRY_SCAN_ACTIVITY_OCF                0x001E
#define HCI_COMMAND_CODE_READ_AUTHENTICATION_ENABLE_OCF                 0x001F
#define HCI_COMMAND_CODE_WRITE_AUTHENTICATION_ENABLE_OCF                0x0020
#define HCI_COMMAND_CODE_READ_ENCRYPTION_MODE_OCF                       0x0021
#define HCI_COMMAND_CODE_WRITE_ENCRYPTION_MODE_OCF                      0x0022
#define HCI_COMMAND_CODE_READ_CLASS_OF_DEVICE_OCF                       0x0023
#define HCI_COMMAND_CODE_WRITE_CLASS_OF_DEVICE_OCF                      0x0024
#define HCI_COMMAND_CODE_READ_VOICE_SETTING_OCF                         0x0025
#define HCI_COMMAND_CODE_WRITE_VOICE_SETTING_OCF                        0x0026
#define HCI_COMMAND_CODE_READ_AUTOMATIC_FLUSH_TIMEOUT_OCF               0x0027
#define HCI_COMMAND_CODE_WRITE_AUTOMATIC_FLUSH_TIMEOUT_OCF              0x0028
#define HCI_COMMAND_CODE_READ_NUM_BROADCAST_RETRANSMISSIONS_OCF         0x0029
#define HCI_COMMAND_CODE_WRITE_NUM_BROADCAST_RETRANSMISSIONS_OCF        0x002A
#define HCI_COMMAND_CODE_READ_HOLD_MODE_ACTIVITY_OCF                    0x002B
#define HCI_COMMAND_CODE_WRITE_HOLD_MODE_ACTIVITY_OCF                   0x002C
#define HCI_COMMAND_CODE_READ_TRANSMIT_POWER_LEVEL_OCF                  0x002D
#define HCI_COMMAND_CODE_READ_SCO_FLOW_CONTROL_ENABLE_OCF               0x002E
#define HCI_COMMAND_CODE_READ_SYNCHRONOUS_FLOW_CONTROL_ENABLE_OCF       0x002E
#define HCI_COMMAND_CODE_WRITE_SCO_FLOW_CONTROL_ENABLE_OCF              0x002F
#define HCI_COMMAND_CODE_WRITE_SYNCHRONOUS_FLOW_CONTROL_ENABLE_OCF      0x002F
#define HCI_COMMAND_CODE_SET_HOST_CONTROLLER_TO_HOST_FLOW_CONTROL_OCF   0x0031
#define HCI_COMMAND_CODE_HOST_BUFFER_SIZE_OCF                           0x0033
#define HCI_COMMAND_CODE_HOST_NUMBER_OF_COMPLETED_PACKETS_OCF           0x0035
#define HCI_COMMAND_CODE_READ_LINK_SUPERVISION_TIMEOUT_OCF              0x0036
#define HCI_COMMAND_CODE_WRITE_LINK_SUPERVISION_TIMEOUT_OCF             0x0037
#define HCI_COMMAND_CODE_READ_NUMBER_OF_SUPPORTED_IAC_OCF               0x0038
#define HCI_COMMAND_CODE_READ_CURRENT_IAC_LAP_OCF                       0x0039
#define HCI_COMMAND_CODE_WRITE_CURRENT_IAC_LAP_OCF                      0x003A
#define HCI_COMMAND_CODE_READ_PAGE_SCAN_PERIOD_MODE_OCF                 0x003B
#define HCI_COMMAND_CODE_WRITE_PAGE_SCAN_PERIOD_MODE_OCF                0x003C
#define HCI_COMMAND_CODE_READ_PAGE_SCAN_MODE_OCF                        0x003D
#define HCI_COMMAND_CODE_WRITE_PAGE_SCAN_MODE_OCF                       0x003E

   /* HCI Command Code OCF Definitions (Host Control and Baseband -     */
   /* Version 1.2).                                                     */
#define HCI_COMMAND_CODE_SET_AFH_HOST_CHANNEL_CLASSIFICATION_OCF        0x003F
#define HCI_COMMAND_CODE_READ_INQUIRY_SCAN_TYPE_OCF                     0x0042
#define HCI_COMMAND_CODE_WRITE_INQUIRY_SCAN_TYPE_OCF                    0x0043
#define HCI_COMMAND_CODE_READ_INQUIRY_MODE_OCF                          0x0044
#define HCI_COMMAND_CODE_WRITE_INQUIRY_MODE_OCF                         0x0045
#define HCI_COMMAND_CODE_READ_PAGE_SCAN_TYPE_OCF                        0x0046
#define HCI_COMMAND_CODE_WRITE_PAGE_SCAN_TYPE_OCF                       0x0047
#define HCI_COMMAND_CODE_READ_AFH_CHANNEL_ASSESSMENT_MODE_OCF           0x0048
#define HCI_COMMAND_CODE_WRITE_AFH_CHANNEL_ASSESSMENT_MODE_OCF          0x0049

   /* HCI Command Code OCF Definitions (Host Control and Baseband -     */
   /* Version 2.1).                                                     */
#define HCI_COMMAND_CODE_READ_EXTENDED_INQUIRY_RESPONSE_OCF             0x0051
#define HCI_COMMAND_CODE_WRITE_EXTENDED_INQUIRY_RESPONSE_OCF            0x0052
#define HCI_COMMAND_CODE_REFRESH_ENCRYPTION_KEY_OCF                     0x0053
#define HCI_COMMAND_CODE_READ_SIMPLE_PAIRING_MODE_OCF                   0x0055
#define HCI_COMMAND_CODE_WRITE_SIMPLE_PAIRING_MODE_OCF                  0x0056
#define HCI_COMMAND_CODE_READ_LOCAL_OOB_DATA_OCF                        0x0057
#define HCI_COMMAND_CODE_READ_INQUIRY_RESPONSE_TRANSMIT_POWER_LEVEL_OCF 0x0058
#define HCI_COMMAND_CODE_WRITE_INQUIRY_TRANSMIT_POWER_LEVEL_OCF         0x0059
#define HCI_COMMAND_CODE_READ_DEFAULT_ERRONEOUS_DATA_REPORTING_OCF      0x005A
#define HCI_COMMAND_CODE_WRITE_DEFAULT_ERRONEOUS_DATA_REPORTING_OCF     0x005B
#define HCI_COMMAND_CODE_ENHANCED_FLUSH_OCF                             0x005F
#define HCI_COMMAND_CODE_SEND_KEYPRESS_NOTIFICATION_OCF                 0x0060

   /* HCI Command Code OCF Definitions (Informational Parameters).      */
#define HCI_COMMAND_CODE_READ_LOCAL_VERSION_INFORMATION_OCF             0x0001
#define HCI_COMMAND_CODE_READ_LOCAL_SUPPORTED_FEATURES_OCF              0x0003
#define HCI_COMMAND_CODE_READ_BUFFER_SIZE_OCF                           0x0005
#define HCI_COMMAND_CODE_READ_COUNTRY_CODE_OCF                          0x0007
#define HCI_COMMAND_CODE_READ_BD_ADDR_OCF                               0x0009

   /* HCI Command Code OCF Definitions (Informational Parameters -      */
   /* Version 1.2)                                                      */
#define HCI_COMMAND_CODE_READ_LOCAL_SUPPORTED_COMMANDS_OCF              0x0002
#define HCI_COMMAND_CODE_READ_LOCAL_EXTENDED_FEATURES_OCF               0x0004

   /* HCI Command Code OCF Definitions (Status Parameters).             */
#define HCI_COMMAND_CODE_READ_FAILED_CONTACT_COUNTER_OCF                0x0001
#define HCI_COMMAND_CODE_RESET_FAILED_CONTACT_COUNTER_OCF               0x0002
#define HCI_COMMAND_CODE_GET_LINK_QUALITY_OCF                           0x0003
#define HCI_COMMAND_CODE_READ_RSSI_OCF                                  0x0005

   /* HCI Command Code OCF Definitions (Status Parameters - Version     */
   /* 1.2).                                                             */
#define HCI_COMMAND_CODE_READ_AFH_CHANNEL_MAP_OCF                       0x0006
#define HCI_COMMAND_CODE_READ_CLOCK_OCF                                 0x0007

   /* HCI Command Code OCF Definitions (Testing Commands).              */
#define HCI_COMMAND_CODE_READ_LOOPBACK_MODE_OCF                         0x0001
#define HCI_COMMAND_CODE_WRITE_LOOPBACK_MODE_OCF                        0x0002
#define HCI_COMMAND_CODE_ENABLE_DEVICE_UNDER_TEST_MODE_OCF              0x0003

   /* HCI Command Code OCF Definitions (Testing Commands - Version 2.1).*/
#define HCI_COMMAND_CODE_WRITE_SIMPLE_PAIRING_DEBUG_MODE_OCF            0x0004

   /* HCI Command Code OpCode Definitions (NULL OpCode).                */
#define HCI_COMMAND_OPCODE_NULL                                         (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_NULL_OGF, HCI_COMMAND_CODE_NULL_OCF))

   /* HCI Command Code OpCode Definitions (Link Control).               */
#define HCI_COMMAND_OPCODE_INQUIRY                                      (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_INQUIRY_OCF))
#define HCI_COMMAND_OPCODE_INQUIRY_CANCEL                               (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_INQUIRY_CANCEL_OCF))
#define HCI_COMMAND_OPCODE_PERIODIC_INQUIRY_MODE                        (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_PERIODIC_INQUIRY_MODE_OCF))
#define HCI_COMMAND_OPCODE_EXIT_PERIODIC_INQUIRY_MODE                   (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_EXIT_PERIODIC_INQUIRY_MODE_OCF))
#define HCI_COMMAND_OPCODE_CREATE_CONNECTION                            (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_CREATE_CONNECTION_OCF))
#define HCI_COMMAND_OPCODE_DISCONNECT                                   (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_DISCONNECT_OCF))
#define HCI_COMMAND_OPCODE_ADD_SCO_CONNECTION                           (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_ADD_SCO_CONNECTION_OCF))
#define HCI_COMMAND_OPCODE_ACCEPT_CONNECTION_REQUEST                    (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_ACCEPT_CONNECTION_REQUEST_OCF))
#define HCI_COMMAND_OPCODE_REJECT_CONNECTION_REQUEST                    (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_REJECT_CONNECTION_REQUEST_OCF))
#define HCI_COMMAND_OPCODE_LINK_KEY_REQUEST_REPLY                       (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_LINK_KEY_REQUEST_REPLY_OCF))
#define HCI_COMMAND_OPCODE_LINK_KEY_REQUEST_NEGATIVE_REPLY              (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_LINK_KEY_REQUEST_NEGATIVE_REPLY_OCF))
#define HCI_COMMAND_OPCODE_PIN_CODE_REQUEST_REPLY                       (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_PIN_CODE_REQUEST_REPLY_OCF))
#define HCI_COMMAND_OPCODE_PIN_CODE_REQUEST_NEGATIVE_REPLY              (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_PIN_CODE_REQUEST_NEGATIVE_REPLY_OCF))
#define HCI_COMMAND_OPCODE_CHANGE_CONNECTION_PACKET_TYPE                (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_CHANGE_CONNECTION_PACKET_TYPE_OCF))
#define HCI_COMMAND_OPCODE_AUTHENTICATION_REQUESTED                     (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_AUTHENTICATION_REQUESTED_OCF))
#define HCI_COMMAND_OPCODE_SET_CONNECTION_ENCRYPTION                    (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_SET_CONNECTION_ENCRYPTION_OCF))
#define HCI_COMMAND_OPCODE_CHANGE_CONNECTION_LINK_KEY                   (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_CHANGE_CONNECTION_LINK_KEY_OCF))
#define HCI_COMMAND_OPCODE_MASTER_LINK_KEY                              (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_MASTER_LINK_KEY_OCF))
#define HCI_COMMAND_OPCODE_REMOTE_NAME_REQUEST                          (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_REMOTE_NAME_REQUEST_OCF))
#define HCI_COMMAND_OPCODE_READ_REMOTE_SUPPORTED_FEATURES               (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_READ_REMOTE_SUPPORTED_FEATURES_OCF))
#define HCI_COMMAND_OPCODE_READ_REMOTE_VERSION_INFORMATION              (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_READ_REMOTE_VERSION_INFORMATION_OCF))
#define HCI_COMMAND_OPCODE_READ_CLOCK_OFFSET                            (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_READ_CLOCK_OFFSET_OCF))

   /* HCI Command Code OpCode Definitions (Link Control - Version 1.2). */
#define HCI_COMMAND_OPCODE_CREATE_CONNECTION_CANCEL                     (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_CREATE_CONNECTION_CANCEL_OCF))
#define HCI_COMMAND_OPCODE_REMOTE_NAME_REQUEST_CANCEL                   (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_REMOTE_NAME_REQUEST_CANCEL_OCF))
#define HCI_COMMAND_OPCODE_READ_REMOTE_EXTENDED_FEATURES                (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_READ_REMOTE_EXTENDED_FEATURES_OCF))
#define HCI_COMMAND_OPCODE_READ_LMP_HANDLE                              (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_READ_LMP_HANDLE_OCF))
#define HCI_COMMAND_OPCODE_SETUP_SYNCHRONOUS_CONNECTION                 (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_SETUP_SYNCHRONOUS_CONNECTION_OCF))
#define HCI_COMMAND_OPCODE_ACCEPT_SYNCHRONOUS_CONNECTION                (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_ACCEPT_SYNCHRONOUS_CONNECTION_OCF))
#define HCI_COMMAND_OPCODE_REJECT_SYNCHRONOUS_CONNECTION                (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_REJECT_SYNCHRONOUS_CONNECTION_OCF))

   /* HCI Command Code OpCode Definitions (Link Control - Version 2.1). */
#define HCI_COMMAND_OPCODE_IO_CAPABILITY_REQUEST_REPLY                  (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_IO_CAPABILITY_REQUEST_REPLY_OCF))
#define HCI_COMMAND_OPCODE_USER_CONFIRMATION_REQUEST_REPLY              (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_USER_CONFIRMATION_REQUEST_REPLY_OCF))
#define HCI_COMMAND_OPCODE_USER_CONFIRMATION_REQUEST_NEGATIVE_REPLY     (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_USER_CONFIRMATION_REQUEST_NEGATIVE_REPLY_OCF))
#define HCI_COMMAND_OPCODE_USER_PASSKEY_REQUEST_REPLY                   (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_USER_PASSKEY_REQUEST_REPLY_OCF))
#define HCI_COMMAND_OPCODE_USER_PASSKEY_REQUEST_NEGATIVE_REPLY          (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_USER_PASSKEY_REQUEST_NEGATIVE_REPLY_OCF))
#define HCI_COMMAND_OPCODE_REMOTE_OOB_DATA_REQUEST_REPLY                (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_REMOTE_OOB_DATA_REQUEST_REPLY_OCF))
#define HCI_COMMAND_OPCODE_REMOTE_OOB_DATA_REQUEST_NEGATIVE_REPLY       (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_REMOTE_OOB_DATA_REQUEST_NEGATIVE_REPLY_OCF))
#define HCI_COMMAND_OPCODE_IO_CAPABILITY_REQUEST_NEGATIVE_REPLY         (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_CONTROL_OGF, HCI_COMMAND_CODE_IO_CAPABILITY_REQUEST_NEGATIVE_REPLY_OCF))

   /* HCI Command Code OpCode Definitions (Link Policy).                */
#define HCI_COMMAND_OPCODE_HOLD_MODE                                    (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_POLICY_OGF, HCI_COMMAND_CODE_HOLD_MODE_OCF))
#define HCI_COMMAND_OPCODE_SNIFF_MODE                                   (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_POLICY_OGF, HCI_COMMAND_CODE_SNIFF_MODE_OCF))
#define HCI_COMMAND_OPCODE_EXIT_SNIFF_MODE                              (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_POLICY_OGF, HCI_COMMAND_CODE_EXIT_SNIFF_MODE_OCF))
#define HCI_COMMAND_OPCODE_PARK_MODE                                    (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_POLICY_OGF, HCI_COMMAND_CODE_PARK_MODE_OCF))
#define HCI_COMMAND_OPCODE_EXIT_PARK_MODE                               (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_POLICY_OGF, HCI_COMMAND_CODE_EXIT_PARK_MODE_OCF))
#define HCI_COMMAND_OPCODE_QOS_SETUP                                    (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_POLICY_OGF, HCI_COMMAND_CODE_QOS_SETUP_OCF))
#define HCI_COMMAND_OPCODE_ROLE_DISCOVERY                               (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_POLICY_OGF, HCI_COMMAND_CODE_ROLE_DISCOVERY_OCF))
#define HCI_COMMAND_OPCODE_SWITCH_ROLE                                  (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_POLICY_OGF, HCI_COMMAND_CODE_SWITCH_ROLE_OCF))
#define HCI_COMMAND_OPCODE_READ_LINK_POLICY_SETTINGS                    (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_POLICY_OGF, HCI_COMMAND_CODE_READ_LINK_POLICY_SETTINGS_OCF))
#define HCI_COMMAND_OPCODE_WRITE_LINK_POLICY_SETTINGS                   (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_POLICY_OGF, HCI_COMMAND_CODE_WRITE_LINK_POLICY_SETTINGS_OCF))

   /* HCI Command Code OpCode Definitions (Link Policy - Version 1.2).  */
#define HCI_COMMAND_OPCODE_READ_DEFAULT_LINK_POLICY_SETTINGS            (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_POLICY_OGF, HCI_COMMAND_CODE_READ_DEFAULT_LINK_POLICY_SETTINGS_OCF))
#define HCI_COMMAND_OPCODE_WRITE_DEFAULT_LINK_POLICY_SETTINGS           (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_POLICY_OGF, HCI_COMMAND_CODE_WRITE_DEFAULT_LINK_POLICY_SETTINGS_OCF))
#define HCI_COMMAND_OPCODE_FLOW_SPECIFICATION                           (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_POLICY_OGF, HCI_COMMAND_CODE_FLOW_SPECIFICATION_OCF))

   /* HCI Command Code OpCode Definitions (Link Policy - Version 2.1).  */
#define HCI_COMMAND_OPCODE_SNIFF_SUBRATING                              (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_LINK_POLICY_OGF, HCI_COMMAND_CODE_SNIFF_SUBRATING_OCF))

   /* HCI Command Code OpCode Definitions (Host Control and Baseband).  */
#define HCI_COMMAND_OPCODE_SET_EVENT_MASK                               (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_SET_EVENT_MASK_OCF))
#define HCI_COMMAND_OPCODE_RESET                                        (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_RESET_OCF))
#define HCI_COMMAND_OPCODE_SET_EVENT_FILTER                             (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_SET_EVENT_FILTER_OCF))
#define HCI_COMMAND_OPCODE_FLUSH                                        (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_FLUSH_OCF))
#define HCI_COMMAND_OPCODE_READ_PIN_TYPE                                (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_PIN_TYPE_OCF))
#define HCI_COMMAND_OPCODE_WRITE_PIN_TYPE                               (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_PIN_TYPE_OCF))
#define HCI_COMMAND_OPCODE_CREATE_NEW_UNIT_KEY                          (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_CREATE_NEW_UNIT_KEY_OCF))
#define HCI_COMMAND_OPCODE_READ_STORED_LINK_KEY                         (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_STORED_LINK_KEY_OCF))
#define HCI_COMMAND_OPCODE_WRITE_STORED_LINK_KEY                        (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_STORED_LINK_KEY_OCF))
#define HCI_COMMAND_OPCODE_DELETE_STORED_LINK_KEY                       (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_DELETE_STORED_LINK_KEY_OCF))
#define HCI_COMMAND_OPCODE_CHANGE_LOCAL_NAME                            (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_CHANGE_LOCAL_NAME_OCF))
#define HCI_COMMAND_OPCODE_WRITE_LOCAL_NAME                             (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_LOCAL_NAME_OCF))
#define HCI_COMMAND_OPCODE_READ_LOCAL_NAME                              (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_LOCAL_NAME_OCF))
#define HCI_COMMAND_OPCODE_READ_CONNECTION_ACCEPT_TIMEOUT               (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_CONNECTION_ACCEPT_TIMEOUT_OCF))
#define HCI_COMMAND_OPCODE_WRITE_CONNECTION_ACCEPT_TIMEOUT              (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_CONNECTION_ACCEPT_TIMEOUT_OCF))
#define HCI_COMMAND_OPCODE_READ_PAGE_TIMEOUT                            (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_PAGE_TIMEOUT_OCF))
#define HCI_COMMAND_OPCODE_WRITE_PAGE_TIMEOUT                           (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_PAGE_TIMEOUT_OCF))
#define HCI_COMMAND_OPCODE_READ_SCAN_ENABLE                             (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_SCAN_ENABLE_OCF))
#define HCI_COMMAND_OPCODE_WRITE_SCAN_ENABLE                            (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_SCAN_ENABLE_OCF))
#define HCI_COMMAND_OPCODE_READ_PAGE_SCAN_ACTIVITY                      (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_PAGE_SCAN_ACTIVITY_OCF))
#define HCI_COMMAND_OPCODE_WRITE_PAGE_SCAN_ACTIVITY                     (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_PAGE_SCAN_ACTIVITY_OCF))
#define HCI_COMMAND_OPCODE_READ_INQUIRY_SCAN_ACTIVITY                   (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_INQUIRY_SCAN_ACTIVITY_OCF))
#define HCI_COMMAND_OPCODE_WRITE_INQUIRY_SCAN_ACTIVITY                  (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_INQUIRY_SCAN_ACTIVITY_OCF))
#define HCI_COMMAND_OPCODE_READ_AUTHENTICATION_ENABLE                   (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_AUTHENTICATION_ENABLE_OCF))
#define HCI_COMMAND_OPCODE_WRITE_AUTHENTICATION_ENABLE                  (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_AUTHENTICATION_ENABLE_OCF))
#define HCI_COMMAND_OPCODE_READ_ENCRYPTION_MODE                         (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_ENCRYPTION_MODE_OCF))
#define HCI_COMMAND_OPCODE_WRITE_ENCRYPTION_MODE                        (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_ENCRYPTION_MODE_OCF))
#define HCI_COMMAND_OPCODE_READ_CLASS_OF_DEVICE                         (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_CLASS_OF_DEVICE_OCF))
#define HCI_COMMAND_OPCODE_WRITE_CLASS_OF_DEVICE                        (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_CLASS_OF_DEVICE_OCF))
#define HCI_COMMAND_OPCODE_READ_VOICE_SETTING                           (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_VOICE_SETTING_OCF))
#define HCI_COMMAND_OPCODE_WRITE_VOICE_SETTING                          (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_VOICE_SETTING_OCF))
#define HCI_COMMAND_OPCODE_READ_AUTOMATIC_FLUSH_TIMEOUT                 (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_AUTOMATIC_FLUSH_TIMEOUT_OCF))
#define HCI_COMMAND_OPCODE_WRITE_AUTOMATIC_FLUSH_TIMEOUT                (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_AUTOMATIC_FLUSH_TIMEOUT_OCF))
#define HCI_COMMAND_OPCODE_READ_NUM_BROADCAST_RETRANSMISSIONS           (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_NUM_BROADCAST_RETRANSMISSIONS_OCF))
#define HCI_COMMAND_OPCODE_WRITE_NUM_BROADCAST_RETRANSMISSIONS          (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_NUM_BROADCAST_RETRANSMISSIONS_OCF))
#define HCI_COMMAND_OPCODE_READ_HOLD_MODE_ACTIVITY                      (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_HOLD_MODE_ACTIVITY_OCF))
#define HCI_COMMAND_OPCODE_WRITE_HOLD_MODE_ACTIVITY                     (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_HOLD_MODE_ACTIVITY_OCF))
#define HCI_COMMAND_OPCODE_READ_TRANSMIT_POWER_LEVEL                    (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_TRANSMIT_POWER_LEVEL_OCF))
#define HCI_COMMAND_OPCODE_READ_SCO_FLOW_CONTROL_ENABLE                 (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_SCO_FLOW_CONTROL_ENABLE_OCF))
#define HCI_COMMAND_OPCODE_READ_SYNCHRONOUS_FLOW_CONTROL_ENABLE         (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_SYNCHRONOUS_FLOW_CONTROL_ENABLE_OCF))
#define HCI_COMMAND_OPCODE_WRITE_SCO_FLOW_CONTROL_ENABLE                (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_SCO_FLOW_CONTROL_ENABLE_OCF))
#define HCI_COMMAND_OPCODE_WRITE_SYNCHRONOUS_FLOW_CONTROL_ENABLE        (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_SYNCHRONOUS_FLOW_CONTROL_ENABLE_OCF))
#define HCI_COMMAND_OPCODE_SET_HOST_CONTROLLER_TO_HOST_FLOW_CONTROL     (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_SET_HOST_CONTROLLER_TO_HOST_FLOW_CONTROL_OCF))
#define HCI_COMMAND_OPCODE_HOST_BUFFER_SIZE                             (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_HOST_BUFFER_SIZE_OCF))
#define HCI_COMMAND_OPCODE_HOST_NUMBER_OF_COMPLETED_PACKETS             (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_HOST_NUMBER_OF_COMPLETED_PACKETS_OCF))
#define HCI_COMMAND_OPCODE_READ_LINK_SUPERVISION_TIMEOUT                (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_LINK_SUPERVISION_TIMEOUT_OCF))
#define HCI_COMMAND_OPCODE_WRITE_LINK_SUPERVISION_TIMEOUT               (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_LINK_SUPERVISION_TIMEOUT_OCF))
#define HCI_COMMAND_OPCODE_READ_NUMBER_OF_SUPPORTED_IAC                 (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_NUMBER_OF_SUPPORTED_IAC_OCF))
#define HCI_COMMAND_OPCODE_READ_CURRENT_IAC_LAP                         (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_CURRENT_IAC_LAP_OCF))
#define HCI_COMMAND_OPCODE_WRITE_CURRENT_IAC_LAP                        (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_CURRENT_IAC_LAP_OCF))
#define HCI_COMMAND_OPCODE_READ_PAGE_SCAN_PERIOD_MODE                   (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_PAGE_SCAN_PERIOD_MODE_OCF))
#define HCI_COMMAND_OPCODE_WRITE_PAGE_SCAN_PERIOD_MODE                  (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_PAGE_SCAN_PERIOD_MODE_OCF))
#define HCI_COMMAND_OPCODE_READ_PAGE_SCAN_MODE                          (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_PAGE_SCAN_MODE_OCF))
#define HCI_COMMAND_OPCODE_WRITE_PAGE_SCAN_MODE                         (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_PAGE_SCAN_MODE_OCF))

   /* HCI Command Code OpCode Definitions (Host Control and Baseband -  */
   /* Version 1.2).                                                     */
#define HCI_COMMAND_OPCODE_SET_AFH_HOST_CHANNEL_CLASSIFICATION          (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_SET_AFH_HOST_CHANNEL_CLASSIFICATION_OCF))
#define HCI_COMMAND_OPCODE_READ_INQUIRY_SCAN_TYPE                       (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_INQUIRY_SCAN_TYPE_OCF))
#define HCI_COMMAND_OPCODE_WRITE_INQUIRY_SCAN_TYPE                      (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_INQUIRY_SCAN_TYPE_OCF))
#define HCI_COMMAND_OPCODE_READ_INQUIRY_MODE                            (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_INQUIRY_MODE_OCF))
#define HCI_COMMAND_OPCODE_WRITE_INQUIRY_MODE                           (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_INQUIRY_MODE_OCF))
#define HCI_COMMAND_OPCODE_READ_PAGE_SCAN_TYPE                          (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_PAGE_SCAN_TYPE_OCF))
#define HCI_COMMAND_OPCODE_WRITE_PAGE_SCAN_TYPE                         (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_PAGE_SCAN_TYPE_OCF))
#define HCI_COMMAND_OPCODE_READ_AFH_CHANNEL_ASSESSMENT_MODE             (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_AFH_CHANNEL_ASSESSMENT_MODE_OCF))
#define HCI_COMMAND_OPCODE_WRITE_AFH_CHANNEL_ASSESSMENT_MODE            (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_AFH_CHANNEL_ASSESSMENT_MODE_OCF))

   /* HCI Command Code OpCode Definitions (Host Control and Baseband -  */
   /* Version 2.1).                                                     */
#define HCI_COMMAND_OPCODE_READ_EXTENDED_INQUIRY_RESPONSE               (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_EXTENDED_INQUIRY_RESPONSE_OCF))
#define HCI_COMMAND_OPCODE_WRITE_EXTENDED_INQUIRY_RESPONSE              (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_EXTENDED_INQUIRY_RESPONSE_OCF))
#define HCI_COMMAND_OPCODE_REFRESH_ENCRYPTION_KEY                       (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_REFRESH_ENCRYPTION_KEY_OCF))
#define HCI_COMMAND_OPCODE_READ_SIMPLE_PAIRING_MODE                     (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_SIMPLE_PAIRING_MODE_OCF))
#define HCI_COMMAND_OPCODE_WRITE_SIMPLE_PAIRING_MODE                    (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_SIMPLE_PAIRING_MODE_OCF))
#define HCI_COMMAND_OPCODE_READ_LOCAL_OOB_DATA                          (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_LOCAL_OOB_DATA_OCF))
#define HCI_COMMAND_OPCODE_READ_INQUIRY_RESPONSE_TRANSMIT_POWER_LEVEL   (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_INQUIRY_RESPONSE_TRANSMIT_POWER_LEVEL_OCF))
#define HCI_COMMAND_OPCODE_WRITE_INQUIRY_TRANSMIT_POWER_LEVEL           (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_INQUIRY_TRANSMIT_POWER_LEVEL_OCF))
#define HCI_COMMAND_OPCODE_READ_DEFAULT_ERRONEOUS_DATA_REPORTING        (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_READ_DEFAULT_ERRONEOUS_DATA_REPORTING_OCF))
#define HCI_COMMAND_OPCODE_WRITE_DEFAULT_ERRONEOUS_DATA_REPORTING       (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_WRITE_DEFAULT_ERRONEOUS_DATA_REPORTING_OCF))
#define HCI_COMMAND_OPCODE_ENHANCED_FLUSH                               (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_ENHANCED_FLUSH_OCF))
#define HCI_COMMAND_OPCODE_SEND_KEYPRESS_NOTIFICATION                   (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_CONTROL_BASEBAND_OGF, HCI_COMMAND_CODE_SEND_KEYPRESS_NOTIFICATION_OCF))

   /* HCI Command Code OpCode Definitions (Informational Parameters).   */
#define HCI_COMMAND_OPCODE_READ_LOCAL_VERSION_INFORMATION               (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_INFORMATIONAL_PARAMETERS_OGF, HCI_COMMAND_CODE_READ_LOCAL_VERSION_INFORMATION_OCF))
#define HCI_COMMAND_OPCODE_READ_LOCAL_SUPPORTED_FEATURES                (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_INFORMATIONAL_PARAMETERS_OGF, HCI_COMMAND_CODE_READ_LOCAL_SUPPORTED_FEATURES_OCF))
#define HCI_COMMAND_OPCODE_READ_BUFFER_SIZE                             (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_INFORMATIONAL_PARAMETERS_OGF, HCI_COMMAND_CODE_READ_BUFFER_SIZE_OCF))
#define HCI_COMMAND_OPCODE_READ_COUNTRY_CODE                            (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_INFORMATIONAL_PARAMETERS_OGF, HCI_COMMAND_CODE_READ_COUNTRY_CODE_OCF))
#define HCI_COMMAND_OPCODE_READ_BD_ADDR                                 (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_INFORMATIONAL_PARAMETERS_OGF, HCI_COMMAND_CODE_READ_BD_ADDR_OCF))

   /* HCI Command Code OpCode Definitions (Informational Parameters -   */
   /* Version 1.2).                                                     */
#define HCI_COMMAND_OPCODE_READ_LOCAL_SUPPORTED_COMMANDS                (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_INFORMATIONAL_PARAMETERS_OGF, HCI_COMMAND_CODE_READ_LOCAL_SUPPORTED_COMMANDS_OCF))
#define HCI_COMMAND_OPCODE_READ_LOCAL_EXTENDED_FEATURES                 (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_INFORMATIONAL_PARAMETERS_OGF, HCI_COMMAND_CODE_READ_LOCAL_EXTENDED_FEATURES_OCF))

   /* HCI Command Code OpCode Definitions (Status Parameters).          */
#define HCI_COMMAND_OPCODE_READ_FAILED_CONTACT_COUNTER                  (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_STATUS_PARAMETERS_OGF, HCI_COMMAND_CODE_READ_FAILED_CONTACT_COUNTER_OCF))
#define HCI_COMMAND_OPCODE_RESET_FAILED_CONTACT_COUNTER                 (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_STATUS_PARAMETERS_OGF, HCI_COMMAND_CODE_RESET_FAILED_CONTACT_COUNTER_OCF))
#define HCI_COMMAND_OPCODE_GET_LINK_QUALITY                             (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_STATUS_PARAMETERS_OGF, HCI_COMMAND_CODE_GET_LINK_QUALITY_OCF))
#define HCI_COMMAND_OPCODE_READ_RSSI                                    (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_STATUS_PARAMETERS_OGF, HCI_COMMAND_CODE_READ_RSSI_OCF))

   /* HCI Command Code OpCode Definitions (Status Parameters - Version  */
   /* 1.2).                                                             */
#define HCI_COMMAND_OPCODE_READ_AFH_CHANNEL_MAP                         (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_STATUS_PARAMETERS_OGF, HCI_COMMAND_CODE_READ_AFH_CHANNEL_MAP_OCF))
#define HCI_COMMAND_OPCODE_READ_CLOCK                                   (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_STATUS_PARAMETERS_OGF, HCI_COMMAND_CODE_READ_CLOCK_OCF))

   /* HCI Command Code OpCode Definitions (Testing Commands).           */
#define HCI_COMMAND_OPCODE_READ_LOOPBACK_MODE                           (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_TESTING_COMMANDS_OGF, HCI_COMMAND_CODE_READ_LOOPBACK_MODE_OCF))
#define HCI_COMMAND_OPCODE_WRITE_LOOPBACK_MODE                          (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_TESTING_COMMANDS_OGF, HCI_COMMAND_CODE_WRITE_LOOPBACK_MODE_OCF))
#define HCI_COMMAND_OPCODE_ENABLE_DEVICE_UNDER_TEST_MODE                (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_TESTING_COMMANDS_OGF, HCI_COMMAND_CODE_ENABLE_DEVICE_UNDER_TEST_MODE_OCF))

   /* HCI Command Code OpCode Definitions (Testing Commands - Version   */
   /* 2.1).                                                             */
#define HCI_COMMAND_OPCODE_WRITE_SIMPLE_PAIRING_DEBUG_MODE              (HCI_MAKE_COMMAND_OPCODE(HCI_COMMAND_CODE_TESTING_COMMANDS_OGF, HCI_COMMAND_CODE_WRITE_SIMPLE_PAIRING_DEBUG_MODE_OCF))

   /* HCI Event Declarations/Types/Constants.                           */
#define HCI_EVENT_CODE_INQUIRY_COMPLETE                                 0x01
#define HCI_EVENT_CODE_INQUIRY_RESULT                                   0x02
#define HCI_EVENT_CODE_CONNECTION_COMPLETE                              0x03
#define HCI_EVENT_CODE_CONNECTION_REQUEST                               0x04
#define HCI_EVENT_CODE_DISCONNECTION_COMPLETE                           0x05
#define HCI_EVENT_CODE_AUTHENTICATION_COMPLETE                          0x06
#define HCI_EVENT_CODE_REMOTE_NAME_REQUEST_COMPLETE                     0x07
#define HCI_EVENT_CODE_ENCRYPTION_CHANGE_EVENT                          0x08
#define HCI_EVENT_CODE_CHANGE_CONNECTION_LINK_KEY_COMPLETE              0x09
#define HCI_EVENT_CODE_MASTER_LINK_KEY_COMPLETE                         0x0A
#define HCI_EVENT_CODE_READ_REMOTE_SUPPORTED_FEATURES_COMPLETE          0x0B
#define HCI_EVENT_CODE_READ_REMOTE_VERSION_INFORMATION_COMPLETE         0x0C
#define HCI_EVENT_CODE_QOS_SETUP_COMPLETE                               0x0D
#define HCI_EVENT_CODE_COMMAND_COMPLETE                                 0x0E
#define HCI_EVENT_CODE_COMMAND_STATUS                                   0x0F
#define HCI_EVENT_CODE_HARDWARE_ERROR                                   0x10
#define HCI_EVENT_CODE_FLUSH_OCCURRED                                   0x11
#define HCI_EVENT_CODE_ROLE_CHANGE                                      0x12
#define HCI_EVENT_CODE_NUMBER_OF_COMPLETED_PACKETS                      0x13
#define HCI_EVENT_CODE_MODE_CHANGE                                      0x14
#define HCI_EVENT_CODE_RETURN_LINK_KEYS                                 0x15
#define HCI_EVENT_CODE_PIN_CODE_REQUEST                                 0x16
#define HCI_EVENT_CODE_LINK_KEY_REQUEST                                 0x17
#define HCI_EVENT_CODE_LINK_KEY_NOTIFICATION                            0x18
#define HCI_EVENT_CODE_LOOPBACK_COMMAND                                 0x19
#define HCI_EVENT_CODE_DATA_BUFFER_OVERFLOW                             0x1A
#define HCI_EVENT_CODE_MAX_SLOTS_CHANGE_EVENT                           0x1B
#define HCI_EVENT_CODE_READ_CLOCK_OFFSET_COMPLETE                       0x1C
#define HCI_EVENT_CODE_CONNECTION_PACKET_TYPE_CHANGED                   0x1D
#define HCI_EVENT_CODE_QOS_VIOLATION                                    0x1E
#define HCI_EVENT_CODE_PAGE_SCAN_MODE_CHANGE                            0x1F
#define HCI_EVENT_CODE_PAGE_SCAN_REPETITION_MODE_CHANGE                 0x20

   /* The following block of HCI Event Declarations/Type/Constants are  */
   /* for Version 1.2.                                                  */
#define HCI_EVENT_CODE_FLOW_SPECIFICATION_COMPLETE                      0x21
#define HCI_EVENT_CODE_INQUIRY_RESULT_WITH_RSSI                         0x22
#define HCI_EVENT_CODE_READ_REMOTE_EXTENDED_FEATURES_COMPLETE           0x23
#define HCI_EVENT_CODE_SYNCHRONOUS_CONNECTION_COMPLETE                  0x2C
#define HCI_EVENT_CODE_SYNCHRONOUS_CONNECTION_CHANGED                   0x2D

   /* The following block of HCI Event Declarations/Type/Constants are  */
   /* for Version 2.1.                                                  */
#define HCI_EVENT_CODE_SNIFF_SUBRATING                                  0x2E
#define HCI_EVENT_CODE_EXTENDED_INQUIRY_RESULT                          0x2F
#define HCI_EVENT_CODE_ENCRYPTION_KEY_REFRESH_COMPLETE                  0x30
#define HCI_EVENT_CODE_IO_CAPABILITY_REQUEST                            0x31
#define HCI_EVENT_CODE_IO_CAPABILITY_RESPONSE                           0x32
#define HCI_EVENT_CODE_USER_CONFIRMATION_REQUEST                        0x33
#define HCI_EVENT_CODE_USER_PASSKEY_REQUEST                             0x34
#define HCI_EVENT_CODE_REMOTE_OOB_DATA_REQUEST                          0x35
#define HCI_EVENT_CODE_SIMPLE_PAIRING_COMPLETE                          0x36
#define HCI_EVENT_CODE_LINK_SUPERVISION_TIMEOUT_CHANGED                 0x38
#define HCI_EVENT_CODE_ENHANCED_FLUSH_COMPLETE                          0x39
#define HCI_EVENT_CODE_USER_PASSKEY_NOTIFICATION                        0x3B
#define HCI_EVENT_CODE_KEYPRESS_NOTIFICATION                            0x3C
#define HCI_EVENT_CODE_REMOTE_HOST_SUPPORTED_FEATURES_NOTIFICATION      0x3D

#define HCI_EVENT_CODE_BLUETOOTH_LOGO_TESTING                           0xFE
#define HCI_EVENT_CODE_VENDOR_SPECIFIC_DEBUG                            0xFF

   /* HCI Error Code Definitions/Constants.                             */
#define HCI_ERROR_CODE_NO_ERROR                                         0x00
#define HCI_ERROR_CODE_UNKNOWN_HCI_COMMAND                              0x01
#define HCI_ERROR_CODE_NO_CONNECTION                                    0x02
#define HCI_ERROR_CODE_HARDWARE_FAILURE                                 0x03
#define HCI_ERROR_CODE_PAGE_TIMEOUT                                     0x04
#define HCI_ERROR_CODE_AUTHENTICATION_FAILURE                           0x05
#define HCI_ERROR_CODE_KEY_MISSING                                      0x06
#define HCI_ERROR_CODE_MEMORY_FULL                                      0x07
#define HCI_ERROR_CODE_CONNECTION_TIMEOUT                               0x08
#define HCI_ERROR_CODE_MAX_NUMBER_OF_CONNECTIONS                        0x09
#define HCI_ERROR_CODE_MAX_NUMBER_OF_SCO_CONNECTIONS_TO_A_DEVICE        0x0A
#define HCI_ERROR_CODE_ACL_CONNECTION_ALREADY_EXISTS                    0x0B
#define HCI_ERROR_CODE_COMMAND_DISALLOWED                               0x0C
#define HCI_ERROR_CODE_HOST_REJECTED_DUE_TO_LIMITED_RESOURCES           0x0D
#define HCI_ERROR_CODE_HOST_REJECTED_DUE_TO_SECURITY_REASONS            0x0E
#define HCI_ERROR_CODE_HOST_REJECTED_DUE_TO_REMOTE_DEVICE_IS_PERSONAL   0x0F
#define HCI_ERROR_CODE_HOST_TIMEOUT                                     0x10
#define HCI_ERROR_CODE_UNSUPPORTED_FEATURE_OR_PARAMETER_VALUE           0x11
#define HCI_ERROR_CODE_INVALID_HCI_COMMAND_PARAMETERS                   0x12
#define HCI_ERROR_CODE_OTHER_END_TERMINATED_CONNECTION_USER_ENDED       0x13
#define HCI_ERROR_CODE_OTHER_END_TERMINATED_CONNECTION_LOW_RESOURCES    0x14
#define HCI_ERROR_CODE_OTHER_END_TERMINATED_CONNECTION_ABOUT_TO_PWR_OFF 0x15
#define HCI_ERROR_CODE_CONNECTION_TERMINATED_BY_LOCAL_HOST              0x16
#define HCI_ERROR_CODE_REPEATED_ATTEMPTS                                0x17
#define HCI_ERROR_CODE_PAIRING_NOT_ALLOWED                              0x18
#define HCI_ERROR_CODE_UNKNOWN_LMP_PDU                                  0x19
#define HCI_ERROR_CODE_UNSUPPORTED_REMOTE_FEATURE                       0x1A
#define HCI_ERROR_CODE_SCO_OFFSET_REJECTED                              0x1B
#define HCI_ERROR_CODE_SCO_INTERVAL_REJECTED                            0x1C
#define HCI_ERROR_CODE_SCO_AIR_MODE_REJECTED                            0x1D
#define HCI_ERROR_CODE_INVALID_LMP_PARAMETERS                           0x1E
#define HCI_ERROR_CODE_UNSPECIFIED_ERROR                                0x1F
#define HCI_ERROR_CODE_UNSUPPORTED_LMP_PARAMETER_VALUE                  0x20
#define HCI_ERROR_CODE_ROLE_CHANGE_NOT_ALLOWED                          0x21
#define HCI_ERROR_CODE_LMP_RESPONSE_TIMEOUT                             0x22
#define HCI_ERROR_CODE_LMP_ERROR_TRANSACTION_COLLISION                  0x23

   /* HCI Error Code Definitions/Constants (Version 1.1).               */
#define HCI_ERROR_CODE_LMP_PDU_NOT_ALLOWED                              0x24
#define HCI_ERROR_CODE_ENCRYPTION_MODE_NOT_ACCEPTABLE                   0x25
#define HCI_ERROR_CODE_UNIT_KEY_USED                                    0x26
#define HCI_ERROR_CODE_QOS_NOT_SUPPORTED                                0x27
#define HCI_ERROR_CODE_INSTANT_PASSED                                   0x28
#define HCI_ERROR_CODE_PAIRING_WITH_UNIT_KEY_NOT_SUPPORTED              0x29

   /* HCI Error Code Definitions/Constants (Version 1.2).               */
#define HCI_ERROR_CODE_SUCCESS                                          0x00
#define HCI_ERROR_CODE_UNKNOWN_CONNECTION_IDENTIFIER                    0x02
#define HCI_ERROR_CODE_PIN_MISSING                                      0x06
#define HCI_ERROR_CODE_MEMORY_CAPACITY_EXCEEDED                         0x07
#define HCI_ERROR_CODE_CONNECTION_LIMIT_EXCEEDED                        0x09
#define HCI_ERROR_CODE_SYNCHRONOUS_CONNECTION_LIMIT_TO_A_DEVICE_EXCEEDED 0x0A
#define HCI_ERROR_CODE_CONNECTION_REJECTED_DUE_TO_LIMITED_RESOURCES     0x0D
#define HCI_ERROR_CODE_CONNECTION_REJECTED_DUE_TO_SECURITY_REASONS      0x0E
#define HCI_ERROR_CODE_CONNECTION_REJECTED_DUE_TO_UNACCEPTABLE_BD_ADDR  0x0F
#define HCI_ERROR_CODE_CONNECTION_ACCEPT_TIMEOUT_EXCEEDED               0x10
#define HCI_ERROR_CODE_REMOTE_USER_TERMINATED_CONNECTION                0x13
#define HCI_ERROR_CODE_REMOTE_DEVICE_TERMINATED_CONNECTION_LOW_RESOURCES  0x14
#define HCI_ERROR_CODE_REMOTE_DEVICE_TERMINATED_CONNECTION_DUE_TO_PWR_OFF 0x15
#define HCI_ERROR_CODE_LINK_KEY_CANNOT_BE_CHANGED                       0x26
#define HCI_ERROR_CODE_REQUESTED_QOS_NOT_SUPPORTED                      0x27
#define HCI_ERROR_CODE_DIFFERENT_TRANSACTION_COLLISION                  0x2A
#define HCI_ERROR_CODE_QOS_UNACCEPTABLE_PARAMETER                       0x2C
#define HCI_ERROR_CODE_QOS_REJECTED                                     0x2D
#define HCI_ERROR_CODE_CHANNEL_CLASSIFICATION_NOT_SUPPORTED             0x2E
#define HCI_ERROR_CODE_INSUFFICIENT_SECURITY                            0x2F
#define HCI_ERROR_CODE_PARAMETER_OUT_OF_MANDATORY_RANGE                 0x30
#define HCI_ERROR_CODE_ROLE_SWITCH_PENDING                              0x32
#define HCI_ERROR_CODE_RESERVED_SLOT_VIOLATION                          0x34
#define HCI_ERROR_CODE_ROLE_SWITCH_FAILED                               0x35

   /* HCI Error Code Definitions/Constants (Version 2.1).               */
#define HCI_ERROR_CODE_EXTENDED_INQUIRY_RESPONSE_TOO_LARGE                0x36
#define HCI_ERROR_CODE_SECURE_SIMPLE_PAIRING_NOT_SUPPORTED_BY_HOST        0x37
#define HCI_ERROR_CODE_HOST_BUSY_PAIRING                                  0x38

   /* HCI Command Definitions/Constants.                                */

   /* The following type declaration represents the structure of the    */
   /* Header of an HCI Command Packet.  This Header Information is      */
   /* contained in Every Defined HCI Command Packet.  This structure    */
   /* forms the basis of additional defined HCI Command Packets.  Since */
   /* this structure is present at the begining of Every Defined HCI    */
   /* Command Packet, this structure will be the first element of Every */
   /* Defined HCI Command Packet in this file.                          */
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Command_Header_t
{
   NonAlignedWord_t Command_OpCode;
   NonAlignedByte_t Parameter_Total_Length;
} __PACKED_STRUCT_END__ HCI_Command_Header_t;

#define HCI_COMMAND_HEADER_SIZE                         (sizeof(HCI_Command_Header_t))

#define HCI_COMMAND_MAX_SIZE                            (sizeof(HCI_Command_Header_t) + (sizeof(Byte_t)*256))

   /* HCI Command Definitions (Link Control).                           */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Inquiry_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   LAP_t                LAP;
   Byte_t               Inquiry_Length;
   Byte_t               Num_Responses;
} __PACKED_STRUCT_END__ HCI_Inquiry_Command_t;

#define HCI_INQUIRY_COMMAND_SIZE                        (sizeof(HCI_Inquiry_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Inquiry_Cancel_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Inquiry_Cancel_Command_t;

#define HCI_INQUIRY_CANCEL_COMMAND_SIZE                 (sizeof(HCI_Inquiry_Cancel_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Periodic_Inquiry_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Max_Period_Length;
   NonAlignedWord_t     Min_Period_Length;
   LAP_t                LAP;
   Byte_t               Inquiry_Length;
   Byte_t               Num_Responses;
} __PACKED_STRUCT_END__ HCI_Periodic_Inquiry_Mode_Command_t;

#define HCI_PERIODIC_INQUIRY_MODE_COMMAND_SIZE          (sizeof(HCI_Periodic_Inquiry_Mode_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Exit_Periodic_Inquiry_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Exit_Periodic_Inquiry_Mode_Command_t;

#define HCI_EXIT_PERIODIC_INQUIRY_MODE_COMMAND_SIZE     (sizeof(HCI_Exit_Periodic_Inquiry_Mode_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Create_Connection_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
   NonAlignedWord_t     Packet_Type;
   Byte_t               Page_Scan_Repetition_Mode;
   Byte_t               Page_Scan_Mode;
   NonAlignedWord_t     Clock_Offset;
   Byte_t               Allow_Role_Switch;
} __PACKED_STRUCT_END__ HCI_Create_Connection_Command_t;

#define HCI_CREATE_CONNECTION_COMMAND_SIZE              (sizeof(HCI_Create_Connection_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Disconnect_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
   Byte_t               Reason;
} __PACKED_STRUCT_END__ HCI_Disconnect_Command_t;

#define HCI_DISCONNECT_COMMAND_SIZE                     (sizeof(HCI_Disconnect_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Add_SCO_Connection_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
   NonAlignedWord_t     Packet_Type;
} __PACKED_STRUCT_END__ HCI_Add_SCO_Connection_Command_t;

#define HCI_ADD_SCO_CONNECTION_COMMAND_SIZE             (sizeof(HCI_Add_SCO_Connection_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Accept_Connection_Request_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
   Byte_t               Role;
} __PACKED_STRUCT_END__ HCI_Accept_Connection_Request_Command_t;

#define HCI_ACCEPT_CONNECTION_REQUEST_COMMAND_SIZE      (sizeof(HCI_Accept_Connection_Request_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Reject_Connection_Request_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
   Byte_t               Reason;
} __PACKED_STRUCT_END__ HCI_Reject_Connection_Request_Command_t;

#define HCI_REJECT_CONNECTION_REQUEST_COMMAND_SIZE      (sizeof(HCI_Reject_Connection_Request_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Link_Key_Request_Reply_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
   Link_Key_t           Link_Key;
} __PACKED_STRUCT_END__ HCI_Link_Key_Request_Reply_Command_t;

#define HCI_LINK_KEY_REQUEST_REPLY_COMMAND_SIZE         (sizeof(HCI_Link_Key_Request_Reply_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Link_Key_Request_Negative_Reply_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
} __PACKED_STRUCT_END__ HCI_Link_Key_Request_Negative_Reply_Command_t;

#define HCI_LINK_KEY_REQUEST_NEGATIVE_REPLY_COMMAND_SIZE (sizeof(HCI_Link_Key_Request_Negative_Reply_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_PIN_Code_Request_Reply_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
   Byte_t               PIN_Code_Length;
   PIN_Code_t           PIN_Code;
} __PACKED_STRUCT_END__ HCI_PIN_Code_Request_Reply_Command_t;

#define HCI_PIN_CODE_REQUEST_REPLY_COMMAND_SIZE         (sizeof(HCI_PIN_Code_Request_Reply_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_PIN_Code_Request_Negative_Reply_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
} __PACKED_STRUCT_END__ HCI_PIN_Code_Request_Negative_Reply_Command_t;

#define HCI_PIN_CODE_REQUEST_NEGATIVE_REPLY_COMMAND_SIZE (sizeof(HCI_PIN_Code_Request_Negative_Reply_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Change_Connection_Packet_Type_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
   NonAlignedWord_t     Packet_Type;
} __PACKED_STRUCT_END__ HCI_Change_Connection_Packet_Type_Command_t;

#define HCI_CHANGE_CONNECTION_PACKET_TYPE_COMMAND_SIZE  (sizeof(HCI_Change_Connection_Packet_Type_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Authentication_Requested_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Authentication_Requested_Command_t;

#define HCI_AUTHENTICATION_REQUESTED_COMMAND_SIZE       (sizeof(HCI_Authentication_Requested_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Set_Connection_Encryption_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
   Byte_t               Encryption_Enable;
} __PACKED_STRUCT_END__ HCI_Set_Connection_Encryption_Command_t;

#define HCI_SET_CONNECTION_ENCRYPTION_COMMAND_SIZE      (sizeof(HCI_Set_Connection_Encryption_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Change_Connection_Link_Key_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Change_Connection_Link_Key_Command_t;

#define HCI_CHANGE_CONNECTION_LINK_KEY_COMMAND_SIZE     (sizeof(HCI_Change_Connection_Link_Key_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Master_Link_Key_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Key_Flag;
} __PACKED_STRUCT_END__ HCI_Master_Link_Key_Command_t;

#define HCI_MASTER_LINK_KEY_COMMAND_SIZE                (sizeof(HCI_Master_Link_Key_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Remote_Name_Request_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
   Byte_t               Page_Scan_Repetition_Mode;
   Byte_t               Page_Scan_Mode;
   NonAlignedWord_t     Clock_Offset;
} __PACKED_STRUCT_END__ HCI_Remote_Name_Request_Command_t;

#define HCI_REMOTE_NAME_REQUEST_COMMAND_SIZE            (sizeof(HCI_Remote_Name_Request_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Remote_Supported_Features_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Read_Remote_Supported_Features_Command_t;

#define HCI_READ_REMOTE_SUPPORTED_FEATURES_COMMAND_SIZE (sizeof(HCI_Read_Remote_Supported_Features_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Remote_Version_Information_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Read_Remote_Version_Information_Command_t;

#define HCI_READ_REMOTE_VERSION_INFORMATION_COMMAND_SIZE (sizeof(HCI_Read_Remote_Version_Information_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Clock_Offset_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Read_Clock_Offset_Command_t;

#define HCI_READ_CLOCK_OFFSET_COMMAND_SIZE              (sizeof(HCI_Read_Clock_Offset_Command_t))

   /* HCI Command Definitions (Link Control - Version 1.2).             */
   
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Create_Connection_Cancel_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
} __PACKED_STRUCT_END__ HCI_Create_Connection_Cancel_Command_t;

#define HCI_CREATE_CONNECTION_CANCEL_COMMAND_SIZE       (sizeof(HCI_Create_Connection_Cancel_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Remote_Name_Request_Cancel_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
} __PACKED_STRUCT_END__ HCI_Remote_Name_Request_Cancel_Command_t;

#define HCI_REMOTE_NAME_REQUEST_CANCEL_COMMAND_SIZE     (sizeof(HCI_Remote_Name_Request_Cancel_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Remote_Extended_Features_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
   Byte_t               Page_Number;
} __PACKED_STRUCT_END__ HCI_Read_Remote_Extended_Features_Command_t;

#define HCI_READ_REMOTE_EXTENDED_FEATURES_COMMAND_SIZE  (sizeof(HCI_Read_Remote_Extended_Features_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_LMP_Handle_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Read_LMP_Handle_Command_t;

#define HCI_READ_LMP_HANDLE_COMMAND_SIZE                (sizeof(HCI_Read_LMP_Handle_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Setup_Synchronous_Connection_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
   NonAlignedDWord_t    Transmit_Bandwidth;
   NonAlignedDWord_t    Receive_Bandwidth;
   NonAlignedWord_t     Max_Latency;
   NonAlignedWord_t     Voice_Setting;
   Byte_t               Retransmission_Effort;
   NonAlignedWord_t     Packet_Type;
} __PACKED_STRUCT_END__ HCI_Setup_Synchronous_Connection_Command_t;

#define HCI_SETUP_SYNCHRONOUS_CONNECTION_COMMAND_SIZE   (sizeof(HCI_Setup_Synchronous_Connection_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Accept_Synchronous_Connection_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
   NonAlignedDWord_t    Transmit_Bandwidth;
   NonAlignedDWord_t    Receive_Bandwidth;
   NonAlignedWord_t     Max_Latency;
   NonAlignedWord_t     Content_Format;
   Byte_t               Retransmission_Effort;
   NonAlignedWord_t     Packet_Type;
} __PACKED_STRUCT_END__ HCI_Accept_Synchronous_Connection_Command_t;

#define HCI_ACCEPT_SYNCHRONOUS_CONNECTION_COMMAND_SIZE  (sizeof(HCI_Accept_Synchronous_Connection_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Reject_Synchronous_Connection_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
   Byte_t               Reason;
} __PACKED_STRUCT_END__ HCI_Reject_Synchronous_Connection_Command_t;

#define HCI_REJECT_SYNCHRONOUS_CONNECTION_COMMAND_SIZE  (sizeof(HCI_Reject_Synchronous_Connection_Command_t))

   /* HCI Command Definitions (Link Control - Version 2.1).             */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_IO_Capability_Request_Reply_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
   Byte_t               IO_Capability;
   Byte_t               OOB_Data_Present;
   Byte_t               Authentication_Requirements;
} __PACKED_STRUCT_END__ HCI_IO_Capability_Request_Reply_Command_t;

#define HCI_IO_CAPABILITY_REQUEST_REPLY_COMMAND_SIZE     (sizeof(HCI_IO_Capability_Request_Reply_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_User_Confirmation_Request_Reply_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
} __PACKED_STRUCT_END__ HCI_User_Confirmation_Request_Reply_Command_t;

#define HCI_USER_CONFIRMATION_REQUEST_REPLY_COMMAND_SIZE (sizeof(HCI_User_Confirmation_Request_Reply_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_User_Confirmation_Request_Negative_Reply_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
} __PACKED_STRUCT_END__ HCI_User_Confirmation_Request_Negative_Reply_Command_t;

#define HCI_USER_CONFIRMATION_REQUEST_NEGATIVE_REPLY_COMMAND_SIZE (sizeof(HCI_User_Confirmation_Request_Negative_Reply_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_User_Passkey_Request_Reply_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
   NonAlignedDWord_t    Numeric_Value;
} __PACKED_STRUCT_END__ HCI_User_Passkey_Request_Reply_Command_t;

#define HCI_USER_PASSKEY_REQUEST_REPLY_COMMAND_SIZE      (sizeof(HCI_User_Passkey_Request_Reply_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_User_Passkey_Request_Negative_Reply_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
} __PACKED_STRUCT_END__ HCI_User_Passkey_Request_Negative_Reply_Command_t;

#define HCI_USER_PASSKEY_REQUEST_NEGATIVE_REPLY_COMMAND_SIZE   (sizeof(HCI_User_Passkey_Request_Negative_Reply_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Remote_OOB_Data_Request_Reply_Command_t
{
   HCI_Command_Header_t        HCI_Command_Header;
   BD_ADDR_t                   BD_ADDR;
   Simple_Pairing_Hash_t       Simple_Pairing_Hash;
   Simple_Pairing_Randomizer_t Simple_Pairing_Randomizer;
} __PACKED_STRUCT_END__ HCI_Remote_OOB_Data_Request_Reply_Command_t;

#define HCI_REMOTE_OOB_DATA_REQUEST_REPLY_COMMAND_SIZE   (sizeof(HCI_Remote_OOB_Data_Request_Reply_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Remote_OOB_Data_Request_Negative_Reply_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
} __PACKED_STRUCT_END__ HCI_Remote_OOB_Data_Request_Negative_Reply_Command_t;

#define HCI_REMOTE_OOB_DATA_REQUEST_NEGATIVE_REPLY_COMMAND_SIZE   (sizeof(HCI_Remote_OOB_Data_Request_Negative_Reply_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_IO_Capability_Request_Negative_Reply_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
   Byte_t               Reason;
} __PACKED_STRUCT_END__ HCI_IO_Capability_Request_Negative_Reply_Command_t;

#define HCI_IO_CAPABILITY_REQUEST_NEGATIVE_REPLY_COMMAND_SIZE     (sizeof(HCI_IO_Capability_Request_Negative_Reply_Command_t))

   /* HCI Command Definitions (Link Policy).                            */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Hold_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
   NonAlignedWord_t     Hold_Mode_Max_Interval;
   NonAlignedWord_t     Hold_Mode_Min_Interval;
} __PACKED_STRUCT_END__ HCI_Hold_Mode_Command_t;

#define HCI_HOLD_MODE_COMMAND_SIZE                      (sizeof(HCI_Hold_Mode_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Sniff_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
   NonAlignedWord_t     Sniff_Max_Interval;
   NonAlignedWord_t     Sniff_Min_Interval;
   NonAlignedWord_t     Sniff_Attempt;
   NonAlignedWord_t     Sniff_Timeout;
} __PACKED_STRUCT_END__ HCI_Sniff_Mode_Command_t;

#define HCI_SNIFF_MODE_COMMAND_SIZE                     (sizeof(HCI_Sniff_Mode_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Exit_Sniff_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Exit_Sniff_Mode_Command_t;

#define HCI_EXIT_SNIFF_MODE_COMMAND_SIZE                (sizeof(HCI_Exit_Sniff_Mode_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Park_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
   NonAlignedWord_t     Beacon_Max_Interval;
   NonAlignedWord_t     Beacon_Min_Interval;
} __PACKED_STRUCT_END__ HCI_Park_Mode_Command_t;

#define HCI_PARK_MODE_COMMAND_SIZE                      (sizeof(HCI_Park_Mode_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Exit_Park_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Exit_Park_Mode_Command_t;

#define HCI_EXIT_PARK_MODE_COMMAND_SIZE                 (sizeof(HCI_Exit_Park_Mode_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_QoS_Setup_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
   Byte_t               Flags;
   Byte_t               Service_Type;
   NonAlignedDWord_t    Token_Rate;
   NonAlignedDWord_t    Peak_Bandwidth;
   NonAlignedDWord_t    Latency;
   NonAlignedDWord_t    Delay_Variation;
} __PACKED_STRUCT_END__ HCI_QoS_Setup_Command_t;

#define HCI_QOS_SETUP_COMMAND_SIZE                      (sizeof(HCI_QoS_Setup_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Role_Discovery_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Role_Discovery_Command_t;

#define HCI_ROLE_DISCOVERY_COMMAND_SIZE                 (sizeof(HCI_Role_Discovery_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Switch_Role_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
   Byte_t               Role;
} __PACKED_STRUCT_END__ HCI_Switch_Role_Command_t;

#define HCI_SWITCH_ROLE_COMMAND_SIZE                    (sizeof(HCI_Switch_Role_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Link_Policy_Settings_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Read_Link_Policy_Settings_Command_t;

#define HCI_READ_LINK_POLICY_SETTINGS_COMMAND_SIZE      (sizeof(HCI_Read_Link_Policy_Settings_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Link_Policy_Settings_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
   NonAlignedWord_t     Link_Policy_Settings;
} __PACKED_STRUCT_END__ HCI_Write_Link_Policy_Settings_Command_t;

#define HCI_WRITE_LINK_POLICY_SETTINGS_COMMAND_SIZE     (sizeof(HCI_Write_Link_Policy_Settings_Command_t))

   /* HCI Command Definitions (Link Policy - Version 1.2).              */
   
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Default_Link_Policy_Settings_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Default_Link_Policy_Settings_Command_t;

#define HCI_READ_DEFAULT_LINK_POLICY_SETTINGS_COMMAND_SIZE  (sizeof(HCI_Read_Default_Link_Policy_Settings_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Default_Link_Policy_Settings_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Link_Policy_Settings;
} __PACKED_STRUCT_END__ HCI_Write_Default_Link_Policy_Settings_Command_t;

#define HCI_WRITE_DEFAULT_LINK_POLICY_SETTINGS_COMMAND_SIZE (sizeof(HCI_Write_Default_Link_Policy_Settings_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Flow_Specification_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
   Byte_t               Flags;
   Byte_t               Flow_Direction;
   Byte_t               Service_Type;
   NonAlignedDWord_t    Token_Rate;
   NonAlignedDWord_t    Token_Bucket_Size;
   NonAlignedDWord_t    Peak_Bandwidth;
   NonAlignedDWord_t    Access_Latency;
} __PACKED_STRUCT_END__ HCI_Flow_Specification_Command_t;

#define HCI_FLOW_SPECIFICATION_COMMAND_SIZE             (sizeof(HCI_Flow_Specification_Command_t))

   /* HCI Command Definitions (Link Policy - Version 2.1).              */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Sniff_Subrating_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
   NonAlignedWord_t     Maximum_Latency;
   NonAlignedWord_t     Minimum_Remote_Timeout;
   NonAlignedWord_t     Minimum_Local_Timeout;
} __PACKED_STRUCT_END__ HCI_Sniff_Subrating_Command_t;

#define HCI_SNIFF_SUBRATING_COMMAND_SIZE                 (sizeof(HCI_Sniff_Subrating_Command_t))

   /* HCI Command Definitions (Host Control and Baseband).              */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Set_Event_Mask_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Event_Mask_t         Event_Mask;
} __PACKED_STRUCT_END__ HCI_Set_Event_Mask_Command_t;

#define HCI_SET_EVENT_MASK_COMMAND_SIZE                 (sizeof(HCI_Set_Event_Mask_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Reset_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Reset_Command_t;

#define HCI_RESET_COMMAND_SIZE                          (sizeof(HCI_Reset_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Set_Event_Filter_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Filter_Type;
   Byte_t               Filter_Condition_Type;
   Byte_t               Variable_Data[1];
} __PACKED_STRUCT_END__ HCI_Set_Event_Filter_Command_t;

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Determine the size (in Bytes) of an                */
   /* HCI Set Event Filter Command Data Structure based upon the size of*/
   /* the Condition Information associated with the Command. The first  */
   /* parameter to this MACRO is the size (in Bytes) of the Condition   */
   /* Data that is to be part of the Set Event Filter Command.          */
#define HCI_SET_EVENT_FILTER_COMMAND_SIZE(_x)           (sizeof(HCI_Set_Event_Filter_Command_t) - sizeof(Byte_t) + (unsigned int)(_x))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Flush_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Flush_Command_t;

#define HCI_FLUSH_COMMAND_SIZE                          (sizeof(HCI_Flush_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_PIN_Type_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_PIN_Type_Command_t;

#define HCI_READ_PIN_TYPE_COMMAND_SIZE                  (sizeof(HCI_Read_PIN_Type_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_PIN_Type_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               PIN_Type;
} __PACKED_STRUCT_END__ HCI_Write_PIN_Type_Command_t;

#define HCI_WRITE_PIN_TYPE_COMMAND_SIZE                 (sizeof(HCI_Write_PIN_Type_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Create_New_Unit_Key_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Create_New_Unit_Key_Command_t;

#define HCI_CREATE_NEW_UNIT_KEY_COMMAND_SIZE            (sizeof(HCI_Create_New_Unit_Key_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Stored_Link_Key_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
   Byte_t               Read_All_Flag;
} __PACKED_STRUCT_END__ HCI_Read_Stored_Link_Key_Command_t;

#define HCI_READ_STORED_LINK_KEY_COMMAND_SIZE           (sizeof(HCI_Read_Stored_Link_Key_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Stored_Link_Key_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Num_Keys_To_Write;
   Byte_t               Variable_Data[1];
} __PACKED_STRUCT_END__ HCI_Write_Stored_Link_Key_Command_t;

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Determine the size (in Bytes) of an                */
   /* HCI Write Stored Link Key Command Data Structure based upon the   */
   /* Number of BD_ADDR/Link Key Pairs that are required.  The first    */
   /* parameter to this MACRO is the Number of BD_ADDR/Link Key Pairs.  */
#define HCI_WRITE_STORED_LINK_KEY_COMMAND_SIZE(_x)      ((sizeof(HCI_Write_Stored_Link_Key_Command_t) - sizeof(Byte_t)) + ((_x)*(sizeof(BD_ADDR_t)+sizeof(Link_Key_t))))

   /* The following definition exists to define the Total Number of     */
   /* Stored Link Key's that can be supported by a single               */
   /* HCI_Write_Stored_Link_Key_Command_t Command Packet.               */
#define HCI_WRITE_STORED_LINK_KEY_COMMAND_MAX_KEYS       (((sizeof(Byte_t)*256) - HCI_WRITE_STORED_LINK_KEY_COMMAND_SIZE(0))/(sizeof(BD_ADDR_t) + sizeof(Link_Key_t)))

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Set a specified BD_ADDR in the HCI Write Stored    */
   /* Link Key Command Data.  The first parameter is a pointer to a     */
   /* Data Buffer that is an HCI_Write_Stored_Link_Key_Command_t.  The  */
   /* Second parameter is the Index of the BD_ADDR to Set, and the      */
   /* Third parameter is the BD_ADDR value to set.                      */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_WRITE_STORED_LINK_KEY_COMMAND_SET_BD_ADDR(_x, _y, _z)                                                                           \
{                                                                                                                                           \
   ASSIGN_UNALIGNED_GENERIC_TYPE(((BD_ADDR_t *)(((Byte_t *)((_x)->Variable_Data)) + (_y)*(sizeof(BD_ADDR_t) + sizeof(Link_Key_t)))), (_z)); \
}

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Set a specified Link Key in the HCI Write Stored   */
   /* Link Key Command Data.  The first parameter is a pointer to a     */
   /* Data Buffer that is an HCI_Write_Stored_Link_Key_Command_t.  The  */
   /* Second parameter is the Index of the Link Key to Set, and the     */
   /* Third parameter is the Link Key value to set.                     */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_WRITE_STORED_LINK_KEY_COMMAND_SET_LINK_KEY(_x, _y, _z)                                                                                                 \
{                                                                                                                                                                  \
   ASSIGN_UNALIGNED_GENERIC_TYPE(((Link_Key_t *)(((Byte_t *)((_x)->Variable_Data)) + ((_y)*(sizeof(BD_ADDR_t) + sizeof(Link_Key_t))) + sizeof(BD_ADDR_t))), (_z)); \
}

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Delete_Stored_Link_Key_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
   Byte_t               Delete_All_Flag;
} __PACKED_STRUCT_END__ HCI_Delete_Stored_Link_Key_Command_t;

#define HCI_DELETE_STORED_LINK_KEY_COMMAND_SIZE         (sizeof(HCI_Delete_Stored_Link_Key_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Change_Local_Name_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Variable_Data[1];
} __PACKED_STRUCT_END__ HCI_Change_Local_Name_Command_t;

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Determine the size (in Bytes) of an                */
   /* HCI Change Local Name Command Data Structure based upon the       */
   /* Length (in Bytes) of the Name that is required.  The first        */
   /* parameter to this MACRO is the Length (in Bytes) of the Name.     */
#define HCI_CHANGE_LOCAL_NAME_COMMAND_SIZE(_x)          ((sizeof(HCI_Change_Local_Name_Command_t) - sizeof(Byte_t)) + ((unsigned int)(_x)))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Local_Name_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Local_Name_Command_t;

#define HCI_READ_LOCAL_NAME_COMMAND_SIZE                (sizeof(HCI_Read_Local_Name_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Connection_Accept_Timeout_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Connection_Accept_Timeout_Command_t;

#define HCI_READ_CONNECTION_ACCEPT_TIMEOUT_COMMAND_SIZE (sizeof(HCI_Read_Connection_Accept_Timeout_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Connection_Accept_Timeout_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Conn_Accept_Timeout;
} __PACKED_STRUCT_END__ HCI_Write_Connection_Accept_Timeout_Command_t;

#define HCI_WRITE_CONNECTION_ACCEPT_TIMEOUT_COMMAND_SIZE (sizeof(HCI_Write_Connection_Accept_Timeout_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Page_Timeout_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Page_Timeout_Command_t;

#define HCI_READ_PAGE_TIMEOUT_COMMAND_SIZE              (sizeof(HCI_Read_Page_Timeout_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Page_Timeout_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Page_Timeout;
} __PACKED_STRUCT_END__ HCI_Write_Page_Timeout_Command_t;

#define HCI_WRITE_PAGE_TIMEOUT_COMMAND_SIZE             (sizeof(HCI_Write_Page_Timeout_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Scan_Enable_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Scan_Enable_Command_t;

#define HCI_READ_SCAN_ENABLE_COMMAND_SIZE               (sizeof(HCI_Read_Scan_Enable_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Scan_Enable_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Scan_Enable;
} __PACKED_STRUCT_END__ HCI_Write_Scan_Enable_Command_t;

#define HCI_WRITE_SCAN_ENABLE_COMMAND_SIZE              (sizeof(HCI_Write_Scan_Enable_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Page_Scan_Activity_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Page_Scan_Activity_Command_t;

#define HCI_READ_PAGE_SCAN_ACTIVITY_COMMAND_SIZE        (sizeof(HCI_Read_Page_Scan_Activity_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Page_Scan_Activity_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Page_Scan_Interval;
   NonAlignedWord_t     Page_Scan_Window;
} __PACKED_STRUCT_END__ HCI_Write_Page_Scan_Activity_Command_t;

#define HCI_WRITE_PAGE_SCAN_ACTIVITY_COMMAND_SIZE       (sizeof(HCI_Write_Page_Scan_Activity_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Inquiry_Scan_Activity_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Inquiry_Scan_Activity_Command_t;

#define HCI_READ_INQUIRY_SCAN_ACTIVITY_COMMAND_SIZE     (sizeof(HCI_Read_Inquiry_Scan_Activity_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Inquiry_Scan_Activity_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Inquiry_Scan_Interval;
   NonAlignedWord_t     Inquiry_Scan_Window;
} __PACKED_STRUCT_END__ HCI_Write_Inquiry_Scan_Activity_Command_t;

#define HCI_WRITE_INQUIRY_SCAN_ACTIVITY_COMMAND_SIZE    (sizeof(HCI_Write_Inquiry_Scan_Activity_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Authentication_Enable_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Authentication_Enable_Command_t;

#define HCI_READ_AUTHENTICATION_ENABLE_COMMAND_SIZE     (sizeof(HCI_Read_Authentication_Enable_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Authentication_Enable_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Authentication_Enable;
} __PACKED_STRUCT_END__ HCI_Write_Authentication_Enable_Command_t;

#define HCI_WRITE_AUTHENTICATION_ENABLE_COMMAND_SIZE    (sizeof(HCI_Write_Authentication_Enable_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Encryption_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Encryption_Mode_Command_t;

#define HCI_READ_ENCRYPTION_MODE_COMMAND_SIZE           (sizeof(HCI_Read_Encryption_Mode_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Encryption_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Encryption_Mode;
} __PACKED_STRUCT_END__ HCI_Write_Encryption_Mode_Command_t;

#define HCI_WRITE_ENCRYPTION_MODE_COMMAND_SIZE          (sizeof(HCI_Write_Encryption_Mode_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Class_of_Device_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Class_of_Device_Command_t;

#define HCI_READ_CLASS_OF_DEVICE_COMMAND_SIZE           (sizeof(HCI_Read_Class_of_Device_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Class_of_Device_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Class_of_Device_t    Class_of_Device;
} __PACKED_STRUCT_END__ HCI_Write_Class_of_Device_Command_t;

#define HCI_WRITE_CLASS_OF_DEVICE_COMMAND_SIZE          (sizeof(HCI_Write_Class_of_Device_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Voice_Setting_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Voice_Setting_Command_t;

#define HCI_READ_VOICE_SETTING_COMMAND_SIZE             (sizeof(HCI_Read_Voice_Setting_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Voice_Setting_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Voice_Setting;
} __PACKED_STRUCT_END__ HCI_Write_Voice_Setting_Command_t;

#define HCI_WRITE_VOICE_SETTING_COMMAND_SIZE            (sizeof(HCI_Write_Voice_Setting_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Automatic_Flush_Timeout_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Read_Automatic_Flush_Timeout_Command_t;

#define HCI_READ_AUTOMATIC_FLUSH_TIMEOUT_COMMAND_SIZE   (sizeof(HCI_Read_Automatic_Flush_Timeout_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Automatic_Flush_Timeout_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
   NonAlignedWord_t     Flush_Timeout;
} __PACKED_STRUCT_END__ HCI_Write_Automatic_Flush_Timeout_Command_t;

#define HCI_WRITE_AUTOMATIC_FLUSH_TIMEOUT_COMMAND_SIZE  (sizeof(HCI_Write_Automatic_Flush_Timeout_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Num_Broadcast_Retransmissions_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Num_Broadcast_Retransmissions_Command_t;

#define HCI_READ_NUM_BROADCAST_RETRANSMISSIONS_COMMAND_SIZE (sizeof(HCI_Read_Num_Broadcast_Retransmissions_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Num_Broadcast_Retransmissions_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Num_Broadcast_Retran;
} __PACKED_STRUCT_END__ HCI_Write_Num_Broadcast_Retransmissions_Command_t;

#define HCI_WRITE_NUM_BROADCAST_RETRANSMISSIONS_COMMAND_SIZE (sizeof(HCI_Write_Num_Broadcast_Retransmissions_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Hold_Mode_Activity_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Hold_Mode_Activity_Command_t;

#define HCI_READ_HOLD_MODE_ACTIVITY_COMMAND_SIZE        (sizeof(HCI_Read_Hold_Mode_Activity_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Hold_Mode_Activity_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Hold_Mode_Activity;
} __PACKED_STRUCT_END__ HCI_Write_Hold_Mode_Activity_Command_t;

#define HCI_WRITE_HOLD_MODE_ACTIVITY_COMMAND_SIZE       (sizeof(HCI_Write_Hold_Mode_Activity_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Transmit_Power_Level_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
   Byte_t               Type;
} __PACKED_STRUCT_END__ HCI_Read_Transmit_Power_Level_Command_t;

#define HCI_READ_TRANSMIT_POWER_LEVEL_COMMAND_SIZE      (sizeof(HCI_Read_Transmit_Power_Level_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_SCO_Flow_Control_Enable_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_SCO_Flow_Control_Enable_Command_t;

#define HCI_READ_SCO_FLOW_CONTROL_ENABLE_COMMAND_SIZE   (sizeof(HCI_Read_SCO_Flow_Control_Enable_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_SCO_Flow_Control_Enable_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               SCO_Flow_Control_Enable;
} __PACKED_STRUCT_END__ HCI_Write_SCO_Flow_Control_Enable_Command_t;

#define HCI_WRITE_SCO_FLOW_CONTROL_ENABLE_COMMAND_SIZE  (sizeof(HCI_Write_SCO_Flow_Control_Enable_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Set_Host_Controller_To_Host_Flow_Control_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Flow_Control_Enable;
} __PACKED_STRUCT_END__ HCI_Set_Host_Controller_To_Host_Flow_Control_Command_t;

#define HCI_SET_HOST_CONTROLLER_TO_HOST_FLOW_CONTROL_COMMAND_SIZE (sizeof(HCI_Set_Host_Controller_To_Host_Flow_Control_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Host_Buffer_Size_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Host_ACL_Data_Packet_Length;
   Byte_t               Host_SCO_Data_Packet_Length;
   NonAlignedWord_t     Host_Total_Num_ACL_Data_Packets;
   NonAlignedWord_t     Host_Total_Num_SCO_Data_Packets;
} __PACKED_STRUCT_END__ HCI_Host_Buffer_Size_Command_t;

#define HCI_HOST_BUFFER_SIZE_COMMAND_SIZE               (sizeof(HCI_Host_Buffer_Size_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Host_Number_Of_Completed_Packets_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Number_Of_Handles;
   Byte_t               Variable_Data[1];
} __PACKED_STRUCT_END__ HCI_Host_Number_Of_Completed_Packets_Command_t;

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Determine the size (in Bytes) of an                */
   /* HCI Host Number of Completed Packets Command Data Structure       */
   /* based upon the Number of Connection Handle/Number of Completed    */
   /* Packet Pairs that are required.  The first parameter to this MACRO*/
   /* is the Number of Connection Handle/Number of Completed Packet     */
   /* Pairs.                                                            */
#define HCI_HOST_NUMBER_OF_COMPLETED_PACKETS_COMMAND_SIZE(_x) ((sizeof(HCI_Host_Number_Of_Completed_Packets_Command_t) - sizeof(Byte_t)) + ((Byte_t)(_x)*(sizeof(Word_t)+sizeof(Word_t))))

   /* The following definition exists to define the Total Number of     */
   /* Connection Handle/Number of Completed Packets that can be         */
   /* supported by a single HCI_Host_Number_Of_Completed_Packets        */
   /* Command Packet.                                                   */
#define HCI_HOST_NUMBER_OF_COMPLETED_PACKETS_COMMAND_MAX_HANDLES (((sizeof(Byte_t)*256) - HCI_HOST_NUMBER_OF_COMPLETED_PACKETS_COMMAND_SIZE(0))/(sizeof(Word_t) + sizeof(Word_t)))

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Set a specified Connection Handle in the Host      */
   /* Number of Completed Packets Command Data.  The first parameter is */
   /* a pointer to a Data Buffer that is an                             */
   /* HCI_Host_Number_Of_Completed_Packets_Command_t.  The Second       */
   /* parameter is the Index of the Connection Handle to Set, and the   */
   /* Third parameter is the Connection Handle value to Set.            */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_HOST_NUMBER_OF_COMPLETED_PACKETS_COMMAND_SET_HANDLE(_x, _y, _z)                                                              \
{                                                                                                                                        \
   ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD((((Byte_t *)((_x)->Variable_Data)) + (_y)*(sizeof(Word_t) + sizeof(Word_t))), (_z)); \
}

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Set a specified Number of Completed Packets in the */
   /* Host Number of Completed Packets Command Data.  The first         */
   /* parameter is a pointer to a Data Buffer that is an                */
   /* HCI_Host_Number_Of_Completed_Packets_Command_t.  The Second       */
   /* parameter is the Index of the Number of Completed Packets to Set, */
   /* and the Third parameter is the Connection Handle value to Set.    */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_HOST_NUMBER_OF_COMPLETED_PACKETS_COMMAND_SET_NUM_PACKETS(_x, _y, _z)                                                                            \
{                                                                                                                                                           \
   ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD((((Byte_t *)((_x)->Variable_Data)) + ((_y)*(sizeof(Word_t) + sizeof(Word_t))) + sizeof(Word_t)), (_z)); \
}

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Link_Supervision_Timeout_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Read_Link_Supervision_Timeout_Command_t;

#define HCI_READ_LINK_SUPERVISION_TIMEOUT_COMMAND_SIZE  (sizeof(HCI_Read_Link_Supervision_Timeout_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Link_Supervision_Timeout_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
   NonAlignedWord_t     Link_Supervision_Timeout;
} __PACKED_STRUCT_END__ HCI_Write_Link_Supervision_Timeout_Command_t;

#define HCI_WRITE_LINK_SUPERVISION_TIMEOUT_COMMAND_SIZE  (sizeof(HCI_Write_Link_Supervision_Timeout_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Number_Of_Supported_IAC_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Number_Of_Supported_IAC_Command_t;

#define HCI_READ_NUMBER_OF_SUPPORTED_IAC_COMMAND_SIZE   (sizeof(HCI_Read_Number_Of_Supported_IAC_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Current_IAC_LAP_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Current_IAC_LAP_Command_t;

#define HCI_READ_CURRENT_IAC_LAP_COMMAND_SIZE           (sizeof(HCI_Read_Current_IAC_LAP_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Current_IAC_LAP_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Num_Current_IAC;
   Byte_t               Variable_Data[1];
} __PACKED_STRUCT_END__ HCI_Write_Current_IAC_LAP_Command_t;

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Determine the size (in Bytes) of an                */
   /* HCI Write Current IAC LAP Command Data Structure based upon the   */
   /* Number of Connection IACs that are required.  The first parameter */
   /* to this MACRO is the Number of IAC's.                             */
#define HCI_WRITE_CURRENT_IAC_LAP_COMMAND_SIZE(_x)      ((sizeof(HCI_Write_Current_IAC_LAP_Command_t) - sizeof(Byte_t)) + ((_x)*(sizeof(LAP_t))))

   /* The following definition exists to define the Total Number of     */
   /* IAC LAP's that can be supported by a single                       */
   /* HCI_Write_Current_IAC_LAP_Command_t Command Packet.               */
#define HCI_WRITE_CURRENT_IAC_LAP_COMMAND_MAX_IAC_LAPS   (((sizeof(Byte_t)*256) - HCI_WRITE_CURRENT_IAC_LAP_COMMAND_SIZE(0))/(sizeof(LAP_t)))

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Set a specified IAC LAP in the Write Current IAC   */
   /* LAP Command Data.  The first parameter is a pointer to a Data     */
   /* Buffer that is an HCI_Write_Current_IAC_LAP_Command_t.  The       */
   /* second parameter is the Index of the IAC LAP to Set, and the third*/
   /* parameter is the IAC LAP value to Set.                            */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_WRITE_CURRENT_IAC_LAP_COMMAND_SET_IAC_LAP(_x, _y, _z)                                              \
{                                                                                                              \
   ASSIGN_UNALIGNED_GENERIC_TYPE(((LAP_t *)(((Byte_t *)((_x)->Variable_Data)) + (_y)*(sizeof(LAP_t)))), (_z)); \
}

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Page_Scan_Period_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Page_Scan_Period_Mode_Command_t;

#define HCI_READ_PAGE_SCAN_PERIOD_MODE_COMMAND_SIZE     (sizeof(HCI_Read_Page_Scan_Period_Mode_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Page_Scan_Period_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Page_Scan_Period_Mode;
} __PACKED_STRUCT_END__ HCI_Write_Page_Scan_Period_Mode_Command_t;

#define HCI_WRITE_PAGE_SCAN_PERIOD_MODE_COMMAND_SIZE    (sizeof(HCI_Write_Page_Scan_Period_Mode_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Page_Scan_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Page_Scan_Mode_Command_t;

#define HCI_READ_PAGE_SCAN_MODE_COMMAND_SIZE            (sizeof(HCI_Read_Page_Scan_Mode_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Page_Scan_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Page_Scan_Mode;
} __PACKED_STRUCT_END__ HCI_Write_Page_Scan_Mode_Command_t;

#define HCI_WRITE_PAGE_SCAN_MODE_COMMAND_SIZE           (sizeof(HCI_Write_Page_Scan_Mode_Command_t))

   /* HCI Command Definitions (Host Control and Baseband - Version 1.2) */
   
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Set_AFH_Host_Channel_Classification_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   AFH_Channel_Map_t    AFH_Host_Channel_Classification;
} __PACKED_STRUCT_END__ HCI_Set_AFH_Host_Channel_Classification_Command_t;

#define HCI_SET_AFH_HOST_CHANNEL_CLASSIFICATION_COMMAND_SIZE  (sizeof(HCI_Set_AFH_Host_Channel_Classification_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Inquiry_Scan_Type_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Inquiry_Scan_Type_Command_t;

#define HCI_READ_INQUIRY_SCAN_TYPE_COMMAND_SIZE         (sizeof(HCI_Read_Inquiry_Scan_Type_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Inquiry_Scan_Type_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Scan_Type;
} __PACKED_STRUCT_END__ HCI_Write_Inquiry_Scan_Type_Command_t;

#define HCI_WRITE_INQUIRY_SCAN_TYPE_COMMAND_SIZE        (sizeof(HCI_Write_Inquiry_Scan_Type_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Inquiry_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Inquiry_Mode_Command_t;

#define HCI_READ_INQUIRY_MODE_COMMAND_SIZE              (sizeof(HCI_Read_Inquiry_Mode_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Inquiry_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Inquiry_Mode;
} __PACKED_STRUCT_END__ HCI_Write_Inquiry_Mode_Command_t;

#define HCI_WRITE_INQUIRY_MODE_COMMAND_SIZE             (sizeof(HCI_Write_Inquiry_Mode_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Page_Scan_Type_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Page_Scan_Type_Command_t;

#define HCI_READ_PAGE_SCAN_TYPE_COMMAND_SIZE            (sizeof(HCI_Read_Page_Scan_Type_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Page_Scan_Type_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Page_Scan_Type;
} __PACKED_STRUCT_END__ HCI_Write_Page_Scan_Type_Command_t;

#define HCI_WRITE_PAGE_SCAN_TYPE_COMMAND_SIZE           (sizeof(HCI_Write_Page_Scan_Type_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_AFH_Channel_Assessment_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_AFH_Channel_Assessment_Mode_Command_t;

#define HCI_READ_AFH_CHANNEL_ASSESSMENT_MODE_COMMAND_SIZE  (sizeof(HCI_Read_AFH_Channel_Assessment_Mode_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_AFH_Channel_Assessment_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               AFH_Channel_Assessment_Mode;
} __PACKED_STRUCT_END__ HCI_Write_AFH_Channel_Assessment_Mode_Command_t;

#define HCI_WRITE_AFH_CHANNEL_ASSESSMENT_MODE_COMMAND_SIZE (sizeof(HCI_Write_AFH_Channel_Assessment_Mode_Command_t))

   /* HCI Command Definitions (Host Control and Baseband - Version 2.1) */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Extended_Inquiry_Response_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Extended_Inquiry_Response_Command_t;

#define HCI_READ_EXTENDED_INQUIRY_RESPONSE_COMMAND_SIZE     (sizeof(HCI_Read_Extended_Inquiry_Response_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Extended_Inquiry_Response_Command_t
{
   HCI_Command_Header_t             HCI_Command_Header;
   Byte_t                           FEC_Required;
   Extended_Inquiry_Response_Data_t Extended_Inquiry_Response;
} __PACKED_STRUCT_END__ HCI_Write_Extended_Inquiry_Response_Command_t;

#define HCI_WRITE_EXTENDED_INQUIRY_RESPONSE_COMMAND_SIZE (sizeof(HCI_Write_Extended_Inquiry_Response_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Refresh_Encryption_Key_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Refresh_Encryption_Key_Command_t;

#define HCI_REFRESH_ENCRYPTION_KEY_COMMAND_SIZE          (sizeof(HCI_Refresh_Encryption_Key_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Simple_Pairing_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Simple_Pairing_Mode_Command_t;

#define HCI_READ_SIMPLE_PAIRING_MODE_COMMAND_SIZE        (sizeof(HCI_Read_Simple_Pairing_Mode_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Simple_Pairing_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Simple_Pairing_Enable;
} __PACKED_STRUCT_END__ HCI_Write_Simple_Pairing_Mode_Command_t;

#define HCI_WRITE_SIMPLE_PAIRING_MODE_COMMAND_SIZE       (sizeof(HCI_Write_Simple_Pairing_Mode_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Local_OOB_Data_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Local_OOB_Data_Command_t;

#define HCI_READ_LOCAL_OOB_DATA_COMMAND_SIZE             (sizeof(HCI_Read_Local_OOB_Data_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Inquiry_Response_Transmit_Power_Level_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Inquiry_Response_Transmit_Power_Level_Command_t;

#define HCI_READ_INQUIRY_RESPONSE_TRANSMIT_POWER_LEVEL_COMMAND_SIZE  (sizeof(HCI_Read_Inquiry_Response_Transmit_Power_Level_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Inquiry_Transmit_Power_Level_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   SByte_t              TX_Power;
} __PACKED_STRUCT_END__ HCI_Write_Inquiry_Transmit_Power_Level_Command_t;

#define HCI_WRITE_INQUIRY_TRANSMIT_POWER_LEVEL_COMMAND_SIZE    (sizeof(HCI_Write_Inquiry_Transmit_Power_Level_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Send_Keypress_Notification_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   BD_ADDR_t            BD_ADDR;
   Byte_t               Notification_Type;
} __PACKED_STRUCT_END__ HCI_Send_Keypress_Notification_Command_t;

#define HCI_SEND_KEYPRESS_NOTIFICATION_COMMAND_SIZE            (sizeof(HCI_Send_Keypress_Notification_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Default_Erroneous_Data_Reporting_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Default_Erroneous_Data_Reporting_Command_t;

#define HCI_READ_DEFAULT_ERRONEOUS_DATA_REPORTING_COMMAND_SIZE (sizeof(HCI_Read_Default_Erroneous_Data_Reporting_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Default_Erroneous_Data_Reporting_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Erroneous_Data_Reporting;
} __PACKED_STRUCT_END__ HCI_Write_Default_Erroneous_Data_Reporting_Command_t;

#define HCI_WRITE_DEFAULT_ERRONEOUS_DATA_REPORTING_COMMAND_SIZE   (sizeof(HCI_Write_Default_Erroneous_Data_Reporting_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Enhanced_Flush_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
   Byte_t               Packet_Type;
} __PACKED_STRUCT_END__ HCI_Enhanced_Flush_Command_t;

#define HCI_ENHANCED_FLUSH_COMMAND_SIZE                  (sizeof(HCI_Enhanced_Flush_Command_t))

   /* HCI Command Definitions (Informational Parameters).               */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Local_Version_Information_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Local_Version_Information_Command_t;

#define HCI_READ_LOCAL_VERSION_INFORMATION_COMMAND_SIZE (sizeof(HCI_Read_Local_Version_Information_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Local_Supported_Features_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Local_Supported_Features_Command_t;

#define HCI_READ_LOCAL_SUPPORTED_FEATURES_COMMAND_SIZE  (sizeof(HCI_Read_Local_Supported_Features_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Buffer_Size_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Buffer_Size_Command_t;

#define HCI_READ_BUFFER_SIZE_COMMAND_SIZE               (sizeof(HCI_Read_Buffer_Size_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Country_Code_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Country_Code_Command_t;

#define HCI_READ_COUNTRY_CODE_COMMAND_SIZE              (sizeof(HCI_Read_Country_Code_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_BD_ADDR_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_BD_ADDR_Command_t;

#define HCI_READ_BD_ADDR_COMMAND_SIZE                   (sizeof(HCI_Read_BD_ADDR_Command_t))

   /* HCI Command Definitions (Informational Parameters - Version 1.2). */
   
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Local_Supported_Commands_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Local_Supported_Commands_Command_t;

#define HCI_READ_LOCAL_SUPPORTED_COMMANDS_COMMAND_SIZE  (sizeof(HCI_Read_Local_Supported_Commands_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Local_Extended_Features_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Page_Number;
} __PACKED_STRUCT_END__ HCI_Read_Local_Extended_Features_Command_t;

#define HCI_READ_LOCAL_EXTENDED_FEATURES_COMMAND_SIZE   (sizeof(HCI_Read_Local_Extended_Features_Command_t))

   /* HCI Command Definitions (Status Parameters).                      */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Failed_Contact_Counter_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Read_Failed_Contact_Counter_Command_t;

#define HCI_READ_FAILED_CONTACT_COUNTER_COMMAND_SIZE    (sizeof(HCI_Read_Failed_Contact_Counter_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Reset_Failed_Contact_Counter_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Reset_Failed_Contact_Counter_Command_t;

#define HCI_RESET_FAILED_CONTACT_COUNTER_COMMAND_SIZE   (sizeof(HCI_Reset_Failed_Contact_Counter_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Get_Link_Quality_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Get_Link_Quality_Command_t;

#define HCI_GET_LINK_QUALITY_COMMAND_SIZE               (sizeof(HCI_Get_Link_Quality_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_RSSI_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Read_RSSI_Command_t;

#define HCI_READ_RSSI_COMMAND_SIZE                      (sizeof(HCI_Read_RSSI_Command_t))

   /* HCI Command Definitions (Status Parameters - Version 1.2).        */
   
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_AFH_Channel_Map_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Read_AFH_Channel_Map_Command_t;

#define HCI_READ_AFH_CHANNEL_MAP_COMMAND_SIZE           (sizeof(HCI_Read_AFH_Channel_Map_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Clock_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   NonAlignedWord_t     Connection_Handle;
   Byte_t               Which_Clock;
} __PACKED_STRUCT_END__ HCI_Read_Clock_Command_t;

#define HCI_READ_CLOCK_COMMAND_SIZE                     (sizeof(HCI_Read_Clock_Command_t))

   /* HCI Command Definitions (Testing Commands).                       */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Loopback_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Read_Loopback_Mode_Command_t;

#define HCI_READ_LOOPBACK_MODE_COMMAND_SIZE             (sizeof(HCI_Read_Loopback_Mode_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Loopback_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Loopback_Mode;
} __PACKED_STRUCT_END__ HCI_Write_Loopback_Mode_Command_t;

#define HCI_WRITE_LOOPBACK_MODE_COMMAND_SIZE            (sizeof(HCI_Write_Loopback_Mode_Command_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Enable_Device_Under_Test_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
} __PACKED_STRUCT_END__ HCI_Enable_Device_Under_Test_Mode_Command_t;

#define HCI_ENABLE_DEVICE_UNDER_TEST_MODE_COMMAND_SIZE  (sizeof(HCI_Enable_Device_Under_Test_Mode_Command_t))

   /* HCI Command Definitions (Testing Commands - Version 2.1).         */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Simple_Pairing_Debug_Mode_Command_t
{
   HCI_Command_Header_t HCI_Command_Header;
   Byte_t               Simple_Pairing_Debug_Mode;
} __PACKED_STRUCT_END__ HCI_Write_Simple_Pairing_Debug_Mode_Command_t;

#define HCI_WRITE_SIMPLE_PAIRING_DEBUG_MODE_COMMAND_SIZE (sizeof(HCI_Write_Simple_Pairing_Debug_Mode_Command_t))

   /* HCI Event Definitions.                                            */

   /* The following type declaration represents the structure of the    */
   /* Header of an HCI Event Packet.  This Header Information is        */
   /* contained in Every Defined HCI Event Packet.  This structure      */
   /* forms the basis of additional defined HCI Event Packets.  Since   */
   /* this structure is present at the begining of Every Defined HCI    */
   /* Event Packet, this structure will be the first element of Every   */
   /* Defined HCI Event Packet in this file.                            */
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Event_Header_t
{
   NonAlignedByte_t Event_Code;
   NonAlignedByte_t Parameter_Total_Length;
} __PACKED_STRUCT_END__ HCI_Event_Header_t;

#define HCI_EVENT_HEADER_SIZE                           (sizeof(HCI_Event_Header_t))

#define HCI_EVENT_MAX_SIZE                              (sizeof(HCI_Event_Header_t) + (sizeof(Byte_t)*256))

   /* The following MACRO Exists to determine the Size (in Bytes) of    */
   /* the buffer that would be required to satisfy an HCI Event packet  */
   /* of the specified Parameter Total Length (in Bytes).  The first    */
   /* parameter of this MACRO is the size (in Bytes) of the total       */
   /* number of Parameter Bytes required for the HCI Event Packet.      */
#define HCI_EVENT_SIZE(_x)                              (sizeof(HCI_Event_Header_t) + (unsigned int)(_x))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Inquiry_Complete_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   Byte_t             Num_Responses;
} __PACKED_STRUCT_END__ HCI_Inquiry_Complete_Event_t;

#define HCI_INQUIRY_COMPLETE_EVENT_SIZE                 (sizeof(HCI_Inquiry_Complete_Event_t))

   /* Below is the HCI Inquiry Complete Event for the Bluetooth HCI 1.1 */
   /* Specification (Version 1.1).                                      */
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Inquiry_Complete_Event_1_1_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
} __PACKED_STRUCT_END__ HCI_Inquiry_Complete_Event_1_1_t;

#define HCI_INQUIRY_COMPLETE_EVENT_1_1_SIZE             (sizeof(HCI_Inquiry_Complete_Event_1_1_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Inquiry_Result_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Num_Responses;
   Byte_t             Variable_Data[1];
} __PACKED_STRUCT_END__ HCI_Inquiry_Result_Event_t;

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Determine the size (in Bytes) of an                */
   /* HCI Inquiry Result Event Data Structure based upon the Number of  */
   /* Responses.  The first parameter of this MACRO is the Number of    */
   /* Responses.                                                        */
#define HCI_INQUIRY_RESULT_EVENT_SIZE(_x)               ((sizeof(HCI_Inquiry_Result_Event_t) - sizeof(Byte_t)) + ((_x)*(sizeof(BD_ADDR_t)+sizeof(Byte_t)+sizeof(Byte_t)+sizeof(Byte_t)+sizeof(Class_of_Device_t)+sizeof(Word_t))))

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Read a specified BD_ADDR in the HCI Inquiry Result */
   /* Event Data.  The first parameter is a pointer to a Data Buffer    */
   /* that is an HCI_Inquiry Result_Event_t.  The Second parameter is   */
   /* the Index of the BD_ADDR to Read.                                 */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_INQUIRY_RESULT_EVENT_READ_BD_ADDR(_x, _y)          \
   READ_UNALIGNED_GENERIC_TYPE(((BD_ADDR_t *)(((Byte_t *)((_x)->Variable_Data)) + (_y)*(sizeof(BD_ADDR_t) + sizeof(Byte_t)*3 + sizeof(Class_of_Device_t) + sizeof(Word_t)))))
   
   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Read a specified Page Scan Repetition Mode value in*/
   /* the HCI Inquiry Result Event Data.  The first parameter is a      */
   /* pointer to a Data Buffer that is an HCI_Inquiry Result_Event_t.   */
   /* The Second parameter is the Index of the Page Scan Repetition Mode*/
   /* Value to Read.                                                    */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_INQUIRY_RESULT_EVENT_READ_REPETITION_MODE(_x, _y)  \
   READ_UNALIGNED_BYTE_LITTLE_ENDIAN(((Byte_t *)(((Byte_t *)((_x)->Variable_Data)) + ((_y)*(sizeof(BD_ADDR_t) + sizeof(Byte_t)*3 + sizeof(Class_of_Device_t) + sizeof(Word_t))) + sizeof(BD_ADDR_t))))

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Read a specified Page Scan Period Mode value in    */
   /* the HCI Inquiry Result Event Data.  The first parameter is a      */
   /* pointer to a Data Buffer that is an HCI_Inquiry Result_Event_t.   */
   /* The Second parameter is the Index of the Page Scan Period Mode    */
   /* Value to Read.                                                    */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_INQUIRY_RESULT_EVENT_READ_PERIOD_MODE(_x, _y)      \
   READ_UNALIGNED_BYTE_LITTLE_ENDIAN(((Byte_t *)(((Byte_t *)((_x)->Variable_Data)) + ((_y)*(sizeof(BD_ADDR_t) + sizeof(Byte_t)*3 + sizeof(Class_of_Device_t) + sizeof(Word_t))) + sizeof(BD_ADDR_t) + sizeof(Byte_t))))

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Read a specified Page Scan Mode value in the HCI   */
   /* Inquiry Result Event Data.  The first parameter is a pointer to   */
   /* a Data Buffer that is an HCI_Inquiry Result_Event_t.  The second  */
   /* parameter is the Index of the Page Scan Mode value to read.       */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_INQUIRY_RESULT_EVENT_READ_SCAN_MODE(_x, _y)        \
   READ_UNALIGNED_BYTE_LITTLE_ENDIAN(((Byte_t *)(((Byte_t *)((_x)->Variable_Data)) + ((_y)*(sizeof(BD_ADDR_t) + sizeof(Byte_t)*3 + sizeof(Class_of_Device_t) + sizeof(Word_t))) + sizeof(BD_ADDR_t) + sizeof(Byte_t)*2)))

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Read a specified Class of Device value in the HCI  */
   /* Inquiry Result Event Data.  The first parameter is a pointer to   */
   /* a Data Buffer that is an HCI_Inquiry Result_Event_t.  The second  */
   /* parameter is the Index of the Class of Device value to read.      */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_INQUIRY_RESULT_EVENT_READ_CLASS_OF_DEVICE(_x, _y)  \
   READ_UNALIGNED_GENERIC_TYPE(((Class_of_Device_t *)(((Byte_t *)((_x)->Variable_Data)) + ((_y)*(sizeof(BD_ADDR_t) + sizeof(Byte_t)*3 + sizeof(Class_of_Device_t) + sizeof(Word_t))) + sizeof(BD_ADDR_t) + sizeof(Byte_t)*3)))

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Read a specified Clock Offset value in the HCI     */
   /* Inquiry Result Event Data.  The first parameter is a pointer to   */
   /* a Data Buffer that is an HCI_Inquiry Result_Event_t.  The second  */
   /* parameter is the Index of the Clock Offset value to read.         */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_INQUIRY_RESULT_EVENT_READ_CLOCK_OFFSET(_x, _y)     \
   READ_UNALIGNED_WORD_LITTLE_ENDIAN((((Byte_t *)((_x)->Variable_Data)) + ((_y)*(sizeof(BD_ADDR_t) + sizeof(Byte_t)*3 + sizeof(Class_of_Device_t) + sizeof(Word_t))) + sizeof(BD_ADDR_t) + sizeof(Byte_t)*3 + sizeof(Class_of_Device_t)))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Connection_Complete_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   NonAlignedWord_t   Connection_Handle;
   BD_ADDR_t          BD_ADDR;
   Byte_t             Link_Type;
   Byte_t             Encryption_Mode;
} __PACKED_STRUCT_END__ HCI_Connection_Complete_Event_t;

#define HCI_CONNECTION_COMPLETE_EVENT_SIZE              (sizeof(HCI_Connection_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Connection_Request_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   BD_ADDR_t          BD_ADDR;
   Class_of_Device_t  Class_of_Device;
   Byte_t             Link_Type;
} __PACKED_STRUCT_END__ HCI_Connection_Request_Event_t;

#define HCI_CONNECTION_REQUEST_EVENT_SIZE               (sizeof(HCI_Connection_Request_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Disconnection_Complete_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   NonAlignedWord_t   Connection_Handle;
   Byte_t             Reason;
} __PACKED_STRUCT_END__ HCI_Disconnection_Complete_Event_t;

#define HCI_DISCONNECTION_COMPLETE_EVENT_SIZE           (sizeof(HCI_Disconnection_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Authentication_Complete_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   NonAlignedWord_t   Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Authentication_Complete_Event_t;

#define HCI_AUTHENTICATION_COMPLETE_EVENT_SIZE          (sizeof(HCI_Authentication_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Remote_Name_Request_Complete_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   BD_ADDR_t          BD_ADDR;
   Byte_t             Variable_Data[1];
} __PACKED_STRUCT_END__ HCI_Remote_Name_Request_Complete_Event_t;

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Determine the size (in Bytes) of an HCI Remote     */
   /* Name Request Complete Event Data Structure based upon the Length  */
   /* of the Name String (in bytes, including the NULL terminating      */
   /* character).  The first parameter to this MACRO is the Length of   */
   /* the Name String (in bytes, including the NULL terminating         */
   /* character).                                                       */
#define HCI_REMOTE_NAME_REQUEST_COMPLETE_EVENT_SIZE(_x) ((sizeof(HCI_Remote_Name_Request_Complete_Event_t) - sizeof(Byte_t)) + ((Byte_t)(_x)*(sizeof(Byte_t))))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Encryption_Change_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   NonAlignedWord_t   Connection_Handle;
   Byte_t             Encryption_Enable;
} __PACKED_STRUCT_END__ HCI_Encryption_Change_Event_t;

#define HCI_ENCRYPTION_CHANGE_EVENT_SIZE                (sizeof(HCI_Encryption_Change_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Change_Connection_Link_Key_Complete_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   NonAlignedWord_t   Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Change_Connection_Link_Key_Complete_Event_t;

#define HCI_CHANGE_CONNECTION_LINK_KEY_COMPLETE_EVENT_SIZE (sizeof(HCI_Change_Connection_Link_Key_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Master_Link_Key_Complete_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   NonAlignedWord_t   Connection_Handle;
   Byte_t             Key_Flag;
} __PACKED_STRUCT_END__ HCI_Master_Link_Key_Complete_Event_t;

#define HCI_MASTER_LINK_KEY_COMPLETE_EVENT_SIZE         (sizeof(HCI_Master_Link_Key_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Remote_Supported_Features_Complete_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   NonAlignedWord_t   Connection_Handle;
   LMP_Features_t     LMP_Features;
} __PACKED_STRUCT_END__ HCI_Read_Remote_Supported_Features_Complete_Event_t;

#define HCI_READ_REMOTE_SUPPORTED_FEATURES_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Remote_Supported_Features_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Remote_Version_Information_Complete_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   NonAlignedWord_t   Connection_Handle;
   Byte_t             LMP_Version;
   NonAlignedWord_t   Manufacturer_Name;
   NonAlignedWord_t   LMP_Subversion;
} __PACKED_STRUCT_END__ HCI_Read_Remote_Version_Information_Complete_Event_t;

#define HCI_READ_REMOTE_VERSION_INFORMATION_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Remote_Version_Information_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_QoS_Setup_Complete_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   NonAlignedWord_t   Connection_Handle;
   Byte_t             Flags;
   Byte_t             Service_Type;
   NonAlignedDWord_t  Token_Rate;
   NonAlignedDWord_t  Peak_Bandwidth;
   NonAlignedDWord_t  Latency;
   NonAlignedDWord_t  Delay_Variation;
} __PACKED_STRUCT_END__ HCI_QoS_Setup_Complete_Event_t;

#define HCI_QOS_SETUP_COMPLETE_EVENT_SIZE               (sizeof(HCI_QoS_Setup_Complete_Event_t))

   /* The following type declaration represents the structure of an HCI */
   /* Command Complete Event Header.  This structure will be present    */
   /* at the beginning of ALL HCI Command Complete Event Packets.       */
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Command_Complete_Event_Header_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Num_HCI_Command_Packets;
   NonAlignedWord_t   Command_OpCode;
} __PACKED_STRUCT_END__ HCI_Command_Complete_Event_Header_t;

#define HCI_COMMAND_COMPLETE_EVENT_HEADER_SIZE          (sizeof(HCI_Command_Complete_Event_Header_t))

   /* The following type declaration represents the structure of an HCI */
   /* Command Status Event.  The first element of this structure is     */
   /* the HCI Event Header (see description above), followed by the     */
   /* data that is unique to this HCI Event Type Structure.             */
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Command_Status_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   Byte_t             Num_HCI_Command_Packets;
   NonAlignedWord_t   Command_OpCode;
} __PACKED_STRUCT_END__ HCI_Command_Status_Event_t;

#define HCI_COMMAND_STATUS_EVENT_SIZE                   (sizeof(HCI_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Hardware_Error_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Hardware_Code;
} __PACKED_STRUCT_END__ HCI_Hardware_Error_Event_t;

#define HCI_HARDWARE_ERROR_EVENT_SIZE                   (sizeof(HCI_Hardware_Error_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Flush_Occurred_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   NonAlignedWord_t   Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Flush_Occurred_Event_t;

#define HCI_FLUSH_OCCURRED_EVENT_SIZE                   (sizeof(HCI_Flush_Occurred_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Role_Change_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   BD_ADDR_t          BD_ADDR;
   Byte_t             New_Role;
} __PACKED_STRUCT_END__ HCI_Role_Change_Event_t;

#define HCI_ROLE_CHANGE_EVENT_SIZE                      (sizeof(HCI_Role_Change_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Number_Of_Completed_Packets_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Number_of_Handles;
   Byte_t             Variable_Data[1];
} __PACKED_STRUCT_END__ HCI_Number_Of_Completed_Packets_Event_t;

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Determine the size (in Bytes) of an                */
   /* HCI Number of Completed Packets Event Data Structure based        */
   /* upon the Number of Connection Handle/Number of Completed Packet   */
   /* Pairs that are specified.  The first parameter to this MACRO is   */
   /* the Number of Connection Handle/Number of Completed Packet Pairs. */
#define HCI_NUMBER_OF_COMPLETED_PACKETS_EVENT_SIZE(_x)  ((sizeof(HCI_Number_Of_Completed_Packets_Event_t) - sizeof(Byte_t)) + ((_x)*(sizeof(Word_t)+sizeof(Word_t))))

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Read a specified Connection Handle in the Number   */
   /* of Completed Packets Event Data.  The first parameter is a pointer*/
   /* to a Data Buffer that is an                                       */
   /* HCI_Number_Of_Completed_Packets_Event_t.  The second parameter is */
   /* the Index of the Connection Handle to Read.                       */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_NUMBER_OF_COMPLETED_PACKETS_EVENT_READ_HANDLE(_x, _y)      \
   READ_UNALIGNED_WORD_LITTLE_ENDIAN((((Byte_t *)((_x)->Variable_Data)) + (_y)*(sizeof(Word_t) + sizeof(Word_t))))

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Read the specified Number of Completed Packets in  */
   /* the Number of Completed Packets Event Data.  The first parameter  */
   /* is a pointer to a Data Buffer that is an                          */
   /* HCI_Number_Of_Completed_Packets_Event_t.  The second parameter is */
   /* the Index of the Number of Completed Packets to Read.             */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_NUMBER_OF_COMPLETED_PACKETS_EVENT_READ_NUM_PACKETS(_x, _y) \
   READ_UNALIGNED_WORD_LITTLE_ENDIAN((((Byte_t *)((_x)->Variable_Data)) + ((_y)*(sizeof(Word_t) + sizeof(Word_t))) + sizeof(Word_t)))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Mode_Change_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   NonAlignedWord_t   Connection_Handle;
   Byte_t             Current_Mode;
   NonAlignedWord_t   Interval;
} __PACKED_STRUCT_END__ HCI_Mode_Change_Event_t;

#define HCI_MODE_CHANGE_EVENT_SIZE                      (sizeof(HCI_Mode_Change_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Return_Link_Keys_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Num_Keys;
   Byte_t             Variable_Data[1];
} __PACKED_STRUCT_END__ HCI_Return_Link_Keys_Event_t;

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Determine the size (in Bytes) of an                */
   /* HCI Return Link Keys Event Data Structure based upon the Number   */
   /* of BD_ADDR/Link Key Pairs that are specified.  The first          */
   /* parameter to this MACRO is the Number of BD_ADDR/Link Key Pairs.  */
#define HCI_RETURN_LINK_KEYS_EVENT_SIZE(_x)             ((sizeof(HCI_Return_Link_Keys_Event_t) - sizeof(Byte_t)) + ((_x)*(sizeof(BD_ADDR_t)+sizeof(Link_Key_t))))

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Read a specified BD_ADDR in the Return Link Keys   */
   /* Event Data.  The first parameter is a pointer to a Data Buffer    */
   /* that is a HCI_Return_Link_Keys_Event_t.  The second parameter is  */
   /* the Index of the BD_ADDR to Read.                                 */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_RETURN_LINK_KEYS_EVENT_READ_BD_ADDR(_x, _y)  \
   READ_UNALIGNED_GENERIC_TYPE(((BD_ADDR_t *)(((Byte_t *)((_x)->Variable_Data)) + ((_y)*(sizeof(BD_ADDR_t) + sizeof(Link_Key_t))))))

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Read the specified Link Key in the Return Link Keys*/
   /* Event Data.of Completed Packets Event Data.  The first parameter  */
   /* Event Data.  The first parameter is a pointer to a Data Buffer    */
   /* that is a HCI_Return_Link_Keys_Event_t.  The second parameter is  */
   /* the Index of the Link Key to Read.                                */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_RETURN_LINK_KEYS_EVENT_READ_LINK_KEY(_x, _y) \
   READ_UNALIGNED_GENERIC_TYPE(((Link_Key_t *)(((Byte_t *)((_x)->Variable_Data)) + ((_y)*(sizeof(BD_ADDR_t) + sizeof(Link_Key_t))) + sizeof(BD_ADDR_t))))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_PIN_Code_Request_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   BD_ADDR_t          BD_ADDR;
} __PACKED_STRUCT_END__ HCI_PIN_Code_Request_Event_t;

#define HCI_PIN_CODE_REQUEST_EVENT_SIZE                 (sizeof(HCI_PIN_Code_Request_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Link_Key_Request_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   BD_ADDR_t          BD_ADDR;
} __PACKED_STRUCT_END__ HCI_Link_Key_Request_Event_t;

#define HCI_LINK_KEY_REQUEST_EVENT_SIZE                 (sizeof(HCI_Link_Key_Request_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Link_Key_Notification_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   BD_ADDR_t          BD_ADDR;
   Link_Key_t         Link_Key;
} __PACKED_STRUCT_END__ HCI_Link_Key_Notification_Event_t;

#define HCI_LINK_KEY_NOTIFICATION_EVENT_SIZE            (sizeof(HCI_Link_Key_Notification_Event_t))

   /* Below is the HCI Link Key Notification Event for the Bluetooth    */
   /* HCI 1.1 Specification (Version 1.1).                              */
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Link_Key_Notification_Event_1_1_t
{
   HCI_Event_Header_t HCI_Event_Header;
   BD_ADDR_t          BD_ADDR;
   Link_Key_t         Link_Key;
   Byte_t             Key_Type;
} __PACKED_STRUCT_END__ HCI_Link_Key_Notification_Event_1_1_t;

#define HCI_LINK_KEY_NOTIFICATION_EVENT_1_1_SIZE        (sizeof(HCI_Link_Key_Notification_Event_1_1_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Loopback_Command_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Variable_Data[1];
} __PACKED_STRUCT_END__ HCI_Loopback_Command_Event_t;

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Determine the size (in Bytes) of an                */
   /* HCI Loopback Command Event Data Structure based upon the size of  */
   /* the HCI Command Data Packet Required.  The first parameter to     */
   /* this MACRO is the Size of the HCI Command Data Packet (in bytes). */
#define HCI_LOOPBACK_COMMAND_EVENT_SIZE(_x)             ((sizeof(HCI_Loopback_Command_Event_t) - sizeof(Byte_t)) + ((unsigned int)(_x)))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Data_Buffer_Overflow_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Link_Type;
} __PACKED_STRUCT_END__ HCI_Data_Buffer_Overflow_Event_t;

#define HCI_DATA_BUFFER_OVERFLOW_EVENT_SIZE             (sizeof(HCI_Data_Buffer_Overflow_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Max_Slots_Change_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   NonAlignedWord_t   Connection_Handle;
   Byte_t             LMP_Max_Slots;
} __PACKED_STRUCT_END__ HCI_Max_Slots_Change_Event_t;

#define HCI_MAX_SLOTS_CHANGE_EVENT_SIZE                 (sizeof(HCI_Max_Slots_Change_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Clock_Offset_Complete_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   NonAlignedWord_t   Connection_Handle;
   NonAlignedWord_t   Clock_Offset;
} __PACKED_STRUCT_END__ HCI_Read_Clock_Offset_Complete_Event_t;

#define HCI_READ_CLOCK_OFFSET_COMPLETE_EVENT_SIZE       (sizeof(HCI_Read_Clock_Offset_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Connection_Packet_Type_Changed_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   NonAlignedWord_t   Connection_Handle;
   NonAlignedWord_t   Packet_Type;
} __PACKED_STRUCT_END__ HCI_Connection_Packet_Type_Changed_Event_t;

#define HCI_CONNECTION_PACKET_TYPE_CHANGED_EVENT_SIZE   (sizeof(HCI_Connection_Packet_Type_Changed_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_QoS_Violation_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   NonAlignedWord_t   Connection_Handle;
} __PACKED_STRUCT_END__ HCI_QoS_Violation_Event_t;

#define HCI_QOS_VIOLATION_EVENT_SIZE                    (sizeof(HCI_QoS_Violation_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Page_Scan_Mode_Change_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   BD_ADDR_t          BD_ADDR;
   Byte_t             Page_Scan_Mode;
} __PACKED_STRUCT_END__ HCI_Page_Scan_Mode_Change_Event_t;

#define HCI_PAGE_SCAN_MODE_CHANGE_EVENT_SIZE            (sizeof(HCI_Page_Scan_Mode_Change_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Page_Scan_Repetition_Mode_Change_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   BD_ADDR_t          BD_ADDR;
   Byte_t             Page_Scan_Repetition_Mode;
} __PACKED_STRUCT_END__ HCI_Page_Scan_Repetition_Mode_Change_Event_t;

#define HCI_PAGE_SCAN_REPETITION_MODE_CHANGE_EVENT_SIZE (sizeof(HCI_Page_Scan_Repetition_Mode_Change_Event_t))

   /* The following events represent the new Events that are part of    */
   /* Bluetooth Version 1.2.                                            */
   
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Flow_Specification_Complete_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   NonAlignedWord_t   Connection_Handle;
   Byte_t             Flags;
   Byte_t             Flow_Direction;
   Byte_t             Service_Type;
   NonAlignedDWord_t  Token_Rate;
   NonAlignedDWord_t  Token_Bucket_Size;
   NonAlignedDWord_t  Peak_Bandwidth;
   NonAlignedDWord_t  Access_Latency;
} __PACKED_STRUCT_END__ HCI_Flow_Specification_Complete_Event_t;

#define HCI_FLOW_SPECIFICATION_COMPLETE_EVENT_SIZE      (sizeof(HCI_Flow_Specification_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Inquiry_Result_With_RSSI_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Num_Responses;
   Byte_t             Variable_Data[1];
} __PACKED_STRUCT_END__ HCI_Inquiry_Result_With_RSSI_Event_t;

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Determine the size (in Bytes) of an HCI Inquiry    */
   /* Result With RSSI Event Data Structure based upon the Number of    */
   /* Responses.  The first parameter of this MACRO is the Number of    */
   /* Responses.                                                        */
#define HCI_INQUIRY_RESULT_WITH_RSSI_EVENT_SIZE(_x)     ((sizeof(HCI_Inquiry_Result_With_RSSI_Event_t) - sizeof(Byte_t)) + ((_x)*(sizeof(BD_ADDR_t)+sizeof(Byte_t)+sizeof(Byte_t)+sizeof(Class_of_Device_t)+sizeof(Word_t)+sizeof(Byte_t))))

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Read a specified BD_ADDR in the HCI Inquiry Result */
   /* With RSSI Event Data.  The first parameter is a pointer to a Data */
   /* Buffer that is an HCI_Inquiry_Result_With_RSSI_Event_t.  The      */
   /* Second parameter is the Index of the BD_ADDR to Read.             */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_INQUIRY_RESULT_WITH_RSSI_EVENT_READ_BD_ADDR(_x, _y)          \
   READ_UNALIGNED_GENERIC_TYPE(((BD_ADDR_t *)(((Byte_t *)((_x)->Variable_Data)) + (_y)*(sizeof(BD_ADDR_t) + sizeof(Byte_t)*3 + sizeof(Class_of_Device_t) + sizeof(Word_t)))))
   
   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Read a specified Page Scan Repetition Mode value in*/
   /* the HCI Inquiry Result With RSSI Event Data.  The first parameter */
   /* is a pointer to a Data Buffer that is an                          */
   /* HCI_Inquiry_Result_With_RSSI_Event_t.  The Second parameter is the*/
   /* Index of the Page Scan Repetition Mode Value to Read.             */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_INQUIRY_RESULT_WITH_RSSI_EVENT_READ_REPETITION_MODE(_x, _y)  \
   READ_UNALIGNED_BYTE_LITTLE_ENDIAN(((Byte_t *)(((Byte_t *)((_x)->Variable_Data)) + ((_y)*(sizeof(BD_ADDR_t) + sizeof(Byte_t)*3 + sizeof(Class_of_Device_t) + sizeof(Word_t))) + sizeof(BD_ADDR_t))))

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Read a specified Page Scan Period Mode value in the*/
   /* HCI Inquiry Result With RSSI Event Data.  The first parameter is a*/
   /* pointer to a Data Buffer that is an                               */
   /* HCI_Inquiry_Result_With_RSSI_Event_t.  The Second parameter is the*/
   /* Index of the Page Scan Period Mode Value to Read.                 */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_INQUIRY_RESULT_WITH_RSSI_EVENT_READ_PERIOD_MODE(_x, _y)      \
   READ_UNALIGNED_BYTE_LITTLE_ENDIAN(((Byte_t *)(((Byte_t *)((_x)->Variable_Data)) + ((_y)*(sizeof(BD_ADDR_t) + sizeof(Byte_t)*3 + sizeof(Class_of_Device_t) + sizeof(Word_t))) + sizeof(BD_ADDR_t) + sizeof(Byte_t))))

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Read a specified Class of Device value in the HCI  */
   /* Inquiry Result With RSSI Event Data.  The first parameter is a    */
   /* pointer to a Data Buffer that is an                               */
   /* HCI_Inquiry_Result_With_RSSI_Event_t.  The second parameter is the*/
   /* Index of the Class of Device value to read.                       */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_INQUIRY_RESULT_WITH_RSSI_EVENT_READ_CLASS_OF_DEVICE(_x, _y)  \
   READ_UNALIGNED_GENERIC_TYPE(((Class_of_Device_t *)(((Byte_t *)((_x)->Variable_Data)) + ((_y)*(sizeof(BD_ADDR_t) + sizeof(Byte_t)*3 + sizeof(Class_of_Device_t) + sizeof(Word_t))) + sizeof(BD_ADDR_t) + sizeof(Byte_t)*2)))

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Read a specified Clock Offset value in the HCI     */
   /* Inquiry Result With RSSI Event Data.  The first parameter is a    */
   /* pointer to a Data Buffer that is an                               */
   /* HCI_Inquiry_Result_With_RSSI_Event_t.  The second parameter is the*/
   /* Index of the Clock Offset value to read.                          */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_INQUIRY_RESULT_WITH_RSSI_EVENT_READ_CLOCK_OFFSET(_x, _y)     \
   READ_UNALIGNED_WORD_LITTLE_ENDIAN((((Byte_t *)((_x)->Variable_Data)) + ((_y)*(sizeof(BD_ADDR_t) + sizeof(Byte_t)*3 + sizeof(Class_of_Device_t) + sizeof(Word_t))) + sizeof(BD_ADDR_t) + sizeof(Byte_t)*2 + sizeof(Class_of_Device_t)))
   
   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Read a specified RSSI value in the HCI Inquiry     */
   /* Result With RSSI Event Data.  The first parameter is a pointer to */
   /* a Data Buffer that is an HCI_Inquiry_Result_With_RSSI_Event_t.    */
   /* The second parameter is the Index of the RSSI value to read.      */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_INQUIRY_RESULT_WITH_RSSI_EVENT_READ_RSSI(_x, _y)     \
   READ_UNALIGNED_BYTE_LITTLE_ENDIAN((((Byte_t *)((_x)->Variable_Data)) + ((_y)*(sizeof(BD_ADDR_t) + sizeof(Byte_t)*3 + sizeof(Class_of_Device_t) + sizeof(Word_t))) + sizeof(BD_ADDR_t) + sizeof(Byte_t)*2 + sizeof(Class_of_Device_t) + sizeof(Word_t)))
   
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Remote_Extended_Features_Complete_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   NonAlignedWord_t   Connection_Handle;
   Byte_t             Page_Number;
   Byte_t             Maximum_Page_Number;
   LMP_Features_t     Extended_LMP_Features;
} __PACKED_STRUCT_END__ HCI_Read_Remote_Extended_Features_Complete_Event_t;

#define HCI_READ_REMOTE_EXTENDED_FEATURES_COMPLETE_EVENT_SIZE  (sizeof(HCI_Read_Remote_Extended_Features_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Synchronous_Connection_Complete_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   NonAlignedWord_t   Connection_Handle;
   BD_ADDR_t          BD_ADDR;
   Byte_t             Link_Type;
   Byte_t             Transmission_Interval;
   Byte_t             Retransmission_Window;
   NonAlignedWord_t   Rx_Packet_Length;
   NonAlignedWord_t   Tx_Packet_Length;
   Byte_t             Air_Mode;
} __PACKED_STRUCT_END__ HCI_Synchronous_Connection_Complete_Event_t;

#define HCI_SYNCHRONOUS_CONNECTION_COMPLETE_EVENT_SIZE  (sizeof(HCI_Synchronous_Connection_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Synchronous_Connection_Changed_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   NonAlignedWord_t   Connection_Handle;
   Byte_t             Transmission_Interval;
   Byte_t             Retransmission_Window;
   NonAlignedWord_t   Rx_Packet_Length;
   NonAlignedWord_t   Tx_Packet_Length;
} __PACKED_STRUCT_END__ HCI_Synchronous_Connection_Changed_Event_t;

#define HCI_SYNCHRONOUS_CONNECTION_CHANGED_EVENT_SIZE   (sizeof(HCI_Synchronous_Connection_Changed_Event_t))

   /* The following events represent the new Events that are part of    */
   /* Bluetooth Version 2.1.                                            */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Sniff_Subrating_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   NonAlignedWord_t   Connection_Handle;
   NonAlignedWord_t   Maximum_Transmit_Latency;
   NonAlignedWord_t   Maximum_Receive_Latency;
   NonAlignedWord_t   Minimum_Remote_Timeout;
   NonAlignedWord_t   Minimum_Local_Timeout;
} __PACKED_STRUCT_END__ HCI_Sniff_Subrating_Event_t;

#define HCI_SNIFF_SUBRATING_EVENT_SIZE                   (sizeof(HCI_Sniff_Subrating_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Extended_Inquiry_Result_Event_t
{
   HCI_Event_Header_t               HCI_Event_Header;
   Byte_t                           Num_Responses;
   BD_ADDR_t                        BD_ADDR;
   Byte_t                           Page_Scan_Repetition_Mode;
   Byte_t                           Reserved;
   Class_of_Device_t                Class_of_Device;
   NonAlignedWord_t                 Clock_Offset;
   Byte_t                           RSSI;
   Extended_Inquiry_Response_Data_t Extended_Inquiry_Response;
} __PACKED_STRUCT_END__ HCI_Extended_Inquiry_Result_Event_t;

#define HCI_EXTENDED_INQUIRY_RESULT_EVENT_SIZE           (sizeof(HCI_Extended_Inquiry_Result_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Encryption_Key_Refresh_Complete_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   NonAlignedWord_t   Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Encryption_Key_Refresh_Complete_Event_t;

#define HCI_ENCRYPTION_KEY_REFRESH_COMPLETE_EVENT_SIZE   (sizeof(HCI_Encryption_Key_Refresh_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_IO_Capability_Request_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   BD_ADDR_t          BD_ADDR;
} __PACKED_STRUCT_END__ HCI_IO_Capability_Request_Event_t;

#define HCI_IO_CAPABILITY_REQUEST_EVENT_SIZE             (sizeof(HCI_IO_Capability_Request_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_IO_Capability_Response_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   BD_ADDR_t          BD_ADDR;
   Byte_t             IO_Capability;
   Byte_t             OOB_Data_Present;
   Byte_t             Authentication_Requirements;
} __PACKED_STRUCT_END__ HCI_IO_Capability_Response_Event_t;

#define HCI_IO_CAPABILITY_RESPONSE_EVENT_SIZE            (sizeof(HCI_IO_Capability_Response_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_User_Confirmation_Request_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   BD_ADDR_t          BD_ADDR;
   NonAlignedDWord_t  Numeric_Value;
} __PACKED_STRUCT_END__ HCI_User_Confirmation_Request_Event_t;

#define HCI_USER_CONFIRMATION_REQUEST_EVENT_SIZE         (sizeof(HCI_User_Confirmation_Request_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_User_Passkey_Request_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   BD_ADDR_t          BD_ADDR;
} __PACKED_STRUCT_END__ HCI_User_Passkey_Request_Event_t;

#define HCI_USER_PASSKEY_REQUEST_EVENT_SIZE              (sizeof(HCI_User_Passkey_Request_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Remote_OOB_Data_Request_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   BD_ADDR_t          BD_ADDR;
} __PACKED_STRUCT_END__ HCI_Remote_OOB_Data_Request_Event_t;

#define HCI_REMOTE_OOB_DATA_REQUEST_EVENT_SIZE           (sizeof(HCI_Remote_OOB_Data_Request_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Simple_Pairing_Complete_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Status;
   BD_ADDR_t          BD_ADDR;
} __PACKED_STRUCT_END__ HCI_Simple_Pairing_Complete_Event_t;

#define HCI_SIMPLE_PAIRING_COMPLETE_EVENT_SIZE           (sizeof(HCI_Simple_Pairing_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Link_Supervision_Timeout_Changed_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   NonAlignedWord_t   Connection_Handle;
   NonAlignedWord_t   Link_Supervision_Timeout;
} __PACKED_STRUCT_END__ HCI_Link_Supervision_Timeout_Changed_Event_t;

#define HCI_LINK_SUPERVISION_TIMEOUT_CHANGED_EVENT_SIZE  (sizeof(HCI_Link_Supervision_Timeout_Changed_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Enhanced_Flush_Complete_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   NonAlignedWord_t   Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Enhanced_Flush_Complete_Event_t;

#define HCI_ENHANCED_FLUSH_COMPLETE_EVENT_SIZE           (sizeof(HCI_Enhanced_Flush_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_User_Passkey_Notification_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   BD_ADDR_t          BD_ADDR;
   NonAlignedDWord_t  Passkey;
} __PACKED_STRUCT_END__ HCI_User_Passkey_Notification_Event_t;

#define HCI_USER_PASSKEY_NOTIFICATION_EVENT_SIZE         (sizeof(HCI_User_Passkey_Notification_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Keypress_Notification_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   BD_ADDR_t          BD_ADDR;
   Byte_t             Notification_Type;
} __PACKED_STRUCT_END__ HCI_Keypress_Notification_Event_t;

#define HCI_KEYPRESS_NOTIFICATION_EVENT_SIZE             (sizeof(HCI_Keypress_Notification_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Remote_Host_Supported_Features_Notification_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   BD_ADDR_t          BD_ADDR;
   LMP_Features_t     Host_Supported_Features;
} __PACKED_STRUCT_END__ HCI_Remote_Host_Supported_Features_Notification_Event_t;

#define HCI_REMOTE_HOST_SUPPORTED_FEATURES_NOTIFICATION_EVENT_SIZE   (sizeof(HCI_Remote_Host_Supported_Features_Notification_Event_t))

   /* Miscellaneous Event Types (Version 1.1).                          */
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Bluetooth_Logo_Testing_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Variable_Data[1];
} __PACKED_STRUCT_END__ HCI_Bluetooth_Logo_Testing_Event_t;

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Determine the size (in Bytes) of an                */
   /* HCI Bluetooth Logo Testing Event Data Structure based upon the    */
   /* size of Total Number of Bytes required for the Parameters.  The   */
   /* first parameter to this MACRO is the Size (in Bytes) of the       */
   /* Bluetooth Logo Testing Event Packet Parameters (total).           */
#define HCI_BLUETOOTH_LOGO_TESTING_EVENT_SIZE(_x)       ((sizeof(HCI_Bluetooth_Logo_Testing_Event_t) - sizeof(Byte_t)) + ((unsigned int)(_x)))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Vendor_Specific_Debug_Event_t
{
   HCI_Event_Header_t HCI_Event_Header;
   Byte_t             Variable_Data[1];
} __PACKED_STRUCT_END__ HCI_Vendor_Specific_Debug_Event_t;

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Determine the size (in Bytes) of an                */
   /* HCI Vendor Specific Debug Event Data Structure based upon the     */
   /* size of Total Number of Bytes required for the Parameters.  The   */
   /* first parameter to this MACRO is the Size (in Bytes) of the       */
   /* Vendor Specific Debug Event Packet Parameters (total).            */
#define HCI_VENDOR_SPECIFIC_DEBUG_EVENT_SIZE(_x)        ((sizeof(HCI_Vendor_Specific_Debug_Event_t) - sizeof(Byte_t)) + ((unsigned int)(_x)))

   /* HCI Command Complete Event Definitions (Link Control).            */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Inquiry_Cancel_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Inquiry_Cancel_Command_Complete_Event_t;

#define HCI_INQUIRY_CANCEL_COMMAND_COMPLETE_EVENT_SIZE  (sizeof(HCI_Inquiry_Cancel_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Periodic_Inquiry_Mode_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Periodic_Inquiry_Mode_Command_Complete_Event_t;

#define HCI_PERIODIC_INQUIRY_MODE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Periodic_Inquiry_Mode_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Exit_Periodic_Inquiry_Mode_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Exit_Periodic_Inquiry_Mode_Command_Complete_Event_t;

#define HCI_EXIT_PERIODIC_INQUIRY_MODE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Exit_Periodic_Inquiry_Mode_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Link_Key_Request_Reply_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   BD_ADDR_t                           BD_ADDR;
} __PACKED_STRUCT_END__ HCI_Link_Key_Request_Reply_Command_Complete_Event_t;

#define HCI_LINK_KEY_REQUEST_REPLY_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Link_Key_Request_Reply_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Link_Key_Request_Negative_Reply_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   BD_ADDR_t                           BD_ADDR;
} __PACKED_STRUCT_END__ HCI_Link_Key_Request_Negative_Reply_Command_Complete_Event_t;

#define HCI_LINK_KEY_REQUEST_NEGATIVE_REPLY_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Link_Key_Request_Negative_Reply_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_PIN_Code_Request_Reply_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   BD_ADDR_t                           BD_ADDR;
} __PACKED_STRUCT_END__ HCI_PIN_Code_Request_Reply_Command_Complete_Event_t;

#define HCI_PIN_CODE_REQUEST_REPLY_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_PIN_Code_Request_Reply_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_PIN_Code_Request_Negative_Reply_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   BD_ADDR_t                           BD_ADDR;
} __PACKED_STRUCT_END__ HCI_PIN_Code_Request_Negative_Reply_Command_Complete_Event_t;

#define HCI_PIN_CODE_REQUEST_NEGATIVE_REPLY_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_PIN_Code_Request_Negative_Reply_Command_Complete_Event_t))

   /* HCI Command Complete Event Definitions (Link Control - Version    */
   /* 1.2).                                                             */
   
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Create_Connection_Cancel_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   BD_ADDR_t                           BD_ADDR;
} __PACKED_STRUCT_END__ HCI_Create_Connection_Cancel_Command_Complete_Event_t;

#define HCI_CREATE_CONNECTION_CANCEL_COMMAND_COMPLETE_EVENT_SIZE  (sizeof(HCI_Create_Connection_Cancel_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Remote_Name_Request_Cancel_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   BD_ADDR_t                           BD_ADDR;
} __PACKED_STRUCT_END__ HCI_Remote_Name_Request_Cancel_Command_Complete_Event_t;

#define HCI_REMOTE_NAME_REQUEST_CANCEL_COMMAND_COMPLETE_EVENT_SIZE  (sizeof(HCI_Remote_Name_Request_Cancel_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_LMP_Handle_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Word_t                              Connection_Handle;
   Byte_t                              LMP_Handle;
   NonAlignedDWord_t                   Reserved;
} __PACKED_STRUCT_END__ HCI_Read_LMP_Handle_Command_Complete_Event_t;

#define HCI_READ_LMP_HANDLE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_LMP_Handle_Command_Complete_Event_t))

   /* HCI Command Complete Event Definitions (Link Control - Version    */
   /* 2.1).                                                             */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_IO_Capability_Request_Reply_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Event_Header;
   Byte_t                              Status;
   BD_ADDR_t                           BD_ADDR;
} __PACKED_STRUCT_END__ HCI_IO_Capability_Request_Reply_Command_Complete_Event_t;

#define HCI_IO_CAPABILITY_REQUEST_REPLY_COMMAND_COMPLETE_EVENT_SIZE  (sizeof(HCI_IO_Capability_Request_Reply_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_User_Confirmation_Request_Reply_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Event_Header;
   Byte_t                              Status;
   BD_ADDR_t                           BD_ADDR;
} __PACKED_STRUCT_END__ HCI_User_Confirmation_Request_Reply_Command_Complete_Event_t;

#define HCI_USER_CONFIRMATION_REQUEST_REPLY_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_User_Confirmation_Request_Reply_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_User_Confirmation_Request_Negative_Reply_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Event_Header;
   Byte_t                              Status;
   BD_ADDR_t                           BD_ADDR;
} __PACKED_STRUCT_END__ HCI_User_Confirmation_Request_Negative_Reply_Command_Complete_Event_t;

#define HCI_USER_CONFIRMATION_REQUEST_NEGATIVE_REPLY_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_User_Confirmation_Request_Negative_Reply_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_User_Passkey_Request_Reply_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Event_Header;
   Byte_t                              Status;
   BD_ADDR_t                           BD_ADDR;
} __PACKED_STRUCT_END__ HCI_User_Passkey_Request_Reply_Command_Complete_Event_t;

#define HCI_USER_PASSKEY_REQUEST_REPLY_COMMAND_COMPLETE_EVENT_SIZE   (sizeof(HCI_User_Passkey_Request_Reply_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_User_Passkey_Request_Negative_Reply_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Event_Header;
   Byte_t                              Status;
   BD_ADDR_t                           BD_ADDR;
} __PACKED_STRUCT_END__ HCI_User_Passkey_Request_Negative_Reply_Command_Complete_Event_t;

#define HCI_USER_PASSKEY_REQUEST_NEGATIVE_REPLY_COMMAND_COMPLETE_EVENT_SIZE   (sizeof(HCI_User_Passkey_Request_Negative_Reply_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Remote_OOB_Data_Request_Reply_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Event_Header;
   Byte_t                              Status;
   BD_ADDR_t                           BD_ADDR;
} __PACKED_STRUCT_END__ HCI_Remote_OOB_Data_Request_Reply_Command_Complete_Event_t;

#define HCI_REMOTE_OOB_DATA_REQUEST_REPLY_COMMAND_COMPLETE_EVENT_SIZE   (sizeof(HCI_Remote_OOB_Data_Request_Reply_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Remote_OOB_Data_Request_Negative_Reply_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Event_Header;
   Byte_t                              Status;
   BD_ADDR_t                           BD_ADDR;
} __PACKED_STRUCT_END__ HCI_Remote_OOB_Data_Request_Negative_Reply_Command_Complete_Event_t;

#define HCI_REMOTE_OOB_DATA_REQUEST_NEGATIVE_REPLY_COMMAND_COMPLETE_EVENT_SIZE   (sizeof(HCI_Remote_OOB_Data_Request_Negative_Reply_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_IO_Capability_Request_Negative_Reply_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Event_Header;
   Byte_t                              Status;
   BD_ADDR_t                           BD_ADDR;
} __PACKED_STRUCT_END__ HCI_IO_Capability_Request_Negative_Reply_Command_Complete_Event_t;

#define HCI_IO_CAPABILITY_REQUEST_NEGATIVE_REPLY_COMMAND_COMPLETE_EVENT_SIZE  (sizeof(HCI_IO_Capability_Request_Negative_Reply_Command_Complete_Event_t))

   /* HCI Command Complete Event Definitions (Link Policy).             */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Role_Discovery_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Connection_Handle;
   Byte_t                              Current_Role;
} __PACKED_STRUCT_END__ HCI_Role_Discovery_Command_Complete_Event_t;

#define HCI_ROLE_DISCOVERY_COMMAND_COMPLETE_EVENT_SIZE  (sizeof(HCI_Role_Discovery_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Link_Policy_Settings_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Connection_Handle;
   NonAlignedWord_t                    Link_Policy_Settings;
} __PACKED_STRUCT_END__ HCI_Read_Link_Policy_Settings_Command_Complete_Event_t;

#define HCI_READ_LINK_POLICY_SETTINGS_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Link_Policy_Settings_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Link_Policy_Settings_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Write_Link_Policy_Settings_Command_Complete_Event_t;

#define HCI_WRITE_LINK_POLICY_SETTINGS_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Link_Policy_Settings_Command_Complete_Event_t))

   /* HCI Command Complete Event Definitions (Link Policy - Version     */
   /* 1.2).                                                             */
   
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Default_Link_Policy_Settings_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Link_Policy_Settings;
} __PACKED_STRUCT_END__ HCI_Read_Default_Link_Policy_Settings_Command_Complete_Event_t;

#define HCI_READ_DEFAULT_LINK_POLICY_SETTINGS_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Default_Link_Policy_Settings_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Default_Link_Policy_Settings_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Default_Link_Policy_Settings_Command_Complete_Event_t;

#define HCI_WRITE_DEFAULT_LINK_POLICY_SETTINGS_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Default_Link_Policy_Settings_Command_Complete_Event_t))

   /* HCI Command Complete Event Definitions (Link Policy - Version     */
   /* 2.1).                                                             */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Sniff_Subrating_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Sniff_Subrating_Command_Complete_Event_t;

#define HCI_SNIFF_SUBRATING_COMMAND_COMPLETE_EVENT_SIZE  (sizeof(HCI_Sniff_Subrating_Command_Complete_Event_t))

   /* HCI Command Complete Event Definitions (Host Control and          */
   /* Baseband).                                                        */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Set_Event_Mask_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Set_Event_Mask_Command_Complete_Event_t;

#define HCI_SET_EVENT_MASK_COMMAND_COMPLETE_EVENT_SIZE  (sizeof(HCI_Set_Event_Mask_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Reset_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Reset_Command_Complete_Event_t;

#define HCI_RESET_COMMAND_COMPLETE_EVENT_SIZE           (sizeof(HCI_Reset_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Set_Event_Filter_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Set_Event_Filter_Command_Complete_Event_t;

#define HCI_SET_EVENT_FILTER_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Set_Event_Filter_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Flush_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Flush_Command_Complete_Event_t;

#define HCI_FLUSH_COMMAND_COMPLETE_EVENT_SIZE           (sizeof(HCI_Flush_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_PIN_Type_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Byte_t                              PIN_Type;
} __PACKED_STRUCT_END__ HCI_Read_PIN_Type_Command_Complete_Event_t;

#define HCI_READ_PIN_TYPE_COMMAND_COMPLETE_EVENT_SIZE   (sizeof(HCI_Read_PIN_Type_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_PIN_Type_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_PIN_Type_Command_Complete_Event_t;

#define HCI_WRITE_PIN_TYPE_COMMAND_COMPLETE_EVENT_SIZE  (sizeof(HCI_Write_PIN_Type_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Create_New_Unit_Key_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Create_New_Unit_Key_Command_Complete_Event_t;

#define HCI_CREATE_NEW_UNIT_KEY_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Create_New_Unit_Key_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Stored_Link_Key_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Max_Num_Keys;
   NonAlignedWord_t                    Num_Keys_Read;
} __PACKED_STRUCT_END__ HCI_Read_Stored_Link_Key_Command_Complete_Event_t;

#define HCI_READ_STORED_LINK_KEY_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Stored_Link_Key_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Stored_Link_Key_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Byte_t                              Num_Keys_Written;
} __PACKED_STRUCT_END__ HCI_Write_Stored_Link_Key_Command_Complete_Event_t;

#define HCI_WRITE_STORED_LINK_KEY_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Stored_Link_Key_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Delete_Stored_Link_Key_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Num_Keys_Deleted;
} __PACKED_STRUCT_END__ HCI_Delete_Stored_Link_Key_Command_Complete_Event_t;

#define HCI_DELETE_STORED_LINK_KEY_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Delete_Stored_Link_Key_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Change_Local_Name_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Change_Local_Name_Command_Complete_Event_t;

#define HCI_CHANGE_LOCAL_NAME_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Change_Local_Name_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Local_Name_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Byte_t                              Variable_Data[1];
} __PACKED_STRUCT_END__ HCI_Read_Local_Name_Command_Complete_Event_t;

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Determine the size (in Bytes) of an HCI Read       */
   /* Local Name Command Complete Event Data Structure based upon the   */
   /* Length of the Name String (in bytes, including the NULL           */
   /* terminating character).  The first parameter to this MACRO is the */
   /* Length of the Name String (in bytes, including the NULL           */
   /* terminating character).                                           */
#define HCI_READ_LOCAL_NAME_COMMAND_COMPLETE_EVENT_SIZE(_x) ((sizeof(HCI_Read_Local_Name_Command_Complete_Event_t) - sizeof(Byte_t)) + ((unsigned int)(_x)))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Connection_Accept_Timeout_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Conn_Accept_Timeout;
} __PACKED_STRUCT_END__ HCI_Read_Connection_Accept_Timeout_Command_Complete_Event_t;

#define HCI_READ_CONNECTION_ACCEPT_TIMEOUT_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Connection_Accept_Timeout_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Connection_Accept_Timeout_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Connection_Accept_Timeout_Command_Complete_Event_t;

#define HCI_WRITE_CONNECTION_ACCEPT_TIMEOUT_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Connection_Accept_Timeout_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Page_Timeout_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Page_Timeout;
} __PACKED_STRUCT_END__ HCI_Read_Page_Timeout_Command_Complete_Event_t;

#define HCI_READ_PAGE_TIMEOUT_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Page_Timeout_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Page_Timeout_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Page_Timeout_Command_Complete_Event_t;

#define HCI_WRITE_PAGE_TIMEOUT_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Page_Timeout_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Scan_Enable_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Byte_t                              Scan_Enable;
} __PACKED_STRUCT_END__ HCI_Read_Scan_Enable_Command_Complete_Event_t;

#define HCI_READ_SCAN_ENABLE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Scan_Enable_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Scan_Enable_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Scan_Enable_Command_Complete_Event_t;

#define HCI_WRITE_SCAN_ENABLE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Scan_Enable_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Page_Scan_Activity_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Page_Scan_Interval;
   NonAlignedWord_t                    Page_Scan_Window;
} __PACKED_STRUCT_END__ HCI_Read_Page_Scan_Activity_Command_Complete_Event_t;

#define HCI_READ_PAGE_SCAN_ACTIVITY_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Page_Scan_Activity_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Page_Scan_Activity_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Page_Scan_Activity_Command_Complete_Event_t;

#define HCI_WRITE_PAGE_SCAN_ACTIVITY_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Page_Scan_Activity_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Inquiry_Scan_Activity_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Inquiry_Scan_Interval;
   NonAlignedWord_t                    Inquiry_Scan_Window;
} __PACKED_STRUCT_END__ HCI_Read_Inquiry_Scan_Activity_Command_Complete_Event_t;

#define HCI_READ_INQUIRY_SCAN_ACTIVITY_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Inquiry_Scan_Activity_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Inquiry_Scan_Activity_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Inquiry_Scan_Activity_Command_Complete_Event_t;

#define HCI_WRITE_INQUIRY_SCAN_ACTIVITY_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Inquiry_Scan_Activity_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Authentication_Enable_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Byte_t                              Authentication_Enable;
} __PACKED_STRUCT_END__ HCI_Read_Authentication_Enable_Command_Complete_Event_t;

#define HCI_READ_AUTHENTICATION_ENABLE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Authentication_Enable_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Authentication_Enable_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Authentication_Enable_Command_Complete_Event_t;

#define HCI_WRITE_AUTHENTICATION_ENABLE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Authentication_Enable_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Encryption_Mode_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Byte_t                              Encryption_Mode;
} __PACKED_STRUCT_END__ HCI_Read_Encryption_Mode_Command_Complete_Event_t;

#define HCI_READ_ENCRYPTION_MODE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Encryption_Mode_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Encryption_Mode_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Encryption_Mode_Command_Complete_Event_t;

#define HCI_WRITE_ENCRYPTION_MODE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Encryption_Mode_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Class_of_Device_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Class_of_Device_t                   Class_of_Device;
} __PACKED_STRUCT_END__ HCI_Read_Class_of_Device_Command_Complete_Event_t;

#define HCI_READ_CLASS_OF_DEVICE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Class_of_Device_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Class_of_Device_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Class_of_Device_Command_Complete_Event_t;

#define HCI_WRITE_CLASS_OF_DEVICE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Class_of_Device_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Voice_Setting_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Voice_Setting;
} __PACKED_STRUCT_END__ HCI_Read_Voice_Setting_Command_Complete_Event_t;

#define HCI_READ_VOICE_SETTING_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Voice_Setting_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Voice_Setting_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Voice_Setting_Command_Complete_Event_t;

#define HCI_WRITE_VOICE_SETTING_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Voice_Setting_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Automatic_Flush_Timeout_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Connection_Handle;
   NonAlignedWord_t                    Flush_Timeout;
} __PACKED_STRUCT_END__ HCI_Read_Automatic_Flush_Timeout_Command_Complete_Event_t;

#define HCI_READ_AUTOMATIC_FLUSH_TIMEOUT_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Automatic_Flush_Timeout_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Automatic_Flush_Timeout_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Write_Automatic_Flush_Timeout_Command_Complete_Event_t;

#define HCI_WRITE_AUTOMATIC_FLUSH_TIMEOUT_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Automatic_Flush_Timeout_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Num_Broadcast_Retransmissions_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Byte_t                              Num_Broadcast_Retran;
} __PACKED_STRUCT_END__ HCI_Read_Num_Broadcast_Retransmissions_Command_Complete_Event_t;

#define HCI_READ_NUM_BROADCAST_RETRANSMISSIONS_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Num_Broadcast_Retransmissions_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Num_Broadcast_Retransmissions_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Num_Broadcast_Retransmissions_Command_Complete_Event_t;

#define HCI_WRITE_NUM_BROADCAST_RETRANSMISSIONS_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Num_Broadcast_Retransmissions_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Hold_Mode_Activity_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Byte_t                              Hold_Mode_Activity;
} __PACKED_STRUCT_END__ HCI_Read_Hold_Mode_Activity_Command_Complete_Event_t;

#define HCI_READ_HOLD_MODE_ACTIVITY_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Hold_Mode_Activity_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Hold_Mode_Activity_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Hold_Mode_Activity_Command_Complete_Event_t;

#define HCI_WRITE_HOLD_MODE_ACTIVITY_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Hold_Mode_Activity_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Transmit_Power_Level_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Connection_Handle;
   Byte_t                              Transmit_Power_Level;
} __PACKED_STRUCT_END__ HCI_Read_Transmit_Power_Level_Command_Complete_Event_t;

#define HCI_READ_TRANSMIT_POWER_LEVEL_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Transmit_Power_Level_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_SCO_Flow_Control_Enable_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Byte_t                              SCO_Flow_Control_Enable;
} __PACKED_STRUCT_END__ HCI_Read_SCO_Flow_Control_Enable_Command_Complete_Event_t;

#define HCI_READ_SCO_FLOW_CONTROL_ENABLE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_SCO_Flow_Control_Enable_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_SCO_Flow_Control_Enable_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_SCO_Flow_Control_Enable_Command_Complete_Event_t;

#define HCI_WRITE_SCO_FLOW_CONTROL_ENABLE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_SCO_Flow_Control_Enable_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Set_Host_Controller_To_Host_Flow_Control_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Set_Host_Controller_To_Host_Flow_Control_Command_Complete_Event_t;

#define HCI_SET_HOST_CONTROLLER_TO_HOST_FLOW_CONTROL_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Set_Host_Controller_To_Host_Flow_Control_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Host_Buffer_Size_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Host_Buffer_Size_Command_Complete_Event_t;

#define HCI_HOST_BUFFER_SIZE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Host_Buffer_Size_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Host_Number_Of_Completed_Packets_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Host_Number_Of_Completed_Packets_Command_Complete_Event_t;

#define HCI_HOST_NUMBER_OF_COMPLETED_PACKETS_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Host_Number_Of_Completed_Packets_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Link_Supervision_Timeout_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Connection_Handle;
   NonAlignedWord_t                    Link_Supervision_Timeout;
} __PACKED_STRUCT_END__ HCI_Read_Link_Supervision_Timeout_Command_Complete_Event_t;

#define HCI_READ_LINK_SUPERVISION_TIMEOUT_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Link_Supervision_Timeout_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Link_Supervision_Timeout_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Write_Link_Supervision_Timeout_Command_Complete_Event_t;

#define HCI_WRITE_LINK_SUPERVISION_TIMEOUT_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Link_Supervision_Timeout_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Number_Of_Supported_IAC_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Byte_t                              Num_Support_IAC;
} __PACKED_STRUCT_END__ HCI_Read_Number_Of_Supported_IAC_Command_Complete_Event_t;

#define HCI_READ_NUMBER_OF_SUPPORTED_IAC_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Number_Of_Supported_IAC_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Current_IAC_LAP_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Byte_t                              Num_Current_IAC;
   Byte_t                              Variable_Data[1];
} __PACKED_STRUCT_END__ HCI_Read_Current_IAC_LAP_Command_Complete_Event_t;

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Determine the size (in Bytes) of an HCI Read       */
   /* Current IAC LAP Command Complete Event Data Structure based upon  */
   /* the Number of Connection IACs that are required.  The first       */
   /* parameter to this MACRO is the Number of IAC's.                   */
#define HCI_READ_CURRENT_IAC_LAP_COMMAND_COMPLETE_EVENT_SIZE(_x) ((sizeof(HCI_Read_Current_IAC_LAP_Command_Complete_Event_t) - sizeof(Byte_t)) + (((Byte_t)(_x))*(sizeof(LAP_t))))

   /* The following definition exists to define the Total Number of     */
   /* Stored IAC LAP's that can be supported by a single                */
   /* HCI_Read_Current_IAC_LAP_Command_t Command Packet.                */
#define HCI_READ_CURRENT_IAC_LAP_COMMAND_MAX_IAC_LAPS    (((sizeof(Byte_t)*256) - HCI_READ_CURRENT_IAC_LAP_COMMAND_COMPLETE_EVENT_SIZE(0))/(sizeof(LAP_t)))

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability to Read a specified IAC LAP in the Read Current IAC   */
   /* LAP Command Complete Event Data.  The first parameter is a pointer*/
   /* to a Data Buffer that is an                                       */
   /* HCI_Read_Current_IAC_LAP_Command_Complete_Event_t.  The second    */
   /* parameter is the Index of the IAC LAP to Read.                    */
   /* * NOTE * This MACRO assumes that the Num_Current_IAC field of     */
   /*          the HCI_Read_Current_IAC_LAP_Command_Complete_Event_t is */
   /*          valid and this value IS USED by this MACRO to calculate  */
   /*          the correct offset into the structure !                  */
   /* * NOTE * No Check of any of the input data is performed !         */
#define HCI_READ_CURRENT_IAC_LAP_COMMAND_COMPLETE_EVENT_READ_IAC_LAP(_x, _y) \
   READ_UNALIGNED_GENERIC_TYPE(&(((LAP_t *)((_x)->Variable_Data))[(_y)]))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Current_IAC_LAP_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Current_IAC_LAP_Command_Complete_Event_t;

#define HCI_WRITE_CURRENT_IAC_LAP_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Current_IAC_LAP_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Page_Scan_Period_Mode_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Byte_t                              Page_Scan_Period_Mode;
} __PACKED_STRUCT_END__ HCI_Read_Page_Scan_Period_Mode_Command_Complete_Event_t;

#define HCI_READ_PAGE_SCAN_PERIOD_MODE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Page_Scan_Period_Mode_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Page_Scan_Period_Mode_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Page_Scan_Period_Mode_Command_Complete_Event_t;

#define HCI_WRITE_PAGE_SCAN_PERIOD_MODE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Page_Scan_Period_Mode_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Page_Scan_Mode_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Byte_t                              Page_Scan_Mode;
} __PACKED_STRUCT_END__ HCI_Read_Page_Scan_Mode_Command_Complete_Event_t;

#define HCI_READ_PAGE_SCAN_MODE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Page_Scan_Mode_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Page_Scan_Mode_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Page_Scan_Mode_Command_Complete_Event_t;

#define HCI_WRITE_PAGE_SCAN_MODE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Page_Scan_Mode_Command_Complete_Event_t))

   /* HCI Command Complete Event Definitions (Host Control and Baseband */
   /* - Version 1.2).                                                   */
   
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Set_AFH_Host_Channel_Classification_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Set_AFH_Host_Channel_Classification_Command_Complete_Event_t;

#define HCI_SET_AFH_HOST_CHANNEL_CLASSIFICATION_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Set_AFH_Host_Channel_Classification_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Inquiry_Scan_Type_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Byte_t                              Inquiry_Scan_Type;
} __PACKED_STRUCT_END__ HCI_Read_Inquiry_Scan_Type_Command_Complete_Event_t;

#define HCI_READ_INQUIRY_SCAN_TYPE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Inquiry_Scan_Type_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Inquiry_Scan_Type_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Inquiry_Scan_Type_Command_Complete_Event_t;

#define HCI_WRITE_INQUIRY_SCAN_TYPE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Inquiry_Scan_Type_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Inquiry_Mode_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Byte_t                              Inquiry_Mode;
} __PACKED_STRUCT_END__ HCI_Read_Inquiry_Mode_Command_Complete_Event_t;

#define HCI_READ_INQUIRY_MODE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Inquiry_Mode_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Inquiry_Mode_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Inquiry_Mode_Command_Complete_Event_t;

#define HCI_WRITE_INQUIRY_MODE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Inquiry_Mode_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Page_Scan_Type_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Byte_t                              Page_Scan_Type;
} __PACKED_STRUCT_END__ HCI_Read_Page_Scan_Type_Command_Complete_Event_t;

#define HCI_READ_PAGE_SCAN_TYPE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Page_Scan_Type_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Page_Scan_Type_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Page_Scan_Type_Command_Complete_Event_t;

#define HCI_WRITE_PAGE_SCAN_TYPE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Page_Scan_Type_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_AFH_Channel_Assessment_Mode_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Byte_t                              AFH_Channel_Assessment_Mode;
} __PACKED_STRUCT_END__ HCI_Read_AFH_Channel_Assessment_Mode_Command_Complete_Event_t;

#define HCI_READ_AFH_CHANNEL_ASSESSMENT_MODE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_AFH_Channel_Assessment_Mode_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_AFH_Channel_Assessment_Mode_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_AFH_Channel_Assessment_Mode_Command_Complete_Event_t;

#define HCI_WRITE_AFH_CHANNEL_ASSESSMENT_MODE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_AFH_Channel_Assessment_Mode_Command_Complete_Event_t))

   /* HCI Command Complete Event Definitions (Host Control and Baseband */
   /* - Version 2.1).                                                   */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Extended_Inquiry_Response_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Event_Header;
   Byte_t                              Status;
   Byte_t                              FEC_Required;
   Extended_Inquiry_Response_Data_t    Extended_Inquiry_Response;
} __PACKED_STRUCT_END__ HCI_Read_Extended_Inquiry_Response_Command_Complete_Event_t;

#define HCI_READ_EXTENDED_INQUIRY_RESPONSE_COMMAND_COMPLETE_EVENT_SIZE  (sizeof(HCI_Read_Extended_Inquiry_Response_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Extended_Inquiry_Response_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Extended_Inquiry_Response_Command_Complete_Event_t;

#define HCI_WRITE_EXTENDED_INQUIRY_RESPONSE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Extended_Inquiry_Response_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Refresh_Encryption_Key_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Refresh_Encryption_Key_Command_Complete_Event_t;

#define HCI_REFRESH_ENCRYPTION_KEY_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Refresh_Encryption_Key_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Simple_Pairing_Mode_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Event_Header;
   Byte_t                              Status;
   Byte_t                              Simple_Pairing_Enable;
} __PACKED_STRUCT_END__ HCI_Read_Simple_Pairing_Mode_Command_Complete_Event_t;

#define HCI_READ_SIMPLE_PAIRING_MODE_COMMAND_COMPLETE_EVENT_SIZE  (sizeof(HCI_Read_Simple_Pairing_Mode_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Simple_Pairing_Mode_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Simple_Pairing_Mode_Command_Complete_Event_t;

#define HCI_WRITE_SIMPLE_PAIRING_MODE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Simple_Pairing_Mode_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Local_OOB_Data_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Event_Header;
   Byte_t                              Status;
   Simple_Pairing_Hash_t               Simple_Pairing_Hash;
   Simple_Pairing_Randomizer_t         Simple_Pairing_Randomizer;
} __PACKED_STRUCT_END__ HCI_Read_Local_OOB_Data_Command_Complete_Event_t;

#define HCI_READ_LOCAL_OOB_DATA_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Local_OOB_Data_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Inquiry_Response_Transmit_Power_Level_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Event_Header;
   Byte_t                              Status;
   SByte_t                             TX_Power;
} __PACKED_STRUCT_END__ HCI_Read_Inquiry_Response_Transmit_Power_Level_Command_Complete_Event_t;

#define HCI_READ_INQUIRY_RESPONSE_TRANSMIT_POWER_LEVEL_COMMAND_COMPLETE_EVENT_SIZE  (sizeof(HCI_Read_Inquiry_Response_Transmit_Power_Level_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Inquiry_Transmit_Power_Level_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Inquiry_Transmit_Power_Level_Command_Complete_Event_t;

#define HCI_WRITE_INQUIRY_TRANSMIT_POWER_LEVEL_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Inquiry_Transmit_Power_Level_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Send_Keypress_Notification_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Event_Header;
   Byte_t                              Status;
   BD_ADDR_t                           BD_ADDR;
} __PACKED_STRUCT_END__ HCI_Send_Keypress_Notification_Command_Complete_Event_t;

#define HCI_SEND_KEYPRESS_NOTIFICATION_COMMAND_COMPLETE_EVENT_SIZE   (sizeof(HCI_Send_Keypress_Notification_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Default_Erroneous_Data_Reporting_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Event_Header;
   Byte_t                              Status;
   Byte_t                              Erroneous_Data_Reporting;
} __PACKED_STRUCT_END__ HCI_Read_Default_Erroneous_Data_Reporting_Command_Complete_Event_t;

#define HCI_READ_DEFAULT_ERRONEOUS_DATA_REPORTING_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Default_Erroneous_Data_Reporting_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Default_Erroneous_Data_Reporting_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Default_Erroneous_Data_Reporting_Command_Complete_Event_t;

#define HCI_WRITE_DEFAULT_ERRONEOUS_DATA_REPORTING_COMMAND_COMPLETE_EVENT_SIZE   (sizeof(HCI_Write_Default_Erroneous_Data_Reporting_Command_Complete_Event_t))

   /* HCI Command Complete Event Definitions (Informational Parameters).*/

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Local_Version_Information_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Byte_t                              HCI_Version;
   NonAlignedWord_t                    HCI_Revision;
   Byte_t                              LMP_Version;
   NonAlignedWord_t                    Manufacturer_Name;
   NonAlignedWord_t                    LMP_Subversion;
} __PACKED_STRUCT_END__ HCI_Read_Local_Version_Information_Command_Complete_Event_t;

#define HCI_READ_LOCAL_VERSION_INFORMATION_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Local_Version_Information_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Local_Supported_Features_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   LMP_Features_t                      LMP_Features;
} __PACKED_STRUCT_END__ HCI_Read_Local_Supported_Features_Command_Complete_Event_t;

#define HCI_READ_LOCAL_SUPPORTED_FEATURES_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Local_Supported_Features_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Buffer_Size_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    HC_ACL_Data_Packet_Length;
   Byte_t                              HC_SCO_Data_Packet_Length;
   NonAlignedWord_t                    HC_Total_Num_ACL_Data_Packets;
   NonAlignedWord_t                    HC_Total_Num_SCO_Data_Packets;
} __PACKED_STRUCT_END__ HCI_Read_Buffer_Size_Command_Complete_Event_t;

#define HCI_READ_BUFFER_SIZE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Buffer_Size_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Country_Code_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Byte_t                              Country_Code;
} __PACKED_STRUCT_END__ HCI_Read_Country_Code_Command_Complete_Event_t;

#define HCI_READ_COUNTRY_CODE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Country_Code_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_BD_ADDR_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   BD_ADDR_t                           BD_ADDR;
} __PACKED_STRUCT_END__ HCI_Read_BD_ADDR_Command_Complete_Event_t;

#define HCI_READ_BD_ADDR_COMMAND_COMPLETE_EVENT_SIZE    (sizeof(HCI_Read_BD_ADDR_Command_Complete_Event_t))

   /* HCI Command Complete Event Definitions (Informational Parameters -*/
   /* Version 1.2).                                                     */
   
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Local_Supported_Commands_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Supported_Commands_t                Supported_Commands;
} __PACKED_STRUCT_END__ HCI_Read_Local_Supported_Commands_Command_Complete_Event_t;

#define HCI_READ_LOCAL_SUPPORTED_COMMANDS_COMMAND_COMPLETE_EVENT_SIZE    (sizeof(HCI_Read_Local_Supported_Commands_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Local_Extended_Features_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Byte_t                              Page_Number;
   Byte_t                              Maximum_Page_Number;
   LMP_Features_t                      Extended_LMP_Features;
} __PACKED_STRUCT_END__ HCI_Read_Local_Extended_Features_Command_Complete_Event_t;

#define HCI_READ_LOCAL_EXTENDED_FEATURES_COMMAND_COMPLETE_EVENT_SIZE    (sizeof(HCI_Read_Local_Extended_Features_Command_Complete_Event_t))

   /* HCI Command Complete Event Definitions (Status Parameters).       */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Failed_Contact_Counter_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Connection_Handle;
   NonAlignedWord_t                    Failed_Contact_Counter;
} __PACKED_STRUCT_END__ HCI_Read_Failed_Contact_Counter_Command_Complete_Event_t;

#define HCI_READ_FAILED_CONTACT_COUNTER_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Failed_Contact_Counter_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Reset_Failed_Contact_Counter_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Connection_Handle;
} __PACKED_STRUCT_END__ HCI_Reset_Failed_Contact_Counter_Command_Complete_Event_t;

#define HCI_RESET_FAILED_CONTACT_COUNTER_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Reset_Failed_Contact_Counter_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Get_Link_Quality_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Connection_Handle;
   Byte_t                              Link_Quality;
} __PACKED_STRUCT_END__ HCI_Get_Link_Quality_Command_Complete_Event_t;

#define HCI_GET_LINK_QUALITY_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Get_Link_Quality_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_RSSI_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Connection_Handle;
   Byte_t                              RSSI;
} __PACKED_STRUCT_END__ HCI_Read_RSSI_Command_Complete_Event_t;

#define HCI_READ_RSSI_COMMAND_COMPLETE_EVENT_SIZE       (sizeof(HCI_Read_RSSI_Command_Complete_Event_t))

   /* HCI Command Complete Event Definitions (Status Parameters -       */
   /* Version 1.2).                                                     */
   
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_AFH_Channel_Map_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Connection_Handle;
   Byte_t                              AFH_Mode;
   AFH_Channel_Map_t                   AFH_Channel_Map;
} __PACKED_STRUCT_END__ HCI_Read_AFH_Channel_Map_Command_Complete_Event_t;

#define HCI_READ_AFH_CHANNEL_MAP_COMMAND_COMPLETE_EVENT_SIZE   (sizeof(HCI_Read_AFH_Channel_Map_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Clock_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   NonAlignedWord_t                    Connection_Handle;
   NonAlignedDWord_t                   Clock;
   NonAlignedWord_t                    Accuracy;
} __PACKED_STRUCT_END__ HCI_Read_Clock_Command_Complete_Event_t;

#define HCI_READ_CLOCK_COMMAND_COMPLETE_EVENT_SIZE   (sizeof(HCI_Read_Clock_Command_Complete_Event_t))

   /* HCI Command Complete Event Definitions (Testing Commands).        */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Loopback_Mode_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
   Byte_t                              Loopback_Mode;
} __PACKED_STRUCT_END__ HCI_Read_Loopback_Mode_Command_Complete_Event_t;

#define HCI_READ_LOOPBACK_MODE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Read_Loopback_Mode_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Loopback_Mode_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Loopback_Mode_Command_Complete_Event_t;

#define HCI_WRITE_LOOPBACK_MODE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Loopback_Mode_Command_Complete_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Enable_Device_Under_Test_Mode_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Command_Complete_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Enable_Device_Under_Test_Mode_Command_Complete_Event_t;

#define HCI_ENABLE_DEVICE_UNDER_TEST_MODE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Enable_Device_Under_Test_Mode_Command_Complete_Event_t))

   /* HCI Command Complete Event Definitions (Testing Commands - Version*/
   /* 2.1).                                                             */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Write_Simple_Pairing_Debug_Mode_Command_Complete_Event_t
{
   HCI_Command_Complete_Event_Header_t HCI_Event_Header;
   Byte_t                              Status;
} __PACKED_STRUCT_END__ HCI_Write_Simple_Pairing_Debug_Mode_Command_Complete_Event_t;

#define HCI_WRITE_SIMPLE_PAIRING_DEBUG_MODE_COMMAND_COMPLETE_EVENT_SIZE (sizeof(HCI_Write_Simple_Pairing_Debug_Mode_Command_Complete_Event_t))

   /* HCI Command Status Event Definitions (Link Control).              */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Inquiry_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Inquiry_Command_Status_Event_t;

#define HCI_INQUIRY_COMMAND_STATUS_EVENT_SIZE           (sizeof(HCI_Inquiry_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Create_Connection_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Create_Connection_Command_Status_Event_t;

#define HCI_CREATE_CONNECTION_COMMAND_STATUS_EVENT_SIZE (sizeof(HCI_Create_Connection_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Disconnect_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Disconnect_Command_Status_Event_t;

#define HCI_DISCONNECT_COMMAND_STATUS_EVENT_SIZE        (sizeof(HCI_Disconnect_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Add_SCO_Connection_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Add_SCO_Connection_Command_Status_Event_t;

#define HCI_ADD_SCO_CONNECTION_COMMAND_STATUS_EVENT_SIZE (sizeof(HCI_Add_SCO_Connection_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Accept_Connection_Request_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Accept_Connection_Request_Command_Status_Event_t;

#define HCI_ACCEPT_CONNECTION_REQUEST_COMMAND_STATUS_EVENT_SIZE (sizeof(HCI_Accept_Connection_Request_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Reject_Connection_Request_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Reject_Connection_Request_Command_Status_Event_t;

#define HCI_REJECT_CONNECTION_REQUEST_COMMAND_STATUS_EVENT_SIZE (sizeof(HCI_Reject_Connection_Request_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Change_Connection_Packet_Type_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Change_Connection_Packet_Type_Command_Status_Event_t;

#define HCI_CHANGE_CONNECTION_PACKET_TYPE_COMMAND_STATUS_EVENT_SIZE (sizeof(HCI_Change_Connection_Packet_Type_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Authentication_Requested_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Authentication_Requested_Command_Status_Event_t;

#define HCI_AUTHENTICATION_REQUESTED_COMMAND_STATUS_EVENT_SIZE (sizeof(HCI_Authentication_Requested_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Set_Connection_Encryption_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Set_Connection_Encryption_Command_Status_Event_t;

#define HCI_SET_CONNECTION_ENCRYPTION_COMMAND_STATUS_EVENT_SIZE (sizeof(HCI_Set_Connection_Encryption_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Change_Connection_Link_Key_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Change_Connection_Link_Key_Command_Status_Event_t;

#define HCI_CHANGE_CONNECTION_LINK_KEY_COMMAND_STATUS_EVENT_SIZE (sizeof(HCI_Change_Connection_Link_Key_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Master_Link_Key_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Master_Link_Key_Command_Status_Event_t;

#define HCI_MASTER_LINK_KEY_COMMAND_STATUS_EVENT_SIZE   (sizeof(HCI_Master_Link_Key_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Remote_Name_Request_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Remote_Name_Request_Command_Status_Event_t;

#define HCI_REMOTE_NAME_REQUEST_COMMAND_STATUS_EVENT_SIZE (sizeof(HCI_Remote_Name_Request_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Remote_Supported_Features_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Read_Remote_Supported_Features_Command_Status_Event_t;

#define HCI_READ_REMOTE_SUPPORTED_FEATURES_COMMAND_STATUS_EVENT_SIZE (sizeof(HCI_Read_Remote_Supported_Features_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Remote_Version_Information_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Read_Remote_Version_Information_Command_Status_Event_t;

#define HCI_READ_REMOTE_VERSION_INFORMATION_COMMAND_STATUS_EVENT_SIZE (sizeof(HCI_Read_Remote_Version_Information_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Clock_Offset_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Read_Clock_Offset_Command_Status_Event_t;

#define HCI_READ_CLOCK_OFFSET_COMMAND_STATUS_EVENT_SIZE (sizeof(HCI_Read_Clock_Offset_Command_Status_Event_t))

   /* HCI Command Status Event Definitions (Link Control - Version 1.2).*/
   
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Read_Remote_Extended_Features_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Read_Remote_Extended_Features_Command_Status_Event_t;

#define HCI_READ_REMOTE_EXTENDED_FEATURES_COMMAND_STATUS_EVENT_SIZE (sizeof(HCI_Read_Remote_Extended_Features_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Setup_Synchronous_Connection_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Setup_Synchronous_Connection_Command_Status_Event_t;

#define HCI_SETUP_SYNCHRONOUS_CONNECTION_COMMAND_STATUS_EVENT_SIZE (sizeof(HCI_Setup_Synchronous_Connection_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Accept_Synchronous_Connection_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Accept_Synchronous_Connection_Command_Status_Event_t;

#define HCI_ACCEPT_SYNCHRONOUS_CONNECTION_COMMAND_STATUS_EVENT_SIZE (sizeof(HCI_Accept_Synchronous_Connection_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Reject_Synchronous_Connection_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Reject_Synchronous_Connection_Command_Status_Event_t;

#define HCI_REJECT_SYNCHRONOUS_CONNECTION_COMMAND_STATUS_EVENT_SIZE (sizeof(HCI_Reject_Synchronous_Connection_Command_Status_Event_t))

   /* HCI Command Status Event Definitions (Link Policy).               */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Hold_Mode_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Hold_Mode_Command_Status_Event_t;

#define HCI_HOLD_MODE_COMMAND_STATUS_EVENT_SIZE         (sizeof(HCI_Hold_Mode_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Sniff_Mode_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Sniff_Mode_Command_Status_Event_t;

#define HCI_SNIFF_MODE_COMMAND_STATUS_EVENT_SIZE        (sizeof(HCI_Sniff_Mode_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Exit_Sniff_Mode_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Exit_Sniff_Mode_Command_Status_Event_t;

#define HCI_EXIT_SNIFF_MODE_COMMAND_STATUS_EVENT_SIZE   (sizeof(HCI_Exit_Sniff_Mode_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Park_Mode_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Park_Mode_Command_Status_Event_t;

#define HCI_PARK_MODE_COMMAND_STATUS_EVENT_SIZE         (sizeof(HCI_Park_Mode_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Exit_Park_Mode_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Exit_Park_Mode_Command_Status_Event_t;

#define HCI_EXIT_PARK_MODE_COMMAND_STATUS_EVENT_SIZE    (sizeof(HCI_Exit_Park_Mode_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_QoS_Setup_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_QoS_Setup_Command_Status_Event_t;

#define HCI_QOS_SETUP_COMMAND_STATUS_EVENT_SIZE         (sizeof(HCI_QoS_Setup_Command_Status_Event_t))

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Switch_Role_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Switch_Role_Command_Status_Event_t;

#define HCI_SWITCH_ROLE_COMMAND_STATUS_EVENT_SIZE       (sizeof(HCI_Switch_Role_Command_Status_Event_t))

   /* HCI Command Status Event Definitions (Link Policy - Version 1.2). */
   
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Flow_Specification_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Flow_Specification_Command_Status_Event_t;

#define HCI_FLOW_SPECIFICATION_COMMAND_STATUS_EVENT_SIZE  (sizeof(HCI_Flow_Specification_Command_Status_Event_t))

   /* HCI Command Status Event Definitions (Host Control and Baseband). */

   /* HCI Command Status Event Definitions (Host Controller and Baseband*/
   /* - Version 2.1).                                                   */

typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_Enhanced_Flush_Command_Status_Event_t
{
   HCI_Command_Status_Event_t HCI_Command_Status_Event;
} __PACKED_STRUCT_END__ HCI_Enhanced_Flush_Command_Status_Event_t;

#define HCI_ENHANCED_FLUSH_COMMAND_STATUS_EVENT_SIZE     (sizeof(HCI_Enhanced_Flush_Command_Status_Event_t))

   /* HCI Command Status Event Definitions (Informational Parameters).  */

   /* HCI Command Status Event Definitions (Status Parameters).         */

   /* HCI Command Status Event Definitions (Testing Commands).          */

   /* The following type declaration represents the structure of the    */
   /* an HCI ACL Data Packet.  The only detail to note is that the      */
   /* ACL Data field is an array of Byte_t's, and NOT a Pointer to an   */
   /* array of Byte_t's.  This is very important, because this          */
   /* mechanism will allow an arbitrary memory buffer to be typecast to */
   /* this structure and all elements will be accessible in the same    */
   /* memory block (i.e. NO other pointer operation is required).  The  */
   /* side effect of this is that when the memory for a Raw ACL Data    */
   /* Packet is to be allocated, the allocated size is required will be */
   /* (sizeof(HCI_ACL_Data_t)-1) + length of the Packet Data.  After    */
   /* this is completed, the data elements in the Packet Data array can */
   /* be accessed by simply Array Logic, aiding code readability.  It   */
   /* might appear confusing to the user because array elements greater */
   /* than zero will be indexed, however, as long as the programmer is  */
   /* aware of this design decision, the code should be much more simple*/
   /* to read.  MACRO's and Definitions will be provided following this */
   /* structure definition to alleviate the programmer from having to   */
   /* remember the above formula when allocating memory of the correct  */
   /* size.                                                             */
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_ACL_Data_t
{
   NonAlignedWord_t Connection_Handle_And_Flags;
   NonAlignedWord_t Data_Total_Length;
   Byte_t           ACL_Data[1];
} __PACKED_STRUCT_END__ HCI_ACL_Data_t;

   /* The following Constant represents the actual size of the HCI ACL  */
   /* Data Packet Header Information.  This Constant is to be used      */
   /* instead of simply using sizeof(HCI_ACL_Data_t) to get the size.   */
   /* The reason for this was explained above, and is primarily to aid  */
   /* in code readability and efficiency.                               */
#define HCI_ACL_DATA_HEADER_SIZE       (sizeof(HCI_ACL_Data_t)-sizeof(Byte_t))

   /* The following MACRO is provided to allow the programmer a very    */
   /* simple means of quickly determining the number of Data Bytes that */
   /* will be required to hold a HCI ACL Data Information Header and the*/
   /* Raw HCI ACL Data (of the specified length).  See notes and        */
   /* discussion above for the reason for this MACRO definition.        */
#define HCI_CALCULATE_ACL_DATA_SIZE(_x)  (HCI_ACL_DATA_HEADER_SIZE+(unsigned int)(_x))

   /* The following Constants represent the defined Bluetooth HCI Bit   */
   /* Mask's to apply to the Bluetooth HCI ACL Packet Flags.  These     */
   /* Masks are applied to the Connection_Handle_And_Flags member of the*/
   /* HCI ACL Data Packet member.  After the correct Mask is applied,   */
   /* the Data can then be tested and/or set with the bit definition    */
   /* values that follow.                                               */
#define HCI_ACL_FLAGS_CONNECTION_HANDLE_MASK                            0x0FFF
#define HCI_ACL_FLAGS_PACKET_BOUNDARY_MASK                              0x3000
#define HCI_ACL_FLAGS_BROADCAST_MASK                                    0xC000

   /* The following Constants represent the defined Bluetooth HCI Bit   */
   /* Values (based upon the HCI_ACL_FLAGS_PACKET_BOUNDARY_MASK         */
   /* Bit Mask) that specify a specific Bluetooth HCI ACL Packet        */
   /* Boundary Setting.                                                 */
#define HCI_ACL_FLAGS_PACKET_BOUNDARY_CONTINUE_PACKET                   0x1000
#define HCI_ACL_FLAGS_PACKET_BOUNDARY_FIRST_PACKET                      0x2000

   /* The following Constants represent the defined Bluetooth HCI Bit   */
   /* Values (based upon the HCI_ACL_FLAGS_BROADCAST_MASK Bit Mask)     */
   /* that specify a specific Bluetooth HCI ACL Packet Broadcast        */
   /* Setting.                                                          */
   /* * NOTE * These definitions are for Packets from Host to Host      */
   /*          Controller.                                              */
#define HCI_ACL_FLAGS_PACKET_BROADCAST_NO_BROADCAST                     0x0000
#define HCI_ACL_FLAGS_PACKET_BROADCAST_ACTIVE_BROADCAST                 0x4000
#define HCI_ACL_FLAGS_PACKET_BROADCAST_PICONET_BROADCAST                0x8000

   /* Bluetooth Version 1.2 HCI ACL Packet Broadcast Settings.          */
   /* * NOTE * These definitions are for Packets from Host to Host      */
   /*          Controller.                                              */
#define HCI_ACL_FLAGS_PACKET_BROADCAST_NO_BROADCAST                     0x0000
#define HCI_ACL_FLAGS_PACKET_BROADCAST_ACTIVE_SLAVE_BROADCAST           0x4000
#define HCI_ACL_FLAGS_PACKET_BROADCAST_PARKED_SLAVE_BROADCAST           0x8000

   /* The following Constants represent the defined Bluetooth HCI Bit   */
   /* Values (based upon the HCI_ACL_FLAGS_BROADCAST_MASK Bit Mask)     */
   /* that specify a specific Bluetooth HCI ACL Packet Broadcast        */
   /* Setting.                                                          */
   /* * NOTE * These definitions are for Packets from Host Controller   */
   /*          to Host.                                                 */
#define HCI_ACL_FLAGS_PACKET_BROADCAST_POINT_TO_POINT                   0x0000
#define HCI_ACL_FLAGS_PACKET_BROADCAST_ACTIVE_SLAVE                     0x4000
#define HCI_ACL_FLAGS_PACKET_BROADCAST_PARKED_SLAVE                     0x8000

   /* The following type declaration represents the structure of the    */
   /* an HCI SCO Data Packet.  The only detail to note is that the      */
   /* SCO Data field is an array of Byte_t's, and NOT a Pointer to an   */
   /* array of Byte_t's.  This is very important, because this          */
   /* mechanism will allow an arbitrary memory buffer to be typecast to */
   /* this structure and all elements will be accessible in the same    */
   /* memory block (i.e. NO other pointer operation is required).  The  */
   /* side effect of this is that when the memory for a Raw SCO Data    */
   /* Packet is to be allocated, the allocated size is required will be */
   /* (sizeof(HCI_SCO_Data_t)-1) + length of the Packet Data.  After    */
   /* this is completed, the data elements in the Packet Data array can */
   /* be accessed by simply Array Logic, aiding code readability.  It   */
   /* might appear confusing to the user because array elements greater */
   /* than zero will be indexed, however, as long as the programmer is  */
   /* aware of this design decision, the code should be much more simple*/
   /* to read.  MACRO's and Definitions will be provided following this */
   /* structure definition to alleviate the programmer from having to   */
   /* remember the above formula when allocating memory of the correct  */
   /* size.                                                             */
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_SCO_Data_t
{
   NonAlignedWord_t Connection_Handle_And_Flags;
   Byte_t           Data_Total_Length;
   Byte_t           SCO_Data[1];
} __PACKED_STRUCT_END__ HCI_SCO_Data_t;

   /* The following Constant represents the actual size of the HCI SCO  */
   /* Data Packet Header Information.  This Constant is to be used      */
   /* instead of simply using sizeof(HCI_SCO_Data_t) to get the size.   */
   /* The reason for this was explained above, and is primarily to aid  */
   /* in code readability and efficiency.                               */
#define HCI_SCO_DATA_HEADER_SIZE       (sizeof(HCI_SCO_Data_t)-sizeof(Byte_t))

   /* The following MACRO is provided to allow the programmer a very    */
   /* simple means of quickly determining the number of Data Bytes that */
   /* will be required to hold a HCI SCO Data Information Header and the*/
   /* Raw HCI SCO Data (of the specified length).  See notes and        */
   /* discussion above for the reason for this MACRO definition.        */
#define HCI_CALCULATE_SCO_DATA_SIZE(_x)  (HCI_SCO_DATA_HEADER_SIZE+(unsigned int)(_x))

   /* The following Constants represent the defined Bluetooth HCI Bit   */
   /* Mask's to apply to the Bluetooth HCI SCO Packet Flags.  These     */
   /* Masks are applied to the Connection_Handle_And_Flags member of the*/
   /* HCI SCO Data Packet member.                                       */
#define HCI_SCO_FLAGS_CONNECTION_HANDLE_MASK                            0x0FFF

   /* The following type declaration represents the structure of the    */
   /* an HCI eSCO Data Packet.  The only detail to note is that the     */
   /* eSCO Data field is an array of Byte_t's, and NOT a Pointer to an  */
   /* array of Byte_t's.  This is very important, because this          */
   /* mechanism will allow an arbitrary memory buffer to be typecast to */
   /* this structure and all elements will be accessible in the same    */
   /* memory block (i.e. NO other pointer operation is required).  The  */
   /* side effect of this is that when the memory for a Raw eSCO Data   */
   /* Packet is to be allocated, the allocated size is required will be */
   /* (sizeof(HCI_eSCO_Data_t)-1) + length of the Packet Data.  After   */
   /* this is completed, the data elements in the Packet Data array can */
   /* be accessed by simply Array Logic, aiding code readability.  It   */
   /* might appear confusing to the user because array elements greater */
   /* than zero will be indexed, however, as long as the programmer is  */
   /* aware of this design decision, the code should be much more simple*/
   /* to read.  MACRO's and Definitions will be provided following this */
   /* structure definition to alleviate the programmer from having to   */
   /* remember the above formula when allocating memory of the correct  */
   /* size.                                                             */
typedef __PACKED_STRUCT_BEGIN__ struct _tagHCI_eSCO_Data_t
{
   NonAlignedWord_t Connection_Handle_And_Flags;
   Byte_t           Data_Total_Length;
   Byte_t           eSCO_Data[1];
} __PACKED_STRUCT_END__ HCI_eSCO_Data_t;

   /* The following Constant represents the actual size of the HCI eSCO */
   /* Data Packet Header Information.  This Constant is to be used      */
   /* instead of simply using sizeof(HCI_eSCO_Data_t) to get the size.  */
   /* The reason for this was explained above, and is primarily to aid  */
   /* in code readability and efficiency.                               */
#define HCI_ESCO_DATA_HEADER_SIZE      (sizeof(HCI_ESCO_Data_t)-sizeof(Byte_t))

   /* The following MACRO is provided to allow the programmer a very    */
   /* simple means of quickly determining the number of Data Bytes that */
   /* will be required to hold a HCI eSCO Data Information Header and   */
   /* the Raw HCI eSCO Data (of the specified length).  See notes and   */
   /* discussion above for the reason for this MACRO definition.        */
#define HCI_CALCULATE_ESCO_DATA_SIZE(_x)  (HCI_ESCO_DATA_HEADER_SIZE+(unsigned int)(_x))

   /* The following Constants represent the defined Bluetooth HCI Bit   */
   /* Mask's to apply to the Bluetooth HCI eSCO Packet Flags.  These    */
   /* Masks are applied to the Connection_Handle_And_Flags member of the*/
   /* HCI eSCO Data Packet member.                                      */
#define HCI_ESCO_FLAGS_CONNECTION_HANDLE_MASK                            0x0FFF

   /* Generic HCI Type Definitions/Constants.                           */

   /* The following MACRO is a utility MACRO that assigns the HCI       */
   /* General/Unlimited Inquiry Access Code (GIAC) to a specified LAP_t */
   /* variable.  This MACRO accepts one parameter which is the LAP_t    */
   /* variable that is to receive the GIAC LAP Constant value.          */
#define HCI_ASSIGN_GIAC_LAP(_x)   ASSIGN_LAP((_x), 0x9E, 0x8B, 0x33)

   /* The following MACRO is a utility MACRO that assigns the HCI       */
   /* Limited Dedicated Inquiry Access Code (LIAC) to a specified LAP_t */
   /* variable.  This MACRO accepts one parameter which is the LAP_t    */
   /* variable that is to receive the LIAC LAP Constant value.          */
#define HCI_ASSIGN_LIAC_LAP(_x)   ASSIGN_LAP((_x), 0x9E, 0x8B, 0x00)

   /* The following Constants represent Bit Number Constants that are   */
   /* to be used with the EVENT_MASK MACRO's (Set/Reset/Test).  These   */
   /* Constants are used as the second parameter in those MACRO's to    */
   /* specify the correct HCI Bluetooth Event in the Event Mask.        */
#define HCI_EVENT_MASK_INQUIRY_COMPLETE_BIT_NUMBER                      0x00
#define HCI_EVENT_MASK_INQUIRY_RESULT_BIT_NUMBER                        0x01
#define HCI_EVENT_MASK_CONNECTION_COMPLETE_BIT_NUMBER                   0x02
#define HCI_EVENT_MASK_CONNECTION_REQUEST_BIT_NUMBER                    0x03
#define HCI_EVENT_MASK_DISCONNECTION_COMPLETE_BIT_NUMBER                0x04
#define HCI_EVENT_MASK_AUTHENTICAITION_COMPLETE_BIT_NUMBER              0x05
#define HCI_EVENT_MASK_REMOTE_NAME_REQUEST_COMPLETE_BIT_NUMBER          0x06
#define HCI_EVENT_MASK_ENCRYPTION_CHANGE_BIT_NUMBER                     0x07
#define HCI_EVENT_MASK_CHANGE_CONNECTION_LINK_KEY_COMPLETE_BIT_NUMBER   0x08
#define HCI_EVENT_MASK_MASTER_LINK_KEY_COMPLETE_BIT_NUMBER              0x09
#define HCI_EVENT_MASK_READ_REMOTE_SUPPORTED_FEATURES_COMPLETE_BIT_NUMBER  0x0A
#define HCI_EVENT_MASK_READ_REMOTE_VERSION_INFORMATION_COMPLETE_BIT_NUMBER 0x0B
#define HCI_EVENT_MASK_QOS_SETUP_COMPLETE_BIT_NUMBER                    0x0C
#define HCI_EVENT_MASK_COMMAND_COMPLETE_BIT_NUMBER                      0x0D
#define HCI_EVENT_MASK_STATUS_COMMAND_BIT_NUMBER                        0x0E
#define HCI_EVENT_MASK_HARDWARE_ERROR_BIT_NUMBER                        0x0F
#define HCI_EVENT_MASK_FLUSH_OCCURRED_BIT_NUMBER                        0x10
#define HCI_EVENT_MASK_ROLE_CHANGE_BIT_NUMBER                           0x11
#define HCI_EVENT_MASK_NUMBER_OF_COMPLETED_PACKETS_BIT_NUMBER           0x12
#define HCI_EVENT_MASK_MODE_CHANGE_BIT_NUMBER                           0x13
#define HCI_EVENT_MASK_RETURN_LINK_KEYS_BIT_NUMBER                      0x14
#define HCI_EVENT_MASK_PIN_CODE_REQUEST_BIT_NUMBER                      0x15
#define HCI_EVENT_MASK_LINK_KEY_REQUEST_BIT_NUMBER                      0x16
#define HCI_EVENT_MASK_LINK_KEY_NOTIFICATION_BIT_NUMBER                 0x17
#define HCI_EVENT_MASK_LOOPBACK_COMMAND_BIT_NUMBER                      0x18
#define HCI_EVENT_MASK_DATA_BUFFER_OVERFLOW_BIT_NUMBER                  0x19
#define HCI_EVENT_MASK_MAX_SLOTS_CHANGE_BIT_NUMBER                      0x1A
#define HCI_EVENT_MASK_READ_CLOCK_OFFSET_COMPLETE_BIT_NUMBER            0x1B
#define HCI_EVENT_MASK_CONNECTION_PACKET_TYPE_CHANGED_BIT_NUMBER        0x1C
#define HCI_EVENT_MASK_QOS_VIOLATION_BIT_NUMBER                         0x1D
#define HCI_EVENT_MASK_PAGE_SCAN_MODE_CHANGE_BIT_NUMBER                 0x1E
#define HCI_EVENT_MASK_PAGE_SCAN_REPETITION_MODE_CHANGE_BIT_NUMBER      0x1F

   /* The following Constants represent Bit Number Constants that are to*/
   /* be used with the EVENT_MASK MACRO's (Set/Reset/Test).  These      */
   /* Constants are used as the second parameter in those MACRO's to    */
   /* specify the correct HCI Bluetooth Event in the Event Mask (Version*/
   /* 1.2).                                                             */
#define HCI_EVENT_MASK_FLOW_SPECIFICATION_BIT_NUMBER                    0x20
#define HCI_EVENT_MASK_INQUIRY_RESULT_WITH_RSSI_BIT_NUMBER              0x21
#define HCI_EVENT_MASK_READ_REMOTE_EXTENDED_FEATURES_COMPLETE_BIT_NUMBER 0x22
#define HCI_EVENT_MASK_SYNCHRONOUS_CONNECTION_COMPLETE_BIT_NUMBER       0x2B
#define HCI_EVENT_MASK_SYNCHRONOUS_CONNECTION_CHANGED_BIT_NUMBER        0x2C

   /* The following Constants represent Bit Number Constants that are to*/
   /* be used with the EVENT_MASK MACRO's (Set/Reset/Test).  These      */
   /* Constants are used as the second parameter in those MACRO's to    */
   /* specify the correct HCI Bluetooth Event in the Event Mask (Version*/
   /* 2.1).                                                             */
#define HCI_EVENT_MASK_SNIFF_SUBRATING_BIT_NUMBER                             0x2D
#define HCI_EVENT_MASK_EXTENDED_INQUIRY_RESULT_BIT_NUMBER                     0x2E
#define HCI_EVENT_MASK_ENCRYPTION_REFRESH_COMPLETE_BIT_NUMBER                 0x2F
#define HCI_EVENT_MASK_IO_CAPABILITY_REQUEST_BIT_NUMBER                       0x30
#define HCI_EVENT_MASK_IO_CAPABILITY_REQUEST_REPLY_BIT_NUMBER                 0x31
#define HCI_EVENT_MASK_USER_CONFIRMATION_REQUEST_BIT_NUMBER                   0x32
#define HCI_EVENT_MASK_USER_PASSKEY_REQUEST_BIT_NUMBER                        0x33
#define HCI_EVENT_MASK_REMOTE_OOB_DATA_REQUEST_BIT_NUMBER                     0x34
#define HCI_EVENT_MASK_SIMPLE_PAIRING_COMPLETE_BIT_NUMBER                     0x35
#define HCI_EVENT_MASK_LINK_SUPERVISION_TIMEOUT_CHANGED_BIT_NUMBER            0x37
#define HCI_EVENT_MASK_ENHANCED_FLUSH_COMPLETE_BIT_NUMBER                     0x38
#define HCI_EVENT_MASK_USER_PASSKEY_NOTIFICATION_BIT_NUMBER                   0x39
#define HCI_EVENT_MASK_USER_KEYPRESS_NOTIFICATION_BIT_NUMBER                  0x3A
#define HCI_EVENT_MASK_REMOTE_HOST_SUPPORTED_FEATURES_NOTIFICATION_BIT_NUMBER 0x3B

   /* The following MACRO is a utility MACRO that exists to aid the     */
   /* user in Enabling ALL defined HCI Events in the HCI Event Mask.    */
   /* This MACRO accepts as input the Event Mask (of type Event_Mask_t) */
   /* to enable All Defined Events for.                                 */
   /* * NOTE * This MACRO is only valid for Events located in the Page  */
   /*          1 Event Mask NOT the Page 2 Event Mask !!!!!!!!!!!!!!!!! */
#define HCI_ENABLE_ALL_HCI_EVENTS_IN_EVENT_MASK(_x)                                              \
{                                                                                                \
   ASSIGN_EVENT_MASK((_x), 0, 0, 0, 0, 0, 0, 0, 0);                                              \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_INQUIRY_COMPLETE_BIT_NUMBER);                         \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_INQUIRY_RESULT_BIT_NUMBER);                           \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_CONNECTION_COMPLETE_BIT_NUMBER);                      \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_CONNECTION_REQUEST_BIT_NUMBER);                       \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_DISCONNECTION_COMPLETE_BIT_NUMBER);                   \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_AUTHENTICAITION_COMPLETE_BIT_NUMBER);                 \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_REMOTE_NAME_REQUEST_COMPLETE_BIT_NUMBER);             \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_ENCRYPTION_CHANGE_BIT_NUMBER);                        \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_CHANGE_CONNECTION_LINK_KEY_COMPLETE_BIT_NUMBER);      \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_MASTER_LINK_KEY_COMPLETE_BIT_NUMBER);                 \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_READ_REMOTE_SUPPORTED_FEATURES_COMPLETE_BIT_NUMBER);  \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_READ_REMOTE_VERSION_INFORMATION_COMPLETE_BIT_NUMBER); \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_QOS_SETUP_COMPLETE_BIT_NUMBER);                       \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_COMMAND_COMPLETE_BIT_NUMBER);                         \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_STATUS_COMMAND_BIT_NUMBER);                           \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_HARDWARE_ERROR_BIT_NUMBER);                           \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_FLUSH_OCCURRED_BIT_NUMBER);                           \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_ROLE_CHANGE_BIT_NUMBER);                              \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_NUMBER_OF_COMPLETED_PACKETS_BIT_NUMBER);              \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_MODE_CHANGE_BIT_NUMBER);                              \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_RETURN_LINK_KEYS_BIT_NUMBER);                         \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_PIN_CODE_REQUEST_BIT_NUMBER);                         \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_LINK_KEY_REQUEST_BIT_NUMBER);                         \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_LINK_KEY_NOTIFICATION_BIT_NUMBER);                    \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_LOOPBACK_COMMAND_BIT_NUMBER);                         \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_DATA_BUFFER_OVERFLOW_BIT_NUMBER);                     \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_MAX_SLOTS_CHANGE_BIT_NUMBER);                         \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_READ_CLOCK_OFFSET_COMPLETE_BIT_NUMBER);               \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_CONNECTION_PACKET_TYPE_CHANGED_BIT_NUMBER);           \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_QOS_VIOLATION_BIT_NUMBER);                            \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_PAGE_SCAN_MODE_CHANGE_BIT_NUMBER);                    \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_PAGE_SCAN_REPETITION_MODE_CHANGE_BIT_NUMBER);         \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_FLOW_SPECIFICATION_BIT_NUMBER);                       \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_INQUIRY_RESULT_WITH_RSSI_BIT_NUMBER);                 \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_READ_REMOTE_EXTENDED_FEATURES_COMPLETE_BIT_NUMBER);   \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_SYNCHRONOUS_CONNECTION_COMPLETE_BIT_NUMBER);          \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_SYNCHRONOUS_CONNECTION_CHANGED_BIT_NUMBER);           \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_SNIFF_SUBRATING_BIT_NUMBER);                             \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_EXTENDED_INQUIRY_RESULT_BIT_NUMBER);                     \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_ENCRYPTION_REFRESH_COMPLETE_BIT_NUMBER);                 \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_IO_CAPABILITY_REQUEST_BIT_NUMBER);                       \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_IO_CAPABILITY_REQUEST_REPLY_BIT_NUMBER);                 \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_USER_CONFIRMATION_REQUEST_BIT_NUMBER);                   \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_USER_PASSKEY_REQUEST_BIT_NUMBER);                        \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_REMOTE_OOB_DATA_REQUEST_BIT_NUMBER);                     \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_SIMPLE_PAIRING_COMPLETE_BIT_NUMBER);                     \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_LINK_SUPERVISION_TIMEOUT_CHANGED_BIT_NUMBER);            \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_ENHANCED_FLUSH_COMPLETE_BIT_NUMBER);                     \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_USER_PASSKEY_NOTIFICATION_BIT_NUMBER);                   \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_USER_KEYPRESS_NOTIFICATION_BIT_NUMBER);                  \
   SET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_REMOTE_HOST_SUPPORTED_FEATURES_NOTIFICATION_BIT_NUMBER); \
}

   /* The following MACRO is a utility MACRO that exists to aid the     */
   /* user in Disabling ALL defined HCI Events in the HCI Event Mask.   */
   /* This MACRO accepts as input the Event Mask (of type Event_Mask_t) */
   /* to disable All Defined Events for.                                */
   /* * NOTE * This MACRO is only valid for Events located in the Page  */
   /*          1 Event Mask NOT the Page 2 Event Mask !!!!!!!!!!!!!!!!! */
#define HCI_DISABLE_ALL_HCI_EVENTS_IN_EVENT_MASK(_x)                                               \
{                                                                                                  \
   ASSIGN_EVENT_MASK((_x), 0, 0, 0, 0, 0, 0, 0, 0);                                                \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_INQUIRY_COMPLETE_BIT_NUMBER);                         \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_INQUIRY_RESULT_BIT_NUMBER);                           \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_CONNECTION_COMPLETE_BIT_NUMBER);                      \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_CONNECTION_REQUEST_BIT_NUMBER);                       \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_DISCONNECTION_COMPLETE_BIT_NUMBER);                   \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_AUTHENTICAITION_COMPLETE_BIT_NUMBER);                 \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_REMOTE_NAME_REQUEST_COMPLETE_BIT_NUMBER);             \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_ENCRYPTION_CHANGE_BIT_NUMBER);                        \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_CHANGE_CONNECTION_LINK_KEY_COMPLETE_BIT_NUMBER);      \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_MASTER_LINK_KEY_COMPLETE_BIT_NUMBER);                 \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_READ_REMOTE_SUPPORTED_FEATURES_COMPLETE_BIT_NUMBER);  \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_READ_REMOTE_VERSION_INFORMATION_COMPLETE_BIT_NUMBER); \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_QOS_SETUP_COMPLETE_BIT_NUMBER);                       \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_COMMAND_COMPLETE_BIT_NUMBER);                         \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_STATUS_COMMAND_BIT_NUMBER);                           \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_HARDWARE_ERROR_BIT_NUMBER);                           \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_FLUSH_OCCURRED_BIT_NUMBER);                           \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_ROLE_CHANGE_BIT_NUMBER);                              \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_NUMBER_OF_COMPLETED_PACKETS_BIT_NUMBER);              \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_MODE_CHANGE_BIT_NUMBER);                              \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_RETURN_LINK_KEYS_BIT_NUMBER);                         \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_PIN_CODE_REQUEST_BIT_NUMBER);                         \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_LINK_KEY_REQUEST_BIT_NUMBER);                         \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_LINK_KEY_NOTIFICATION_BIT_NUMBER);                    \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_LOOPBACK_COMMAND_BIT_NUMBER);                         \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_DATA_BUFFER_OVERFLOW_BIT_NUMBER);                     \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_MAX_SLOTS_CHANGE_BIT_NUMBER);                         \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_READ_CLOCK_OFFSET_COMPLETE_BIT_NUMBER);               \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_CONNECTION_PACKET_TYPE_CHANGED_BIT_NUMBER);           \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_QOS_VIOLATION_BIT_NUMBER);                            \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_PAGE_SCAN_MODE_CHANGE_BIT_NUMBER);                    \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_PAGE_SCAN_REPETITION_MODE_CHANGE_BIT_NUMBER);         \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_FLOW_SPECIFICATION_BIT_NUMBER);                       \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_INQUIRY_RESULT_WITH_RSSI_BIT_NUMBER);                 \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_READ_REMOTE_EXTENDED_FEATURES_COMPLETE_BIT_NUMBER);   \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_SYNCHRONOUS_CONNECTION_COMPLETE_BIT_NUMBER);          \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_SYNCHRONOUS_CONNECTION_CHANGED_BIT_NUMBER);           \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_SNIFF_SUBRATING_BIT_NUMBER);                             \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_EXTENDED_INQUIRY_RESULT_BIT_NUMBER);                     \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_ENCRYPTION_REFRESH_COMPLETE_BIT_NUMBER);                 \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_IO_CAPABILITY_REQUEST_BIT_NUMBER);                       \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_IO_CAPABILITY_REQUEST_REPLY_BIT_NUMBER);                 \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_USER_CONFIRMATION_REQUEST_BIT_NUMBER);                   \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_USER_PASSKEY_REQUEST_BIT_NUMBER);                        \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_REMOTE_OOB_DATA_REQUEST_BIT_NUMBER);                     \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_SIMPLE_PAIRING_COMPLETE_BIT_NUMBER);                     \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_LINK_SUPERVISION_TIMEOUT_CHANGED_BIT_NUMBER);            \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_ENHANCED_FLUSH_COMPLETE_BIT_NUMBER);                     \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_USER_PASSKEY_NOTIFICATION_BIT_NUMBER);                   \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_USER_KEYPRESS_NOTIFICATION_BIT_NUMBER);                  \
   RESET_EVENT_MASK_BIT((_x), HCI_EVENT_MASK_REMOTE_HOST_SUPPORTED_FEATURES_NOTIFICATION_BIT_NUMBER); \
}

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Minimum and Maximum Acceptable Values for Connection Handles.     */
#define HCI_CONNECTION_HANDLE_MINIMUM_VALUE                             0x0000
#define HCI_CONNECTION_HANDLE_MAXIMUM_VALUE                             0x0EFF

   /* The following Constant represents a Bluetooth HCI Connection      */
   /* Handle value that is guaranteed to be invalid.                    */
#define HCI_CONNECTION_HANDLE_INVALID_VALUE                             0xF000

   /* The following MACRO is a utility MACRO that exists to aid code    */
   /* readability of testing whether or not a specified Connection      */
   /* Handle is valid.  The first parameter to this MACRO is the        */
   /* Connection Handle Value to verify.  This MACRO returns a          */
   /* boolean value based upon whether or not the specified Connection  */
   /* Handle value is valid.  This MACRO returns a boolean TRUE if the  */
   /* specified Connection Handle is valid, or a boolean FALSE if the   */
   /* specified Connection Handle value is invalid.                     */
#define HCI_CONNECTION_HANDLE_VALID_CONNECTION_HANDLE(_x)               (((_x) >= HCI_CONNECTION_HANDLE_MINIMUM_VALUE) && ((_x) <= HCI_CONNECTION_HANDLE_MAXIMUM_VALUE))

   /* The following Constants represent the defined Bluetooth HCI ACL   */
   /* Packet Types.                                                     */
#define HCI_PACKET_ACL_TYPE_DM1                                         0x0008
#define HCI_PACKET_ACL_TYPE_DH1                                         0x0010
#define HCI_PACKET_ACL_TYPE_DM3                                         0x0400
#define HCI_PACKET_ACL_TYPE_DH3                                         0x0800
#define HCI_PACKET_ACL_TYPE_DM5                                         0x4000
#define HCI_PACKET_ACL_TYPE_DH5                                         0x8000

   /* The following constants represent the defined Bluetooth HCI ACL   */
   /* extended packet types (Version 2.0).                              */
   /* * NOTE * These types are different in that they specify packet    */
   /*          type that MAY NOT be used (rather than packet types that */
   /*          MAY be used).                                            */
#define HCI_PACKET_ACL_TYPE_2_DH1_MAY_NOT_BE_USED                       0x0002
#define HCI_PACKET_ACL_TYPE_3_DH1_MAY_NOT_BE_USED                       0x0004

#define HCI_PACKET_ACL_TYPE_2_DH3_MAY_NOT_BE_USED                       0x0100
#define HCI_PACKET_ACL_TYPE_3_DH3_MAY_NOT_BE_USED                       0x0200

#define HCI_PACKET_ACL_TYPE_2_DH5_MAY_NOT_BE_USED                       0x1000
#define HCI_PACKET_ACL_TYPE_3_DH5_MAY_NOT_BE_USED                       0x2000

   /* The following Constants represent the defined Bluetooth HCI Page  */
   /* Scan Repetition Mode Types.                                       */
#define HCI_PAGE_SCAN_REPETITION_MODE_R0                                0x00
#define HCI_PAGE_SCAN_REPETITION_MODE_R1                                0x01
#define HCI_PAGE_SCAN_REPETITION_MODE_R2                                0x02

   /* The following Constants represent the defined Bluetooth HCI Page  */
   /* Scan Mode Types.                                                  */
#define HCI_PAGE_SCAN_MODE_MANDATORY                                    0x00
#define HCI_PAGE_SCAN_MODE_OPTIONAL_I                                   0x01
#define HCI_PAGE_SCAN_MODE_OPTIONAL_II                                  0x02
#define HCI_PAGE_SCAN_MODE_OPTIONAL_III                                 0x03

   /* The following Constants represent the defined Bluetooth HCI Page  */
   /* Scan Types (Version 1.2).                                         */
#define HCI_PAGE_SCAN_TYPE_MANDATORY_STANDARD_SCAN                      0x00
#define HCI_PAGE_SCAN_TYPE_OPTIONAL_INTERLACED_SCAN                     0x01

   /* The following Constants represent the defined Bluetooth HCI Clock */
   /* Offset Bit Mask values.                                           */
#define HCI_CLOCK_OFFSET_CLK_SLAVE_CLK_MASTER_MASK                      0x7FFF
#define HCI_CLOCK_OFFSET_VALID_FLAG_MASK                                0x8000

   /* The following Constants represent the defined Bluetooth HCI Role  */
   /* Switch Options.                                                   */
#define HCI_ROLE_SWITCH_LOCAL_MASTER_NO_ROLE_SWITCH                     0x00
#define HCI_ROLE_SWITCH_LOCAL_MASTER_ACCEPT_ROLE_SWITCH                 0x01

   /* The following Constants represent the defined Bluetooth HCI SCO   */
   /* Packet Types.                                                     */
#define HCI_PACKET_SCO_TYPE_HV1                                         0x0020
#define HCI_PACKET_SCO_TYPE_HV2                                         0x0040
#define HCI_PACKET_SCO_TYPE_HV3                                         0x0080

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Synchronous Connection Packet Types (SCO and eSCO in Version 1.2  */
   /* only).                                                            */
#define HCI_PACKET_SYNCHRONOUS_CONNECTION_TYPE_HV1                      0x0001
#define HCI_PACKET_SYNCHRONOUS_CONNECTION_TYPE_HV2                      0x0002
#define HCI_PACKET_SYNCHRONOUS_CONNECTION_TYPE_HV3                      0x0004
#define HCI_PACKET_SYNCHRONOUS_CONNECTION_TYPE_EV3                      0x0008
#define HCI_PACKET_SYNCHRONOUS_CONNECTION_TYPE_EV4                      0x0010
#define HCI_PACKET_SYNCHRONOUS_CONNECTION_TYPE_EV5                      0x0020

   /* The following constants represent the defined Bluetooth HCI eSCO  */
   /* extended packet types (Version 2.0).                              */
   /* * NOTE * These types are different in that they specify packet    */
   /*          type that MAY NOT be used (rather than packet types that */
   /*          MAY be used).                                            */
#define HCI_PACKET_SYNCHRONOUS_CONNECTION_TYPE_2_EV3_MAY_NOT_BE_USED    0x0040
#define HCI_PACKET_SYNCHRONOUS_CONNECTION_TYPE_3_EV3_MAY_NOT_BE_USED    0x0080

#define HCI_PACKET_SYNCHRONOUS_CONNECTION_TYPE_2_EV5_MAY_NOT_BE_USED    0x0100
#define HCI_PACKET_SYNCHRONOUS_CONNECTION_TYPE_3_EV5_MAY_NOT_BE_USED    0x0200

   /* The following constants are placeholders for the reserved bits    */
   /* in the packet type field.                                         */
#define HCI_PACKET_SYNCHRONOUS_CONNECTION_TYPE_RESERVED0                0x0400
#define HCI_PACKET_SYNCHRONOUS_CONNECTION_TYPE_RESERVED1                0x0800
#define HCI_PACKET_SYNCHRONOUS_CONNECTION_TYPE_RESERVED2                0x1000
#define HCI_PACKET_SYNCHRONOUS_CONNECTION_TYPE_RESERVED3                0x2000
#define HCI_PACKET_SYNCHRONOUS_CONNECTION_TYPE_RESERVED4                0x4000
#define HCI_PACKET_SYNCHRONOUS_CONNECTION_TYPE_RESERVED5                0x8000

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Synchronous Connecton Maximum Latency Type values (Version 1.2    */
   /* only).                                                            */
#define HCI_SYNCHRONOUS_CONNECTION_MAX_LATENCY_MINIMUM                  0x0004
#define HCI_SYNCHRONOUS_CONNECTION_MAX_LATENCY_MAXIMUM                  0xFFFE
#define HCI_SYNCHRONOUS_CONNECTION_MAX_LATENCY_DONT_CARE                0xFFFF

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Synchronous Connection Retransmission Effort Type values (Version */
   /* 1.2 only).                                                        */
#define HCI_SYNCHRONOUS_CONNECTION_RETRANSMISSION_EFFORT_NONE                 0x00
#define HCI_SYNCHRONOUS_CONNECTION_RETRANSMISSION_EFFORT_ONE_OPTIMIZE_POWER   0x01
#define HCI_SYNCHRONOUS_CONNECTION_RETRANSMISSION_EFFORT_ONE_OPTIMIZE_QUALITY 0x02
#define HCI_SYNCHRONOUS_CONNECTION_RETRANSMISSION_EFFORT_DONT_CARE            0xFF

   /* The following Constants represent the defined Bluetooth Values    */
   /* that specify specific Bluetooth HCI Transmit and Receive Bandwidth*/
   /* values when Accepting Synchronous Connections (Version 1.2).      */
#define HCI_SYNCHRONOUS_CONNECTION_ACCEPT_TRANSMIT_BANDWIDTH_MINIMUM    0x00000000
#define HCI_SYNCHRONOUS_CONNECTION_ACCEPT_TRANSMIT_BANDWIDTH_MAXIMUM    0xFFFFFFFE
#define HCI_SYNCHRONOUS_CONNECTION_ACCEPT_TRANSMIT_BANDWIDTH_DONT_CARE  0xFFFFFFFF

#define HCI_SYNCHRONOUS_CONNECTION_ACCEPT_RECEIVE_BANDWIDTH_MINIMUM     0x00000000
#define HCI_SYNCHRONOUS_CONNECTION_ACCEPT_RECEIVE_BANDWIDTH_MAXIMUM     0xFFFFFFFE
#define HCI_SYNCHRONOUS_CONNECTION_ACCEPT_RECEIVE_BANDWIDTH_DONT_CARE   0xFFFFFFFF

   /* The following constants represent the defined Bluetooth Values    */
   /* that specify the specific Bluetooth HCI I/O Capabilities values   */
   /* used with I/O Capability commands (Version 2.1).                  */
#define HCI_IO_CAPABILITY_DISPLAY_ONLY                                  0x00
#define HCI_IO_CAPABILITY_DISPLAY_YES_NO                                0x01
#define HCI_IO_CAPABILITY_KEYBOARD_ONLY                                 0x02
#define HCI_IO_CAPABILITY_NO_INPUT_NO_OUTPUT                            0x03

   /* The following constants are used with the HCI I/O Capabilities    */
   /* values used with the I/O Capability Events (Version 2.1).         */
#define HCI_IO_CAPABILITY_OOB_AUTHENTICATION_DATA_NOT_PRESENT           0x00
#define HCI_IO_CAPABILITY_OOB_AUTHENTICATION_DATA_PRESENT               0x01

   /* The following constants are used with the HCI I/O Capabilities    */
   /* values with the I/O Capability Events (Version 2.1).              */
#define HCI_AUTHENTICATION_REQUIREMENTS_MITM_PROTECTION_NOT_REQUIRED_NO_BONDING        0x00
#define HCI_AUTHENTICATION_REQUIREMENTS_MITM_PROTECTION_REQUIRED_NO_BONDING            0x01
#define HCI_AUTHENTICATION_REQUIREMENTS_MITM_PROTECTION_NOT_REQUIRED_DEDICATED_BONDING 0x02
#define HCI_AUTHENTICATION_REQUIREMENTS_MITM_PROTECTION_REQUIRED_DEDICATED_BONDING     0x03
#define HCI_AUTHENTICATION_REQUIREMENTS_MITM_PROTECTION_NOT_REQUIRED_GENERAL_BONDING   0x04
#define HCI_AUTHENTICATION_REQUIREMENTS_MITM_PROTECTION_REQUIRED_GENERAL_BONDING       0x05

   /* The following constants represent the defined Bluetooth Values    */
   /* that specify the specific Bluetooth HCI minimum and maximum       */
   /* Passkey values used during Simple Pairing (Version 2.1).          */
#define HCI_PASSKEY_NUMERIC_VALUE_MINIMUM                               0x00000000
#define HCI_PASSKEY_NUMERIC_VALUE_MAXIMUM                               0x000F423F

   /* The following constants represent the defined minimum and maximum */
   /* timeout values that are used with the Bluetooth Sniff Subrating   */
   /* HCI commands (Version 2.1).                                       */
#define HCI_SNIFF_SUBRATING_TIMEOUT_MINIMUM                             0x0000
#define HCI_SNIFF_SUBRATING_TIMEOUT_MAXIMUM                             0xFFFE

   /* The following Constants represent the defined Bluetooth Values    */
   /* that specify a specific Bluetooth HCI Air Mode Format for         */
   /* Synchronous Connections (Version 1.2)                             */
#define HCI_AIR_MODE_FORMAT_U_LAW                                       0x00
#define HCI_AIR_MODE_FORMAT_A_LAW                                       0x01
#define HCI_AIR_MODE_FORMAT_CVSD                                        0x02
#define HCI_AIR_MODE_FORMAT_TRANSPARENT_DATA                            0x03

   /* The following Constants represent the defined Bluetooth HCI Role  */
   /* Change Types.                                                     */
#define HCI_ROLE_SWITCH_BECOME_MASTER                                   0x00
#define HCI_ROLE_SWITCH_REMAIN_SLAVE                                    0x01

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Encryption Enable (Link Level) Types.                             */
#define HCI_ENCRYPTION_ENABLE_LINK_LEVEL_OFF                            0x00
#define HCI_ENCRYPTION_ENABLE_LINK_LEVEL_ON                             0x01

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Master Link Key Key Flag Types.                                   */
#define HCI_MASTER_LINK_KEY_USE_SEMI_PERMANENT_LINK_KEYS                0x00
#define HCI_MASTER_LINK_KEY_USE_TEMPORARY_LINK_KEYS                     0x01

   /* The following Constants represent the defined Bluetooth HCI QoS   */
   /* Service Types.                                                    */
#define HCI_QOS_SERVICE_TYPE_NO_TRAFFIC                                 0x00
#define HCI_QOS_SERVICE_TYPE_BEST_EFFORT                                0x01
#define HCI_QOS_SERVICE_TYPE_GUARANTEED                                 0x02

   /* The following Constants represent the defined Bluetooth HCI Flow  */
   /* Specification Flow Direction (Version 1.2).                       */
#define HCI_FLOW_SPECIFICATION_FLOW_DIRECTION_OUTGOING_FLOW             0x00
#define HCI_FLOW_SPECIFICATION_FLOW_DIRECTION_INCOMING_FLOW             0x01

   /* The following Constants represent the defined Bluetooth HCI Flow  */
   /* Specification Service Types (Version 1.2).                        */
#define HCI_FLOW_SPECIFICATION_SERVICE_TYPE_NO_TRAFFIC                  0x00
#define HCI_FLOW_SPECIFICATION_SERVICE_TYPE_BEST_EFFORT                 0x01
#define HCI_FLOW_SPECIFICATION_SERVICE_TYPE_GUARANTEED                  0x02

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Current Role Types.                                               */
#define HCI_CURRENT_ROLE_MASTER                                         0x00
#define HCI_CURRENT_ROLE_SLAVE                                          0x01

   /* The following Constants represent the defined Bluetooth HCI Link  */
   /* Policy Settings Flag Types.                                       */
#define HCI_LINK_POLICY_SETTINGS_DISABLE_ALL_LM_MODES                   0x0000
#define HCI_LINK_POLICY_SETTINGS_ENABLE_MASTER_SLAVE_SWITCH             0x0001
#define HCI_LINK_POLICY_SETTINGS_ENABLE_HOLD_MODE                       0x0002
#define HCI_LINK_POLICY_SETTINGS_ENABLE_SNIFF_MODE                      0x0004
#define HCI_LINK_POLICY_SETTINGS_ENABLE_PARK_MODE                       0x0008

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Country Code Types (Version 1.0B)                                 */
#define HCI_COUNTRY_CODE_NORTH_AMERICA_AND_EUROPE                       0x00
#define HCI_COUNTRY_CODE_FRANCE                                         0x01
#define HCI_COUNTRY_CODE_SPAIN                                          0x02
#define HCI_COUNTRY_CODE_JAPAN                                          0x03

   /* The following Constants represent additional defined Bluetooth    */
   /* HCI Country Code Types (Version 1.1).  The only other Country     */
   /* Code listed above that is valid is HCI_COUNTRY_CODE_FRANCE.       */
#define HCI_COUNTRY_CODE_NORTH_AMERICA_EUROPE_JAPAN_NOT_FRANCE          0x00

   /* The following Constants represent the various Clocks that can be  */
   /* queried via the defined HCI Commands/Events (Version 1.2 only).   */
#define HCI_CLOCK_LOCAL_CLOCK                                           0x00
#define HCI_CLOCK_PICONET_CLOCK                                         0x01

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Loopback Code Types.                                              */
#define HCI_LOOPBACK_MODE_NO_LOOPBACK_MODE                              0x00
#define HCI_LOOPBACK_MODE_ENABLE_LOCAL_LOOPBACK                         0x01
#define HCI_LOOPBACK_MODE_ENABLE_REMOTE_LOOPBACK                        0x02

   /* The following Constants represent the defined Bluetooth HCI Filter*/
   /* Types.                                                            */
#define HCI_FILTER_TYPE_CLEAR                                           0x00
#define HCI_FILTER_TYPE_INQUIRY_RESULT                                  0x01
#define HCI_FILTER_TYPE_CONNECTION_SETUP                                0x02

   /* The following Constants represent the defined Bluetooth HCI Filter*/
   /* Condition Types for the HCI_FILTER_TYPE_INQUIRY_RESULT Type.      */
#define HCI_FILTER_CONDITION_TYPE_RESULT_FILTER_NEW_DEVICE              0x00
#define HCI_FILTER_CONDITION_TYPE_RESULT_FILTER_CLASS_OF_DEVICE         0x01
#define HCI_FILTER_CONDITION_TYPE_RESULT_FILTER_BD_ADDR                 0x02

   /* The following Constants represent the defined Bluetooth HCI Filter*/
   /* Condition Types for the HCI_FILTER_TYPE_CONNECTION_SETUP Type.    */
#define HCI_FILTER_CONDITION_TYPE_CONNECTION_SETUP_NEW_DEVICE           0x00
#define HCI_FILTER_CONDITION_TYPE_CONNECTION_SETUP_CLASS_OF_DEVICE      0x01
#define HCI_FILTER_CONDITION_TYPE_CONNECTION_SETUP_BD_ADDR              0x02

   /* The following Constants represent the defined Bluetooth HCI Auto  */
   /* Accept Flag Types.                                                */
#define HCI_AUTO_ACCEPT_FLAG_DO_NOT_AUTO_ACCEPT                         0x01
#define HCI_AUTO_ACCEPT_FLAG_DO_AUTO_ACCEPT                             0x02

   /* The following Constants represent additional defined Bluetooth    */
   /* HCI Auto Accept Flag Types (Version 1.1).                         */
#define HCI_AUTO_ACCEPT_FLAG_DO_AUTO_ACCEPT_ROLE_SWITCH_DISABLED        0x02
#define HCI_AUTO_ACCEPT_FLAG_DO_AUTO_ACCEPT_ROLE_SWITCH_ENABLED         0x03

   /* The following Constants represent the defined Bluetooth HCI PIN   */
   /* Types.                                                            */
#define HCI_PIN_TYPE_VARIABLE                                           0x00
#define HCI_PIN_TYPE_FIXED                                              0x01

   /* The following Constants represent the defined Bluetooth HCI Read  */
   /* Link Key Flag Types.                                              */
#define HCI_READ_LINK_KEY_BD_ADDR                                       0x00
#define HCI_READ_LINK_KEY_ALL_STORED                                    0x01

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Delete Link Key Flag Types.                                       */
#define HCI_DELETE_LINK_KEY_BD_ADDR                                     0x00
#define HCI_DELETE_LINK_KEY_ALL_STORED                                  0x01

   /* The following Constants represent the defined Bluetooth HCI Scan  */
   /* Enable Types.                                                     */
#define HCI_SCAN_ENABLE_NO_SCANS_ENABLED                                0x00
#define HCI_SCAN_ENABLE_INQUIRY_SCAN_ENABLED_PAGE_SCAN_DISABLED         0x01
#define HCI_SCAN_ENABLE_INQUIRY_SCAN_DISABLED_PAGE_SCAN_ENABLED         0x02
#define HCI_SCAN_ENABLE_INQUIRY_SCAN_ENABLED_PAGE_SCAN_ENABLED          0x03

#define HCI_SCAN_ENABLE_INQUIRY_SCAN_ENABLED_BIT_MASK                   0x01
#define HCI_SCAN_ENABLE_PAGE_SCAN_ENABLED_BIT_MASK                      0x02

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Authentication Enable Types.                                      */
#define HCI_AUTHENTICATION_ENABLE_AUTHENTICATION_DISABLED               0x00
#define HCI_AUTHENTICATION_ENABLE_AUTHENTICATION_ENABLED_ALL_CONNECTIONS 0x01

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Encryption Mode Types.                                            */
#define HCI_ENCRYPTION_MODE_ENCRYPTION_DISABLED                         0x00
#define HCI_ENCRYPTION_MODE_ENCRYPTION_POINT_TO_POINT_PACKETS           0x01
#define HCI_ENCRYPTION_MODE_ENCRYPTION_POINT_TO_POINT_BROADCAST_PACKETS 0x02

   /* The following Constants represent the defined Bluetooth HCI Bit   */
   /* Mask's to apply to the Bluetooth HCI Voice Setting Values.        */
   /* After the correct Mask is applied, the Data can then be tested    */
   /* and/or set with the bit definition values that follow.            */
#define HCI_VOICE_SETTING_INPUT_CODING_MASK                             0x0300
#define HCI_VOICE_SETTING_INPUT_DATA_FORMAT_MASK                        0x00C0
#define HCI_VOICE_SETTING_INPUT_SAMPLE_SIZE_MASK                        0x0020
#define HCI_VOICE_SETTING_LINEAR_PCM_BIT_POS_NUM_MASK                   0x001C
#define HCI_VOICE_SETTING_AIR_CODING_FORMAT_MASK                        0x0003

   /* The following Constants represent the defined Bluetooth HCI Bit   */
   /* Values (based upon the HCI_VOICE_SETTING_INPUT_CODING_MASK        */
   /* Bit Mask) that specify a specific Bluetooth HCI Input Coding      */
   /* Voice Setting.                                                    */
#define HCI_VOICE_SETTING_INPUT_CODING_LINEAR                           0x0000
#define HCI_VOICE_SETTING_INPUT_CODING_U_LAW                            0x0100
#define HCI_VOICE_SETTING_INPUT_CODING_A_LAW                            0x0200

   /* The following Constants represent the defined Bluetooth HCI Bit   */
   /* Values (based upon the HCI_VOICE_SETTING_INPUT_DATA_FORMAT_MASK   */
   /* Bit Mask) that specify a specific Bluetooth HCI Input Data Format */
   /* Voice Setting.                                                    */
#define HCI_VOICE_SETTING_INPUT_DATA_FORMAT_1_COMPLEMENT                0x0000
#define HCI_VOICE_SETTING_INPUT_DATA_FORMAT_2_COMPLEMENT                0x0040
#define HCI_VOICE_SETTING_INPUT_DATA_FORMAT_SIGN_MAGNITUDE              0x0080
#define HCI_VOICE_SETTING_INPUT_DATA_FORMAT_UNSIGNED                    0x00C0

   /* The following Constants represent the defined Bluetooth HCI Bit   */
   /* Values (based upon the HCI_VOICE_SETTING_INPUT_SAMPLE_SIZE_MASK   */
   /* Bit Mask) that specify a specific Bluetooth HCI Input Sample Size */
   /* Voice Setting.                                                    */
#define HCI_VOICE_SETTING_INPUT_SAMPLE_SIZE_8_BIT                       0x0000
#define HCI_VOICE_SETTING_INPUT_SAMPLE_SIZE_16_BIT                      0x0020

   /* The following Constant represents the defined Bluetooth HCI       */
   /* Linear PCM Bit Position Number Shift Value.  This value represents*/
   /* the Number of Bit Positions that a value must be shifted into the */
   /* (or out of) Voice Setting Parameter to get a numerical value of   */
   /* the Number of Linear PCM Bit Positions                            */
#define HCI_VOICE_SETTING_LINEAR_PCM_BIT_POS_NUM_SHIFT_VALUE            0x0002

   /* The following Constants represent the defined Bluetooth HCI Bit   */
   /* Values (based upon the HCI_VOICE_SETTING_AIR_CODING_FORMAT_MASK   */
   /* Bit Mask) that specify a specific Bluetooth HCI Air Coding Format */
   /* Voice Setting.                                                    */
#define HCI_VOICE_SETTING_AIR_CODING_FORMAT_CVSD                        0x0000
#define HCI_VOICE_SETTING_AIR_CODING_FORMAT_U_LAW                       0x0001
#define HCI_VOICE_SETTING_AIR_CODING_FORMAT_A_LAW                       0x0002
#define HCI_VOICE_SETTING_AIR_CODING_FORMAT_NONE                        0x0003

   /* The following Constants represent the defined Bluetooth HCI Bit   */
   /* Values (based upon the HCI_VOICE_SETTING_AIR_CODING_FORMAT_MASK   */
   /* Bit Mask) that specify a specific Bluetooth HCI Air Coding Format */
   /* Voice Setting (Version 1.2)                                       */
#define HCI_VOICE_SETTING_AIR_CODING_FORMAT_TRANSPARENT_DATA            0x0003

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Hold Mode Activity Bit Value Types.                               */
#define HCI_HOLD_MODE_ACTIVITY_MAINTAIN_CURRENT_POWER_STATE             0x00
#define HCI_HOLD_MODE_ACTIVITY_SUSPEND_PAGE_STATE                       0x01
#define HCI_HOLD_MODE_ACTIVITY_SUSPEND_INQUIRY_STATE                    0x02
#define HCI_HOLD_MODE_ACTIVITY_SUSPEND_PERIODIC_INQUIRIES               0x04

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Transmit Power Level Types.                                       */
#define HCI_TRANSMIT_POWER_LEVEL_TYPE_CURRENT                           0x00
#define HCI_TRANSMIT_POWER_LEVEL_TYPE_MAXIMUM                           0x01

   /* The following Constants represent the defined Bluetooth HCI SCO   */
   /* Flow Control Enable Types.                                        */
#define HCI_SCO_FLOW_CONTROL_DISABLE                                    0x00
#define HCI_SCO_FLOW_CONTROL_ENABLE                                     0x01

   /* The following Constants represent the defined Bluetooth HCI Host  */
   /* Flow Control Enable Types.                                        */
#define HCI_HOST_FLOW_CONTROL_ENABLE_OFF                                0x00
#define HCI_HOST_FLOW_CONTROL_ENABLE_ON                                 0x01

   /* The following Constants represent additional defined Bluetooth    */
   /* HCI Host Flow Control Enable Types (Version 1.1).                 */
#define HCI_HOST_FLOW_CONTROL_ENABLE_ACL_ON_SCO_OFF                     0x01
#define HCI_HOST_FLOW_CONTROL_ENABLE_ACL_OFF_SCO_ON                     0x02
#define HCI_HOST_FLOW_CONTROL_ENABLE_ACL_ON_SCO_ON                      0x03

   /* The following Constants represent the defined Bluetooth HCI Page  */
   /* Scan Period Mode Types.                                           */
#define HCI_PAGE_SCAN_PERIOD_MODE_P0                                    0x00
#define HCI_PAGE_SCAN_PERIOD_MODE_P1                                    0x01
#define HCI_PAGE_SCAN_PERIOD_MODE_P2                                    0x02

   /* The following Constants represent the defined Bluetooth HCI Link  */
   /* Type Types.                                                       */
#define HCI_LINK_TYPE_SCO_CONNECTION                                    0x00
#define HCI_LINK_TYPE_ACL_CONNECTION                                    0x01

   /* The following Constants represent the defined Bluetooth HCI Link  */
   /* Type Types (Version 1.2).                                         */
#define HCI_LINK_TYPE_ESCO_CONNECTION                                   0x02

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Current Mode Types.                                               */
#define HCI_CURRENT_MODE_ACTIVE_MODE                                    0x00
#define HCI_CURRENT_MODE_HOLD_MODE                                      0x01
#define HCI_CURRENT_MODE_SNIFF_MODE                                     0x02
#define HCI_CURRENT_MODE_PARK_MODE                                      0x03

   /* The following Constants represent the defined Bluetooth HCI       */
   /* SCO Link Number of Connections.                                   */
#define HCI_NUMBER_SCO_CONNECTIONS_SAME_MASTER                          0x03
#define HCI_NUMBER_SCO_CONNECTIONS_DIFFERENT_MASTER                     0x02

#define HCI_MAX_NUMBER_SCO_CONNECTIONS  ((HCI_NUMBER_SCO_CONNECTIONS_SAME_MASTER>HCI_NUMBER_SCO_CONNECTIONS_DIFFERENT_MASTER)?HCI_NUMBER_SCO_CONNECTIONS_SAME_MASTER:HCI_NUMBER_SCO_CONNECTIONS_DIFFERENT_MASTER)

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Inquiry Scan Types (Version 1.2).                                 */
#define HCI_INQUIRY_SCAN_TYPE_MANDATORY_STANDARD_SCAN                   0x00
#define HCI_INQUIRY_SCAN_TYPE_OPTIONAL_INTERLACED_SCAN                  0x01

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Inquiry Scan Modes (Version 1.2).                                 */
#define HCI_INQUIRY_MODE_STANDARD_INQUIRY_RESULT                        0x00
#define HCI_INQUIRY_MODE_INQUIRY_RESULT_FORMAT_WITH_RSSI                0x01
#define HCI_INQUIRY_MODE_INQUIRY_RESULT_WITH_RSSI_OR_EXTENDED_RESULT    0x02

   /* The following Constants represent the defined Bluetooth HCI AFH   */
   /* Channel Assessment Mode Types (Version 1.2).                      */
#define HCI_AFH_CHANNEL_ASSESSMENT_MODE_CONTROLLER_ASSESSMENT_DISABLED  0x00
#define HCI_AFH_CHANNEL_ASSESSMENT_MODE_CONTROLLER_ASSESSMENT_ENABLED   0x01

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Extended Inquiry Response FEC_Required defined values (Version    */
   /* 2.1).                                                             */
#define HCI_EXTENDED_INQUIRY_RESPONSE_FEC_NOT_REQUIRED                  0x00
#define HCI_EXTENDED_INQUIRY_RESPONSE_FEC_REQUIRED                      0x01

   /* The following Constants represent the defined Bluetooth HCI Simple*/
   /* Pairing Modes (Version 2.1).                                      */
#define HCI_SIMPLE_PAIRING_MODE_NOT_ENABLED                             0x00
#define HCI_SIMPLE_PAIRING_MODE_ENABLED                                 0x01

   /* The following Constants represent the defined Bluetooth HCI       */
   /* minimum and maximum Inquiry Transamit Power values - TX_Power in  */
   /* dBm (Version 2.1).                                                */
#define HCI_INQUIRY_TRANSMIT_POWER_MINIMUM                              (-70)
#define HCI_INQUIRY_TRANSMIT_POWER_MAXIMUM                              (20)

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Keypress Notification Types that are used with Keypress           */
   /* Notification (Version 2.1).                                       */
#define HCI_KEYPRESS_NOTIFICATION_TYPE_PASSKEY_ENTRY_STARTED            0x00
#define HCI_KEYPRESS_NOTIFICATION_TYPE_PASSKEY_DIGIT_ENTERED            0x01
#define HCI_KEYPRESS_NOTIFICATION_TYPE_PASSKEY_DIGIT_ERASED             0x02
#define HCI_KEYPRESS_NOTIFICATION_TYPE_PASSKEY_CLEARED                  0x03
#define HCI_KEYPRESS_NOTIFICATION_TYPE_PASSKEY_ENTRY_COMPLETED          0x04

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Erroneous Data Reporting Flags (Version 2.1).                     */
#define HCI_ERRONEOUS_DATA_REPORTING_NOT_ENABLED                        0x00
#define HCI_ERRONEOUS_DATA_REPORTING_ENABLED                            0x01

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Enhanced Flush Packet Types (Version 2.1).                        */
#define HCI_ENHANCED_FLUSH_PACKET_TYPE_AUTOMATICALLY_FLUSHABLE          0x00

   /* The following Constants represent Bit Number Constants that are to*/
   /* be used with the SUPPORTED_COMMANDS MACRO's (Set/Reset/Test).     */
   /* These Constants are used as the second parameter in those MACRO's */
   /* to specify the correct Supported Command in the Supported_Commands*/
   /* Mask (Version 2.1).                                               */
#define HCI_SUPPORTED_COMMAND_INQUIRY_BIT_NUMBER                                  0x00
#define HCI_SUPPORTED_COMMAND_INQUIRY_CANCEL_BIT_NUMBER                           0x01
#define HCI_SUPPORTED_COMMAND_PERIODIC_INQUIRY_MODE_BIT_NUMBER                    0x02
#define HCI_SUPPORTED_COMMAND_EXIT_PERIODIC_INQUIRY_MODE_BIT_NUMBER               0x03
#define HCI_SUPPORTED_COMMAND_CREATE_CONNECTION_BIT_NUMBER                        0x04
#define HCI_SUPPORTED_COMMAND_DISCONNECT_BIT_NUMBER                               0x05
#define HCI_SUPPORTED_COMMAND_ADD_SCO_CONNECTION_BIT_NUMBER                       0x06
#define HCI_SUPPORTED_COMMAND_CANCEL_CREATE_CONNECTION_BIT_NUMBER                 0x07
#define HCI_SUPPORTED_COMMAND_ACCEPT_CONNECTION_REQUEST_BIT_NUMBER                0x08
#define HCI_SUPPORTED_COMMAND_REJECT_CONNECTION_REQUEST_BIT_NUMBER                0x09
#define HCI_SUPPORTED_COMMAND_LINK_KEY_REQUEST_BIT_NUMBER                         0x0A
#define HCI_SUPPORTED_COMMAND_LINK_KEY_REQUEST_NEGATIVE_REPLY_BIT_NUMBER          0x0B
#define HCI_SUPPORTED_COMMAND_PIN_CODE_REQUEST_BIT_NUMBER                         0x0C
#define HCI_SUPPORTED_COMMAND_PIN_CODE_REQUEST_NEGATIVE_REPLY_BIT_NUMBER          0x0D
#define HCI_SUPPORTED_COMMAND_CHANGE_CONNECTION_PACKET_TYPE_BIT_NUMBER            0x0E
#define HCI_SUPPORTED_COMMAND_AUTHENTICATION_REQUEST_BIT_NUMBER                   0x0F
#define HCI_SUPPORTED_COMMAND_SET_CONNECTION_ENCRYPTION_BIT_NUMBER                0x10
#define HCI_SUPPORTED_COMMAND_CHANGE_CONNECTION_LINK_KEY_BIT_NUMBER               0x11
#define HCI_SUPPORTED_COMMAND_MASTER_LINK_KEY_BIT_NUMBER                          0x12
#define HCI_SUPPORTED_COMMAND_REMOTE_NAME_REQUEST_BIT_NUMBER                      0x13
#define HCI_SUPPORTED_COMMAND_CANCEL_REMOTE_NAME_REQUEST_BIT_NUMBER               0x14
#define HCI_SUPPORTED_COMMAND_READ_REMOTE_SUPPORTED_FEATURES_BIT_NUMBER           0x15
#define HCI_SUPPORTED_COMMAND_READ_REMOTE_EXTENDED_FEATURES_BIT_NUMBER            0x16
#define HCI_SUPPORTED_COMMAND_READ_REMOTE_VERSION_INFORMATION_BIT_NUMBER          0x17
#define HCI_SUPPORTED_COMMAND_READ_CLOCK_OFFSET_BIT_NUMBER                        0x18
#define HCI_SUPPORTED_COMMAND_READ_LMP_HANDLE_BIT_NUMBER                          0x19
#define HCI_SUPPORTED_COMMAND_HOLD_MODE_BIT_NUMBER                                0x21
#define HCI_SUPPORTED_COMMAND_SNIFF_MODE_BIT_NUMBER                               0x22
#define HCI_SUPPORTED_COMMAND_EXIT_SNIFF_MODE_BIT_NUMBER                          0x23
#define HCI_SUPPORTED_COMMAND_PARK_STATE_BIT_NUMBER                               0x24
#define HCI_SUPPORTED_COMMAND_EXIT_PARK_STATE_BIT_NUMBER                          0x25
#define HCI_SUPPORTED_COMMAND_QOS_SETUP_BIT_NUMBER                                0x26
#define HCI_SUPPORTED_COMMAND_ROLE_DISCOVERY_BIT_NUMBER                           0x27
#define HCI_SUPPORTED_COMMAND_SWITCH_ROLE_BIT_NUMBER                              0x28
#define HCI_SUPPORTED_COMMAND_READ_LINK_POLICY_BIT_NUMBER                         0x29
#define HCI_SUPPORTED_COMMAND_WRITE_LINK_POLICY_BIT_NUMBER                        0x2A
#define HCI_SUPPORTED_COMMAND_READ_DEFAULT_LINK_POLICY_BIT_NUMBER                 0x2B
#define HCI_SUPPORTED_COMMAND_WRITE_DEFAULT_LINK_POLICY_BIT_NUMBER                0x2C
#define HCI_SUPPORTED_COMMAND_FLOW_SPECIFICATION_BIT_NUMBER                       0x2D
#define HCI_SUPPORTED_COMMAND_SET_EVENT_MASK_BIT_NUMBER                           0x2E
#define HCI_SUPPORTED_COMMAND_RESET_BIT_NUMBER                                    0x2F
#define HCI_SUPPORTED_COMMAND_SET_EVENT_FILTER_BIT_NUMBER                         0x30
#define HCI_SUPPORTED_COMMAND_FLUSH_BIT_NUMBER                                    0x31
#define HCI_SUPPORTED_COMMAND_READ_PIN_TYPE_BIT_NUMBER                            0x32
#define HCI_SUPPORTED_COMMAND_WRITE_PIN_TYPE_BIT_NUMBER                           0x33
#define HCI_SUPPORTED_COMMAND_CREATE_NEW_UNIT_KEY_BIT_NUMBER                      0x34
#define HCI_SUPPORTED_COMMAND_READ_STORED_LINK_KEY_BIT_NUMBER                     0x35
#define HCI_SUPPORTED_COMMAND_WRITE_STORED_LINK_KEY_BIT_NUMBER                    0x36
#define HCI_SUPPORTED_COMMAND_DELETE_STORED_LINK_KEY_BIT_NUMBER                   0x37
#define HCI_SUPPORTED_COMMAND_WRITE_LOCAL_NAME_BIT_NUMBER                         0x38
#define HCI_SUPPORTED_COMMAND_READ_LOCAL_NAME_BIT_NUMBER                          0x39
#define HCI_SUPPORTED_COMMAND_READ_CONNECTION_ACCEPT_TIMEOUT_BIT_NUMBER           0x3A
#define HCI_SUPPORTED_COMMAND_WRITE_CONNECTION_ACCEPT_TIMEOUT_BIT_NUMBER          0x3B
#define HCI_SUPPORTED_COMMAND_READ_PAGE_TIMEOUT_BIT_NUMBER                        0x3C
#define HCI_SUPPORTED_COMMAND_WRITE_PAGE_TIMEOUT_BIT_NUMBER                       0x3D
#define HCI_SUPPORTED_COMMAND_READ_SCAN_ENABLE_BIT_NUMBER                         0x3E
#define HCI_SUPPORTED_COMMAND_WRITE_SCAN_ENABLE_BIT_NUMBER                        0x3F
#define HCI_SUPPORTED_COMMAND_READ_PAGE_SCAN_ACTIVITY_BIT_NUMBER                  0x40
#define HCI_SUPPORTED_COMMAND_WRITE_PAGE_SCAN_ACTIVITY_BIT_NUMBER                 0x41
#define HCI_SUPPORTED_COMMAND_READ_INQUIRY_SCAN_ACTIVITY_BIT_NUMBER               0x42
#define HCI_SUPPORTED_COMMAND_WRITE_INQUIRY_SCAN_ACTIVITY_BIT_NUMBER              0x43
#define HCI_SUPPORTED_COMMAND_READ_AUTHENTICATION_ENABLE_BIT_NUMBER               0x44
#define HCI_SUPPORTED_COMMAND_WRITE_AUTHENTICATION_ENABLE_BIT_NUMBER              0x45
#define HCI_SUPPORTED_COMMAND_READ_ENCRYPTION_MODE_BIT_NUMBER                     0x46
#define HCI_SUPPORTED_COMMAND_WRITE_ENCRYPTION_MODE_BIT_NUMBER                    0x47
#define HCI_SUPPORTED_COMMAND_READ_CLASS_OF_DEVICE_BIT_NUMBER                     0x48
#define HCI_SUPPORTED_COMMAND_WRITE_CLASS_OF_DEVICE_BIT_NUMBER                    0x49
#define HCI_SUPPORTED_COMMAND_READ_VOICE_SETTING_BIT_NUMBER                       0x4A
#define HCI_SUPPORTED_COMMAND_WRITE_VOICE_SETTING_BIT_NUMBER                      0x4B
#define HCI_SUPPORTED_COMMAND_READ_AUTOMATIC_FLUSH_TIMEOUT_BIT_NUMBER             0x4C
#define HCI_SUPPORTED_COMMAND_WRITE_AUTOMATIC_FLUSH_TIMEOUT_BIT_NUMBER            0x4D
#define HCI_SUPPORTED_COMMAND_READ_NUM_BROADCAST_RETRANSMISSIONS_BIT_NUMBER       0x4E
#define HCI_SUPPORTED_COMMAND_WRITE_NUM_BROADCAST_RETRANSMISSIONS_BIT_NUMBER      0x4F
#define HCI_SUPPORTED_COMMAND_READ_HOLD_MODE_ACTIVITY_BIT_NUMBER                  0x50
#define HCI_SUPPORTED_COMMAND_WRITE_HOLD_MODE_ACTIVITY_BIT_NUMBER                 0x51
#define HCI_SUPPORTED_COMMAND_READ_TRANSMIT_POWER_LEVEL_BIT_NUMBER                0x52
#define HCI_SUPPORTED_COMMAND_READ_SYNCHRONOUS_FLOW_CONTROL_ENABLE_BIT_NUMBER     0x53
#define HCI_SUPPORTED_COMMAND_WRITE_SYNCHRONOUS_FLOW_CONTROL_ENABLE_BIT_NUMBER    0x54
#define HCI_SUPPORTED_COMMAND_SET_HOST_CONTROLLER_TO_HOST_FLOW_CONTROL_BIT_NUMBER 0x55
#define HCI_SUPPORTED_COMMAND_HOST_BUFFER_SIZE_BIT_NUMBER                         0x56
#define HCI_SUPPORTED_COMMAND_HOST_NUMBER_OF_COMPLETED_PACKETS_BIT_NUMBER         0x57
#define HCI_SUPPORTED_COMMAND_READ_LINK_SUPERVISION_TIMEOUT_BIT_NUMBER            0x58
#define HCI_SUPPORTED_COMMAND_WRITE_LINK_SUPERVISION_TIMEOUT_BIT_NUMBER           0x59
#define HCI_SUPPORTED_COMMAND_READ_NUMBER_SUPPORTED_IAC_BIT_NUMBER                0x5A
#define HCI_SUPPORTED_COMMAND_READ_CURRENT_IAC_LAP_BIT_NUMBER                     0x5B
#define HCI_SUPPORTED_COMMAND_WRITE_CURRENT_IAC_LAP_BIT_NUMBER                    0x5C
#define HCI_SUPPORTED_COMMAND_READ_PAGE_SCAN_PERIOD_MODE_BIT_NUMBER               0x5D
#define HCI_SUPPORTED_COMMAND_WRITE_PAGE_SCAN_PERIOD_MODE_BIT_NUMBER              0x5E
#define HCI_SUPPORTED_COMMAND_READ_PAGE_SCAN_MODE_BIT_NUMBER                      0x5F
#define HCI_SUPPORTED_COMMAND_WRITE_PAGE_SCAN_MODE_BIT_NUMBER                     0x60
#define HCI_SUPPORTED_COMMAND_SET_AFH_CHANNEL_CLASSIFICATION_BIT_NUMBER           0x61
#define HCI_SUPPORTED_COMMAND_READ_INQUIRY_SCAN_TYPE_BIT_NUMBER                   0x64
#define HCI_SUPPORTED_COMMAND_WRITE_INQUIRY_SCAN_TYPE_BIT_NUMBER                  0x65
#define HCI_SUPPORTED_COMMAND_READ_INQUIRY_MODE_BIT_NUMBER                        0x66
#define HCI_SUPPORTED_COMMAND_WRITE_INQUIRY_MODE_BIT_NUMBER                       0x67
#define HCI_SUPPORTED_COMMAND_READ_PAGE_SCAN_TYPE_BIT_NUMBER                      0x68
#define HCI_SUPPORTED_COMMAND_WRITE_PAGE_SCAN_TYPE_BIT_NUMBER                     0x69
#define HCI_SUPPORTED_COMMAND_READ_AFH_CHANNEL_ASSESSMENT_MODE_BIT_NUMBER         0x6A
#define HCI_SUPPORTED_COMMAND_WRITE_AFH_CHANNEL_ASSESSMENT_MODE_BIT_NUMBER        0x6B
#define HCI_SUPPORTED_COMMAND_READ_LOCAL_VERSION_INFORMATION_BIT_NUMBER           0x73
#define HCI_SUPPORTED_COMMAND_READ_LOCAL_SUPPORTED_FEATURES_BIT_NUMBER            0x75
#define HCI_SUPPORTED_COMMAND_READ_LOCAL_EXTENDED_FEATURES_BIT_NUMBER             0x76
#define HCI_SUPPORTED_COMMAND_READ_BUFFER_SIZE_BIT_NUMBER                         0x77
#define HCI_SUPPORTED_COMMAND_READ_COUNTRY_CODE_BIT_NUMBER                        0x78
#define HCI_SUPPORTED_COMMAND_READ_BD_ADDR_BIT_NUMBER                             0x79
#define HCI_SUPPORTED_COMMAND_READ_FAILED_CONTACT_COUNT_BIT_NUMBER                0x7A
#define HCI_SUPPORTED_COMMAND_RESET_FAILED_CONTACT_COUNT_BIT_NUMBER               0x7B
#define HCI_SUPPORTED_COMMAND_GET_LINK_QUALITY_BIT_NUMBER                         0x7C
#define HCI_SUPPORTED_COMMAND_READ_RSSI_BIT_NUMBER                                0x7D
#define HCI_SUPPORTED_COMMAND_READ_AFH_CHANNEL_MAP_BIT_NUMBER                     0x7E
#define HCI_SUPPORTED_COMMAND_READ_BD_CLOCK_BIT_NUMBER                            0x7F
#define HCI_SUPPORTED_COMMAND_READ_LOOPBACK_MODE_BIT_NUMBER                       0x80
#define HCI_SUPPORTED_COMMAND_WRITE_LOOPBACK_MODE_BIT_NUMBER                      0x81
#define HCI_SUPPORTED_COMMAND_ENABLE_DEVICE_UNDER_TEST_MODE_BIT_NUMBER            0x82
#define HCI_SUPPORTED_COMMAND_SETUP_SYNCHRONOUS_CONNECTION_BIT_NUMBER             0x83
#define HCI_SUPPORTED_COMMAND_ACCEPT_SYNCHRONOUS_CONNECTION_BIT_NUMBER            0x84
#define HCI_SUPPORTED_COMMAND_REJECT_SYNCHRONOUS_CONNECTION_BIT_NUMBER            0x85
#define HCI_SUPPORTED_COMMAND_READ_EXTENDED_INQUIRY_RESPONSE_BIT_NUMBER           0x88
#define HCI_SUPPORTED_COMMAND_WRITE_EXTENDED_INQUIRY_RESPONSE_BIT_NUMBER          0x89
#define HCI_SUPPORTED_COMMAND_REFRESH_ENCRYPTION_KEY_BIT_NUMBER                   0x8A
#define HCI_SUPPORTED_COMMAND_SNIFF_SUBRATING_BIT_NUMBER                          0x8C
#define HCI_SUPPORTED_COMMAND_READ_SIMPLE_PAIRING_MODE_BIT_NUMBER                 0x8D
#define HCI_SUPPORTED_COMMAND_WRITE_SIMPLE_PAIRING_MODE_BIT_NUMBER                0x8E
#define HCI_SUPPORTED_COMMAND_READ_LOCAL_OOB_DATA_BIT_NUMBER                      0x8F
#define HCI_SUPPORTED_COMMAND_READ_INQUIRY_RESPONSE_TRANSMIT_POWER_BIT_NUMBER     0x90
#define HCI_SUPPORTED_COMMAND_WRITE_INQUIRY_TRANSMIT_POWER_LEVEL_BIT_NUMBER       0x91
#define HCI_SUPPORTED_COMMAND_READ_DEFAULT_ERRONEOUS_DATA_REPORTING_BIT_NUMBER    0x92
#define HCI_SUPPORTED_COMMAND_WRITE_DEFAULT_ERRONEOUS_DATA_REPORTING_BIT_NUMBER   0x93
#define HCI_SUPPORTED_COMMAND_IO_CAPABILITY_REQUEST_REPLY_BIT_NUMBER              0x97
#define HCI_SUPPORTED_COMMAND_USER_CONFIRMATION_REQUEST_REPLY_BIT_NUMBER          0x98
#define HCI_SUPPORTED_COMMAND_USER_CONFIRMATION_REQUEST_NEGATIVE_REPLY_BIT_NUMBER 0x99                                0x
#define HCI_SUPPORTED_COMMAND_USER_PASSKEY_REQUEST_REPLY_BIT_NUMBER               0x9A
#define HCI_SUPPORTED_COMMAND_USER_PASSKEY_REQUEST_NEGATIVE_REPLY_BIT_NUMBER      0x9B
#define HCI_SUPPORTED_COMMAND_REMOTE_OOB_DATA_REQUEST_REPLY_BIT_NUMBER            0x9C
#define HCI_SUPPORTED_COMMAND_WRITE_SIMPLE_PAIRING_DEBUG_MODE_BIT_NUMBER          0x9D
#define HCI_SUPPORTED_COMMAND_ENHANCED_FLUSH_BIT_NUMBER                           0x9E
#define HCI_SUPPORTED_COMMAND_REMOTE_OOB_DATA_REQUEST_NEGATIVE_REPLY_BIT_NUMBER   0x9F
#define HCI_SUPPORTED_COMMAND_SEND_KEYPRESS_NOTIFICATION_BIT_NUMBER               0xA2
#define HCI_SUPPORTED_COMMAND_IO_CAPABILITIES_RESPONSE_NEGATIVE_REPLY_BIT_NUMBER  0xA3                              0x
#define HCI_SUPPORTED_COMMAND_CREATE_PHYSICAL_LINK_BIT_NUMBER                     0xB0
#define HCI_SUPPORTED_COMMAND_ACCEPT_PHYSICAL_LINK_BIT_NUMBER                     0xB1
#define HCI_SUPPORTED_COMMAND_DISCONNECT_PHYSICAL_LINK_BIT_NUMBER                 0xB2
#define HCI_SUPPORTED_COMMAND_CREATE_LOGICAL_LINK_BIT_NUMBER                      0xB3
#define HCI_SUPPORTED_COMMAND_ACCEPT_LOGICAL_LINK_BIT_NUMBER                      0xB4
#define HCI_SUPPORTED_COMMAND_DISCONNECT_LOGICAL_LINK_BIT_NUMBER                  0xB5
#define HCI_SUPPORTED_COMMAND_LOGICAL_LINK_CANCEL_BIT_NUMBER                      0xB6
#define HCI_SUPPORTED_COMMAND_FLOW_SPEC_MODIFY_BIT_NUMBER                         0xB7
#define HCI_SUPPORTED_COMMAND_READ_LOGICAL_LINK_ACCEPT_TIMEOUT_BIT_NUMBER         0xB8
#define HCI_SUPPORTED_COMMAND_WRITE_LOGICAL_LINK_ACCEPT_TIMEOUT_BIT_NUMBER        0xB9
#define HCI_SUPPORTED_COMMAND_SET_EVENT_MASK_PAGE_2_BIT_NUMBER                    0xBA
#define HCI_SUPPORTED_COMMAND_READ_LOCATION_DATA_BIT_NUMBER                       0xBB
#define HCI_SUPPORTED_COMMAND_WRITE_LOCATION_DATA_BIT_NUMBER                      0xBC
#define HCI_SUPPORTED_COMMAND_READ_LOCAL_AMP_INFO_BIT_NUMBER                      0xBD
#define HCI_SUPPORTED_COMMAND_READ_LOCAL_AMP_ASSOC_BIT_NUMBER                     0xBE
#define HCI_SUPPORTED_COMMAND_WRITE_REMOTE_AMP_ASSOC_BIT_NUMBER                   0xBF
#define HCI_SUPPORTED_COMMAND_READ_FLOW_CONTROL_MODE_BIT_NUMBER                   0xC0
#define HCI_SUPPORTED_COMMAND_WRITE_FLOW_CONTROL_MODE_BIT_NUMBER                  0xC1
#define HCI_SUPPORTED_COMMAND_READ_DATA_BLOCK_SIZE_BIT_NUMBER                     0xC2
#define HCI_SUPPORTED_COMMAND_SET_AMP_TRANSMIT_POWER_BIT_NUMBER                   0xC4
#define HCI_SUPPORTED_COMMAND_ENABLE_AMP_RECEIVER_REPORTS_BIT_NUMBER              0xC5
#define HCI_SUPPORTED_COMMAND_AMP_TEST_END_BIT_NUMBER                             0xC6
#define HCI_SUPPORTED_COMMAND_AMP_TEST_COMMAND_BIT_NUMBER                         0xC7
#define HCI_SUPPORTED_COMMAND_READ_BEST_EFFOR_FLUSH_TIMEOUT_BIT_NUMBER            0xCA
#define HCI_SUPPORTED_COMMAND_WRITE_BEST_EFFOR_FLUSH_TIMEOUT_BIT_NUMBER           0xCB
#define HCI_SUPPORTED_COMMAND_SHORT_RANGE_MODE_BIT_NUMBER                         0xCC

   /* The following Constants represent Bit Number Constants that are   */
   /* to be used with the FEATURE MACRO's (Set/Reset/Test).  These      */
   /* Constants are used as the second parameter in those MACRO's to    */
   /* specify the correct LMP Feature in the LMP_Features Mask.         */
#define HCI_LMP_FEATURE_THREE_SLOT_PACKETS_BIT_NUMBER                   0x00
#define HCI_LMP_FEATURE_FIVE_SLOT_PACKETS_BIT_NUMBER                    0x01
#define HCI_LMP_FEATURE_ENCRYPTION_BIT_NUMBER                           0x02
#define HCI_LMP_FEATURE_SLOT_OFFSET_BIT_NUMBER                          0x03
#define HCI_LMP_FEATURE_TIMING_ACCURACY_BIT_NUMBER                      0x04
#define HCI_LMP_FEATURE_SWITCH_BIT_NUMBER                               0x05
#define HCI_LMP_FEATURE_HOLD_MODE_BIT_NUMBER                            0x06
#define HCI_LMP_FEATURE_SNIFF_MODE_BIT_NUMBER                           0x07
#define HCI_LMP_FEATURE_PARK_MODE_BIT_NUMBER                            0x08
#define HCI_LMP_FEATURE_RSSI_BIT_NUMBER                                 0x09
#define HCI_LMP_FEATURE_CHANNEL_QUALITY_DRIVEN_DATA_RATE_BIT_NUMBER     0x0A
#define HCI_LMP_FEATURE_SCO_LINK_BIT_NUMBER                             0x0B
#define HCI_LMP_FEATURE_HV2_PACKETS_BIT_NUMBER                          0x0C
#define HCI_LMP_FEATURE_HV3_PACKETS_BIT_NUMBER                          0x0D
#define HCI_LMP_FEATURE_U_LAW_LOG_BIT_NUMBER                            0x0E
#define HCI_LMP_FEATURE_A_LAW_LOG_BIT_NUMBER                            0x0F
#define HCI_LMP_FEATURE_CVSD_BIT_NUMBER                                 0x10
#define HCI_LMP_FEATURE_PAGING_SCHEME_BIT_NUMBER                        0x11
#define HCI_LMP_FEATURE_POWER_CONTROL_BIT_NUMBER                        0x12

   /* The following Constants represent Bit Number Constants that are to*/
   /* be used with the FEATURE MACRO's (Set/Reset/Test).  These         */
   /* Constants are used as the second parameter in those MACRO's to    */
   /* specify the correct LMP Feature in the LMP_Features Mask (Version */
   /* 1.2).                                                             */
#define HCI_LMP_FEATURE_ROLE_SWITCH_BIT_NUMBER                          0x05
#define HCI_LMP_FEATURE_PARK_STATE_BIT_NUMBER                           0x08
#define HCI_LMP_FEATURE_POWER_CONTROL_REQUESTS_BIT_NUMBER               0x09
#define HCI_LMP_FEATURE_PAGING_PARAMETER_NEGOTIATION_BIT_NUMBER         0x11
#define HCI_LMP_FEATURE_TRANSPARENT_SYNCHRONOUS_DATA_BIT_NUMBER         0x13
#define HCI_LMP_FEATURE_FLOW_CONTROL_LAG_LEAST_SIGNIFICANT_BIT_BIT_NUMBER 0x14
#define HCI_LMP_FEATURE_FLOW_CONTROL_LAG_MIDDLE_BIT_BIT_NUMBER            0x15
#define HCI_LMP_FEATURE_FLOW_CONTROL_LAG_MOST_SIGNIFICANT_BIT_BIT_NUMBER  0x16
#define HCI_LMP_FEATURE_BROADCAST_ENCRYPTION_BIT_NUMBER                 0x17
#define HCI_LMP_FEATURE_ENHANCED_INQUIRY_SCAN_BIT_NUMBER                0x1B
#define HCI_LMP_FEATURE_INTERLACED_INQUIRY_SCAN_BIT_NUMBER              0x1C
#define HCI_LMP_FEATURE_INTERLACED_PAGE_SCAN_BIT_NUMBER                 0x1D
#define HCI_LMP_FEATURE_RSSI_WITH_INQUIRY_RESULTS_BIT_NUMBER            0x1E
#define HCI_LMP_FEATURE_EXTENDED_SCO_LINKS_EV3_PACKETS_BIT_NUMBER       0x1F
#define HCI_LMP_FEATURE_EXTENDED_EV4_PACKETS_BIT_NUMBER                 0x20
#define HCI_LMP_FEATURE_EXTENDED_EV5_PACKETS_BIT_NUMBER                 0x21
#define HCI_LMP_FEATURE_EXTENDED_AFH_CAPABLE_SLAVE_BIT_NUMBER           0x23
#define HCI_LMP_FEATURE_EXTENDED_AFH_CLASSIFICATION_SLAVE_BIT_NUMBER    0x24
#define HCI_LMP_FEATURE_EXTENDED_AFH_CAPABLE_MASTER_BIT_NUMBER          0x2B
#define HCI_LMP_FEATURE_EXTENDED_AFH_CLASSIFICATION_MASTER_BIT_NUMBER   0x2C
#define HCI_LMP_FEATURE_EXTENDED_FEATURES_BIT_NUMBER                    0x3F

   /* The following Constants represent Bit Number Constants that are to*/
   /* be used with the FEATURE MACRO's (Set/Reset/Test).  These         */
   /* Constants are used as the second parameter in those MACRO's to    */
   /* specify the correct LMP Feature in the LMP_Features Mask (Version */
   /* 2.0).                                                             */
#define HCI_LMP_FEATURE_ENHANCED_DATA_RATE_ACL_2_MBPS_MODE_BIT_NUMBER   0x19
#define HCI_LMP_FEATURE_ENHANCED_DATA_RATE_ACL_3_MBPS_MODE_BIT_NUMBER   0x1A
#define HCI_LMP_FEATURE_3_SLOT_ENHANCED_DATA_RATE_ACL_PACKETS_BIT_NUMBER 0x27
#define HCI_LMP_FEATURE_5_SLOT_ENHANCED_DATA_RATE_ACL_PACKETS_BIT_NUMBER 0x28
#define HCI_LMP_FEATURE_ENHANCED_DATA_RATE_ESCO_2_MBPS_MODE_BIT_NUMBER  0x2D
#define HCI_LMP_FEATURE_ENHANCED_DATA_RATE_ESCO_3_MBPS_MODE_BIT_NUMBER  0x2E
#define HCI_LMP_FEATURE_3_SLOT_ENHANCED_DATA_RATE_ESCO_PACKETS_BIT_NUMBER 0x2F

   /* The following Constants represent the defined Bluetooth HCI       */
   /* PIN Code Length Minimum and Maximum Length Values.                */
#define HCI_PIN_CODE_LENGTH_MINIMUM                                     0x01
#define HCI_PIN_CODE_LENGTH_MAXIMUM                                     0x10

   /* The following Constants represent the defined Bluetooth HCI       */
   /* Version Constants (which also dictates the version of the HCI     */
   /* Specification that this HCI Layer supports).                      */
   /* * NOTE * If a Bluetooth HCI Specification value is NOT listed in  */
   /*          this list then it is NOT supported by the HCI API        */
   /*          present in this file.                                    */
#define HCI_VERSION_SPECIFICATION_1_0B                                  0x00
#define HCI_VERSION_SPECIFICATION_1_1                                   0x01
#define HCI_VERSION_SPECIFICATION_1_2                                   0x02
#define HCI_VERSION_SPECIFICATION_2_0                                   0x03
#define HCI_VERSION_SPECIFICATION_2_1                                   0x04

   /* The following Constants represent the defined Bluetooth Link      */
   /* Manager Protocol (LMP) Version values for the LMP Version HCI     */
   /* Commands.                                                         */
#define HCI_LMP_VERSION_BLUETOOTH_1_0                                   0x00
#define HCI_LMP_VERSION_BLUETOOTH_1_1                                   0x01
#define HCI_LMP_VERSION_BLUETOOTH_1_2                                   0x02
#define HCI_LMP_VERSION_BLUETOOTH_2_0                                   0x03
#define HCI_LMP_VERSION_BLUETOOTH_2_1                                   0x04

   /* The following Constants represent the defined Bluetooth Link      */
   /* Manger Protocol LMP_CompID Codes (Manufacturer Names in HCI       */
   /* Command).                                                         */
#define HCI_LMP_COMPID_MANUFACTURER_NAME_ERICSSON_MOBILE_COMMUNICATIONS 0x0000
#define HCI_LMP_COMPID_MANUFACTURER_NAME_NOKIA_MOBILE_PHONES            0x0001
#define HCI_LMP_COMPID_MANUFACTURER_NAME_INTEL_CORPORATION              0x0002
#define HCI_LMP_COMPID_MANUFACTURER_NAME_IBM_CORPORATION                0x0003
#define HCI_LMP_COMPID_MANUFACTURER_NAME_TOSHIBA_CORPORATION            0x0004

   /* The following Constants represent the additional defined          */
   /* Bluetooth Link Manger Protocol LMP_CompID Codes (Manufacturer     */
   /* Names in HCI Command) for Bluetooth Specification after Version   */
   /* 1.1).                                                             */
#define HCI_LMP_COMPID_MANUFACTURER_NAME_3COM                           0x0005
#define HCI_LMP_COMPID_MANUFACTURER_NAME_MICROSOFT                      0x0006
#define HCI_LMP_COMPID_MANUFACTURER_NAME_LUCENT                         0x0007
#define HCI_LMP_COMPID_MANUFACTURER_NAME_MOTOROLA                       0x0008
#define HCI_LMP_COMPID_MANUFACTURER_NAME_INFINEON_TECHNOLOGIES_AG       0x0009
#define HCI_LMP_COMPID_MANUFACTURER_NAME_CAMBRIDGE_SILICON_RADIO        0x000A
#define HCI_LMP_COMPID_MANUFACTURER_NAME_SILICON_WAVE                   0x000B
#define HCI_LMP_COMPID_MANUFACTURER_NAME_DIGIANSWER                     0x000C
#define HCI_LMP_COMPID_MANUFACTURER_NAME_TEXAS_INSTRUMENTS              0x000D
#define HCI_LMP_COMPID_MANUFACTURER_NAME_PARTHUS_TECHNOLOGIES           0x000E
#define HCI_LMP_COMPID_MANUFACTURER_NAME_BROADCOM                       0x000F
#define HCI_LMP_COMPID_MANUFACTURER_NAME_MITEL_SEMICONDUCTOR            0x0010
#define HCI_LMP_COMPID_MANUFACTURER_NAME_ZARLINK_SEMICONDUCTOR          0x0010
#define HCI_LMP_COMPID_MANUFACTURER_NAME_WIDCOMM                        0x0011
#define HCI_LMP_COMPID_MANUFACTURER_NAME_TELENCOMM                      0x0012
#define HCI_LMP_COMPID_MANUFACTURER_NAME_ZEEVO                          0x0012
#define HCI_LMP_COMPID_MANUFACTURER_NAME_ATMEL                          0x0013
#define HCI_LMP_COMPID_MANUFACTURER_NAME_MITSUBISHI                     0x0014
#define HCI_LMP_COMPID_MANUFACTURER_NAME_RTX_TELECOM                    0x0015
#define HCI_LMP_COMPID_MANUFACTURER_NAME_KC_TECHNOLOGY                  0x0016
#define HCI_LMP_COMPID_MANUFACTURER_NAME_NEWLOGIC                       0x0017
#define HCI_LMP_COMPID_MANUFACTURER_NAME_TRANSILICA                     0x0018
#define HCI_LMP_COMPID_MANUFACTURER_NAME_ROHDE_AND_SCHWARTZ             0x0019
#define HCI_LMP_COMPID_MANUFACTURER_NAME_TTPCOM                         0x001A
#define HCI_LMP_COMPID_MANUFACTURER_NAME_SIGNIA_TECHNOLOGIES            0x001B
#define HCI_LMP_COMPID_MANUFACTURER_NAME_CONEXANT_SYSTEMS               0x001C
#define HCI_LMP_COMPID_MANUFACTURER_NAME_QUALCOMM                       0x001D
#define HCI_LMP_COMPID_MANUFACTURER_NAME_INVENTEL                       0x001E
#define HCI_LMP_COMPID_MANUFACTURER_NAME_AVM_BERLIN                     0x001F
#define HCI_LMP_COMPID_MANUFACTURER_NAME_BANDSPEED                      0x0020
#define HCI_LMP_COMPID_MANUFACTURER_NAME_MANSELLA                       0x0021
#define HCI_LMP_COMPID_MANUFACTURER_NAME_NEC                            0x0022
#define HCI_LMP_COMPID_MANUFACTURER_NAME_WAVEPLUS_TECHNOLOGY            0x0023
#define HCI_LMP_COMPID_MANUFACTURER_NAME_ALCATEL                        0x0024
#define HCI_LMP_COMPID_MANUFACTURER_NAME_PHILIPS_SEMICONDUCTORS         0x0025
#define HCI_LMP_COMPID_MANUFACTURER_NAME_C_TECHNOLOGIES                 0x0026
#define HCI_LMP_COMPID_MANUFACTURER_NAME_OPEN_INTERFACE                 0x0027
#define HCI_LMP_COMPID_MANUFACTURER_NAME_RF_MICRO_DEVICES               0x0028
#define HCI_LMP_COMPID_MANUFACTURER_NAME_HITACHI                        0x0029
#define HCI_LMP_COMPID_MANUFACTURER_NAME_SYMBOL_TECHNOLOGIES            0x002A
#define HCI_LMP_COMPID_MANUFACTURER_NAME_TENOVIS                        0x002B
#define HCI_LMP_COMPID_MANUFACTURER_NAME_MACRONIX_INTERNATIONAL         0x002C
#define HCI_LMP_COMPID_MANUFACTURER_NAME_GCT_SEMICONDUCTOR              0x002D
#define HCI_LMP_COMPID_MANUFACTURER_NAME_NORWOOD_SYSTEMS                0x002E
#define HCI_LMP_COMPID_MANUFACTURER_NAME_MEWTEL_TECHNOLOGY              0x002F
#define HCI_LMP_COMPID_MANUFACTURER_NAME_ST_MICROELECTRONICS            0x0030
#define HCI_LMP_COMPID_MANUFACTURER_NAME_SYNOPSYS                       0x0031
#define HCI_LMP_COMPID_MANUFACTURER_NAME_RED_M_COMMUNICATIONS           0x0032
#define HCI_LMP_COMPID_MANUFACTURER_NAME_COMMIL_LTD                     0x0033
#define HCI_LMP_COMPID_MANUFACTURER_NAME_CATC                           0x0034
#define HCI_LMP_COMPID_MANUFACTURER_NAME_ECLIPSE_SL                     0x0035
#define HCI_LMP_COMPID_MANUFACTURER_NAME_RENESAS_TECHNOLOGY_CORP        0x0036
#define HCI_LMP_COMPID_MANUFACTURER_NAME_MOBILIAN_CORPORATION           0x0037
#define HCI_LMP_COMPID_MANUFACTURER_NAME_TERAX                          0x0038
#define HCI_LMP_COMPID_MANUFACTURER_NAME_INTEGRATED_SYSTEM_SOLUTION     0x0039
#define HCI_LMP_COMPID_MANUFACTURER_NAME_MATSUSHITA                     0x003A
#define HCI_LMP_COMPID_MANUFACTURER_NAME_GENNUM_CORPORATION             0x003B
#define HCI_LMP_COMPID_MANUFACTURER_NAME_RESEARCH_IN_MOTION             0x003C
#define HCI_LMP_COMPID_MANUFACTURER_NAME_IPEXTREME                      0x003D
#define HCI_LMP_COMPID_MANUFACTURER_NAME_SYSTEMS_AND_CHIPS              0x003E
#define HCI_LMP_COMPID_MANUFACTURER_NAME_BLUETOOTH_SIG                  0x003F
#define HCI_LMP_COMPID_MANUFACTURER_NAME_SEIKO_EPSON_CORPORATION        0x0040
#define HCI_LMP_COMPID_MANUFACTURER_NAME_INTEGRATED_SILICON_SOLUTION    0x0041
#define HCI_LMP_COMPID_MANUFACTURER_NAME_CONWISE_TECHNOLOGY_CORPORATION 0x0042
#define HCI_LMP_COMPID_MANUFACTURER_NAME_PARROT_SA                      0x0043
#define HCI_LMP_COMPID_MANUFACTURER_NAME_SOCKET_MOBILE                  0x0044
#define HCI_LMP_COMPID_MANUFACTURER_NAME_ATHEROS_COMMUNICATIONS         0x0045
#define HCI_LMP_COMPID_MANUFACTURER_NAME_MEDIATEK_INCORPORATED          0x0046
#define HCI_LMP_COMPID_MANUFACTURER_NAME_BLUEGIGA                       0x0047
#define HCI_LMP_COMPID_MANUFACTURER_NAME_MARVELL_TECHNOLOGY_GROUP       0x0048
#define HCI_LMP_COMPID_MANUFACTURER_NAME_3DSP_CORPORATION               0x0049
#define HCI_LMP_COMPID_MANUFACTURER_NAME_ACCEL_SEMICONDUCTOR            0x0049
#define HCI_LMP_COMPID_MANUFACTURER_NAME_CONTINENTAL_AUTOMOTIVE_SYSTEMS 0x004A
#define HCI_LMP_COMPID_MANUFACTURER_NAME_APPLE_INCORPORATED             0x004B
#define HCI_LMP_COMPID_MANUFACTURER_NAME_STACCATO_COMMUNICATIONS        0x004C
#define HCI_LMP_COMPID_MANUFACTURER_NAME_AVAGO_TECHONOLOGIES            0x004D
#define HCI_LMP_COMPID_MANUFACTURER_NAME_APT_LIMITED                    0x004E
#define HCI_LMP_COMPID_MANUFACTURER_NAME_SIRF_TECHONOLIGY               0x004F
#define HCI_LMP_COMPID_MANUFACTURER_NAME_TZERO_TECHNOLOGIES             0x0050

   /* The following Constant represents the defined COMP ID that is     */
   /* reserved for Interoperatiblity and Link Manager testing.          */
#define HCI_LMP_COMPID_MANUFACTURER_NAME_RESERVED_FOR_LMP_TESTING       0xFFFF

   /* The following Constants represent the defined Bluetooth HCI Link  */
   /* Key Types (Version 1.1).                                          */
#define HCI_LINK_KEY_TYPE_COMBINATION_KEY                               0x00
#define HCI_LINK_KEY_TYPE_LOCAL_UNIT_KEY                                0x01
#define HCI_LINK_KEY_TYPE_REMOTE_UNIT_KEY                               0x02
#define HCI_LINK_KEY_TYPE_DEBUG_COMBINATION_KEY                         0x03
#define HCI_LINK_KEY_TYPE_UNAUTHENTICATED_COMBINATION_KEY               0x04
#define HCI_LINK_KEY_TYPE_AUTHENTICATED_COMBINATION_KEY                 0x05
#define HCI_LINK_KEY_TYPE_CHANGED_COMBINATION_KEY                       0x06
#define HCI_LINK_KEY_TYPE_INVALID_KEY_TYPE                              0xFF

   /* The following Constants represent the defined Class of Device     */
   /* Format Type that can be used with the Class of Device Format      */
   /* Type MACRO's.                                                     */
#define HCI_LMP_CLASS_OF_DEVICE_FORMAT_TYPE_1                           0x00

  /* The following Constants represents the defined Class of Device     */
  /* Major Service Class Types that can be used with the Class of       */
  /* Device Major Service Class MACRO's.                                */
#define HCI_LMP_CLASS_OF_DEVICE_SERVICE_CLASS_LIMITED_DISCOVER_MODE_BIT 0x0001
#define HCI_LMP_CLASS_OF_DEVICE_SERVICE_CLASS_POSITIONING_BIT           0x0008
#define HCI_LMP_CLASS_OF_DEVICE_SERVICE_CLASS_NETWORKING_BIT            0x0010
#define HCI_LMP_CLASS_OF_DEVICE_SERVICE_CLASS_RENDERING_BIT             0x0020
#define HCI_LMP_CLASS_OF_DEVICE_SERVICE_CLASS_CAPTURING_BIT             0x0040
#define HCI_LMP_CLASS_OF_DEVICE_SERVICE_CLASS_OBJECT_TRANSFER_BIT       0x0080
#define HCI_LMP_CLASS_OF_DEVICE_SERVICE_CLASS_AUDIO_BIT                 0x0100
#define HCI_LMP_CLASS_OF_DEVICE_SERVICE_CLASS_TELEPHONY_BIT             0x0200
#define HCI_LMP_CLASS_OF_DEVICE_SERVICE_CLASS_INFORMATION_BIT           0x0400

  /* The following Constants represents the defined Class of Device     */
  /* Major Device Class Types that can be used with the Class of        */
  /* Device Major Device Class MACRO's.                                 */
#define HCI_LMP_CLASS_OF_DEVICE_MAJOR_DEVICE_CLASS_MISCELLANEOUS        0x00
#define HCI_LMP_CLASS_OF_DEVICE_MAJOR_DEVICE_CLASS_COMPUTER             0x01
#define HCI_LMP_CLASS_OF_DEVICE_MAJOR_DEVICE_CLASS_PHONE                0x02
#define HCI_LMP_CLASS_OF_DEVICE_MAJOR_DEVICE_CLASS_LAN_ACCESS_POINT     0x03
#define HCI_LMP_CLASS_OF_DEVICE_MAJOR_DEVICE_CLASS_AUDIO_VIDEO          0x04
#define HCI_LMP_CLASS_OF_DEVICE_MAJOR_DEVICE_CLASS_PERIPHERAL           0x05
#define HCI_LMP_CLASS_OF_DEVICE_MAJOR_DEVICE_CLASS_IMAGING              0x06
#define HCI_LMP_CLASS_OF_DEVICE_MAJOR_DEVICE_CLASS_WEARABLE             0x07
#define HCI_LMP_CLASS_OF_DEVICE_MAJOR_DEVICE_CLASS_TOY                  0x08
#define HCI_LMP_CLASS_OF_DEVICE_MAJOR_DEVICE_CLASS_HEALTH               0x09
#define HCI_LMP_CLASS_OF_DEVICE_MAJOR_DEVICE_CLASS_UNCLASSIFIED         0x1F

  /* The following Constants represents the defined Class of Device     */
  /* Minor Device Class Types that can be used with the Class of        */
  /* Device Minor Device Class MACRO's.                                 */
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_COMPUTER_UNCLASSIFIED 0x00
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_COMPUTER_DESKTOP     0x01
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_COMPUTER_SERVER      0x02
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_COMPUTER_LAPTOP      0x03
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_COMPUTER_HANDHELD    0x04
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_COMPUTER_PALM_PC     0x05
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_COMPUTER_WEARABLE    0x06

#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_PHONE_UNCLASSIFIED   0x00
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_PHONE_CELLULAR       0x01
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_PHONE_CORDLESS       0x02
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_PHONE_SMARTPHONE     0x03
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_PHONE_WIRED_MODEM    0x04
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_PHONE_VOICE_GATEWAY  0x04
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_PHONE_ISDN_ACCESS    0x05

#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_LAN_LOAD_FACTOR_MASK 0x38
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_LAN_SUB_FIELD_MASK   0x07

#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_LAN_FULLY_AVAILABLE  0x00
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_LAN_1_17_UTILIZED    0x08
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_LAN_17_33_UTILIZED   0x10
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_LAN_33_50_UTILIZED   0x18
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_LAN_50_67_UTILIZED   0x20
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_LAN_67_83_UTILIZED   0x28
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_LAN_83_99_UTILIZED   0x30
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_LAN_NO_SERVICE       0x38

#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_LAN_SUB_FIELD_UNCLASSIFIED 0x00

#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_AUDIO_VIDEO_UNCLASSIFIED              0x00
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_AUDIO_VIDEO_HEADSET                   0x01
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_AUDIO_VIDEO_HANDS_FREE                0x02
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_AUDIO_VIDEO_MICROPHONE                0x04
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_AUDIO_VIDEO_LOUD_SPEAKER              0x05
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_AUDIO_VIDEO_HEADPHONES                0x06
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_AUDIO_VIDEO_PORTABLE_AUDIO            0x07
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_AUDIO_VIDEO_CAR_AUDIO                 0x08
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_AUDIO_VIDEO_SET_TOP_BOX               0x09
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_AUDIO_VIDEO_HIFI_AUDIO_DEVICE         0x0A
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_AUDIO_VIDEO_VCR                       0x0B
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_AUDIO_VIDEO_VIDEO_CAMERA              0x0C
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_AUDIO_VIDEO_CAMCORDER                 0x0D
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_AUDIO_VIDEO_VIDEO_MONITOR             0x0E
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_AUDIO_VIDEO_VIDEO_DISPLAY_LOUDSPEAKER 0x0F
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_AUDIO_VIDEO_CONFERENCING              0x10
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_AUDIO_GAMING_TOY                      0x12

#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_PERIPHERAL_UNCLASSIFIED     0x00
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_PERIPHERAL_JOYSTICK         0x01
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_PERIPHERAL_GAMEPAD          0x02
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_PERIPHERAL_REMOTE_CONTROL   0x03
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_PERIPHERAL_SENSING_DEVICE   0x04
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_PERIPHERAL_DIGITIZER_TABLET 0x05
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_PERIPHERAL_CARD_READER      0x06

#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_PERIPHERAL_KEYBOARD_MASK                 0x10
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_PERIPHERAL_POINTING_DEVICE_MASK          0x20
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_PERIPHERAL_KEYBOARD_POINTING_DEVICE_MASK 0x30

#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_IMAGING_UNCLASSIFIED 0x00

#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_IMAGING_DISPLAY_MASK 0x04
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_IMAGING_CAMERA_MASK  0x08
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_IMAGING_SCANNER_MASK 0x10
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_IMAGING_PRINTER_MASK 0x20

#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_WEARABLE_WRIST_WATCH 0x01
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_WEARABLE_PAGER       0x02
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_WEARABLE_JACKET      0x03
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_WEARABLE_HELMET      0x04
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_WEARABLE_GLASSES     0x05

#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_TOY_ROBOT            0x01
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_TOY_VEHICLE          0x02
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_TOY_DOLL_ACTION_FIGURE 0x03
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_TOY_CONTROLLER       0x04
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_CLASS_TOY_GAME             0x05

#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_HEALTH_UNCLASSIFIED        0x00

#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_HEALTH_BLOOD_PRESSURE_MONITOR    0x01
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_HEALTH_THERMOMETER               0x02
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_HEALTH_WEIGHING_SCALE            0x03
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_HEALTH_GLUCOSE_METER             0x04
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_HEALTH_PULSE_OXIMETER            0x05
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_HEALTH_HEART_PULSE_RATE_MONITOR  0x06
#define HCI_LMP_CLASS_OF_DEVICE_MINOR_DEVICE_HEALTH_HEALTH_DATA_DISPLAY       0x07

   /* Restore Structure Packing.                                        */
#pragma pack(pop, __HCITYPESH_PUSH__)

#endif
