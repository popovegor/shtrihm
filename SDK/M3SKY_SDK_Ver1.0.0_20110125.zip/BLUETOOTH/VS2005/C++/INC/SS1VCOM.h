/*****< ss1vcom.h >************************************************************/
/*      Copyright 2001, 2002, 2003, 2004 Stonestreet One, Inc.                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  SS1VCOM - Stonestreet One Virtual COM Port Driver Layer Dynamic Link      */
/*            Library for Windows CE (WINCE Only) Prototypes and Constants.   */
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   01/30/02  D. Lange       Initial creation.                               */
/******************************************************************************/
#ifndef __SS1VCOMH__
#define __SS1VCOMH__

   /* NOTE - Conditional Defines that *MUST* be defined if a DLL is to  */
   /*        Used.                                                      */
#ifdef __IMPORTDLL__
   #define __DLLMODEF__ __declspec(dllimport)
#else
   #ifdef __EXPORTDLL__
      #define __DLLMODEF__ __declspec(dllexport)
   #else
      #define __DLLMODEF__ __declspec(dllimport)
   #endif
#endif

   /* Error Return Codes.                                               */
#define VCOM_DRIVER_ERROR_INVALID_PORT_NUMBER   (-1)    /* Error that denotes */
                                                        /* that the specified */
                                                        /* Virtual COM Port   */
                                                        /* Number is invalid. */

#define VCOM_DRIVER_ERROR_UNSUPPORTED_PORT      (-2)    /* Error that denotes */
                                                        /* that the specified */
                                                        /* Virtual COM Port   */
                                                        /* cannot be opened   */
                                                        /* because it cannot  */
                                                        /* be located in the  */
                                                        /* System.            */

#define VCOM_DRIVER_ERROR_INVALID_CALLBACK_INFORMATION (-3)/* Error that      */
                                                        /* denotes that the   */
                                                        /* specified Callback */
                                                        /* function pointer   */
                                                        /* is invalid.        */

#define VCOM_DRIVER_ERROR_INITIALIZING_DRIVER   (-4)    /* Error that denotes */
                                                        /* that an error      */
                                                        /* occurred during    */
                                                        /* Driver             */
                                                        /* Configuration.     */

#define VCOM_DRIVER_ERROR_INVALID_DRIVER_ID     (-5)    /* Error that denotes */
                                                        /* Driver ID supplied */
                                                        /* as function        */
                                                        /* argument is NOT    */
                                                        /* registered with    */
                                                        /* the DLL.           */
                                                        
#define VCOM_DRIVER_ERROR_INVALID_PARAMETER     (-6)    /* Error that denotes */
                                                        /* a parameter that   */
                                                        /* was supplied as a  */
                                                        /* function argument  */
                                                        /* is NOT valid.      */

#define VCOM_DRIVER_ERROR_WRITING_TO_DEVICE     (-7)    /* Error that denotes */
                                                        /* that there was an  */
                                                        /* error while trying */
                                                        /* to write to the    */
                                                        /* Virtual COM Port   */
                                                        /* Device.            */
                                                        
#define VCOM_DRIVER_ERROR_READING_FROM_DEVICE   (-8)    /* Error that denotes */
                                                        /* that there was an  */
                                                        /* error while trying */
                                                        /* to read from the   */
                                                        /* Virtual COM Port   */
                                                        /* Device.            */

#define VCOM_DRIVER_ERROR_UNKNOWN               (-9)    /* Error that is not  */
                                                        /* covered by any     */
                                                        /* other Error Code.  */

   /* The following enumerated type represents the Status of the Break  */
   /* Signal for a specified Virtual COM Port.                          */
typedef enum   
{
   vbsBreakCleared,
   vbsBreakReceived
} VCOM_Break_Status_t;   

   /* The following Constants represent the Bit Mask that specifies     */
   /* the value of an individual Modem/Port Control Signal.  If the     */
   /* specified Bit has a binary value of '1', then the Signal is       */
   /* considered to be set, else it is considered NOT set (clear).      */
   /* This Bit Mask is used with the VCOM_PortStatus() function.        */
#define VCOM_PORT_STATUS_CLEAR_VALUE                            0x00000000
#define VCOM_PORT_STATUS_RTS_CTS_BIT                            0x00000001
#define VCOM_PORT_STATUS_DTR_DSR_BIT                            0x00000002
#define VCOM_PORT_STATUS_RING_INDICATOR_BIT                     0x00000004
#define VCOM_PORT_STATUS_CARRIER_DETECT_BIT                     0x00000008

   /* The following Constants represent the Bit Mask that specifies     */
   /* the value of an individual Modem/Port Line Status Signal.  If the */
   /* specified Bit has a binary value of '1', then the Signal is       */
   /* considered to be set, else it is considered NOT set (clear).      */
   /* This Bit Mask is used with the VCOM_LineStatus() function.        */
#define VCOM_LINE_STATUS_NO_ERROR_VALUE                         0x00000000
#define VCOM_LINE_STATUS_OVERRUN_ERROR_BIT                      0x00000001
#define VCOM_LINE_STATUS_PARITY_ERROR_BIT                       0x00000002
#define VCOM_LINE_STATUS_FRAMING_ERROR_BIT                      0x00000004

   /* Virtual COM Port API Event Types.                                 */
typedef enum
{
   etVCOM_Break_Indication,
   etVCOM_Port_Status_Indication,
   etVCOM_Data_Indication,
   etVCOM_Line_Status_Indication
} VCOM_Event_Type_t;

typedef struct _tagVCOM_Break_Indication_Data_t
{
   unsigned int        VCOMPortID;
   VCOM_Break_Status_t BreakStatus;
} VCOM_Break_Indication_Data_t;

#define VCOM_BREAK_INDICATION_DATA_SIZE                 (sizeof(VCOM_Break_Indication_Data_t))

typedef struct _tagVCOM_Port_Status_Indication_Data_t
{
   unsigned int VCOMPortID;
   unsigned int VCOMPortStatusMask;
} VCOM_Port_Status_Indication_Data_t;

#define VCOM_PORT_STATUS_INDICATION_DATA_SIZE           (sizeof(VCOM_Port_Status_Indication_Data_t))

typedef struct _tagVCOM_Data_Indication_Data_t
{
   unsigned int VCOMPortID;
   unsigned int DataLength;
} VCOM_Data_Indication_Data_t;

#define VCOM_DATA_INDICATION_DATA_SIZE                  (sizeof(VCOM_Data_Indication_Data_t))

typedef struct _tagVCOM_Line_Status_Indication_Data_t
{
   unsigned int VCOMPortID;
   unsigned int VCOMLineStatusMask;
} VCOM_Line_Status_Indication_Data_t;

#define VCOM_LINE_STATUS_INDICATION_DATA_SIZE           (sizeof(VCOM_Line_Status_Indication_Data_t))

   /* The following structure represents the container structure for    */
   /* Holding all VCOM Event Data Data.                                 */
typedef struct _tagVCOM_Event_Data_t
{
   VCOM_Event_Type_t Event_Data_Type;
   union
   {
      VCOM_Break_Indication_Data_t       VCOM_Break_Indication_Data;
      VCOM_Port_Status_Indication_Data_t VCOM_Port_Status_Indication_Data;
      VCOM_Data_Indication_Data_t        VCOM_Data_Indication_Data;
      VCOM_Line_Status_Indication_Data_t VCOM_Line_Status_Indication_Data;
   } Event_Data;
} VCOM_Event_Data_t;

   /* The following declared type represents the Prototype Function for */
   /* a VCOM Driver Receive Event Callback.  This function will be      */
   /* called whenever an event occurs on the specified virtual COM Port */
   /* that was opened with the specified Driver ID.  This function      */
   /* passes to the caller the VCOM Driver ID, the Event Information    */
   /* that occurred and the VCOM Driver Callback Parameter that was     */
   /* specified when this Callback was installed.  The caller is free   */
   /* to use the contents of the VCOM Event ONLY in the context of      */
   /* this callback.  If the caller requires the Data for a longer      */
   /* period of time, then the callback function MUST copy the data     */
   /* into another Data Buffer.  This function is guaranteed NOT to be  */
   /* invoked more than once simultaneously for the specified installed */
   /* callback (i.e. this  function DOES NOT have be reentrant).  It    */
   /* Needs to be noted however, that if the same Callback function is  */
   /* installed for multiple Virtual COM Ports, then the function IS    */
   /* NOT guaranteed to NOT be called simultaneously.  The function is  */
   /* only guaranteed to be called serially for a single context in     */
   /* which the Callback has been installed.  This means that if the    */
   /* same Callback function is installed for two (or more) Virtual COM */
   /* Ports, then the function COULD be called simultaneously for       */
   /* both Events.  It should also be noted that this function is       */
   /* is called in the Thread Context of a Thread that the User does    */
   /* NOT own.  Therefore, processing in this function should be as     */
   /* efficient as possible (this argument holds anyway because another */
   /* Event will not be received while this function call is            */
   /* outstanding).                                                     */
   /* ** NOTE ** This function MUST NOT Block and wait for events that  */
   /*            can only be satisfied by Receiving VCOM Events.        */
   /*            A Deadlock WILL occur because NO Other Receive VCOM    */
   /*            Callbacks will be issued while this function is        */
   /*            currently outstanding.                                 */
typedef void (__stdcall *VCOM_DriverCallback_t)(unsigned int VCOMDriverID, VCOM_Event_Data_t *VCOMEventData, unsigned long CallbackParameter);

   /* The following function is responsible for Opening a Virtual COM   */
   /* Port Driver Driver on the specified COM Port.  The first          */
   /* parameter to this function specifies the COM Port Number of the   */
   /* Actual COM Port in the system.  The second and third parameters   */
   /* specify the VCOM Driver Callback function that is to be called    */
   /* when a VCOM Event Occurs.  All parameters to this function *MUST* */
   /* be specified.  If this function is successful, the caller will    */
   /* receive a non-zero, non-negative return value which serves as the */
   /* VCOMDriverID parameter for all other functions in the VCOM Driver.*/
   /* Since all VCOM functions require a valid VCOM Driver ID, this     */
   /* function must be called successfully before any other function    */
   /* can be called.  If this function fails then the return value is a */
   /* negative error code (see error codes above).                      */
__DLLMODEF__ int __stdcall VCOM_OpenDriver(unsigned int COMPortNumber, VCOM_DriverCallback_t VCOMCallback, unsigned long CallbackParameter);

#ifdef INCLUDE_VCOM_DRIVER_API_PROTOTYPES
   typedef int (__stdcall *PFN_VCOM_OpenDriver_t)(unsigned int COMPortNumber, VCOM_DriverCallback_t VCOMCallback, unsigned long CallbackParameter);
#endif

   /* The following function is responsible for Closing the Virtual COM */
   /* Port Driver that was opened via a successful call to the          */
   /* VCOM_OpenDriver() function.  The Input parameter to this function */
   /* MUST have been acquired by a successful call to VCOM_OpenDriver().*/
   /* Once this function completes, the Virtual COM Port Driver that was*/
   /* closed cannot be accessed again (sending/receiving data) by       */
   /* this module until the Driver is Re-Opened by calling the          */
   /* VCOM_OpenDriver() function.                                       */
__DLLMODEF__ void __stdcall VCOM_CloseDriver(unsigned int VCOMDriverID);

#ifdef INCLUDE_VCOM_DRIVER_API_PROTOTYPES
   typedef void (__stdcall *PFN_VCOM_CloseDriver_t)(unsigned int VCOMDriverID);
#endif

   /* The following function is responsible for Reading Serial Data from*/
   /* the specified Virtual COM Port Driver.  The input parameters to   */
   /* this function are the Virtual COM Port Driver ID, the Size of the */
   /* Data Buffer to be used for reading, and a pointer to the Data     */
   /* Buffer.  This function returns the number of data bytes that were */
   /* successfully read (zero if there were no Data Bytes ready to be   */
   /* read), or a negative return error code if unsuccessful.           */
__DLLMODEF__ int __stdcall VCOM_Read(unsigned int VCOMDriverID, unsigned int DataBufferSize, unsigned char *DataBuffer);

#ifdef INCLUDE_VCOM_DRIVER_API_PROTOTYPES
   typedef int (__stdcall *PFN_VCOM_Read_t)(unsigned int VCOMDriverID, unsigned int DataBufferSize, unsigned char *DataBuffer);
#endif
                                                                      
   /* The following function is responsible for Sending Serial Data to  */
   /* the specified Virtual COM Port.  The VCOMDriverID parameter that  */
   /* is passed to this function MUST have been established via a       */
   /* successful call to the VCOM_OpenDriver() function.  The remaining */
   /* parameters to this function are the Length of the Data to send    */
   /* and a pointer to the Data Buffer to Send.  This function returns  */
   /* the number of data bytes that were successfully sent, or a        */
   /* negative return error code if unsuccessful.                       */
__DLLMODEF__ int __stdcall VCOM_Write(unsigned int VCOMDriverID, unsigned int DataLength, unsigned char *DataBuffer);

#ifdef INCLUDE_VCOM_DRIVER_API_PROTOTYPES
   typedef int (__stdcall *PFN_VCOM_Write_t)(unsigned int VCOMDriverID, unsigned int DataLength, unsigned char *DataBuffer);
#endif

   /* The following function is provided to allow the programmer a      */
   /* means to notify the Virtual COM Port of a Break Condition.  This  */
   /* function accepts as input the Virtual COM Port Driver ID of the   */
   /* Virtual COM Port that is to receive the Break Condition.  This    */
   /* function returns zero if successful, or a negative return value   */
   /* if there was an error.                                            */
__DLLMODEF__ int __stdcall VCOM_SendBreak(unsigned int VCOMDriverID);

#ifdef INCLUDE_VCOM_DRIVER_API_PROTOTYPES
   typedef int (__stdcall *PFN_VCOM_SendBreak_t)(unsigned int VCOMDriverID);
#endif

   /* The following function is provided to allow the programmer a      */
   /* method to send the existing state of ALL Modem/Port Control       */
   /* Signals to the Virtual COM Port.  This function accepts as input  */
   /* the Virtual COM Port Driver ID and the Current State of all the   */
   /* Modem Control Signals.  This function returns zero if successful, */
   /* or a negative return value if there was an error.                 */
__DLLMODEF__ int __stdcall VCOM_PortStatus(unsigned int VCOMDriverID, unsigned int VCOMPortStatusMask);

#ifdef INCLUDE_VCOM_DRIVER_API_PROTOTYPES
   typedef int (__stdcall *PFN_VCOM_PortStatus_t)(unsigned int VCOMDriverID, unsigned int VCOMPortStatusMask);
#endif

   /* The following function is provided to allow the programmer a      */
   /* method to read the existing state of ALL Modem/Port Control       */
   /* Signals from the Virtual COM Port Driver.  This function accepts  */
   /* as input the Virtual COM Port Driver ID and a pointer to a        */
   /* variable that is receive the Current State of all the Modem       */
   /* Control Signals.  This function returns zero if successful, or a  */
   /* negative return value if there was an error.                      */
__DLLMODEF__ int __stdcall VCOM_ReadPortStatus(unsigned int VCOMDriverID, unsigned int *VCOMPortStatusMask);

#ifdef INCLUDE_VCOM_DRIVER_API_PROTOTYPES
   typedef int (__stdcall *PFN_VCOM_ReadPortStatus_t)(unsigned int VCOMDriverID, unsigned int *VCOMPortStatusMask);
#endif

   /* The following function is provided to allow the programmer a      */
   /* method to send the existing state of the Line Status to the       */
   /* Virtual COM Port.  This function accepts as input the Virtual COM */
   /* Port Driver ID and the Current Line Status State.  This function  */
   /* returns zero if successful, or a negative return value if there   */
   /* was an error.                                                     */
__DLLMODEF__ int __stdcall VCOM_LineStatus(unsigned int VCOMDriverID, unsigned int VCOMLineStatusMask);

#ifdef INCLUDE_VCOM_DRIVER_API_PROTOTYPES
   typedef int (__stdcall *PFN_VCOM_LineStatus_t)(unsigned int VCOMDriverID, unsigned int VCOMLineStatusMask);
#endif

#endif