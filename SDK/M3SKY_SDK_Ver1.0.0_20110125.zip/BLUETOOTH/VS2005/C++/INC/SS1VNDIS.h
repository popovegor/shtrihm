/*****< ss1vndis.h >***********************************************************/
/*      Copyright 2001, 2002, 2003, 2004 Stonestreet One, Inc.                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  SS1VNDIS - Stonestreet One Virtual NDIS Driver Layer Dynamic Link (DLL)   */
/*             Library for Windows CE (WINCE Only) Prototypes and Constants.  */
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   08/24/03  D. Lange       Initial creation.                               */
/******************************************************************************/
#ifndef __SS1VNDISH__
#define __SS1VNDISH__

   /* NOTE - Conditional Defines that *MUST* be defined if a DLL is to  */
   /*        Used.                                                      */
#ifdef __IMPORTDLL__
   #define __DLLMODEF__ __declspec(dllimport)
#else
   #ifdef __EXPORTDLL__
      #define __DLLMODEF__ __declspec(dllexport)
   #else
      #define __DLLMODEF__ __declspec(dllimport)
   #endif
#endif

   /* Error Return Codes.                                               */
#define VNDIS_DRIVER_ERROR_INVALID_INDEX_NUMBER (-1)    /* Error that denotes */
                                                        /* that the specified */
                                                        /* Virtual NDIS Index */
                                                        /* Number is invalid. */

#define VNDIS_DRIVER_ERROR_UNSUPPORTED_INDEX    (-2)    /* Error that denotes */
                                                        /* that the specified */
                                                        /* Virtual NDIS Index */
                                                        /* cannot be opened   */
                                                        /* because it cannot  */
                                                        /* be located in the  */
                                                        /* System.            */

#define VNDIS_DRIVER_ERROR_INVALID_CALLBACK_INFORMATION (-3) /* Error that    */
                                                        /* denotes that the   */
                                                        /* specified Callback */
                                                        /* function pointer   */
                                                        /* is invalid.        */

#define VNDIS_DRIVER_ERROR_INITIALIZING_DRIVER  (-4)    /* Error that denotes */
                                                        /* that an error      */
                                                        /* occurred during    */
                                                        /* Driver             */
                                                        /* Configuration.     */

#define VNDIS_DRIVER_ERROR_INVALID_DRIVER_ID    (-5)    /* Error that denotes */
                                                        /* Driver ID supplied */
                                                        /* as function        */
                                                        /* argument is NOT    */
                                                        /* registered with    */
                                                        /* the DLL.           */
                                                        
#define VNDIS_DRIVER_ERROR_INVALID_PARAMETER    (-6)    /* Error that denotes */
                                                        /* a parameter that   */
                                                        /* was supplied as a  */
                                                        /* function argument  */
                                                        /* is NOT valid.      */

#define VNDIS_DRIVER_ERROR_WRITING_TO_DEVICE    (-7)    /* Error that denotes */
                                                        /* that there was an  */
                                                        /* error while trying */
                                                        /* to write to the    */
                                                        /* Virtual NDIS       */
                                                        /* Device.            */
                                                        
#define VNDIS_DRIVER_ERROR_READING_FROM_DEVICE  (-8)    /* Error that denotes */
                                                        /* that there was an  */
                                                        /* error while trying */
                                                        /* to read from the   */
                                                        /* Virtual NDIS       */
                                                        /* Device.            */

#define VNDIS_DRIVER_ERROR_UNKNOWN              (-9)    /* Error that is not  */
                                                        /* covered by any     */
                                                        /* other Error Code.  */

   /* The following constant represents the largest possible payload    */
   /* size of an Ethernet packet (not counting the Ethernet Header).    */
#define VNDIS_MAXIMUM_ETHERNET_PAYLOAD_SIZE     1500

   /* Force ALL Structure Declarations to be Byte Packed (noting the    */
   /* current Structure Packing).                                       */
#pragma pack(push, __SS1VNDISH_PUSH__)
#pragma pack(1)

   /* The following type definition represents the container class for a*/
   /* Virtual NDIS Ethernet Address.                                    */
typedef struct _tagVNDIS_Ethernet_Address_t
{
   unsigned char Address0;
   unsigned char Address1;
   unsigned char Address2;
   unsigned char Address3;
   unsigned char Address4;
   unsigned char Address5;
} VNDIS_Ethernet_Address_t;

#define VNDIS_ETHERNET_ADDRESS_SIZE                     (sizeof(VNDIS_Ethernet_Address_t))

   /* The following MACRO is a utility MACRO that exists to assign the  */
   /* individual Byte values into the specified VNDIS_Ethernet_Address  */
   /* variable.  The Bytes are NOT in Little Endian Format and are      */
   /* assigned to the VNDIS_Ethernet_Address Variable in BIG Endian     */
   /* Format.  The first parameter is the VNDIS_Ethernet_Address        */
   /* Variable (of type VNDIS_Ethernet_Address_t) to assign, and the    */
   /* next six parameters are the Individual Ethernet Address Byte      */
   /* values to assign to the variable.                                 */
#define VNDIS_ASSIGN_ETHERNET_ADDRESS(_dest, _a, _b, _c, _d, _e, _f) \
{                                                                    \
   (_dest).Address0 = (_a);                                          \
   (_dest).Address1 = (_b);                                          \
   (_dest).Address2 = (_c);                                          \
   (_dest).Address3 = (_d);                                          \
   (_dest).Address4 = (_e);                                          \
   (_dest).Address5 = (_f);                                          \
}

   /* The following MACRO is a utility MACRO that exists to aid in the  */
   /* Comparison of two VNDIS_Ethernet_Address_t variables.  This MACRO */
   /* only returns whether the two VNDIS_Ethernet_Address_t variables   */
   /* are equal (MACRO returns BOOLEAN result) NOT less than/greater    */
   /* than.  The two parameters to this MACRO are both of type          */
   /* VNDIS_Ethernet_Address_t and represent the                        */
   /* VNDIS_Ethernet_Address_t variables to compare.                    */
#define VNDIS_COMPARE_ADDRESSES(_x, _y)                                                                                                           \
(                                                                                                                                              \
   ((_x).Address0 == (_y).Address0) && ((_x).Address1 == (_y).Address1) && ((_x).Address2  == (_y).Address2) && \
   ((_x).Address3 == (_y).Address3) && ((_x).Address4 == (_y).Address4) && ((_x).Address5  == (_y).Address5)    \
)

   /* Restore Structure Packing.                                        */
#pragma pack(pop, __SS1VNDISH_PUSH__)

   /* The following type definition represents the container class for  */
   /* all Ethernet Header Information (associated with each Ethernet    */
   /* Packet).                                                          */
typedef struct _tagVNDIS_Ethernet_Header_t
{
   VNDIS_Ethernet_Address_t DestinationAddress;
   VNDIS_Ethernet_Address_t SourceAddress;
   unsigned short           EthernetTypeField;
} VNDIS_Ethernet_Header_t;

#define VNDIS_ETHERNET_HEADER_SIZE                      (sizeof(VNDIS_Ethernet_Header_t))

   /* Virtual NDIS Driver API Event Types.                              */
typedef enum
{
   etVNDIS_Data_Indication
} VNDIS_Event_Type_t;

   /* The following structure represents the event data that required to*/
   /* signal the arrival of Data.                                       */
typedef struct _tagVNDIS_Data_Indication_Data_t
{
   unsigned int             VNDISDriverID;
   VNDIS_Ethernet_Header_t  EthernetHeader;
   unsigned int             PayloadLength;
   unsigned char           *PayloadBuffer;
} VNDIS_Data_Indication_Data_t;

#define VNDIS_DATA_INDICATION_DATA_SIZE                 (sizeof(VNDIS_Data_Indication_Data_t))

   /* The following structure represents the container structure for    */
   /* Holding all VNDIS Event Data Data.                                */
typedef struct _tagVNDIS_Event_Data_t
{
   VNDIS_Event_Type_t Event_Data_Type;
   union
   {
      VNDIS_Data_Indication_Data_t VNDIS_Data_Indication_Data;
   } Event_Data;
} VNDIS_Event_Data_t;

   /* The following declared type represents the Prototype Function for */
   /* a VNDIS Driver Receive Event Callback.  This function will be     */
   /* called whenever an event occurs on the specified virtual NDIS     */
   /* device that was opened with the specified Driver ID.  This        */
   /* function passes to the caller the VNDIS Driver ID, the Event      */
   /* Information that occurred and the VNDIS Driver Callback Parameter */
   /* that was specified when this Callback was installed.  The caller  */
   /* is free to use the contents of the VNDIS Event ONLY in the context*/
   /* of this callback.  If the caller requires the Data for a longer   */
   /* period of time, then the callback function MUST copy the data into*/
   /* another Data Buffer.  This function is guaranteed NOT to be       */
   /* invoked more than once simultaneously for the specified installed */
   /* callback (i.e. this function DOES NOT have be reentrant).  It     */
   /* needs to be noted however, that if the same Callback function is  */
   /* installed for multiple Virtual NDIS Ports, then the function IS   */
   /* NOT guaranteed to NOT be called simultaneously.  The function is  */
   /* only guaranteed to be called serially for a single context in     */
   /* which the Callback has been installed.  This means that if the    */
   /* same Callback function is installed for two (or more) Virtual NDIS*/
   /* Ports, then the function COULD be called simultaneously for both  */
   /* Events.  It should also be noted that this function is is called  */
   /* in the Thread Context of a Thread that the User does NOT own.     */
   /* Therefore, processing in this function should be as efficient as  */
   /* possible (this argument holds anyway because another Event will   */
   /* not be received while this function call is outstanding).         */
   /* ** NOTE ** This function MUST NOT Block and wait for events that  */
   /*            can only be satisfied by Receiving VNDIS Events.       */
   /*            A Deadlock WILL occur because NO Other Receive VNDIS   */
   /*            Callbacks will be issued while this function is        */
   /*            currently outstanding.                                 */
typedef void (__stdcall *VNDIS_Driver_Callback_t)(unsigned int VNDISDriverID, VNDIS_Event_Data_t *VNDISEventData, unsigned long CallbackParameter);

   /* The following function is responsible for changing the current    */
   /* Ethernet Address that is being used by the specified Virtual NDIS */
   /* Driver.  The first parameter to this function specifies the       */
   /* Virtual NDIS Driver Index of the Actual virtual NDIS Driver in the*/
   /* system.  The second parameter specifies the actual Ethernet       */
   /* Address to use for the specified Driver (based on the first       */
   /* parameter).  This function returns the following status           */
   /* information:                                                      */
   /*    - Zero (No change - already configured with specified address).*/
   /*    - Positive (Changed - previously configured with a different   */
   /*      address).                                                    */
   /*    - Negative return error code (error).                          */
__DLLMODEF__ int __stdcall VNDIS_Configure_Ethernet_Address(unsigned int VNDISIndex, VNDIS_Ethernet_Address_t EthernetAddress);

#ifdef INCLUDE_VNDIS_DRIVER_API_PROTOTYPES
   typedef int (__stdcall *PFN_VNDIS_Configure_Ethernet_Address_t)(unsigned int VNDISIndex, VNDIS_Ethernet_Address_t EthernetAddress);
#endif

   /* The following function is responsible for Opening a virtual NDIS  */
   /* Driver with the specified Index.  The first parameter to this     */
   /* function specifies the Virtual NDIS Driver Index of the Actual    */
   /* virtual NDIS Driver in the system.  The second and third          */
   /* parameters specify the VNDIS Driver Callback function that is to  */
   /* be called when a VNDIS Event Occurs.  All parameters to this      */
   /* function *MUST* be specified.  If this function is successful, the*/
   /* caller will receive a non-zero, non-negative return value which   */
   /* serves as the VNDISDriverID parameter for all other functions in  */
   /* the VNDIS Driver.  Since all VNDIS functions require a valid VNDIS*/
   /* Driver ID, this function must be called successfully before any   */
   /* other function can be called.  If this function fails then the    */
   /* return value is a negative error code (see error codes above).    */
   /* * NOTE * If this function call is successful, no Ethernet Packets */
   /*          can be sent or received, until the Ethernet Connected    */
   /*          State is set to connected.                               */
   /*          The VNDIS_Set_Ethernet_Connected_State() function is     */
   /*          used for this purpose.  In other words, the default      */
   /*          Ethernet Connected State is disconnected (i.e. no        */
   /*          Ethernet Packets can be sent/received).                  */
__DLLMODEF__ int __stdcall VNDIS_Open_Driver(unsigned int VNDISIndex, VNDIS_Driver_Callback_t VNDISCallback, unsigned long CallbackParameter);

#ifdef INCLUDE_VNDIS_DRIVER_API_PROTOTYPES
   typedef int (__stdcall *PFN_VNDIS_Open_Driver_t)(unsigned int VNDISIndex, VNDIS_Driver_Callback_t VNDISCallback, unsigned long CallbackParameter);
#endif

   /* The following function is responsible for Closing the Virtual NDIS*/
   /* Driver that was opened via a successful call to the               */
   /* VNDIS_Open_Driver() function.  The Input parameter to this        */
   /* function MUST have been acquired by a successful call to          */
   /* VNDIS_Open_Driver().  Once this function completes, the Virtual   */
   /* NDIS Driver that was closed cannot be accessed again              */
   /* (sending/receiving data) by this module until the Driver is       */
   /* Re-Opened by calling the VNDIS_Open_Driver() function.            */
__DLLMODEF__ void __stdcall VNDIS_Close_Driver(unsigned int VNDISDriverID);

#ifdef INCLUDE_VNDIS_DRIVER_API_PROTOTYPES
   typedef void (__stdcall *PFN_VNDIS_Close_Driver_t)(unsigned int VNDISDriverID);
#endif

   /* The following function is responsible for querying the current    */
   /* Ethernet Address that is being used by the specified Virtual NDIS */
   /* Driver.  The VNDISDriverID parameter that is passed to this       */
   /* function MUST have been established via a successful call to the  */
   /* VNDIS_Open_Driver() function.  The final parameter to this        */
   /* function is a pointer to a buffer that will hold the current      */
   /* Ethernet Address of the virtual NDIS Driver (if this function is  */
   /* successful).  This function returns zero if successful or a       */
   /* negative return error code if there was an error.  If this        */
   /* function is successful then the buffer pointed to by the          */
   /* EthernetAddress parameter will contain the currently opened       */
   /* Virtual NDIS Driver.  If this function is unsuccessful then the   */
   /* contents of the EthernetAddress parameter buffer will be          */
   /* undefined.                                                        */
__DLLMODEF__ int __stdcall VNDIS_Query_Ethernet_Address(unsigned int VNDISDriverID, VNDIS_Ethernet_Address_t *EthernetAddress);

#ifdef INCLUDE_VNDIS_DRIVER_API_PROTOTYPES
   typedef int (__stdcall *PFN_VNDIS_Query_Ethernet_Address_t)(unsigned int VNDISDriverID, VNDIS_Ethernet_Address_t *EthernetAddress);
#endif

   /* The following function is responsible for specifying the current  */
   /* Ethernet Connected State that is to be used by the specified      */
   /* Virtual NDIS Driver.  The VNDISDriverID parameter that is passed  */
   /* to this function MUST have been established via a successful call */
   /* to the VNDIS_Open_Driver() function.  The final parameter to this */
   /* function is a BOOLEAN parameter that specifies whether or not the */
   /* Ethernet Cable is connected (TRUE) or disconnected (FALSE).  This */
   /* function returns zero if successful or a negative return error    */
   /* code if there was an error.                                       */
   /* * NOTE * This function has to be called with the second parameter */
   /*          set to TRUE (connected) before ANY Ethernet Packets can  */
   /*          be sent or received.                                     */
   /* * NOTE * When the Ethernet Connected State is disconnected, no    */
   /*          Ethenet Packets can be sent or received.                 */
__DLLMODEF__ int __stdcall VNDIS_Set_Ethernet_Connected_State(unsigned int VNDISDriverID, BOOLEAN Connected);

#ifdef INCLUDE_VNDIS_DRIVER_API_PROTOTYPES
   typedef int (__stdcall *PFN_VNDIS_Set_Ethernet_Connected_State_t)(unsigned int VNDISDriverID, BOOLEAN Connected);
#endif

   /* The following function is responsible for sending an Ethernet     */
   /* Packet to the specified Virtual NDIS Driver.  The VNDISDriverID   */
   /* parameter that is passed to this function MUST have been          */
   /* established via a successful call to the VNDIS_Open_Driver()      */
   /* function.  The remaining parameters to this function are the      */
   /* Ethernet Packet Header to use for the packety, followed by the    */
   /* Length of the Data to send and a pointer to the Data Buffer to    */
   /* Send (Payload only).  This function returns zero if successful,   */
   /* or a negative return error code if unsuccessful.                  */
   /* * NOTE * If the Ethernet Connected State is disconnected, then    */
   /*          no Ethernet packets will be passed through the Virtual   */
   /*          NDIS Driver.  The Ethernet connected state is set via a  */
   /*          call to the VNDIS_Set_Ethernet_Connected_State()         */
   /*          function.                                                */
   /* * NOTE * The default state of the Ethernet Connected State is     */
   /*          disconnected.                                            */
__DLLMODEF__ int __stdcall VNDIS_Write_Ethernet_Packet(unsigned int VNDISDriverID, VNDIS_Ethernet_Header_t *EthernetHeader, unsigned int PayloadLength, unsigned char *PayloadBuffer);

#ifdef INCLUDE_VNDIS_DRIVER_API_PROTOTYPES
   typedef int (__stdcall *PFN_VNDIS_Write_Ethernet_Packet_t)(unsigned int VNDISDriverID, VNDIS_Ethernet_Header_t *EthernetHeader, unsigned int PayloadLength, unsigned char *PayloadBuffer);
#endif

#endif