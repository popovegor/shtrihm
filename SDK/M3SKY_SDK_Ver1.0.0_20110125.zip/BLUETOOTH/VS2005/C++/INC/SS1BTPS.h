/*****< ss1btps.h >************************************************************/
/*      Copyright 2000, 2001, 2002, 2003, 2004 Stonestreet One, Inc.          */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  SS1BTPS - Stonestreet One Bluetooth Protocol Stack Dynamic Link Library   */
/*            (DLL) for Windows CE (WINCE Only) Type Definitions, Prototypes, */
/*            and Constants.                                                  */
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   09/11/00  D. Lange       Initial creation.                               */
/******************************************************************************/
#ifndef __SS1BTPSH__
#define __SS1BTPSH__

#include "BSCAPI.h"             /* Bluetooth Stack Controller Types/Constants.*/
#include "HCIAPI.h"             /* Bluetooth Stack HCI API Types/Constants.   */
#include "L2CAPAPI.h"           /* Bluetooth L2CAP API Prototypes/Constants.  */
#include "SCOAPI.h"             /* Bluetooth Stack SCO API Types/Constants.   */
#include "SDPAPI.h"             /* Bluetooth Stack SDP API Types/Constants.   */
#include "GAPAPI.h"             /* Bluetooth Stack GAP API Types/Constants.   */
#include "SPPAPI.h"             /* Bluetooth SPP API Prototypes/Constants.    */
#include "RFCOMAPI.h"           /* Bluetooth RFCOMM API Prototypes/Constants. */
#include "GOEPAPI.h"            /* Bluetooth GOEP API Prototypes/Constants.   */
#include "OTPAPI.h"             /* Bluetooth OTP API Prototypes/Constants.    */

#endif
