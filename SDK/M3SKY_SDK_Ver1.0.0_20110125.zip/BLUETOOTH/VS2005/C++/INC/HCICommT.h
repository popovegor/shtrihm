/*****< hcicommt.h >***********************************************************/
/*      Copyright 2000, 2001, 2002, 2003, 2004 Stonestreet One, Inc.          */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  HCICommT - Serial HCI Driver Layer Types for Windows CE (WINCE Only).     */
/*                                                                            */
/*  Author:  Tim Thomas                                                       */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   07/25/00  T. Thomas      Initial creation.                               */
/******************************************************************************/
#ifndef __HCICOMMTH__
#define __HCICOMMTH__

   /* Force ALL Structure Declarations to be Byte Packed (noting the    */
   /* current Structure Packing).                                       */
#pragma pack(push, __HCICOMMTH_PUSH__)
#pragma pack(1)

   /* The following constants represent the Minimum, Maximum, and       */
   /* Values that are used with the Initialization Delay member of the  */
   /* HCI_COMMDriverInformation_t structure.  These Delays are specified*/
   /* in Milliseconds and represent the delay that is to be added       */
   /* between Port Initialization (Open) and the writing of any data to */
   /* the Port.  This functionality was added because it was found that */
   /* some PCMCIA/Compact Flash Cards required a delay between the      */
   /* time the Port was opened and the time when the Card was ready to  */
   /* accept data.  The default is NO Delay (0 Milliseconds).           */
#define HCI_COMM_INFORMATION_INITIALIZATION_DELAY_MINIMUM     0
#define HCI_COMM_INFORMATION_INITIALIZATION_DELAY_MAXIMUM  5000
#define HCI_COMM_INFORMATION_INITIALIZATION_DELAY_DEFAULT     0

   /* The following type declaration defines the HCI Serial Protocol    */
   /* that will be used as the physical HCI Transport Protocol on the   */
   /* actual COM Port that is opened.  This type declaration is used in */
   /* the HCI_COMMDriverInformation_t structure that is required when   */
   /* an HCI COMM Port is opened.                                       */
typedef enum
{
   cpUART,
   cpUART_RTS_CTS,
   cpBCSP,
   cpBCSP_Muzzled
} HCI_COMM_Protocol_t;

   /* Maximum length for a HCI COMM device name.                        */
#define HCI_COMM_DRIVER_NAME_MAX                              4

   /* Define bit values for Flags word HCI_COMMDriverInformation_t      */ 
#define HCI_COMM_FLAG_NO_POWER_UP_REOPEN  (0x00000001)   /* Do not reopen COM port on standby / resume */

   /* These constants (HCI_COMM_DRIVER_INFORMATION_LENGTH_Vn) should be */
   /* used for DriverInformationSize.  This acts as a weak structure    */
   /* version.                                                          */
#ifndef offsetof
#define offsetof(Structure, Field) ((int)(&((Structure *)0)->Field))
#endif

   /* This length identifies the version of HCI_COMMDriverInformation_t */
   /* that has neither InitializationDelay nor DriverName.              */
#define HCI_COMM_DRIVER_INFORMATION_LENGTH_V0 (offsetof(HCI_COMMDriverInformation_t, InitializationDelay))

   /* This length identifies the version of HCI_COMMDriverInformation   */
   /* that has InitializationDelay but not DriverName.                  */
#define HCI_COMM_DRIVER_INFORMATION_LENGTH_V1 (offsetof(HCI_COMMDriverInformation_t, InitializationBaudRate))

   /* This length identifies the version HCI_COMMDriverInformation_t    */
   /* that has both InitializationDelay and DriverName.                 */
#define HCI_COMM_DRIVER_INFORMATION_LENGTH_V2 (offsetof(HCI_COMMDriverInformation_t, Flags))

   /* This length identifies the version HCI_COMMDriverInformation_t    */
   /* that has both InitializationDelay and DriverName and Flags.       */
#define HCI_COMM_DRIVER_INFORMATION_LENGTH_V3 (sizeof(HCI_COMMDriverInformation_t))

   /* The following type declaration represents the structure of all    */
   /* Data that is needed to open an HCI COMM Port.                     */
typedef struct _tagHCI_COMMDriverInformation_t
{
   unsigned int           DriverInformationSize;/* Physical Size of this      */
                                                /* structure.                 */
   unsigned int           COMPortNumber;        /* Physical COM Port Number   */
                                                /* of the Windows COM Port to */
                                                /* Open.                      */
   unsigned int           BaudRate;             /* Baud Rate to Open COM Port.*/
   HCI_COMM_Protocol_t    Protocol;             /* HCI Protocol that will be  */
                                                /* used for communication over*/
                                                /* Opened COM Port.           */
   unsigned int           InitializationDelay;  /* Time (In Milliseconds) to  */                                     
                                                /* Delay after the Port is    */
                                                /* opened before any data is  */
                                                /* sent over the Port.  This  */
                                                /* member is present because  */
                                                /* some PCMCIA/Compact Flash  */
                                                /* Cards have been seen that  */
                                                /* require a delay because the*/
                                                /* card does not function for */
                                                /* some specified period of   */
                                                /* time.                      */
   unsigned int           InitializationBaudRate; /* Baud Rate to initially   */
                                                /* Open the Port and          */
                                                /* initialize the device.     */
                                                /* During initialization the  */
                                                /* Baud Rate will be changed  */
                                                /* to the actual Baud Rate    */
                                                /* specified as the BaudRate  */
                                                /* member of this structure.  */
   TCHAR                  DriverName[HCI_COMM_DRIVER_NAME_MAX]; /* The name of*/
                                                /* the driver prefix to be    */
                                                /* opened.  For example       */
                                                /* specifying "COM" for this  */
                                                /* value and 8 for the        */
                                                /* COMPortNumber would result */
                                                /* in the COM8: device being  */
                                                /* used as the HCI Driver     */
                                                /* Transport.                 */
   unsigned int          Flags;                 /* Bit Flags.                 */
                                                /* See HCI_COMM_FLAG...       */
} HCI_COMMDriverInformation_t;

   /* Restore Structure Packing.                                        */
#pragma pack(pop, __HCICOMMTH_PUSH__)

#endif
