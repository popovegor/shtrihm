/*****< intdvapi.h >***********************************************************/
/*      Copyright 2005 Stonestreet One, Inc.                                  */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  INTDVAPI - Stonestreet One Bluetooth Stack Bluetooth Device Initialization*/
/*             Utility Type Definitions, Constants, and Prototypes.           */
/*                                                                            */
/*  Author:  Rory Sledge                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname       Description of Modification                  */
/*   --------  -----------       ---------------------------------------------*/
/*   01/30/05  R. Sledge         Initial creation.                            */
/******************************************************************************/
#ifndef __INTDVAPIH__
#define __INTDVAPIH__

#include "SS1BTPS.h"            /* Bluetooth Stack API Prototypes/Constants.  */

   /* Error Return Codes.                                               */
#define INDV_ERROR_INVALID_PARAMETER                             (-1000)
#define INDV_ERROR_DEVICE_ERROR                                  (-1001)
#define INDV_ERROR_UNABLE_TO_FIND_RESOURCE                       (-1002)
#define INDV_ERROR_UNABLE_TO_LOAD_RESOURCE                       (-1003)
#define INDV_ERROR_UNABLE_TO_LOCK_RESOURCE                       (-1004)
#define INDV_ERROR_NO_COMMANDS                                   (-1005)
#define INDV_ERROR_INVALID_COMMAND_TYPE                          (-1006)
#define INDV_ERROR_UNKNOWN_ERROR                                 (-1007)
#define INDV_UNSUPPORTED_DEVICE_INFORMATION_STRUCTURE            (-1008)
#define INDV_UNABLE_TO_ASSIGN_SERIAL_TRANSPORT_REGISTRY_KEY      (-1009)
#define INDV_EXTERNAL_RADIO_INITIALIZATION_FAILED                (-1010)
#define INDV_UNABLE_TO_ASSIGN_SERIAL_GENERAL_REGISTRY_KEY        (-1011)
#define INDV_UNABLE_TO_LOCATE_SERIAL_GENERAL_REGISTRY_KEY        (-1012)
#define INDV_ERROR_AUDIO_UNAVAILABLE                             (-1013)
#define INDV_ERROR_UNKNOWN_AUDIO_ROLE                            (-1014)

   /* The following constants represent the possible command types that */
   /* are handled by the device initialization routine.                 */
#define INDV_INVALID_TYPE                                         (0x00)   
#define INDV_SEND_RAW_COMMAND_TYPE                                (0x01)

   /* Force the following Structure Declarations to be Byte Packed      */
   /* (noting the current Structure Packing).                           */
#pragma pack(push, __INTDVAPIH_PUSH__)
#pragma pack(1)

   /* The following structure contains all information required for a   */
   /* send raw command type to be processed by the device initialization*/
   /* routine.                                                          */
typedef struct _tagINDV_Send_Raw_Command_Information_t
{
   BOOLEAN          WaitForResponse;
   Byte_t           CommandOGF;
   NonAlignedWord_t CommandOCF;
   Byte_t           CommandLength;
   Byte_t           CommandBuffer[1];
} INDV_Send_Raw_Command_Information_t;

#define COMMAND_INFORMATION_SIZE(_x)                    (sizeof(INDV_Send_Raw_Command_Information_t)-sizeof(Byte_t)+(unsigned int)(_x))

   /* The following structure contains the generic container structure  */
   /* for all possible commands that may be processed by the device     */
   /* initialization routine.                                           */
typedef struct _tagINDV_Generic_Command_Information_t
{
   Byte_t CommandType;
   union
   {
      INDV_Send_Raw_Command_Information_t INDVSendRawCommandInformation;
   } CommandInformation;
} INDV_Generic_Command_Information_t;

   /* Restore Structure Packing.                                        */
#pragma pack(pop, __INTDVAPIH_PUSH__)

   /* The following type definition identifies the phase of             */
   /* initialization being requested by the INTDEV initialization DLL.  */
   /* The initialization DLL can either act on the initialization       */
   /* request or, if no behavior is required, ignore it.                */
typedef enum
{
   ipNoActionDefined,
   ipInitializeBeforeHCIOpen,
   ipInitializeAfterHCIOpen,
   ipInitializeBeforeHCIReset,
   ipInitializeAfterHCIReset,
   ipInitializeBeforeHCIClose,
   ipInitializeAfterHCIClose
} INDV_Initialization_Phase_t;

   /* The list of profile types to used for comparison against the      */
   /* possible profile types as used by INDV_Check_Profile_Allowed.     */
   /* This list includes a number of types which are defined by         */
   /* Microsoft using proprietary GUIDs that do not have a direct       */
   /* association with a real profile. If you make a change to this     */
   /* table, make certain to update the profile-check code.             */
typedef enum _tagINDV_ProfileType_t
{
   ptUndefined,
   ptDontCare,
   pt80211CLPP,                        /* PROPOSED                                                 */
   ptA2DP,                             /* Advanced Audio Distribution Profile                      */
   ptAttribute,                        /* PROPOSED                                                 */
   ptAutomation,                       /* PROPOSED                                                 */
   ptAVRCP,                            /* A/V Remote Control Profile                               */
   ptBECIInterface,                    /* PROPOSED                                                 */
   ptBIP,                              /* Basic Imaging Profile                                    */
   ptBPP,                              /* Basic Printing Profile                                   */
   ptCIP,                              /* Common ISDN Access Profile (Deprecated)                  */
   ptCTP,                              /* Cordless Telephony Profile                               */
   ptDI,                               /* Device ID Profile                                        */
   ptDUN,                              /* Dial-Up Networking Profile                               */
   ptESDP,                             /* Extended Service Discovery Profile (for UPnP)            */
   ptFAX,                              /* Fax Profile                                              */
   ptFTP,                              /* File Transfer Profile                                    */
   ptGNSS,                             /* PROPOSED                                                 */
   ptGAVDP,                            /* Generic A/V Distribution Profile                         */   
   ptHealthDevice,                     /* PROPOSED                                                 */
   ptHCRP,                             /* Hardcopy Cable Replacement Profile (Deprecated)          */
   ptHFP,                              /* Hands-Free Profile                                       */
   ptHSP,                              /* Headset Profile                                          */
   ptHID,                              /* Human Interface Device Profile                           */
   ptICP,                              /* Intercom Profile                                         */
   ptLAP,                              /* LAN Access Profile (Deprecated)                          */
   ptMessageAccess,                    /* PROPOSED                                                 */
   ptMultiChannelAdaptation,           /* PROPOSED                                                 */
   ptOPP,                              /* Object Push Profile                                      */
   ptPAN,                              /* Personal Area Network Profile                            */
   ptPBAP,                             /* Phone Book Access Profile                                */
   ptPortableNavigation,               /* PROPOSED                                                 */
   ptSAP,                              /* SIM Access Profile                                       */
   ptSDAP,                             /* Service Discovery Application Profile                    */
   ptSPP,                              /* Serial Port Profile                                      */
   ptSYNCH,                            /* Synchronization Profile                                  */
   ptTimeServiceClass,                 /* PROPOSED                                                 */
   ptUDI,                              /* PROPOSED                                                 */
   ptVDP,                              /* Video Distribution Profile                               */
   ptWAPB,                             /* Wireless Access Protocol Bearer Profile (Deprecated)     */

   ptActiveSync                        /* MS-Specific Extension classification for SPP.            */
} INDV_ProfileType_t;


   /* The list of profile roles to used for comparison against the      */
   /* possible profile types as used by INDV_Check_Profile_Allowed.     */
   /* Where a role is not specifically specified, the shorthand         */
   /* client/server may be used.                                        */
typedef enum _tagINDV_ProfileRole_t 
{
   prDontCare                    = 0,
   prUnspecifiedClient           = 1,
   prUnspecifiedServer           = 2,

   prA2DP_Source                 = 1,
   prA2DP_Sink                   = 2,

   prAVRCP_Target                = 1,
   prAVRCP_Controller            = 2,

   prBPP_Sender                  = 1,
   prBPP_Printer                 = 2,

   prBIP_Initiator               = 1,
   prBIP_Responder               = 2,

   prDUN_DataTerminal            = 1,
   prDUN_Gateway                 = 2,

   prFAX_DataTerminal            = 1,
   prFAX_Gateway                 = 2,

   prGAVD_Initiator              = 1,
   prGAVD_Acceptor               = 2,

   prHeadset                     = 1,
   prHeadsetAudioGateway         = 2,

   prHandsFree                   = 1,
   prHandsFreeAudioGateway       = 2,

   prHID_Device                  = 1,
   prHID_Server                  = 2,

   prPAN_U                       = 1,
   prPAN_NAP                     = 2,
   prPAN_GN                      = 3,

   prMAXIMUM_PROFILE_ROLE_VAL    = 4
} INDV_ProfileRole_t;

   /* This enumeration defines the mask of flags that indication any    */
   /* conditions that have occurred on the device (i.e. the Bluetooth   */
   /* chip) that require attention from the application/stack. The      */
   /* current value of the mask should be accessed through a call to    */
   /* INDV_Check_Device_Reset_Conditions. These conditions are          */
   /* generally polled by the power manager, so it is essential that it */
   /* be running in order for the mask to be correct.                   */
typedef enum
{
   drcmNo_Condition           = 0x0000,
   drcmDevice_Power_Reset     = 0x0001
} INDV_Device_Reset_Condition_Mask_t;

   /* The following enumerated type is used with the                    */
   /* INDV_Set_Bluetooth_Audio_Configuration() function.  These types   */
   /* dictate how the device will route audio received via the Bluetooth*/
   /* Device.                                                           */
typedef enum
{
   barNone                    = 0x0000, 
   barHeadset                 = 0x0001,
   barHandsFree               = 0x0001,
   barAudioGateway            = 0x0002
} INDV_Bluetooth_Audio_Route_t;

   /* The following type definition represents the structure of required*/
   /* information to perform initialization before HCI opens the device */
   /* providing HCI support. The InformationSize member must contain    */
   /* the size of this structure.                                       */
typedef struct _tagINDV_Before_HCI_Open_Information_t
{
   unsigned int            InformationSize;
   HCI_DriverInformation_t DriverInformation;
} INDV_Before_HCI_Open_Information_t;

   /* The following type definition represents the structure of required*/
   /* information to perform initialization after HCI opens the device  */
   /* providing HCI support. The InformationSize member must contain    */
   /* the size of this structure.                                       */
typedef struct _tagINDV_After_HCI_Open_Information_t
{
   unsigned int            InformationSize;
   HANDLE                  DeviceHandle;
   HCI_DriverInformation_t DriverInformation;
} INDV_After_HCI_Open_Information_t;

   /* The following type definition represents the structure of required*/
   /* information to perform initialization before an HCI_reset.        */
   /* The InformationSize member contains the size of this structure.   */
   /* The BluetoothStackID member contains Bluetooth Stack ID of the    */
   /* stack open on the device being initialized.                       */
typedef struct _tagINDV_Before_HCI_Reset_Device_Information_t
{
   unsigned int            InformationSize;
   unsigned int            BluetoothStackID;
} INDV_Before_HCI_Reset_Device_Information_t;

   /* The following type definition represents the structure of required*/
   /* information to perform initialization after an HCI_reset.         */
   /* The InformationSize member contains the size of this structure.   */
   /* The BluetoothStackID member contains Bluetooth Stack ID of the    */
   /* stack open on the device being initialized.                       */
typedef struct _tagINDV_After_HCI_Reset_Device_Information_t
{
   unsigned int            InformationSize;
   unsigned int            BluetoothStackID;
   unsigned int            HCIDriverID;
   HANDLE                  DeviceHandle;
   HCI_DriverInformation_t DriverInformation;
} INDV_After_HCI_Reset_Device_Information_t;

   /* The following type definition represents the structure of required*/
   /* information to perform deinitialization before HCI closes the     */
   /* device providing HCI support. The InformationSize member must     */
   /* contain the size of this structure. The BluetoothStackID member   */
   /* contains Bluetooth Stack ID of the stack open on the device being */
   /* initialized.                                                      */
typedef struct _tagINDV_Before_HCI_Close_Information_t
{
   unsigned int            InformationSize;
   unsigned int            BluetoothStackID;
} INDV_Before_HCI_Close_Information_t;


   /* The following type definition represents the structure of required*/
   /* information to perform deinitialization after HCI closes the      */
   /* device providing HCI support. The InformationSize member must     */
   /* contain the size of this structure. The BluetoothStackID member   */
   /* contains Bluetooth Stack ID of the stack open on the device being */
   /* initialized.                                                      */
typedef struct _tagINDV_After_HCI_Close_Information_t
{
   unsigned int            InformationSize;
} INDV_After_HCI_Close_Information_t;

   /* The following structure encapsulates a generic mechanism for      */
   /* initializing various Platform/Bluetooth Devices combinations.  The*/
   /* InitializationPhase member contains the phase of initialization   */
   /* that is being performed for the particular device type being      */
   /* initialized. The DeviceInformation union contains the specific    */
   /* Platform/Bluetooth Device information.                            */
typedef struct _tagINDV_Initialize_Device_Information_t
{
   INDV_Initialization_Phase_t   InitializationPhase;
   union
   {
      INDV_Before_HCI_Open_Information_t           INDV_BeforeHCIOpenInformation;
      INDV_After_HCI_Open_Information_t            INDV_AfterHCIOpenInformation;
      INDV_Before_HCI_Reset_Device_Information_t   INDV_BeforeHCIResetDeviceInformation;
      INDV_After_HCI_Reset_Device_Information_t    INDV_AfterHCIResetDeviceInformation;
      INDV_Before_HCI_Close_Information_t          INDV_BeforeHCICloseInformation;
      INDV_After_HCI_Close_Information_t           INDV_AfterHCICloseInformation;
   } DeviceInformation;
} INDV_Initialize_Device_Information_t;

   /* The following function is responsible for initializing the        */
   /* Platforms Bluetooth Device.  This includes but may not be limited */
   /* to downloading Patch Trap Code to ROM type devices.  The only     */
   /* parameter to this function is a pointer to a Initialize Device    */
   /* Information structure.  This function returns zero if successful  */
   /* or a negative return value if an error occurred.                  */
__DLLMODEF__ int BTPSAPI INDV_Initialize_Device(INDV_Initialize_Device_Information_t *INDV_Initialize_Device_Information);
                            
#ifdef INCLUDE_INTDEV_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_INDV_Initialize_Device_t)(INDV_Initialize_Device_Information_t *INDV_Initialize_Device_Information);
#endif

typedef enum
{
   udAfterOpen,
   udBeforeWrite,
   udAfterWrite,
   udAfterClose
} INDV_Update_Type_t;

   /* The following function is responsible for updating the            */
   /* Platforms Bluetooth Device.                                       */
__DLLMODEF__ int BTPSAPI INDV_Update_Device(HANDLE COMPortHandle, INDV_Update_Type_t UpdateType);
                            
#ifdef INCLUDE_INTDEV_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_INDV_Update_Device_t)(HANDLE COMPortHandle, INDV_Update_Type_t UpdateType);
#endif
      
   /* This function checks the current condition of the Bluetooth       */
   /* device on which a stack instance is running and returns any       */
   /* conditional flags which indicate an action must be taken by the   */
   /* application (or stack) to resolve a condition caused by a reset,  */
   /* reconfigure or other change of state. The first parameter is the  */
   /* handle to the Bluetooth stack running on the device, the second   */
   /* is a pointer to a 32-bit field to accept the mask of the flags    */
   /* signalled on the device. These conditions are generally polled    */
   /* by the power manager driver, so it is essential that it be        */
   /* running in order for the mask to be correct. The return value is  */
   /* zero if the mask could be successfully read or a negative error   */
   /* code.                                                             */
__DLLMODEF__ int BTPSAPI INDV_Check_Device_Reset_Conditions(unsigned int BluetoothStackID, unsigned int *ResetConditionMask);

#ifdef INCLUDE_INTDEV_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_INDV_Check_Device_Reset_Conditions_t)(unsigned int BluetoothStackID, unsigned int *ResetConditionMask);
#endif

   /* The following function is provided to allow a means to get the    */
   /* configuration of how audio received via the Bluetooth Device is   */
   /* handled.  The first parameter to this function is a pointer to an */
   /* enumerated type that will contain the current audio routing state.*/
   /* The final parameter to this function may be set to NULL and is    */
   /* reserved for future use.  This function return zero if successful */
   /* or a negative return value if an error occurred.                  */
__DLLMODEF__ int BTPSAPI INDV_Get_Bluetooth_Audio_Configuration(INDV_Bluetooth_Audio_Route_t *Bluetooth_Audio_Route, void *Reserved);

#ifdef INCLUDE_INTDEV_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_INDV_Get_Bluetooth_Audio_Configuration_t)(INDV_Bluetooth_Audio_Route_t *Bluetooth_Audio_Route, void *Reserved);
#endif

   /* The following function is provided to allow a means to set the    */
   /* configuration of how audio received via the Bluetooth Device is   */
   /* handled.  The first parameter to this function is an enumerated   */
   /* type dictating how the audio is to be routed from the Bluetooth   */
   /* Device.  The final parameter to this function may be set to NULL  */
   /* and is reserved for future use.  This function returns zero if    */
   /* successful or a negative return value if an error occurred.       */
__DLLMODEF__ int BTPSAPI INDV_Set_Bluetooth_Audio_Configuration(INDV_Bluetooth_Audio_Route_t Bluetooth_Audio_Route, void *Reserved);

#ifdef INCLUDE_INTDEV_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_INDV_Set_Bluetooth_Audio_Configuration_t)(INDV_Bluetooth_Audio_Route_t Bluetooth_Audio_Route, void *Reserved);
#endif

   /* This function is called to notify INTDEV that a power up event    */
   /* has been detected (HCI_DRIVER_EVENT_DEVICE_POWER_UP).             */
__DLLMODEF__ int BTPSAPI INDV_Power_Up_Notification(unsigned int BluetoothStackID);

#ifdef INCLUDE_INTDEV_API_PROTOTYPES
   typedef int (BTPSAPI *PFN_INDV_Power_Up_Notification_t)(unsigned int BluetoothStackID);
#endif


   /* This function is called prior to the execution of any             */
   /* initialization or connection code in specific profiles to         */
   /* determine if the profile is allowed to execute on the platform.   */
   /* By default the profile initialization should return true if there */
   /* is no reason to restrict the initialization of the profile,       */
   /* otherwise it should return an error code.                         */
   /* By default, profiles which cannot find this function in their     */
   /* respective IDV should fail to initialize.                         */
__DLLMODEF__ int BTPSAPI INDV_Check_Profile_Allowed(INDV_ProfileType_t ProfileType, INDV_ProfileRole_t ServerProfileRole, BOOL *Allowed);

#ifdef INCLUDE_INTDEV_API_PROTOTYPES
typedef int (BTPSAPI *PFN_INDV_Check_Profile_Allowed_t)(INDV_ProfileType_t ProfileType, INDV_ProfileRole_t ServerProfileRole, BOOL *Allowed);
#endif


   /* This function is called from within BSC_Initialize to determine   */
   /* whether the stack is allowed to run on the platform. If the       */
   /* platform has disabled the stack, Allowed is assigned false.       */
__DLLMODEF__ int BTPSAPI INDV_Check_Bluetooth_Allowed(BOOL *Allowed);

#ifdef INCLUDE_INTDEV_API_PROTOTYPES
typedef int (BTPSAPI *PFN_INDV_Check_Bluetooth_Allowed_t)(BOOL *Allowed);
#endif

__DLLMODEF__ BOOL INDV_GetConfig(unsigned char *Buffer, unsigned int BufferSize, unsigned int *ConfigSize);

#ifdef INCLUDE_INTDEV_API_PROTOTYPES
typedef int (BTPSAPI *PFN_INDV_GetConfig_t)(unsigned char *Buffer, unsigned int BufferSize, unsigned int *ConfigSize);
#endif


   /* This function is called to check if we should use the temp folder */
   /* as an intermediate folder for FTP transactions.                   */
__DLLMODEF__ int BTPSAPI INDV_UseTempFolderForFTP(TCHAR *value);

#ifdef INCLUDE_INTDEV_API_PROTOTYPES
typedef int (BTPSAPI *PFN_INDV_UseTempFolderForFTP_t)(TCHAR *value);
#endif

typedef enum
{
   spDisableSniffDuringSCO,
   spMaxStackParameters
} INDV_Stack_Parameter_t;

   /* This function is called to check the value of a specific Stack    */
   /* Parameter.                                                        */
__DLLMODEF__ int BTPSAPI INDV_Get_Stack_Parameter(INDV_Stack_Parameter_t StackParameter, DWord_t *Value);

#ifdef INCLUDE_INTDEV_API_PROTOTYPES
typedef int (BTPSAPI *PFN_INDV_Get_Stack_Parameter_t)(INDV_Stack_Parameter_t StackParameter, DWord_t *Value);
#endif

    /* ====== RadioSupport definitions ======
     * Definitions for RadioSupport functions:
     * INDV_GetCustBTAddr - allows specifying a custom (or customer suppied)
     * BD_ADDR.
     * INDV_GetBluetoothRadioSupport - Report if Bluetooth radio is installed
     * and return radio type (INDV_Bluetooth_Radio_Type_t) if available.
     */

__DLLMODEF__ void BTPSAPI INDV_GetCustBTAddr(BYTE *buf);

#ifdef INCLUDE_INTDEV_API_PROTOTYPES
typedef void (BTPSAPI *PFN_INDV_GetCustBTAddr_t)(BYTE *buf);
#endif

__DLLMODEF__ int BTPSAPI INDV_GetBluetoothRadioSupport(DWORD *pRadioType);

#ifdef INCLUDE_INTDEV_API_PROTOTYPES
typedef int (BTPSAPI *PFN_INDV_GetBluetoothRadioSupport_t)(DWORD *pRadioType);
#endif
   /* ====== End RadioSupport definitions ======
    */

   
__DLLMODEF__ int BTPSAPI INDV_AUDIO_Open(void);

#ifdef INCLUDE_INTDEV_API_PROTOTYPES
typedef int (BTPSAPI *PFN_INDV_AUDIO_Close_t)(void);
#endif

__DLLMODEF__ int BTPSAPI INDV_AUDIO_Close(void);

#ifdef INCLUDE_INTDEV_API_PROTOTYPES
typedef int (BTPSAPI *PFN_INDV_AUDIO_Close_t)(void);
#endif

__DLLMODEF__ int BTPSAPI INDV_AUDIO_GetBluetoothAudioRole(DWORD *pdwRole);

#ifdef INCLUDE_INTDEV_API_PROTOTYPES
typedef int (BTPSAPI *PFN_INDV_AUDIO_GetBluetoothAudioRole_t)(DWORD *pdwRole);
#endif

__DLLMODEF__ int BTPSAPI INDV_AUDIO_SetBluetoothAudioRole(const DWORD dwRole);

#ifdef INCLUDE_INTDEV_API_PROTOTYPES
typedef int (BTPSAPI *PFN_INDV_AUDIO_SetBluetoothAudioRole_t)(const DWORD dwRole);
#endif

__DLLMODEF__ int BTPSAPI INDV_AUDIO_GetStatus(DWORD *pdwRole);

#ifdef INCLUDE_INTDEV_API_PROTOTYPES
typedef int (BTPSAPI *PFN_INDV_AUDIO_GetStatus_t)(DWORD *pdwRole);
#endif

__DLLMODEF__ int BTPSAPI INDV_AUDIO_NotifyEventRegister(const HANDLE hEventObject, const DWORD dwEventMask);

#ifdef INCLUDE_INTDEV_API_PROTOTYPES
typedef int (BTPSAPI *PFN_INDV_AUDIO_NotifyEventRegister_t)(const HANDLE hEventObject, const DWORD dwEventMask);
#endif

__DLLMODEF__ int BTPSAPI INDV_AUDIO_NotifyEventDeRegister(const HANDLE hEventObj);

#ifdef INCLUDE_INTDEV_API_PROTOTYPES
typedef int (BTPSAPI *PFN_INDV_AUDIO_NotifyEventDeRegister_t)(const HANDLE hEventObj);
#endif

#endif
