/*****< btapityp.h >***********************************************************/
/*      Copyright 2000 - 2008 Stonestreet One, Inc.                           */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  BTAPITYP - Stonestreet One Bluetooth Protocol Stack API Type Definitions. */
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   12/11/00  D. Lange       Initial creation.                               */
/******************************************************************************/
#ifndef __BTPSAPITH__
#define __BTPSAPITH__

/* This define (SS1CONST) is used to conditionally support the use */
/* of the const modifier.  If desired, define this as const here.  */
#define SS1CONST     const

   /* NOTE - Conditional Defines that *MUST* be defined if a DLL is to  */
   /*        Used.                                                      */
#ifdef __IMPORTDLL__
   #define __DLLMODEF__ __declspec(dllimport)
   #define SS1_DECLARE __declspec(dllimport)   
#else
   #ifdef __EXPORTDLL__
      #define __DLLMODEF__ __declspec(dllexport)
      #define SS1_DECLARE __declspec(dllexport)      
   #else
      #define __DLLMODEF__ __declspec(dllimport)
      #define SS1_DECLARE __declspec(dllimport)      
   #endif
#endif

   /* The following definition defines the API Calling Convention for   */
   /* ALL the API Functions.                                            */
#ifndef BTPSAPI
   #define BTPSAPI __stdcall
#endif

#endif
