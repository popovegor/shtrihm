// BTE_sample_1Dlg.h : header file
//

#pragma once
#include "BTExpAPIStructs.h"  /* Include for BTExplorer API constants/structs */

// CBTE_sample_1Dlg dialog
class CBTE_sample_1Dlg : public CDialog
{
public:
	BTP_Connection_Info_Ex_t  connectionInfo;

	

	CList<BTP_Device_Info_t, BTP_Device_Info_t&>	m_Deviceitem;
	CList<BTP_Connection_Info_t, BTP_Connection_Info_t&>	m_Connectitem;


	int	  m_listtype;
// Construction
public:
	CBTE_sample_1Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_BTE_SAMPLE_1_DIALOG };


	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
#if defined(_DEVICE_RESOLUTION_AWARE) && !defined(WIN32_PLATFORM_WFSP)
	afx_msg void OnSize(UINT /*nType*/, int /*cx*/, int /*cy*/);
#endif
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonInit();
	afx_msg void OnBnClickedButtonClose();
	afx_msg void OnBnClickedButtonConnect();
	afx_msg void OnBnClickedButtonDisconnect();
	afx_msg void OnBnClickedButtonDeviceFind();
	afx_msg void OnBnClickedButtonServiceFind();
	CListCtrl m_ctrllist;
	afx_msg void OnNMClickList1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedButtonLocalinfo();

	afx_msg void OnBnClickedButtonConnectionFind();
	afx_msg void OnBnClickedButton3ConnectionCreate();
	afx_msg void OnBnClickedButtonConnectionDelete();
};
