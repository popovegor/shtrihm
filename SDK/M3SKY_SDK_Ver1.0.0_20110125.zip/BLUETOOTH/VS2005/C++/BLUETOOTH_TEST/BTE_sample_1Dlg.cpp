// BTE_sample_1Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "BTE_sample_1.h"
#include "BTE_sample_1Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CBTE_sample_1Dlg dialog

#include "CustomerDLL.h"      /* include for BTExplorer API functions protos  */



static BTPInitAPI_t                   BTPInitAPI;
static BTPCloseAPI_t                  BTPCloseAPI;
static BTPFindLocalDevice_t           BTPFindLocalDevice;             
static BTPFindFirstDevice_t           BTPFindFirstDevice;
static BTPFindFirstDeviceEx_t         BTPFindFirstDeviceEx;
static BTPFindNextDevice_t            BTPFindNextDevice;
static BTPFindDeviceClose_t           BTPFindDeviceClose;
static BTPFindFirstService_t          BTPFindFirstService;
static BTPFindFirstServiceEx_t        BTPFindFirstServiceEx;
static BTPFindNextService_t           BTPFindNextService;
static BTPFindNextServiceEx_t         BTPFindNextServiceEx;
static BTPFindServiceClose_t          BTPFindServiceClose;
static BTPFindFirstConnection_t       BTPFindFirstConnection;
static BTPFindNextConnection_t        BTPFindNextConnection;
static BTPFindConnectionClose_t       BTPFindConnectionClose;
static BTPCreateConnection_t          BTPCreateConnection;
static BTPCreateConnectionEx_t        BTPCreateConnectionEx;
static BTPDeleteConnection_t          BTPDeleteConnection;
static BTPConnect_t                   BTPConnect;
static BTPDisconnect_t                BTPDisconnect;
static BTPSetAuthenticationCallback_t BTPSetAuthenticationCallback;
static BTPSetIncomingPIN_t            BTPSetIncomingPIN;
static BTPSetOutgoingPIN_t            BTPSetOutgoingPIN;

static HINSTANCE hModule;


static bool GetProcAddresses(HMODULE hModule);
static FARPROC GetProcAddressWithCheck(HMODULE hModule, LPCWSTR lpProcName);
/******************************************************************************/
/**  This is a little helper function to provide diagnostics on getting      **/
/**  procedure addresses from a dynamic library (DLL)                        **/
/******************************************************************************/

static FARPROC GetProcAddressWithCheck(HMODULE hModule, LPCWSTR lpProcName)
{
   FARPROC proc = GetProcAddress(hModule, lpProcName);

   if (NULL == proc)
      fprintf(stderr, "%s - ERROR (line %d): Unable to get procedure address: %S\n", __FUNCTION__, __LINE__, lpProcName);

   return proc;
}

/******************************************************************************/
/**  This loads the entire BTExplorer API from the passed DLL handle and     **/
/**  returns true if all of the functions loaded successfully.               **/
/******************************************************************************/
static bool GetProcAddresses(HMODULE hModule)
{
   BTPInitAPI                   = (BTPInitAPI_t)                   GetProcAddressWithCheck(hModule, _T("BTPInitAPI"));
   BTPCloseAPI                  = (BTPCloseAPI_t)                  GetProcAddressWithCheck(hModule, _T("BTPCloseAPI"));

   BTPFindLocalDevice           = (BTPFindLocalDevice_t)           GetProcAddressWithCheck(hModule, _T("BTPFindLocalDevice"));

   BTPFindFirstDeviceEx         = (BTPFindFirstDeviceEx_t)         GetProcAddressWithCheck(hModule, _T("BTPFindFirstDeviceEx"));
   BTPFindFirstDevice           = (BTPFindFirstDevice_t)           GetProcAddressWithCheck(hModule, _T("BTPFindFirstDevice"));
   BTPFindNextDevice            = (BTPFindNextDevice_t)            GetProcAddressWithCheck(hModule, _T("BTPFindNextDevice"));
   BTPFindDeviceClose           = (BTPFindDeviceClose_t)           GetProcAddressWithCheck(hModule, _T("BTPFindDeviceClose"));
   
   BTPFindFirstService          = (BTPFindFirstService_t)          GetProcAddressWithCheck(hModule, _T("BTPFindFirstService"));
   BTPFindFirstServiceEx        = (BTPFindFirstServiceEx_t)        GetProcAddressWithCheck(hModule, _T("BTPFindFirstServiceEx"));
   BTPFindNextService           = (BTPFindNextService_t)           GetProcAddressWithCheck(hModule, _T("BTPFindNextService"));
   BTPFindNextServiceEx         = (BTPFindNextServiceEx_t)         GetProcAddressWithCheck(hModule, _T("BTPFindNextServiceEx"));
   BTPFindServiceClose          = (BTPFindServiceClose_t)          GetProcAddressWithCheck(hModule, _T("BTPFindServiceClose"));
   
   BTPFindFirstConnection       = (BTPFindFirstConnection_t)       GetProcAddressWithCheck(hModule, _T("BTPFindFirstConnection"));
   BTPFindNextConnection        = (BTPFindNextConnection_t)        GetProcAddressWithCheck(hModule, _T("BTPFindNextConnection"));
   BTPFindConnectionClose       = (BTPFindConnectionClose_t)       GetProcAddressWithCheck(hModule, _T("BTPFindConnectionClose"));
   
   BTPCreateConnection          = (BTPCreateConnection_t)          GetProcAddressWithCheck(hModule, _T("BTPCreateConnection"));
   BTPCreateConnectionEx        = (BTPCreateConnectionEx_t)        GetProcAddressWithCheck(hModule, _T("BTPCreateConnectionEx"));
   BTPDeleteConnection          = (BTPDeleteConnection_t)          GetProcAddressWithCheck(hModule, _T("BTPDeleteConnection"));
   
   BTPConnect                   = (BTPConnect_t)                   GetProcAddressWithCheck(hModule, _T("BTPConnect"));
   BTPDisconnect                = (BTPDisconnect_t)                GetProcAddressWithCheck(hModule, _T("BTPDisconnect"));

   BTPSetIncomingPIN            = (BTPSetIncomingPIN_t)            GetProcAddressWithCheck(hModule, _T("BTPSetIncomingPIN"));
   BTPSetOutgoingPIN            = (BTPSetOutgoingPIN_t)            GetProcAddressWithCheck(hModule, _T("BTPSetOutgoingPIN"));

   BTPSetAuthenticationCallback = (BTPSetAuthenticationCallback_t) GetProcAddressWithCheck(hModule, _T("BTPSetAuthenticationCallback"));

   return (BTPInitAPI && BTPCloseAPI && 
           BTPFindLocalDevice &&
           BTPFindFirstDevice && BTPFindNextDevice && BTPFindDeviceClose && 
           BTPFindFirstService && BTPFindFirstServiceEx && BTPFindNextService && BTPFindNextService && BTPFindServiceClose && 
           BTPFindFirstConnection && BTPFindNextConnection && BTPFindConnectionClose && 
           BTPCreateConnection && BTPCreateConnection && BTPDeleteConnection && 
           BTPConnect && BTPDisconnect && 
           BTPSetIncomingPIN && BTPSetOutgoingPIN &&
           BTPSetAuthenticationCallback);
}
CBTE_sample_1Dlg::CBTE_sample_1Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBTE_sample_1Dlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CBTE_sample_1Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_ctrllist);
}

BEGIN_MESSAGE_MAP(CBTE_sample_1Dlg, CDialog)
#if defined(_DEVICE_RESOLUTION_AWARE) && !defined(WIN32_PLATFORM_WFSP)
	ON_WM_SIZE()
#endif
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_INIT, &CBTE_sample_1Dlg::OnBnClickedButtonInit)
	ON_BN_CLICKED(IDC_BUTTON_CLOSE, &CBTE_sample_1Dlg::OnBnClickedButtonClose)
	ON_BN_CLICKED(IDC_BUTTON_CONNECT, &CBTE_sample_1Dlg::OnBnClickedButtonConnect)
	ON_BN_CLICKED(IDC_BUTTON_DISCONNECT, &CBTE_sample_1Dlg::OnBnClickedButtonDisconnect)
	ON_BN_CLICKED(IDC_BUTTON_DEVICE_FIND, &CBTE_sample_1Dlg::OnBnClickedButtonDeviceFind)
	ON_BN_CLICKED(IDC_BUTTON_SERVICE_FIND, &CBTE_sample_1Dlg::OnBnClickedButtonServiceFind)

ON_NOTIFY(NM_CLICK, IDC_LIST1, &CBTE_sample_1Dlg::OnNMClickList1)
ON_BN_CLICKED(IDC_BUTTON_LOCALINFO, &CBTE_sample_1Dlg::OnBnClickedButtonLocalinfo)

ON_BN_CLICKED(IDC_BUTTON_CONNECTION_FIND, &CBTE_sample_1Dlg::OnBnClickedButtonConnectionFind)
ON_BN_CLICKED(IDC_BUTTON3_CONNECTION_CREATE, &CBTE_sample_1Dlg::OnBnClickedButton3ConnectionCreate)
ON_BN_CLICKED(IDC_BUTTON_CONNECTION_DELETE, &CBTE_sample_1Dlg::OnBnClickedButtonConnectionDelete)
END_MESSAGE_MAP()


// CBTE_sample_1Dlg message handlers

BOOL CBTE_sample_1Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	ListView_SetExtendedListViewStyle(m_ctrllist.GetSafeHwnd(),LVS_EX_FULLROWSELECT);
	m_ctrllist.InsertColumn(0,L"Data",LVCFMT_LEFT,210);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

#if defined(_DEVICE_RESOLUTION_AWARE) && !defined(WIN32_PLATFORM_WFSP)
void CBTE_sample_1Dlg::OnSize(UINT /*nType*/, int /*cx*/, int /*cy*/)
{
	if (AfxIsDRAEnabled())
	{
		DRA::RelayoutDialog(
			AfxGetResourceHandle(), 
			this->m_hWnd, 
			DRA::GetDisplayMode() != DRA::Portrait ? 
			MAKEINTRESOURCE(IDD_BTE_SAMPLE_1_DIALOG_WIDE) : 
			MAKEINTRESOURCE(IDD_BTE_SAMPLE_1_DIALOG));
	}
}
#endif


void CBTE_sample_1Dlg::OnBnClickedButtonInit()
{
	hModule = LoadLibrary(_T("CustomerDLL.dll"));
	if (hModule)
	{
		/* Load the procedure addresses                                      */
		if (GetProcAddresses(hModule))
		{			
			if(BTPInitAPI())
			{
				SetWindowText(L"init_success");
			}
			else
				SetWindowText(L"init_fail");

				
		}
		else
		{
			SetWindowText(L"load_fail");
			FreeLibrary(hModule);			
		}
	}
	else
	SetWindowText(L"load_fail");
	
}

void CBTE_sample_1Dlg::OnBnClickedButtonClose()
{
	m_Deviceitem.RemoveAll();
	BTPCloseAPI();
	Sleep(2000);	
	if(FreeLibrary(hModule))
		SetWindowText(L"dll_free success");
	else
		SetWindowText(L"dll_free fail");
}

void CBTE_sample_1Dlg::OnBnClickedButtonConnect()
{
	HRESULT result;

	result=BTPConnect(connectionInfo.ConnectionID);
	if(result==BTP_ERROR_SUCCESS) 
	SetWindowText(L"Connect");
	else if(result ==BTP_ERROR_INVALID_PARAMETER)
	AfxMessageBox(L"ERROR_INVALID_ PARAMETER");
	else if(result ==BTP_ERROR)
	AfxMessageBox(L"error");
}

void CBTE_sample_1Dlg::OnBnClickedButtonDisconnect()
{
	HRESULT result;

	result = BTPDisconnect(connectionInfo.ConnectionID);
	if(result==BTP_ERROR_SUCCESS) 
	SetWindowText(L"Disconnect");
	else if(result ==BTP_ERROR_INVALID_PARAMETER)
	AfxMessageBox(L"ERROR_INVALID_ PARAMETER");
	else if(result ==BTP_ERROR)
	AfxMessageBox(L"error");
}

void CBTE_sample_1Dlg::OnBnClickedButtonDeviceFind()
{
	m_listtype = 1;				//list type
	m_ctrllist.DeleteAllItems();
	m_Deviceitem.RemoveAll();
	memset(&connectionInfo, 0, sizeof(connectionInfo));
   connectionInfo.Size = sizeof(BTP_Connection_Info_Ex_t);
   connectionInfo.ProfileType = BTP_PROFILE_SPP;

   CString str,stradd,strname;

   HRESULT result;
   BTP_Device_Find    deviceFind;
   BTP_Device_Info_t  deviceInfo;
   BTP_Device_Query_Ex_t deviceQuery;

   memset(&deviceQuery, 0, sizeof(deviceQuery));
   deviceQuery.Size = sizeof(BTP_Device_Query_Ex_t);

   /* Looking for all devices either discovered or remembered              */
   deviceQuery.DeviceAttributes = BTP_DEVICE_ALL;
   deviceQuery.DeviceType = (connectionInfo.ProfileType == BTP_PROFILE_SPP ? bdAll : bdHID);

   /* Tells the API to perform a ten second GAP inquiry, using zero (0)    */
   /* here will just return previously discovered devices.                 */
   deviceQuery.InquiryTimeout = 10;

   BeginWaitCursor();
  
   result = BTPFindFirstDeviceEx(&deviceFind, &deviceInfo, &deviceQuery);
	if (BTP_ERROR_SUCCESS == result)
   {
	   EndWaitCursor();
      do
      {
        BTP_Device_Info_t  deviceInfo_temp;
          memcpy(&deviceInfo_temp,&deviceInfo,sizeof(BTP_Device_Info_t));

		  m_Deviceitem.AddTail(deviceInfo_temp);
		
         result = BTPFindNextDevice(deviceFind, &deviceInfo);
      } while (BTP_ERROR_SUCCESS == result);      
       
	}
      BTPFindDeviceClose(deviceFind);
		
	 


	  int lm_count = m_Deviceitem.GetCount();
	  int i = 0;

	  for(i = lm_count-1;i>=0;i--)
	  {


		  deviceInfo =	m_Deviceitem.GetAt(m_Deviceitem.FindIndex(i));

		  stradd.Format(L"[%02X:%02X:%02X:%02X:%02X:%02X]Device: %d %s ",
			  deviceInfo.BD_ADDR.BD_ADDR5,
                 deviceInfo.BD_ADDR.BD_ADDR4,
                 deviceInfo.BD_ADDR.BD_ADDR3,
                 deviceInfo.BD_ADDR.BD_ADDR2,
                 deviceInfo.BD_ADDR.BD_ADDR1,
                 deviceInfo.BD_ADDR.BD_ADDR0,				
				 deviceInfo.DeviceAttributes,
				 CString(deviceInfo.Name));

	
		  m_ctrllist.InsertItem(0, stradd,0);

	  }	  
} 

void CBTE_sample_1Dlg::OnBnClickedButtonServiceFind()
{
	m_ctrllist.DeleteAllItems();
	m_listtype = 2;				//list type

	unsigned				serviceUUID= 16;
	HRESULT result;
	
	BTP_Service_Find        serviceFind;
	BTP_Service_Info_Ex_t   serviceInfo;
	BTP_Service_Query_t     serviceQuery;
	SDP_UUID_Entry_t        service[1];
	CString					strname;
	
	serviceInfo.Size = sizeof(BTP_Service_Info_Ex_t);

  
   memset(&serviceQuery, 0, sizeof(serviceQuery));

   /* Set the BD ADDR of the device that we want to query                  */
   serviceQuery.BD_ADDR = connectionInfo.BD_ADDR;
   serviceQuery.NumberServiceUUID = 1;
   serviceQuery.Service = service;

   /* Normally, the service UUID will be a 16-bit UUID. There is only one  */
   /* custom case that we have encountered where a 128-bit UUID has been   */
   /* used for a custom SPP service. For this reason, we will only check   */
   /* for the special 128-bit case and assume all others are a 16-bit UUID.*/
   service[0].SDP_Data_Element_Type = deUUID_16;
   switch(connectionInfo.ProfileType)
   {
   case BTP_PROFILE_SPP:
      if (128==serviceUUID)
      {
         service[0].SDP_Data_Element_Type = deUUID_128;
         /* This is the special case of a custom 128-bit UUID SPP.         */
         ASSIGN_UUID_128((service[0].UUID_Value.UUID_128),
            0x85, 0x60, 0xCA, 0x18,  // 0x8560CA18
            0x62, 0x3F,              // 0x623f
            0x4A, 0x77,              // 0x4a77
            0x9F, 0x5E, 0x3C, 0x52, 0x66, 0x68, 0x05, 0x1A); // 0x9f, 0x5e, 0x3c, 0x52, 0x66, 0x68, 0x05, 0x1a
      }
      else
      {
         /* We will only request services that support SPP.                */
         /* FYI: The 16-bit UUID for SPP is 0x1101. Reference the Bluetooth*/
         /* spec for additional UUIDs at http://www.bluetooth.org          */
         ASSIGN_UUID_16((service[0].UUID_Value.UUID_16), 0x11, 0x01)
      }
      break;
   case BTP_PROFILE_HID_HOST:
   case BTP_PROFILE_HID_DEVICE:
      /* We will only request services that support HID.                   */
      /* FYI: The 16-bit UUID for HID is 0x1124. Reference the Bluetooth   */
      /* spec for additional UUIDs at http://www.bluetooth.org             */
      ASSIGN_UUID_16((service[0].UUID_Value.UUID_16), 0x11, 0x24)
      break;
   }

   BeginWaitCursor();
   /* Search for the service                                               */
   result = BTPFindFirstServiceEx(&serviceFind, &serviceInfo, &serviceQuery);
   if (BTP_ERROR_SUCCESS == result)
   {
	   EndWaitCursor();
      do
      {
         /* Is this the service to which we want to connect? For this ex-  */
         /* ample, we will limit our search to any service that at least   */
         /* begins with the string passed in as the service name.          */
       
            /* We found a service that is close to what we are seeking     */
            /* Populate the Connection Info structure for this service.    */
            connectionInfo.ProfileType  = serviceInfo.ProfileType;
            connectionInfo.MajorVersion = serviceInfo.MajorVersion;
            connectionInfo.MinorVersion = serviceInfo.MinorVersion;
            switch(connectionInfo.ProfileType)
            {
			
            case BTP_PROFILE_UNKNOWN: /* Treat unknown profiles as RFCOMM based (SPP) profiles */
				connectionInfo.ProfileInformation.RemoteSerialPortProfileInfo.RFCOMMServerPort  = serviceInfo.ProfileInformation.RemoteSerialPortProfileInfo.RFCOMMServerPort;
                connectionInfo.ProfileInformation.RemoteSerialPortProfileInfo.UseActiveSync    = serviceInfo.ProfileInformation.RemoteSerialPortProfileInfo.UseActiveSync;				
				break;
            case BTP_PROFILE_SPP:
				connectionInfo.ProfileInformation.RemoteSerialPortProfileInfo.RFCOMMServerPort  = serviceInfo.ProfileInformation.RemoteSerialPortProfileInfo.RFCOMMServerPort;
				connectionInfo.ProfileInformation.RemoteSerialPortProfileInfo.UseActiveSync     = serviceInfo.ProfileInformation.RemoteSerialPortProfileInfo.UseActiveSync;

				
				strname.Format(L"%s\n",CString(serviceInfo.ServiceName));
				
				m_ctrllist.InsertItem(0, strname,0);
				break;
			case BTP_PROFILE_HID_HOST:
			case BTP_PROFILE_HID_DEVICE:
				connectionInfo.ProfileInformation.RemoteHIDProfileInfo.DeviceAutomaticReconnect = serviceInfo.ProfileInformation.RemoteHIDProfileInfo.DeviceAutomaticReconnect;
				connectionInfo.ProfileInformation.RemoteHIDProfileInfo.DeviceNormallyConnectable= serviceInfo.ProfileInformation.RemoteHIDProfileInfo.DeviceNormallyConnectable;
				connectionInfo.ProfileInformation.RemoteHIDProfileInfo.DeviceSubclass           = serviceInfo.ProfileInformation.RemoteHIDProfileInfo.DeviceSubclass;
				connectionInfo.ProfileInformation.RemoteHIDProfileInfo.L2CAPControlChannel      = serviceInfo.ProfileInformation.RemoteHIDProfileInfo.L2CAPControlChannel;
				connectionInfo.ProfileInformation.RemoteHIDProfileInfo.L2CAPInterruptChannel    = serviceInfo.ProfileInformation.RemoteHIDProfileInfo.L2CAPInterruptChannel;
				connectionInfo.ProfileInformation.RemoteHIDProfileInfo.VirtualCableSupported    = serviceInfo.ProfileInformation.RemoteHIDProfileInfo.VirtualCableSupported;
				break;
           }	
			
			
         result = BTPFindNextServiceEx(serviceFind, &serviceInfo);
      } while (BTP_ERROR_SUCCESS == result);

      if (BTP_ERROR_NO_MORE != result)
         fprintf(stderr, "%s - ERROR (line %d): Failed to find next service. Result = %d\n", __FUNCTION__, __LINE__, result);

      BTPFindServiceClose(serviceFind);
	 
   }

}



void CBTE_sample_1Dlg::OnNMClickList1(NMHDR *pNMHDR, LRESULT *pResult)
{
	NM_LISTVIEW*		pNMListView	= (NM_LISTVIEW*)pNMHDR;
	int					nSelectNum	= pNMListView->iItem;	
	 BTP_Device_Info_t  deviceInfo;	
	 BTP_Connection_Info_t  connectioinfo_;

	 if(m_listtype ==1)
	 {
		  deviceInfo =	m_Deviceitem.GetAt(m_Deviceitem.FindIndex(nSelectNum));
		  connectionInfo.BD_ADDR = deviceInfo.BD_ADDR;
	 }
	 else if(m_listtype ==3)
	 {
		connectioinfo_ =	m_Connectitem.GetAt(m_Connectitem.FindIndex(nSelectNum));
		  connectionInfo.BD_ADDR = connectioinfo_.BD_ADDR;
		  connectionInfo.ConnectionID = connectioinfo_.ConnectionID;
	 }



	*pResult = 0;
}

void CBTE_sample_1Dlg::OnBnClickedButtonLocalinfo()
{
	HRESULT result;
	DWORD classOfDevice;
	CString str;
	BTP_Find_Local_Device_From_BTE_t device;
	result = BTPFindLocalDevice(&device);
	if (BTP_ERROR_SUCCESS == result)
	{
		
		classOfDevice = (((unsigned int)device.DeviceInfo.ClassOfDevice.Class_of_Device0) << 16) | 
			(((unsigned int)device.DeviceInfo.ClassOfDevice.Class_of_Device1) << 8) |
			((unsigned int)device.DeviceInfo.ClassOfDevice.Class_of_Device2);

		str.Format(L"\tFriendly Name: %s\n\tBD_ADDR: [%02X:%02X:%02X:%02X:%02X:%02X]\n\tClass of Device: %u (0x%02X%02X%02X)\n",
			CString(device.DeviceInfo.Name),
			device.DeviceInfo.BD_ADDR.BD_ADDR5,
			device.DeviceInfo.BD_ADDR.BD_ADDR4,
			device.DeviceInfo.BD_ADDR.BD_ADDR3,
			device.DeviceInfo.BD_ADDR.BD_ADDR2,
			device.DeviceInfo.BD_ADDR.BD_ADDR1,
			device.DeviceInfo.BD_ADDR.BD_ADDR0,
			classOfDevice,
			device.DeviceInfo.ClassOfDevice.Class_of_Device0,
			device.DeviceInfo.ClassOfDevice.Class_of_Device1,
			device.DeviceInfo.ClassOfDevice.Class_of_Device2);

	
		AfxMessageBox(str);
	}
}



void CBTE_sample_1Dlg::OnBnClickedButtonConnectionFind()
{

	m_ctrllist.DeleteAllItems();
	m_Connectitem.RemoveAll();

	m_listtype = 3;				//list type
	HRESULT result;
	CString stradd;
   BTP_Connection_Find    connectFind;
   BTP_Connection_Info_t  connectioinfo;
   BTP_Connection_Query_t connectQuery;

   memset(&connectQuery, 0, sizeof(connectQuery));
 

  
   connectQuery.ConnectionAttributes = BTP_CONNECTION_REMEMBERED;
   

  
   BeginWaitCursor();
  
   result = BTPFindFirstConnection(&connectFind, &connectioinfo, &connectQuery);
	if (BTP_ERROR_SUCCESS == result)
   {
	   EndWaitCursor();
      do
      {
        BTP_Connection_Info_t  connectInfo_temp;
          memcpy(&connectInfo_temp,&connectioinfo,sizeof(BTP_Connection_Info_t));		   
		  m_Connectitem.AddTail(connectInfo_temp);
		
		  result = BTPFindNextConnection(connectFind, &connectioinfo);
      } while (BTP_ERROR_SUCCESS == result);      
       
	}
	BTPFindConnectionClose(connectFind);



	  int lm_count = m_Connectitem.GetCount();
	  int i = 0;

	  for(i = lm_count-1;i>=0;i--)
	  {


		  connectioinfo =	m_Connectitem.GetAt(m_Connectitem.FindIndex(i));


		  

		  stradd.Format(L"[%02X:%02X:%02X:%02X:%02X:%02X] id:%d",
			  connectioinfo.BD_ADDR.BD_ADDR5,
                 connectioinfo.BD_ADDR.BD_ADDR4,
                 connectioinfo.BD_ADDR.BD_ADDR3,
                 connectioinfo.BD_ADDR.BD_ADDR2,
                 connectioinfo.BD_ADDR.BD_ADDR1,
                 connectioinfo.BD_ADDR.BD_ADDR0,
				 connectioinfo.ConnectionID);

	
		  m_ctrllist.InsertItem(0, stradd,0);

	  }
}

void CBTE_sample_1Dlg::OnBnClickedButton3ConnectionCreate()
{
	HRESULT result;
	   /* Create a favorite association												*/
   connectionInfo.ConnectionAttributes = BTP_CONNECTION_REMEMBERED | BTP_CONNECTION_ACTIVE;
   connectionInfo.LocalCOMPort = 9;
   connectionInfo.ProfileType = BTP_PROFILE_SPP; 
   result = BTPCreateConnectionEx(&connectionInfo);
   if (BTP_ERROR_SUCCESS == result)
	   SetWindowText(L"crete connection");
   else
	   AfxMessageBox(L"Create Connection_error");
}

void CBTE_sample_1Dlg::OnBnClickedButtonConnectionDelete()
{
	HRESULT result;
	/* Delete the favorite                                      */
	result = BTPDeleteConnection(connectionInfo.ConnectionID);
	if (BTP_ERROR_SUCCESS != result)
		SetWindowText(L"delete connection");
   else
	   AfxMessageBox(L"delete Connection_error");
}
