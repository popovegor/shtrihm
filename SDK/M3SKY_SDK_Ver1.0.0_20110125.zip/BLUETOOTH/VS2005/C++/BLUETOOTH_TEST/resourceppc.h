//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by BTE_sample_1ppc.rc
//
#define IDD_BTE_SAMPLE_1_DIALOG         102
#define IDD_BTE_SAMPLE_1_DIALOG_WIDE    103
#define IDR_MAINFRAME                   128
#define IDC_STATIC_1                    200
#define IDC_BUTTON_INIT                 1000
#define IDC_BUTTON_CLOSE                1001
#define IDC_BUTTON_CONNECT              1002
#define IDC_BUTTON_DISCONNECT           1003
#define IDC_BUTTON_DEVICE_FIND          1004
#define IDC_BUTTON_SERVICE_FIND         1005
#define IDC_LIST1                       1006
#define IDC_BUTTON_LOCALINFO            1008
#define IDC_BUTTON_CONNECTION_FIND      1010
#define IDC_BUTTON3_CONNECTION_CREATE   1012
#define IDC_BUTTON4                     1013
#define IDC_BUTTON_CONNECTION_DELETE    1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
