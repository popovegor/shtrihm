/*****< CustomerDLL.h >********************************************************/
/*      Copyright 2006 Stonestreet One, Inc.                                  */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  CustomerDLL - Includes function pointer definitions for all BTExplorer    */
/*                Enhanced Provisioning API functions.                        */
/*                                                                            */
/*  Author:  Daniel Grieshaber                                                */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   12/15/06  D. Grieshaber  Initial creation.                               */
/******************************************************************************/

/************************************************************************/
/* Initialization/Cleanup                                               */
/************************************************************************/

   /** Initializes the BTExplorer API.

       \return Returns true for success, false for failure.             */
typedef bool (*BTPInitAPI_t)(void);

   /** Cleans up after the BTExplorer API is no longer needed.          */
typedef void (*BTPCloseAPI_t)(void);

/************************************************************************/
/* Informational                                                        */
/************************************************************************/

   /** Information on the local device.

       \param DeviceInfo Pointer to a structure that will receive 
       information about the local device.

       \return Returns a status code indicating success or failure.     */
typedef HRESULT (*BTPFindLocalDevice_t)(BTP_Find_Local_Device_From_BTE_t *DeviceInfo);

/************************************************************************/
/* Searching for Remote Devices                                         */
/************************************************************************/

   /** Returns the first device matching the criteria.
    
       \param DeviceFind Pointer to the device enumeration handle.
       \param DeviceInfo Pointer to structure to receive device
       information.
       \param DeviceQuery Pointer to structure providing filtering for
       the devices that will be returned.

       \return Returns a status code indicating success or failure.     */
typedef HRESULT (*BTPFindFirstDevice_t)(BTP_Device_Find *DeviceFind, BTP_Device_Info_t *DeviceInfo, const BTP_Device_Query_t *DeviceQuery);

   /** Returns the first device matching the criteria.
    
       \param DeviceFind Pointer to the device enumeration handle.
       \param DeviceInfo Pointer to structure to receive device
       information.
       \param DeviceQuery Pointer to structure providing filtering for
       the devices that will be returned.

       \return Returns a status code indicating success or failure.     */
typedef HRESULT (*BTPFindFirstDeviceEx_t)(BTP_Device_Find *DeviceFind, BTP_Device_Info_t *DeviceInfo, const BTP_Device_Query_Ex_t *DeviceQuery);

   /** Returns the next device matching the criteria specified in the 
       call to BTP_Find_First_Device.

       \param DeviceFind Device enumeration handle.
       \param DeviceInfo Pointer to structure to receive device
       information.

       \return Returns a status code indicating success or failure.      */
typedef HRESULT (*BTPFindNextDevice_t)(BTP_Device_Find DeviceFind, BTP_Device_Info_t *DeviceInfo);

   /** Closes the device enumerations and frees associated resources.

       \param DeviceFind Device enumeration handle.

       \return Returns a status code indicating success or failure.     */
typedef HRESULT (*BTPFindDeviceClose_t)(BTP_Device_Find DeviceFind);


/************************************************************************/
/* Searching for Remote Services                                        */
/************************************************************************/

   /** Begins enumeration of services provided by a device.

       \param ServiceFind Pointer to the service enumeration handle.
       \param ServiceInfo Pointer to a structure to receive service
       information.
       \param ServiceQuery Pointer to structure providing filtering for
       the services that will be returned.

       \return Returns a status code indicating success or failure.     */
typedef HRESULT (*BTPFindFirstService_t)(BTP_Service_Find *ServiceFind, BTP_Service_Info_t *ServiceInfo, const BTP_Service_Query_t *ServiceQuery);

   /** Begins enumeration of services provided by a device.

       \param ServiceFind Pointer to the service enumeration handle.
       \param ServiceInfo Pointer to a structure to receive service
       information.
       \param ServiceQuery Pointer to structure providing filtering for
       the services that will be returned.

       \return Returns a status code indicating success or failure.     */
typedef HRESULT (*BTPFindFirstServiceEx_t)(BTP_Service_Find *ServiceFind, BTP_Service_Info_Ex_t *ServiceInfo, const BTP_Service_Query_t *ServiceQuery);

   /** Retrieves the next service in the enumeration.

       \param ServiceFind Service enumeration handle.
       \param ServiceInfo Pointer to structure to receive service
       information.

       \return Returns a status code indicating success or failure.     */
typedef HRESULT (*BTPFindNextService_t)(BTP_Service_Find ServiceFind, BTP_Service_Info_t *ServiceInfo);

   /** Retrieves the next service in the enumeration.

       \param ServiceFind Service enumeration handle.
       \param ServiceInfo Pointer to structure to receive service
       information.

       \return Returns a status code indicating success or failure.     */
typedef HRESULT (*BTPFindNextServiceEx_t)(BTP_Service_Find ServiceFind, BTP_Service_Info_Ex_t *ServiceInfo);

   /** Terminates the service discovery and frees associated resources.

       \param ServiceFind Service enumeration handle.

       \return Returns a status code indicating success or failure.     */
typedef HRESULT (*BTPFindServiceClose_t)(BTP_Service_Find ServiceFind);


/************************************************************************/
/* Connections and Favorites                                            */
/************************************************************************/

   /** Begins enumeration of active connections and Favorites.

       \param ConnectionFind Pointer to the connections enumeration 
       handle.
       \param ConnectionInfo Pointer to structure to receive connection
       information.
       \param ConnectionQuery Pointer to srtucture providing filtering
       for the connections and Favorites that will be returned.

       \return Returns a status code indicating success or failure.     */
typedef HRESULT (*BTPFindFirstConnection_t)(BTP_Connection_Find *ConnectionFind, BTP_Connection_Info_t *ConnectionInfo, const BTP_Connection_Query_t *ConnectionQuery);

   /** Retrieves the next active connection or Favorite.

       \param ConnectionFind Connections enumeration handle.
       \param ConnectionInfo Pointer to structure to receive connection
       information.

       \return Returns a status code indicating success or failure.     */
typedef HRESULT (*BTPFindNextConnection_t)(BTP_Connection_Find ConnectionFind, BTP_Connection_Info_t *ConnectionInfo);

   /** Terminates the connection enumeration and frees associated 
       resources.

       \param ConnectionFind Connection ennumeration handle.

       \return Returns a status code indicating success or failure.     */
typedef HRESULT (*BTPFindConnectionClose_t)(BTP_Connection_Find ConnectionFind);

   /** Creates a temporary or persistent (Favorite) connection.

       \param ConnectionInfo Pointer to structure identifying the
       connection to be made.

       \return Returns a status code indicating success or failure.     */
typedef HRESULT (*BTPCreateConnection_t)(BTP_Connection_Info_t *ConnectionInfo);

   /** Creates a temporary or persistent (Favorite) connection.

       \param ConnectionInfo Pointer to structure identifying the
       connection to be made.

       \return Returns a status code indicating success or failure.     */
typedef HRESULT (*BTPCreateConnectionEx_t)(BTP_Connection_Info_Ex_t *ConnectionInfo);

   /** Deletes an existing temporary or persistent (Favorite) connection.

       \param ConnectionID Reference to the connection to delete.

       \return Returns a status code indicating success or failure.     */
typedef HRESULT (*BTPDeleteConnection_t)(BTP_Connection_ID ConnectionID);

   /** Connects to a persistent connection (Favorite).

       \param ConnectionID Reference to the connection to connect.      

       \return Returns a status code indicating success or failure.     */
typedef HRESULT (*BTPConnect_t)(BTP_Connection_ID ConnectionID);

   /** Terminates an active connection.

       \param ConnectionID Reference to the connection to disconnect.

       \return Returns a status code indicating success or failure.     */
typedef HRESULT (*BTPDisconnect_t)(BTP_Connection_ID ConnectionID);

   /** Sets the PIN for incoming connections to services that require
       authentication.

       \param NewPIN Pointer to a PIN structure that contains the PIN 
       to be used for incoming connections.
       \param OldPIN Pointer to a PIN structure that will receive the
       PIN that will be overwritten by the NewPIN.

       \return Returns a status code indicating success or failure.     */
typedef HRESULT (*BTPSetIncomingPIN_t)(BTP_PIN_t *NewPIN, BTP_PIN_t *OldPIN);

   /** Sets the PIN for outgoing connections to remote devices that 
       require a PIN.

       \param NewPIN Pointer to a PIN structure that contains the PIN
       to be used for all outgoing connections.
       \param OldPIN Pointer to a PIN structure that will receive the
       PIN that was previously used for outgoing connections.

       \return Returns a status code indicating success or failure.     */
typedef HRESULT (*BTPSetOutgoingPIN_t)(BTP_PIN_t *NewPIN, BTP_PIN_t *OldPIN);


/************************************************************************/
/* Callback Functions                                                   */
/************************************************************************/

   /** Defines a callback for authentication requests associated with a
       specified device.

       \param BD_ADDR Pointer to the device identifier.
       \param AuthenticationCallback Pointer to the function to be
       called when authentication is required.
       \param CallbackParameter User defined parameter.

       \return Returns a status code indicating success or failure.     */
typedef HRESULT (*BTPSetAuthenticationCallback_t)(const BD_ADDR_t *BD_ADDR, BTP_Authentication_Callback_t AuthenticationCallback, LPVOID CallbackParameter);

   /** Defines a callback for connection events associated with a
       specified connection.

       \param ConnectionID ID of the connection to monitor.
       \param ConnectionCallback Pointer to the function to be called
       when a connection event occurs.
       \param CallbackParameter User defined parameter.

       \return Returns a status code indicating success or failure.     */
typedef HRESULT (*BTPSetConnectionCallback_t)(BTP_Connection_ID ConnectionID, BTP_Connection_Callback_t ConnectionCallback, LPVOID CallbackParameter);


   /** Authentication callback prototype. This function is responsible
       for supplying an authentication password associated with the
       remote Bluetooth device specified by the passed in BD_ADDR. 
       
       \param BD_ADDR BD_ADDR specifying the device requesting
       authentication.
       \param PassKey Buffer to accept the password.
       \param CallbackParameter User-defined parameter specified when
       the callback is registered.
      
       \return Returns BTP_ERROR_SUCCESS if successful, or
       BTP_ERROR_NO_KEY_AVAILABLE if no password can be provided.       */
typedef HRESULT (*BTP_Authentication_Callback_t)(const BD_ADDR_t *BD_ADDR, char *const PassKey, LPVOID CallbackParameter);

   /** Connection Event callback prototype.
   
       \param ConnectionID Reference to the connection that encountered
       the event.
       \param ConnectionState True indicates an active connection, false
       indicates an inactive connection.
       \param CallbackParameter User-defined parameter specified when
       the callback is registered.                                      */
typedef void (*BTP_Connection_Callback_t)(const BTP_Connection_ID ConnectionID, bool ConnectionState, LPVOID CallbackParameter);
