﻿namespace BTE_sample_CS_1
{
	partial class IOPinCodeWF
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.MainMenu mainMenu1;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.textBox_Incoming = new System.Windows.Forms.TextBox();
			this.checkbox_Incoming = new System.Windows.Forms.CheckBox();
			this.checkBox_Outgoing = new System.Windows.Forms.CheckBox();
			this.textBox_Outgoing = new System.Windows.Forms.TextBox();
			this.button_ok = new System.Windows.Forms.Button();
			this.button_cancel = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// textBox_Incoming
			// 
			this.textBox_Incoming.Location = new System.Drawing.Point(122, 37);
			this.textBox_Incoming.Name = "textBox_Incoming";
			this.textBox_Incoming.Size = new System.Drawing.Size(100, 21);
			this.textBox_Incoming.TabIndex = 0;
			// 
			// checkbox_Incoming
			// 
			this.checkbox_Incoming.Location = new System.Drawing.Point(17, 37);
			this.checkbox_Incoming.Name = "checkbox_Incoming";
			this.checkbox_Incoming.Size = new System.Drawing.Size(100, 20);
			this.checkbox_Incoming.TabIndex = 1;
			this.checkbox_Incoming.Text = "Incoming";
			// 
			// checkBox_Outgoing
			// 
			this.checkBox_Outgoing.Location = new System.Drawing.Point(17, 78);
			this.checkBox_Outgoing.Name = "checkBox_Outgoing";
			this.checkBox_Outgoing.Size = new System.Drawing.Size(100, 20);
			this.checkBox_Outgoing.TabIndex = 2;
			this.checkBox_Outgoing.Text = "Outgoing";
			// 
			// textBox_Outgoing
			// 
			this.textBox_Outgoing.Location = new System.Drawing.Point(122, 78);
			this.textBox_Outgoing.Name = "textBox_Outgoing";
			this.textBox_Outgoing.Size = new System.Drawing.Size(100, 21);
			this.textBox_Outgoing.TabIndex = 3;
			// 
			// button_ok
			// 
			this.button_ok.Location = new System.Drawing.Point(30, 172);
			this.button_ok.Name = "button_ok";
			this.button_ok.Size = new System.Drawing.Size(82, 46);
			this.button_ok.TabIndex = 4;
			this.button_ok.Text = "OK";
			this.button_ok.Click += new System.EventHandler(this.button_ok_Click);
			// 
			// button_cancel
			// 
			this.button_cancel.Location = new System.Drawing.Point(129, 172);
			this.button_cancel.Name = "button_cancel";
			this.button_cancel.Size = new System.Drawing.Size(82, 46);
			this.button_cancel.TabIndex = 5;
			this.button_cancel.Text = "Cancel";
			this.button_cancel.Click += new System.EventHandler(this.button_cancel_Click);
			// 
			// IOPinCodeWF
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
			this.AutoScroll = true;
			this.ClientSize = new System.Drawing.Size(240, 294);
			this.Controls.Add(this.button_cancel);
			this.Controls.Add(this.button_ok);
			this.Controls.Add(this.textBox_Outgoing);
			this.Controls.Add(this.checkBox_Outgoing);
			this.Controls.Add(this.checkbox_Incoming);
			this.Controls.Add(this.textBox_Incoming);
			this.Name = "IOPinCodeWF";
			this.Text = "IOPinCodeWF";
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TextBox textBox_Incoming;
		private System.Windows.Forms.CheckBox checkbox_Incoming;
		private System.Windows.Forms.CheckBox checkBox_Outgoing;
		private System.Windows.Forms.TextBox textBox_Outgoing;
		private System.Windows.Forms.Button button_ok;
		private System.Windows.Forms.Button button_cancel;
	}
}