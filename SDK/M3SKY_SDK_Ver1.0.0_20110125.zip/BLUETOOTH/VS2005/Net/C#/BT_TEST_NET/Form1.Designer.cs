﻿namespace BTE_sample_CS_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_init = new System.Windows.Forms.Button();
            this.button_close = new System.Windows.Forms.Button();
            this.button_device_find = new System.Windows.Forms.Button();
            this.button_service_find = new System.Windows.Forms.Button();
            this.button_connect = new System.Windows.Forms.Button();
            this.button_disconnect = new System.Windows.Forms.Button();
            this.button_localinfo = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button_ctreate_connection = new System.Windows.Forms.Button();
            this.button_delete_connection = new System.Windows.Forms.Button();
            this.button_conntion_find = new System.Windows.Forms.Button();
            this.button_set_io_pin = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button_init
            // 
            this.button_init.Location = new System.Drawing.Point(0, 8);
            this.button_init.Name = "button_init";
            this.button_init.Size = new System.Drawing.Size(118, 20);
            this.button_init.TabIndex = 0;
            this.button_init.Text = "init";
            this.button_init.Click += new System.EventHandler(this.button_init_Click);
            // 
            // button_close
            // 
            this.button_close.Location = new System.Drawing.Point(122, 8);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(118, 20);
            this.button_close.TabIndex = 1;
            this.button_close.Text = "close";
            this.button_close.Click += new System.EventHandler(this.button_close_Click);
            // 
            // button_device_find
            // 
            this.button_device_find.Location = new System.Drawing.Point(0, 35);
            this.button_device_find.Name = "button_device_find";
            this.button_device_find.Size = new System.Drawing.Size(118, 20);
            this.button_device_find.TabIndex = 2;
            this.button_device_find.Text = "device find";
            this.button_device_find.Click += new System.EventHandler(this.button_device_find_Click);
            // 
            // button_service_find
            // 
            this.button_service_find.Location = new System.Drawing.Point(122, 35);
            this.button_service_find.Name = "button_service_find";
            this.button_service_find.Size = new System.Drawing.Size(118, 20);
            this.button_service_find.TabIndex = 3;
            this.button_service_find.Text = "service find";
            this.button_service_find.Click += new System.EventHandler(this.button_service_find_Click);
            // 
            // button_connect
            // 
            this.button_connect.Location = new System.Drawing.Point(18, 244);
            this.button_connect.Name = "button_connect";
            this.button_connect.Size = new System.Drawing.Size(54, 20);
            this.button_connect.TabIndex = 5;
            this.button_connect.Text = "connect";
            this.button_connect.Click += new System.EventHandler(this.button_connect_Click);
            // 
            // button_disconnect
            // 
            this.button_disconnect.Location = new System.Drawing.Point(78, 244);
            this.button_disconnect.Name = "button_disconnect";
            this.button_disconnect.Size = new System.Drawing.Size(72, 20);
            this.button_disconnect.TabIndex = 6;
            this.button_disconnect.Text = "disconnect";
            this.button_disconnect.Click += new System.EventHandler(this.button_disconnect_Click);
            // 
            // button_localinfo
            // 
            this.button_localinfo.Location = new System.Drawing.Point(158, 244);
            this.button_localinfo.Name = "button_localinfo";
            this.button_localinfo.Size = new System.Drawing.Size(59, 20);
            this.button_localinfo.TabIndex = 7;
            this.button_localinfo.Text = "localinfo";
            this.button_localinfo.Click += new System.EventHandler(this.button_localinfo_Click);
            // 
            // listBox1
            // 
            this.listBox1.Location = new System.Drawing.Point(18, 128);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(199, 100);
            this.listBox1.TabIndex = 8;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // button_ctreate_connection
            // 
            this.button_ctreate_connection.Location = new System.Drawing.Point(0, 61);
            this.button_ctreate_connection.Name = "button_ctreate_connection";
            this.button_ctreate_connection.Size = new System.Drawing.Size(118, 20);
            this.button_ctreate_connection.TabIndex = 9;
            this.button_ctreate_connection.Text = "create conn";
            this.button_ctreate_connection.Click += new System.EventHandler(this.button_ctreate_connection_Click);
            // 
            // button_delete_connection
            // 
            this.button_delete_connection.Location = new System.Drawing.Point(122, 61);
            this.button_delete_connection.Name = "button_delete_connection";
            this.button_delete_connection.Size = new System.Drawing.Size(118, 20);
            this.button_delete_connection.TabIndex = 10;
            this.button_delete_connection.Text = "Delete conn";
            this.button_delete_connection.Click += new System.EventHandler(this.button_delete_connection_Click);
            // 
            // button_conntion_find
            // 
            this.button_conntion_find.Location = new System.Drawing.Point(0, 87);
            this.button_conntion_find.Name = "button_conntion_find";
            this.button_conntion_find.Size = new System.Drawing.Size(118, 20);
            this.button_conntion_find.TabIndex = 11;
            this.button_conntion_find.Text = "Conn find";
            this.button_conntion_find.Click += new System.EventHandler(this.conntion_find_Click);
            // 
            // button_set_io_pin
            // 
            this.button_set_io_pin.Location = new System.Drawing.Point(122, 87);
            this.button_set_io_pin.Name = "button_set_io_pin";
            this.button_set_io_pin.Size = new System.Drawing.Size(118, 20);
            this.button_set_io_pin.TabIndex = 12;
            this.button_set_io_pin.Text = "Set IO Pin Code";
            this.button_set_io_pin.Click += new System.EventHandler(this.button_set_io_pin_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 294);
            this.Controls.Add(this.button_set_io_pin);
            this.Controls.Add(this.button_conntion_find);
            this.Controls.Add(this.button_delete_connection);
            this.Controls.Add(this.button_ctreate_connection);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.button_localinfo);
            this.Controls.Add(this.button_disconnect);
            this.Controls.Add(this.button_connect);
            this.Controls.Add(this.button_service_find);
            this.Controls.Add(this.button_device_find);
            this.Controls.Add(this.button_close);
            this.Controls.Add(this.button_init);
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "M3BtNet";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_init;
        private System.Windows.Forms.Button button_close;
        private System.Windows.Forms.Button button_device_find;
        private System.Windows.Forms.Button button_service_find;
        private System.Windows.Forms.Button button_connect;
        private System.Windows.Forms.Button button_disconnect;
        private System.Windows.Forms.Button button_localinfo;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button_ctreate_connection;
        private System.Windows.Forms.Button button_delete_connection;
        private System.Windows.Forms.Button button_conntion_find;
		private System.Windows.Forms.Button button_set_io_pin;
    }
}

