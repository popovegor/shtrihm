﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using BTEAPIdllNet;

namespace BTE_sample_CS_1
{	
    public partial class Form1 : Form
    {
        M3BTEDllNet BteDll;

		public String m_strIncoming;
		public String m_strOutgoing;


        public uint m_devicecount;
        public uint m_servicecount;
        public uint m_connectioncount;
        public M3BTEDllNet._CONNECTINFO m_connectinfo;
        public M3BTEDllNet._LOCALINFO m_localinfo;

        public uint m_listtype =0;

        public Form1()
        {
            InitializeComponent();

            BteDll = new M3BTEDllNet();


			m_strIncoming = "";
			m_strOutgoing = "";
        }

        private void button_init_Click(object sender, EventArgs e)
        {
			if (BteDll.M3BTPInit())
			{
				MessageBox.Show("connect success");

                M3BTEDllNet._TAG_BTP_PIN NewPinCode = new M3BTEDllNet._TAG_BTP_PIN();
                M3BTEDllNet._TAG_BTP_PIN OldPinCode = new M3BTEDllNet._TAG_BTP_PIN();

                if (m_strOutgoing != null)
                {
                    AssignPinCode(m_strOutgoing, ref NewPinCode);

                    if (BteDll.M3BTPSetOutgoingPIN(out  NewPinCode, ref OldPinCode))
                    {
                        // TODO: 
                        //					MessageBox.Show("OK");
                    }
                    else
                    {
                        // TODO: 
                        //					MessageBox.Show("Fail");
                    }
                    // 				MessageBox.Show("Len: " + OldPinCode.PINLength
                    // 								+ " : " + OldPinCode.PINCode.PIN_Code0
                    // 								+ " : " + OldPinCode.PINCode.PIN_Code1
                    // 								+ " : " + OldPinCode.PINCode.PIN_Code2
                    // 								+ " : " + OldPinCode.PINCode.PIN_Code3
                    // 								+ " : " + OldPinCode.PINCode.PIN_Code4
                    // 								+ " : " + OldPinCode.PINCode.PIN_Code5
                    // 								+ " : " + OldPinCode.PINCode.PIN_Code6
                    // 					);
                }

                if(m_strIncoming != null)
                {
                    AssignPinCode(m_strIncoming, ref NewPinCode);



                    if (BteDll.M3BTPSetIncomingPIN(out NewPinCode, ref OldPinCode))
                    {
                        // TODO: 
                        //					MessageBox.Show("OK");
                    }
                    else
                    {
                        // TODO: 
                        //					MessageBox.Show("Fail");
                    }
                    // 				 MessageBox.Show("Len: " + NewPinCode.PINLength
                    // 								+ " : " + NewPinCode.PINCode.PIN_Code0
                    // 								+ " : " + NewPinCode.PINCode.PIN_Code1
                    // 								+ " : " + NewPinCode.PINCode.PIN_Code2
                    // 								+ " : " + NewPinCode.PINCode.PIN_Code3
                    // 								+ " : " + NewPinCode.PINCode.PIN_Code4
                    // 								+ " : " + NewPinCode.PINCode.PIN_Code5
                    // 								+ " : " + NewPinCode.PINCode.PIN_Code6
                    // 					);
                }

			}
			else
				MessageBox.Show("fail");
        }

        private void button_close_Click(object sender, EventArgs e)
        {
            if (BteDll.M3BTPClose())
                MessageBox.Show("close success");
            else
                MessageBox.Show("fail");
        }       

        private void button_device_find_Click(object sender, EventArgs e)
        {
            m_listtype = 1;
            listBox1.Items.Clear();
            Cursor.Current = Cursors.WaitCursor;

            m_devicecount=BteDll.M3BTPFindDevice();
            // 임시
            m_devicecount = 3;

            Cursor.Current = Cursors.Default;
            String szstr;


            for (uint i = 1; i <= m_devicecount; i++)
            {
                M3BTEDllNet._LOCALINFO localinfo;
                byte[] Name = new byte[1026];
                BteDll.M3BTPGetFindDevice(i, out localinfo, Name);

                szstr = String.Format("{0:x2} {1:x2} {2:x2} {3:x2} {4:x2} {5:x2} {6:G}",
                localinfo.BD_ADDR.add5,
                localinfo.BD_ADDR.add4,
                localinfo.BD_ADDR.add3,
                localinfo.BD_ADDR.add2,
                localinfo.BD_ADDR.add1,
                localinfo.BD_ADDR.add0,
                Encoding.Default.GetString(Name, 0, 1026));

                listBox1.Items.Add(szstr);
                
            }

        }

        private void button_service_find_Click(object sender, EventArgs e)
        {
            if (m_listtype != 1)
            {
                MessageBox.Show("find device");
                return;
            }

            if (listBox1.SelectedIndex == -1)
            {
                MessageBox.Show("select listitem");
                return;
            }
            else
            {
                m_listtype = 2;
                String szstr;
                

                byte[] Name_d = new byte[1026];
                BteDll.M3BTPGetFindDevice((uint)listBox1.SelectedIndex + 1, out m_localinfo, Name_d);
                szstr = String.Format("FIND service {0:x2} {1:x2} {2:x2} {3:x2} {4:x2} {5:x2} {6:G}",
                m_localinfo.BD_ADDR.add5,
                m_localinfo.BD_ADDR.add4,
                m_localinfo.BD_ADDR.add3,
                m_localinfo.BD_ADDR.add2,
                m_localinfo.BD_ADDR.add1,
                m_localinfo.BD_ADDR.add0,
                Encoding.Default.GetString(Name_d, 0, 1026));
                

                listBox1.Items.Clear();
                m_servicecount = BteDll.M3BTPFindService(out m_localinfo);
                
                for (uint i = 1; i <= m_servicecount; i++)
                {
                    M3BTEDllNet._CONNECTINFO connectinfo;
                    byte[] Name_s = new byte[1026];
                    BteDll.M3BTPGetFindService(i, out connectinfo, Name_s);

                    szstr = String.Format("{0:G}",
                    Encoding.Default.GetString(Name_s, 0, 1026));

                    listBox1.Items.Add(szstr);
                }
            }

        }
        private void button_ctreate_connection_Click(object sender, EventArgs e)
        {
            if (m_listtype != 2)
            {
                MessageBox.Show("find service");
                return;
            }

            if (listBox1.SelectedIndex == -1)
            {
                MessageBox.Show("select listitem");
                return;
            }
            else
            {
                M3BTEDllNet._CONNECTINFO connectinfo;
                byte[] Name_s = new byte[1026];

               connectinfo.BD_ADDR = m_localinfo.BD_ADDR;
              
                BteDll.M3BTPGetFindService((uint)listBox1.SelectedIndex + 1, out connectinfo, Name_s);
                String szstr;

                szstr = String.Format("FIND service {0:x2} {1:x2} {2:x2} {3:x2} {4:x2} {5:x2} {6:G}",
               connectinfo.BD_ADDR.add5,
               connectinfo.BD_ADDR.add4,
               connectinfo.BD_ADDR.add3,
               connectinfo.BD_ADDR.add2,
               connectinfo.BD_ADDR.add1,
               connectinfo.BD_ADDR.add0,
               Encoding.Default.GetString(Name_s, 0, 1026));
                MessageBox.Show(szstr);
                
              
                if (BteDll.M3BTPCreateConnection(out connectinfo))
                    MessageBox.Show("create success");
                else
                    MessageBox.Show("create fail");

                m_listtype = 0;
            }
        }

        private void button_delete_connection_Click(object sender, EventArgs e)
        {
            if (m_listtype != 3)
            {
                MessageBox.Show("find connection");
                return;
            }
            if (listBox1.SelectedIndex == -1)
            {
                MessageBox.Show("select listitem");
                return;
            }
            else
            {
                M3BTEDllNet._CONNECTINFO connectinfo;
                
                BteDll.M3BTPGetFindConnection((uint)listBox1.SelectedIndex + 1, out connectinfo);
                if (BteDll.M3BTPDeleteConnection(connectinfo.ConnectionID))
                    MessageBox.Show("delete success");
                else
                    MessageBox.Show("delete fail");

                m_listtype = 0;
            }
        }

        private void conntion_find_Click(object sender, EventArgs e)
        {
            m_listtype = 3;
            listBox1.Items.Clear();
            m_connectioncount = BteDll.M3BTPFindConnection();
            for (uint i = 1; i <= m_connectioncount; i++)
            {
                M3BTEDllNet._CONNECTINFO connectinfo;
                String szstr;
                BteDll.M3BTPGetFindConnection(i, out connectinfo);


                szstr = String.Format("{0:x2} {1:x2} {2:x2} {3:x2} {4:x2} {5:x2}",
                   connectinfo.BD_ADDR.add5,
                   connectinfo.BD_ADDR.add4,
                   connectinfo.BD_ADDR.add3,
                   connectinfo.BD_ADDR.add2,
                   connectinfo.BD_ADDR.add1,
                   connectinfo.BD_ADDR.add0);
                listBox1.Items.Add(szstr);

            }

        }

        private void button_connect_Click(object sender, EventArgs e)
        {
            if (m_listtype != 3)
            {
                MessageBox.Show("find connection");
                return;
            }

            if (listBox1.SelectedIndex == -1)
            {
                MessageBox.Show("select listitem");
                return;
            }
            else
            {

                M3BTEDllNet._CONNECTINFO connectinfo;

                BteDll.M3BTPGetFindConnection((uint)listBox1.SelectedIndex + 1, out connectinfo);
                BteDll.M3BTPConnect(connectinfo.ConnectionID);

                m_listtype = 0;
            }
        }

        private void button_disconnect_Click(object sender, EventArgs e)
        {
            if (m_listtype != 3)
            {
                MessageBox.Show("find connection");
                return;
            }

            if (listBox1.SelectedIndex == -1)
            {
                MessageBox.Show("select listitem");
                return;
            }
            else
            {
                M3BTEDllNet._CONNECTINFO connectinfo;

                BteDll.M3BTPGetFindConnection((uint)listBox1.SelectedIndex + 1, out connectinfo);
                BteDll.M3BTPDisconnect(connectinfo.ConnectionID);

                m_listtype = 0;
            }
        }
        
        private void button_localinfo_Click(object sender, EventArgs e)
        {
            M3BTEDllNet._LOCALINFO localinfo;
            byte [] Name = new byte[1026];

            String szstr;
            BteDll.M3BTPFindLocalDevice(out localinfo, Name);

            szstr = String.Format("{0:x2} {1:x2} {2:x2} {3:x2} {4:x2} {5:x2} {6:G}",
                localinfo.BD_ADDR.add5,
                localinfo.BD_ADDR.add4,
                localinfo.BD_ADDR.add3,
                localinfo.BD_ADDR.add2,
                localinfo.BD_ADDR.add1,
                localinfo.BD_ADDR.add0,
                Encoding.Default.GetString(Name, 0, 1026));
            
            MessageBox.Show(szstr);          

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


		[DllImport("coredll.dll")]
		static extern IntPtr memcpy(ref M3BTEDllNet._TAG_BTP_PIN_CODE dest, char[] c, uint count);

        public bool AssignPinCode(String str, ref M3BTEDllNet._TAG_BTP_PIN pin)
		{
            if ((M3BTEDllNet.PIN_CODE_SIZE < str.Length) || (0 >= str.Length))
				return false;


			pin.PINLength = (uint)str.Length;

			char[] temp = str.ToCharArray();
            char[] arrayData = new char[M3BTEDllNet.PIN_CODE_SIZE];

			int index;

			for (index = 0; index < pin.PINLength; index++)
			{
				arrayData[index] = temp[index];
			}

			pin.PINCode.PIN_Code0 = (byte)arrayData[0];
			pin.PINCode.PIN_Code1 = (byte)arrayData[1];
			pin.PINCode.PIN_Code2 = (byte)arrayData[2];
			pin.PINCode.PIN_Code3 = (byte)arrayData[3];
			pin.PINCode.PIN_Code4 = (byte)arrayData[4];
			pin.PINCode.PIN_Code5 = (byte)arrayData[5];
			pin.PINCode.PIN_Code6 = (byte)arrayData[6];
			pin.PINCode.PIN_Code7 = (byte)arrayData[7];
			pin.PINCode.PIN_Code8 = (byte)arrayData[8];
			pin.PINCode.PIN_Code9 = (byte)arrayData[9];
			pin.PINCode.PIN_Code10 = (byte)arrayData[10];
			pin.PINCode.PIN_Code11 = (byte)arrayData[11];
			pin.PINCode.PIN_Code12 = (byte)arrayData[12];
			pin.PINCode.PIN_Code13 = (byte)arrayData[13];
			pin.PINCode.PIN_Code14 = (byte)arrayData[14];
			pin.PINCode.PIN_Code15 = (byte)arrayData[15];



			return true;		

			
		}

		private void button_set_io_pin_Click(object sender, EventArgs e)
		{			
			IOPinCodeWF IOPinCode;

			IOPinCode = new IOPinCodeWF( m_strIncoming, m_strOutgoing);

			

			if (IOPinCode.ShowDialog() == DialogResult.OK)
			{ 
				m_strIncoming = IOPinCode.GetIncoming();
				m_strOutgoing = IOPinCode.GetOutgoing();
			}
		}




	}
}