﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BTE_sample_CS_1
{
	public partial class IOPinCodeWF : Form
	{
		private String m_strIncoming;
		private String m_strOutgoing;

		public const int PIN_CODE_SIZE = 16;

		public IOPinCodeWF(String strIncoming, String strOutgoing)
		{
			InitializeComponent();

			textBox_Incoming.Text = strIncoming;
			textBox_Outgoing.Text = strOutgoing;
		}

		private void button_ok_Click(object sender, EventArgs e)
		{
			if(checkbox_Incoming.Checked)
			{
				if (textBox_Incoming.Text.Length > PIN_CODE_SIZE)
				{
					//	TODO: error 
				}
				m_strIncoming = textBox_Incoming.Text;
			}

			if(checkBox_Outgoing.Checked)
			{
				if (textBox_Outgoing.Text.Length > PIN_CODE_SIZE)
				{
					//	TODO: error 
				}
				m_strOutgoing = textBox_Outgoing.Text;
			}

			this.DialogResult = DialogResult.OK;
		}

		private void button_cancel_Click(object sender, EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
		}

		public String GetOutgoing()
		{
			return m_strOutgoing;
		}

		public String GetIncoming()
		{
			return m_strIncoming;
		}
	}
}