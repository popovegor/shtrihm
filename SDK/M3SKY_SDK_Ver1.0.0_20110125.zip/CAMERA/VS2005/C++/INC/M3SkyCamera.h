// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the M3SKYCAMERA_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// M3SKYCAMERA_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
#pragma once
#ifdef M3SKYCAMERA_EXPORTS
#define M3SKYCAMERA_API __declspec(dllexport)
#else
#define M3SKYCAMERA_API __declspec(dllimport)
#endif

#define WM_COMPLETE		WM_USER+101
#define WM_STATUS_AF	WM_USER + 916

#define AF_STATUS_START		1
#define AF_STATUS_FINISH	0

// Af Mode
#define AF_MANUAL		0
#define AF_ALWAYS		1
#define AF_AUTO			2



typedef void (CALLBACK *MANAGED_SAMPLEPROCESSEDPROC)(BYTE* pdata, int height, int width, int bitcount, int stride, GUID type);


//#include "Dispdib.h"

// This class is exported from the M3SkyCamera.dll
class M3SKYCAMERA_API CM3SkyCamera {
public:
	CM3SkyCamera(void);
	~CM3SkyCamera(void);
};


typedef enum {
	STILL_MODE = 0,
	VIDEO_MODE
	 
} CAMERA_MODE;

typedef enum {
	VIDEO_ASF = 0,
	VIDEO_WMV 
} VIDEO_TYPE;


///////////////////////////////////////////////////////////////////////////////////////////////////////
// For Getting Pexel Data [11/4/2008 CROW = DongHyun, Eum]

typedef unsigned short RGBQUAD16;

///////////////////////////////////////////////////////////////////////////////////////////////////////


extern M3SKYCAMERA_API int nM3SkyCamera;

M3SKYCAMERA_API int fnM3SkyCamera(void);

EXTERN_C M3SKYCAMERA_API BOOL	OpenCamera(HWND hWnd, CAMERA_MODE cameramode, VIDEO_TYPE videotype = VIDEO_WMV);
EXTERN_C M3SKYCAMERA_API void	CloseCamera();


EXTERN_C M3SKYCAMERA_API BOOL	SetWindowPosition(long left,  long top, long width, long height);
EXTERN_C M3SKYCAMERA_API BOOL	PreviewStart();
EXTERN_C M3SKYCAMERA_API BOOL	PreviewStop();
EXTERN_C M3SKYCAMERA_API BOOL	VideoStart(PTCHAR FileFullName);
EXTERN_C M3SKYCAMERA_API BOOL	VideoStop();	
EXTERN_C M3SKYCAMERA_API WCHAR* CaptureStill(WCHAR *FileFULLName);
EXTERN_C M3SKYCAMERA_API WCHAR* CaptureStillEx(WCHAR *FileFULLName, BOOL AutoInit = FALSE);
EXTERN_C M3SKYCAMERA_API void	captureStill(WCHAR  *FileFullName, WCHAR  *DateName);
EXTERN_C M3SKYCAMERA_API void	captureStillEx(WCHAR  *FileFullName, WCHAR  *DateName, BOOL AutoInit  = FALSE);


EXTERN_C M3SKYCAMERA_API BOOL	FlashOn(BOOL on);
EXTERN_C M3SKYCAMERA_API long	GetResolution(int PinType);
EXTERN_C M3SKYCAMERA_API BOOL	SetResolution(int PinType, int nResolution);
EXTERN_C M3SKYCAMERA_API BOOL	Set_Resolution(int PinType, int nResolution);
EXTERN_C M3SKYCAMERA_API long	GetBrightness();
EXTERN_C M3SKYCAMERA_API BOOL	SetBrightness(long value);
EXTERN_C M3SKYCAMERA_API long	GetWhiteBalance();
EXTERN_C M3SKYCAMERA_API BOOL	SetWhiteBalance(long value);
EXTERN_C M3SKYCAMERA_API BOOL	Zoom(int index);
EXTERN_C M3SKYCAMERA_API BOOL	AutoFocus();
EXTERN_C M3SKYCAMERA_API int	SetAFMode(int nMode);	// Modify 20101216 jj
EXTERN_C M3SKYCAMERA_API void	SetQuality(DWORD value);
EXTERN_C M3SKYCAMERA_API DWORD	GetQuality();

EXTERN_C M3SKYCAMERA_API HRESULT	InitFilterGraph();
EXTERN_C M3SKYCAMERA_API HRESULT	CameraLoad();
EXTERN_C M3SKYCAMERA_API HRESULT	SetupPreview();
EXTERN_C M3SKYCAMERA_API HRESULT	SetupVideo();
EXTERN_C M3SKYCAMERA_API HRESULT	SetupStill();
EXTERN_C M3SKYCAMERA_API HRESULT	SetWindow();


EXTERN_C M3SKYCAMERA_API BOOL InitVideoCamera();

EXTERN_C M3SKYCAMERA_API  PTCHAR GetInfo();
EXTERN_C M3SKYCAMERA_API  void getInfo(WCHAR *strinfo);


EXTERN_C M3SKYCAMERA_API BOOL ShowPreview(BOOL bShow);


EXTERN_C M3SKYCAMERA_API void DecodeMode(BOOL bEnable);

///////////////////////////////////////////////////////////////////////////////////////////////////////
// Histogram Equalization [11/4/2008 CROW = DongHyun, Eum]

EXTERN_C M3SKYCAMERA_API void DibHistoEqual(WCHAR* pFileName);
EXTERN_C M3SKYCAMERA_API void EnableHistoEqual(BOOL Enable, int NightLevel);
EXTERN_C M3SKYCAMERA_API BOOL GetHisto(PBOOL pbHistoEqual);
EXTERN_C M3SKYCAMERA_API BOOL GetNightLevel(int* pNightLevel);



template<typename T>
inline T limit(const T& nvalue)
{
	return ( (nvalue > 255) ? 255 : ((nvalue < 0) ? 0 : nvalue) );
}

template<typename T>
inline T limit(const T& nvalue, const T& lower, const T& upper)
{
	return ((nvalue > upper) ? upper : ((nvalue < lower) ? lower : nvalue));
}

///////////////////////////////////////////////////////////////////////////////////////////////////////

//EXTERN_C M3SKYCAMERA_API HRESULT SetRoll(long value);


EXTERN_C M3SKYCAMERA_API void	RegisterPreview(MANAGED_SAMPLEPROCESSEDPROC fpPreview);