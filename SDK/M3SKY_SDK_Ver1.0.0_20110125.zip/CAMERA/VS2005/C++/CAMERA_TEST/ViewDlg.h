#pragma once
#include "afxwin.h"


// CViewDlg dialog

class CViewDlg : public CDialog
{
	DECLARE_DYNAMIC(CViewDlg)

public:
	BOOL m_bThreading;

	CViewDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CViewDlg();

// Dialog Data
	enum { IDD = IDD_VIEW_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CStatic m_Static_Image;
	virtual BOOL OnInitDialog();
	void Show();
	CString m_strPath;
	virtual void OnOK();
protected:
};
