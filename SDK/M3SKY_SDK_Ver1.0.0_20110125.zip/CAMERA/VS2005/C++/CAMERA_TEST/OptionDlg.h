#pragma once
#include "afxwin.h"

#include "M3SkyCamera.h"
#include "afxcmn.h"
// COptionDlg dialog

class COptionDlg : public CDialog
{
	DECLARE_DYNAMIC(COptionDlg)

public:
	COptionDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~COptionDlg();

// Dialog Data
	enum { IDD = IDD_OPTION_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	CComboBox m_ctlBrightness;
	CComboBox m_ctlWhiteBalance;
	CComboBox m_ctlResolution;

	CString m_strFolder;
	CString m_strFileName;
	CComboBox m_ctlSaveMode;

	
public:
	BOOL	m_bDateSaveMode;
	BOOL	m_bVideo;

	VIDEO_TYPE	m_videotype;

	CEdit m_ctlSaveFolder;
	CEdit m_ctlSaveName;
	afx_msg void OnCbnSelchangeComboSaveMode();
	CStatic m_ctlStaticSaveFolder;
	CStatic m_ctlStaticSaveName;
	CStatic m_ctlStaticVideoType;
	CComboBox m_ctlVideoType;
	CComboBox m_ctlQuality;
public:
	
public:
	void InitResolutionUI();
//////////////////////////////////////////////////////////////////////////
// NightLevel Variable [11/4/2008 CROW = DongHyun, Eum]
	BOOL	m_bHistoEqual;
	int				m_nNightLevel;
	CSpinButtonCtrl m_ctrlspinNightLevel;
	CStatic			m_ctrlstaticNightLevel;
	CEdit			m_ctrleditNightLevel;
	CButton m_ctrlcheckNightMode;
	int			m_nDeviceType;

	afx_msg void OnBnClickedCheckHistoequal();

//////////////////////////////////////////////////////////////////////////
	BOOL m_bAutoPreview;
	afx_msg void OnMenuCancel();
	afx_msg void OnMenuOk();
	int m_nAFType;
	CComboBox m_ctrl_AF_Type;
	afx_msg void OnBnClickedButtonVersion();
	afx_msg void OnCbnSelchangeComboResolution();
};
