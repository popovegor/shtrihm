// Camera.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Camera.h"
#include "CameraDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

HANDLE g_hMutex = NULL;

// CCameraApp

BEGIN_MESSAGE_MAP(CCameraApp, CWinApp)
END_MESSAGE_MAP()


// CCameraApp construction
CCameraApp::CCameraApp()
	: CWinApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only CCameraApp object
CCameraApp theApp;

// CCameraApp initialization

BOOL CCameraApp::InitInstance()
{
    // SHInitExtraControls should be called once during your application's initialization to initialize any
    // of the Windows Mobile specific controls such as CAPEDIT and SIPPREF.
    SHInitExtraControls();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	CCameraDlg dlg;

	m_bCameraSwitchMode = FALSE;

	// ScanEmul�� ����ɶ��� Skip�� �� �ֵ��� ���� [2010.12.8. 14:01:50 ParkHyunJu]
	if(NULL != FindWindow(L"SCANEMUL", NULL))
		m_bCameraSwitchMode = dlg.m_Reg.GetRegValue(HKEY_CURRENT_USER, L"Software\\M3Mobile\\Scanner", L"CAMERA_SWITCH_MODE");


	///�ߺ����� ����

	if(m_bCameraSwitchMode != TRUE)
	{
		g_hMutex = ::CreateMutex(NULL, TRUE, _T("2D IMAGER"));//("MC_SCANNER"));
		if(GetLastError() == ERROR_ALREADY_EXISTS)
		{
			MessageBox(NULL,_T("IMAGER Engine is already running!"),_T("ERROR"),MB_OK|MB_ICONWARNING);

			ReleaseMutex(g_hMutex);
			CloseHandle(g_hMutex);

			return FALSE;
		}
		ReleaseMutex(g_hMutex);
		CloseHandle(g_hMutex);
	}

// 	g_hMutex = ::CreateMutex(NULL, TRUE, _T("2D IMAGER"));//("MC_SCANNER"));
// 	if(GetLastError() == ERROR_ALREADY_EXISTS)
// 	{
// 		MessageBox(NULL,_T("Scanner Engine is already running!"),_T("ERROR"),MB_OK|MB_ICONWARNING);
// 
// 		ReleaseMutex(g_hMutex);
// 		CloseHandle(g_hMutex);
// 
// 		return FALSE;
// 	}
// 	ReleaseMutex(g_hMutex);
// 	CloseHandle(g_hMutex);


	///�ߺ����� ����
	g_hMutex = ::CreateMutex(NULL, TRUE, _T("M3SKYCAMERA"));//("MC_SCANNER"));
	if(GetLastError() == ERROR_ALREADY_EXISTS)
	{
		MessageBox(NULL,_T("Camera Program is already running!"),_T("ERROR"),MB_OK|MB_ICONWARNING);
		return FALSE;
	}

//	CCameraDlg dlg;
	m_pMainWnd = &dlg;
	INT_PTR nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.

	ReleaseMutex(g_hMutex);	
	CloseHandle(g_hMutex);

	return FALSE;
}
