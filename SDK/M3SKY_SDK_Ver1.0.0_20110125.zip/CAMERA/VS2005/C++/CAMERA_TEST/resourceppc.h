//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Camerappc.rc
//
#define IDD_CAMERA_DIALOG               102
#define IDD_CAMERA_DIALOG_WIDE          103
#define IDR_MAINFRAME                   128
#define IDD_OPTION_DIALOG               129
#define IDD_VIEW_DIALOG                 130
#define IDD_DIALOG1                     131
#define IDR_MENU1                       132
#define IDR_MENU                        132
#define IDC_STATIC_1                    200
#define IDC_BTN_FLASH_ON                1001
#define IDC_BTN_FLASH_OFF               1002
#define IDC_BTN_START                   1003
#define IDC_BTN_STOP                    1004
#define IDC_COMBO_BRIGHTNESS            1005
#define IDC_COMBO1                      1006
#define IDC_COMBO_BRIGHT                1006
#define IDC_COMBO_ZOOM                  1006
#define IDC_BTN_VIDEO_START             1007
#define IDC_BTN_VIDEO_STOP              1008
#define IDC_BTNAutoFocus                1009
#define IDC_BTN_AUTOFOCUS               1009
#define IDC_BTN                         1010
#define IDC_BTN_RESIZE                  1010
#define IDC_BTN_CAPTURE                 1011
#define IDC_BTN_MODE                    1012
#define IDC_BTN_OPTION                  1013
#define IDC_COMBO2                      1014
#define IDC_COMBO_RESOLUTION            1014
#define IDC_COMBO_WHITE_BALANCE         1015
#define IDC_EDIT_SAVE_FOLDER            1016
#define IDC_EDIT_SAVE_NAME              1017
#define IDC_COMBO_SAVE_MODE             1018
#define IDC_STATIC_SAVE_FOLDER          1019
#define IDC_STATIC_SAVE_NAME            1020
#define IDC_COMBO3                      1021
#define IDC_COMBO_VIDEO_TYPE            1021
#define IDC_STATIC_VIDEO_TYPE           1022
#define IDC_STATIC_TIME                 1024
#define IDC_STATIC_TIMER                1025
#define IDC_STATIC_IMAGE                1026
#define IDC_STATIC_STATUS               1026
#define IDC_COMBO_                      1028
#define IDC_COMBO_QUALITY               1028
#define IDC_STATIC_STILL_IMAGE          1029
#define IDC_STATIC_STANDBY              1030
#define IDC_CHECK1                      1031
#define IDC_CHECK_CAMERA                1031
#define IDC_CHECK_HISTOGRAM             1031
#define IDC_CHECK_HISTOEQUAL            1031
#define IDC_EDIT_NIGHTLEVEL             1032
#define IDC_SPIN_NIGHTLEVEL             1033
#define IDC_STATIC_NIGHTLEVEL           1034
#define IDC_CHECK_AUTO_PREVIEW          1035
#define IDC_CHECK2                      1036
#define IDC_CHECK_ALWAYS_AF             1036
#define IDC_COMBO4                      1037
#define IDC_COMBO_AF                    1037
#define IDC_STATIC_AGING_COUNT          1038
#define IDC_STATIC_VERSION              1040
#define IDC_BUTTON1                     1041
#define IDC_BUTTON_VERSION              1041
#define IDC_STATIC_NIGHT                1042
#define ID_OK                           32771
#define ID_CANCEL                       32772
#define ID_MENU_CANCEL                  32773
#define ID_MENU_OK                      32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1043
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
