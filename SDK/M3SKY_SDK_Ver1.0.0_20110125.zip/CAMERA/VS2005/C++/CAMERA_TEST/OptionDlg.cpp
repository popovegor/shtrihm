// OptionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Camera.h"
#include "OptionDlg.h"

#include "M3SkyCamera.h"


// COptionDlg dialog

IMPLEMENT_DYNAMIC(COptionDlg, CDialog)

COptionDlg::COptionDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COptionDlg::IDD, pParent)
	, m_strFolder(_T(""))
	, m_strFileName(_T(""))
	, m_nNightLevel(0)
	, m_bAutoPreview(FALSE)
	, m_nAFType(AF_MANUAL)
{

//////////////////////////////////////////////////////////////////////////
//  [10/29/2008 CROW = DongHyun, Eum]
 	m_bHistoEqual = FALSE;				// Histogram Equalization �ʱ�ȭ(FALSE)
	m_nNightLevel = 0;

	GetHisto(&m_bHistoEqual) ;			// ���� ������ m_bHistoEqual���� �޴´�.
	GetNightLevel(&m_nNightLevel);		// ���� ������ m_nNightLevel���� �޴´�.
//////////////////////////////////////////////////////////////////////////
	
}

COptionDlg::~COptionDlg()
{
}

void COptionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_BRIGHT, m_ctlBrightness);
	DDX_Control(pDX, IDC_COMBO_WHITE_BALANCE, m_ctlWhiteBalance);
	DDX_Control(pDX, IDC_COMBO_RESOLUTION, m_ctlResolution);
	DDX_Text(pDX, IDC_EDIT_SAVE_FOLDER, m_strFolder);
	DDX_Text(pDX, IDC_EDIT_SAVE_NAME, m_strFileName);
	DDX_Control(pDX, IDC_COMBO_SAVE_MODE, m_ctlSaveMode);
	DDX_Control(pDX, IDC_EDIT_SAVE_FOLDER, m_ctlSaveFolder);
	DDX_Control(pDX, IDC_EDIT_SAVE_NAME, m_ctlSaveName);
	DDX_Control(pDX, IDC_STATIC_SAVE_FOLDER, m_ctlStaticSaveFolder);
	DDX_Control(pDX, IDC_STATIC_SAVE_NAME, m_ctlStaticSaveName);
	DDX_Control(pDX, IDC_STATIC_VIDEO_TYPE, m_ctlStaticVideoType);
	DDX_Control(pDX, IDC_COMBO_VIDEO_TYPE, m_ctlVideoType);
	DDX_Control(pDX, IDC_COMBO_QUALITY, m_ctlQuality);

	//  [10/10/2008 CROW]
	DDX_Check(pDX, IDC_CHECK_HISTOEQUAL, m_bHistoEqual);
	DDX_Text(pDX, IDC_EDIT_NIGHTLEVEL, m_nNightLevel);
	DDX_Control(pDX, IDC_SPIN_NIGHTLEVEL, m_ctrlspinNightLevel);
	DDX_Control(pDX, IDC_STATIC_NIGHTLEVEL, m_ctrlstaticNightLevel);
	DDX_Control(pDX, IDC_EDIT_NIGHTLEVEL, m_ctrleditNightLevel);
	DDX_Control(pDX, IDC_CHECK_HISTOEQUAL, m_ctrlcheckNightMode);
	DDX_Check(pDX, IDC_CHECK_AUTO_PREVIEW, m_bAutoPreview);
	DDX_Control(pDX, IDC_COMBO_AF, m_ctrl_AF_Type);
}


BEGIN_MESSAGE_MAP(COptionDlg, CDialog)
	ON_CBN_SELCHANGE(IDC_COMBO_SAVE_MODE, &COptionDlg::OnCbnSelchangeComboSaveMode)
	ON_BN_CLICKED(IDC_CHECK_HISTOEQUAL, &COptionDlg::OnBnClickedCheckHistoequal)
	ON_COMMAND(ID_MENU_CANCEL, &COptionDlg::OnMenuCancel)
	ON_COMMAND(ID_MENU_OK, &COptionDlg::OnMenuOk)
	ON_BN_CLICKED(IDC_BUTTON_VERSION, &COptionDlg::OnBnClickedButtonVersion)
	ON_CBN_SELCHANGE(IDC_COMBO_RESOLUTION, &COptionDlg::OnCbnSelchangeComboResolution)
END_MESSAGE_MAP()


// COptionDlg message handlers

BOOL COptionDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Menu
	SHMENUBARINFO mbi;

	HINSTANCE hInst = AfxGetInstanceHandle();

	memset(&mbi, 0, sizeof(SHMENUBARINFO));
	mbi.cbSize = sizeof(SHMENUBARINFO);
	mbi.hwndParent = m_hWnd;
	mbi.nToolBarId = IDR_MENU;
	mbi.hInstRes = hInst;
	mbi.dwFlags = SHCMBF_HMENU;

	SHCreateMenuBar(&mbi);

	// TODO:  Add extra initialization here
	m_ctlBrightness.InsertString(0, L"+3");
	m_ctlBrightness.InsertString(1, L"+2");
	m_ctlBrightness.InsertString(2, L"+1");
	m_ctlBrightness.InsertString(3, L"0");
	m_ctlBrightness.InsertString(4, L"-1");
	m_ctlBrightness.InsertString(5, L"-2");
	m_ctlBrightness.InsertString(6, L"-3");

	m_ctlWhiteBalance.InsertString(0, L"Auto");
	m_ctlWhiteBalance.InsertString(1, L"Sunny");
	m_ctlWhiteBalance.InsertString(2, L"Cloudy");
	m_ctlWhiteBalance.InsertString(3, L"Fluorescent");
	m_ctlWhiteBalance.InsertString(4, L"Incandescent");

	InitResolutionUI();

//////////////////////////////////////////////////////////////////////////
//	Orange
/*

	m_ctlResolution.InsertString(0, L"176*144");
	m_ctlResolution.InsertString(1, L"320*240");
	m_ctlResolution.InsertString(2, L"352*288");
	m_ctlResolution.InsertString(3, L"400*300");
	m_ctlResolution.InsertString(4, L"640*480");
	m_ctlResolution.InsertString(5, L"800*600");
	m_ctlResolution.InsertString(6, L"1024*768");
	m_ctlResolution.InsertString(7, L"1280*960");
	m_ctlResolution.InsertString(8, L"1280*1024");
	m_ctlResolution.InsertString(9, L"1600*1200");
	m_ctlResolution.InsertString(10, L"2048*1536");
*/	


//////////////////////////////////////////////////////////////////////////
//	SKY
// 	m_ctlResolution.InsertString(0, L"176*144");
// 	m_ctlResolution.InsertString(1, L"320*240");
// 	m_ctlResolution.InsertString(2, L"352*288");
// 	m_ctlResolution.InsertString(3, L"640*480");
// 	m_ctlResolution.InsertString(4, L"800*600");
// 	m_ctlResolution.InsertString(5, L"1280*960");
// 	m_ctlResolution.InsertString(6, L"1600*1200");


	m_ctlSaveMode.InsertString(0, L"Date Mode");
	m_ctlSaveMode.InsertString(1, L"Custom Mode");

	m_ctlVideoType.InsertString(0, L"WMV");
	m_ctlVideoType.InsertString(1, L"ASF");

	m_ctlQuality.InsertString(0, L"Low quality");
	m_ctlQuality.InsertString(1, L"Normal quality");
	m_ctlQuality.InsertString(2, L"High quality");

	// Add JJ 20100916: If you use a Auto AF, then SampleGrabberFilter.dll must exist in Flash Disk\Camera folder.
	m_ctrl_AF_Type.InsertString(AF_MANUAL,	L"Manual AF");
	m_ctrl_AF_Type.InsertString(AF_ALWAYS,	L"Always AF");
	m_ctrl_AF_Type.InsertString(AF_AUTO,	L"Auto AF");
	m_ctrl_AF_Type.SetCurSel(m_nAFType);

	if(m_nDeviceType == DEVICE_MM3)
	{
		m_ctrl_AF_Type.EnableWindow(FALSE);
	}

	if(m_bVideo)
	{
		m_ctlStaticVideoType.EnableWindow(TRUE);
		m_ctlVideoType.EnableWindow(TRUE);
		m_ctrl_AF_Type.EnableWindow(FALSE);
		m_ctrlcheckNightMode.EnableWindow(FALSE);
		m_ctlResolution.EnableWindow(FALSE);
		m_ctlQuality.EnableWindow(FALSE);
		
		::EnableWindow(::GetDlgItem(m_hWnd, IDC_CHECK_AUTO_PREVIEW), FALSE);
		::EnableWindow(::GetDlgItem(m_hWnd, IDC_STATIC_NIGHT), FALSE);
	}
	else
	{
		m_ctlStaticVideoType.EnableWindow(FALSE);
		m_ctlVideoType.EnableWindow(FALSE);
		::EnableWindow(::GetDlgItem(m_hWnd, IDC_CHECK_AUTO_PREVIEW), TRUE);
	}

	if(m_bDateSaveMode)
	{
		m_ctlStaticSaveName.EnableWindow(FALSE);
		m_ctlStaticSaveFolder.EnableWindow(FALSE);
		m_ctlSaveFolder.EnableWindow(FALSE);
		m_ctlSaveName.EnableWindow(FALSE);
	}
	else
	{
		m_ctlStaticSaveName.EnableWindow(TRUE);
		m_ctlStaticSaveFolder.EnableWindow(TRUE);
		m_ctlSaveFolder.EnableWindow(TRUE);
		m_ctlSaveName.EnableWindow(TRUE);
	}


	if(m_bDateSaveMode)
		m_ctlSaveMode.SetCurSel(0);
	else
		m_ctlSaveMode.SetCurSel(1);

	if(m_videotype == VIDEO_WMV)
		m_ctlVideoType.SetCurSel(0);
	else
		m_ctlVideoType.SetCurSel(1);


	m_ctlResolution.SetCurSel(GetResolution(1));
	m_ctlBrightness.SetCurSel((GetBrightness()-3)*-1);
	m_ctlWhiteBalance.SetCurSel(GetWhiteBalance());
	m_ctlQuality.SetCurSel(GetQuality());

	//////////////////////////////////////////////////////////////////////////
	// NightLevel Control Setting [11/4/2008 CROW = DongHyun, Eum]

	m_ctrlspinNightLevel.SetRange32(0, 255);

	if(m_bHistoEqual == FALSE)
	{
		m_ctrlcheckNightMode.SetCheck(0);

		m_ctrlstaticNightLevel.EnableWindow(FALSE);
		m_ctrleditNightLevel.EnableWindow(FALSE);
		m_ctrlspinNightLevel.EnableWindow(FALSE);

	}
	else
	{
		m_ctrlcheckNightMode.SetCheck(1);	
	}

	//////////////////////////////////////////////////////////////////////////
	

	UpdateData(FALSE);

	// �ְ� �ػ����� ���� ����Ʈ ��带 �����Ѵ�.
	OnCbnSelchangeComboResolution();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}


void COptionDlg::OnCbnSelchangeComboSaveMode()
{
	if(m_ctlSaveMode.GetCurSel() ==0)
	{
		m_ctlStaticSaveName.EnableWindow(FALSE);
		m_ctlStaticSaveFolder.EnableWindow(FALSE);
		m_ctlSaveFolder.EnableWindow(FALSE);
		m_ctlSaveName.EnableWindow(FALSE);
	}
	else
	{
		m_ctlStaticSaveName.EnableWindow(TRUE);
		m_ctlStaticSaveFolder.EnableWindow(TRUE);
		m_ctlSaveFolder.EnableWindow(TRUE);
		m_ctlSaveName.EnableWindow(TRUE);
	}

	
}

//////////////////////////////////////////////////////////////////////////
//  [11/4/2008 CROW = DongHyun, Eum]

void COptionDlg::OnBnClickedCheckHistoequal()
{
	// TODO: Add your control notification handler code here
	if(m_ctrlcheckNightMode.GetCheck() == 0 )
	{
		m_ctrlstaticNightLevel.EnableWindow(FALSE);
		m_ctrleditNightLevel.EnableWindow(FALSE);
		m_ctrlspinNightLevel.EnableWindow(FALSE);				
	}
	else
	{
		m_ctrlstaticNightLevel.EnableWindow(TRUE);
		m_ctrleditNightLevel.EnableWindow(TRUE);
		m_ctrlspinNightLevel.EnableWindow(TRUE);	
	}
}

//////////////////////////////////////////////////////////////////////////
void COptionDlg::OnMenuCancel()
{
	OnCancel();
}

void COptionDlg::OnMenuOk()
{
	UpdateData(TRUE);


	long value;

	if(m_ctlSaveMode.GetCurSel() == 0)
		m_bDateSaveMode = TRUE;
	else
	{

		if(m_strFolder.GetLength() == 0)
		{
			MessageBox(L"input Save Folder");
			return;
		}
		if(m_strFileName.GetLength() == 0)
		{
			MessageBox(L"input Save Name");
			return;
		}
		m_bDateSaveMode = FALSE;
	}

	//////////////////////////////////////////////////////////////////////////////////
	//  [11/4/2008 CROW = DongHyun, Eum]
	if(m_nNightLevel>255)
	{
		m_nNightLevel = 255;
	}

	EnableHistoEqual(m_bHistoEqual, m_nNightLevel);

	//////////////////////////////////////////////////////////////////////////////////


	value = (m_ctlBrightness.GetCurSel() -3) *-1;
	SetBrightness(value);

	value = m_ctlWhiteBalance.GetCurSel();
	SetWhiteBalance(value);

	value = m_ctlResolution.GetCurSel();


	SetResolution(1,value);



	if(m_ctlVideoType.GetCurSel() == 0)
		m_videotype = VIDEO_WMV;
	else
		m_videotype = VIDEO_ASF;

	m_nAFType = m_ctrl_AF_Type.GetCurSel();
	
	SetAFMode(m_nAFType);

	SetQuality(m_ctlQuality.GetCurSel());


	// TODO: Add your control notification handler code here
	OnOK();
}

//  SKY, Orange���� resolution���� �޶� registry���� �о �����ϵ����� [2010.10.22. 15:13:47 ParkHyunJu]
void COptionDlg::InitResolutionUI()
{

	HKEY	hMainKey;
	DWORD	dwIndex, dwNameLen;
	LONG	lResult;
	TCHAR	pName[MAX_PATH];

	//	The key HKEY_LOCAL_MACHINE\Software\Microsoft\Pictures\Camera\OEM\PictureResolution\ defines the total number of resolution settings available on a device.
	if(ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE, TEXT("Software\\Microsoft\\Pictures\\Camera\\OEM\\PictureResolution"), 0, 0, &hMainKey))
	{
		dwIndex		= 0;
		dwNameLen	= MAX_PATH;


		PDWORD		*pData; 
		DWORD		dwItemCount;
		DWORD		dwItemCountLen = 4;

		//		This value represents the number of available resolutions.
		if(ERROR_SUCCESS == RegQueryValueEx(hMainKey, TEXT("OptionNum"), NULL, NULL, (LPBYTE)&dwItemCount, &dwItemCountLen))
		{
			pData = new PDWORD[dwItemCount];

			if(NULL != pData)
			{
				int index;

				//	�ʱ�ȭ
				for(index = 0; index < dwItemCount; index++)
				{
					pData[index] = NULL;
				}
				
				//	resolution�� item������ �о� ���� 
				while (ERROR_SUCCESS == RegEnumKeyEx(hMainKey, dwIndex++, pName, &dwNameLen, NULL, NULL, NULL, NULL))
				{
					HKEY	hSubKey;
					int		ResolutionIndex;
					DWORD	pResolutionData[2];			//	index 0: width, 1: height			
					TCHAR	pSubKeyPath[MAX_PATH];
					DWORD	dwDataSize;


					wsprintf(pSubKeyPath, L"%s\\%s", TEXT("Software\\Microsoft\\Pictures\\Camera\\OEM\\PictureResolution"), pName);

					if(ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE, pSubKeyPath, 0, 0, &hSubKey))
					{			
						dwDataSize = 4;	
						//	resolution�� item�� Width �о����
						if(ERROR_SUCCESS == RegQueryValueEx(hSubKey, TEXT("Width"), NULL, NULL, (LPBYTE)&pResolutionData[0], &dwDataSize))
						{
							int num = _wtoi(pName) -1;
							pData[num] = new DWORD[2];
							if(NULL != pData[num])
							{
								pData[num][0] = pResolutionData[0];

								dwDataSize = 4;
								//	resolution�� item�� Height �о����
								if(ERROR_SUCCESS == RegQueryValueEx(hSubKey, TEXT("Height"), NULL, NULL, (LPBYTE)&pResolutionData[1], &dwDataSize))
								{
									pData[num][1] = pResolutionData[1];
								}
							}

						}
						RegCloseKey(hSubKey);
					}		
					dwNameLen	= MAX_PATH;
				}

				//	resolution�� "WidthxHeight" ���·� ǥ�� 
				for(index = 0; index < dwItemCount; index++)
				{
					if(NULL != pData[index])
					{
						TCHAR strResolution[10];
						wsprintf(strResolution, L"%dx%d", pData[index][0], pData[index][1]);
						m_ctlResolution.InsertString(index, strResolution);
						delete pData[index];
					}
				}
				delete pData;
			}
		}

		RegCloseKey(hMainKey);
	}
}
void COptionDlg::OnBnClickedButtonVersion()
{
	CString cstrMsg;
	cstrMsg.Format(L"Camera Demo Version\n%s\n%s", APP_VERSION_INFO, GetInfo());
	MessageBox(cstrMsg, L"Version");
}

void COptionDlg::OnCbnSelchangeComboResolution()
{
	
	CString strMsg;
	strMsg.Format(L"GetCount [%d]", m_ctlResolution.GetCount());
	// AfxMessageBox(strMsg);

	// �ִ� �ػ� �϶����� ����Ʈ ��带 ���� ��Ų��. 
	// JJ 101214

	TCHAR strResolution[20];

	m_ctlResolution.GetLBText(m_ctlResolution.GetCurSel(), strResolution);

	if(0 == wcscmp(strResolution, L"2048x1536"))
	{
		m_ctrlcheckNightMode.SetCheck(0);
		m_bHistoEqual = FALSE;

		OnBnClickedCheckHistoequal();

		m_ctrlcheckNightMode.EnableWindow(FALSE);

		::EnableWindow(::GetDlgItem(m_hWnd, IDC_STATIC_NIGHT), FALSE);
	}
	else if(0 == wcscmp(strResolution, L"1600x1200"))	
	{
		// 1600 �ػ󵵴�Night mode�� M3Viewer �� ���� ���� ���� �� �ִ�.
		TCHAR	szThisProgram[MAX_PATH] = {0, }; // Camera Program
		CString szM3Viewr;

		GetModuleFileName(NULL, szThisProgram, sizeof(TCHAR)*MAX_PATH);
		szM3Viewr.Format(_T("%s"), szThisProgram);
		int nIndex = szM3Viewr.ReverseFind('\\');
		szM3Viewr.Format(_T("%s\\M3Viewer.exe"), szM3Viewr.Left(nIndex));

		HANDLE hFile = CreateFile(szM3Viewr, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL,NULL);

		if(hFile == INVALID_HANDLE_VALUE) //Non-executable file or	��an error condition 
		{
			m_ctrlcheckNightMode.EnableWindow(FALSE);

			::EnableWindow(::GetDlgItem(m_hWnd, IDC_STATIC_NIGHT), FALSE);					
		}

	}
	else
	{
		if(m_bVideo == FALSE)
		{
			::EnableWindow(::GetDlgItem(m_hWnd, IDC_STATIC_NIGHT), TRUE);
			m_ctrlcheckNightMode.EnableWindow(TRUE);
		}
		// ���� ����� ������ Ǯ���� �ʿ䰡 ����.

	}
}
