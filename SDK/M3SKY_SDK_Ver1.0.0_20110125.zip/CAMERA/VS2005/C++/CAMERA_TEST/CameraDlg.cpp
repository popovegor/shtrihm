/********************************************************************
created		:	2008/03/27
file base	: 	Camera.exe

file ext	:	cpp
author		:	Dong-Hyun, Eum(vision7901) - SW2

purpose		:	M3 SKY / MM3
Report		:	2008. 03. 27 [03/27/2008 ju]		 v1.0.0 - ���Ĺ������� ����Ǿ ���� ����
				2008. 11. 06 [11/06/2008 vision7901] v1.0.1 - NightMode �߰�. Histogram Equlization�� ���� �߰��Կ��� ȭ�� ���� �ɼ� �߰�
				2008. 12. 02 [12/02/2008 ju]		 v1.0.2 - OS ���ҽ� ���� ���׸� ������ ��ΰ� �ٸ��� ����ó�� �߰�
				2008. 12. 18 [12/18/2008 ju]		 v1.0.3 - �Ϻ��� OS���� ī�޶� Ű�ٿ� ������ �� default ���� 0xc1 �ʳѾ�� F13�κ���
				2009. 03. 27 [03/27/2009 ju]		 v1.0.4 - WM 6.1���� �ʱ�ȭ �������� ���¿��� flash on/off �Ҽ� ���� ������ ���� 
															  GetDlgItem(IDC_BTN_FLASH_ON)->EnableWindow(TRUE);
															  GetDlgItem(IDC_BTN_FLASH_OFF)->EnableWindow(TRUE);	
				2009. 08. 03 [08/03/2009 ju]		 v1.0.4 - Enter key ���� �߰� MM3 ȣȯ Ȯ����
				2010. 01. 12 [01/12/2010 vision7901] v1.0.4 - ī�޶� �μ��ΰ�
				2010. 09. 16 [09/16/2010		 JJ] v1.0.4 - �پ��� AF ����� �߰�. AutoAF ����ǻ ȭ���� �ٲ� �� ���� AF, Always AF ī�޶� �Կ� ���� AF
				2010. 11. 05 [11/05/2010 vision7901] v1.0.5.1 - 2D Imager ScanEmul Switching ��� �߰�
				[2010.11.1. 15:21:59 ParkHyunJu]	 v1.0.5.2 - registry���� resolution ������ �� ǥ���ϴ� ������� ����
															  version ���� ǥ��
				2010. 11. 22 [11/22/2010 vision7901] v1.1.0 - 2D Imager ScanEmul Switching ��� �߰�/ Mutex ����
				2010. 11. 23 JJ v.1.1.1 - ������ ȭ�� �߾ӿ� �簢�� �߰�

				2010. 12. 08. ParkHyunJu						ScanEmul�� ����ɶ��� Switch ��� ���� �Ҽ� �ֵ��� ��
				2010. 12. 09. ParkHyunJu			v0.9.1.1.1	Beta Version ����   ���� ���� ���� �ɶ� "0.9."�� �����Ұ� 	
				2010. 12. 14. JJ					v.1.1.1 - QA �̽� ���� �� ĸ�� �� ����� ��� ����(CaptureStillEx ���)
															  �ִ� �ػ� ���� Night ��� ����, ���׼���
			    2010. 12. 16. JJ					v.1.2.1 - QA ���� ��.. ���� ���� 
				2010. 12. 24. ParkHyunJu			v.1.2.2 -   �޸� �����Ͽ��� BMP ���Ͽ� ���ؼ� 1600*1200 �̻��� �������� ���ϴ� ������ ������ 
																��� ���α׷��� �̿��ϴ� ����� �̿��ؼ� �����Ͽ���. �ִ� 1600*1200 BMP���ϱ��� �����ϵ��� ������
																2048*1536�� BMP������ ����� ���� ����
				2011. 01. 05 JJ						v.1.2.2 - �� ������ 1600X1200 ���� �������� ���� �� ���� ��� ��ü ������ �����ְ� ����
															  MM3 ����
				2011. 01. 14 JJ								- ����Ű ���� ���� 									

				2011. 01. 17. ParkHyunJu			v.1.2.3 -  �̹��� still�߿� Key���� �޼��� �����Ǵ� ���� ����
			    2011. 01. 18. ParkHyunJu						�߰��� �ٸ� ����� ������ �κ��� �־ �ҽ�������
													
													�ӽù��� 1.2.3���� ���� 
				2011. 01. 19 JJ								- AF �ߺ� ���� ����, Ű ���� ���� ����
				2011. 01. 20 JJ								- AF �ߺ� ���� �� ��ư ���� ����
*********************************************************************/

// CameraDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Camera.h"
#include "CameraDlg.h"

#include "OptionDlg.h"
#include "ViewDlg.h"

#include "uuids.h"

// #define AGING			


#ifdef AGING
#define WM_STILL_VEIW_END	WM_USER + 102
#define STILL_TIMER_ID		2
#define STILL_TIMER_DELAY	1500
#endif

//#define DBG_OUT 
#ifdef DBG_OUT
#define DBG_OUTPUT(a);				NKDbgPrintfW(TEXT(a));
#define DBG_OUTPUT1(a,b);			NKDbgPrintfW(TEXT(a),b);
#define DBG_OUTPUT2(a,b,c);			NKDbgPrintfW(TEXT(a),b,c);
#define DBG_OUTPUT3(a,b,c,d);		NKDbgPrintfW(TEXT(a),b,c,d);
#define DBG_OUTPUT4(a,b,c,d,e);		NKDbgPrintfW(TEXT(a),b,c,d,e);
#define DBG_OUTPUT5(a,b,c,d,e,f);	NKDbgPrintfW(TEXT(a),b,c,d,e,f);
#define DBG_OUTPUT6(a,b,c,d,e,f,g);	NKDbgPrintfW(TEXT(a),b,c,d,e,f,g);

#else
#define DBG_OUTPUT(a);
#define DBG_OUTPUT1(a,b);
#define DBG_OUTPUT2(a,b,c);
#define DBG_OUTPUT3(a,b,c,d);
#define DBG_OUTPUT4(a,b,c,d,e);
#define DBG_OUTPUT5(a,b,c,d,e,f);
#define DBG_OUTPUT6(a,b,c,d,e,f,g);

#endif


DWORD  WINAPI PwrMonThread(LPVOID pParam);
DWORD  WINAPI Capture(LPVOID pParma);


///////////////////////////
#include <pm.h>
#include <Msgqueue.h>

#define QUEUE_ENTRIES   3
#define MAX_NAMELEN     200
#define QUEUE_SIZE      (QUEUE_ENTRIES * (sizeof(POWER_BROADCAST) + MAX_NAMELEN))

#define REG_KEYVALUE		(2)		//	VK_F14
#define VK_KEYVALUE		(VK_F13)	//	�Ϻ���� F16, F13 �޼��� ������

//////////////////////////////////////////////////////////////////////////
// 2D Imager ScnaEmul Switching & SideKey Setting
#define HOTKEY_ONE		0x0111
#define HOTKEY_TWO		0x0112
#define HOTKEY_THREE	0x0113

#define WM_CONVERT	WM_USER + 232



#define KEYPAD_NUMERIC	0
#define KEYPAD_QWERTY	1

#define SCANNER_OPTICON		0
#define SCANNER_SYMBOL		1
#define SCANNER_INTERMEC	2
#define SCANNER_HHP			3


//////////////////////////////////////////////////////////////////////////
#define WM_TIMER_CAPTURE	0x1111111
#define WM_TIMER_VIDEO_TIME	0x1111112


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


BOOL g_bOneExcuteThread = FALSE;

// CCameraDlg dialog
CCameraDlg::CCameraDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCameraDlg::IDD, pParent)
	, m_strTimer(_T(""))
	, m_dwAgingCount(0)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCameraDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BTN_START, m_ctlPreviewStart);
	DDX_Control(pDX, IDC_BTN_STOP, m_ctlPreviewStop);
	DDX_Control(pDX, IDC_BTN_CAPTURE, m_ctlCapture);
	DDX_Control(pDX, IDC_BTN_AUTOFOCUS, m_ctlAutoFocus);
	DDX_Control(pDX, IDC_BTN_MODE, m_ctlMode);
	DDX_Control(pDX, IDC_BTN_OPTION, m_ctlOption);
	DDX_Control(pDX, IDC_STATIC_TIMER, m_ctlStaticTimer);
	DDX_Text(pDX, IDC_STATIC_TIMER, m_strTimer);
	DDX_Control(pDX, IDC_STATIC_STANDBY, m_ctlStandby);
	DDX_Control(pDX, IDC_COMBO_ZOOM, m_ctlZoom);
	DDX_Text(pDX, IDC_STATIC_AGING_COUNT, m_dwAgingCount);
}

BEGIN_MESSAGE_MAP(CCameraDlg, CDialog)
#if defined(_DEVICE_RESOLUTION_AWARE) && !defined(WIN32_PLATFORM_WFSP)
	ON_WM_SIZE()
#endif
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BTN_FLASH_ON, &CCameraDlg::OnBnClickedBtnFlashOn)
	ON_BN_CLICKED(IDC_BTN_FLASH_OFF, &CCameraDlg::OnBnClickedBtnFlashOff)
	ON_BN_CLICKED(IDC_BTN_START, &CCameraDlg::OnBnClickedBtnStart)
	ON_BN_CLICKED(IDC_BTN_STOP, &CCameraDlg::OnBnClickedBtnStop)
	ON_BN_CLICKED(IDC_BTN_AUTOFOCUS, &CCameraDlg::OnBnClickedBtnAutofocus)
	ON_BN_CLICKED(IDC_BTN_MODE, &CCameraDlg::OnBnClickedBtnMode)
	ON_BN_CLICKED(IDC_BTN_CAPTURE, &CCameraDlg::OnBnClickedBtnCapture)
	ON_BN_CLICKED(IDC_BTN_OPTION, &CCameraDlg::OnBnClickedBtnOption)
	ON_CBN_SELCHANGE(IDC_COMBO_ZOOM, &CCameraDlg::OnCbnSelchangeComboZoom)
	ON_MESSAGE(WM_STATUS_AF, OnRecvAfMsg)
#ifdef AGING
	ON_MESSAGE(WM_STILL_VEIW_END, OnAging)
#endif
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_WM_ACTIVATE()
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()


#if defined(_DEVICE_RESOLUTION_AWARE) && !defined(WIN32_PLATFORM_WFSP)
void CCameraDlg::OnSize(UINT /*nType*/, int /*cx*/, int /*cy*/)
{
	if (AfxIsDRAEnabled())
	{
		DRA::RelayoutDialog(
			AfxGetResourceHandle(), 
			this->m_hWnd, 
			DRA::GetDisplayMode() != DRA::Portrait ? 
			MAKEINTRESOURCE(IDD_CAMERA_DIALOG_WIDE) : 
			MAKEINTRESOURCE(IDD_CAMERA_DIALOG));
	}
}
#endif






// CCameraDlg message handlers
BOOL CCameraDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	m_bScanEmul = FALSE;
	m_nDeviceType	= 0;
	m_nKeyPadType	= 0;
	m_nScannerType  = 0;
	m_nRightDownKey	= 0;
	m_nRightUpKey	= 0;
	memset(m_szSideKeyReg, 0x00, sizeof(TCHAR) * 1024);

	GetDeviceType();	

	m_bAutoPreview = TRUE;

	m_nAFType = AF_MANUAL;

	SetAFMode(m_nAFType);
	m_bAutoFocusing = FALSE;

#ifdef AGING
	GetDlgItem(IDC_STATIC_AGING_COUNT)->ShowWindow(SW_SHOW);
#else
	GetDlgItem(IDC_STATIC_AGING_COUNT)->ShowWindow(SW_HIDE);
#endif

	if(m_nDeviceType != DEVICE_MM3)	// MM3���� Zoom ������� [2009/7/16 14:32:19 JU]
	{
		RegistSideKey();
		m_ctlAutoFocus.ShowWindow(SW_SHOW);
	}

	//	SetWindowLong(this->m_hWnd,GWL_EXSTYLE,WS_SYSMENU);	 
	m_bWake = FALSE;				//	Camera unload ����
	m_bCaping = FALSE;				//	still ������
	m_bFlag = FALSE;

	m_cameramode = STILL_MODE;		//	still ���
	m_videotype  = VIDEO_ASF;		//	video ���� Ÿ��
	m_bVideoRun = FALSE;			//	video ������?
	m_bPreviewRun = TRUE;			//	OpenCamera ȣ��� �ڵ����� preview run
	m_bStillDateSaveMode = TRUE;	//	�Կ��� still �̹��� ���� �̸��� Date�� ����
	m_bVideoDateSaveMode = TRUE;	//	�Կ��� ������ ���� �̸��� Date�� ����

	if(!OpenCamera(this->m_hWnd,m_cameramode,m_videotype))
	{
		MessageBox(L"Camera open fail", L"Error", MB_OK);
		CDialog::OnCancel();
	}

	GetDlgItem(IDC_BTN_FLASH_ON)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_FLASH_OFF)->EnableWindow(TRUE);

	if(GetSystemMetrics (SM_CXSCREEN)>240)	//	VGA
		SetWindowPosition(80,90,320,240);				//	SetWindowPosition(1,2,477,352);



	//	m_strStillFolder = L"\\My Documents\\My Pictures\\";
	m_strStillFileName	= L"1.bmp";

	//	m_strVideoFolder = L"\\My Documents\\My Pictures\\";
	m_strVideoFileName = L"0.asf";


	TCHAR tcPath[MAX_PATH];
	SHGetSpecialFolderPath(m_hWnd, tcPath, CSIDL_MYPICTURES, false);
	m_strStillFolder.Format(L"%s\\", tcPath);
	m_strVideoFolder.Format(L"%s\\", tcPath);

	if(g_bOneExcuteThread == FALSE)
	{
		DWORD ThreadID;
		HANDLE hThread = CreateThread(NULL, 0, PwrMonThread, this, 0, &ThreadID);
		CloseHandle(hThread);
		g_bOneExcuteThread = TRUE;
	}

	SetForegroundWindow();

	return TRUE;  // return TRUE  unless you set the focus to a control
}



long CCameraDlg::OnRecvAfMsg(WPARAM wParam, LPARAM lParam)
{
	if(wParam == AF_STATUS_START)
	{
		::SetWindowText(::GetDlgItem(m_hWnd, IDC_STATIC_STATUS), L"Auto Focusing..");
		::EnableWindow(::GetDlgItem(m_hWnd, IDC_BTN_AUTOFOCUS), FALSE);
		m_bAutoFocusing = TRUE;
	}
	else if(wParam == AF_STATUS_FINISH)
	{
		::SetWindowText(::GetDlgItem(m_hWnd, IDC_STATIC_STATUS), L"Auto Focusing..OK");
		::EnableWindow(::GetDlgItem(m_hWnd, IDC_BTN_AUTOFOCUS), TRUE);
		m_bAutoFocusing = FALSE;
	}
	else
	{
		::SetWindowText(::GetDlgItem(m_hWnd, IDC_STATIC_STATUS), L"");
	}

	return 0;
}



void CCameraDlg::OnBnClickedBtnFlashOn()
{
	FlashOn(TRUE);
}

void CCameraDlg::OnBnClickedBtnFlashOff()
{
	FlashOn(FALSE);
}

void CCameraDlg::OnBnClickedBtnStart()
{
	if(PreviewStart())
	{
#ifdef AGING
		m_dwAgingCount = 0;
		UpdateData(FALSE);
#endif
		m_bPreviewRun = TRUE;
		m_ctlPreviewStart.EnableWindow(FALSE);
		m_ctlPreviewStop.EnableWindow(TRUE);
		m_ctlCapture.EnableWindow(TRUE);
		m_ctlOption.EnableWindow(FALSE);
		if(m_nAFType != AF_ALWAYS)
			m_ctlAutoFocus.EnableWindow(TRUE);
		GetDlgItem(IDC_BTN_FLASH_ON)->EnableWindow(TRUE);
		GetDlgItem(IDC_BTN_FLASH_OFF)->EnableWindow(TRUE);
//		this->SetFocus();
	}
	
}


void CCameraDlg::OnBnClickedBtnStop()
{
	if(PreviewStop())
	{
		m_bPreviewRun = FALSE;
		m_ctlPreviewStop.EnableWindow(FALSE);
		m_ctlPreviewStart.EnableWindow(TRUE);
		m_ctlOption.EnableWindow(TRUE);
		m_ctlCapture.EnableWindow(FALSE);
		m_ctlAutoFocus.EnableWindow(FALSE);

		GetDlgItem(IDC_BTN_FLASH_ON)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_FLASH_OFF)->EnableWindow(FALSE);

		FlashOn(FALSE);
	}
	
}


void CCameraDlg::OnCbnSelchangeComboBrightness()
{
	long value;
	value = (m_ctlBrightness.GetCurSel() -3) *-1;
	
	SetBrightness(value);
}

BOOL CCameraDlg::PreTranslateMessage(MSG* pMsg)
{

	if(((pMsg->message == WM_KEYDOWN) || (pMsg->message == WM_SYSKEYDOWN)) && ((pMsg->wParam == VK_KEYVALUE) || (pMsg->wParam == VK_RETURN)))
	{
		if((m_bWake == FALSE) && m_bPreviewRun)		// ��Ʈ �����ڸ� ����ϴ� �Ǽ��� �־��� ���� �������� �����Ͽ��� ���� ���� ������ �ٽ� Ȯ���ؾ���
		{
			if(!m_bFlag)
			{
				m_bFlag = TRUE;

				if(!m_bCaping)					//	ĸ���߿��� ���� [2011.1.18. 17:34:01 ParkHyunJu]
				{
					SetTimer(WM_TIMER_CAPTURE, 100, NULL);
				}

				// 101101 Timer�� ����, ĸ�� �� �ڵ� ������ ȭ�� ������ ���ؼ�

// 				DWORD ThreadID;
// 				HANDLE hThread = CreateThread(NULL, 0, Capture, this, 0, &ThreadID);
// 				CloseHandle(hThread);

 				// OnBnClickedBtnCapture();
			}
		}
		else
		{	
			if(!m_bCaping)
			{
				m_ctlStandby.ShowWindow(SW_HIDE);

				if(m_cameramode == STILL_MODE)
					m_cameramode = VIDEO_MODE;
				else
					m_cameramode = STILL_MODE;


				OnBnClickedBtnMode();

				m_bWake = FALSE;
				m_bCaping = FALSE;
			}
		}		
	}
	else 
	{
		if(((pMsg->message == WM_KEYUP) || (pMsg->message == WM_SYSKEYUP)) && ((pMsg->wParam == VK_KEYVALUE) || (pMsg->wParam == VK_RETURN)))
		{	
			m_bFlag = FALSE;
		}
	}

	if(((pMsg->message == WM_KEYDOWN) || (pMsg->message == WM_SYSKEYDOWN)) && ((pMsg->wParam == VK_RETURN)))
	{
		return TRUE;
	}

	if((pMsg->message == WM_KEYDOWN) && (pMsg->wParam == VK_F14) && (m_nScannerType == SCANNER_HHP))
	{
	
		BeginWaitCursor();
		m_bScanEmul = TRUE;

		Sleep(300);

		for(int i=0; i<3; i++)
		{
			CloseCamera();
			Sleep(300);
		}

// 		if(m_nDeviceType != DEVICE_MM3)
// 			UnRegistSideKey();

		::PostMessage(HWND_BROADCAST, WM_CONVERT, NULL, NULL);			

// 		TCHAR szScanEmulClass[100] = L"SCANEMUL";
// 
// 		HWND hFwnd = ::FindWindow(szScanEmulClass, L"");
// 		if(hFwnd)
// 		{
// 			::SendMessage(hFwnd, WM_CONVERT, NULL, NULL);	
// 			::PostMessage(HWND_BROADCAST, WM_CONVERT, NULL, NULL);			
// 		}	
		EndWaitCursor();

		CCameraDlg::OnCancel();
		return TRUE;			
	}

	return CDialog::PreTranslateMessage(pMsg);
}

void CCameraDlg::OnDestroy()
{
	CDialog::OnDestroy();

	while(TRUE == m_bCaping && TRUE == m_bWake)
	{
		Sleep(50);
	}

	DBG_OUTPUT("Destroy\r\n");

	if(m_bScanEmul == FALSE)
	{
		::PostMessage(HWND_BROADCAST, WM_CONVERT, NULL, NULL);			
		CloseCamera();
	}
	
	DBG_OUTPUT("Close\r\n");

	if(m_nDeviceType != DEVICE_MM3)
		UnRegistSideKey();
}

void CCameraDlg::OnBnClickedBtnAutofocus()
{
	if(m_bAutoFocusing)
		return;

	
 	if(!AutoFocus())
	{
		RETAILMSG(RT_MSG, (L"AF Fail\r\n"));
	}	

}

void CCameraDlg::OnBnClickedBtnMode()
{
	if(m_bCaping)
		return;

	if(VIDEO_MODE == m_cameramode)
	{
		m_cameramode = STILL_MODE;
		m_ctlMode.SetWindowText(L"Video Mode");
		m_ctlCapture.SetWindowText(L"Capture");
		m_ctlStaticTimer.ShowWindow(FALSE);
	}
	else
	{
		m_cameramode = VIDEO_MODE;
		m_ctlMode.SetWindowText(L"Still Mode");
		m_ctlCapture.SetWindowText(L"Video Start");
		m_ctlStaticTimer.ShowWindow(TRUE);
	}
	OpenCamera(this->m_hWnd,m_cameramode ,m_videotype );
	GetDlgItem(IDC_BTN_FLASH_ON)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_FLASH_OFF)->EnableWindow(TRUE);

	m_bVideoRun = FALSE;
	m_bPreviewRun = TRUE;
	m_ctlPreviewStart.EnableWindow(FALSE);
	m_ctlPreviewStop.EnableWindow(TRUE);
	m_ctlCapture.EnableWindow(TRUE);
	m_ctlOption.EnableWindow(FALSE);
	if(m_nAFType != AF_ALWAYS)
		m_ctlAutoFocus.EnableWindow(TRUE);
}

void CCameraDlg::OnBnClickedBtnCapture()
{
	if(!m_bCaping)
	{
		m_bCaping = TRUE;		// ī�޶�� �������� 

		DBG_OUTPUT("[CAM APP] OnBnClickedBtnCapture\r\n");
		
		if(!m_bPreviewRun)
		{
			MessageBox(L"Click Preview Start Button");
			return;
		}
		
		CString filefullname;
		TCHAR name[1024];

		GetDlgItem(IDC_BTN_FLASH_ON)->EnableWindow(FALSE);
		GetDlgItem(IDC_BTN_FLASH_OFF)->EnableWindow(FALSE);

		switch(m_cameramode)
		{
		case STILL_MODE :
			m_ctlCapture.EnableWindow(FALSE);
			m_ctlPreviewStop.EnableWindow(FALSE);
			m_ctlAutoFocus.EnableWindow(FALSE);


			if(m_bStillDateSaveMode)
			{
				TCHAR *Name;
				TCHAR *reName;
				Name = NULL;

				DBG_OUTPUT("[CAM APP] +call CaptureStill\r\n");

				reName = CaptureStillEx(Name, m_bAutoPreview);

				DBG_OUTPUT("[CAM APP] -call CaptureStill\r\n");

//////////////////////////////////////////////////////////////////////////
//	�޸� ���� ���� �߻��ϴ� ��찡 �־ viewer ���α׷��� ���� �ۼ��� [2010.12.24. 16:56:39 ParkHyunJu]					

				wcscpy(m_strViewImagePath, reName);
				if(!CreateProcessW(L"\\Flash Disk\\Camera\\M3Viewer.exe", m_strViewImagePath, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL))
				{
					CViewDlg dlg;
					dlg.m_strPath.Format(L"%s",m_strViewImagePath);
					dlg.DoModal();
				}


				::SetForegroundWindow(::FindWindow(NULL, L"M3Viewer"));
				
//	�޸� ���� ���� �߻��ϴ� ��찡 �־ viewer ���α׷��� ���� �ۼ��� [2010.12.24. 16:56:39 ParkHyunJu]				
//////////////////////////////////////////////////////////////////////////

#ifdef AGING
				++m_dwAgingCount;
				UpdateData(FALSE);

				PostMessage(WM_STILL_VEIW_END, NULL, NULL);
#endif				
			}
			else
			{
				filefullname = m_strStillFolder + m_strStillFileName;
				wcscpy(name,LPCTSTR(filefullname));


				CaptureStillEx(name, m_bAutoPreview);


				//////////////////////////////////////////////////////////////////////////						
				//	�޸� ���� ���� �߻��ϴ� ��찡 �־ viewer ���α׷��� ���� �ۼ��� [2010.12.24. 16:56:39 ParkHyunJu]				
				TCHAR	szThisProgram[MAX_PATH] = {0, }; // Camera Program
				CString szM3Viewr;

				GetModuleFileName(NULL, szThisProgram, sizeof(TCHAR)*MAX_PATH);
				szM3Viewr.Format(_T("%s"), szThisProgram);
				int nIndex = szM3Viewr.ReverseFind('\\');
				szM3Viewr.Format(_T("%s\\M3Viewer.exe"), szM3Viewr.Left(nIndex));

				wcscpy(m_strViewImagePath, name);
				if(!CreateProcessW(szM3Viewr, m_strViewImagePath, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL))
				{
					CViewDlg dlg;
					dlg.m_strPath.Format(L"%s", name);
					dlg.DoModal();

				}

				//	�޸� ���� ���� �߻��ϴ� ��찡 �־ viewer ���α׷��� ���� �ۼ��� [2010.12.24. 16:56:39 ParkHyunJu]				
				//////////////////////////////////////////////////////////////////////////						
			}

			m_ctlStaticTimer.ShowWindow(FALSE);
			
			// file full name : \My Documents\My Pictures\(DATE).jpg 		
			//CaptureStill(L"\\My Documents\\My Pictures\\11.jpg");
			m_bFlag = FALSE;
			m_bWake = TRUE;
//			m_bCaping = FALSE;
			
			if(m_bAutoPreview)
			{

				GetDlgItem(IDC_BTN_FLASH_ON)->EnableWindow(TRUE);
				GetDlgItem(IDC_BTN_FLASH_OFF)->EnableWindow(TRUE);

				m_bPreviewRun = TRUE;
				m_bWake = FALSE;

				m_ctlPreviewStart.EnableWindow(FALSE);
				m_ctlPreviewStop.EnableWindow(TRUE);
				m_ctlCapture.EnableWindow(TRUE);
				m_ctlOption.EnableWindow(FALSE);
				if(m_nAFType != AF_ALWAYS)
					m_ctlAutoFocus.EnableWindow(TRUE);
			}

			break;

		case VIDEO_MODE:
			if(!m_bVideoRun)
			{
				DBG_OUTPUT("[CAM APP] Video recode Start\r\n");

				m_ctlCapture.EnableWindow(FALSE);
				m_ctlPreviewStart.EnableWindow(FALSE);
				m_ctlPreviewStop.EnableWindow(FALSE);
				if(m_bVideoDateSaveMode)
				{
					VideoStart(0);	// file full name :\My Documents\My Pictures\\(DATE).wmv
				//VideoStart(L"My Documents\\aaa.wmv");
				}
				else
				{
					filefullname = m_strVideoFolder + m_strVideoFileName;
					wcscpy(name,LPCTSTR(filefullname));
					VideoStart(name);
				}
				SetTimer(WM_TIMER_VIDEO_TIME, 1000, 0);
				m_time =0;
				m_bVideoRun = TRUE;
				m_ctlCapture.SetWindowText(L"Video Stop");	
				m_bCaping = FALSE;
				m_bFlag = FALSE;					//		Flag  �����̿��� �߰��� [2011.1.17. 19:26:14 ParkHyunJu]
				m_ctlCapture.EnableWindow(TRUE);
			}
			else
			{
				m_ctlCapture.EnableWindow(FALSE);
				m_ctlPreviewStop.EnableWindow(FALSE);
				m_ctlAutoFocus.EnableWindow(FALSE);

				DBG_OUTPUT("[CAM APP] Video recode Stop\r\n");
				KillTimer(WM_TIMER_VIDEO_TIME);
				
				VideoStop();

// ��� �� [2011.1.18. 17:00:52 ParkHyunJu]				PreviewStop();

				CloseCamera();

				m_bWake = TRUE;
				m_bFlag = FALSE;					//		Flag  �����̿��� �߰��� [2011.1.17. 19:26:14 ParkHyunJu]
				m_strTimer.Format(L"00:00");
			}
			UpdateData(FALSE);
			break;

		default:
			MessageBox(L"No Capture check code");
			
		}
//		this->SetFocus();
		m_bCaping = FALSE;
	}
	m_ctlStandby.ShowWindow(SW_SHOW);
	::SetFocus(m_ctlStandby.m_hWnd);

	// �޸� ������ ����Ų��.
	// JJ 101214
// 	if(m_bAutoPreview)
// 	{
// 
// 		if(m_bWake)
// 		{
// 			m_ctlStandby.ShowWindow(SW_HIDE);
// 
// 			if(m_cameramode == STILL_MODE)
// 				m_cameramode = VIDEO_MODE;
// 			else
// 				m_cameramode = STILL_MODE;
// 
// 			OnBnClickedBtnMode();
// 			m_bCaping = FALSE;
// 		}
// 		m_bWake = FALSE;
//  	}

	//////////////////////////////////////////////////////////////////////////
	//  �޼��� �����Ǵ°��� �������ؼ� �޼����� ������	[2011.1.17. 14:10:45 ParkHyunJu]	
	MSG msg;	
	int count = 0;

	while(count++ < 500)
	{			
		if(::PeekMessage(&msg, NULL, WM_KEYDOWN, WM_SYSKEYUP, PM_REMOVE))
		{
			if(((msg.message == WM_KEYDOWN) || (msg.message == WM_SYSKEYDOWN) ||(msg.message == WM_KEYUP) || (msg.message == WM_SYSKEYUP))
				&& ((msg.wParam == VK_KEYVALUE) || (msg.wParam == VK_RETURN) || (msg.wParam == VK_F23)))		//	KeyValue (VK_F23�� AcitionKey)
			{
				DBG_OUTPUT("[CAM APP] WM_KEYDOWN WM_SYSKEYDOWN WM_KEYUP WM_SYSKEYUP r\n");

				continue;
			}
			else
			{
				::PostMessage(m_hWnd, msg.message, msg.wParam, msg.lParam);
			}
		}
		else
		{
			break;
		}
	}
	//  �޼��� �����Ǵ°��� �������ؼ� �޼����� ������	[2011.1.17. 14:10:45 ParkHyunJu]
	//////////////////////////////////////////////////////////////////////////


}

void CCameraDlg::OnBnClickedBtnOption()
{
	COptionDlg dlg;

	// Add JJ 20110104
	dlg.m_nDeviceType = m_nDeviceType;


	if(m_cameramode == STILL_MODE)
	{
		dlg.m_bVideo	= FALSE;
		dlg.m_strFolder = this->m_strStillFolder;
		dlg.m_strFileName = this->m_strStillFileName;
		dlg.m_bDateSaveMode = this->m_bStillDateSaveMode;
		dlg.m_bAutoPreview = m_bAutoPreview;
		dlg.m_nAFType = m_nAFType;
	}
	else
	{
		dlg.m_videotype = this->m_videotype;
		dlg.m_bVideo	= TRUE;
		dlg.m_strFolder = this->m_strVideoFolder;
		dlg.m_strFileName = this->m_strVideoFileName;
		dlg.m_bDateSaveMode = this->m_bVideoDateSaveMode;
	}
	
	if(dlg.DoModal() == IDOK)
	{
		if(m_cameramode == STILL_MODE)
		{
			this->m_strStillFolder = dlg.m_strFolder;
			this->m_strStillFileName = dlg.m_strFileName;
			this->m_bStillDateSaveMode = dlg.m_bDateSaveMode;
			this->m_bAutoPreview = dlg.m_bAutoPreview;

			this->m_nAFType = dlg.m_nAFType;
		}
		else
		{
			this->m_videotype = dlg.m_videotype;
			this->m_strVideoFolder = dlg.m_strFolder;
			this->m_strVideoFileName = dlg.m_strFileName;
			this->m_bVideoDateSaveMode = dlg.m_bDateSaveMode;

			// AF ����� �Ŵ���� ����
			this->m_nAFType = AF_MANUAL;
		}
		
		if(m_bWake)
		{
			m_ctlStandby.ShowWindow(SW_HIDE);
		}

		OpenCamera(this->m_hWnd, m_cameramode, m_videotype);
		GetDlgItem(IDC_BTN_FLASH_ON)->EnableWindow(TRUE);
		GetDlgItem(IDC_BTN_FLASH_OFF)->EnableWindow(TRUE);

		m_bPreviewRun = TRUE;
		m_ctlPreviewStart.EnableWindow(FALSE);
		m_ctlPreviewStop.EnableWindow(TRUE);
		m_ctlCapture.EnableWindow(TRUE);
		m_ctlOption.EnableWindow(FALSE);

		if(m_nAFType != AF_ALWAYS)
			m_ctlAutoFocus.EnableWindow(TRUE);
	}
}

void CCameraDlg::OnTimer(UINT_PTR nIDEvent)
{
	int minute;
	int second;

	switch(nIDEvent)
	{
#ifdef AGING
		case STILL_TIMER_ID:
			KillTimer(STILL_TIMER_ID);
			OnBnClickedBtnCapture();
			break;
#endif

		case WM_TIMER_CAPTURE:
			KillTimer(WM_TIMER_CAPTURE);
			OnBnClickedBtnCapture();
			
			break;
		case 100:
			KillTimer(100);
			::SetFocus(::GetDlgItem(m_hWnd, IDC_BTN_FLASH_OFF));
			break;
		case WM_TIMER_VIDEO_TIME:
			m_time++;
			
			minute = m_time /60;
			second = m_time %60;

			m_strTimer.Format(L"%02d:%02d",minute, second);
			UpdateData(FALSE);

			break;
		case 1002:
			m_ctlCapture.SetFocus();

	}


	
	CDialog::OnTimer(nIDEvent);
}


void CCameraDlg::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized)
{
	CDialog::OnActivate(nState, pWndOther, bMinimized);
}


DWORD WINAPI PwrMonThread(LPVOID pParam)
{
	HANDLE hNotifications;
	HANDLE hReadMsgQ;
	MSGQUEUEOPTIONS msgOptions = {0};


	CCameraDlg * dlg = (CCameraDlg *)(pParam);


	/*
	//RETAILMSG(1, (TEXT("[+++PWM: PwrMonThread] \r\n")));
	while(!IsAPIReady(SH_SHELL) || !IsAPIReady(SH_WMGR) || !IsAPIReady(SH_GDI))
	{
	Sleep(250);
	}
	*/

	//    CeSetThreadPriority(GetCurrentThread(), 95);

	//RETAILMSG(1, (TEXT("[PWM: PwrMonThread] Test Point1 \r\n")));
	// Create a message queue for Power Manager notifications.
	msgOptions.dwSize        = sizeof(MSGQUEUEOPTIONS);
	msgOptions.dwFlags       = 0;
	msgOptions.dwMaxMessages = 10;//QUEUE_ENTRIES;
	msgOptions.cbMaxMessage  = sizeof(POWER_BROADCAST) + MAX_NAMELEN;
	msgOptions.bReadAccess   = TRUE;

	hReadMsgQ = CreateMsgQueue(NULL, &msgOptions);
	if ( hReadMsgQ == NULL )
	{
		DEBUGMSG(1, (TEXT("PWM: CreateMsgQueue(Read): error %d\r\n"), GetLastError()));
		//		g_FlagExitThrd = TRUE;
	}

	// Request Power notifications
	hNotifications = RequestPowerNotifications(hReadMsgQ, POWER_NOTIFY_ALL);
	if ( ! hNotifications ) 
	{
		DEBUGMSG(1, (TEXT("PWM: RequestPowerNotifications: error %d\r\n"), GetLastError()));
		//		g_FlagExitThrd = TRUE;
	}

	//    RETAILMSG(1, (TEXT("[PWM: PwrMonThread] Test Point2 \r\n")));
	while(g_bOneExcuteThread)
	{
		DWORD   iBytesInQueue = 0;//int   iBytesInQueue = 0;
		DWORD dwFlags;
		UCHAR buf[QUEUE_SIZE];
		PPOWER_BROADCAST pB = (PPOWER_BROADCAST) buf;

		memset(buf, 0, QUEUE_SIZE);

		DEBUGMSG(1, (TEXT("PWM: Waiting for PM state transition notification\r\n")));

		// Read message from queue.
		if ( ! ReadMsgQueue(hReadMsgQ, buf, QUEUE_SIZE, &iBytesInQueue, INFINITE, &dwFlags) )
		{
			DEBUGMSG(1, (TEXT("PWM: ReadMsgQueue: ERROR:%d\r\n"), GetLastError()));
		} 
		else if ( iBytesInQueue < sizeof(POWER_BROADCAST) )
		{
			RETAILMSG(1, (TEXT("PWM: Received short message: %d bytes, expected: %d\r\n"),
				iBytesInQueue, sizeof(POWER_BROADCAST)));
		}
		else 
		{
			switch ( pB->Message )
			{
			case PBT_TRANSITION:

				// 				RETAILMSG(0, (TEXT("PWM: PBT_TRANSITION to system power state [Flags: 0x%x]: '%s'\r\n"),
				// 					pB->Flags, pB->SystemPowerState));

				switch ( POWER_STATE(pB->Flags) )
				{
				case POWER_STATE_ON:
					DBG_OUTPUT("************* POWER_STATE_ON*************\r\n");
					break;

				case POWER_STATE_OFF:
					DBG_OUTPUT("*************POWER_STATE_OFF*************\r\n");
					break;

				case POWER_STATE_CRITICAL:
					DBG_OUTPUT("*************POWER_STATE_CRITICAL*************\r\n");
					break;

				case POWER_STATE_BOOT:
					DBG_OUTPUT("*************POWER_STATE_BOOT*************\r\n");
					break;

				case POWER_STATE_IDLE:
					DBG_OUTPUT("*************POWER_STATE_IDLE*************\r\n");
					break;

				case POWER_STATE_SUSPEND:
					{


						DBG_OUTPUT("*************POWER_STATE_SUSPEND\r\n***************");
/*
						dlg->m_bWake = TRUE;
						Sleep(1000);
						CloseCamera();

						dlg->m_bFlag = FALSE;						
*/
					}

					break;

				case POWER_STATE_RESET:
					DBG_OUTPUT("*************POWER_STATE_RESET*************\r\n");
					break;

				case POWER_STATE_PASSWORD:
					DBG_OUTPUT("*************POWER_STATE_PASSWORD*************\r\n");
					break;

				case 0:
					DBG_OUTPUT1("*************Power State Flags:0x%x*************\r\n",pB->Flags);
					break;

				default:
					DBG_OUTPUT1("*************Unknown Power State Flags:0x%x*************\r\n",pB->Flags);
					break;
				}
				break;

			case PBT_SUSPENDKEYPRESSED:
				{
					DBG_OUTPUT("**********PBT_SUSPENDKEYPRESSED***************\r\n");

					break;
				}

			case PBT_RESUME:
				{

					DBG_OUTPUT("**********POWER_STATE_RESUME***************\r\n");

					dlg->m_bCaping = TRUE;	
					dlg->m_ctlPreviewStart.EnableWindow(FALSE);
					dlg->m_ctlOption.EnableWindow(FALSE);
					if(dlg->m_bPreviewRun)
					{
						dlg->m_ctlCapture.EnableWindow(FALSE);
						dlg->m_ctlPreviewStop.EnableWindow(FALSE);
						dlg->m_ctlAutoFocus.EnableWindow(FALSE);

						dlg->GetDlgItem(IDC_BTN_FLASH_ON)->EnableWindow(FALSE);
						dlg->GetDlgItem(IDC_BTN_FLASH_OFF)->EnableWindow(FALSE);
					}

					if(dlg->m_bVideoRun)
					{
						dlg->KillTimer(WM_TIMER_VIDEO_TIME);
						dlg->m_strTimer.Format(L"00:00");
						dlg->m_ctlCapture.SetWindowText(L"Video Start");
						dlg->m_ctlPreviewStop.EnableWindow(FALSE);
						dlg->m_bVideoRun = FALSE;
						dlg->m_bCaping = FALSE;
						dlg->UpdateData(FALSE);

//						dlg->m_ctlCapture.EnableWindow(FALSE);
//						VideoStop();
					}


					CloseCamera();
					dlg->m_bCaping = FALSE;
					dlg->m_bFlag = FALSE;
					dlg->m_bWake = TRUE;
					dlg->m_ctlStandby.ShowWindow(SW_SHOW);

					dlg->SetTimer(100, 10, NULL);
					break;
				}       
			case PBT_POWERSTATUSCHANGE:
				DBG_OUTPUT("**********PBT_POWERSTATUSCHANGE***************\r\n");
				break;

			case PBT_POWERINFOCHANGE:
				DBG_OUTPUT("**********PBT_POWERINFOCHANGE***************\r\n");
				break;

			default:
				break;
			}
		}
	}

	if ( hNotifications )
	{
		StopPowerNotifications(hNotifications);
		hNotifications = NULL;
	}

	if ( hReadMsgQ )
	{
		CloseMsgQueue(hReadMsgQ);
		hReadMsgQ = NULL;
	}

	RETAILMSG(1, (TEXT("[--PwrMonThread]\r\n")));
	return 0;
}

void CCameraDlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	if(m_bWake)
	{
		DBG_OUTPUT("[CAM APP]LButtonDown\r\n");
		m_ctlStandby.ShowWindow(SW_HIDE);

		if(m_cameramode == STILL_MODE)
			m_cameramode = VIDEO_MODE;
		else
			m_cameramode = STILL_MODE;
		
		OnBnClickedBtnMode();
		m_bCaping = FALSE;
	}
	m_bWake = FALSE;

	CDialog::OnLButtonDown(nFlags, point);
}

DWORD  WINAPI Capture(LPVOID pParma)
{
	DBG_OUTPUT("[CAM APP] +Thread capture\r\n");
	CCameraDlg * dlg = ((CCameraDlg *)(pParma));
	dlg->OnBnClickedBtnCapture();
// 	dlg->m_bFlag = FALSE;

//	���� ���� �Կ� ���� �Կ� ���� �ΰ��� ����̹Ƿ� 
//	����ũ���� �Կ� ���� ��ġ�� ���������� ��ġ�� ������
//	dlg->m_bWake = TRUE;

 	dlg->m_ctlStandby.ShowWindow(SW_SHOW);
	DBG_OUTPUT("[CAM APP] -Thread capture\r\n");
//	::SetFocus(dlg->m_ctlStandby.m_hWnd);

	return 0;
}





BOOL CCameraDlg::RegistSideKey()
{
	m_nRightUpKey = m_Reg.GetRegValue(HKEY_LOCAL_MACHINE, m_szSideKeyReg, L"RightUpKey");
	m_Reg.SetRegValue(HKEY_LOCAL_MACHINE, m_szSideKeyReg, L"RightUpKey", 2);

	m_nRightDownKey = m_Reg.GetRegValue(HKEY_LOCAL_MACHINE, m_szSideKeyReg, L"RightDownKey");
	m_Reg.SetRegValue(HKEY_LOCAL_MACHINE, m_szSideKeyReg, L"RightDownKey", 3);

	return TRUE;

}

BOOL CCameraDlg::UnRegistSideKey()
{
	m_Reg.SetRegValue(HKEY_LOCAL_MACHINE, m_szSideKeyReg, L"RightUpKey", m_nRightUpKey);
	m_Reg.SetRegValue(HKEY_LOCAL_MACHINE, m_szSideKeyReg, L"RightDownKey", m_nRightDownKey);

	return TRUE;
}


void CCameraDlg::GetDeviceType()
{
	//////////////////////////////////////////////////////////////////////////
	// Device
	TCHAR szModel[33]= {0, };	
	SystemParametersInfo(SPI_GETOEMINFO, 64, szModel, SPIF_SENDCHANGE);

	if(wcscmp(szModel, L"MM3") == 0)
	{
		m_nDeviceType = DEVICE_MM3;
	}
	else if((wcscmp(szModel, L"M3ORANGE") == 0) || (wcscmp(szModel, L"MC7101") == 0) || (wcscmp(szModel, L"MC7X01") == 0))
	{		
		m_nDeviceType	= DEVICE_M3ORANGE;	
		m_nKeyPadType	= m_Reg.GetRegValue(HKEY_LOCAL_MACHINE, L"ControlPanel\\keypad", L"KeypadType");
	}
	else
	{
		m_nDeviceType = DEVICE_M3SKY;
	}
	//////////////////////////////////////////////////////////////////////////
	if(m_nDeviceType == DEVICE_M3ORANGE)	// M3SKY Summint & M3ORANGE
	{
		if(m_nKeyPadType == KEYPAD_QWERTY)
			wsprintf(m_szSideKeyReg, L"ControlPanel\\Keypad\\Qwerty");
		else
			wsprintf(m_szSideKeyReg, L"ControlPanel\\Keypad\\Numeric");
	}
	else
		wsprintf(m_szSideKeyReg, L"ControlPanel\\Keypad\\SideKey");

	//////////////////////////////////////////////////////////////////////////

	// Scanner
	m_nScannerType = m_Reg.GetRegValue(HKEY_CURRENT_USER,L"MCSetting\\Hardware", L"Scanner");
}

void CCameraDlg::OnCbnSelchangeComboZoom()
{
	Zoom(m_ctlZoom.GetCurSel());
}

#ifdef AGING
LRESULT CCameraDlg::OnAging(WPARAM wParam, LPARAM lParam)
{

	SetTimer(STILL_TIMER_ID, STILL_TIMER_DELAY, NULL);

	return TRUE;
}
#endif
