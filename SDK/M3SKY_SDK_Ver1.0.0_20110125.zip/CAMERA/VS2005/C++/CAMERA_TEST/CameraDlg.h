// CameraDlg.h : header file
//

#pragma once
#include "afxwin.h"
#include "M3SkyCamera.h"
#include "Reg.h"


// CCameraDlg dialog
class CCameraDlg : public CDialog
{
// Construction
public:
	CCameraDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_CAMERA_DIALOG };


	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
#if defined(_DEVICE_RESOLUTION_AWARE) && !defined(WIN32_PLATFORM_WFSP)
	afx_msg void OnSize(UINT /*nType*/, int /*cx*/, int /*cy*/);
#endif
	DECLARE_MESSAGE_MAP()
public:
	CReg		m_Reg;
	CComboBox	m_ctlZoom;
	CComboBox	m_ctlBrightness;
	CButton		m_ctlPreviewStart;
	CButton		m_ctlPreviewStop;
	CButton		m_ctlCapture;
	CButton		m_ctlAutoFocus;
	CButton		m_ctlMode;
	CButton		m_ctlOption;
	CStatic		m_ctlStaticTimer;
	CStatic		m_ctlStandby;
	CString		m_strTimer;
	

	afx_msg void OnBnClickedBtnFlashOn();
	afx_msg void OnBnClickedBtnFlashOff();
	afx_msg void OnBnClickedBtnStart();
	afx_msg void OnBnClickedBtnStop();
	afx_msg void OnBnClickedBtnMode();
	afx_msg void OnBnClickedBtnCapture();
	afx_msg void OnBnClickedBtnOption();
	afx_msg void OnCbnSelchangeComboBrightness();
	afx_msg void OnBnClickedBtnAutofocus();
	afx_msg void OnCbnSelchangeComboZoom();
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT_PTR nIDEvent);	
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	long OnRecvAfMsg(WPARAM wParam, LPARAM lParam);

	LRESULT OnAging(WPARAM wParam, LPARAM lParam);
	

	LRESULT OnAutoPreview(WPARAM wParam, LPARAM lParam);

public:
	CAMERA_MODE	m_cameramode;
	VIDEO_TYPE	m_videotype;

	BOOL		m_bWake;			//  ����ũ�� �ߴ��� ? 
	BOOL		m_bCaping;			//  still or recoding ���ΰ�?
	BOOL		m_bFlag;

	BOOL		m_bVideoRun;
	BOOL		m_bPreviewRun;
	BOOL		m_bAutoPreview;
	int			m_nAFType;
	BOOL		m_bAutoFocusing;

private:
	DWORD		m_dwButtonValue;
	BOOL		m_bStillDateSaveMode;
	BOOL		m_bVideoDateSaveMode;
	ULONG		m_time;

	CString		m_strStillFolder;
	CString		m_strStillFileName;
	CString		m_strVideoFolder;
	CString		m_strVideoFileName;

//	BOOL		m_bMM3Device;


	BOOL RegistSideKey();
	BOOL UnRegistSideKey();
	void GetDeviceType();
public:
	DWORD m_dwAgingCount;


	BOOL		m_bScanEmul;
	
	int			m_nDeviceType;
	int			m_nKeyPadType;
	int			m_nScannerType;
	
	int			m_nRightDownKey;
	int			m_nRightUpKey;
	
	TCHAR		m_szSideKeyReg[1024];

	TCHAR m_strViewImagePath[MAX_PATH];

};
