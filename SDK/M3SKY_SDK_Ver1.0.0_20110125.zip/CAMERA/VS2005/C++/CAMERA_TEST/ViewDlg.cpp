// ViewDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Camera.h"
#include "ViewDlg.h"

//	�̹��� ����
#include <initguid.h>
#include <imaging.h>

//#define DBG_OUT 
#ifdef DBG_OUT
#define DBG_OUTPUT(a);				NKDbgPrintfW(TEXT(a));
#define DBG_OUTPUT1(a,b);			NKDbgPrintfW(TEXT(a),b);
#define DBG_OUTPUT2(a,b,c);			NKDbgPrintfW(TEXT(a),b,c);
#define DBG_OUTPUT3(a,b,c,d);		NKDbgPrintfW(TEXT(a),b,c,d);
#define DBG_OUTPUT4(a,b,c,d,e);		NKDbgPrintfW(TEXT(a),b,c,d,e);
#define DBG_OUTPUT5(a,b,c,d,e,f);	NKDbgPrintfW(TEXT(a),b,c,d,e,f);
#define DBG_OUTPUT6(a,b,c,d,e,f,g);	NKDbgPrintfW(TEXT(a),b,c,d,e,f,g);
#else
#define DBG_OUTPUT(a);
#define DBG_OUTPUT1(a,b);
#define DBG_OUTPUT2(a,b,c);
#define DBG_OUTPUT3(a,b,c,d);
#define DBG_OUTPUT4(a,b,c,d,e);
#define DBG_OUTPUT5(a,b,c,d,e,f);
#define DBG_OUTPUT6(a,b,c,d,e,f,g);
#endif










DWORD WINAPI ViewThread(LPVOID pParam);

//#pragma comment (lib, "ole32.lib")
// CViewDlg dialog

IMPLEMENT_DYNAMIC(CViewDlg, CDialog)

CViewDlg::CViewDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CViewDlg::IDD, pParent)
{

}

CViewDlg::~CViewDlg()
{

}

void CViewDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_IMAGE, m_Static_Image);
}


BEGIN_MESSAGE_MAP(CViewDlg, CDialog)
END_MESSAGE_MAP()


// CViewDlg message handlers

BOOL CViewDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here
	SetForegroundWindow();
	m_bThreading = FALSE;

	DWORD ThreadID;
	HANDLE hThread = CreateThread(NULL, 0, ViewThread, this, 0, &ThreadID);
	CloseHandle(hThread);
	

//	Sleep(1400);

	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

DWORD WINAPI ViewThread(LPVOID pParam)
{
	
	DBG_OUTPUT("+ViewThread");
	CViewDlg * dlg = (CViewDlg *)pParam;

	dlg->m_bThreading = TRUE;

	Sleep(60);
	DBG_OUTPUT("+Show");
	dlg->Show();
	Sleep(2000);
	DBG_OUTPUT("-Show");
		
	dlg->SendMessage(WM_CLOSE);
	DBG_OUTPUT("-ViewThread");

	dlg->m_bThreading = FALSE;
	return TRUE;
}

void CViewDlg::Show()
{
	RECT				rect;
	HRESULT				hr;
	CDC					*m_hWndDC;
	HDC					m_hDCmem;

	IImage				*m_pImage;
	IImagingFactory		*m_pImagingFactory;


	m_hWndDC = m_Static_Image.GetDC();
	m_Static_Image.GetClientRect(&rect);


	m_hDCmem = CreateCompatibleDC( m_hWndDC->m_hDC );

	m_pImage = NULL;
	m_pImagingFactory = NULL;

	hr = CoCreateInstance(CLSID_ImagingFactory, NULL, CLSCTX_INPROC_SERVER, IID_IImagingFactory, (void**) &m_pImagingFactory);

	if (FAILED(hr)) 
		goto finish;

	hr = m_pImagingFactory->CreateImageFromFile(m_strPath, &m_pImage);

	if (FAILED(hr) || m_pImage == NULL)   
		goto finish;

	hr = m_pImage->Draw(m_hWndDC->m_hDC, &rect, NULL);

	if(hr != S_OK)
		MessageBox(L"error");

finish:

	if (m_pImage)                 
		m_pImage->Release();

	if (m_pImagingFactory)    
		m_pImagingFactory->Release();

	DeleteDC(m_hDCmem);

	m_Static_Image.ReleaseDC( m_hWndDC );
}

void CViewDlg::OnOK()
{

}
