﻿Imports System.Runtime.InteropServices
Imports System.Text

Public Class ClassCamera

    Private Declare Function SHSetAppKeyWndAssoc Lib "aygshell.dll" _
    (ByVal bVk As Byte, ByVal hMainWnd As IntPtr) _
    As Boolean

    Private Declare Function OpenCamera Lib "M3SkyCamera.dll" _
    (ByVal hMainWnd As IntPtr, ByVal cameramode As CAMERA_MODE, ByVal videotype As VIDEO_TYPE) _
    As Boolean

    Private Declare Sub CloseCamera Lib "M3SkyCamera.dll" ()

    Private Declare Function SetWindowPosition Lib "M3SkyCamera.dll" _
    (ByVal left As Integer, ByVal top As Integer, ByVal width As Integer, ByVal height As Integer) _
    As Boolean

    Private Declare Function PreviewStart Lib "M3SkyCamera.dll" _
    () As Boolean

    Private Declare Function PreviewStop Lib "M3SkyCamera.dll" _
    () As Boolean

    Private Declare Function VideoStart Lib "M3SkyCamera.dll" _
    (ByVal FileFULLName As String) As Boolean

    Private Declare Function VideoStop Lib "M3SkyCamera.dll" _
    () As Boolean

    Private Declare Function CaptureStill Lib "M3SkyCamera.dll" _
    (ByVal FileFULLName As String) As String

    Private Declare Sub captureStill Lib "M3SkyCamera.dll" _
    (ByVal FileFULLName As String, ByVal strInfo As StringBuilder)

    Private Declare Function FlashOn Lib "M3SkyCamera.dll" _
    (ByVal bOn As Boolean) As Boolean

    Private Declare Function SetResolution Lib "M3SkyCamera.dll" _
    (ByVal PinType As Integer, ByVal nResolution As Integer) As Boolean

    Private Declare Function SetBrightness Lib "M3SkyCamera.dll" _
    (ByVal lValue As Long) As Boolean

    Private Declare Function SetWhiteBalance Lib "M3SkyCamera.dll" _
    (ByVal lValue As Long) As Boolean

    Private Declare Function AutoFocus Lib "M3SkyCamera.dll" _
    () As Boolean

    Private Declare Function GetResolution Lib "M3SkyCamera.dll" _
    (ByVal PinType As Integer) As Integer

    Private Declare Function GetBrightness Lib "M3SkyCamera.dll" _
    () As Integer

    Private Declare Function GetWhiteBalance Lib "M3SkyCamera.dll" _
    () As Integer

    Private Declare Function GetInfo Lib "M3SkyCamera.dll" _
    () As String

    Private Declare Sub getInfo Lib "M3SkyCamera.dll" _
    (ByVal strInfo As StringBuilder)
    'getInfo는 버전정보를 얻어오는 것이기 때문에 ByVal을 ByRef로 변경함

    Private Declare Sub getInfoEx Lib "M3SkyCamera.dll" _
    (ByVal strInfo As StringBuilder)




    Private Declare Sub SetQuality Lib "M3SkyCamera.dll" _
    (ByVal nValue As Integer)

    Private Declare Function GetQuality Lib "M3SkyCamera.dll" _
    () As Integer

    Private Declare Function GetHisto Lib "M3SkyCamera.dll" _
    (ByRef pbHistoEqual As Boolean) As Boolean

    Private Declare Function GetNightLevel Lib "M3SkyCamera.dll" _
    (ByRef pNightLevel As Integer) As Boolean

    Private Declare Sub EnableHistoEqual Lib "M3SkyCamera.dll" _
    (ByVal bEnable As Boolean, ByVal NightLevel As Integer)

    Public Function GetHistogram(ByRef pbHisto As Boolean) As Boolean
        Return GetHisto(pbHisto)
    End Function

    Public Function GetNight(ByRef pNight As Integer) As Boolean
        Return GetNightLevel(pNight)
    End Function

    Public Sub EnableHisto(ByVal HistoEqul As Boolean, ByVal NightLevel As Integer)
        EnableHistoEqual(HistoEqul, NightLevel)
    End Sub

    Public Function SHSetAppKey(ByVal bVk As Byte, ByVal hMainWnd As IntPtr) As Boolean
        Return SHSetAppKeyWndAssoc(bVk, hMainWnd)
    End Function

    Public Function SetAutoFocus() As Boolean
        Return AutoFocus()
    End Function

    Public Function Open(ByVal hMainWnd As IntPtr, ByVal cameramode As CAMERA_MODE, ByVal videotype As VIDEO_TYPE) As Boolean
        Return OpenCamera(hMainWnd, cameramode, videotype)
    End Function

    Public Shared Sub Close()
        CloseCamera()
    End Sub

    Public Function SetPosition(ByVal left As Integer, ByVal top As Integer, ByVal width As Integer, ByVal height As Integer) As Boolean
        Return SetWindowPosition(left, top, width, height)
    End Function

    Public Function Preview_Start() As Boolean
        Return PreviewStart()
    End Function

    Public Function Preview_Stop() As Boolean
        Return PreviewStop()
    End Function

    Public Function Video_Start(ByVal FileFullName As String) As Boolean
        Return VideoStart(FileFullName)
    End Function

    Public Function Video_Stop() As Boolean
        Return VideoStop()
    End Function

    Public Function Capture(ByVal FileFullName As String) As String
        Return CaptureStill(FileFullName)
    End Function

    Public Sub Capture(ByVal FileFullName As String, ByVal info As StringBuilder)
        CaptureStill(FileFullName, info)
    End Sub

    Public Function Flash_On(ByVal bOn As Boolean) As Boolean
        Return FlashOn(bOn)
    End Function

    Public Function Get_Resolution(ByVal PinType As Integer) As Integer
        Return GetResolution(PinType)
    End Function

    Public Function Set_Resolution(ByVal PinType As Integer, ByVal nResolution As Integer) As Boolean
        Return SetResolution(PinType, nResolution)
    End Function

    Public Function Get_Brightness() As Integer
        Return GetBrightness()
    End Function

    Public Function Set_Brightness(ByVal lValue As Long) As Boolean
        Return SetBrightness(lValue)
    End Function

    Public Function Get_WhiteBalance() As Integer
        Return GetWhiteBalance()
    End Function

    Public Function Set_WhiteBalance(ByVal lValue As Long) As Boolean
        Return SetWhiteBalance(lValue)
    End Function

    Public Function Get_Info() As String
        Return GetInfo()
    End Function

    Public Sub Get_Info(ByVal info As StringBuilder)
        GetInfo(info)
    End Sub

    Public Sub Get_InfoEx(ByVal info As StringBuilder)
        GetInfoEx(info)
    End Sub
    Public Sub Set_Quality(ByVal nValue As Integer)
        SetQuality(nValue)
    End Sub

    Public Function Get_Quality() As Integer
        Return GetQuality()
    End Function
End Class
