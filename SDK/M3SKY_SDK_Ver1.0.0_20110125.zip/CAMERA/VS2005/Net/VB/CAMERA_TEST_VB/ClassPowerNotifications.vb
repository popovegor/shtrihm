﻿Imports System.Runtime.InteropServices
Imports System.Text
Imports System.Threading

Public Class ClassPowerNotifications
    Private hWnd As IntPtr
    Private ptr As IntPtr = IntPtr.Zero
    Private t As Thread
    Private done As Boolean = False

    Public Const WM_USER As Integer = &H400
    Public Const WM_CALLBACK_MESSAGE As Integer = WM_USER + 144

    Public stanby As System.Windows.Forms.Label

    ' MsgQ option
    Public Structure MsgQOptions
        '참조되지않아서 주석처리        Public dwSize As UInteger
        '참조되지않아서 주석처리       Public dwFlags As UInteger
        '참조되지않아서 주석처리        Public dwMaxMessages As UInteger
        '참조되지않아서 주석처리        Public cbMaxMessage As UInteger
        Public bReadAccess As Boolean
    End Structure

    Private Declare Function SendMessage Lib "coredll.dll" _
    (ByVal Hwnd As IntPtr, ByVal Msg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) _
    As Integer

    Private Declare Function RequestPowerNotifications Lib "coredll.dll" _
    (ByVal hMsgQ As IntPtr, ByVal Flags As Long) _
    As IntPtr

    Private Declare Function WaitForSingleObject Lib "coredll.dll" _
    (ByVal hHandle As IntPtr, ByVal wait As Integer) As UInt32

    Private Declare Function CreateMsgQueue Lib "coredll.dll" _
    (ByVal name As String, ByRef qoption As MsgQOptions) As IntPtr

    Private Declare Function ReadMsgQueue Lib "coredll.dll" _
    (ByVal msgqueue As IntPtr, ByVal lpBuffer() As Byte, ByVal bufsize As UInteger, ByRef numRead As UInteger, ByVal timeout As Integer, ByRef flags As UInteger) _
    As Boolean

    Public Sub New(ByVal handle As IntPtr)
        Dim options As MsgQOptions = New MsgQOptions()
        '참조되지않아서 주석처리        options.dwFlags = 0
        '참조되지않아서 주석처리       options.dwMaxMessages = 20
        '참조되지않아서 주석처리        options.cbMaxMessage = 10000
        options.bReadAccess = True
        '참조되지않아서 주석처리        options.dwSize = System.Runtime.InteropServices.Marshal.SizeOf(options)

        ptr = CreateMsgQueue("Test", options)
        RequestPowerNotifications(ptr, &HFFFFFFFF)
        t = New Thread(AddressOf DoWork)
        hWnd = handle
    End Sub

    Public Sub StartThread()
        t.Start()

    End Sub

    Public Sub StopThread()
        done = True
        t.Abort()
    End Sub

    Private Function ConvertByteArray(ByVal array() As Byte, ByVal offset As Integer) As UInteger
        Dim res As UInteger = 0
        res += array(offset)
        res += array(offset + 1) * &H100
        res += array(offset + 2) * &H10000
        res += array(offset + 3) * &H1000000
        Return res
    End Function

    Private Sub DoWork()
        Dim buf(10000) As Byte
        Dim nRead As UInteger = 0
        Dim flags As UInteger = 0
        Dim res As UInteger = 0

        Try
            While (done <> True)
                res = WaitForSingleObject(ptr, 1000)
                If res = 0 Then
                    ReadMsgQueue(ptr, buf, buf.Length, nRead, -1, flags)
                    Dim msgvalue As UInteger = ConvertByteArray(buf, 0)

                    If msgvalue = &H2 Then ' Resume
                        ClassCamera.Close()
                        CameraForm.m_bWake = True
                        CameraForm.m_bCaping = False
                        SendMessage(hWnd, CatchCallback.WM_CALLBACK_MESSAGE, 0, 0)

                    End If

                    Dim flag As UInteger = ConvertByteArray(buf, 4)
                    Dim msg As String = ""

                    Select Case flags
                        Case 65536
                            msg = "******Power On"
                        Case 131072
                            msg = "******Power Off"
                        Case 262144
                            msg = "******Power Critical"
                        Case 524288
                            msg = "******Power Boot"
                        Case 1048576
                            msg = "******Power Idle"
                        Case 2097152
                            msg = "******Power Suspend"
                            CameraForm.m_bCaping = True
                        Case 8388608
                            msg = "******Power Reset"
                        Case Else
                            msg = "******Unknown Flag: " + flag
                    End Select

                    If msg <> "" Then
                        Console.WriteLine(msg)

                    End If

                End If
            End While
        Catch ex As Exception
            If done = False Then
                Console.WriteLine("Got exception: " + ex.ToString())
            End If


        End Try

    End Sub





End Class
