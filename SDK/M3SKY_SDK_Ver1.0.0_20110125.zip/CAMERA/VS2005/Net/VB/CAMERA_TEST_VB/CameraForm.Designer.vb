<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class CameraForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Private mainMenu1 As System.Windows.Forms.MainMenu

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem_Ok = New System.Windows.Forms.MenuItem
        Me.BTN_CAMERA_MODE = New System.Windows.Forms.Button
        Me.BTN_OPTION = New System.Windows.Forms.Button
        Me.BTN_CAPTURE = New System.Windows.Forms.Button
        Me.BTN_AUTO_FOCUS = New System.Windows.Forms.Button
        Me.BTN_PREVIEW_STOP = New System.Windows.Forms.Button
        Me.BTN_PREVIEW_START = New System.Windows.Forms.Button
        Me.BTN_FLASH_OFF = New System.Windows.Forms.Button
        Me.BTN_FLASH_ON = New System.Windows.Forms.Button
        Me.LABEL_STAND = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.Add(Me.MenuItem_Ok)
        '
        'MenuItem_Ok
        '
        Me.MenuItem_Ok.Text = "OK"
        '
        'BTN_CAMERA_MODE
        '
        Me.BTN_CAMERA_MODE.Location = New System.Drawing.Point(121, 247)
        Me.BTN_CAMERA_MODE.Name = "BTN_CAMERA_MODE"
        Me.BTN_CAMERA_MODE.Size = New System.Drawing.Size(116, 18)
        Me.BTN_CAMERA_MODE.TabIndex = 17
        Me.BTN_CAMERA_MODE.Text = "Still Mode"
        '
        'BTN_OPTION
        '
        Me.BTN_OPTION.Enabled = False
        Me.BTN_OPTION.Location = New System.Drawing.Point(121, 190)
        Me.BTN_OPTION.Name = "BTN_OPTION"
        Me.BTN_OPTION.Size = New System.Drawing.Size(116, 18)
        Me.BTN_OPTION.TabIndex = 16
        Me.BTN_OPTION.Text = "Option"
        '
        'BTN_CAPTURE
        '
        Me.BTN_CAPTURE.Location = New System.Drawing.Point(3, 190)
        Me.BTN_CAPTURE.Name = "BTN_CAPTURE"
        Me.BTN_CAPTURE.Size = New System.Drawing.Size(116, 18)
        Me.BTN_CAPTURE.TabIndex = 15
        Me.BTN_CAPTURE.Text = "Capture"
        '
        'BTN_AUTO_FOCUS
        '
        Me.BTN_AUTO_FOCUS.Location = New System.Drawing.Point(3, 247)
        Me.BTN_AUTO_FOCUS.Name = "BTN_AUTO_FOCUS"
        Me.BTN_AUTO_FOCUS.Size = New System.Drawing.Size(116, 18)
        Me.BTN_AUTO_FOCUS.TabIndex = 14
        Me.BTN_AUTO_FOCUS.Text = "AutoFocus"
        Me.BTN_AUTO_FOCUS.Visible = False
        '
        'BTN_PREVIEW_STOP
        '
        Me.BTN_PREVIEW_STOP.Location = New System.Drawing.Point(121, 209)
        Me.BTN_PREVIEW_STOP.Name = "BTN_PREVIEW_STOP"
        Me.BTN_PREVIEW_STOP.Size = New System.Drawing.Size(116, 18)
        Me.BTN_PREVIEW_STOP.TabIndex = 13
        Me.BTN_PREVIEW_STOP.Text = "Preview Stop"
        '
        'BTN_PREVIEW_START
        '
        Me.BTN_PREVIEW_START.Enabled = False
        Me.BTN_PREVIEW_START.Location = New System.Drawing.Point(3, 209)
        Me.BTN_PREVIEW_START.Name = "BTN_PREVIEW_START"
        Me.BTN_PREVIEW_START.Size = New System.Drawing.Size(116, 18)
        Me.BTN_PREVIEW_START.TabIndex = 12
        Me.BTN_PREVIEW_START.Text = "Preview Start"
        '
        'BTN_FLASH_OFF
        '
        Me.BTN_FLASH_OFF.Location = New System.Drawing.Point(121, 228)
        Me.BTN_FLASH_OFF.Name = "BTN_FLASH_OFF"
        Me.BTN_FLASH_OFF.Size = New System.Drawing.Size(116, 18)
        Me.BTN_FLASH_OFF.TabIndex = 11
        Me.BTN_FLASH_OFF.Text = "Flash Off"
        '
        'BTN_FLASH_ON
        '
        Me.BTN_FLASH_ON.Location = New System.Drawing.Point(3, 228)
        Me.BTN_FLASH_ON.Name = "BTN_FLASH_ON"
        Me.BTN_FLASH_ON.Size = New System.Drawing.Size(116, 18)
        Me.BTN_FLASH_ON.TabIndex = 10
        Me.BTN_FLASH_ON.Text = "Flash On"
        '
        'LABEL_STAND
        '
        Me.LABEL_STAND.Location = New System.Drawing.Point(94, 79)
        Me.LABEL_STAND.Name = "LABEL_STAND"
        Me.LABEL_STAND.Size = New System.Drawing.Size(52, 20)
        Me.LABEL_STAND.Text = "Standby"
        Me.LABEL_STAND.Visible = False
        '
        'CameraForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(240, 268)
        Me.Controls.Add(Me.LABEL_STAND)
        Me.Controls.Add(Me.BTN_CAMERA_MODE)
        Me.Controls.Add(Me.BTN_OPTION)
        Me.Controls.Add(Me.BTN_CAPTURE)
        Me.Controls.Add(Me.BTN_AUTO_FOCUS)
        Me.Controls.Add(Me.BTN_PREVIEW_STOP)
        Me.Controls.Add(Me.BTN_PREVIEW_START)
        Me.Controls.Add(Me.BTN_FLASH_OFF)
        Me.Controls.Add(Me.BTN_FLASH_ON)
        Me.Menu = Me.mainMenu1
        Me.Name = "CameraForm"
        Me.Text = "Camera"
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents BTN_CAMERA_MODE As System.Windows.Forms.Button
    Private WithEvents BTN_OPTION As System.Windows.Forms.Button
    Private WithEvents BTN_CAPTURE As System.Windows.Forms.Button
    Private WithEvents BTN_AUTO_FOCUS As System.Windows.Forms.Button
    Private WithEvents BTN_PREVIEW_STOP As System.Windows.Forms.Button
    Private WithEvents BTN_PREVIEW_START As System.Windows.Forms.Button
    Private WithEvents BTN_FLASH_OFF As System.Windows.Forms.Button
    Private WithEvents BTN_FLASH_ON As System.Windows.Forms.Button
    Friend WithEvents MenuItem_Ok As System.Windows.Forms.MenuItem
    Private WithEvents LABEL_STAND As System.Windows.Forms.Label

End Class
