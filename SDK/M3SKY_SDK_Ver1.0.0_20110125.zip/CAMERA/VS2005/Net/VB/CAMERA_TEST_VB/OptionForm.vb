﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports Microsoft.Win32



Public Class OptionForm
    Public m_strFolder As String
    Public m_strFileName As String

    Public m_strVersion As StringBuilder

    Public m_bDateSaveMode As Boolean
    Public m_bVideo As Boolean

    Public m_videotype As VIDEO_TYPE
    Public m_Cam As ClassCamera
    Public m_bHistoEqul As Boolean
    Public m_nNightLevel As Integer

    Private Sub OptionForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If (m_bVideo = True) Then
            CBOX_VIDEO_TYPE.Enabled = True
            LABEL_VIDEO_TYPE.Enabled = True
        Else
            CBOX_VIDEO_TYPE.Enabled = False
            LABEL_VIDEO_TYPE.Enabled = False
        End If

        If (m_bDateSaveMode = True) Then
            LABEL_SAVE_FOLDER.Enabled = False
            TBOX_SAVE_FOLDER.Enabled = False
            LABEL_SAVE_NAME.Enabled = False
            TBOX_SAVE_NAME.Enabled = False
        Else
            LABEL_SAVE_FOLDER.Enabled = True
            TBOX_SAVE_FOLDER.Enabled = True
            LABEL_SAVE_NAME.Enabled = True
            TBOX_SAVE_NAME.Enabled = True
        End If 

        InitResolutionUI()

        If (m_bDateSaveMode = True) Then
            CBOX_SAVE_MODE.SelectedIndex = 0
        Else
            CBOX_SAVE_MODE.SelectedIndex = 1
        End If

        If (m_videotype = VIDEO_TYPE.VIDEO_WMV) Then
            CBOX_VIDEO_TYPE.SelectedIndex = 0
        Else
            CBOX_VIDEO_TYPE.SelectedIndex = 1
        End If

        TBOX_SAVE_FOLDER.Text = m_strFolder
        TBOX_SAVE_NAME.Text = m_strFileName


        CBOX_RESOLUTION.SelectedIndex = m_Cam.Get_Resolution(1)
        CBOX_BRIGHT.SelectedIndex = (m_Cam.Get_Brightness() - 3) * -1
        CBOX_WHITE_BALANCE.SelectedIndex = m_Cam.Get_WhiteBalance()
        CBOX_QUALITY.SelectedIndex = m_Cam.Get_Quality()

        m_Cam.GetHistogram(m_bHistoEqul)
        m_Cam.GetNight(m_nNightLevel)

        CHECK_HISTOEQUAL.Checked = m_bHistoEqul
        NUM_NIGHTLEVEL.Value = m_nNightLevel

        If (CHECK_HISTOEQUAL.Checked = False) Then
            LABEL_LEVEL.Enabled = False
            NUM_NIGHTLEVEL.Enabled = False
        Else
            LABEL_LEVEL.Enabled = True
            NUM_NIGHTLEVEL.Enabled = True
        End If

        Dim strVersion As New StringBuilder(120)
        m_Cam.Get_InfoEx(strVersion)       
        Label_Version.Text = String.Format("{0} App 1.0.0 version build 2010.12.09.", strVersion)

    End Sub
    Private Sub CBOX_SAVE_MODE_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CBOX_SAVE_MODE.SelectedIndexChanged

        If (CBOX_SAVE_MODE.SelectedIndex = 0) Then
            LABEL_SAVE_NAME.Enabled = False
            LABEL_SAVE_FOLDER.Enabled = False
            TBOX_SAVE_NAME.Enabled = False
            TBOX_SAVE_FOLDER.Enabled = False

        Else
            LABEL_SAVE_NAME.Enabled = True
            LABEL_SAVE_FOLDER.Enabled = True
            TBOX_SAVE_NAME.Enabled = True
            TBOX_SAVE_FOLDER.Enabled = True
        End If

    End Sub
    Private Sub CHECK_HISTOEQUAL_CheckStateChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CHECK_HISTOEQUAL.Click

        If (CHECK_HISTOEQUAL.Checked = True) Then
            LABEL_LEVEL.Enabled = True
            NUM_NIGHTLEVEL.Enabled = True
        Else
            LABEL_LEVEL.Enabled = False
            NUM_NIGHTLEVEL.Enabled = False
        End If
    End Sub

    Private Sub Menu_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_OK.Click

        Dim value As Long

        If (CBOX_SAVE_MODE.SelectedIndex = 0) Then
            m_bDateSaveMode = True
        Else
            If (TBOX_SAVE_FOLDER.TextLength = 0) Then
                MessageBox.Show("input Save Folder")
                Return
            End If
            If (TBOX_SAVE_NAME.TextLength = 0) Then
                MessageBox.Show("input Save Name")
                Return
            End If
            m_bDateSaveMode = False
        End If


        value = (CBOX_BRIGHT.SelectedIndex - 3) * -1
        m_Cam.Set_Brightness(value)

        value = CBOX_WHITE_BALANCE.SelectedIndex
        m_Cam.Set_WhiteBalance(value)

        value = CBOX_RESOLUTION.SelectedIndex

        m_Cam.Set_Resolution(1, value)

        m_Cam.Set_Quality(CBOX_QUALITY.SelectedIndex)

        m_nNightLevel = NUM_NIGHTLEVEL.Value

        m_bHistoEqul = CHECK_HISTOEQUAL.Checked

        m_Cam.EnableHisto(m_bHistoEqul, m_nNightLevel)

        If (CBOX_VIDEO_TYPE.SelectedIndex = 0) Then
            m_videotype = VIDEO_TYPE.VIDEO_WMV
        Else
            m_videotype = VIDEO_TYPE.VIDEO_ASF
        End If


        m_strFolder = TBOX_SAVE_FOLDER.Text
        m_strFileName = TBOX_SAVE_NAME.Text

        Me.DialogResult = DialogResult.OK
    End Sub

    Private Sub Menu_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Menu_Cancel.Click

        Me.DialogResult = DialogResult.Cancel
    End Sub
    Private Sub InitResolutionUI()      ' M3Orange는 기존 M3Sky와 resolution이 달라서 registry에서 resolution값을 얻어옴 [2010.11.16. 2:53:44 ParkHyunJu]
        Dim nItemCount As Integer = &H0
        Dim strValueName As String = "OptionNum"
        Dim strPath As String = "Software\\Microsoft\\Pictures\\Camera\\OEM\\PictureResolution"



        'The key HKEY_LOCAL_MACHINE\Software\Microsoft\Pictures\Camera\OEM\PictureResolution\ defines the total number of resolution settings available on a device.
        'This value represents the number of available resolutions.

        nItemCount = Registry.LocalMachine.OpenSubKey(strPath).GetValue(strValueName)


        If 0 <> nItemCount Then

            Dim ItemName(nItemCount * 2) As Integer
            Dim nResolutionIndex As Integer

            Dim MainKey As RegistryKey = Registry.LocalMachine.OpenSubKey(strPath)

            nItemCount = MainKey.SubKeyCount
            nResolutionIndex = 0

            For Each SubKeyName As String In MainKey.GetSubKeyNames()
                Dim SubKeyPath As String = "Software\\Microsoft\\Pictures\\Camera\\OEM\\PictureResolution\\" + SubKeyName
                nResolutionIndex = Convert.ToInt32(SubKeyName)


                Dim SubKey As RegistryKey = Registry.LocalMachine.OpenSubKey(SubKeyPath)
                ItemName(nResolutionIndex * 2 - 2) = SubKey.GetValue("Width")
                ItemName(nResolutionIndex * 2 - 1) = SubKey.GetValue("Height")
                nResolutionIndex += 1
            Next

            nResolutionIndex = 0

            While nResolutionIndex < nItemCount
                CBOX_RESOLUTION.Items.Add(Convert.ToString(ItemName(nResolutionIndex * 2)) + "x" + Convert.ToString(ItemName(nResolutionIndex * 2 + 1)))
                nResolutionIndex += 1
            End While
        End If


        '176*144
        '320*240
        '352*288
        '640*480
        '800*600
        '1280*960
        '1600*1200





    End Sub
End Class