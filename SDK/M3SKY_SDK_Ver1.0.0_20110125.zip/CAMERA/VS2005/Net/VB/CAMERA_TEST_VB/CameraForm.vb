' 1.0.0 version ���������߰� [2010.11.1. 19:42:34 ParkHyunJu]
'               M3Orange�� ���� M3Sky�� resolution�� �޶� registry���� resolution���� ���� [2010.11.16. 2:53:44 ParkHyunJu]

' 0.9.1.0.0 version  Beta Version ����   ���� ���� ���� �ɶ� "0.9."�� �����Ұ� [2010.12.9. 11:49:49 ParkHyunJu]		
' 1.0.0 2011. 01. 03 ���� ����

Imports System
Imports System.Collections.Generic
Imports System.Data
Imports System.ComponentModel
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports System.Threading
Imports Microsoft.Win32
Imports Microsoft.WindowsCE.Forms
Imports System.Diagnostics


Public Enum CAMERA_MODE
    STILL_MODE '= 0
    VIDEO_MODE '= 1
End Enum

Public Enum VIDEO_TYPE
    VIDEO_ASF '= 0
    VIDEO_WMV '= 1
End Enum


Public Class CameraForm

    Private m_CamKeyValue As Integer

    Private m_cameramode As CAMERA_MODE
    Private m_videotype As VIDEO_TYPE

    Private m_bVideoRun As Boolean
    Private m_bPreviewRun As Boolean
    Private m_bStillDateSaveMode As Boolean
    Private m_bVideoDateSaveMode As Boolean

    Private m_strStillFolder As String
    Private m_strStillFileName As String
    Private m_strVideoFolder As String
    Private m_strVideoFileName As String

    Private m_Cam As ClassCamera
    Private pn As ClassPowerNotifications

    Public Shared m_bWake As Boolean = False
    Public Shared m_bCaping As Boolean = False
    Public Shared standby As Label

    Private msgWinCall As CatchCallback

    Private Declare Function SystemParametersInfo Lib "coredll.dll" _
    (ByVal uiAction As UInt32, ByVal uiParam As UInt32, ByVal pvParam As StringBuilder, ByVal fWinIni As UInt32) _
    As Boolean

    Private Declare Function GetSystemMetrics Lib "coredll.dll" _
    (ByVal smIndex As Integer) As Integer

    Private Sub CameraForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        m_Cam = New ClassCamera()
        msgWinCall = New CatchCallback(Me)

        pn = New ClassPowerNotifications(msgWinCall.Hwnd)
        pn.StartThread()

        Dim oemInfo As New StringBuilder(64)
        SystemParametersInfo(258, 64, oemInfo, 2)

        If String.Compare(oemInfo.ToString(), "MM3") <> 0 Then
            BTN_AUTO_FOCUS.Visible = True
        End If

        Dim CamSideBtn As RegistryKey = Registry.LocalMachine.CreateSubKey("ControlPanel\\keypad\\SideKey")
        m_CamKeyValue = Convert.ToInt32(CamSideBtn.GetValue("RightUpKey"))

        If m_CamKeyValue <> 2 Then
            CamSideBtn.SetValue("RightUpKey", 2, RegistryValueKind.DWord)
        End If

        m_Cam.SHSetAppKey(Keys.F13, Handle)

        m_cameramode = CAMERA_MODE.STILL_MODE
        m_videotype = VIDEO_TYPE.VIDEO_ASF
        m_bVideoRun = False
        m_bPreviewRun = True
        m_bStillDateSaveMode = True
        m_bVideoDateSaveMode = True

        m_Cam.Open(Me.Handle, m_cameramode, m_videotype)

        m_strStillFolder = "\\My Documents\\My Pictures\\"
        m_strStillFileName = "1.jpg"

        m_strVideoFolder = "\\My Documents\\My Pictures\\"
        m_strVideoFileName = "0.asf"

        If GetSystemMetrics(0) > 240 Then
            m_Cam.SetPosition(80, 90, 320, 240)
        End If

        Me.KeyPreview = True
    End Sub
    Private Sub CameraForm_Closed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        If m_CamKeyValue <> 2 Then
            Dim CamSideBtn As RegistryKey = Registry.LocalMachine.CreateSubKey("ControlPanel\\keypad\\SideKey")
            CamSideBtn.SetValue("RightUpKey", m_CamKeyValue, RegistryValueKind.DWord)
        End If

        pn.StopThread()
        ClassCamera.Close()
    End Sub

    Public Sub DisableButton(ByVal a As Integer, ByVal b As Integer)
        BTN_CAPTURE.Enabled = False
        BTN_AUTO_FOCUS.Enabled = False
        BTN_PREVIEW_STOP.Enabled = False
        BTN_CAMERA_MODE.Enabled = False
    End Sub



    Private Sub FlashOn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_FLASH_ON.Click
        m_Cam.Flash_On(True)
    End Sub
    Private Sub FlashOff_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_FLASH_OFF.Click
        m_Cam.Flash_On(False)
    End Sub
    Private Sub Start_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_PREVIEW_START.Click
        If m_Cam.Preview_Start() = True Then
            m_bPreviewRun = True
            BTN_PREVIEW_START.Enabled = False
            BTN_PREVIEW_STOP.Enabled = True
            BTN_CAPTURE.Enabled = True
            BTN_OPTION.Enabled = False
            BTN_AUTO_FOCUS.Enabled = True
        End If
    End Sub
    Private Sub Stop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_PREVIEW_STOP.Click
        If m_Cam.Preview_Stop() = True Then
            m_bPreviewRun = False
            BTN_PREVIEW_START.Enabled = True
            BTN_PREVIEW_STOP.Enabled = False
            BTN_CAPTURE.Enabled = False
            BTN_OPTION.Enabled = True
            BTN_AUTO_FOCUS.Enabled = False
        End If
    End Sub
    Private Sub AutoFocus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_AUTO_FOCUS.Click
        m_Cam.SetAutoFocus()
    End Sub
    Private Sub BTN_CAPTURE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CAPTURE.Click
        CaptureFn()
    End Sub
    Private Sub BTN_OPTION_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OPTION.Click

        Dim dlg As OptionForm = New OptionForm()
        dlg.m_Cam = Me.m_Cam


        If (m_cameramode = CAMERA_MODE.STILL_MODE) Then
            dlg.m_bVideo = False
            dlg.m_strFolder = m_strStillFolder
            dlg.m_strFileName = m_strStillFileName
            dlg.m_bDateSaveMode = m_bStillDateSaveMode
        Else

            dlg.m_videotype = m_videotype
            dlg.m_bVideo = True

            dlg.m_strFolder = m_strVideoFolder
            dlg.m_strFileName = m_strVideoFileName
            dlg.m_bDateSaveMode = m_bVideoDateSaveMode

        End If

        If (dlg.ShowDialog() = DialogResult.OK) Then
            If (m_cameramode = CAMERA_MODE.STILL_MODE) Then
                m_strStillFolder = dlg.m_strFolder
                m_strStillFileName = dlg.m_strFileName
                m_bStillDateSaveMode = dlg.m_bDateSaveMode
            Else
                m_videotype = dlg.m_videotype
                m_strVideoFolder = dlg.m_strFolder
                m_strVideoFileName = dlg.m_strFileName
                m_bVideoDateSaveMode = dlg.m_bDateSaveMode
            End If

            m_Cam.Open(Me.Handle, m_cameramode, m_videotype)

            m_bPreviewRun = True
            BTN_PREVIEW_START.Enabled = False
            BTN_PREVIEW_STOP.Enabled = True
            BTN_CAPTURE.Enabled = True
            BTN_OPTION.Enabled = False
            BTN_AUTO_FOCUS.Enabled = True
        End If

    End Sub
    Private Sub BTN_CAMERA_MODE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CAMERA_MODE.Click
        ChangeCameraMode()

    End Sub

    Private Sub CaptureFn()
        If (m_bCaping <> True) Then
            m_bCaping = True

            If (m_bPreviewRun <> True) Then
                MessageBox.Show("Click Preview Start Button")
                Return
            End If

            Dim filefullname As String = ""

            Select Case m_cameramode
                Case CAMERA_MODE.STILL_MODE
                    BTN_CAPTURE.Enabled = False
                    BTN_PREVIEW_STOP.Enabled = False
                    BTN_AUTO_FOCUS.Enabled = False

                    If (m_bStillDateSaveMode = True) Then
                        Dim path As String = String.Empty
                        path = m_Cam.Capture(Nothing)
                    Else
                        filefullname = m_strStillFolder + m_strStillFileName
                        m_Cam.Capture(filefullname)
                    End If

                    m_bWake = True
                Case CAMERA_MODE.VIDEO_MODE
                    If (m_bVideoRun <> True) Then
                        BTN_PREVIEW_START.Enabled = False
                        BTN_PREVIEW_STOP.Enabled = False

                        If (m_bVideoDateSaveMode = True) Then
                            m_Cam.Video_Start("")
                        Else
                            filefullname = m_strVideoFolder + m_strVideoFileName
                            m_Cam.Video_Start(filefullname)

                        End If

                        BTN_CAPTURE.Text = "Video Stop"
                        BTN_PREVIEW_STOP.Enabled = False
                        m_bVideoRun = True

                    Else
                        BTN_CAPTURE.Enabled = False
                        BTN_PREVIEW_STOP.Enabled = False
                        BTN_AUTO_FOCUS.Enabled = False

                        m_Cam.Video_Stop()
                        ClassCamera.Close()
                        m_bWake = True
                        BTN_CAPTURE.Text = "Video Start"
                        m_bVideoRun = False

                    End If

            End Select
        End If
    End Sub

    Private Sub ChangeCameraMode()
        If (CAMERA_MODE.VIDEO_MODE = m_cameramode) Then
            m_cameramode = CAMERA_MODE.STILL_MODE
            BTN_CAMERA_MODE.Text = "Video Mode"
            BTN_CAPTURE.Text = "Capture"
        Else
            m_cameramode = CAMERA_MODE.VIDEO_MODE
            BTN_CAMERA_MODE.Text = "Still Mode"
            BTN_CAPTURE.Text = "Video Start"
        End If

        m_Cam.Open(Me.Handle, m_cameramode, m_videotype)

        m_bPreviewRun = True
        BTN_PREVIEW_START.Enabled = False
        BTN_PREVIEW_STOP.Enabled = True
        BTN_CAPTURE.Enabled = True
        BTN_OPTION.Enabled = False
        BTN_AUTO_FOCUS.Enabled = True

    End Sub

    Private Sub MenuItem_Ok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem_Ok.Click
        Close()
    End Sub

    Private Sub CameraForm_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown
        If (m_bWake = True) Then
            LABEL_STAND.Hide()
            m_bCaping = False

            If (m_cameramode = CAMERA_MODE.STILL_MODE) Then
                m_cameramode = CAMERA_MODE.VIDEO_MODE
            Else
                m_cameramode = CAMERA_MODE.STILL_MODE
            End If

            ChangeCameraMode()
        End If

        m_bWake = False
    End Sub

    Private Sub CameraForm_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown

        If (e.KeyCode = Keys.F13) Then
            If (m_bWake = False) And (m_bPreviewRun = True) Then
                CaptureFn()
            Else
                If (m_bCaping <> True) Then
                    If (m_cameramode = CAMERA_MODE.STILL_MODE) Then
                        m_cameramode = CAMERA_MODE.VIDEO_MODE
                    Else
                        m_cameramode = CAMERA_MODE.STILL_MODE
                    End If

                    ChangeCameraMode()

                    m_bWake = False
                    m_bCaping = False

                End If
            End If
        End If

    End Sub
End Class

Public Class CatchCallback
    Inherits MessageWindow

    Public Const WM_USER As Integer = &H400
    Public Const WM_CALLBACK_MESSAGE As Integer = WM_USER + &H12

    Private Container As CameraForm

    Public Sub New(ByVal formcontainer As CameraForm)
        Container = formcontainer
    End Sub

    Protected Overrides Sub WndProc(ByRef msg As Message)
        Select Case msg.Msg
            Case WM_CALLBACK_MESSAGE
                Container.DisableButton(msg.WParam, msg.LParam)

        End Select

        MyBase.WndProc(msg)
    End Sub


End Class
