﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class OptionForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Private mainMenu1 As System.Windows.Forms.MainMenu

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.Menu_OK = New System.Windows.Forms.MenuItem
        Me.Menu_Cancel = New System.Windows.Forms.MenuItem
        Me.NUM_NIGHTLEVEL = New System.Windows.Forms.NumericUpDown
        Me.LABEL_LEVEL = New System.Windows.Forms.Label
        Me.CHECK_HISTOEQUAL = New System.Windows.Forms.CheckBox
        Me.label2 = New System.Windows.Forms.Label
        Me.CBOX_QUALITY = New System.Windows.Forms.ComboBox
        Me.label1 = New System.Windows.Forms.Label
        Me.TBOX_SAVE_NAME = New System.Windows.Forms.TextBox
        Me.TBOX_SAVE_FOLDER = New System.Windows.Forms.TextBox
        Me.CBOX_VIDEO_TYPE = New System.Windows.Forms.ComboBox
        Me.CBOX_SAVE_MODE = New System.Windows.Forms.ComboBox
        Me.CBOX_WHITE_BALANCE = New System.Windows.Forms.ComboBox
        Me.CBOX_RESOLUTION = New System.Windows.Forms.ComboBox
        Me.CBOX_BRIGHT = New System.Windows.Forms.ComboBox
        Me.LABEL_VIDEO_TYPE = New System.Windows.Forms.Label
        Me.LABEL_SAVE_NAME = New System.Windows.Forms.Label
        Me.LABEL_SAVE_FOLDER = New System.Windows.Forms.Label
        Me.LABEL_SAVE_MODE = New System.Windows.Forms.Label
        Me.LABEL_WHITE_BALANCE = New System.Windows.Forms.Label
        Me.LABEL_RESOLUTION = New System.Windows.Forms.Label
        Me.LABEL_BRIGHT = New System.Windows.Forms.Label
        Me.Label_Version = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.Add(Me.Menu_OK)
        Me.mainMenu1.MenuItems.Add(Me.Menu_Cancel)
        '
        'Menu_OK
        '
        Me.Menu_OK.Text = "OK"
        '
        'Menu_Cancel
        '
        Me.Menu_Cancel.Text = "CANCEL"
        '
        'NUM_NIGHTLEVEL
        '
        Me.NUM_NIGHTLEVEL.Location = New System.Drawing.Point(177, 126)
        Me.NUM_NIGHTLEVEL.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.NUM_NIGHTLEVEL.Name = "NUM_NIGHTLEVEL"
        Me.NUM_NIGHTLEVEL.Size = New System.Drawing.Size(56, 22)
        Me.NUM_NIGHTLEVEL.TabIndex = 68
        '
        'LABEL_LEVEL
        '
        Me.LABEL_LEVEL.Location = New System.Drawing.Point(135, 129)
        Me.LABEL_LEVEL.Name = "LABEL_LEVEL"
        Me.LABEL_LEVEL.Size = New System.Drawing.Size(35, 19)
        Me.LABEL_LEVEL.Text = "Level"
        '
        'CHECK_HISTOEQUAL
        '
        Me.CHECK_HISTOEQUAL.Location = New System.Drawing.Point(105, 129)
        Me.CHECK_HISTOEQUAL.Name = "CHECK_HISTOEQUAL"
        Me.CHECK_HISTOEQUAL.Size = New System.Drawing.Size(19, 16)
        Me.CHECK_HISTOEQUAL.TabIndex = 67
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(28, 127)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(72, 20)
        Me.label2.Text = "Night Mode"
        '
        'CBOX_QUALITY
        '
        Me.CBOX_QUALITY.Items.Add("Low quality")
        Me.CBOX_QUALITY.Items.Add("Normal quality")
        Me.CBOX_QUALITY.Items.Add("High quality")
        Me.CBOX_QUALITY.Location = New System.Drawing.Point(134, 3)
        Me.CBOX_QUALITY.Name = "CBOX_QUALITY"
        Me.CBOX_QUALITY.Size = New System.Drawing.Size(100, 22)
        Me.CBOX_QUALITY.TabIndex = 66
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(9, 7)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(118, 20)
        Me.label1.Text = "compression level :"
        '
        'TBOX_SAVE_NAME
        '
        Me.TBOX_SAVE_NAME.Location = New System.Drawing.Point(106, 174)
        Me.TBOX_SAVE_NAME.Name = "TBOX_SAVE_NAME"
        Me.TBOX_SAVE_NAME.Size = New System.Drawing.Size(128, 21)
        Me.TBOX_SAVE_NAME.TabIndex = 65
        '
        'TBOX_SAVE_FOLDER
        '
        Me.TBOX_SAVE_FOLDER.Location = New System.Drawing.Point(106, 151)
        Me.TBOX_SAVE_FOLDER.Name = "TBOX_SAVE_FOLDER"
        Me.TBOX_SAVE_FOLDER.Size = New System.Drawing.Size(128, 21)
        Me.TBOX_SAVE_FOLDER.TabIndex = 64
        '
        'CBOX_VIDEO_TYPE
        '
        Me.CBOX_VIDEO_TYPE.Items.Add("WMV")
        Me.CBOX_VIDEO_TYPE.Items.Add("ASF")
        Me.CBOX_VIDEO_TYPE.Location = New System.Drawing.Point(106, 197)
        Me.CBOX_VIDEO_TYPE.Name = "CBOX_VIDEO_TYPE"
        Me.CBOX_VIDEO_TYPE.Size = New System.Drawing.Size(128, 22)
        Me.CBOX_VIDEO_TYPE.TabIndex = 63
        '
        'CBOX_SAVE_MODE
        '
        Me.CBOX_SAVE_MODE.Items.Add("Date Mode")
        Me.CBOX_SAVE_MODE.Items.Add("Custom Mode")
        Me.CBOX_SAVE_MODE.Location = New System.Drawing.Point(106, 102)
        Me.CBOX_SAVE_MODE.Name = "CBOX_SAVE_MODE"
        Me.CBOX_SAVE_MODE.Size = New System.Drawing.Size(128, 22)
        Me.CBOX_SAVE_MODE.TabIndex = 62
        '
        'CBOX_WHITE_BALANCE
        '
        Me.CBOX_WHITE_BALANCE.Items.Add("Auto")
        Me.CBOX_WHITE_BALANCE.Items.Add("Sunny")
        Me.CBOX_WHITE_BALANCE.Items.Add("Cloudy")
        Me.CBOX_WHITE_BALANCE.Items.Add("Fluorescent")
        Me.CBOX_WHITE_BALANCE.Items.Add("Incandescent")
        Me.CBOX_WHITE_BALANCE.Location = New System.Drawing.Point(106, 76)
        Me.CBOX_WHITE_BALANCE.Name = "CBOX_WHITE_BALANCE"
        Me.CBOX_WHITE_BALANCE.Size = New System.Drawing.Size(128, 22)
        Me.CBOX_WHITE_BALANCE.TabIndex = 61
        '
        'CBOX_RESOLUTION
        '
        Me.CBOX_RESOLUTION.Location = New System.Drawing.Point(106, 51)
        Me.CBOX_RESOLUTION.Name = "CBOX_RESOLUTION"
        Me.CBOX_RESOLUTION.Size = New System.Drawing.Size(128, 22)
        Me.CBOX_RESOLUTION.TabIndex = 60
        '
        'CBOX_BRIGHT
        '
        Me.CBOX_BRIGHT.Items.Add("+3")
        Me.CBOX_BRIGHT.Items.Add("+2")
        Me.CBOX_BRIGHT.Items.Add("+1")
        Me.CBOX_BRIGHT.Items.Add("0")
        Me.CBOX_BRIGHT.Items.Add("-1")
        Me.CBOX_BRIGHT.Items.Add("-2")
        Me.CBOX_BRIGHT.Items.Add("-3")
        Me.CBOX_BRIGHT.Location = New System.Drawing.Point(105, 27)
        Me.CBOX_BRIGHT.Name = "CBOX_BRIGHT"
        Me.CBOX_BRIGHT.Size = New System.Drawing.Size(129, 22)
        Me.CBOX_BRIGHT.TabIndex = 59
        '
        'LABEL_VIDEO_TYPE
        '
        Me.LABEL_VIDEO_TYPE.Location = New System.Drawing.Point(17, 198)
        Me.LABEL_VIDEO_TYPE.Name = "LABEL_VIDEO_TYPE"
        Me.LABEL_VIDEO_TYPE.Size = New System.Drawing.Size(83, 20)
        Me.LABEL_VIDEO_TYPE.Text = "Video Type :"
        Me.LABEL_VIDEO_TYPE.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LABEL_SAVE_NAME
        '
        Me.LABEL_SAVE_NAME.Location = New System.Drawing.Point(17, 176)
        Me.LABEL_SAVE_NAME.Name = "LABEL_SAVE_NAME"
        Me.LABEL_SAVE_NAME.Size = New System.Drawing.Size(83, 20)
        Me.LABEL_SAVE_NAME.Text = "Save Name :"
        Me.LABEL_SAVE_NAME.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LABEL_SAVE_FOLDER
        '
        Me.LABEL_SAVE_FOLDER.Location = New System.Drawing.Point(17, 155)
        Me.LABEL_SAVE_FOLDER.Name = "LABEL_SAVE_FOLDER"
        Me.LABEL_SAVE_FOLDER.Size = New System.Drawing.Size(83, 20)
        Me.LABEL_SAVE_FOLDER.Text = "Save Folder :"
        Me.LABEL_SAVE_FOLDER.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LABEL_SAVE_MODE
        '
        Me.LABEL_SAVE_MODE.Location = New System.Drawing.Point(23, 104)
        Me.LABEL_SAVE_MODE.Name = "LABEL_SAVE_MODE"
        Me.LABEL_SAVE_MODE.Size = New System.Drawing.Size(77, 20)
        Me.LABEL_SAVE_MODE.Text = "Save Mode :"
        Me.LABEL_SAVE_MODE.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LABEL_WHITE_BALANCE
        '
        Me.LABEL_WHITE_BALANCE.Location = New System.Drawing.Point(9, 78)
        Me.LABEL_WHITE_BALANCE.Name = "LABEL_WHITE_BALANCE"
        Me.LABEL_WHITE_BALANCE.Size = New System.Drawing.Size(91, 20)
        Me.LABEL_WHITE_BALANCE.Text = "White Balance :"
        Me.LABEL_WHITE_BALANCE.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LABEL_RESOLUTION
        '
        Me.LABEL_RESOLUTION.Location = New System.Drawing.Point(27, 53)
        Me.LABEL_RESOLUTION.Name = "LABEL_RESOLUTION"
        Me.LABEL_RESOLUTION.Size = New System.Drawing.Size(73, 20)
        Me.LABEL_RESOLUTION.Text = "Resolution :"
        Me.LABEL_RESOLUTION.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LABEL_BRIGHT
        '
        Me.LABEL_BRIGHT.Location = New System.Drawing.Point(27, 29)
        Me.LABEL_BRIGHT.Name = "LABEL_BRIGHT"
        Me.LABEL_BRIGHT.Size = New System.Drawing.Size(73, 20)
        Me.LABEL_BRIGHT.Text = "Brightness :"
        Me.LABEL_BRIGHT.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label_Version
        '
        Me.Label_Version.Location = New System.Drawing.Point(0, 209)
        Me.Label_Version.Name = "Label_Version"
        Me.Label_Version.Size = New System.Drawing.Size(240, 56)
        '
        'OptionForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(240, 268)
        Me.Controls.Add(Me.NUM_NIGHTLEVEL)
        Me.Controls.Add(Me.LABEL_LEVEL)
        Me.Controls.Add(Me.CHECK_HISTOEQUAL)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.CBOX_QUALITY)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.TBOX_SAVE_NAME)
        Me.Controls.Add(Me.TBOX_SAVE_FOLDER)
        Me.Controls.Add(Me.CBOX_VIDEO_TYPE)
        Me.Controls.Add(Me.CBOX_SAVE_MODE)
        Me.Controls.Add(Me.CBOX_WHITE_BALANCE)
        Me.Controls.Add(Me.CBOX_RESOLUTION)
        Me.Controls.Add(Me.CBOX_BRIGHT)
        Me.Controls.Add(Me.LABEL_VIDEO_TYPE)
        Me.Controls.Add(Me.LABEL_SAVE_NAME)
        Me.Controls.Add(Me.LABEL_SAVE_FOLDER)
        Me.Controls.Add(Me.LABEL_SAVE_MODE)
        Me.Controls.Add(Me.LABEL_WHITE_BALANCE)
        Me.Controls.Add(Me.LABEL_RESOLUTION)
        Me.Controls.Add(Me.LABEL_BRIGHT)
        Me.Controls.Add(Me.Label_Version)
        Me.Menu = Me.mainMenu1
        Me.Name = "OptionForm"
        Me.Text = "OptionForm"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Menu_OK As System.Windows.Forms.MenuItem
    Friend WithEvents Menu_Cancel As System.Windows.Forms.MenuItem
    Private WithEvents NUM_NIGHTLEVEL As System.Windows.Forms.NumericUpDown
    Private WithEvents LABEL_LEVEL As System.Windows.Forms.Label
    Private WithEvents CHECK_HISTOEQUAL As System.Windows.Forms.CheckBox
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents CBOX_QUALITY As System.Windows.Forms.ComboBox
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents TBOX_SAVE_NAME As System.Windows.Forms.TextBox
    Private WithEvents TBOX_SAVE_FOLDER As System.Windows.Forms.TextBox
    Private WithEvents CBOX_VIDEO_TYPE As System.Windows.Forms.ComboBox
    Private WithEvents CBOX_SAVE_MODE As System.Windows.Forms.ComboBox
    Private WithEvents CBOX_WHITE_BALANCE As System.Windows.Forms.ComboBox
    Private WithEvents CBOX_RESOLUTION As System.Windows.Forms.ComboBox
    Private WithEvents CBOX_BRIGHT As System.Windows.Forms.ComboBox
    Private WithEvents LABEL_VIDEO_TYPE As System.Windows.Forms.Label
    Private WithEvents LABEL_SAVE_NAME As System.Windows.Forms.Label
    Private WithEvents LABEL_SAVE_FOLDER As System.Windows.Forms.Label
    Private WithEvents LABEL_SAVE_MODE As System.Windows.Forms.Label
    Private WithEvents LABEL_WHITE_BALANCE As System.Windows.Forms.Label
    Private WithEvents LABEL_RESOLUTION As System.Windows.Forms.Label
    Private WithEvents LABEL_BRIGHT As System.Windows.Forms.Label
    Friend WithEvents Label_Version As System.Windows.Forms.Label
End Class
