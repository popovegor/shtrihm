﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;


namespace CameraNet
{
    public partial class Option : Form
    {
        public string m_strFolder;
        public string m_strFileName;
//		private string m_strVersion;
        
        public bool m_bDateSaveMode;
        public bool m_bVideo;

        public VIDEO_TYPE m_videotype;
        public Camera m_Cam;

        /////////////////////////////////////////////////////////////////////////
        //  NightLevel Variable[11/6/2008 Crow = Donghyun, Eum ]
        public bool m_bHistoEqul;
        public int m_nNightLevel;
        /////////////////////////////////////////////////////////////////////////


        public Option()
        {
            InitializeComponent();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Option_Load(object sender, EventArgs e)
        {
			//////////////////////////////////////////////////////////////////////////
			//  [2010.10.25. 18:05:37 ParkHyunJu]

			InitResolutionUI();
			//
			//////////////////////////////////////////////////////////////////////////



            if (m_bVideo)
            {
                CBOX_VIDEO_TYPE.Enabled = true;
                LABEL_VIDEO_TYPE.Enabled = true;
            }
            else
            {
                CBOX_VIDEO_TYPE.Enabled = false;
                LABEL_VIDEO_TYPE.Enabled = false;
            }

            if (m_bDateSaveMode)
            {
                LABEL_SAVE_FOLDER.Enabled = false;
                TBOX_SAVE_FOLDER.Enabled = false;
                LABEL_SAVE_NAME.Enabled = false;
                TBOX_SAVE_NAME.Enabled = false;
            }
            else
            {
                LABEL_SAVE_FOLDER.Enabled = true;
                TBOX_SAVE_FOLDER.Enabled = true;
                LABEL_SAVE_NAME.Enabled = true;
                TBOX_SAVE_NAME.Enabled = true;
            }


            if (m_bDateSaveMode)
                CBOX_SAVE_MODE.SelectedIndex = 0;
            else
                CBOX_SAVE_MODE.SelectedIndex = 1;

            if (m_videotype == VIDEO_TYPE.VIDEO_WMV)
                CBOX_VIDEO_TYPE.SelectedIndex = 0;
            else
                CBOX_VIDEO_TYPE.SelectedIndex = 1;

            TBOX_SAVE_FOLDER.Text = m_strFolder;
            TBOX_SAVE_NAME.Text = m_strFileName;


			StringBuilder strVersion = new StringBuilder(100);
			m_Cam.Get_Info(strVersion);
			strVersion.Remove(0, 1);
			label_Version.Text = String.Format("{0} App 1.0.3 version build 2010.12.09.", strVersion);
			

            CBOX_RESOLUTION.SelectedIndex = m_Cam.Get_Resolution(1);
            CBOX_BRIGHT.SelectedIndex = (m_Cam.Get_Brightness() - 3) * -1;
            CBOX_WHITE_BALANCE.SelectedIndex = m_Cam.Get_WhiteBalance();
            CBOX_QUALITY.SelectedIndex = m_Cam.Get_Quality();

            ////////////////////////////////////////////////////////////////////////////////////////
//             //  [11/6/2008 CROW = Donghyun, Eum]
            
            m_Cam.GetHistogram(ref m_bHistoEqul);		// 현재 설정된 m_bHistoEqual값을 받는다.
            m_Cam.GetNight(ref m_nNightLevel);		    // 현재 설정된 m_nNightLevel값을 받는다.
            
            CHECK_HISTOEQUAL.Checked = m_bHistoEqul;
            NUM_NIGHTLEVEL.Value = m_nNightLevel;

            if(CHECK_HISTOEQUAL.Checked == false)
            {
                LABEL_LEVEL.Enabled = false;
                NUM_NIGHTLEVEL.Enabled = false;
            }
            else
            {
                LABEL_LEVEL.Enabled = true;
                NUM_NIGHTLEVEL.Enabled = true;
            }
      
            ////////////////////////////////////////////////////////////////////////////////////////

        }

        private void BTN_OK_Click(object sender, EventArgs e)
        {
            long value;

	        if(CBOX_SAVE_MODE.SelectedIndex == 0)
		        m_bDateSaveMode = true;
	        else
	        {
		        if(TBOX_SAVE_FOLDER.TextLength == 0)
		        {
			        MessageBox.Show("input Save Folder");
			        return;
		        }
		        if(TBOX_SAVE_NAME.TextLength == 0)
		        {
			        MessageBox.Show("input Save Name");
			        return;
		        }
		        m_bDateSaveMode = false;
	        }


	        value = (CBOX_BRIGHT.SelectedIndex -3) *-1;
	        m_Cam.Set_Brightness(value);

	        value = CBOX_WHITE_BALANCE.SelectedIndex;
	        m_Cam.Set_WhiteBalance(value);

            value = CBOX_RESOLUTION.SelectedIndex;

	        m_Cam.Set_Resolution(1, (int)value);

            m_Cam.Set_Quality(CBOX_QUALITY.SelectedIndex);

            ////////////////////////////////////////////////////////////////////////////////////////
            //  [11/6/2008 CROW = Donghyun, Eum]
            m_nNightLevel = (int)NUM_NIGHTLEVEL.Value;

            m_bHistoEqul = CHECK_HISTOEQUAL.Checked;

            m_Cam.EnableHisto(m_bHistoEqul, m_nNightLevel);

            ////////////////////////////////////////////////////////////////////////////////////////

	        if(CBOX_VIDEO_TYPE.SelectedIndex == 0)
		        m_videotype = VIDEO_TYPE.VIDEO_WMV;
	        else
                m_videotype = VIDEO_TYPE.VIDEO_ASF;


            m_strFolder = TBOX_SAVE_FOLDER.Text;
            m_strFileName = TBOX_SAVE_NAME.Text;

            this.DialogResult = DialogResult.OK;
        }

        private void TBOX_SAVE_FOLDER_TextChanged(object sender, EventArgs e)
        {


        }

        private void CBOX_SAVE_MODE_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(CBOX_SAVE_MODE.SelectedIndex == 0)
            {
                LABEL_SAVE_NAME.Enabled = false;
                LABEL_SAVE_FOLDER.Enabled = false;
                TBOX_SAVE_NAME.Enabled = false;
                TBOX_SAVE_FOLDER.Enabled = false;
            }
            else
            {
                LABEL_SAVE_NAME.Enabled = true;
                LABEL_SAVE_FOLDER.Enabled = true;
                TBOX_SAVE_NAME.Enabled = true;
                TBOX_SAVE_FOLDER.Enabled = true;

            }
        }

        private void BTN_CANCEL_Click_1(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////
        //  [11/6/2008 CROW = Donghyun, Eum]
        private void CHECK_HISTOEQUAL_CheckStateChanged(object sender, EventArgs e)
        {
            if (CHECK_HISTOEQUAL.Checked == true)
            {
                LABEL_LEVEL.Enabled = true;
                NUM_NIGHTLEVEL.Enabled = true;
            }
            else
            {
                LABEL_LEVEL.Enabled = false;
                NUM_NIGHTLEVEL.Enabled = false;
            }

        }
        //////////////////////////////////////////////////////////////////////////////////////////////////


		//////////////////////////////////////////////////////////////////////////
		//  resolution combobox insert item	[2010.10.29. 10:09:33 ParkHyunJu]

		//  SKY, Orange간의 resolution값이 달라서 registry에서 읽어서 적용하도록함 [2010.10.22. 15:13:47 ParkHyunJu]
		private void InitResolutionUI()
		{
			string strValueName = "OptionNum";
			string strPath = "Software\\Microsoft\\Pictures\\Camera\\OEM\\PictureResolution";
			int nResolutionIndex;
			
			
	//		Reg reg = new Reg();

			uint dwordItemCount = 0;
			//	The key HKEY_LOCAL_MACHINE\Software\Microsoft\Pictures\Camera\OEM\PictureResolution\ defines the total number of resolution settings available on a device.
			//	This value represents the number of available resolutions.


			dwordItemCount = Convert.ToUInt32(Registry.LocalMachine.OpenSubKey(strPath).GetValue(strValueName));

			if(0 != dwordItemCount)
			{
				uint [] ItemName = new uint[dwordItemCount*2];

				RegistryKey hMainKey = Registry.LocalMachine.OpenSubKey(strPath);

				nResolutionIndex = 0;

				foreach (String SubKeyName in hMainKey.GetSubKeyNames())
				{
					String SubKeyPath = "Software\\Microsoft\\Pictures\\Camera\\OEM\\PictureResolution\\" + SubKeyName;
					nResolutionIndex = Convert.ToInt32(SubKeyName);

					RegistryKey SubKey = Registry.LocalMachine.OpenSubKey(SubKeyPath);
					ItemName[nResolutionIndex * 2 - 2] = Convert.ToUInt32(SubKey.GetValue("Width"));
					ItemName[nResolutionIndex * 2 - 1] = Convert.ToUInt32(SubKey.GetValue("Height"));
					nResolutionIndex += 1;
				}
				
				nResolutionIndex = 0;
				while (nResolutionIndex < dwordItemCount)
                {
					CBOX_RESOLUTION.Items.Add(Convert.ToString(ItemName[nResolutionIndex * 2]) + "x" + Convert.ToString(ItemName[nResolutionIndex * 2 + 1]));
					nResolutionIndex += 1;
				}
			}
			

		}
		//  resolution combobox insert item	[2010.10.29. 10:09:33 ParkHyunJu]
		//////////////////////////////////////////////////////////////////////////
	
              
    }
}