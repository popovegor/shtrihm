﻿/********************************************************************
created		:	2008/03/27
file base	: 	CameraNet.exe

file ext	:	C#.Net
author		:	Dong-Hyun, Eum(vision7901) - SW2

purpose		:	M3 SKY / MM3
Report		:	2008. 03. 27 [03/27/2008 ju]			v1.0.0 - 정식버전으로 빌드되어서 나간 버전
				2008. 12. 18 [12/18/2008 ju]			v1.0.1 - 일본어 OS에서 카메라 키다운 눌렀을 때 default 값인 0xc1 않넘어옴 F13로변경
				2008. 12. 31 [03/27/2009 ju]			v1.0.2 - SetWindowPosition 인자값을 long으로 하면 잘못된 값이 dll로 전달되어서 int로 변환함
				2010. 01. 12 [01/12/2010 vision7901]	v1.0.2 - 카메라 인수인계
				[2010.10.29. 10:09:33 ParkHyunJu]		v1.0.3 - resolution combobox insert item 방식을 registry에서 읽어들이는 방법으로 변경함
																 버전정보 보이도록 수정

				[2010.12.9. 11:49:49 ParkHyunJu]		v0.9.1.0.3	Beta Version 배포   추후 정식 배포 될때 "0.9."을 삭제할것 	
                2011. 01. 04 JJ     v. 1.0.3 버전 수정
*********************************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;

using Microsoft.Win32;
using Microsoft.WindowsCE.Forms;



using System.Diagnostics;

namespace CameraNet
{
    public enum CAMERA_MODE { STILL_MODE = 0, VIDEO_MODE };
    public enum VIDEO_TYPE { VIDEO_ASF = 0, VIDEO_WMV };



    public partial class Form1 : Form
    {
		private int m_CamKeyValue;

        private CAMERA_MODE m_cameramode;
        private VIDEO_TYPE m_videotype;

        private bool m_bVideoRun;
        private bool m_bPreviewRun;
        private bool m_bStillDateSaveMode;
        private bool m_bVideoDateSaveMode;
        
        private string m_strStillFolder;
        private string m_strStillFileName;
        private string m_strVideoFolder;
        private string m_strVideoFileName;

        private Camera m_Cam;
        private PowerNotifications pn;

        public static bool m_bWake = false;
        public static bool m_bCaping = false;
        public static System.Windows.Forms.Label standby;

		private CatchCallback msgWinCall;

        public Form1()
        {
            InitializeComponent();
            m_Cam = new Camera();
			msgWinCall = new CatchCallback(this);
            pn = new PowerNotifications(msgWinCall.Hwnd);
            pn.Start();


            

//  SPI_GETOEMINFO == 258        [7/31/2009 ju]
//  SPIF_SENDCHANGE == 0x0002

            StringBuilder oemInfo = new StringBuilder(64);
            SystemParametersInfo(258, 64, oemInfo, 2);

            if (0 != String.Compare(oemInfo.ToString(), "MM3"))
                BTN_AUTO_FOCUS.Visible = true;

//          SM_CXSCREEN == 0

           


            
        }

		public void DisableButton(int a, int b)
		{
			BTN_CAPTURE.Enabled = false;
			BTN_AUTO_FOCUS.Enabled = false;
			BTN_PREVIEW_STOP.Enabled = false;
			BTN_CAMERA_MODE.Enabled = false;
		}


        private void FlashOn_Click(object sender, EventArgs e)
        {
            m_Cam.Flash_On(true);
        }

        private void FlashOff_Click(object sender, EventArgs e)
        {
            m_Cam.Flash_On(false);
        }

        private void Start_Click(object sender, EventArgs e)
        {
            if (m_Cam.Preview_Start())
            {
                m_bPreviewRun = true;
                BTN_PREVIEW_START.Enabled = false;
                BTN_PREVIEW_STOP.Enabled = true;
                BTN_CAPTURE.Enabled = true;
                BTN_OPTION.Enabled = false;
                BTN_AUTO_FOCUS.Enabled = true;
            }
        }

        private void Stop_Click(object sender, EventArgs e)
        {
            if (m_Cam.Preview_Stop())
            {
                m_bPreviewRun = false;
                BTN_PREVIEW_START.Enabled = true;
                BTN_PREVIEW_STOP.Enabled = false;
                BTN_CAPTURE.Enabled = false;
                BTN_OPTION.Enabled = true;
                BTN_AUTO_FOCUS.Enabled = false;
            }
        }

        private void AutoFocus_Click(object sender, EventArgs e)
        {
            m_Cam.SetAutoFocus();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

			RegistryKey CamSideBtn = Registry.LocalMachine.CreateSubKey("ControlPanel\\keypad\\SideKey");
			m_CamKeyValue = Convert.ToInt32(CamSideBtn.GetValue("RightUpKey"));	//	초기 설정된 값은 7(RETRUN)이 설정된다 
			if(m_CamKeyValue != 2)
                CamSideBtn.SetValue("RightUpKey", 2, RegistryValueKind.DWord);		//	우리가 사용할 값인 2(VK_F13) 설정한다.


            m_Cam.SHSetAppKey((byte)Keys.F13, Handle);

            m_cameramode = CAMERA_MODE.STILL_MODE;
            m_videotype = VIDEO_TYPE.VIDEO_ASF;
            m_bVideoRun = false;
            m_bPreviewRun = true;
            m_bStillDateSaveMode = true;
            m_bVideoDateSaveMode = true;
            
            m_Cam.Open(this.Handle, m_cameramode, m_videotype);

            m_strStillFolder = "\\My Documents\\My Pictures\\";
            m_strStillFileName = "1.jpg";

            m_strVideoFolder = "\\My Documents\\My Pictures\\";
            m_strVideoFileName = "0.asf";

            if (GetSystemMetrics(0) > 240)
                m_Cam.SetPosition(80, 90, 320, 240);

        }

        private void Form1_Closed(object sender, EventArgs e)
        {
			if (m_CamKeyValue != 2)
			{
				RegistryKey CamSideBtn = Registry.LocalMachine.CreateSubKey("ControlPanel\\keypad\\SideKey");
				CamSideBtn.SetValue("RightUpKey", m_CamKeyValue, RegistryValueKind.DWord);		//	우리가 사용할 값인 0(DEFAULT) 설정한다.
			}
            pn.Stop();
            Camera.Close();//m_Cam.Close();
        }


        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyValue == (byte)Keys.F13)
            {
				if ((m_bWake == false) && m_bPreviewRun)
				{
					CaptureFn();
				}
				else
				{
					if (!m_bCaping)
					{
						// Standby 않보이는 문제 확인
						if (m_cameramode == CAMERA_MODE.STILL_MODE)
							m_cameramode = CAMERA_MODE.VIDEO_MODE;
						else
							m_cameramode = CAMERA_MODE.STILL_MODE;

						ChangeCameraMode();
						m_bWake = false;
						m_bCaping = false;
					}
				}
			}
//	Key Up에 대한 처리도 추가 할것인가?
			

        }

        private void BTN_OPTION_Click(object sender, EventArgs e)
        {
            Option dlg;

            dlg = new Option();

            dlg.m_Cam = this.m_Cam;


            if (m_cameramode == CAMERA_MODE.STILL_MODE)
            {
                dlg.m_bVideo = false;
                dlg.m_strFolder = m_strStillFolder;
                dlg.m_strFileName = m_strStillFileName;
                dlg.m_bDateSaveMode = m_bStillDateSaveMode;
            }
            else
            {
                dlg.m_videotype = m_videotype;
                dlg.m_bVideo = true;

                dlg.m_strFolder = m_strVideoFolder;
                dlg.m_strFileName = m_strVideoFileName;
                dlg.m_bDateSaveMode = m_bVideoDateSaveMode;

            }

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                if (m_cameramode == CAMERA_MODE.STILL_MODE)
                {
                    m_strStillFolder = dlg.m_strFolder;
                    m_strStillFileName = dlg.m_strFileName;
                    m_bStillDateSaveMode = dlg.m_bDateSaveMode;
                }
                else
                {
                    m_videotype = dlg.m_videotype;
                    m_strVideoFolder = dlg.m_strFolder;
                    m_strVideoFileName = dlg.m_strFileName;
                    m_bVideoDateSaveMode = dlg.m_bDateSaveMode;
                }
                m_Cam.Open(this.Handle, m_cameramode, m_videotype);

                m_bPreviewRun = true;
                BTN_PREVIEW_START.Enabled = false;
                BTN_PREVIEW_STOP.Enabled = true;
                BTN_CAPTURE.Enabled = true;
                BTN_OPTION.Enabled = false;
                BTN_AUTO_FOCUS.Enabled = true;
            }
        }

        private void BTN_CAMERA_MODE_Click(object sender, EventArgs e)
        {
            ChangeCameraMode();
        }
        public void ChangeCameraMode()
        {
            if (CAMERA_MODE.VIDEO_MODE == m_cameramode)
            {
                m_cameramode = CAMERA_MODE.STILL_MODE;
                BTN_CAMERA_MODE.Text = "Video Mode";
                BTN_CAPTURE.Text = "Capture";
            }
            else
            {
                m_cameramode = CAMERA_MODE.VIDEO_MODE;
                BTN_CAMERA_MODE.Text = "Still Mode";
                BTN_CAPTURE.Text = "Video Start";
            }
            m_Cam.Open(this.Handle, m_cameramode, m_videotype);

            m_bPreviewRun = true;
            BTN_PREVIEW_START.Enabled = false;
            BTN_PREVIEW_STOP.Enabled = true;
            BTN_CAPTURE.Enabled = true;
            BTN_OPTION.Enabled = false;
            BTN_AUTO_FOCUS.Enabled = true;
        }

        private void CaptureFn()
        {
            if (!m_bCaping)
            {
				m_bCaping = true;   // 카메라는 동작중임 

				if (!m_bPreviewRun)	
                {
                    MessageBox.Show("Click Preview Start Button");
                    return;
                }

                string filefullname;

                switch (m_cameramode)
                {
					case CAMERA_MODE.STILL_MODE:
						BTN_CAPTURE. Enabled = false;
						BTN_PREVIEW_STOP. Enabled = false;
						BTN_AUTO_FOCUS. Enabled = false;

						if (m_bStillDateSaveMode)
						{
							StringBuilder path = new StringBuilder(100);
							m_Cam.Capture(null,path);	// 파일 경로 잘 얻어오는지 확인하기e
//							MessageBox.Show(String.Format("{0}", path));
						}
						else
						{
							filefullname = m_strStillFolder + m_strStillFileName;
							m_Cam.Capture(filefullname);
						}
						// file full name : \My Documents\My Pictures\(DATE).jpg 		
						//m_Cam.Capture("\\My Documents\\My Pictures\\11.jpg");

						m_bWake = true;
						break;

						case CAMERA_MODE.VIDEO_MODE:
							if (!m_bVideoRun)
							{
//								BTN_CAPTURE.Enabled = false;
								BTN_PREVIEW_START.Enabled = false;
								BTN_PREVIEW_STOP.Enabled = false;

								if (m_bVideoDateSaveMode)
								{
									m_Cam.Video_Start(null);	// file full name :\My Documents\My Pictures\\(DATE).wmv
									//m_Cam.Video_Start(L"My Documents\\aaa.wmv");
								}
								else
								{
									filefullname = m_strVideoFolder + m_strVideoFileName;
									m_Cam.Video_Start(filefullname);
								}
							BTN_CAPTURE.Text = "Video Stop";
							BTN_PREVIEW_STOP.Enabled = false;
							m_bVideoRun = true;

							}
							else
							{
								BTN_CAPTURE.Enabled = false;
								BTN_PREVIEW_STOP.Enabled = false;
								BTN_AUTO_FOCUS.Enabled = false;

								m_Cam.Video_Stop();
								Camera.Close();
								m_bWake = true;
								BTN_CAPTURE.Text = "Video Start";
								m_bVideoRun = false;
							}
							break;

                }
                m_bCaping = false;
            }
        }
        private void BTN_CAPTURE_Click(object sender, EventArgs e)
        {
            CaptureFn();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (m_bWake)
            {
                LABEL_STAND.Hide();
                m_bCaping = false;

                if (m_cameramode == CAMERA_MODE.STILL_MODE)
                    m_cameramode = CAMERA_MODE.VIDEO_MODE;
                else
                    m_cameramode = CAMERA_MODE.STILL_MODE;

                ChangeCameraMode();

            }
            m_bWake = false;
        }

        [DllImport("coredll.dll")]
        private static extern bool SystemParametersInfo(UInt32 uiAction, UInt32 uiParam, StringBuilder pvParam, UInt32 fWinIni);

        [DllImport("coredll.dll")]
        static extern int GetSystemMetrics(int smIndex);

        private void menuItem_Ok_Click(object sender, EventArgs e)
        {
            Close();
        }


        
    }



    public class Camera
    {



        [DllImport("aygshell.dll")]
        private static extern bool SHSetAppKeyWndAssoc(byte bVk, IntPtr hMainWnd);

        [DllImport("M3SkyCamera.dll")]
        private static extern bool OpenCamera(IntPtr hMainWnd, CAMERA_MODE cameramode, VIDEO_TYPE videotype);

        [DllImport("M3SkyCamera.dll")]
        private static extern void CloseCamera();

        [DllImport("M3SkyCamera.dll")]
        private static extern bool SetWindowPosition(int left, int top, int width, int height);

        [DllImport("M3SkyCamera.dll")]
        private static extern bool PreviewStart();

        [DllImport("M3SkyCamera.dll")]
        private static extern bool PreviewStop();

        [DllImport("M3SkyCamera.dll")]
        private static extern bool VideoStart(string FileFULLName);

        [DllImport("M3SkyCamera.dll")]
        private static extern bool VideoStop();

        [DllImport("M3SkyCamera.dll")]
        private static extern string CaptureStill(string FileFULLName);

		[DllImport("M3SkyCamera.dll")]
		private static extern void captureStill(string FileFULLName, StringBuilder strInfo);

        [DllImport("M3SkyCamera.dll")]
        private static extern bool FlashOn(bool on);


        [DllImport("M3SkyCamera.dll")]
        private static extern bool SetResolution(int PinType, int nResolution);

        [DllImport("M3SkyCamera.dll")]
        private static extern bool SetBrightness(long value);

        [DllImport("M3SkyCamera.dll")]
        private static extern bool SetWhiteBalance(long value);

        [DllImport("M3SkyCamera.dll")]
        private static extern bool AutoFocus();

        [DllImport("M3SkyCamera.dll")]
        private static extern int GetResolution(int PinType);

        [DllImport("M3SkyCamera.dll")]
        private static extern int GetBrightness();

        [DllImport("M3SkyCamera.dll")]
        private static extern int GetWhiteBalance();

        [DllImport("M3SkyCamera.dll")]
        private static extern string GetInfo();

		[DllImport("M3SkyCamera.dll")]
		private static extern void getInfo(StringBuilder strInfo);

        [DllImport("M3SkyCamera.dll")]
        private static extern void SetQuality(int value);

        [DllImport("M3SkyCamera.dll")]
        private static extern int GetQuality();

        //////////////////////////////////////////////////////////////////////////
        //  [11/7/2008 vision7901]
        
        [DllImport("M3SkyCamera.dll")]
        private static extern bool GetHisto(ref bool pbHistoEqual);
        [DllImport("M3SkyCamera.dll")]
        private static extern bool GetNightLevel(ref int pNightLevel);
        [DllImport("M3SkyCamera.dll")]
        private static extern void EnableHistoEqual(bool Enable, int NightLevel);

        public bool GetHistogram(ref bool pbHisto)
        {
            return GetHisto(ref pbHisto);
        }
        public bool GetNight(ref int pNight)
        {
            return GetNightLevel(ref pNight);
        }
        public void EnableHisto(bool HistoEqul, int NightLevel)
        {
            EnableHistoEqual(HistoEqul, NightLevel);
        }

        //////////////////////////////////////////////////////////////////////////


        public bool SHSetAppKey(byte bVk, IntPtr hMainWnd)
        {
            return SHSetAppKeyWndAssoc(bVk, hMainWnd);
        }

        public bool SetAutoFocus()
        {
            return AutoFocus();
        }

        public bool Open(IntPtr hMainWnd, CAMERA_MODE cameramode, VIDEO_TYPE videotype)
        {
            return OpenCamera(hMainWnd, cameramode, videotype);
        }

        public static void Close()
        {
            CloseCamera();
        }

        public bool SetPosition(int left, int top, int width, int height)
        {
            return SetWindowPosition(left, top, width, height);
        }
        public bool Preview_Start()
        {
            return PreviewStart();
        }

        public bool Preview_Stop()
        {
            return PreviewStop();
        }


        public bool Video_Start(string FileFullName)
        {
            return VideoStart(FileFullName);
        }

        public bool Video_Stop()
        {
            return VideoStop();
        }

        public string Capture(string FileFULLName)
        {
            return CaptureStill(FileFULLName);
        }

		public void Capture(string FileFULLName, StringBuilder info)
		{
			captureStill(FileFULLName, info);
		}


        public bool Flash_On(bool on)
        {
            return FlashOn(on);
        }

        public int Get_Resolution(int PinType)
        {
            return GetResolution(PinType);
        }

        public bool Set_Resolution(int PinType, int nResolution)
        {
            return SetResolution(PinType, nResolution);
        }

        public int Get_Brightness()
        {
            return GetBrightness();
        }

        public bool Set_Brightness(long value)
        {
            return SetBrightness(value);
        }

        public int Get_WhiteBalance()
        {
            return GetWhiteBalance();
        }

        public bool Set_WhiteBalance(long value)
        {
            return SetWhiteBalance(value);
        }

        public string Get_Info()
        {
            return GetInfo();
        }

		public void Get_Info(StringBuilder info)
		{
			getInfo(info);
		}
        
        public void Set_Quality(int value)
        {
            SetQuality(value);
        }

        public int Get_Quality()
        {
            return GetQuality();
        }
    }

	public class CatchCallback : MessageWindow
	{
		public const int WM_USER = 0x400;
		public const int WM_CALLBACK_MESSAGE = WM_USER + 0;

		private Form1 container;

		public CatchCallback(Form1 container)
		{
			this.container = container;
		}
		protected override void WndProc(ref Message msg)
		{
			switch (msg.Msg)
			{
				case WM_CALLBACK_MESSAGE:
					container.DisableButton((int)msg.WParam, (int)msg.LParam);
					break;
			}
			base.WndProc(ref msg);
		}

	}




    public class PowerNotifications
    {
		IntPtr hWnd;

        IntPtr ptr = IntPtr.Zero;
        Thread t = null;
        bool done = false;

		public const int WM_USER = 0x400;
		public const int WM_CALLBACK_MESSAGE = WM_USER + 144;

        
        public System.Windows.Forms.Label stanby;

		[DllImport("coredll.dll")]
		private static extern int SendMessage(IntPtr Hwnd, int Msg, int wParam, int lParam);

        [DllImport("coredll.dll")]
        private static extern IntPtr RequestPowerNotifications(IntPtr hMsgQ, uint Flags);

        [DllImport("coredll.dll")]
        private static extern uint WaitForSingleObject(IntPtr hHandle, int wait);

        [DllImport("coredll.dll")]
        private static extern IntPtr CreateMsgQueue(string name, ref MsgQOptions options);

        [DllImport("coredll.dll")]
        private static extern bool ReadMsgQueue(IntPtr hMsgQ, byte[] lpBuffer, uint cbBufSize, ref uint lpNumRead, int dwTimeout, ref uint pdwFlags);

        public PowerNotifications(IntPtr handle)
        {
            MsgQOptions options = new MsgQOptions();
            options.dwFlags = 0;
            options.dwMaxMessages = 20;
            options.cbMaxMessage = 10000;
            options.bReadAccess = true;
            options.dwSize = (uint)System.Runtime.InteropServices.Marshal.SizeOf(options);
            ptr = CreateMsgQueue("Test", ref options);
            RequestPowerNotifications(ptr, 0xFFFFFFFF);
            t = new Thread(new ThreadStart(DoWork));
			hWnd = handle;

        }

        public void Start()
        {
            t.Start();
        }

        public void Stop()
        {
            done = true;
            t.Abort();
        }

        private void DoWork()
        {
            byte[] buf = new byte[10000];
            uint nRead = 0, flags = 0, res = 0;

            //           Console.WriteLine("starting loop");
            try
            {
                while (!done)
                {
                    res = WaitForSingleObject(ptr, 1000);
                    if (res == 0)
                    {
                        ReadMsgQueue(ptr, buf, (uint)buf.Length, ref nRead, -1, ref flags);

                        uint msgvalue = ConvertByteArray(buf, 0);


                        if (msgvalue == 0x00000002) //  RESUME
                        { 
                            Camera.Close();
                            Form1.m_bWake = true;
							Form1.m_bCaping = false;
							SendMessage(hWnd, CatchCallback.WM_CALLBACK_MESSAGE, 0, 0);
							
                        }
                        uint flag = ConvertByteArray(buf, 4);

                        string msg = null;
                        switch (flag)
                        {
                            case 65536:
                                msg = "******Power On";
                                break;
                            case 131072:
								msg = "******Power Off";
                                break;
                            case 262144:
								msg = "******Power Critical";
                                break;
                            case 524288:
								msg = "******Power Boot";
                                break;
                            case 1048576:
								msg = "******Power Idle";
                                break;
                            case 2097152:
								msg = "******Power Suspend";
								Form1.m_bCaping = true;
                                break;
                            case 8388608:
								msg = "******Power Reset";
                                break;
                            case 0:
                                // non power transition messages are ignored
                                break;
                            default:
								msg = "******Unknown Flag: " + flag;
                                break;
                        }
                        if (msg != null)
                            Console.WriteLine(msg);



                    }
                }
            }
            catch (Exception ex)
            {
                if (!done)
                {
                    Console.WriteLine("Got exception: " + ex.ToString());
                }
            }
        }

        uint ConvertByteArray(byte[] array, int offset)
        {
            uint res = 0;
            res += array[offset];
            res += array[offset + 1] * (uint)0x100;
            res += array[offset + 2] * (uint)0x10000;
            res += array[offset + 3] * (uint)0x1000000;
            return res;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct MsgQOptions
        {
            public uint dwSize;
            public uint dwFlags;
            public uint dwMaxMessages;
            public uint cbMaxMessage;
            public bool bReadAccess;
        }
    }

}
