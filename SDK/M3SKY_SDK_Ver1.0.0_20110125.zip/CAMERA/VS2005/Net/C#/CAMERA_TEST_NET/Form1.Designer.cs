﻿namespace CameraNet
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.mainMenu = new System.Windows.Forms.MainMenu();
            this.BTN_FLASH_ON = new System.Windows.Forms.Button();
            this.BTN_FLASH_OFF = new System.Windows.Forms.Button();
            this.BTN_PREVIEW_START = new System.Windows.Forms.Button();
            this.BTN_PREVIEW_STOP = new System.Windows.Forms.Button();
            this.BTN_AUTO_FOCUS = new System.Windows.Forms.Button();
            this.BTN_CAPTURE = new System.Windows.Forms.Button();
            this.BTN_OPTION = new System.Windows.Forms.Button();
            this.BTN_CAMERA_MODE = new System.Windows.Forms.Button();
            this.LABEL_STAND = new System.Windows.Forms.Label();
            this.menuItem_Ok = new System.Windows.Forms.MenuItem();
            this.SuspendLayout();
            // 
            // mainMenu
            // 
            this.mainMenu.MenuItems.Add(this.menuItem_Ok);
            // 
            // BTN_FLASH_ON
            // 
            this.BTN_FLASH_ON.Location = new System.Drawing.Point(3, 229);
            this.BTN_FLASH_ON.Name = "BTN_FLASH_ON";
            this.BTN_FLASH_ON.Size = new System.Drawing.Size(116, 18);
            this.BTN_FLASH_ON.TabIndex = 0;
            this.BTN_FLASH_ON.Text = "Flash On";
            this.BTN_FLASH_ON.Click += new System.EventHandler(this.FlashOn_Click);
            // 
            // BTN_FLASH_OFF
            // 
            this.BTN_FLASH_OFF.Location = new System.Drawing.Point(121, 229);
            this.BTN_FLASH_OFF.Name = "BTN_FLASH_OFF";
            this.BTN_FLASH_OFF.Size = new System.Drawing.Size(116, 18);
            this.BTN_FLASH_OFF.TabIndex = 1;
            this.BTN_FLASH_OFF.Text = "Flash Off";
            this.BTN_FLASH_OFF.Click += new System.EventHandler(this.FlashOff_Click);
            // 
            // BTN_PREVIEW_START
            // 
            this.BTN_PREVIEW_START.Enabled = false;
            this.BTN_PREVIEW_START.Location = new System.Drawing.Point(3, 210);
            this.BTN_PREVIEW_START.Name = "BTN_PREVIEW_START";
            this.BTN_PREVIEW_START.Size = new System.Drawing.Size(116, 18);
            this.BTN_PREVIEW_START.TabIndex = 2;
            this.BTN_PREVIEW_START.Text = "Preview Start";
            this.BTN_PREVIEW_START.Click += new System.EventHandler(this.Start_Click);
            // 
            // BTN_PREVIEW_STOP
            // 
            this.BTN_PREVIEW_STOP.Location = new System.Drawing.Point(121, 210);
            this.BTN_PREVIEW_STOP.Name = "BTN_PREVIEW_STOP";
            this.BTN_PREVIEW_STOP.Size = new System.Drawing.Size(116, 18);
            this.BTN_PREVIEW_STOP.TabIndex = 3;
            this.BTN_PREVIEW_STOP.Text = "Preview Stop";
            this.BTN_PREVIEW_STOP.Click += new System.EventHandler(this.Stop_Click);
            // 
            // BTN_AUTO_FOCUS
            // 
            this.BTN_AUTO_FOCUS.Location = new System.Drawing.Point(3, 248);
            this.BTN_AUTO_FOCUS.Name = "BTN_AUTO_FOCUS";
            this.BTN_AUTO_FOCUS.Size = new System.Drawing.Size(116, 18);
            this.BTN_AUTO_FOCUS.TabIndex = 6;
            this.BTN_AUTO_FOCUS.Text = "AutoFocus";
            this.BTN_AUTO_FOCUS.Visible = false;
            this.BTN_AUTO_FOCUS.Click += new System.EventHandler(this.AutoFocus_Click);
            // 
            // BTN_CAPTURE
            // 
            this.BTN_CAPTURE.Location = new System.Drawing.Point(3, 191);
            this.BTN_CAPTURE.Name = "BTN_CAPTURE";
            this.BTN_CAPTURE.Size = new System.Drawing.Size(116, 18);
            this.BTN_CAPTURE.TabIndex = 7;
            this.BTN_CAPTURE.Text = "Capture";
            this.BTN_CAPTURE.Click += new System.EventHandler(this.BTN_CAPTURE_Click);
            // 
            // BTN_OPTION
            // 
            this.BTN_OPTION.Enabled = false;
            this.BTN_OPTION.Location = new System.Drawing.Point(121, 191);
            this.BTN_OPTION.Name = "BTN_OPTION";
            this.BTN_OPTION.Size = new System.Drawing.Size(116, 18);
            this.BTN_OPTION.TabIndex = 8;
            this.BTN_OPTION.Text = "Option";
            this.BTN_OPTION.Click += new System.EventHandler(this.BTN_OPTION_Click);
            // 
            // BTN_CAMERA_MODE
            // 
            this.BTN_CAMERA_MODE.Location = new System.Drawing.Point(121, 248);
            this.BTN_CAMERA_MODE.Name = "BTN_CAMERA_MODE";
            this.BTN_CAMERA_MODE.Size = new System.Drawing.Size(116, 18);
            this.BTN_CAMERA_MODE.TabIndex = 9;
            this.BTN_CAMERA_MODE.Text = "Still Mode";
            this.BTN_CAMERA_MODE.Click += new System.EventHandler(this.BTN_CAMERA_MODE_Click);
            // 
            // LABEL_STAND
            // 
            this.LABEL_STAND.Location = new System.Drawing.Point(94, 79);
            this.LABEL_STAND.Name = "LABEL_STAND";
            this.LABEL_STAND.Size = new System.Drawing.Size(52, 20);
            this.LABEL_STAND.Text = "Standby";
            this.LABEL_STAND.Visible = false;
            // 
            // menuItem_Ok
            // 
            this.menuItem_Ok.Text = "OK";
            this.menuItem_Ok.Click += new System.EventHandler(this.menuItem_Ok_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(256, 284);
            this.Controls.Add(this.LABEL_STAND);
            this.Controls.Add(this.BTN_CAMERA_MODE);
            this.Controls.Add(this.BTN_OPTION);
            this.Controls.Add(this.BTN_CAPTURE);
            this.Controls.Add(this.BTN_AUTO_FOCUS);
            this.Controls.Add(this.BTN_PREVIEW_STOP);
            this.Controls.Add(this.BTN_PREVIEW_START);
            this.Controls.Add(this.BTN_FLASH_OFF);
            this.Controls.Add(this.BTN_FLASH_ON);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Menu = this.mainMenu;
            this.Name = "Form1";
            this.Text = "Camera";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Closed += new System.EventHandler(this.Form1_Closed);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BTN_FLASH_ON;
        private System.Windows.Forms.Button BTN_FLASH_OFF;
        private System.Windows.Forms.Button BTN_PREVIEW_START;
        private System.Windows.Forms.Button BTN_PREVIEW_STOP;
        private System.Windows.Forms.Button BTN_AUTO_FOCUS;
        private System.Windows.Forms.Button BTN_CAPTURE;
        private System.Windows.Forms.Button BTN_OPTION;
        private System.Windows.Forms.Button BTN_CAMERA_MODE;
        private System.Windows.Forms.Label LABEL_STAND;
        private System.Windows.Forms.MenuItem menuItem_Ok;
    }
}

