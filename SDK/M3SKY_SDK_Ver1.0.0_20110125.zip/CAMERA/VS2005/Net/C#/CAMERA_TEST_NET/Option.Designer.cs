﻿namespace CameraNet
{
    partial class Option
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.LABEL_BRIGHT = new System.Windows.Forms.Label();
			this.LABEL_RESOLUTION = new System.Windows.Forms.Label();
			this.LABEL_WHITE_BALANCE = new System.Windows.Forms.Label();
			this.LABEL_SAVE_MODE = new System.Windows.Forms.Label();
			this.LABEL_SAVE_FOLDER = new System.Windows.Forms.Label();
			this.LABEL_SAVE_NAME = new System.Windows.Forms.Label();
			this.LABEL_VIDEO_TYPE = new System.Windows.Forms.Label();
			this.CBOX_BRIGHT = new System.Windows.Forms.ComboBox();
			this.CBOX_RESOLUTION = new System.Windows.Forms.ComboBox();
			this.CBOX_WHITE_BALANCE = new System.Windows.Forms.ComboBox();
			this.CBOX_SAVE_MODE = new System.Windows.Forms.ComboBox();
			this.CBOX_VIDEO_TYPE = new System.Windows.Forms.ComboBox();
			this.TBOX_SAVE_FOLDER = new System.Windows.Forms.TextBox();
			this.TBOX_SAVE_NAME = new System.Windows.Forms.TextBox();
			this.BTN_OK = new System.Windows.Forms.Button();
			this.BTN_CANCEL = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.CBOX_QUALITY = new System.Windows.Forms.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this.CHECK_HISTOEQUAL = new System.Windows.Forms.CheckBox();
			this.LABEL_LEVEL = new System.Windows.Forms.Label();
			this.NUM_NIGHTLEVEL = new System.Windows.Forms.NumericUpDown();
			this.label_Version = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// LABEL_BRIGHT
			// 
			this.LABEL_BRIGHT.Location = new System.Drawing.Point(24, 30);
			this.LABEL_BRIGHT.Name = "LABEL_BRIGHT";
			this.LABEL_BRIGHT.Size = new System.Drawing.Size(73, 20);
			this.LABEL_BRIGHT.Text = "Brightness :";
			this.LABEL_BRIGHT.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// LABEL_RESOLUTION
			// 
			this.LABEL_RESOLUTION.Location = new System.Drawing.Point(24, 55);
			this.LABEL_RESOLUTION.Name = "LABEL_RESOLUTION";
			this.LABEL_RESOLUTION.Size = new System.Drawing.Size(73, 20);
			this.LABEL_RESOLUTION.Text = "Resolution :";
			this.LABEL_RESOLUTION.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// LABEL_WHITE_BALANCE
			// 
			this.LABEL_WHITE_BALANCE.Location = new System.Drawing.Point(6, 80);
			this.LABEL_WHITE_BALANCE.Name = "LABEL_WHITE_BALANCE";
			this.LABEL_WHITE_BALANCE.Size = new System.Drawing.Size(91, 20);
			this.LABEL_WHITE_BALANCE.Text = "White Balance :";
			this.LABEL_WHITE_BALANCE.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// LABEL_SAVE_MODE
			// 
			this.LABEL_SAVE_MODE.Location = new System.Drawing.Point(20, 105);
			this.LABEL_SAVE_MODE.Name = "LABEL_SAVE_MODE";
			this.LABEL_SAVE_MODE.Size = new System.Drawing.Size(77, 20);
			this.LABEL_SAVE_MODE.Text = "Save Mode :";
			this.LABEL_SAVE_MODE.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// LABEL_SAVE_FOLDER
			// 
			this.LABEL_SAVE_FOLDER.Location = new System.Drawing.Point(14, 155);
			this.LABEL_SAVE_FOLDER.Name = "LABEL_SAVE_FOLDER";
			this.LABEL_SAVE_FOLDER.Size = new System.Drawing.Size(83, 20);
			this.LABEL_SAVE_FOLDER.Text = "Save Folder :";
			this.LABEL_SAVE_FOLDER.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// LABEL_SAVE_NAME
			// 
			this.LABEL_SAVE_NAME.Location = new System.Drawing.Point(14, 177);
			this.LABEL_SAVE_NAME.Name = "LABEL_SAVE_NAME";
			this.LABEL_SAVE_NAME.Size = new System.Drawing.Size(83, 20);
			this.LABEL_SAVE_NAME.Text = "Save Name :";
			this.LABEL_SAVE_NAME.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// LABEL_VIDEO_TYPE
			// 
			this.LABEL_VIDEO_TYPE.Location = new System.Drawing.Point(14, 200);
			this.LABEL_VIDEO_TYPE.Name = "LABEL_VIDEO_TYPE";
			this.LABEL_VIDEO_TYPE.Size = new System.Drawing.Size(83, 20);
			this.LABEL_VIDEO_TYPE.Text = "Video Type :";
			this.LABEL_VIDEO_TYPE.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// CBOX_BRIGHT
			// 
			this.CBOX_BRIGHT.Items.Add("+3");
			this.CBOX_BRIGHT.Items.Add("+2");
			this.CBOX_BRIGHT.Items.Add("+1");
			this.CBOX_BRIGHT.Items.Add("0");
			this.CBOX_BRIGHT.Items.Add("-1");
			this.CBOX_BRIGHT.Items.Add("-2");
			this.CBOX_BRIGHT.Items.Add("-3");
			this.CBOX_BRIGHT.Location = new System.Drawing.Point(102, 28);
			this.CBOX_BRIGHT.Name = "CBOX_BRIGHT";
			this.CBOX_BRIGHT.Size = new System.Drawing.Size(129, 22);
			this.CBOX_BRIGHT.TabIndex = 7;
			// 
			// CBOX_RESOLUTION
			// 
			this.CBOX_RESOLUTION.Location = new System.Drawing.Point(103, 53);
			this.CBOX_RESOLUTION.Name = "CBOX_RESOLUTION";
			this.CBOX_RESOLUTION.Size = new System.Drawing.Size(128, 22);
			this.CBOX_RESOLUTION.TabIndex = 8;
			// 
			// CBOX_WHITE_BALANCE
			// 
			this.CBOX_WHITE_BALANCE.Items.Add("Auto");
			this.CBOX_WHITE_BALANCE.Items.Add("Sunny");
			this.CBOX_WHITE_BALANCE.Items.Add("Cloudy");
			this.CBOX_WHITE_BALANCE.Items.Add("Fluorescent");
			this.CBOX_WHITE_BALANCE.Items.Add("Incandescent");
			this.CBOX_WHITE_BALANCE.Location = new System.Drawing.Point(103, 78);
			this.CBOX_WHITE_BALANCE.Name = "CBOX_WHITE_BALANCE";
			this.CBOX_WHITE_BALANCE.Size = new System.Drawing.Size(128, 22);
			this.CBOX_WHITE_BALANCE.TabIndex = 9;
			// 
			// CBOX_SAVE_MODE
			// 
			this.CBOX_SAVE_MODE.Items.Add("Date Mode");
			this.CBOX_SAVE_MODE.Items.Add("Custom Mode");
			this.CBOX_SAVE_MODE.Location = new System.Drawing.Point(103, 103);
			this.CBOX_SAVE_MODE.Name = "CBOX_SAVE_MODE";
			this.CBOX_SAVE_MODE.Size = new System.Drawing.Size(128, 22);
			this.CBOX_SAVE_MODE.TabIndex = 10;
			this.CBOX_SAVE_MODE.SelectedIndexChanged += new System.EventHandler(this.CBOX_SAVE_MODE_SelectedIndexChanged);
			// 
			// CBOX_VIDEO_TYPE
			// 
			this.CBOX_VIDEO_TYPE.Items.Add("WMV");
			this.CBOX_VIDEO_TYPE.Items.Add("ASF");
			this.CBOX_VIDEO_TYPE.Location = new System.Drawing.Point(103, 199);
			this.CBOX_VIDEO_TYPE.Name = "CBOX_VIDEO_TYPE";
			this.CBOX_VIDEO_TYPE.Size = new System.Drawing.Size(128, 22);
			this.CBOX_VIDEO_TYPE.TabIndex = 11;
			// 
			// TBOX_SAVE_FOLDER
			// 
			this.TBOX_SAVE_FOLDER.Location = new System.Drawing.Point(103, 151);
			this.TBOX_SAVE_FOLDER.Name = "TBOX_SAVE_FOLDER";
			this.TBOX_SAVE_FOLDER.Size = new System.Drawing.Size(128, 21);
			this.TBOX_SAVE_FOLDER.TabIndex = 12;
			this.TBOX_SAVE_FOLDER.TextChanged += new System.EventHandler(this.TBOX_SAVE_FOLDER_TextChanged);
			// 
			// TBOX_SAVE_NAME
			// 
			this.TBOX_SAVE_NAME.Location = new System.Drawing.Point(103, 175);
			this.TBOX_SAVE_NAME.Name = "TBOX_SAVE_NAME";
			this.TBOX_SAVE_NAME.Size = new System.Drawing.Size(128, 21);
			this.TBOX_SAVE_NAME.TabIndex = 13;
			// 
			// BTN_OK
			// 
			this.BTN_OK.Location = new System.Drawing.Point(6, 271);
			this.BTN_OK.Name = "BTN_OK";
			this.BTN_OK.Size = new System.Drawing.Size(109, 22);
			this.BTN_OK.TabIndex = 14;
			this.BTN_OK.Text = "OK";
			this.BTN_OK.Click += new System.EventHandler(this.BTN_OK_Click);
			// 
			// BTN_CANCEL
			// 
			this.BTN_CANCEL.Location = new System.Drawing.Point(123, 271);
			this.BTN_CANCEL.Name = "BTN_CANCEL";
			this.BTN_CANCEL.Size = new System.Drawing.Size(109, 22);
			this.BTN_CANCEL.TabIndex = 15;
			this.BTN_CANCEL.Text = "Cancel";
			this.BTN_CANCEL.Click += new System.EventHandler(this.BTN_CANCEL_Click_1);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(6, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(118, 20);
			this.label1.Text = "compression level :";
			// 
			// CBOX_QUALITY
			// 
			this.CBOX_QUALITY.Items.Add("Low quality");
			this.CBOX_QUALITY.Items.Add("Normal quality");
			this.CBOX_QUALITY.Items.Add("High quality");
			this.CBOX_QUALITY.Location = new System.Drawing.Point(131, 4);
			this.CBOX_QUALITY.Name = "CBOX_QUALITY";
			this.CBOX_QUALITY.Size = new System.Drawing.Size(100, 22);
			this.CBOX_QUALITY.TabIndex = 24;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(25, 128);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(72, 20);
			this.label2.Text = "Night Mode";
			// 
			// CHECK_HISTOEQUAL
			// 
			this.CHECK_HISTOEQUAL.Location = new System.Drawing.Point(102, 129);
			this.CHECK_HISTOEQUAL.Name = "CHECK_HISTOEQUAL";
			this.CHECK_HISTOEQUAL.Size = new System.Drawing.Size(19, 16);
			this.CHECK_HISTOEQUAL.TabIndex = 34;
			this.CHECK_HISTOEQUAL.CheckStateChanged += new System.EventHandler(this.CHECK_HISTOEQUAL_CheckStateChanged);
			// 
			// LABEL_LEVEL
			// 
			this.LABEL_LEVEL.Location = new System.Drawing.Point(132, 129);
			this.LABEL_LEVEL.Name = "LABEL_LEVEL";
			this.LABEL_LEVEL.Size = new System.Drawing.Size(35, 19);
			this.LABEL_LEVEL.Text = "Level";
			// 
			// NUM_NIGHTLEVEL
			// 
			this.NUM_NIGHTLEVEL.Location = new System.Drawing.Point(174, 128);
			this.NUM_NIGHTLEVEL.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
			this.NUM_NIGHTLEVEL.Name = "NUM_NIGHTLEVEL";
			this.NUM_NIGHTLEVEL.Size = new System.Drawing.Size(56, 22);
			this.NUM_NIGHTLEVEL.TabIndex = 48;
			// 
			// label_Version
			// 
			this.label_Version.Location = new System.Drawing.Point(11, 224);
			this.label_Version.Name = "label_Version";
			this.label_Version.Size = new System.Drawing.Size(220, 44);
			// 
			// Option
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
			this.AutoScroll = true;
			this.ClientSize = new System.Drawing.Size(240, 294);
			this.Controls.Add(this.label_Version);
			this.Controls.Add(this.NUM_NIGHTLEVEL);
			this.Controls.Add(this.LABEL_LEVEL);
			this.Controls.Add(this.CHECK_HISTOEQUAL);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.CBOX_QUALITY);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.BTN_CANCEL);
			this.Controls.Add(this.BTN_OK);
			this.Controls.Add(this.TBOX_SAVE_NAME);
			this.Controls.Add(this.TBOX_SAVE_FOLDER);
			this.Controls.Add(this.CBOX_VIDEO_TYPE);
			this.Controls.Add(this.CBOX_SAVE_MODE);
			this.Controls.Add(this.CBOX_WHITE_BALANCE);
			this.Controls.Add(this.CBOX_RESOLUTION);
			this.Controls.Add(this.CBOX_BRIGHT);
			this.Controls.Add(this.LABEL_VIDEO_TYPE);
			this.Controls.Add(this.LABEL_SAVE_NAME);
			this.Controls.Add(this.LABEL_SAVE_FOLDER);
			this.Controls.Add(this.LABEL_SAVE_MODE);
			this.Controls.Add(this.LABEL_WHITE_BALANCE);
			this.Controls.Add(this.LABEL_RESOLUTION);
			this.Controls.Add(this.LABEL_BRIGHT);
			this.Name = "Option";
			this.Text = "Option";
			this.Load += new System.EventHandler(this.Option_Load);
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label LABEL_BRIGHT;
        private System.Windows.Forms.Label LABEL_RESOLUTION;
        private System.Windows.Forms.Label LABEL_WHITE_BALANCE;
        private System.Windows.Forms.Label LABEL_SAVE_MODE;
        private System.Windows.Forms.Label LABEL_SAVE_FOLDER;
        private System.Windows.Forms.Label LABEL_SAVE_NAME;
        private System.Windows.Forms.Label LABEL_VIDEO_TYPE;
        private System.Windows.Forms.ComboBox CBOX_BRIGHT;
        private System.Windows.Forms.ComboBox CBOX_RESOLUTION;
        private System.Windows.Forms.ComboBox CBOX_WHITE_BALANCE;
        private System.Windows.Forms.ComboBox CBOX_SAVE_MODE;
        private System.Windows.Forms.ComboBox CBOX_VIDEO_TYPE;
        private System.Windows.Forms.TextBox TBOX_SAVE_FOLDER;
        private System.Windows.Forms.TextBox TBOX_SAVE_NAME;
        private System.Windows.Forms.Button BTN_OK;
        private System.Windows.Forms.Button BTN_CANCEL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CBOX_QUALITY;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox CHECK_HISTOEQUAL;
        private System.Windows.Forms.Label LABEL_LEVEL;
        private System.Windows.Forms.NumericUpDown NUM_NIGHTLEVEL;
		private System.Windows.Forms.Label label_Version;

    }
}