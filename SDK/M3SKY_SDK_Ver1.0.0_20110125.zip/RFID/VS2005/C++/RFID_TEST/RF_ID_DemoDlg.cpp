//////////////////////////////////////////////////////////////////////////
// RF_ID_Demo 
// v.1.1.1	2010-12-16 JJ Continuous Serial Read �߰� (���� ���� ����)
//
//////////////////////////////////////////////////////////////////////////
// RF_ID_DemoDlg.cpp : implementation file
//


#include "stdafx.h"
#include "RF_ID_Demo.h"
#include "RF_ID_DemoDlg.h"
#include "Msgqueue.h"
#include "Pm.h"
#include "CFReaderLib.h"


#define QUEUE_ENTRIES   3
#define MAX_NAMELEN     200
#define QUEUE_SIZE      (QUEUE_ENTRIES * (sizeof(POWER_BROADCAST) + MAX_NAMELEN))


UINT PowerStatusThreadFunc(LPVOID pParam);


// CRF_ID_DemoDlg

IMPLEMENT_DYNAMIC(CRF_ID_DemoDlg, CPropertySheet)

CRF_ID_DemoDlg::CRF_ID_DemoDlg(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{

}

CRF_ID_DemoDlg::CRF_ID_DemoDlg(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	AddPage(&m_ReadWrite);
	AddPage(&m_Option);	

	m_nRightUpKey, m_nRightDownKey, m_nLeftUpKey, m_nLeftDownKey, m_nSoft1Key, m_nSoft2Key = 0;

	HKEY hKey;
	int nRet;
//	DWORD dwDisp;
	DWORD value;
	DWORD size;
	DWORD Reg;
	Reg = REG_DWORD;
	size = sizeof(DWORD);

	// Get Key each key type
	int nKeypadType = GetKeypadType();
	if(nKeypadType == KEY_SKY_ORIGINAL)
		nRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"ControlPanel\\keypad\\SideKey", 0, NULL, &hKey);
	else if(nKeypadType == KEY_SKY_SUMMIT_NUMERIC)
		nRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"ControlPanel\\keypad\\Numeric", 0, NULL, &hKey);
	else if(nKeypadType == KEY_SKY_SUMMIT_QWERTY)
		nRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"ControlPanel\\keypad\\qwerty", 0, NULL, &hKey);

	if(nRet != ERROR_SUCCESS)
	{
		AfxMessageBox(_T("Button Set Fail"));
		return;
	}

	nRet = RegQueryValueEx(hKey, L"RightUpKey", NULL, NULL, (LPBYTE)&value, &size);
	if(nRet != ERROR_SUCCESS)
	{
		AfxMessageBox(_T("Button Set Fail"));
		return;
	}

	m_nRightUpKey = value;

	nRet = RegQueryValueEx(hKey, L"RightDownKey", NULL, NULL, (LPBYTE)&value, &size);
	if(nRet != ERROR_SUCCESS)
	{
		AfxMessageBox(_T("Button Set Fail"));
		return;
	}

	m_nRightDownKey = value;

	nRet = RegQueryValueEx(hKey, L"LeftUpKey", NULL, NULL, (LPBYTE)&value, &size);
	if(nRet != ERROR_SUCCESS)
	{
		AfxMessageBox(_T("Button Set Fail"));
		return;
	}

	m_nLeftUpKey = value;

	nRet = RegQueryValueEx(hKey, L"LeftDownKey", NULL, NULL, (LPBYTE)&value, &size);
	if(nRet != ERROR_SUCCESS)
	{
		AfxMessageBox(_T("Button Set Fail"));
		return;
	}

	m_nLeftDownKey = value;

	nRet = RegQueryValueEx(hKey, L"Soft1Key", NULL, NULL, (LPBYTE)&value, &size);
	if(nRet != ERROR_SUCCESS)
	{
		AfxMessageBox(_T("Button Set Fail"));
		return;
	}

	m_nSoft1Key = value;

	nRet = RegQueryValueEx(hKey, L"Soft2Key", NULL, NULL, (LPBYTE)&value, &size);
	if(nRet != ERROR_SUCCESS)
	{
		AfxMessageBox(_T("Button Set Fail"));
		return;
	}

	m_nSoft2Key = value;

	if(m_nRightUpKey != 2)
	{
		value = 2;
		RegSetValueEx(hKey, L"RightUpKey", NULL, REG_DWORD, (LPBYTE)&value,sizeof(DWORD));
	}

	if(m_nRightDownKey != 3)
	{
		value = 3;
		RegSetValueEx(hKey, L"RightDownKey", NULL, REG_DWORD, (LPBYTE)&value,sizeof(DWORD));
	}
	RegCloseKey(hKey);		




	InitCommonControls();

	
	m_pWakeUpThread = ::AfxBeginThread(PowerStatusThreadFunc, (LPVOID)this, THREAD_PRIORITY_NORMAL);
	m_pWakeUpThread->m_bAutoDelete = TRUE;

}

CRF_ID_DemoDlg::~CRF_ID_DemoDlg()
{
	HKEY hKey;
	int nRet;
//	DWORD dwDisp;
	DWORD value;
	DWORD size;
	DWORD Reg;
	Reg = REG_DWORD;
	size = sizeof(DWORD);
	// Get Key each key type
	int nKeypadType = GetKeypadType();
	if(nKeypadType == KEY_SKY_ORIGINAL)
		nRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"ControlPanel\\keypad\\SideKey", 0, NULL, &hKey);
	else if(nKeypadType == KEY_SKY_SUMMIT_NUMERIC)
		nRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"ControlPanel\\keypad\\Numeric", 0, NULL, &hKey);
	else if(nKeypadType == KEY_SKY_SUMMIT_QWERTY)
		nRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"ControlPanel\\keypad\\qwerty", 0, NULL, &hKey);

	if(nRet != ERROR_SUCCESS)
	{
		AfxMessageBox(_T("Button Set Fail"));
		return;
	}

	value = m_nLeftUpKey;
	RegSetValueEx(hKey, L"LeftUpKey", NULL, REG_DWORD, (LPBYTE)&value,sizeof(DWORD));

	value = m_nLeftDownKey;
	RegSetValueEx(hKey, L"LeftDownKey", NULL, REG_DWORD, (LPBYTE)&value,sizeof(DWORD));

	value = m_nRightUpKey;
	RegSetValueEx(hKey, L"RightUpKey", NULL, REG_DWORD, (LPBYTE)&value,sizeof(DWORD));

	value = m_nRightDownKey;
	RegSetValueEx(hKey, L"RightDownKey", NULL, REG_DWORD, (LPBYTE)&value,sizeof(DWORD));

	value = m_nSoft1Key;
	RegSetValueEx(hKey, L"Soft1Key", NULL, REG_DWORD, (LPBYTE)&value,sizeof(DWORD));

	value = m_nSoft2Key;
	RegSetValueEx(hKey, L"Soft2Key", NULL, REG_DWORD, (LPBYTE)&value,sizeof(DWORD));
	RegCloseKey(hKey);	
}


BEGIN_MESSAGE_MAP(CRF_ID_DemoDlg, CPropertySheet)
	ON_MESSAGE(WM_RECEIVE_DATA, OnReceiveData)
END_MESSAGE_MAP()


// CRF_ID_DemoDlg message handlers


// Get Key Type of Model
int CRF_ID_DemoDlg::GetKeypadType()
{
	DWORD dwKeyType;
	TCHAR szBuf[20];
	memset(szBuf, 0x00, 20);

	const DWORD KEY_NUMERIC = 0;
	const DWORD KEY_QWERTY = 1;

	// Check Sky Summit
	SystemParametersInfo(SPI_GETOEMINFO, MAX_PATH, szBuf, 0);

	if ((wcscmp(szBuf, _T("MC7101")) == 0) || (wcscmp(szBuf, _T("MC7X01")) == 0))
	{
		// Check Numeric or qwerty
		HKEY key;
		DWORD dwDisp;
		DWORD Size;
		if(RegCreateKeyEx(HKEY_LOCAL_MACHINE, L"ControlPanel\\keypad", 0, NULL, REG_OPTION_NON_VOLATILE, KEY_READ, NULL, &key, &dwDisp) != ERROR_SUCCESS)
		{
			return -1;
		}
		Size = sizeof(LONG);
		if(RegQueryValueEx(key, L"KeypadType", 0, NULL, (LPBYTE)&dwKeyType, &Size) != ERROR_SUCCESS)
		{
			return -1;
		}

		RegCloseKey(key);


		if (dwKeyType == KEY_NUMERIC)
		{
			return KEY_SKY_SUMMIT_NUMERIC;
		}
		else if (dwKeyType == KEY_QWERTY)
		{
			return KEY_SKY_SUMMIT_QWERTY;
		}
	}
	else
	{
		return KEY_SKY_ORIGINAL;
	}

	return 0;
}


LRESULT CRF_ID_DemoDlg::OnReceiveData(WPARAM wParam, LPARAM lParam)
{
	m_ReadWrite.OnReadData((LPCTSTR)wParam, (LPCTSTR)lParam);
	return FALSE;
}
BOOL CRF_ID_DemoDlg::PreTranslateMessage(MSG* pMsg)
{
// 	RETAILMSG(RT_MSG,(L"pMsg->wParam: [0x%X] ", pMsg->wParam));
// 	RETAILMSG(RT_MSG,(L"pMsg->message: [0x%X]\r\n", pMsg->message));

	if(pMsg->message == WM_KEYUP && pMsg->wParam == VK_F13)
	{
		m_ReadWrite.OnBnClickedBtnWrite();
	}
	if(pMsg->message == WM_KEYUP && pMsg->wParam == VK_F14)
	{
		m_ReadWrite.OnBnClickedBtnRead();
	}

	return CPropertySheet::PreTranslateMessage(pMsg);
}


UINT PowerStatusThreadFunc(LPVOID pParam)
{
	MSGQUEUEOPTIONS			lm_Options;
	HANDLE					lm_hPMMQ, lm_hPMNoti;
	DWORD					lm_dwErrCode, lm_dwPri = 251, lm_dwCount = 0;
	CString					lm_szErr;
	UCHAR					lm_ucBuf[160];
	DWORD					lm_dwReadSize = 0, lm_dwFlags;
	BOOL					lm_bResult;
	// SYSTEM_POWER_STATUS_EX2	SPSE;

	lm_Options.dwSize			= sizeof (MSGQUEUEOPTIONS);
	lm_Options.dwFlags			= MSGQUEUE_ALLOW_BROKEN;
	lm_Options.dwMaxMessages	= 10;
	lm_Options.cbMaxMessage		= 16;
	lm_Options.bReadAccess		= TRUE;
	char buffer[514];

	lm_hPMMQ = CreateMsgQueue (NULL, &lm_Options);
	if (lm_hPMMQ == NULL)
	{
		lm_dwErrCode = GetLastError();
		lm_szErr.Format (TEXT("CreateMsgQueue ERROR:%d\n"), lm_dwErrCode);
        //AfxMessageBox (lm_szErr);
		goto _Exit;
	}

	lm_hPMNoti = RequestPowerNotifications (lm_hPMMQ, POWER_NOTIFY_ALL);
	if (lm_hPMNoti == NULL)
	{
		lm_dwErrCode = GetLastError();
		lm_szErr.Format (TEXT("RequestPowerNotifications ERROR:%d\n"), lm_dwErrCode);
        //AfxMessageBox (lm_szErr);
		goto _Exit;
	}

    if ( !CeSetThreadPriority(GetCurrentThread(), lm_dwPri)) 
	{
        lm_dwErrCode = GetLastError();
		lm_szErr.Format (TEXT("CeSetThreadPriority ERROR:%d\n"), lm_dwErrCode);
        //AfxMessageBox (lm_szErr);
        goto _Exit;
    }

	while (1)
	{
		memset (&lm_ucBuf, 0, 160);

		lm_bResult = ReadMsgQueue (lm_hPMMQ, &lm_ucBuf, sizeof (POWER_BROADCAST), &lm_dwReadSize, 0/*INFINITE*/, &lm_dwFlags);
		Sleep(50);

		if (lm_bResult)
		{
			if (lm_dwReadSize >= sizeof(POWER_BROADCAST))
			{
				PPOWER_BROADCAST	pB = (PPOWER_BROADCAST)&lm_ucBuf;
				CString				lm_szResult;
            
				if (pB->Message == PBT_RESUME) 
				{
					RDR_SendCommandGetDataTimeout("c","", buffer, 10);
					RDR_AbortContinuousReadExt();
					RDR_SendCommandGetData("poff", "", buffer);
				}
			}
		}
		else
		{
			lm_dwErrCode = GetLastError ();
			if(lm_dwErrCode == ERROR_TIMEOUT) continue;
			lm_szErr.Format (_T("ReadMsgQueue : %d"), lm_dwErrCode);
			//AfxMessageBox (lm_szErr);

			goto _Exit;
		}
	}

_Exit:
	StopPowerNotifications (lm_hPMNoti);
	CloseMsgQueue (lm_hPMMQ);
	return 0;
}


