#pragma once

#include "ReadWrite.h"
#include "Option.h"



// CRF_ID_DemoDlg

class CRF_ID_DemoDlg : public CPropertySheet
{
	DECLARE_DYNAMIC(CRF_ID_DemoDlg)

public:
	CRF_ID_DemoDlg(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CRF_ID_DemoDlg(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	virtual ~CRF_ID_DemoDlg();

	// Sheet
	CReadWrite m_ReadWrite;
	COption m_Option;

	// key Setting
	int m_nRightUpKey, m_nRightDownKey, m_nLeftUpKey, m_nLeftDownKey, m_nSoft1Key, m_nSoft2Key;

	// Power status check thread
	CWinThread* m_pWakeUpThread;

	// Get Model and key type
	int GetKeypadType();

	afx_msg LRESULT OnReceiveData(WPARAM wParam, LPARAM lParam);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
protected:
	DECLARE_MESSAGE_MAP()

};

