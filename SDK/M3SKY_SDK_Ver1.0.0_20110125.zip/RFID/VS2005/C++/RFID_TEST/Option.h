#pragma once
#include "afxwin.h"


//Tag Type
#define ISO_14443_TYPE_A	0
#define ISO_14443_TYPE_B	1
#define ICODE_UID			2
#define ICODE_EPC			3
#define ICODE				4
#define SR176				5
#define ACTIVATE_ALL_TAG	6
#define ISO_15693			7
//

//Display mode
#define MODE_READ			0
#define MODE_WRITE			1

#define MODE_HEX			0
#define MODE_DEC			1
#define MODE_CHAR			2

#define DEC_PER_BYTE		3
#define HEX_PER_BYTE		2
#define CHAR_PER_BYTE		1

// KeyPad type
#define KEY_SKY_ORIGINAL		0
#define KEY_SKY_SUMMIT_NUMERIC	1
#define KEY_SKY_SUMMIT_QWERTY	2
//

// Read mode
#define READ_ASYNC		0
#define READ_SYNC		1
#define READ_CONTINUOUS	2
//


// COption dialog


typedef struct RfidOption {
	BOOL	bAntenna;
	int		nContinuous;
	TCHAR	szTagType[24];
} ReadOption;

class COption : public CPropertyPage
{
	DECLARE_DYNAMIC(COption)

public:
	COption();
	virtual ~COption();

// Dialog Data
	enum { IDD = IDD_DLG_OPTION };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedBtnReset();

	BOOL m_optAntenna;
	int m_optContinous;

	ReadOption Reader_Option;
	CString m_lstType;
	CString m_lstRead;
	CString m_lstWrite;
	CString m_strDemoVersion;

	CComboBox m_LstCtlRead;
	CComboBox m_LstCtlWrite;
	CComboBox m_cmboxSelectTagType;

	BOOL m_bMifareLogin;
	int m_nDispMode;
};
