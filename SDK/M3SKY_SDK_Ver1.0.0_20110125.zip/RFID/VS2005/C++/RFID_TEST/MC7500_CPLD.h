#ifndef _MC7500_CPLD_H_
#define _MC7500_CPLD_H_

#define MC7500_CPLD_BASE_PA		0x14000000
#define MC7500_CPLD_STATE_OFFSET  0x0
#define MC7500_CPLD_CTRL_OFFSET    0x1000
#define MC7500_CPLD_CTRL_BASE_PA  (MC7500_CPLD_BASE_PA + MC7500_CPLD_CTRL_OFFSET)

#define USHORT_SIZE 0x02

// MHR 20071009 - Modified for P.P board
#define CTRL_LCD_ON_OFFSET			0x0
#define CTRL_LCD_SD_OFFSET  		(CTRL_LCD_ON_OFFSET + USHORT_SIZE)		
#define CTRL_CAM_ON_OFFSET		(CTRL_LCD_SD_OFFSET + USHORT_SIZE)		
#define CTRL_CAM_RST_OFFSET 		(CTRL_CAM_ON_OFFSET + USHORT_SIZE)
#define CTRL_RESERVED1_OFFSET 		(CTRL_CAM_RST_OFFSET + USHORT_SIZE)
#define CTRL_FLSH_ON_OFFSET		(CTRL_RESERVED1_OFFSET + USHORT_SIZE)
#define CTRL_BAT_SEL_OFFSET		(CTRL_FLSH_ON_OFFSET + USHORT_SIZE)
#define CTRL_624_ON_OFFSET			(CTRL_BAT_SEL_OFFSET + USHORT_SIZE)		// MHR 20080827 - modify
#define CTRL_LED_ON_OFFSET			(CTRL_624_ON_OFFSET + USHORT_SIZE)		// MHR 20080807 - modify
#define CTRL_KEYLIGHT_ON_OFFSET	(CTRL_LED_ON_OFFSET + USHORT_SIZE)
#define CTRL_WLAN_ON_OFFSET		(CTRL_KEYLIGHT_ON_OFFSET + USHORT_SIZE)
#define CTRL_WLAN_RST_OFFSET		(CTRL_WLAN_ON_OFFSET + USHORT_SIZE)
#define CTRL_nWLAN_PD_OFFSET		(CTRL_WLAN_RST_OFFSET + USHORT_SIZE)
#define CTRL_IGT_OFFSET				(CTRL_nWLAN_PD_OFFSET + USHORT_SIZE)
#define CTRL_MOTOR_ON_OFFSET		(CTRL_IGT_OFFSET + USHORT_SIZE)
#define CTRL_VOICE_CALL_OFFSET		(CTRL_MOTOR_ON_OFFSET + USHORT_SIZE)
#define CTRL_AC97_ON_OFFSET		(CTRL_VOICE_CALL_OFFSET + USHORT_SIZE)
#define CTRL_SPK_ON_OFFSET			(CTRL_AC97_ON_OFFSET + USHORT_SIZE)
#define CTRL_MIC_ON_OFFSET			(CTRL_SPK_ON_OFFSET + USHORT_SIZE)
#define CTRL_XUARTB_RST_OFFSET	(CTRL_MIC_ON_OFFSET + USHORT_SIZE)		
#define CTRL_XUARTA_RST_OFFSET	(CTRL_XUARTB_RST_OFFSET + USHORT_SIZE)	// 20071009 PP1 ADDS
#define CTRL_SCANNER_ON_OFFSET	(CTRL_XUARTA_RST_OFFSET + USHORT_SIZE)	
#define CTRL_nIRDA_ON_OFFSET		(CTRL_SCANNER_ON_OFFSET + USHORT_SIZE)
#define CTRL_GPS_ON_OFFSET			(CTRL_nIRDA_ON_OFFSET + USHORT_SIZE)
#define CTRL_USB_CTRL_OFFSET		(CTRL_GPS_ON_OFFSET + USHORT_SIZE)		// 20080115 KBJ ADDS
#define CTRL_BT_ON_OFFSET			(CTRL_USB_CTRL_OFFSET + USHORT_SIZE)
#define CTRL_BT_RST_OFFSET			(CTRL_BT_ON_OFFSET + USHORT_SIZE)
#define CTRL_XUART_ON_OFFSET		(CTRL_BT_RST_OFFSET + USHORT_SIZE)
#define CTRL_RFID_ON_OFFSET		(CTRL_XUART_ON_OFFSET + USHORT_SIZE)
#define CTRL_RFID_RST_OFFSET		(CTRL_RFID_ON_OFFSET + USHORT_SIZE)
#define CTRL_RESERVED4_OFFSET		(CTRL_RFID_RST_OFFSET + USHORT_SIZE)
#define CTRL_RESERVED5_OFFSET		(CTRL_RESERVED4_OFFSET + USHORT_SIZE)

#define CTRL_RESERVED3_OFFSET		(CTRL_XUART_ON_OFFSET + USHORT_SIZE)
#define CTRL_USBDET_EN_OFFSET		(CTRL_RESERVED3_OFFSET + USHORT_SIZE)
#define CTRL_nGPS_RST_OFFSET		(CTRL_GPS_ON_OFFSET + USHORT_SIZE)	

#if 0
#define CTRL_LCD_ON_OFFSET			0x0
#define CTRL_LCD_SD_OFFSET  		(CTRL_LCD_ON_OFFSET + USHORT_SIZE)		
#define CTRL_CAM_ON_OFFSET		(CTRL_LCD_SD_OFFSET + USHORT_SIZE)		
#define CTRL_CAM_RST_OFFSET 		(CTRL_CAM_ON_OFFSET + USHORT_SIZE)
#define CTRL_RESERVED1_OFFSET 		(CTRL_CAM_RST_OFFSET + USHORT_SIZE)
#define CTRL_FLSH_ON_OFFSET		(CTRL_RESERVED1_OFFSET + USHORT_SIZE)
#define CTRL_BAT_SEL_OFFSET		(CTRL_FLSH_ON_OFFSET + USHORT_SIZE)
#define CTRL_RESERVED2_OFFSET		(CTRL_BAT_SEL_OFFSET + USHORT_SIZE)
#define CTRL_LED_ON_OFFSET			(CTRL_RESERVED2_OFFSET + USHORT_SIZE)
#define CTRL_KEYLIGHT_ON_OFFSET	(CTRL_LED_ON_OFFSET + USHORT_SIZE)
#define CTRL_WLAN_ON_OFFSET		(CTRL_KEYLIGHT_ON_OFFSET + USHORT_SIZE)
#define CTRL_WLAN_RST_OFFSET		(CTRL_WLAN_ON_OFFSET + USHORT_SIZE)
#define CTRL_nWLAN_PD_OFFSET		(CTRL_WLAN_RST_OFFSET + USHORT_SIZE)
#define CTRL_IGT_OFFSET				(CTRL_nWLAN_PD_OFFSET + USHORT_SIZE)
#define CTRL_MOTOR_ON_OFFSET		(CTRL_IGT_OFFSET + USHORT_SIZE)
#define CTRL_VOICE_CALL_OFFSET		(CTRL_MOTOR_ON_OFFSET + USHORT_SIZE)
#define CTRL_AC97_ON_OFFSET		(CTRL_VOICE_CALL_OFFSET + USHORT_SIZE)
#define CTRL_SPK_ON_OFFSET			(CTRL_AC97_ON_OFFSET + USHORT_SIZE)
#define CTRL_MIC_ON_OFFSET			(CTRL_SPK_ON_OFFSET + USHORT_SIZE)
#define CTRL_XUARTB_RST_OFFSET	(CTRL_MIC_ON_OFFSET + USHORT_SIZE)		
#define CTRL_XUARTA_RST_OFFSET	(CTRL_XUARTB_RST_OFFSET + USHORT_SIZE)	// 20071009 PP1 ADDS
#define CTRL_SCANNER_ON_OFFSET	(CTRL_XUARTA_RST_OFFSET + USHORT_SIZE)	
#define CTRL_nIRDA_ON_OFFSET		(CTRL_SCANNER_ON_OFFSET + USHORT_SIZE)
#define CTRL_GPS_ON_OFFSET			(CTRL_nIRDA_ON_OFFSET + USHORT_SIZE)
#define CTRL_nGPS_RST_OFFSET		(CTRL_GPS_ON_OFFSET + USHORT_SIZE)	
#define CTRL_USB_CTRL_OFFSET		(CTRL_GPS_ON_OFFSET + USHORT_SIZE)		// 20080115 KBJ ADDS
#define CTRL_BT_ON_OFFSET			(CTRL_nGPS_RST_OFFSET + USHORT_SIZE)
#define CTRL_BT_RST_OFFSET			(CTRL_BT_ON_OFFSET + USHORT_SIZE)
#define CTRL_XUART_ON_OFFSET		(CTRL_BT_RST_OFFSET + USHORT_SIZE)
// For PP1 BOARD
#define CTRL_RESERVED3_OFFSET		(CTRL_XUART_ON_OFFSET + USHORT_SIZE)
#define CTRL_USBDET_EN_OFFSET		(CTRL_RESERVED3_OFFSET + USHORT_SIZE)

// For PP2 BOARD
#define CTRL_RFID_ON_OFFSET		(CTRL_XUART_ON_OFFSET + USHORT_SIZE)
#define CTRL_RFID_RST_OFFSET		(CTRL_RFID_ON_OFFSET + USHORT_SIZE)

#define CTRL_RESERVED4_OFFSET		(CTRL_USBDET_EN_OFFSET + USHORT_SIZE)
#define CTRL_RESERVED5_OFFSET		(CTRL_RESERVED4_OFFSET + USHORT_SIZE)
#endif
#define TSTMSG NKDbgPrintfW
/*** bits definitions **************************/
#define CPLD_VERSION			0
#define CPLD_CPU_RAM_CONFIG		1
#define CPLD_DEVICE_STATE		2
#define CPLD_XUART_INTR			3

//cpu_ram_config 14000000 ~2
#define CPU_RAM_CONFIG_BIT_SPD_CFG				(1u << 6)
#define CPU_RAM_CONFIG_BIT_SPD_CFG_MASK			(3u << 6)
	#define SPD_CFG1_312						0
	#define SPD_CFG1_416						1
	#define SPD_CFG1_520						2
	#define SPD_CFG1_624						3	
#define CPU_RAM_CONFIG_BIT_FLSH_CFG				(1u << 4)
#define CPU_RAM_CONFIG_BIT_FLSH_CFG_MASK		(3u << 4)
#define CPU_RAM_CONFIG_BIT_RAM_CFG				(1u << 2)

// device_state 14000004
#define DEVICE_STATE_BIT_CHARGE_COMPLETE		(1u << 7)
#define DEVICE_STATE_BIT_nAC_OK					(1u << 6)
#define DEVICE_STATE_BIT_nLOWBATT				(1u << 5)
#define DEVICE_STATE_BIT_nWLAN_DET			(1u << 4)

typedef struct
{
	unsigned short version;			// 0x14000000
	unsigned short cpu_ram_config;	// 0x14000002
	unsigned short device_state;		// 0x14000004
	unsigned short board_version;		// 20081009 JSA Add : 0x14000006 
	unsigned short model_version;		// 20081009 JSA Add : 0x14000008 
} MC7500_CPLD_STATE, *PMC7500_CPLD_STATE;

#ifndef BSP_PP2
// MHR 20071009 - Modified for P.P board
typedef struct
{
	unsigned short Lcd_on;
	unsigned short Lcd_sd;
	unsigned short Cam_on;
	unsigned short Cam_rst;
	unsigned short Reserved1;
	unsigned short Flsh_on;
	unsigned short Bat_sel;
	unsigned short Reserved2;
	unsigned short Led_on;
	unsigned short Keylight_on;
	unsigned short Wlan_on;
	unsigned short Wlan_rst;
	unsigned short nWlan_pd;
	unsigned short Igt;
	unsigned short Motor_on;
	unsigned short Voice_call;
	unsigned short AC97_on;
	unsigned short Spk_on;
	unsigned short Mic_on;	
	unsigned short XuartA_rst;						// 20071009 pp1 adds
	unsigned short XuartB_rst;
	unsigned short Scanner_on;
	unsigned short nIRDA_on;
	unsigned short Gps_on;
  	unsigned short nGps_rst;		
  	unsigned short Bt_on;
  	unsigned short Bt_rst;
	unsigned short Xuart_on;
	unsigned short Reserved3;
	unsigned short Usbdet_en;
	unsigned short Reserved4;
	unsigned short Reserved5;
}MC7500_CPLD_CTRL, *PMC7500_CPLD_CTRL;
#else   // PP2 20080115 KBJ ADDS
typedef struct
{
	unsigned short Lcd_on;
	unsigned short Lcd_sd;
	unsigned short Cam_on;
	unsigned short Cam_rst;
#if 0	
	unsigned short Reserved1;
#else
	unsigned short Lcd_rst;			// 20080630 kbj adds Lct_rst
#endif
	unsigned short Flsh_on;
	unsigned short Bat_sel;
	unsigned short U624_on;			// MHR 20080827 - Reserved2 => 624_on
	unsigned short Led_on;
	unsigned short Keylight_on;
	unsigned short Wlan_on;
	unsigned short Wlan_rst;
	unsigned short nWlan_pd;
	unsigned short Igt;
	unsigned short Motor_on;
	unsigned short Voice_call;
	unsigned short AC97_on;
	unsigned short Spk_on;
	unsigned short Mic_on;	
	unsigned short XuartB_rst;						// 20071009 pp1 adds
	unsigned short XuartA_rst;
	unsigned short Scanner_on;
	unsigned short nIRDA_on;
	unsigned short Gps_on;
  	unsigned short Usb_ctrl;						// 20080115 kbj pp2 gps rst --> Usb_ctrl
  	unsigned short Bt_on;
  	unsigned short Bt_rst;
	unsigned short Xuart_on;
	unsigned short Rfid_on;
	unsigned short Rfid_rst;
	unsigned short Reserved3;
	unsigned short Reserved4;
}MC7500_CPLD_CTRL, *PMC7500_CPLD_CTRL;
#endif

#define GET_CPLD_VER(pCpldSts) (pCpldSts->version)
#define GET_CPLD_SPD_CFG(pCpldSts) ((pCpldSts->cpu_ram_config & CPU_RAM_CONFIG_BIT_SPD_CFG) >> 6)
#define GET_CPLD_FLSH_CFG(pCpldSts) ((pCpldSts->cpu_ram_config & CPU_RAM_CONFIG_BIT_FLSH_CFG) >> 4)
#define GET_CPLD_RAM_CFG(pCpldSts) ((pCpldSts->cpu_ram_config & CPU_RAM_CONFIG_BIT_RAM_CFG) >> 2)

#define IS_CHARGE_DONE(pCpldSts) ((pCpldSts->device_state & DEVICE_STATE_BIT_CHARGE_COMPLETE)?1:0)
#define IS_nAC_OK(pCpldSts)	((pCpldSts->device_state & DEVICE_STATE_BIT_nAC_OK)?1:0)
//#define IS_nLOWBATT(pCpldSts)   ((pCpldSts->device_state & DEVICE_STATE_BIT_nLOWBATT)?1:0)
#define IS_nLOWBATT(pCpldSts)   (FALSE)    // Temp Value
#define IS_nWLAN_DET(pCpldSts)	((pCpldSts->device_state & DEVICE_STATE_BIT_nWLAN_DET)?1:0)

#define LCD_ON(pCpldCtrl)		(pCpldCtrl->Lcd_on = 1)
#define LCD_OFF(pCpldCtrl)	(pCpldCtrl ->Lcd_on = 0)

#define LCD_SD_DOWN(pCpldCtrl)  (pCpldCtrl->Lcd_sd = 0)
#define LCD_SD_UP(pCpldCtrl)  (pCpldCtrl->Lcd_sd = 1)

// 20080630 kbj adds --------------------------------------
#define LCD_RST_DOWN(pCpldCtrl) (pCpldCtrl->Lcd_rst = 0)
#define LCD_RST_UP(pCpldCtrl) (pCpldCtrl->Lcd_rst = 1)
//-------------------------------------------------------

//20081009 JSA Adds
#define GET_CPLD_BOARD_VER(pCpldSts) (pCpldSts->board_version)
#define GET_CPLD_MODEL_VER(pCpldSts) (pCpldSts->model_version)

//20081012 kbj adds
#define COMBINED_CPLD_VER	0x30

// Debug Dump
#define DUMP_MC7500_CPLD(pCpld) 										\
	{																\
		TSTMSG(L"========== MC7500 CPLD DUMP ===========\r\n"); \
		TSTMSG(L"version                : 0x%x\r\n", pCpld->version);  			\
		TSTMSG(L"cpu_ram_config    : 0x%x\r\n", pCpld->cpu_ram_config);  	\
		TSTMSG(L"device_state        : 0x%x\r\n", pCpld->device_state); 		\
		TSTMSG(L"====================================\r\n");  \
	}


#ifdef __cplusplus
extern "C"{
#endif 
// define functions 
BOOL WriteCPLDCtrl(UINT32 nCPLDID, BOOL bSet);
UINT32 ReadCPLDCtrl(UINT32 nCPLDID);
void CPLDInitShadow(void* pCpldBase, void* pCpldCtrlShadow);
UINT32 ReadCPLDState(UINT32 nCPLDID);
MC7500_CPLD_CTRL* GetCPLDCtrlShadow();
MC7500_CPLD_STATE* GetCPLDState();
void CPLDShadowSetResetValue();
#ifdef __cplusplus
}
#endif 

#endif // #ifndef _MC7500_CPLD_H_
