#pragma once
#include "afxwin.h"

#define WM_RECEIVE_DATA		WM_USER+550
#define STATE_MSG			0
#define STATE_READ			1
#define STATE_WRITE			2


// CReadWrite dialog

class CReadWrite : public CPropertyPage
{
	DECLARE_DYNAMIC(CReadWrite)

public:
	CReadWrite();
	virtual ~CReadWrite();

	void OnReadData(LPCTSTR szSerial, LPCTSTR szData);

// Dialog Data
	enum { IDD = IDD_DLG_READ_WRITE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();

	CWinThread* m_pReadThread;

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedBtnOpen();
	afx_msg void OnBnClickedBtnRead();
	afx_msg void OnBnClickedBtnWrite();
	afx_msg void OnBnClickedBtnClear();
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedBtnStop();
	BOOL UpdateListBox(CString strData,int nState = STATE_MSG);
	BOOL UpdateSerial(CString strSerial);

	BOOL TranslationMsg(int nMode, int nDispMode,const WCHAR* wzInputMsg, WCHAR* wzOutputMsg);
	CButton m_btnOpen;
	CListBox m_LstData;
	CString m_szBlock;
	CString m_szWriteData;
	CString m_strSerial;
	CButton m_btnRead;
	CButton m_btnStop;
	CButton m_btnWrite;
	BOOL m_bPlaySound;
	BOOL m_bContRead;
	CString m_strModuleVersion;
	afx_msg void OnBnClickedBtnCont();
};
