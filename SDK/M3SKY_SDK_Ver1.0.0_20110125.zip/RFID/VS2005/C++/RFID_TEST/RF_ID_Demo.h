// RF_ID_Demo.h : main header file for the PROJECT_NAME application
//
/************************************************************************/
/* 
2010.08.04 1.1.0 [jjy] add setting for Sky Summit Button
                       Delete RDR_SleepComm and RDR_WakeupComm
2010.12.16 1.1.1 JJ Add Continuous Serial Read
*/
/************************************************************************/
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#ifdef POCKETPC2003_UI_MODEL
#include "resourceppc.h"
#endif 

#define DEMO_VER	TEXT("1.1.1")

// CRF_ID_DemoApp:
// See RF_ID_Demo.cpp for the implementation of this class
//

class CRF_ID_DemoApp : public CWinApp
{
public:
	CRF_ID_DemoApp();
	
// Overrides
public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern CRF_ID_DemoApp theApp;
