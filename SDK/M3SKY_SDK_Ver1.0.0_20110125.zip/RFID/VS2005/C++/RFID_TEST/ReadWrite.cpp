// ReadWrite.cpp : implementation file
//

#include "stdafx.h"
#include "RF_ID_Demo.h"
#include "ReadWrite.h"

#include "MC7500_ioctl.h"
#include "MC7500_CPLD.h"
#include "pkfuncs.h"

#include "CFReaderLib.h"
#include "RF_ID_DemoDlg.h"


#define READ_WAVE_PATH	TEXT("\\Windows\\voicbeep.wav")
#define WRITE_WAVE_PATH	TEXT("\\Windows\\RecEnd.wav")


CRF_ID_DemoDlg * dlg;
// CReadWrite dialog
CString szType;
CString szBlock;
HANDLE hReadEvent = ::CreateEvent(NULL, TRUE, FALSE, NULL);
UINT ReadThreadFunc(HWND hRevWnd);
UINT ReadSerialThreadFunc(HWND hRevWnd);

IMPLEMENT_DYNAMIC(CReadWrite, CPropertyPage)

CReadWrite::CReadWrite()
	: CPropertyPage(CReadWrite::IDD)
	, m_szBlock(_T("04"))
	, m_szWriteData(_T("12345678"))
	, m_strSerial(_T("Serial"))
	, m_strModuleVersion(_T(""))
{
	HANDLE hVibThread = ::CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ReadThreadFunc, this->m_hWnd, 0, NULL);
	::CloseHandle(hVibThread);
	m_bPlaySound = FALSE;
	m_bContRead = FALSE;
}

CReadWrite::~CReadWrite()
{
}

void CReadWrite::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDT_BLOCK, m_szBlock);
	DDX_Text(pDX, IDC_EDT_DATA, m_szWriteData);
	DDX_Control(pDX, IDC_BTN_OPEN, m_btnOpen);
	DDX_Control(pDX, IDC_LIST1, m_LstData);
	DDX_Control(pDX, IDC_BTN_READ, m_btnRead);
	DDX_Control(pDX, IDC_BTN_STOP, m_btnStop);
	DDX_Control(pDX, IDC_BTN_WRITE, m_btnWrite);
	DDX_Text(pDX, IDC_STATIC_SERIAL, m_strSerial);
	DDX_Text(pDX, IDC_STATIC_VERSION, m_strModuleVersion);
}


BEGIN_MESSAGE_MAP(CReadWrite, CPropertyPage)
	ON_BN_CLICKED(IDC_BTN_OPEN, &CReadWrite::OnBnClickedBtnOpen)
	ON_BN_CLICKED(IDC_BTN_READ, &CReadWrite::OnBnClickedBtnRead)
	ON_BN_CLICKED(IDC_BTN_WRITE, &CReadWrite::OnBnClickedBtnWrite)
	ON_BN_CLICKED(IDC_BTN_CLEAR, &CReadWrite::OnBnClickedBtnClear)
	ON_BN_CLICKED(IDC_BTN_STOP, &CReadWrite::OnBnClickedBtnStop)
	ON_BN_CLICKED(IDC_BTN_CONT, &CReadWrite::OnBnClickedBtnCont)
	ON_WM_DESTROY()
	ON_WM_CREATE()
END_MESSAGE_MAP()


// CReadWrite message handlers

BOOL CReadWrite::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	m_btnRead.EnableWindow(FALSE);
	m_btnStop.EnableWindow(FALSE);
	m_btnWrite.EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_CONT)->EnableWindow(FALSE);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CReadWrite::UpdateListBox(CString strData,int nState)
{
	BOOL bResult;
	WCHAR wzMsg[256];
	memset(wzMsg, 0x00, sizeof(WCHAR) * 256);


	if(strData.GetLength() <= 1)
	{
		switch(strData[0])
		{
		case '?':
			wsprintf(wzMsg, L"Unknown Command");
			break;
		case 'C':
			wsprintf(wzMsg, L"Collision or CRC/MAX Error");
			break;
		case 'F':
			wsprintf(wzMsg, L"General failure");
			break;
		case 'I':
			wsprintf(wzMsg, L"Invalid value format");
			break;
		case 'N':
			wsprintf(wzMsg, L"No tag in the field");
			break;
		case 'R':
			wsprintf(wzMsg, L"Out of range");
			break;
		case 'X':
			wsprintf(wzMsg, L"Authentication failed");
			break;
		default:
			wsprintf(wzMsg, L"Unknown Error");
			break;
		}
		bResult = FALSE;
	}
	else
	{
		bResult = TRUE;
		
		switch(nState)
		{
		case STATE_MSG:
			wcscpy(wzMsg, strData.GetBuffer(0));
			// Noting
			break;
		case STATE_READ:			
			if(TranslationMsg(MODE_READ, dlg->m_Option.m_nDispMode, strData.GetBuffer(0), wzMsg))
				PlaySound(READ_WAVE_PATH,0,SND_NODEFAULT|SND_ASYNC);

			break;
		case STATE_WRITE:
			if(TranslationMsg(MODE_READ, dlg->m_Option.m_nDispMode, strData.GetBuffer(0), wzMsg))
				PlaySound(WRITE_WAVE_PATH,0,SND_NODEFAULT|SND_ASYNC);
			
			break;
		}
	}

	m_LstData.InsertString(0, wzMsg);

	CSize   sz;
	int     dx=0;
	CDC*    pDC = m_LstData.GetDC();
	sz = pDC->GetTextExtent(wzMsg);

	if (sz.cx > dx)
		dx = sz.cx;

	m_LstData.ReleaseDC(pDC);

	// Set the horizontal extent only if the current extent is not large enough.
	if (m_LstData.GetHorizontalExtent() < dx)
	{
		m_LstData.SetHorizontalExtent(dx);
	}

	return bResult;
}

// translate output and input
// read: Hex -> DEC or Char
// write: DEC or CHAR -> HEX
BOOL CReadWrite::TranslationMsg(int nMode, int nDispMode,const WCHAR* wzInputMsg, WCHAR* wzOutputMsg)
{
	switch(nDispMode)
	{
	case MODE_HEX:
		wcscpy(wzOutputMsg, wzInputMsg);
		break;
	case MODE_DEC:
		{
			if(nMode == MODE_READ)
			{
				WCHAR *wFlag;
				int nLength = wcslen(wzInputMsg);
				int nByteLength = nLength / HEX_PER_BYTE; // �� ����Ʈ ���� ���Դ����� ���Ѵ�.

				RETAILMSG(RT_MSG, (L"Dec Output: "));
				for(int i = 0; i < nByteLength; i++)
				{
					WCHAR wzTemp[HEX_PER_BYTE] = {wzInputMsg[i * HEX_PER_BYTE] , wzInputMsg[i * HEX_PER_BYTE + 1]};
					unsigned long ulTemp;
					ulTemp = wcstoul(wzTemp, &wFlag, 16);
					wsprintf(wzOutputMsg, L"%s%03d", wzOutputMsg, ulTemp);

					RETAILMSG(RT_MSG, (L"%03d ", ulTemp));
				}
				RETAILMSG(RT_MSG, (L"\n"));
				RETAILMSG(RT_MSG, (L"Resutl: %s\n", wzOutputMsg));				
			}
			else if(nMode == MODE_WRITE)
			{
				// Decimal value to Hexadecimal value
				WCHAR *wFlag;
				int nLength = wcslen(wzInputMsg);
				int nByteLength = nLength / DEC_PER_BYTE; // Decimal number count per one byte
				RETAILMSG(RT_MSG, (L"Wrtie to Hex: "));
				for(int i= 0; i< nByteLength; i++)
				{
					WCHAR wzTemp[DEC_PER_BYTE] = {wzInputMsg[i * DEC_PER_BYTE] , wzInputMsg[i * DEC_PER_BYTE + 1] , wzInputMsg[i * DEC_PER_BYTE + 2]};
					unsigned long ulTemp;
					ulTemp = wcstoul(wzTemp, &wFlag, 16);
					wsprintf(wzOutputMsg, L"%s%02X", wzOutputMsg, ulTemp);

					RETAILMSG(RT_MSG, (L"%02X ", ulTemp));
				}
				RETAILMSG(RT_MSG, (L"\n"));

			}
		}
		break;
	case MODE_CHAR:
		{
			if(nMode == MODE_READ)
			{
				WCHAR *wFlag;
				int nLength = wcslen(wzInputMsg);
				int nByteLength = nLength / 2; // �� ����Ʈ ���� ���Դ����� ���Ѵ�.

				RETAILMSG(RT_MSG, (L"Char Output: "));
				for(int i = 0; i < nByteLength; i++)
				{
					WCHAR wzTemp[2] = {wzInputMsg[i * 2] , wzInputMsg[i * 2 + 1]};
					unsigned long ulTemp;
					ulTemp = wcstoul(wzTemp, &wFlag, 16);
					RETAILMSG(RT_MSG, (L"%02X[%c] ", ulTemp, ulTemp));

					wsprintf(wzOutputMsg, L"%s%c", wzOutputMsg, ulTemp);
					/*
					// if ulTemp is not a a-z, 0-9, then return Hex value
					if((ulTemp >= 'a' && ulTemp <= 'z') || (ulTemp >= 'A' && ulTemp <= 'Z') || (ulTemp >= '0' && ulTemp <= '9'))
					{
						wsprintf(wzOutputMsg, L"%s%c", wzOutputMsg, ulTemp);
					}
					else
					{
						wsprintf(wzOutputMsg,L"Tag data is not a string");
						return FALSE;
					}
					//
					*/
				}
				RETAILMSG(RT_MSG, (L"\n"));
				RETAILMSG(RT_MSG, (L"Resutl: %s\n", wzOutputMsg));
			}
			else if(nMode == MODE_WRITE)
			{
				int nLength = wcslen(wzInputMsg);
				int nByteLength = nLength / CHAR_PER_BYTE; // �� ����Ʈ ���� ���Դ����� ���Ѵ�.

				RETAILMSG(RT_MSG, (L"Write to char: "));
				for(int i = 0; i < nByteLength; i++)
				{
					WCHAR wzTemp = wzInputMsg[i];
					int nTemp = (int)wzTemp;
					RETAILMSG(RT_MSG, (L"%02X[%c] ", nTemp, nTemp));

					wsprintf(wzOutputMsg, L"%s%02X", wzOutputMsg, nTemp);
					// if ulTemp is not a a-z, 0-9, then return Hex value
					/*
					if((nTemp >= 'a' && nTemp <= 'z') || (nTemp >= 'A' && nTemp <= 'Z') || (nTemp >= '0' && nTemp <= '9'))
					{
						wsprintf(wzOutputMsg, L"%s%02X", wzOutputMsg, nTemp);
					}
					else
					{
						wsprintf(wzOutputMsg,L"Tag data is not a string");
						return FALSE;
					}
					*/
					//
				}
				RETAILMSG(RT_MSG, (L"\n"));
				RETAILMSG(RT_MSG, (L"Result: %s\n", wzOutputMsg));

			}
		}
		break;
	default:
		break;
	}
	return TRUE;

}

BOOL CReadWrite::UpdateSerial(CString strSerial)
{
	/*
	// For Get Tag Type (Remove: 091014)
	switch(strSerial[0])
	{
	case 'D':
		m_strTagType.Format(L"Tag Type: ICode UID");
		break;
	case 'E':
		m_strTagType.Format(L"Tag Type: ICode EPC");
		break;
	case 'I':
		m_strTagType.Format(L"Tag Type: ICode");
		break;
	case 'M':
		m_strTagType.Format(L"Tag Type: ISO 14443 A");
		break;
	case 'S':
		m_strTagType.Format(L"Tag Type: SR 176");
		break;
	case 'V':
		m_strTagType.Format(L"Tag Type: ISO 15693");
		break;
	case 'Z':
		m_strTagType.Format(L"Tag Type: ISO 14443 B");
		break;
	default:
		m_strTagType.Format(L"Tag Type: Unknown Tag");
		break;
	}
	

	int nLength = strSerial.GetLength();

	// Get Serial
	m_strSerial.Format(L"Serial: %s",strSerial.Right(nLength - 1));
	*/

	
	m_strSerial = L"Serial: " + strSerial;

	return TRUE;
}


void CReadWrite::OnBnClickedBtnOpen()
{
	UINT		nCPLDID = 0, uOut;
	BOOL		rc;
	char com_port[10];
	char buffer[514];

	uOut = 1;

	m_btnOpen.EnableWindow(FALSE);

	nCPLDID = CPLD_ID_RFID_RST	;	
	rc = KernelIoControl(IOCTL_HAL_CPLD_CTRL_WRITE, &nCPLDID, sizeof(UINT), &uOut, sizeof(UINT), NULL);
	Sleep(100);

	nCPLDID = CPLD_ID_RFID_ON	;	
	rc = KernelIoControl(IOCTL_HAL_CPLD_CTRL_WRITE, &nCPLDID, sizeof(UINT), &uOut, sizeof(UINT), NULL);
	Sleep(50);



	sprintf(com_port, "MOC%s", "1");

	if(RDR_OpenComm(com_port, 1, NULL) == 0)
	{
		UpdateListBox(_T("OpenComm Failed"));
		return;
	}
	Sleep(300); 

    if(RDR_OpenReader(1, 0) == 0) {

		UpdateListBox(_T("OpenReader Failed"));
        return;
    }

	RDR_AbortContinuousReadExt();

	readerConfig settings = RDR_GetReaderConfig();

	settings.protocol = 0;
	RDR_SetReaderConfig(&settings);

	//RDR_SetCommProtocol('0');
	//RDR_SetCommBaudRate(115200);


	memset(buffer, 0x00, 514);
	// x: Reset command
	RDR_SendCommandGetData("x", "", buffer);
	Sleep(100);
	// s: Select card Command
	RDR_SendCommandGetData("s","", buffer);
	Sleep(100);
	// "ot" Select Tag Type command, 'o' Select tag type and 't' is 'activate all type'
	RDR_SendCommandGetData("o", "t", buffer);
	Sleep(100);
	// poff: Antenna power off- save power consume
	RDR_SendCommandGetData("poff", "", buffer);

	UpdateListBox(_T("Reader Open"));

	// Get Version
	memset(buffer, 0x00, 514);
	RDR_EmptyCommRcvBuffer();
	RDR_SendCommandGetData("v", "", buffer);
	m_strModuleVersion.Format(_T("Firmware: %S"), buffer);
	UpdateData(FALSE);
	//


	m_btnOpen.EnableWindow(FALSE);
	m_btnRead.EnableWindow(TRUE);
	m_btnWrite.EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_CONT)->EnableWindow(TRUE);

	dlg = (CRF_ID_DemoDlg *)AfxGetMainWnd();
	dlg->SetFocus();
}


void CReadWrite::OnBnClickedBtnRead()
{
	if(!m_btnRead.IsWindowEnabled())
		return;



	char buffer[514];
	CString szTemp;

	m_btnRead.EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_CONT)->EnableWindow(FALSE);

	UpdateData(TRUE);

	RDR_EmptyCommRcvBuffer();
	memset(buffer, 0x00, 514);
	RDR_SendCommandGetData("pon", "", buffer);

	if(dlg->m_Option.Reader_Option.nContinuous == READ_ASYNC)
	{
		RDR_SendCommandGetDataTimeout("c","", buffer, 2 * 1000);
		RDR_AbortContinuousReadExt();
	}
	else if(dlg->m_Option.Reader_Option.nContinuous == READ_SYNC)
	{
		// wait 20 sec
		RDR_SendCommandGetDataTimeout("c","", buffer, 20 * 1000);
		RDR_AbortContinuousReadExt();
	}
	else if(dlg->m_Option.Reader_Option.nContinuous == READ_CONTINUOUS)
	{
		szType = dlg->m_Option.Reader_Option.szTagType;
		szBlock = m_szBlock;
		::SetEvent(hReadEvent);
		m_btnStop.EnableWindow(TRUE);
		RDR_SendCommandGetData("poff", "", buffer);
		return;
	}

	RDR_SendCommandGetDataTimeout("s","", buffer, 2000);
	szTemp.Format(_T("%S"), buffer);
	if(buffer[1] == 0)
	{
		UpdateListBox(szTemp);
		
		UpdateSerial(L"");

		UpdateData(FALSE);
		m_btnRead.EnableWindow(TRUE);
		RDR_SendCommandGetData("poff", "", buffer);
		return;
	}
	UpdateSerial(szTemp);

	UpdateData(FALSE);

	

	if(dlg->m_Option.m_bMifareLogin == TRUE)
	{
		int i = 0;
		do
		{
			// Key make
			int nSector = int(_ttoi(m_szBlock)/4);

			CString szKey;	// For Retail
			szKey.Format(L"%02dAAFFFFFFFFFFFF", nSector);
			RETAILMSG(1,(L"Mifare key: [%s]\r\n", szKey));

			char chKey[50] = {0x00};
			sprintf(chKey, "%02dAAFFFFFFFFFFFF", nSector);
			//

			RDR_SendCommandGetData("l", chKey, buffer);
			szTemp.Format(_T("%c"), buffer[0]);
			i++;
		}while(i <= 5 && szTemp != _T("L"));

 		RETAILMSG(1,(L"Login result (%s)\r\n", szTemp));

		if(wcscmp(dlg->m_Option.Reader_Option.szTagType, _T("activate all tags")) != 0)
		{
			if(szTemp != _T("L"))
			{
				m_btnRead.EnableWindow(TRUE);
				RDR_SendCommandGetData("poff", "", buffer);
				return;
			}
		}
	}


	char		cTemp[100] = {0, };
	WideCharToMultiByte(CP_ACP, 0, m_szBlock, _tcslen(m_szBlock), cTemp, 100, NULL, NULL);

	RDR_SendCommandGetData("rb", cTemp, buffer);
	szTemp.Format(_T("%S"), buffer);
	UpdateListBox(szTemp, STATE_READ);
	

	m_btnRead.EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_CONT)->EnableWindow(TRUE);


	RDR_SendCommandGetData("poff", "", buffer);
}

void CReadWrite::OnBnClickedBtnWrite()
{
	if(!m_btnWrite.IsWindowEnabled())
		return;


	m_btnWrite.EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_CONT)->EnableWindow(FALSE);

	char buffer[514];
	CString szTemp;

	RDR_EmptyCommRcvBuffer();
	memset(buffer, 0x00, 514);

	RDR_SendCommandGetData("pon", "", buffer);
	
	UpdateData(TRUE);

	RDR_SendCommandGetDataTimeout("c","", buffer, 1000);
	RDR_AbortContinuousReadExt();

	RDR_SendCommandGetDataTimeout("s","", buffer, 2000);
	szTemp.Format(_T("%S"), buffer);
	if(buffer[1] == 0)
	{
		UpdateListBox(szTemp);
		UpdateSerial(L"");
		UpdateData(FALSE);
		RDR_SendCommandGetData("poff", "", buffer);

		m_btnWrite.EnableWindow(TRUE);
		return;
	}

	UpdateSerial(szTemp);
	UpdateData(FALSE);




	if(dlg->m_Option.m_bMifareLogin == TRUE)
	{
		int i = 0;
		do
		{
			// Key make
			int nSector = int(_ttoi(m_szBlock)/4);

			CString szKey;	// For Retail
			szKey.Format(L"%02dAAFFFFFFFFFFFF", nSector);
			RETAILMSG(1,(L"Mifare key: [%s]\r\n", szKey));

			char chKey[50] = {0x00};
			sprintf(chKey, "%02dAAFFFFFFFFFFFF", nSector);
			//

			RDR_SendCommandGetData("l", chKey, buffer);
			szTemp.Format(_T("%c"), buffer[0]);
			i++;
		}while(i <= 5 && szTemp != _T("L"));

		if(wcscmp(dlg->m_Option.Reader_Option.szTagType, _T("activate all tags")) != 0)
		{
			if(szTemp != _T("L"))
			{
				RDR_SendCommandGetData("poff", "", buffer);
				m_btnWrite.EnableWindow(TRUE);

				return;
			}
		}
	}

	// Translate Input msg with display mode 
	WCHAR wzHexData[128] = {0x00};
	memset(wzHexData, 0x00, sizeof(WCHAR) * 128);
	TranslationMsg(MODE_WRITE, dlg->m_Option.m_nDispMode, m_szWriteData.GetBuffer(0), wzHexData);
	RETAILMSG(RT_MSG, (L"Input string: %s\n Output Hex: %s\n", m_szWriteData, wzHexData));
	//

	// Write Buffer (Block Number + write data)
	WCHAR wzWriteBuffer[128]; 
	memset(wzWriteBuffer, 0x00, sizeof(WCHAR) * 128);
	wsprintf(wzWriteBuffer, L"%s%s", m_szBlock.GetBuffer(0), wzHexData);
	//

	// Uni code to ascii code
	char		cTemp[100] = {0, };
	WideCharToMultiByte(CP_ACP, 0, wzWriteBuffer, _tcslen(wzWriteBuffer), cTemp, 100, NULL, NULL);
	//

	// Write Msg
	RDR_SendCommandGetData("wb", cTemp, buffer);
	szTemp.Format(_T("%S"), buffer);
	//

	UpdateListBox(szTemp, STATE_WRITE);
	
	m_btnWrite.EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_CONT)->EnableWindow(TRUE);

	RDR_SendCommandGetData("poff", "", buffer);

	dlg = (CRF_ID_DemoDlg *)AfxGetMainWnd();
	dlg->SetFocus();
}


void CReadWrite::OnBnClickedBtnClear()
{
	m_LstData.ResetContent();
	m_LstData.SetHorizontalExtent(0);
}

void CReadWrite::OnDestroy()
{
	CPropertyPage::OnDestroy();

	
	UINT		nCPLDID = 0, uOut;
	BOOL		rc;
	uOut = 0;


	nCPLDID = CPLD_ID_RFID_ON	;	
	rc = KernelIoControl(IOCTL_HAL_CPLD_CTRL_WRITE, &nCPLDID, sizeof(UINT), &uOut, sizeof(UINT), NULL);
	Sleep(50);

	nCPLDID = CPLD_ID_RFID_RST	;	
	rc = KernelIoControl(IOCTL_HAL_CPLD_CTRL_WRITE, &nCPLDID, sizeof(UINT), &uOut, sizeof(UINT), NULL);
	Sleep(100);
}

void CReadWrite::OnBnClickedBtnStop()
{
	GetDlgItem(IDC_BTN_CONT)->EnableWindow(TRUE);
	m_btnRead.EnableWindow(TRUE);
	m_btnStop.EnableWindow(FALSE);
	::ResetEvent(hReadEvent);
}

void CReadWrite::OnReadData(LPCTSTR szSerial, LPCTSTR szData)
{
	UpdateSerial(szSerial);
	if(szData != _T(""))
		UpdateListBox(szData, STATE_READ);
	


	UpdateData(FALSE);
}

UINT ReadThreadFunc(HWND hRevWnd)
{
	char buffer[514];
	CString szTemp;

	TCHAR szSerial[24];
	TCHAR szData[256];

	RDR_EmptyCommRcvBuffer();
	memset(buffer, 0x00, 514);

	while(1)
	{
		WaitForSingleObject(hReadEvent, INFINITE);

		RDR_SendCommandGetData("pon", "", buffer);

		RDR_SendCommandGetDataTimeout("c","", buffer, 1000);
		RDR_AbortContinuousReadExt();

		if(WaitForSingleObject(hReadEvent, 0) == WAIT_TIMEOUT)
			continue;
		
		RDR_SendCommandGetDataTimeout("s","", buffer, 2000);
		szTemp.Format(_T("%S"), buffer);
		wsprintf(szSerial, _T("%s"), szTemp);
		if(buffer[1] == 0)
		{
			::PostMessage(HWND_BROADCAST, WM_RECEIVE_DATA, (WPARAM)_T(""), (LPARAM)_T(""));
			//dlg->m_LstData.InsertString(0, _T("No Tag"));
			//dlg->m_txtSerial = _T("");
			//dlg->UpdateData(FALSE);
			continue;
		}
		//dlg->m_txtSerial = szTemp;
		//dlg->UpdateData(FALSE);
		//AfxMessageBox(szTemp);
		::PostMessage(HWND_BROADCAST, WM_RECEIVE_DATA, (WPARAM)szSerial, (LPARAM)_T(""));


		if(wcscmp(szType, _T("ISO 14443 Type A")) == 0 ||
			wcscmp(szType, _T("activate all tags")) == 0)
		{
			int i = 0;
			do
			{
				// Key make
				int nSector = int(_ttoi(szBlock)/4);

				CString szKey;	// For Retail
				szKey.Format(L"%02dAAFFFFFFFFFFFF", nSector);
				RETAILMSG(1,(L"Mifare key: [%s]\r\n", szKey));

				char chKey[50] = {0x00};
				sprintf(chKey, "%02dAAFFFFFFFFFFFF", nSector);
				//

				RDR_SendCommandGetData("l", chKey, buffer);
				szTemp.Format(_T("%c"), buffer[0]);
				i++;
			}while(i <= 5 && szTemp != _T("L"));

			if(wcscmp(szType, _T("activate all tags")) != 0)
			{
				if(szTemp != _T("L"))
					continue;
			}
		}

		char		cTemp[100] = {0, };
		WideCharToMultiByte(CP_ACP, 0, szBlock, _tcslen(szBlock), cTemp, 100, NULL, NULL);

		RDR_SendCommandGetData("rb", cTemp, buffer);
		szTemp.Format(_T("%S"), buffer);
		wsprintf(szData, _T("%s"), szTemp);
		::PostMessage(HWND_BROADCAST, WM_RECEIVE_DATA, (WPARAM)szSerial, (LPARAM)szData);
		RDR_SendCommandGetData("poff", "", buffer);
	}
	return 1;
}


BOOL g_bRead = FALSE;

void CReadWrite::OnBnClickedBtnCont()
{
	if ( m_bContRead == FALSE)
	{
		g_bRead = TRUE;
		HANDLE hVibThread = ::CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ReadSerialThreadFunc, this->m_hWnd, 0, NULL);
		::CloseHandle(hVibThread);
		m_bContRead = TRUE;

		m_btnRead.EnableWindow(FALSE);
		m_btnWrite.EnableWindow(FALSE);

		::SetWindowText(::GetDlgItem(m_hWnd, IDC_BTN_CONT),L"STOP");

	}
	else
	{
		g_bRead = FALSE;
		Sleep(500);
		m_bContRead = FALSE;

		m_btnRead.EnableWindow(TRUE);
		m_btnWrite.EnableWindow(TRUE);

		::SetWindowText(::GetDlgItem(m_hWnd, IDC_BTN_CONT),L"CONTINUE");
	}

}

UINT ReadSerialThreadFunc(HWND hRevWnd)
{
	RETAILMSG(RT_MSG, (L"ReadSerialThreadFunc - while1: g_bRead[%d]\r\n", g_bRead));

	char buffer[514];
	CString szTemp;
	TCHAR szSerial[514] = {0x00,};
	TCHAR szData[514] = {0x00,};


	RDR_EmptyCommRcvBuffer();

	RDR_SendCommand("c", "");

	BOOL bRet = TRUE;
	int nCount = 0;

	while(g_bRead)
	{
		memset(buffer, 0x00, 514);
		RDR_GetData(buffer);

		if(buffer[0] == 0x0D)
			bRet = FALSE;
		else if(strlen(buffer) > 2)
		{
			bRet = TRUE;
			wsprintf(szSerial, L"%S", buffer);
			wsprintf(szData, L"Serial: %S", buffer);
			::SendMessage(HWND_BROADCAST, WM_RECEIVE_DATA, (WPARAM)szSerial, (LPARAM)szData);
			RETAILMSG(RT_MSG, (L"ReadSerialThreadFunc: [%S][%s] \r\n", buffer, szSerial));
		}
		else
			bRet = FALSE;


			// 		if(nCount++ > 100)
			// 			bRet = FALSE;


		RETAILMSG(RT_MSG, (L"ReadSerialThreadFunc - while2: bRet[%d], buffer[%S]\r\n", bRet, buffer));
	}

	RDR_AbortContinuousReadExt();
	RDR_SendCommand("poff","");
	RDR_EmptyCommRcvBuffer();


	return 0;
}
