// RF_ID_Demo.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "RF_ID_Demo.h"
#include "RF_ID_DemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CRF_ID_DemoApp

BEGIN_MESSAGE_MAP(CRF_ID_DemoApp, CWinApp)
END_MESSAGE_MAP()

HANDLE g_hMutex;

// CRF_ID_DemoApp construction
CRF_ID_DemoApp::CRF_ID_DemoApp()
	: CWinApp()
{

	// Place all significant initialization in InitInstance
}


// The one and only CRF_ID_DemoApp object
CRF_ID_DemoApp theApp;

// CRF_ID_DemoApp initialization

BOOL CRF_ID_DemoApp::InitInstance()
{
    // SHInitExtraControls should be called once during your application's initialization to initialize any
    // of the Windows Mobile specific controls such as CAPEDIT and SIPPREF.
    SHInitExtraControls();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	// avoid duple running
	g_hMutex = NULL;
	g_hMutex = ::CreateMutex(NULL, TRUE, _T("M3_RFID"));

	if(GetLastError() == ERROR_ALREADY_EXISTS)
	{
		HWND hWnd =NULL;
		hWnd = ::FindWindow(NULL,_T("RF_ID_Demo"));
		if(hWnd == NULL)
		{
			::MessageBox(NULL,_T("RFID Engine is aleady running!"),_T("ERROR"),MB_OK|MB_ICONWARNING);			
		}
		else
		{
			::MessageBox(NULL,_T("RF_ID_Demo is aleady running!"),_T("ERROR"),MB_OK|MB_ICONWARNING);			
		}
		return FALSE;
	}
	//


	CRF_ID_DemoDlg dlg(_T(""));
	m_pMainWnd = &dlg;
	INT_PTR nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
