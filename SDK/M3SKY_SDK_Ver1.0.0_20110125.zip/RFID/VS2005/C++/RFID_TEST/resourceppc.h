//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RF_ID_Demoppc.rc
//
#define ID_BTN_SLEEP                    3
#define IDD_RF_ID_DEMO_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDD_DLG_READ_WRITE              129
#define IDD_DLG_OPTION                  130
#define IDC_STATIC_1                    200
#define IDC_BTN_OPEN                    1001
#define IDC_BTN_READ                    1002
#define IDC_BTN_WRITE                   1003
#define IDC_EDT_BLOCK                   1004
#define IDC_EDT_DATA                    1005
#define IDC_EDT_SERIAL                  1006
#define IDC_LIST1                       1007
#define IDC_OPT_ANT_ON                  1008
#define IDC_BTN_CLEAR                   1009
#define IDC_OPT_ANT_OFF                 1009
#define IDC_BTN_STOP                    1010
#define IDC_BTN_CONT					1019
#define IDC_OPT_SYNC_                   1010
#define IDC_OPT_ASYNC                   1010
#define IDC_OPT_SYNC                    1011
#define IDC_COMBO1                      1012
#define IDC_BTN_RESET                   1013
#define IDC_OPT_CONTINUOUS              1014
#define IDC_BTN_WAKEUP                  1015
#define IDC_COMBO2                      1017
#define IDC_COMBO3                      1018
#define IDC_BUTTON1                     1020
#define IDC_STATIC_VERSION              1022
#define IDC_STATIC_SERIAL               1023
#define IDC_CHECK_LOGIN                 1024
#define IDC_RADIO_HEX                   1025
#define IDC_RADIO_CHAR                  1026
#define IDC_RADIO_DEC                   1027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
