// Option.cpp : implementation file
//

#include "stdafx.h"
#include "RF_ID_Demo.h"
#include "Option.h"
#include "RF_ID_DemoDlg.h"

#include "CFReaderLib.h"


// COption dialog

IMPLEMENT_DYNAMIC(COption, CPropertyPage)

COption::COption()
	: CPropertyPage(COption::IDD)
	, m_optAntenna(1)
	, m_optContinous(0)
	, m_lstRead(_T("RightDownKey"))
	, m_lstWrite(_T("RightUpKey"))
	, m_strDemoVersion(DEMO_VER)
	, m_bMifareLogin(FALSE)
	, m_nDispMode(MODE_HEX)
{
	Reader_Option.bAntenna = 0;
	Reader_Option.nContinuous = 0;
	wsprintf(Reader_Option.szTagType, _T("%s"), _T("activate all tags"));

}

COption::~COption()
{
}

void COption::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_OPT_ANT_ON, m_optAntenna);
	DDX_Radio(pDX, IDC_OPT_ASYNC, m_optContinous);
	DDX_CBString(pDX, IDC_COMBO1, m_lstType);
	DDX_CBString(pDX, IDC_COMBO2, m_lstRead);
	DDX_CBString(pDX, IDC_COMBO3, m_lstWrite);
	DDX_Control(pDX, IDC_COMBO2, m_LstCtlRead);
	DDX_Control(pDX, IDC_COMBO3, m_LstCtlWrite);
	DDX_Control(pDX, IDC_COMBO1, m_cmboxSelectTagType);
	DDX_Text(pDX, IDC_STATIC_VERSION, m_strDemoVersion);
	DDX_Check(pDX, IDC_CHECK_LOGIN, m_bMifareLogin);
	DDX_Radio(pDX, IDC_RADIO_HEX, m_nDispMode);
}


BEGIN_MESSAGE_MAP(COption, CPropertyPage)
	ON_BN_CLICKED(IDOK, &COption::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &COption::OnBnClickedCancel)
	ON_BN_CLICKED(IDC_BTN_RESET, &COption::OnBnClickedBtnReset)
END_MESSAGE_MAP()


// COption message handlers

BOOL COption::OnInitDialog()
{
	CPropertyPage::OnInitDialog();


	// �±� Ÿ�� ����Ʈ �����
	m_cmboxSelectTagType.InsertString(0, L"ISO 14443 Type A");
	m_cmboxSelectTagType.InsertString(1, L"ISO 14443 Type B");
	m_cmboxSelectTagType.InsertString(2, L"ICODE UID");
	m_cmboxSelectTagType.InsertString(3, L"ICODE EPC");
	m_cmboxSelectTagType.InsertString(4, L"ICODE");
	m_cmboxSelectTagType.InsertString(5, L"SR176");
	m_cmboxSelectTagType.InsertString(6, L"activate all tags");
	m_cmboxSelectTagType.InsertString(7, L"ISO 15693");
	m_cmboxSelectTagType.SetCurSel(ACTIVATE_ALL_TAG);
	//

	return TRUE;
}

void COption::OnBnClickedOk()
{
	UpdateData(TRUE);

	if(m_LstCtlWrite.GetCurSel() == m_LstCtlRead.GetCurSel())
	{
		AfxMessageBox(L"Button set fail");
		return;
	}

	Reader_Option.bAntenna = !m_optAntenna;
	Reader_Option.nContinuous = m_optContinous;
	wsprintf(Reader_Option.szTagType, _T("%s"), m_lstType);

	char buffer[514];
	char cTemp[24] = {0, };


	memset(buffer, 0x00, 514);
	

	
	CRF_ID_DemoDlg * dlg;
	dlg = (CRF_ID_DemoDlg *)AfxGetMainWnd();

	// Button setting
	HKEY hKey;
	int nRet;
	DWORD dwData;
	int nLeftUp, nLeftDown, nRightUp, nRightDown, nSoft1, nSoft2;


	nRightUp = 0;
	nRightDown = 0;
	nLeftUp = 0;
	nLeftDown = 0;
	nSoft1 = 0;
	nSoft2 = 0;

	switch(m_LstCtlWrite.GetCurSel())
	{
	case 0:
		nLeftUp = 2;
		break;
	case 1:
		nLeftDown = 2;
		break;
	case 2:
		nRightUp = 2;
		break;
	case 3:
		nRightDown = 2;
		break;
	case 4:
		nSoft1 = 2;
		break;
	case 5:
		nSoft2 = 2;
		break;
	}

	switch(m_LstCtlRead.GetCurSel())
	{
	case 0:
		nLeftUp = 3;
		break;
	case 1:
		nLeftDown = 3;
		break;
	case 2:
		nRightUp = 3;
		break;
	case 3:
		nRightDown = 3;
		break;
	case 4:
		nSoft1 = 3;
		break;
	case 5:
		nSoft2 = 3;
		break;
	}

	// Get Key each key type
	int nKeypadType = dlg->GetKeypadType();
	if(nKeypadType == KEY_SKY_ORIGINAL)
		nRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"ControlPanel\\keypad\\SideKey", 0, NULL, &hKey);
	else if(nKeypadType == KEY_SKY_SUMMIT_NUMERIC)
		nRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"ControlPanel\\keypad\\Numeric", 0, NULL, &hKey);
	else if(nKeypadType == KEY_SKY_SUMMIT_QWERTY)
		nRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"ControlPanel\\keypad\\qwerty", 0, NULL, &hKey);

    if(nRet != ERROR_SUCCESS)
	{
		AfxMessageBox(_T("Reg Save Fail"));
        return;
	}

	dwData = nLeftUp;
    nRet = RegSetValueEx(hKey, _T("LeftUpKey"), 0, REG_DWORD, (LPBYTE)&dwData, sizeof(DWORD));
    
    if(nRet != ERROR_SUCCESS)
    {
		AfxMessageBox(_T("Reg Save Fail"));
        RegCloseKey(hKey);
        return;
    }

	dwData = nLeftDown;
    nRet = RegSetValueEx(hKey, _T("LeftDownKey"), 0, REG_DWORD, (LPBYTE)&dwData, sizeof(DWORD));
    
    if(nRet != ERROR_SUCCESS)
    {
		AfxMessageBox(_T("Reg Save Fail"));
        RegCloseKey(hKey);
        return;
    }

	dwData = nRightUp;
    nRet = RegSetValueEx(hKey, _T("RightUpKey"), 0, REG_DWORD, (LPBYTE)&dwData, sizeof(DWORD));
    
    if(nRet != ERROR_SUCCESS)
    {
		AfxMessageBox(_T("Reg Save Fail"));
        RegCloseKey(hKey);
        return;
    }

	dwData = nRightDown;
    nRet = RegSetValueEx(hKey, _T("RightDownKey"), 0, REG_DWORD, (LPBYTE)&dwData, sizeof(DWORD));
    
    if(nRet != ERROR_SUCCESS)
    {
		AfxMessageBox(_T("Reg Save Fail"));
        RegCloseKey(hKey);
        return;
    }

	dwData = nSoft1;
    nRet = RegSetValueEx(hKey, _T("Soft1Key"), 0, REG_DWORD, (LPBYTE)&dwData, sizeof(DWORD));
    
    if(nRet != ERROR_SUCCESS)
    {
		AfxMessageBox(_T("Reg Save Fail"));
        RegCloseKey(hKey);
        return;
    }

	dwData = nSoft2;
    nRet = RegSetValueEx(hKey, _T("Soft2Key"), 0, REG_DWORD, (LPBYTE)&dwData, sizeof(DWORD));
    
    if(nRet != ERROR_SUCCESS)
    {
		AfxMessageBox(_T("Reg Save Fail"));
        RegCloseKey(hKey);
        return;
    }

    RegCloseKey(hKey);


	// Set Tag Type
	char cType[2] = {0,0};
	memset(buffer, 0x00, 514);

	int nType = m_cmboxSelectTagType.GetCurSel();
	switch(nType)
	{
	case ISO_14443_TYPE_A:
		cType[0] = 'a';
		break;
	case ISO_14443_TYPE_B:
		cType[0] = 'b';
		break;
	case ICODE_UID:
		cType[0] = 'd';
		break;
	case ICODE_EPC:
		cType[0] = 'e';
		break;
	case ICODE:
		cType[0] = 'i';
		break;
	case SR176:
		cType[0] = 's';
		break;
	case ACTIVATE_ALL_TAG:
		cType[0] = 't';
		break;
	case ISO_15693:
		cType[0] = 'v';
		break;
	}

	wcscpy(Reader_Option.szTagType, m_lstType);

	RDR_SendCommandGetData("o", cType, buffer);
	Sleep(100);

	CString szTemp;
	szTemp.Format(L"%S", buffer);
	RETAILMSG(RT_MSG,(L"Tag result: (%s:%s)\r\n",m_lstType, szTemp));
	RETAILMSG(RT_MSG,(L"=======================\r\n"));
	//

	if(Reader_Option.bAntenna)
		RDR_SendCommandGetData("pon", "", buffer);
	else
		RDR_SendCommandGetData("poff", "", buffer);

	(CPropertySheet *)GetParent()->SendMessage(PSM_SETCURSEL, 0);
	dlg->SetFocus();
}

void COption::OnBnClickedCancel()
{
	(CPropertySheet *)GetParent()->SendMessage(PSM_SETCURSEL, 0);	

	CRF_ID_DemoDlg * dlg = (CRF_ID_DemoDlg *)AfxGetMainWnd();
	dlg->SetFocus();
}

void COption::OnBnClickedBtnReset()
{
	char buffer[514];
	memset(buffer, 0x00, 514);
	RDR_SendCommandGetData("x", "", buffer);
	Sleep(1000);
	RDR_SendCommandGetData("poff", "", buffer);
}


/* 
// 2010-08-10 delete jjy 
// This functions, RDR_SleepComm and RDR_WakeupComm, have problem
// If use this function, then doesn't kill rfid process.

void COption::OnBnClickedBtnSleep()
{
	if(!m_bSleep)
	{
		RDR_SleepComm();
		m_bSleep = TRUE;
	}
}

void COption::OnBnClickedBtnWakeup()
{
	if(m_bSleep)
	{
		char buffer[514];
		memset(buffer, 0x00, 514);
		RDR_WakeupComm();
		
		Sleep(100);
		RDR_SendCommandGetData("poff", "", buffer);
		m_bSleep = FALSE;
	}

}
*/

