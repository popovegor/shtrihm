#ifndef _MC7500_IOCTL_H_
#define _MC7500_IOCTL_H_

#define IOCTL_HAL_GET_BUILDSTR 		CTL_CODE(FILE_DEVICE_HAL, 2051, METHOD_BUFFERED, FILE_ANY_ACCESS)


/*
//20060304 kbj ----------------------------------------------------------------------------------
#define IOCTL_HAL_LCD_ONOFF 			CTL_CODE(FILE_DEVICE_HAL, 2053, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_HAL_CPLD_STATUS_SET   	CTL_CODE(FILE_DEVICE_HAL, 2054, METHOD_BUFFERED, FILE_ANY_ACCESS)   //20060420 kbj added
*/

//20061110 kbj  M3 Plus�� ȣȯ���� 
#define IOCTL_HAL_BT_POWER_SEL		CTL_CODE(FILE_DEVICE_HAL, 2055 , METHOD_BUFFERED, FILE_ANY_ACCESS)

//20060817 kbj For Bluetooth control -----------------------------------------------------------------
#define IOCTL_HAL_BTH_PWR_EN   		CTL_CODE(FILE_DEVICE_HAL, 2075, METHOD_BUFFERED, FILE_ANY_ACCESS)   //20060420 kbj added
#define IOCTL_HAL_BTH_PWR_DIS  		CTL_CODE(FILE_DEVICE_HAL, 2076, METHOD_BUFFERED, FILE_ANY_ACCESS)   //20060420 kbj added

#define IOCTL_HAL_WLAN_ONOFF 			CTL_CODE(FILE_DEVICE_HAL, 2077, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define IOCTL_HAL_CPLD_CTRL_WRITE        CTL_CODE(FILE_DEVICE_HAL, 2078, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_HAL_CPLD_READ          		CTL_CODE(FILE_DEVICE_HAL, 2079, METHOD_BUFFERED, FILE_ANY_ACCESS)

// 2007.08.08 chpark �߰�
#define IOCTL_HAL_REGIST_WAKEUPSRC  CTL_CODE(FILE_DEVICE_HAL, 2080, METHOD_BUFFERED, FILE_ANY_ACCESS)

// 2007.10.30 chpark �߰�
// Clock Frequency Change CODE - 
#define IOCTL_HAL_CHANGE_CLOCKFREQ		CTL_CODE(FILE_DEVICE_HAL, 2081, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define IOCTL_HAL_ENTER_DEEPSLEEP		CTL_CODE(FILE_DEVICE_HAL, 2082, METHOD_BUFFERED, FILE_ANY_ACCESS)	// MHR 20080119
#define IOCTL_HAL_GET_BOOT_OS_INFO     CTL_CODE(FILE_DEVICE_HAL, 2083, METHOD_BUFFERED, FILE_ANY_ACCESS)	// KBJ 20080408
#define IOCTL_HAL_GET_BATT_OFFSET_INFO CTL_CODE(FILE_DEVICE_HAL, 2084, METHOD_BUFFERED, FILE_ANY_ACCESS)  // MHR 20080814 - adds
#define IOCTL_HAL_GET_BATT_CAL_VALID_INFO CTL_CODE(FILE_DEVICE_HAL, 2085, METHOD_BUFFERED, FILE_ANY_ACCESS)  // MHR 20080814 - adds

// 2008.09.17 chpark
// Application���� Platform�� �� �� �ֵ��� code �߰�
// 7700�� 7500 Scanner DLL�� �ٸ���.
#define IOCTL_HAL_GET_PLATFORMID	CTL_CODE(FILE_DEVICE_HAL, 2086, METHOD_BUFFERED, FILE_ANY_ACCESS)

// 20081222 KBJ ADDS
#define IOCTL_HAL_GET_PRODUCTID		CTL_CODE(FILE_DEVICE_HAL, 2087, METHOD_BUFFERED, FILE_ANY_ACCESS)


// 2007.08.27 chpark �߰�
// Power Applet���� ���
#define IOCTL_HAL_GET_WAKEUPSRC		0x0
#define IOCTL_HAL_SET_WAKEUPSRC		0x1

#define IOCTL_KEYWAKEUP_NOUSE		0x0
#define IOCTL_KEYWAKEUP_USE			0x1

// ID for CPLD Information -------------------------------------------------------------------------
#define CPLD_ID_VER					0x0
#define CPLD_ID_SPD_CFG			0x1
#define CPLD_ID_FLSH_CFG            	0x2
#define CPLD_ID_RAM_CFG			0x3
#define CPLD_ID_CHARGE_DONE	   	0x4
#define CPLD_ID_nAC_OK				0x5
#define CPLD_ID_nLOWBATT			0x6
#define CPLD_ID_nWLAN_DET			0x7
#define CPLD_ID_LCD_ON				0x8
#define CPLD_ID_LCD_SD  			0x9
#define CPLD_ID_CAM_ON      			0xa
#define CPLD_ID_CAM_RST    			0xb
#define CPLD_ID_FLSH_ON   			0xc
#define CPLD_ID_BAT_SEL    			0xd
#define CPLD_ID_LED_ON    			0xe
#define CPLD_ID_KEYLIGHT_ON		0x10
#define CPLD_ID_WLAN_ON  			0x11
#define CPLD_ID_WLAN_RST 			0x12
#define CPLD_ID_nWLAN_PD   			0x13
#define CPLD_ID_IGT					0x14
#define CPLD_ID_MOTOR_ON   			0x15
#define CPLD_ID_VOICE_CALL			0x16
#define CPLD_ID_AC97_ON    			0x17
#define CPLD_ID_SPK_ON				0x18
#define CPLD_ID_MIC_ON				0x19
#define CPLD_ID_XUART_ON  			0x1a
#define CPLD_ID_XUARTB_RST 		0x1b
#define CPLD_ID_SCANNER_ON		0x1c
#define CPLD_ID_nIRDA_ON   			0x1d
#define CPLD_ID_GPS_ON    			0x1e
#define CPLD_ID_nGPS_RST			0x1f
#define CPLD_ID_USB_CTRL			0x1f		// 20080115 kbj adds
#define CPLD_ID_BT_ON     			0x20
#define CPLD_ID_BT_RST	  			0x21
#define CPLD_ID_USBDET_EN			0x22
#define CPLD_ID_XUARTA_RST 		0x23		// 20071009 pp1 adds

// 20080115 KBJ ADDS FOR PP2
#define CPLD_ID_RFID_ON			0x24
#define CPLD_ID_RFID_RST			0x25

// MHR 20080827 - 
#define CPLD_ID_LCD_RST				0x26
#define CPLD_ID_624_ON				0x27

// 20081009 JSA Adds
#define CPLD_ID_BOARD_VER			0x28
#define CPLD_ID_MODEL_VER			0x29

#define CPLD_ID_CTRL_ALL			0xfe
#define CPLD_ID_STATE_ALL			0xff

#define CPLD_ID_MIN					CPLD_ID_VER
#define CPLD_ID_WRITE_MIN			CPLD_ID_LCD_ON
//#define CPLD_ID_MAX				CPLD_ID_USBDET_EN		
#ifndef BSP_PP2
#define CPLD_ID_MAX					CPLD_ID_XUARTA_RST		//20071009 pp1 addds
#else
//#define CPLD_ID_MAX				CPLD_ID_RFID_RST		//20080115 pp2 addds
//#define CPLD_ID_MAX				CPLD_ID_624_ON		//20080827 MC7700S addds
#define CPLD_ID_MAX					CPLD_ID_MODEL_VER		//20081010 addds
#endif

#define CPLD_ERR_READ_NONE		0xFFFF

//2007.10.30 chpark
// Address
#define CLOCKFREQ_CHANGE					0x00000041		
// 2007.10.30 chpark
// Core Frequency Change struct
typedef struct _CORE_FREQ_CHANGE {
	DWORD dwPAddr;
	DWORD dwFreq;
} CORE_FREQ_CHANGE, *PCORE_FREQ_CHANGE;

// 20080408 KBJ ADDS --------------
typedef struct _BOOT_OS_INFO{
	DWORD	BootVer;
	TCHAR	szOSName[15];
} BOOT_OS_INFO, *PBOOT_OS_INFO;

#define CAMERA_INIT_DONE_EVENTNAME	TEXT("CAMERA_INIT_DONE_EVENT")
#endif
