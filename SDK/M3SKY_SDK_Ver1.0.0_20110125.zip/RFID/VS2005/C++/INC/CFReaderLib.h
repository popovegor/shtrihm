#pragma once

struct readerConfig
{
  long baudRate;  
  char protocol;  
  unsigned char stationID;
};

struct presetSettings 
{
  long baudRate;  
  char protocol;  
};

// Opens and initializes a specified communication device and a reader at once. This function only works with one reader module.
char  __cdecl RDR_OpenSingle(char* commDevice, char autodetect, short knownReader, struct presetSettings* settings);

// Detect serial port with connected reader.
char* __cdecl RDR_DetectSerialPort(char* buffer);

// Returns the power resume state.
char  __cdecl RDR_GetResumeState();

// Opens and initializes a specified communication device.
char  __cdecl RDR_OpenComm(char* commDevice, char autodetect, struct presetSettings* settings);

// Gives control of RTS and DTR pins.
void  __cdecl RDR_CommExtFunction(long function);

// Closes and releases the communication device.
void  __cdecl RDR_CloseComm();

// Closes the communication device but does not release communication resources.
void  __cdecl RDR_SleepComm();

// Reopens the communication without allocating communication resources.
char  __cdecl RDR_WakeupComm();

// Empties the receive buffer of the communication device.
void  __cdecl RDR_EmptyCommRcvBuffer();

// Aborts the continuous read command. (This function is obsolete, use RDR_AbortContinuousReadExt)
void  __cdecl RDR_AbortContinuousRead();

// Aborts the continuous read command.
void  __cdecl RDR_AbortContinuousReadExt();

// Sets and applies the transfer protocol of the communication device.
void  __cdecl RDR_SetCommProtocol(char protocol);

// Returns the active transfer protocol of the communication device.
char  __cdecl RDR_GetCommProtocol();

// Sets and applies the baud rate of the communication device.
void  __cdecl RDR_SetCommBaudRate(long bdRate);

// Gets the current baud rate of the communication device.
long  __cdecl RDR_GetCommBaudRate();

// Sets and applies the continuous receive mode of the commnication device.
void  __cdecl RDR_SetCommContRcv(char contReceiveMode);

// Returns the state of continuous receive mode.
char  __cdecl RDR_GetCommContRcv();

// Sets and applies the timeout of the communication device.
void  __cdecl RDR_SetCommTimeout(long timeout);

// Returns the timeout of the communication device.
long  __cdecl RDR_GetCommTimeout();

// Detect station ID of a reader.
char  __cdecl RDR_DetectReader();

// Opens a reader with specified ID.
char  __cdecl RDR_OpenReader(unsigned char id, short knownReader);

// Closes a reader.
void  __cdecl RDR_CloseReader();

// Resets a reader.
void  __cdecl RDR_ResetReader();

// Sends a command to a reader.
long  __cdecl RDR_SendCommand(char* command, char* data);

// Receives data from a reader.
char* __cdecl RDR_GetData(char* buffer);

// Sends a command to a reader and receives data.
char* __cdecl RDR_SendCommandGetData(char* command, char* data, char* buffer);

// Receives data from a reader with timeout.
char* __cdecl RDR_GetDataTimeout(char* buffer, long timeout);

// Sends a command to a reader and receives data with timeout.
char* __cdecl RDR_SendCommandGetDataTimeout(char* command, char* data, char* buffer, long timeout);

// Sets and applies the reader with specified configuration. The communication device even adapted to this new settings.
char  __cdecl RDR_SetReaderConfig(struct readerConfig* config);

// Returns current reader configuration.
struct readerConfig __cdecl RDR_GetReaderConfig();

// Returns the version string of the reader.
char* __cdecl RDR_GetReaderType(char* buffer);

// Returns the station ID of the reader.
unsigned char __cdecl RDR_GetStationID();

// Check if a script command is available for the reader.
char  __cdecl RDR_IsCommandAvailable(char* command);

// Returns the device ID of the reader.
char* __cdecl RDR_GetDeviceID(char* buffer);

// Activates/deactivates broadcast mode of binary protocol using the reader.
void  __cdecl RDR_SetBroadcast(char broadcast);

// Returns the state of broadcast mode of the reader.
char  __cdecl RDR_GetBroadcast();

// Returns the version of the DLL. (This function is obsolete, use GetDLLVersionStr)
long  __cdecl RDR_GetDLLVersion(void);

// Returns the version of the DLL as string.
char* __cdecl RDR_GetDLLVersionStr(char* buffer);

// Activates/deactivates debug output for the reader.
void  __cdecl RDR_SetDebugOutputState(char state);

// Returns the state of debug output for the reader.
char  __cdecl RDR_GetDebugOutputState();

// Returns the debug output for the reader.
char* __cdecl RDR_GetDebugOutput(char* buffer);

// Starts the timer for the reader.
void  __cdecl RDR_StartTimer();

// Returns the response time for the reader.
float __cdecl RDR_GetTiming();

// Returns the flag of the binary protocol v2 for the reader.
char  __cdecl RDR_GetBinFlag();

// Returns the used binary protocol type for the reader.
char  __cdecl RDR_GetBinProtocol();

// Prepares the firmware upload and checks the password.
long  __cdecl RDR_LoadFirmware(char* data, long length, char* password, char option);

// Initialize the firmware update.
void  __cdecl RDR_InitUpdateFirmware();

// Update one line of the firmware. Call this function until the upload is finished.
char  __cdecl RDR_UpdateFirmware();

// Encrypts data using DES algorithm.
char* __cdecl RDR_DESEncrypt(char options, char* key, char* data, long length, char* output);

// Decrypts data using DES algorithm.
char* __cdecl RDR_DESDecrypt(char options, char* key, char* data, long length, char* output);

// DESFire command set.
char* __cdecl RDR_DESFire(char command, char* data, char* output);

// Sets the timeout of the DESFire SAM.
void  __cdecl RDR_SetDESFireSAMTimeout(char timeout);

// Returns the timeout of the DESFire SAM.
char  __cdecl RDR_GetDESFireSAMTimeout();

// Enables/disables high baud rates (230400 + 460800 Baud).
void  __cdecl RDR_SetHighBaudrates(char enable);

// Returns the state of using high baud rates.
char  __cdecl RDR_GetHighBaudrates();


// DESFire and SAM definitions
#define DESFIRE_SAM_ON_OFF                0x00
#define DESFIRE_AUTHENICATE               0x01
#define DESFIRE_CHANGE_KEY_SETTINGS       0x02
#define DESFIRE_GET_KEY_SETTINGS          0x03
#define DESFIRE_CHANGE_KEY                0x04
#define DESFIRE_GET_KEY_VERSION           0x05
#define DESFIRE_CREATE_APPLICATION        0x06
#define DESFIRE_DELETE_APPLICATION        0x07
#define DESFIRE_GET_APPLICATION_IDS       0x08
#define DESFIRE_SELECT_APPLICATION        0x09
#define DESFIRE_FORMAT_PICC               0x0A
#define DESFIRE_GET_VERSION               0x0B
#define DESFIRE_GET_FILE_IDS              0x0C
#define DESFIRE_GET_FILE_SETTINGS         0x0D
#define DESFIRE_CHANGE_FILE_SETTINGS      0x0E
#define DESFIRE_CREATE_STANDARD_DATA_FILE 0x0F
#define DESFIRE_CREATE_BACKUP_DATA_FILE   0x10
#define DESFIRE_CREATE_VALUE_FILE         0x11
#define DESFIRE_CREATE_LINEAR_RECORD_FILE 0x12
#define DESFIRE_CREATE_CYCLIC_RECORD_FILE 0x13
#define DESFIRE_DELETE_FILE               0x14
#define DESFIRE_READ_DATA                 0x15
#define DESFIRE_READ_RECORDS              0x16
#define DESFIRE_WRITE_DATA                0x17
#define DESFIRE_WRITE_RECORDS             0x18
#define DESFIRE_GET_VALUE                 0x19
#define DESFIRE_CREDIT                    0x1A
#define DESFIRE_DEBIT                     0x1B
#define DESFIRE_LIMITED_CREDIT            0x1C
#define DESFIRE_CLEAR_RECORD_FILE         0x1D
#define DESFIRE_COMMIT_TRANSACTION        0x1E
#define DESFIRE_ABORT_TRANSACTION         0x1F
#define DESFIRE_SET_FILE_SETTINGS         0x20

#define SAM_DISABLE_CRYPTO                0x30
#define SAM_CHANGE_KEY_ENTRY              0x31
#define SAM_GET_KEY_ENTRY                 0x32
#define SAM_CHANGE_KUC_ENTRY              0x33
#define SAM_GET_KUC_ENTRY                 0x34
#define SAM_CHANGE_KEY_PICC               0x35
#define SAM_GET_VERSION                   0x36
#define SAM_AUTHENTICATE_HOST             0x37
#define SAM_SELECT_APPLICATION            0x38
#define SAM_DUMP_SESSION_KEY              0x39
#define SAM_LOAD_INIT_VECTOR              0x3A
#define SAM_AUTHENTICATE_PICC1            0x3B
#define SAM_AUTHENTICATE_PICC2            0x3C
#define SAM_VERIFY_MAC                    0x3D
#define SAM_GENERATE_MAC                  0x3E
#define SAM_DECIPHER_DATA                 0x3F
#define SAM_ENCIPHER_DATA                 0x40
#define SAM_SET_LOGICAL_CHANNEL           0x42

