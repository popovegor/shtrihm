<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    private mainMenu1 As System.Windows.Forms.MainMenu

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.m_tbMain = New System.Windows.Forms.TabControl
        Me.m_tbReadWrite = New System.Windows.Forms.TabPage
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.lst_Msg = New System.Windows.Forms.ListBox
        Me.txt_Serial = New System.Windows.Forms.TextBox
        Me.txt_Data = New System.Windows.Forms.TextBox
        Me.txt_Block = New System.Windows.Forms.TextBox
        Me.Btn_Write = New System.Windows.Forms.Button
        Me.Btn_Stop = New System.Windows.Forms.Button
        Me.Btn_Read = New System.Windows.Forms.Button
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Version = New System.Windows.Forms.Button
        Me.Btn_Open = New System.Windows.Forms.Button
        Me.m_tbOption = New System.Windows.Forms.TabPage
        Me.Btn_Apply = New System.Windows.Forms.Button
        Me.Btn_Reset = New System.Windows.Forms.Button
        Me.Btn_Cancel = New System.Windows.Forms.Button
        Me.Cmb_WriteBtn = New System.Windows.Forms.ComboBox
        Me.label4 = New System.Windows.Forms.Label
        Me.Cmb_ReadBtn = New System.Windows.Forms.ComboBox
        Me.label3 = New System.Windows.Forms.Label
        Me.Cmb_TagType = New System.Windows.Forms.ComboBox
        Me.label2 = New System.Windows.Forms.Label
        Me.panel2 = New System.Windows.Forms.Panel
        Me.label1 = New System.Windows.Forms.Label
        Me.Opt_AntOff = New System.Windows.Forms.RadioButton
        Me.Opt_AntOn = New System.Windows.Forms.RadioButton
        Me.panel1 = New System.Windows.Forms.Panel
        Me.Opt_Continue = New System.Windows.Forms.RadioButton
        Me.Opt_ASync = New System.Windows.Forms.RadioButton
        Me.Opt_Sync = New System.Windows.Forms.RadioButton
        Me.m_tbMain.SuspendLayout()
        Me.m_tbReadWrite.SuspendLayout()
        Me.m_tbOption.SuspendLayout()
        Me.panel2.SuspendLayout()
        Me.panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'm_tbMain
        '
        Me.m_tbMain.Controls.Add(Me.m_tbReadWrite)
        Me.m_tbMain.Controls.Add(Me.m_tbOption)
        Me.m_tbMain.Location = New System.Drawing.Point(0, 0)
        Me.m_tbMain.Name = "m_tbMain"
        Me.m_tbMain.SelectedIndex = 0
        Me.m_tbMain.Size = New System.Drawing.Size(240, 268)
        Me.m_tbMain.TabIndex = 0
        '
        'm_tbReadWrite
        '
        Me.m_tbReadWrite.Controls.Add(Me.Btn_Close)
        Me.m_tbReadWrite.Controls.Add(Me.lst_Msg)
        Me.m_tbReadWrite.Controls.Add(Me.txt_Serial)
        Me.m_tbReadWrite.Controls.Add(Me.txt_Data)
        Me.m_tbReadWrite.Controls.Add(Me.txt_Block)
        Me.m_tbReadWrite.Controls.Add(Me.Btn_Write)
        Me.m_tbReadWrite.Controls.Add(Me.Btn_Stop)
        Me.m_tbReadWrite.Controls.Add(Me.Btn_Read)
        Me.m_tbReadWrite.Controls.Add(Me.Btn_Clear)
        Me.m_tbReadWrite.Controls.Add(Me.Btn_Version)
        Me.m_tbReadWrite.Controls.Add(Me.Btn_Open)
        Me.m_tbReadWrite.Location = New System.Drawing.Point(0, 0)
        Me.m_tbReadWrite.Name = "m_tbReadWrite"
        Me.m_tbReadWrite.Size = New System.Drawing.Size(240, 245)
        Me.m_tbReadWrite.Text = "Read Write"
        '
        'Btn_Close
        '
        Me.Btn_Close.Location = New System.Drawing.Point(156, 18)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(65, 20)
        Me.Btn_Close.TabIndex = 27
        Me.Btn_Close.Text = "Close"
        '
        'lst_Msg
        '
        Me.lst_Msg.Location = New System.Drawing.Point(20, 98)
        Me.lst_Msg.Name = "lst_Msg"
        Me.lst_Msg.Size = New System.Drawing.Size(201, 72)
        Me.lst_Msg.TabIndex = 26
        '
        'txt_Serial
        '
        Me.txt_Serial.Location = New System.Drawing.Point(20, 71)
        Me.txt_Serial.Name = "txt_Serial"
        Me.txt_Serial.Size = New System.Drawing.Size(201, 21)
        Me.txt_Serial.TabIndex = 25
        '
        'txt_Data
        '
        Me.txt_Data.Location = New System.Drawing.Point(75, 44)
        Me.txt_Data.Name = "txt_Data"
        Me.txt_Data.Size = New System.Drawing.Size(146, 21)
        Me.txt_Data.TabIndex = 24
        Me.txt_Data.Text = "12345678901234567890098765432112"
        '
        'txt_Block
        '
        Me.txt_Block.Location = New System.Drawing.Point(20, 44)
        Me.txt_Block.Name = "txt_Block"
        Me.txt_Block.Size = New System.Drawing.Size(49, 21)
        Me.txt_Block.TabIndex = 23
        Me.txt_Block.Text = "04"
        '
        'Btn_Write
        '
        Me.Btn_Write.Location = New System.Drawing.Point(158, 206)
        Me.Btn_Write.Name = "Btn_Write"
        Me.Btn_Write.Size = New System.Drawing.Size(63, 20)
        Me.Btn_Write.TabIndex = 22
        Me.Btn_Write.Text = "WRITE"
        '
        'Btn_Stop
        '
        Me.Btn_Stop.Location = New System.Drawing.Point(89, 206)
        Me.Btn_Stop.Name = "Btn_Stop"
        Me.Btn_Stop.Size = New System.Drawing.Size(63, 20)
        Me.Btn_Stop.TabIndex = 21
        Me.Btn_Stop.Text = "STOP"
        '
        'Btn_Read
        '
        Me.Btn_Read.Location = New System.Drawing.Point(20, 206)
        Me.Btn_Read.Name = "Btn_Read"
        Me.Btn_Read.Size = New System.Drawing.Size(63, 20)
        Me.Btn_Read.TabIndex = 20
        Me.Btn_Read.Text = "READ"
        '
        'Btn_Clear
        '
        Me.Btn_Clear.Location = New System.Drawing.Point(158, 180)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(63, 20)
        Me.Btn_Clear.TabIndex = 19
        Me.Btn_Clear.Text = "CLEAR"
        '
        'Btn_Version
        '
        Me.Btn_Version.Location = New System.Drawing.Point(20, 180)
        Me.Btn_Version.Name = "Btn_Version"
        Me.Btn_Version.Size = New System.Drawing.Size(63, 20)
        Me.Btn_Version.TabIndex = 18
        Me.Btn_Version.Text = "VERSION"
        '
        'Btn_Open
        '
        Me.Btn_Open.Location = New System.Drawing.Point(20, 18)
        Me.Btn_Open.Name = "Btn_Open"
        Me.Btn_Open.Size = New System.Drawing.Size(63, 20)
        Me.Btn_Open.TabIndex = 17
        Me.Btn_Open.Text = "Open"
        '
        'm_tbOption
        '
        Me.m_tbOption.Controls.Add(Me.Btn_Apply)
        Me.m_tbOption.Controls.Add(Me.Btn_Reset)
        Me.m_tbOption.Controls.Add(Me.Btn_Cancel)
        Me.m_tbOption.Controls.Add(Me.Cmb_WriteBtn)
        Me.m_tbOption.Controls.Add(Me.label4)
        Me.m_tbOption.Controls.Add(Me.Cmb_ReadBtn)
        Me.m_tbOption.Controls.Add(Me.label3)
        Me.m_tbOption.Controls.Add(Me.Cmb_TagType)
        Me.m_tbOption.Controls.Add(Me.label2)
        Me.m_tbOption.Controls.Add(Me.panel2)
        Me.m_tbOption.Controls.Add(Me.panel1)
        Me.m_tbOption.Location = New System.Drawing.Point(0, 0)
        Me.m_tbOption.Name = "m_tbOption"
        Me.m_tbOption.Size = New System.Drawing.Size(240, 245)
        Me.m_tbOption.Text = "Option"
        '
        'Btn_Apply
        '
        Me.Btn_Apply.Location = New System.Drawing.Point(163, 215)
        Me.Btn_Apply.Name = "Btn_Apply"
        Me.Btn_Apply.Size = New System.Drawing.Size(64, 20)
        Me.Btn_Apply.TabIndex = 35
        Me.Btn_Apply.Text = "Apply"
        '
        'Btn_Reset
        '
        Me.Btn_Reset.Location = New System.Drawing.Point(88, 215)
        Me.Btn_Reset.Name = "Btn_Reset"
        Me.Btn_Reset.Size = New System.Drawing.Size(64, 20)
        Me.Btn_Reset.TabIndex = 34
        Me.Btn_Reset.Text = "Reset"
        '
        'Btn_Cancel
        '
        Me.Btn_Cancel.Location = New System.Drawing.Point(12, 215)
        Me.Btn_Cancel.Name = "Btn_Cancel"
        Me.Btn_Cancel.Size = New System.Drawing.Size(64, 20)
        Me.Btn_Cancel.TabIndex = 33
        Me.Btn_Cancel.Text = "Cancel"
        '
        'Cmb_WriteBtn
        '
        Me.Cmb_WriteBtn.Items.Add("LeftUpKey")
        Me.Cmb_WriteBtn.Items.Add("LeftDownKey")
        Me.Cmb_WriteBtn.Items.Add("RightUpKey")
        Me.Cmb_WriteBtn.Items.Add("RightDownKey")
        Me.Cmb_WriteBtn.Items.Add("Soft1Key")
        Me.Cmb_WriteBtn.Items.Add("Soft2Key")
        Me.Cmb_WriteBtn.Location = New System.Drawing.Point(121, 160)
        Me.Cmb_WriteBtn.Name = "Cmb_WriteBtn"
        Me.Cmb_WriteBtn.Size = New System.Drawing.Size(107, 22)
        Me.Cmb_WriteBtn.TabIndex = 32
        '
        'label4
        '
        Me.label4.Location = New System.Drawing.Point(128, 140)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(100, 17)
        Me.label4.Text = "Write Button"
        '
        'Cmb_ReadBtn
        '
        Me.Cmb_ReadBtn.Items.Add("LeftUpKey")
        Me.Cmb_ReadBtn.Items.Add("LeftDownKey")
        Me.Cmb_ReadBtn.Items.Add("RightUpKey")
        Me.Cmb_ReadBtn.Items.Add("RightDownKey")
        Me.Cmb_ReadBtn.Items.Add("Soft1Key")
        Me.Cmb_ReadBtn.Items.Add("Soft2Key")
        Me.Cmb_ReadBtn.Location = New System.Drawing.Point(12, 160)
        Me.Cmb_ReadBtn.Name = "Cmb_ReadBtn"
        Me.Cmb_ReadBtn.Size = New System.Drawing.Size(107, 22)
        Me.Cmb_ReadBtn.TabIndex = 31
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(19, 140)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(100, 17)
        Me.label3.Text = "Read Button"
        '
        'Cmb_TagType
        '
        Me.Cmb_TagType.Items.Add("use all")
        Me.Cmb_TagType.Items.Add("use icode")
        Me.Cmb_TagType.Items.Add("use 14443a")
        Me.Cmb_TagType.Items.Add("use 14443b")
        Me.Cmb_TagType.Items.Add("use 15693")
        Me.Cmb_TagType.Items.Add("use sr176")
        Me.Cmb_TagType.Items.Add("use tagit")
        Me.Cmb_TagType.Location = New System.Drawing.Point(12, 113)
        Me.Cmb_TagType.Name = "Cmb_TagType"
        Me.Cmb_TagType.Size = New System.Drawing.Size(215, 22)
        Me.Cmb_TagType.TabIndex = 30
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(19, 94)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(100, 17)
        Me.label2.Text = "Select Tag Type"
        '
        'panel2
        '
        Me.panel2.Controls.Add(Me.label1)
        Me.panel2.Controls.Add(Me.Opt_AntOff)
        Me.panel2.Controls.Add(Me.Opt_AntOn)
        Me.panel2.Location = New System.Drawing.Point(12, 9)
        Me.panel2.Name = "panel2"
        Me.panel2.Size = New System.Drawing.Size(216, 37)
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(7, 10)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(57, 21)
        Me.label1.Text = "Antenna"
        '
        'Opt_AntOff
        '
        Me.Opt_AntOff.Checked = True
        Me.Opt_AntOff.Location = New System.Drawing.Point(143, 9)
        Me.Opt_AntOff.Name = "Opt_AntOff"
        Me.Opt_AntOff.Size = New System.Drawing.Size(51, 20)
        Me.Opt_AntOff.TabIndex = 1
        Me.Opt_AntOff.Text = "Off"
        '
        'Opt_AntOn
        '
        Me.Opt_AntOn.Location = New System.Drawing.Point(86, 9)
        Me.Opt_AntOn.Name = "Opt_AntOn"
        Me.Opt_AntOn.Size = New System.Drawing.Size(51, 20)
        Me.Opt_AntOn.TabIndex = 0
        Me.Opt_AntOn.TabStop = False
        Me.Opt_AntOn.Text = "On"
        '
        'panel1
        '
        Me.panel1.Controls.Add(Me.Opt_Continue)
        Me.panel1.Controls.Add(Me.Opt_ASync)
        Me.panel1.Controls.Add(Me.Opt_Sync)
        Me.panel1.Location = New System.Drawing.Point(12, 52)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(216, 37)
        '
        'Opt_Continue
        '
        Me.Opt_Continue.Location = New System.Drawing.Point(122, 11)
        Me.Opt_Continue.Name = "Opt_Continue"
        Me.Opt_Continue.Size = New System.Drawing.Size(84, 20)
        Me.Opt_Continue.TabIndex = 4
        Me.Opt_Continue.TabStop = False
        Me.Opt_Continue.Text = "Continuous"
        '
        'Opt_ASync
        '
        Me.Opt_ASync.Location = New System.Drawing.Point(66, 11)
        Me.Opt_ASync.Name = "Opt_ASync"
        Me.Opt_ASync.Size = New System.Drawing.Size(57, 20)
        Me.Opt_ASync.TabIndex = 3
        Me.Opt_ASync.TabStop = False
        Me.Opt_ASync.Text = "Sync"
        '
        'Opt_Sync
        '
        Me.Opt_Sync.Checked = True
        Me.Opt_Sync.Location = New System.Drawing.Point(7, 11)
        Me.Opt_Sync.Name = "Opt_Sync"
        Me.Opt_Sync.Size = New System.Drawing.Size(57, 20)
        Me.Opt_Sync.TabIndex = 2
        Me.Opt_Sync.Text = "ASync"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(240, 268)
        Me.Controls.Add(Me.m_tbMain)
        Me.KeyPreview = True
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "RFID VB"
        Me.m_tbMain.ResumeLayout(False)
        Me.m_tbReadWrite.ResumeLayout(False)
        Me.m_tbOption.ResumeLayout(False)
        Me.panel2.ResumeLayout(False)
        Me.panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents m_tbMain As System.Windows.Forms.TabControl
    Friend WithEvents m_tbReadWrite As System.Windows.Forms.TabPage
    Friend WithEvents m_tbOption As System.Windows.Forms.TabPage
    Private WithEvents Btn_Close As System.Windows.Forms.Button
    Private WithEvents lst_Msg As System.Windows.Forms.ListBox
    Private WithEvents txt_Serial As System.Windows.Forms.TextBox
    Private WithEvents txt_Data As System.Windows.Forms.TextBox
    Private WithEvents txt_Block As System.Windows.Forms.TextBox
    Private WithEvents Btn_Write As System.Windows.Forms.Button
    Private WithEvents Btn_Stop As System.Windows.Forms.Button
    Private WithEvents Btn_Read As System.Windows.Forms.Button
    Private WithEvents Btn_Clear As System.Windows.Forms.Button
    Private WithEvents Btn_Version As System.Windows.Forms.Button
    Private WithEvents Btn_Open As System.Windows.Forms.Button
    Private WithEvents Btn_Apply As System.Windows.Forms.Button
    Private WithEvents Btn_Reset As System.Windows.Forms.Button
    Private WithEvents Btn_Cancel As System.Windows.Forms.Button
    Private WithEvents Cmb_WriteBtn As System.Windows.Forms.ComboBox
    Private WithEvents label4 As System.Windows.Forms.Label
    Private WithEvents Cmb_ReadBtn As System.Windows.Forms.ComboBox
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents Cmb_TagType As System.Windows.Forms.ComboBox
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents panel2 As System.Windows.Forms.Panel
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents Opt_AntOff As System.Windows.Forms.RadioButton
    Private WithEvents Opt_AntOn As System.Windows.Forms.RadioButton
    Private WithEvents panel1 As System.Windows.Forms.Panel
    Private WithEvents Opt_Continue As System.Windows.Forms.RadioButton
    Private WithEvents Opt_ASync As System.Windows.Forms.RadioButton
    Private WithEvents Opt_Sync As System.Windows.Forms.RadioButton

End Class
