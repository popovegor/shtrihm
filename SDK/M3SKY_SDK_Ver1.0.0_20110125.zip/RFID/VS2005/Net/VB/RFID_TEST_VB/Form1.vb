Imports System
Imports System.Threading
Imports Microsoft.Win32
Imports CFReaderDLLWrapper
Imports System.Windows.Forms
Imports System.Text


Public Class Form1

#Region " Declare "
    'Member variables

    'sound
    Private soundStr As String = "\\Windows\\alarm4.wav"

    'class
    Private dllACG As New ACG_CFReader()

    'Controls
    Private m_nLeftUpKey As Integer = 0
    Private m_nLeftDownKey As Integer = 0
    Private m_nRightUpKey As Integer = 0
    Private m_nRightDownKey As Integer = 0
    Private m_nSoft1Key As Integer = 0
    Private m_nSoft2Key As Integer = 0

    Private szTagType As String = "use all"
    Private szBlock As String = ""


    'Constant
    Private Const FILE_DEVICE_HAL As UInteger = &H101
    Private Const CPLD_ID_RFID_ON As UInteger = &H24
    Private Const CPLD_ID_RFID_RST As UInteger = &H25
    Private Const METHOD_BUFFERED As UInteger = 0
    Private Const FILE_ANY_ACCESS As UInteger = 0

    ' Variables
    Private m_bRead As Boolean = False
    Private m_nSyncMode As Integer = 0
    Private m_nAntenna As Integer = 0

    ' OEM
    Private Const SPI_GETOEMINFO As UInteger = 258
    Declare Function SystemParametersInfo Lib "Coredll.dll" _
    (ByVal uiAction As UInteger, ByVal uiParam As UInteger, ByVal pvParam As StringBuilder, ByVal fWinIni As UInteger) As Boolean

    ' Keypad const Type
    Private Const KEY_SKY_ORIGINAL As Integer = 0
    Private Const KEY_SKY_SUMMIT_NUMERIC As Integer = 1
    Private Const KEY_SKY_SUMMIT_QWERTY As Integer = 2

    Public m_nKeyPadType As Integer = KEY_SKY_ORIGINAL

    ' Function
    Declare Function KernelIoControl Lib "CoreDll.dll" _
        (ByVal dwIoControlCode As Int32, _
         ByRef lpInBuf As IntPtr, _
         ByVal nInBufSize As Integer, _
         ByRef lpOutBuf As Int32, _
         ByVal nOutBufSize As Integer, _
         ByRef lpBytesReturned As IntPtr _
        ) As Integer

    ' For Power    
    ' Constants
    Private Const PPN_UNATTENDEDMODE As Integer = 3
    Private Const POWER_STATE_SCREENOFF As UInteger = &H400000
    Private Const POWER_STATE_BACKLIGHTON As UInteger = &H2000000
    Private Const PBT_RESUME As UInteger = &H2
    Private Const POWER_NOTIFY_ALL As Long = &HFFFFFFFF

    'functions
    Public Declare Function PowerPolicyNotify Lib "coredll.dll" (ByVal dwMessage As Integer, ByVal dwData As Integer) As Boolean
    Public Declare Function RequestPowerNotifications Lib "coredll.dll" (ByVal hMsgQueue As IntPtr, ByVal flags As Long) As IntPtr
    Public Declare Function StopPowerNotifications Lib "coredll.dll" (ByVal hHandle As IntPtr) As Integer
    Public Declare Function CreateMsgQueue Lib "coredll.dll" (ByVal name As String, ByRef options As MsgQOptions) As IntPtr
    Public Declare Function CloseMsgQueue Lib "coredll.dll" (ByVal msgqueue As IntPtr) As Boolean
    Public Declare Function WaitForSingleObject Lib "coredll.dll" (ByVal hHandle As IntPtr, ByVal wait As Integer) As UInteger
    Public Declare Function ReadMsgQueue Lib "coredll.dll" (ByVal msgqueue As IntPtr, ByVal lpBuffer() As Byte, ByVal bufsize As UInteger, ByRef numRead As UInteger, ByVal timeout As Integer, ByRef flags As UInteger) As Boolean

    ' MsgQ option
    Public Structure MsgQOptions
        Public dwSize As UInteger
        Public dwFlags As UInteger
        Public dwMaxMessages As UInteger
        Public cbMaxMessage As UInteger
        Public bReadAccess As Boolean
    End Structure

    ' variable for power
    Private mMsgQueueHandle As IntPtr = IntPtr.Zero
    Private mPowerNotificationHandle As IntPtr = IntPtr.Zero
    Private MessageLoopThread As Threading.Thread = Nothing
    Private loopUntil As Boolean = False


#End Region

#Region " initialize form "

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'Button Disable
        Btn_Read.Enabled = False
        Btn_Stop.Enabled = False
        Btn_Write.Enabled = False
        Btn_Version.Enabled = False

        'init. combo
        Cmb_TagType.Text = "use all"
        Cmb_ReadBtn.Text = "RightDownKey"
        Cmb_WriteBtn.Text = "RightUpKey"

        m_nKeyPadType = GetKeypadType()


        'save Reg
        Dim rk As RegistryKey = Nothing
        ' each model
        If (m_nKeyPadType = KEY_SKY_ORIGINAL) Then
            rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\KeyPad\\SideKey", True)
        ElseIf (m_nKeyPadType = KEY_SKY_SUMMIT_NUMERIC) Then
            rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\keypad\\Numeric", True)
        ElseIf (m_nKeyPadType = KEY_SKY_SUMMIT_QWERTY) Then
            rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\keypad\\qwerty", True)
        End If

        m_nLeftUpKey = Convert.ToInt32(rk.GetValue("LeftUpKey", -1))
        m_nLeftDownKey = Convert.ToInt32(rk.GetValue("LeftDownKey", -1))
        m_nRightUpKey = Convert.ToInt32(rk.GetValue("RightUpKey", -1))
        m_nRightDownKey = Convert.ToInt32(rk.GetValue("RightDownKey", -1))
        m_nSoft1Key = Convert.ToInt32(rk.GetValue("Soft1Key", -1))
        m_nSoft2Key = Convert.ToInt32(rk.GetValue("Soft2Key", -1))

        ' key
        Me.KeyPreview = True

        ' For Power manage

        ' Set the options up for the messagequeue
        ' Create a thread that will monitor our message queue
        Me.MessageLoopThread = New Threading.Thread(AddressOf ThreadMsgQueueLoop)
        Me.MessageLoopThread.Start()

    End Sub

    Private Function GetKeypadType() As Integer
        Dim strModelType As StringBuilder = New StringBuilder(260)
        Const KEY_NUMERIC As Integer = 0
        Const KEY_QWERTY As Integer = 1

        SystemParametersInfo(SPI_GETOEMINFO, 260, strModelType, 0)

        If (strModelType.ToString = "MC7101") Or (strModelType.ToString = "MC7X01") Then
            Dim nKeyType As Integer = 0

            Dim rk As RegistryKey
            rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\keypad", True)

            If (rk Is Nothing) Then
                MessageBox.Show("Does not setting keypad type")
            Else
                nKeyType = Convert.ToInt32(rk.GetValue("KeypadType", -1))
            End If

            If nKeyType = KEY_NUMERIC Then
                Return KEY_SKY_SUMMIT_NUMERIC
            ElseIf nKeyType = KEY_QWERTY Then
                Return KEY_SKY_SUMMIT_QWERTY
            End If

        End If

        Return KEY_SKY_ORIGINAL

    End Function
    Private Sub ThreadMsgQueueLoop()
        Dim buffer As String = ""
        Dim mqopt As New MsgQOptions
        mqopt.dwFlags = &H2
        mqopt.dwMaxMessages = 10
        mqopt.cbMaxMessage = 16
        mqopt.bReadAccess = True
        mqopt.dwSize = System.Runtime.InteropServices.Marshal.SizeOf(mqopt)

        ' Create the messagequeue
        Me.mMsgQueueHandle = CreateMsgQueue(Nothing, mqopt)

        ' Create the power notification handle
        Me.mPowerNotificationHandle = RequestPowerNotifications(Me.mMsgQueueHandle, POWER_NOTIFY_ALL)

        Try
            Dim buf(49) As Byte ' 50 element array of bytes
            Dim numberRead As UInteger = 0
            Dim flags As UInteger ' = 0

            ' Loop until this is false or the thread is aborted
            Me.loopUntil = True

            While Me.loopUntil
                ' wait object(Msg)
                Dim nRet As UInteger = WaitForSingleObject(Me.mMsgQueueHandle, -1)

                If nRet = 0 Then

                    ' Read the latest item(s) off the messagequeue
                    ReadMsgQueue(Me.mMsgQueueHandle, buf, buf.Length, numberRead, 0, flags)
                    Thread.Sleep(50)

                    If buf(0) = PBT_RESUME Then
                        dllACG.RDR_SendCommandGetDataTimeout("c", "", buffer, 10)
                        dllACG.RDR_AbortContinuousReadExt()
                        dllACG.RDR_SendCommandGetData("poff", "", buffer)
                    End If
                End If
            End While
        Catch ex As Threading.ThreadAbortException
        End Try
    End Sub


    Private Sub Form1_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown

        Dim CurrentKey As UInteger = e.KeyCode

        If (CurrentKey = System.Windows.Forms.Keys.F13) Then
            'write
            Write()
        End If
        If (CurrentKey = System.Windows.Forms.Keys.F14) Then
            'read
            Read()
        End If
    End Sub

#End Region

#Region " Open and Close "
    Public Function CTL_CODE( _
        ByVal DeviceType As Integer, _
        ByVal Func As Integer, _
        ByVal Method As Integer, _
        ByVal Access As Integer) As Integer

        Return (DeviceType << 16) Or (Access << 14) Or (Func << 2) Or Method

    End Function

    Private Sub Btn_Open_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Open.Click
        Dim csel As UInteger
        Dim cout As UInteger
        Dim bytesReturned As UInteger = 0

        Dim IOCTL_HAL_CPLD_CTRL_WRITE As UInteger

        IOCTL_HAL_CPLD_CTRL_WRITE = CTL_CODE(FILE_DEVICE_HAL, 2078, METHOD_BUFFERED, FILE_ANY_ACCESS)

        ' Device Init
        csel = CPLD_ID_RFID_ON
        cout = 1

        KernelIoControl(IOCTL_HAL_CPLD_CTRL_WRITE, csel, 0, cout, 0, bytesReturned)
        Thread.Sleep(100)

        csel = CPLD_ID_RFID_RST
        KernelIoControl(IOCTL_HAL_CPLD_CTRL_WRITE, csel, 0, cout, 0, bytesReturned)
        Thread.Sleep(100)

        Dim buffer As String = ""
        Dim settings As ACG_CFReader.presetSettings


        settings.baudRate = 9600
        settings.protocol = 0

        Dim openFlag As Integer = dllACG.RDR_OpenComm("MOC1", 6, settings)
        If openFlag = 0 Then
            MessageBox.Show("OpenComm Failed")
        Else
            openFlag = dllACG.RDR_OpenReader(1, 0)
            If openFlag = 0 Then
                MessageBox.Show("OpenReader Failed")
            Else
                ' open btn disable
                Btn_Open.Enabled = False

                dllACG.RDR_AbortContinuousReadExt()

                ' reset
                dllACG.RDR_SendCommandGetData("x", "", buffer)
                Thread.Sleep(100)

                ' select card
                dllACG.RDR_SendCommandGetData("s", "", buffer)
                Thread.Sleep(100)

                'use all tag
                dllACG.RDR_SendCommandGetData("o", "t", buffer)
                Thread.Sleep(100)

                ' poff
                dllACG.RDR_SendCommandGetData("poff", "", buffer)

                lst_Msg.Items.Add("Reader Open")

                Btn_Read.Enabled = True
                Btn_Write.Enabled = True
                Btn_Version.Enabled = True

                ' each model
                Dim rk As RegistryKey = Nothing
                If (m_nKeyPadType = KEY_SKY_ORIGINAL) Then
                    rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\KeyPad\\SideKey", True)
                ElseIf (m_nKeyPadType = KEY_SKY_SUMMIT_NUMERIC) Then
                    rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\keypad\\Numeric", True)
                ElseIf (m_nKeyPadType = KEY_SKY_SUMMIT_QWERTY) Then
                    rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\keypad\\qwerty", True)
                End If

                ' Default Keys Setting
                rk.SetValue("RightUpKey", 2)
                rk.SetValue("RightDownKey", 3)


            End If
        End If


    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Closing_Form1()
    End Sub


    Private Sub Closing_Form1()
        Dim csel As UInteger
        Dim cout As UInteger

        Dim IOCTL_HAL_CPLD_CTRL_WRITE As UInteger = CTL_CODE(FILE_DEVICE_HAL, 2078, METHOD_BUFFERED, FILE_ANY_ACCESS)

        Dim bytesReturned As UInteger = 0

        If m_bRead = True Then
            m_bRead = False
            Thread.Sleep(1000)
        End If


        csel = CPLD_ID_RFID_ON
        cout = 0

        KernelIoControl(IOCTL_HAL_CPLD_CTRL_WRITE, csel, 0, cout, 0, bytesReturned)
        Thread.Sleep(100)

        csel = CPLD_ID_RFID_RST
        KernelIoControl(IOCTL_HAL_CPLD_CTRL_WRITE, csel, 0, cout, 0, bytesReturned)
        Thread.Sleep(100)

        ' Recovery reg
        ' each model
        Dim rk As RegistryKey = Nothing
        If (m_nKeyPadType = KEY_SKY_ORIGINAL) Then
            rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\KeyPad\\SideKey", True)
        ElseIf (m_nKeyPadType = KEY_SKY_SUMMIT_NUMERIC) Then
            rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\keypad\\Numeric", True)
        ElseIf (m_nKeyPadType = KEY_SKY_SUMMIT_QWERTY) Then
            rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\keypad\\qwerty", True)
        End If

        rk.SetValue("LeftUpKey", m_nLeftUpKey)
        rk.SetValue("LeftDownKey", m_nLeftDownKey)
        rk.SetValue("RightUpKey", m_nRightUpKey)
        rk.SetValue("RightDownKey", m_nRightDownKey)
        rk.SetValue("Soft1Key", m_nSoft1Key)
        rk.SetValue("Soft2Key", m_nSoft2Key)

        ' power Management
        If Me.MessageLoopThread IsNot Nothing Then
            ' Set the loopuntil variable to false so that the while loop no longer executes
            Me.loopUntil = False

            ' Abort the message loop monitoring thread
            Me.MessageLoopThread.Abort()

            ' Wait for the thread to abort for 500ms
            Me.MessageLoopThread.Join(500)
        End If

        ' Inform WM that we no longer need power notifications
        If Me.mPowerNotificationHandle <> IntPtr.Zero Then
            StopPowerNotifications(Me.mPowerNotificationHandle)
        End If

        ' Destroy the message queue
        If Me.mMsgQueueHandle <> IntPtr.Zero Then
            CloseMsgQueue(Me.mMsgQueueHandle)
        End If

        ' Power Management end

        Close()

        Application.Exit()
    End Sub

#End Region

#Region " Read Data "
    Private Sub Btn_Read_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Read.Click
        Read()
    End Sub

    Private Sub Read()

        If Btn_Read.Enabled = False Then
            Return
        End If

        Dim buffer As String = ""


        Btn_Read.Enabled = False

        ' antenna on
        dllACG.RDR_SendCommandGetData("pon", "", buffer)
        dllACG.RDR_EmptyCommRcvBuffer()
        buffer = ""

        ' mode 0: Async/ mode1: sync/ mode2: continuous read
        If m_nSyncMode = 1 Then

            dllACG.RDR_SendCommandGetDataTimeout("c", "", buffer, 24 * 60 * 60 * 1000)
            dllACG.RDR_AbortContinuousReadExt()
        ElseIf m_nSyncMode = 2 Then
            Dim thRead As New Thread(AddressOf ContinuousRead)
            m_bRead = True

            szBlock = txt_Block.Text
            thRead.Start()
            Btn_Stop.Enabled = True
            dllACG.RDR_SendCommandGetData("poff", "", buffer)
            Return

        End If

        buffer = ""
        ' select card
        dllACG.RDR_SendCommandGetDataTimeout("s", "", buffer, 2000)

        If buffer = "N" Then
            lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1
            lst_Msg.Items.Add("No Tag")
            lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1
            txt_Serial.Text = ""
            Btn_Read.Enabled = True
            dllACG.RDR_SendCommandGetData("poff", "", buffer)
            Return
        End If

        txt_Serial.Text = buffer
        Thread.Sleep(100)

        dllACG.RDR_EmptyCommRcvBuffer()
        buffer = ""

        If szTagType <> "use 15693" Then
            Dim i As Integer = 0
            ' Login 
            Do While i <= 5 And buffer <> "L"
                dllACG.RDR_SendCommandGetData("l", "01AAFFFFFFFFFFFF", buffer)
                Thread.Sleep(100)
                i = i + 1
            Loop

            If szTagType <> "use all" Then

                If buffer <> "L" Then
                    Btn_Read.Enabled = True
                    dllACG.RDR_SendCommandGetData("poff", "", buffer)
                    Return
                End If

            End If

        End If

        dllACG.RDR_EmptyCommRcvBuffer()
        buffer = ""

        ' Read Block
        dllACG.RDR_SendCommandGetData("rb", txt_Block.Text, buffer)
        lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1
        lst_Msg.Items.Add(buffer)
        lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1
        Btn_Read.Enabled = True

        dllACG.RDR_SendCommandGetData("poff", "", buffer)


    End Sub

    Private Sub ContinuousRead()
        Dim buffer As String = ""

        dllACG.RDR_EmptyCommRcvBuffer()

        Do While m_bRead = True
            ' power on
            dllACG.RDR_SendCommandGetData("pon", "", buffer)
            Thread.Sleep(100)

            ' continuous read
            dllACG.RDR_SendCommandGetDataTimeout("c", "", buffer, 2000)
            dllACG.RDR_AbortContinuousReadExt()

            If m_bRead = False Then
                Exit Do
            End If

            dllACG.RDR_EmptyCommRcvBuffer()
            buffer = ""

            ' select card
            dllACG.RDR_SendCommandGetDataTimeout("s", "", buffer, 2000)
            If buffer = "N" Then
                Continue Do
            End If

            ReadSerial(buffer)
            Thread.Sleep(100)

            dllACG.RDR_EmptyCommRcvBuffer()
            buffer = ""

            If szTagType <> "use 15693" Then
                Dim i As Integer = 0

                Do While i <= 5 And buffer <> "L"
                    'login
                    dllACG.RDR_SendCommandGetData("l", "01AAFFFFFFFFFFFF", buffer)
                    Thread.Sleep(100)
                    i = i + 1

                Loop

                If szTagType <> "use all" Then

                    If buffer <> "L" Then
                        Continue Do
                    End If

                End If

            End If

            dllACG.RDR_EmptyCommRcvBuffer()
            buffer = ""

            ' read block
            dllACG.RDR_SendCommandGetData("rb", szBlock, buffer)
            ReadData(buffer)

            ' power on
            dllACG.RDR_SendCommandGetData("poff", "", buffer)

        Loop

    End Sub

    ' Declare delegate
    Private Delegate Sub myDelegate(ByVal szString As String)

    Private Sub ReadData(ByVal szData As String)

        If txt_Serial.InvokeRequired = True Then
            Dim d As myDelegate = New myDelegate(AddressOf ReadData)
            Invoke(d, New Object() {szData})
        Else
            lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1
            lst_Msg.Items.Add(szData)
            lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1
        End If
    End Sub

    Private Sub ReadSerial(ByVal szSerial As String)

        If txt_Serial.InvokeRequired = True Then
            Dim d As myDelegate = New myDelegate(AddressOf ReadSerial)
            Invoke(d, New Object() {szSerial})
        Else
            txt_Serial.Text = szSerial
        End If

    End Sub

    Private Sub Btn_Stop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Stop.Click
        Btn_Read.Enabled = True
        Btn_Stop.Enabled = False
        m_bRead = False
    End Sub

#End Region

#Region " Write Data "

    Private Sub Btn_Write_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Write.Click

        Write()
    End Sub
    Private Sub Write()
        If Btn_Write.Enabled = False Then
            Return
        End If


        Dim buffer As String = ""

        dllACG.RDR_EmptyCommRcvBuffer()

        dllACG.RDR_SendCommandGetData("pon", "", buffer)
        buffer = ""

        dllACG.RDR_SendCommandGetDataTimeout("c", "", buffer, 1000)
        dllACG.RDR_AbortContinuousReadExt()

        dllACG.RDR_SendCommandGetDataTimeout("s", "", buffer, 2000)
        If buffer = "N" Then
            lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1
            lst_Msg.Items.Add("No Tag")
            lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1
            txt_Serial.Text = ""
            dllACG.RDR_SendCommandGetData("poff", "", buffer)
            Return
        End If

        txt_Serial.Text = buffer

        dllACG.RDR_EmptyCommRcvBuffer()
        buffer = ""

        If szTagType <> "use 15693" Then
            Dim i As Integer = 0
            Do While i <= 5 And buffer <> "L"
                dllACG.RDR_SendCommandGetData("l", "01AAFFFFFFFFFFFF", buffer)
                Thread.Sleep(100)
                i = i + 1
            Loop

            If szTagType <> "use all" Then
                If buffer <> "L" Then
                    dllACG.RDR_SendCommandGetData("poff", "", buffer)
                    Return
                End If
            End If

        End If

        buffer = ""

        dllACG.RDR_SendCommandGetData("wb", txt_Block.Text & txt_Data.Text, buffer)
        lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1
        lst_Msg.Items.Add(buffer)
        lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1

        dllACG.RDR_SendCommandGetData("poff", "", buffer)

    End Sub
#End Region

#Region " Option Tab "
    Private Sub Btn_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Cancel.Click
        m_tbMain.SelectedIndex = 0
    End Sub

    Private Sub Btn_Reset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Reset.Click

        Dim buffer As String = ""

        'reset
        dllACG.RDR_SendCommandGetData("x", "", buffer)
    End Sub

    Private Sub Btn_Apply_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Apply.Click

        ' Sync mode setting
        If Opt_Sync.Checked = True Then
            m_nSyncMode = 0
        End If
        If Opt_ASync.Checked = True Then
            m_nSyncMode = 1
        End If
        If Opt_Continue.Checked = True Then
            m_nSyncMode = 2
        End If

        ' Tag Type Setting
        szTagType = Cmb_TagType.Text
        Dim buffer As String = ""
        dllACG.RDR_SendCommandGetData(Cmb_TagType.Text, "", buffer)
        Thread.Sleep(100)

        buffer = ""

        ' Antenna Setting
        If (Opt_AntOn.Checked) Then
            dllACG.RDR_SendCommandGetData("pon", "", buffer)
        Else
            dllACG.RDR_SendCommandGetData("poff", "", buffer)
        End If

        ' button setting
        Dim nLeftUp = m_nLeftUpKey, nLeftDown = m_nLeftDownKey, nRightUp = m_nRightUpKey, _
            nRightDown = m_nRightDownKey, nSoft1 = m_nSoft1Key, nSoft2 = m_nSoft2Key
        ' write btn setting
        Select Case Cmb_WriteBtn.SelectedIndex
            Case 0
                nLeftUp = 2
            Case 1
                nLeftDown = 2
            Case 2
                nRightUp = 2
            Case 3
                nRightDown = 2
            Case 4
                nSoft1 = 2
            Case 5
                nSoft2 = 2
        End Select

        ' read btn setting
        Select Case Cmb_ReadBtn.SelectedIndex
            Case 0
                nLeftUp = 3
            Case 1
                nLeftDown = 3
            Case 2
                nRightUp = 3
            Case 3
                nRightDown = 3
            Case 4
                nSoft1 = 3
            Case 5
                nSoft2 = 3
        End Select

        ' button reg change
        ' each model
        Dim rk As RegistryKey = Nothing
        If (m_nKeyPadType = KEY_SKY_ORIGINAL) Then
            rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\KeyPad\\SideKey", True)
        ElseIf (m_nKeyPadType = KEY_SKY_SUMMIT_NUMERIC) Then
            rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\keypad\\Numeric", True)
        ElseIf (m_nKeyPadType = KEY_SKY_SUMMIT_QWERTY) Then
            rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\keypad\\qwerty", True)
        End If

        rk.SetValue("LeftUpKey", nLeftUp)
        rk.SetValue("LeftDownKey", nLeftDown)
        rk.SetValue("RightUpKey", nRightUp)
        rk.SetValue("RightDownKey", nRightDown)
        rk.SetValue("Soft1Key", nSoft1)
        rk.SetValue("Soft2Key", nSoft2)

        m_tbMain.SelectedIndex = 0

    End Sub


#End Region

#Region " ETC Button Click "
    Private Sub Btn_Version_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Version.Click

        Dim buffer As String = ""

        lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1

        ' dll version
        dllACG.RDR_GetDLLVersionStr(buffer)
        lst_Msg.Items.Add("CFReaderDLLWrapper : " & buffer)

        ' Station ID
        lst_Msg.Items.Add("Station ID: " & dllACG.RDR_GetStationID())

        ' Reader type
        dllACG.RDR_GetReaderType(buffer)
        lst_Msg.Items.Add("Type: " & buffer)

        ' Device id
        dllACG.RDR_GetDeviceID(buffer)
        lst_Msg.Items.Add("DeviceID: " & buffer)

        dllACG.RDR_AbortContinuousRead()

        ' reader module version
        dllACG.RDR_SendCommandGetData("v", "", buffer)
        lst_Msg.Items.Add("Version: " & buffer)

        lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1
    End Sub
    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        lst_Msg.Items.Clear()
    End Sub
#End Region

End Class
