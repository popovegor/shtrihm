﻿//////////////////////////////////////////////////////////////////////////
// 2011. 01. 04 JJ v.1.0.1 버전 관리 시작
//////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;
using Microsoft.Win32;
using CFReaderDLLWrapper;

namespace RF_ID_Demo_Net
{

    public struct presetSettings
    {
        public long baudRate;
        public char protocol;
    };

    public partial class Form1 : Form
    {
        #region Declare class member

        
        // declare member
        [DllImport("Coredll.dll")]
        public static extern int KernelIoControl
                               (uint dwIoControlCode,
                               ref uint lpInBuf,
                               int nInBufSize,
                               out uint lpOutBuf,
                               int nOutBufSize,
                               ref uint lpBytesReturned);

        private const uint FILE_DEVICE_HAL = 0x00000101;
        private const uint CPLD_ID_RFID_ON = 0x24;
        private const uint CPLD_ID_RFID_RST = 0x25;
        private const uint METHOD_BUFFERED = 0;
        private const uint FILE_ANY_ACCESS = 0;

        // OEM Information
        private const uint SPI_GETOEMINFO = 258;

        [DllImport("Coredll.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool SystemParametersInfo(uint uiAction, uint uiParam,StringBuilder pvParam, uint fWinIni);
        //
        
        // Keypad const type 
        private const int   KEY_SKY_ORIGINAL         = 0;
        private const int   KEY_SKY_SUMMIT_NUMERIC   = 1;
        private const int   KEY_SKY_SUMMIT_QWERTY    = 2;
        //

        public int m_nKeyPadType = KEY_SKY_SUMMIT_QWERTY;


        private uint nContinuous = 0;
        private string szTagType = "use all";

        public Thread t1 = null;
        public bool bRead = false;
        public string szBlock = "";

        public int m_nLeftUpKey = 0;
        public int m_nLeftDownKey = 0;
        public int m_nRightUpKey = 0;
        public int m_nRightDownKey = 0;
        public int m_nSoft1Key = 0;
        public int m_nSoft2Key = 0;

       

        public ACG_CFReader dllACG;

        // declare member for Power management
        public const int PBT_RESUME = 0x00000002;
        public const long POWER_NOTIFY_ALL = 0xffffffff;

        // functions
        [DllImport("Coredll.dll")]
        public static extern bool PowerPolicyNotify(int dwMessage, int dwData);
        [DllImport("Coredll.dll")]
        public static extern IntPtr RequestPowerNotifications(IntPtr hMsgQueue, long flags);
        [DllImport("Coredll.dll")]
        public static extern int StopPowerNotifications(IntPtr hHandle);
        [DllImport("Coredll.dll")]
        public static extern IntPtr CreateMsgQueue(string name, ref msgQOptions options);
        [DllImport("Coredll.dll")]
        public static extern uint WaitForSingleObject(IntPtr hHandle, int wait);
        [DllImport("Coredll.dll")]
        public static extern bool CloseMsgQueue(IntPtr msgqueue);
        [DllImport("Coredll.dll")]
        public static extern bool ReadMsgQueue(IntPtr msgqueue, Byte[] lpBuffer, int bufsize, ref uint numRead, int timeout, ref uint flags);

        // msgQ option
        public struct msgQOptions
        {
            public int dwSize;
            public uint dwFlags;
            public uint dwMaxMessages;
            public uint cbMaxMessage;
            public bool bReadAccess;
        };

        // Tag Type
        public const int ISO_14443_TYPE_A = 0;
        public const int ISO_14443_TYPE_B = 1;
        public const int ICODE_UID = 2;
        public const int ICODE_EPC = 3;
        public const int ICODE = 4;
        public const int SR176 = 5;
        public const int ACTIVATE_ALL_TAGS = 6;
        public const int ISO_15693 = 7;


        // variable for power
        IntPtr mMsgQueueHandle = IntPtr.Zero;
        IntPtr mPowerNotificationHandle = IntPtr.Zero;
        Thread MessageLoopThread = null;
        bool loopUntil = false;


#endregion

        #region Initialize Form1
        public Form1()
        {
            InitializeComponent();
            Btn_Read.Enabled = false;
            Btn_Stop.Enabled = false;
            Btn_Write.Enabled = false;
            Btn_Version.Enabled = false;
            Cmb_ReadBtn.Text = "RightDownKey";
            Cmb_WriteBtn.Text = "RightUpKey";
            dllACG = new ACG_CFReader();
                        
            // Add Tag Type Combo Box
            Cmb_TagType.Items.Add("ISO 14443 Type A");
            Cmb_TagType.Items.Add("ISO 14443 Type B");
            Cmb_TagType.Items.Add("ICODE UID");
            Cmb_TagType.Items.Add("ICODE EPC");
            Cmb_TagType.Items.Add("ICODE");
            Cmb_TagType.Items.Add("SR176");
            Cmb_TagType.Items.Add("activate all tags");
            Cmb_TagType.Items.Add("ISO 15693");

            Cmb_TagType.SelectedIndex = ACTIVATE_ALL_TAGS;


            // key setting
            RegistryKey rk = null ;
            m_nKeyPadType = GetKeypadType();

            if (m_nKeyPadType == KEY_SKY_ORIGINAL)
                rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\KeyPad\\SideKey", true);
            else if (m_nKeyPadType == KEY_SKY_SUMMIT_NUMERIC)
                rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\keypad\\Numeric", true);
            else if (m_nKeyPadType == KEY_SKY_SUMMIT_QWERTY)
                rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\keypad\\qwerty", true);
                        
            if (rk == null)
            {
                MessageBox.Show("Does not setting keypad type");
            }
            else
            {
                m_nLeftUpKey = Convert.ToInt32(rk.GetValue("LeftUpKey", -1));
                m_nLeftDownKey = Convert.ToInt32(rk.GetValue("LeftDownKey", -1));
                m_nRightUpKey = Convert.ToInt32(rk.GetValue("RightUpKey", -1));
                m_nRightDownKey = Convert.ToInt32(rk.GetValue("RightDownKey", -1));
                m_nSoft1Key = Convert.ToInt32(rk.GetValue("Soft1Key", -1));
                m_nSoft2Key = Convert.ToInt32(rk.GetValue("Soft2Key", -1));
            }

            this.MessageLoopThread = new Thread(this.ThreadMsgQueueLoop);
            this.MessageLoopThread.Start();
            
        }

        public int GetKeypadType()
        {
            StringBuilder strModelType = new StringBuilder(260);
            String strModel;

            const int KEY_NUMERIC = 0;
            const int KEY_QWERTY = 1;

            SystemParametersInfo(SPI_GETOEMINFO, 260, strModelType, 0);

            strModel = strModelType.ToString();

            if((strModel == "MC7101") || (strModel == "MC7X01"))
            {
                // Sky Summit key type 
                int nKeyType = 0;

                RegistryKey rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\keypad", true);
                if (rk == null)
                {
                    MessageBox.Show("Does not setting keypad type");
                }
                else
                {
                    nKeyType = Convert.ToInt32(rk.GetValue("KeypadType", -1));
                }

                if(nKeyType == KEY_NUMERIC)
                {
                    return KEY_SKY_SUMMIT_NUMERIC;
                }
                else if(nKeyType == KEY_QWERTY)
                {
                    return KEY_SKY_SUMMIT_QWERTY;
                }
            }


            return KEY_SKY_ORIGINAL;;
        }

        private void ThreadMsgQueueLoop()
        {
            string buffer = "";
            msgQOptions mqopt = new msgQOptions();

            mqopt.dwFlags = 0x00000002;
            mqopt.dwMaxMessages = 10;
            mqopt.cbMaxMessage = 16;
            mqopt.bReadAccess = true;
            mqopt.dwSize = System.Runtime.InteropServices.Marshal.SizeOf(mqopt);

            this.mMsgQueueHandle = CreateMsgQueue(null, ref mqopt);

            this.mPowerNotificationHandle = RequestPowerNotifications(this.mMsgQueueHandle, POWER_NOTIFY_ALL);

            Byte[] Buf = new Byte[50];
            uint numberRead = 0;
            uint flags = 0;

            this.loopUntil = true;

            while (this.loopUntil)
            {
                uint nRet = WaitForSingleObject(this.mMsgQueueHandle, -1);

                if (nRet == 0)
                {
                    ReadMsgQueue(this.mMsgQueueHandle, Buf, Buf.Length, ref numberRead, 0, ref flags);
                    Thread.Sleep(50);

                    if (Buf[0] == PBT_RESUME)
                    {
                        dllACG.RDR_EmptyCommRcvBuffer();
                        dllACG.RDR_SendCommandGetDataTimeout("c", "", ref buffer, 10);
                        dllACG.RDR_AbortContinuousReadExt();
                        dllACG.RDR_SendCommandGetData("poff", "", ref  buffer);
                        dllACG.RDR_EmptyCommRcvBuffer();

                        MessageBox.Show("Wake Up");
                    }
                }
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {

            if ((e.KeyCode == System.Windows.Forms.Keys.F13))
            {
                Write();
            }
            if ((e.KeyCode == System.Windows.Forms.Keys.F14))
            {
                Read();
            }
        }


        #endregion

        #region Open And Close
        public static uint CTL_CODE(uint DeviceType, uint Function, uint Method, uint Access)
        {

            return ((DeviceType << 16) | (Access << 14) | (Function << 2) | Method);

        }

        private void Btn_Open_Click(object sender, EventArgs e)
        {
            uint csel;
            uint cout;

            csel = CPLD_ID_RFID_ON;
            cout = 1;
            uint bytesReturned = 0;

            uint IOCTL_HAL_CPLD_CTRL_WRITE = CTL_CODE(FILE_DEVICE_HAL, 2078, METHOD_BUFFERED, FILE_ANY_ACCESS);

            KernelIoControl(IOCTL_HAL_CPLD_CTRL_WRITE, ref csel, 0, out cout, 0, ref bytesReturned);
            Thread.Sleep(100);

            csel = CPLD_ID_RFID_RST;

            KernelIoControl(IOCTL_HAL_CPLD_CTRL_WRITE, ref csel, 0, out cout, 0, ref bytesReturned);
            Thread.Sleep(100);

            string buffer = "";
            ACG_CFReader.presetSettings settings;
            settings.baudRate = 9600;
            settings.protocol = 0;
            int i = dllACG.RDR_OpenComm("MOC1", 6, settings);
            if (i == 0)
                MessageBox.Show("OpenComm failed");
            else
            {
                i = dllACG.RDR_OpenReader(1, 0);
                if (i == 0)
                    MessageBox.Show("OpenReader failed");
                else
                {
                    Btn_Open.Enabled = false;
                    dllACG.RDR_AbortContinuousReadExt();
                    // dllACG.RDR_SendCommandGetData("wp", "0B41", ref buffer);
                    // Thread.Sleep(100);
                    dllACG.RDR_SendCommandGetData("x", "", ref buffer);
                    Thread.Sleep(100);
                    dllACG.RDR_SendCommandGetData("s", "", ref buffer);
                    Thread.Sleep(100);
                    dllACG.RDR_SendCommandGetData("o", "t", ref buffer); // Tag Type
                    Thread.Sleep(100);
                    dllACG.RDR_SendCommandGetData("v", "", ref buffer);
                    label_Version.Text = buffer;
                    Thread.Sleep(100);
                    dllACG.RDR_SendCommandGetData("poff", "", ref buffer);

                    lst_Msg.Items.Add("Reader Open");
                    Btn_Read.Enabled = true;
                    Btn_Write.Enabled = true;
                    Btn_Version.Enabled = true;

                    RegistryKey rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\KeyPad\\SideKey", true);

                    if(rk == null)
                    {
                        lst_Msg.Items.Add("Key setting fault");
                    }
                    else
                    {
                        rk.SetValue("RightUpKey", 2);
                        rk.SetValue("RightDownKey", 3);
                    }

                }
            }
        }

        private void Btn_Close_Click(object sender, EventArgs e)
        {
            uint csel;
            uint cout;

            if(bRead== true){
                bRead = false;
                Thread.Sleep(100);
            }
            

            csel = CPLD_ID_RFID_ON;
            cout = 0;
            uint bytesReturned = 0;

            uint IOCTL_HAL_CPLD_CTRL_WRITE = CTL_CODE(FILE_DEVICE_HAL, 2078, METHOD_BUFFERED, FILE_ANY_ACCESS);

            KernelIoControl(IOCTL_HAL_CPLD_CTRL_WRITE, ref csel, 0, out cout, 0, ref bytesReturned);
            Thread.Sleep(100);

            csel = CPLD_ID_RFID_RST;

            KernelIoControl(IOCTL_HAL_CPLD_CTRL_WRITE, ref csel, 0, out cout, 0, ref bytesReturned);
            Thread.Sleep(100);

            RegistryKey rk = null;
            m_nKeyPadType = GetKeypadType();

            if (m_nKeyPadType == KEY_SKY_ORIGINAL)
                rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\KeyPad\\SideKey", true);
            else if (m_nKeyPadType == KEY_SKY_SUMMIT_NUMERIC)
                rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\keypad\\Numeric", true);
            else if (m_nKeyPadType == KEY_SKY_SUMMIT_QWERTY)
                rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\keypad\\qwerty", true);

            if (rk != null)           
            {
                rk.SetValue("LeftUpKey", m_nLeftUpKey);
                rk.SetValue("LeftDownKey", m_nLeftDownKey);
                rk.SetValue("RightUpKey", m_nRightUpKey);
                rk.SetValue("RightDownKey", m_nRightDownKey);
                rk.SetValue("Soft1Key", m_nSoft1Key);
                rk.SetValue("Soft2Key", m_nSoft2Key);
            }
            // Power Management
            if(this.MessageLoopThread != null)
            {
                this.loopUntil = false;

                this.MessageLoopThread.Abort();

                this.MessageLoopThread.Join(500);
            }

            if(this.mPowerNotificationHandle != IntPtr.Zero)
            {
                StopPowerNotifications(this.mPowerNotificationHandle);
            }

            if(this.mMsgQueueHandle != IntPtr.Zero)
            {
                CloseMsgQueue(this.mMsgQueueHandle);
            }


            Close();

            Application.Exit();
        }

        #endregion

        #region Read
        private void Btn_Read_Click(object sender, EventArgs e)
        {
            Read();
        }

        private void Read()
        {
            if (!Btn_Read.Enabled)
                return;
            string buffer = "";

            Btn_Read.Enabled = false;

            dllACG.RDR_SendCommandGetData("pon", "", ref buffer);

            dllACG.RDR_EmptyCommRcvBuffer();
            buffer = "";

            if (nContinuous == 0)
            {
                dllACG.RDR_SendCommandGetDataTimeout("c", "", ref buffer, 2000);
                dllACG.RDR_AbortContinuousReadExt();
            }
            else if (nContinuous == 1)
            {
                dllACG.RDR_SendCommandGetDataTimeout("c", "", ref buffer, 20 * 1000);
                dllACG.RDR_AbortContinuousReadExt();
            }
            else if (nContinuous == 2)
            {
                this.t1 = new Thread(new ThreadStart(this.ContinuousRead));
                bRead = true;
                szBlock = txt_Block.Text;
                t1.Start();
                Btn_Stop.Enabled = true;
                dllACG.RDR_SendCommandGetData("poff", "", ref buffer);
                return;

            }

            dllACG.RDR_SendCommandGetDataTimeout("s", "", ref buffer, 2000);
            
            if (buffer == "N")
            {
                lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1;
                lst_Msg.Items.Add("No Tag");
                lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1;
                label_Serial.Text = "";
                Btn_Read.Enabled = true;
                dllACG.RDR_SendCommandGetData("poff", "", ref buffer);
                return;
            }
            
            label_Serial.Text = buffer;

            if (szTagType != "use 15693")
            {
                int i = 0;
                do
                {
                    dllACG.RDR_SendCommandGetData("l", "01AAFFFFFFFFFFFF", ref buffer);

                    i++;
                } while (i <= 5 && buffer != "L");

                if (szTagType != "use all")
                {
                    if (buffer != "L")
                    {
                        Btn_Read.Enabled = true;
                        dllACG.RDR_SendCommandGetData("poff", "", ref buffer);
                        return;
                    }
                }
            }

            dllACG.RDR_EmptyCommRcvBuffer();
            buffer = "";

            dllACG.RDR_SendCommandGetData("rb", txt_Block.Text, ref buffer);
            lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1;
            lst_Msg.Items.Add(buffer);
            lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1;
            Btn_Read.Enabled = true;

            dllACG.RDR_SendCommandGetData("poff", "", ref buffer);
        }


        private delegate void myDelegate(string szString);

        public void ReadSerial(string szSerial)
        {
            if (this.label_Serial.InvokeRequired)
            {
                myDelegate d = new myDelegate(ReadSerial);
                this.Invoke(d, new object[] { szSerial });
            }
            else
            {
                this.label_Serial.Text = szSerial;
            }

        }

        public void ReadData(string szData)
        {
            if (this.lst_Msg.InvokeRequired)
            {
                myDelegate d = new myDelegate(ReadData);
                this.Invoke(d, new object[] { szData });
            }
            else
            {
                this.lst_Msg.SelectedIndex = this.lst_Msg.Items.Count - 1;
                this.lst_Msg.Items.Add(szData);
                this.lst_Msg.SelectedIndex = this.lst_Msg.Items.Count - 1;
            }

        }

        private void GetBlock(string sztxtBlock)
        {
            if (this.txt_Block.InvokeRequired)
            {
                myDelegate d = new myDelegate(GetBlock);
                this.Invoke(d, new object[] { szBlock });
            }
            else
            {
                szBlock = sztxtBlock;
            }
        }

        private void ContinuousRead()
        {
            string buffer = "";

            dllACG.RDR_EmptyCommRcvBuffer();

            do
            {
                dllACG.RDR_SendCommandGetData("pon", "", ref buffer);
                Thread.Sleep(100);

                dllACG.RDR_SendCommandGetDataTimeout("c", "", ref buffer, 2000);
                dllACG.RDR_AbortContinuousReadExt();

                if (!bRead)
                    break;

                dllACG.RDR_EmptyCommRcvBuffer();
                buffer = "";

                dllACG.RDR_SendCommandGetDataTimeout("s", "", ref buffer, 2000);
                if (buffer == "N")
                {
                    continue;
                }
                this.ReadSerial(buffer);
                Thread.Sleep(100);

                dllACG.RDR_EmptyCommRcvBuffer();
                buffer = "";

                if (szTagType != "use 15693")
                {
                    int i = 0;
                    do
                    {
                        dllACG.RDR_SendCommandGetData("l", "01AAFFFFFFFFFFFF", ref buffer);
                        Thread.Sleep(100);
                        i++;
                    } while (i <= 5 && buffer != "L");

                    if (szTagType != "use all")
                    {
                        if (buffer != "L")
                            continue;
                    }
                }

                dllACG.RDR_EmptyCommRcvBuffer();
                buffer = "";

                this.GetBlock(buffer);



                dllACG.RDR_SendCommandGetData("rb", szBlock, ref buffer);
                this.ReadData(buffer);

                dllACG.RDR_SendCommandGetData("poff", "", ref buffer);

            } while (bRead);
        }

        private void Btn_Stop_Click(object sender, EventArgs e)
        {
            Btn_Read.Enabled = true;
            Btn_Stop.Enabled = false;
            bRead = false;
        }
        #endregion

        #region Write
        private void Btn_Write_Click(object sender, EventArgs e)
        {
            Write();
        }

        private void Write()
        {
            if (!Btn_Write.Enabled)
                return;
            string buffer = "";

            dllACG.RDR_EmptyCommRcvBuffer();

            dllACG.RDR_SendCommandGetData("pon", "", ref buffer);

            buffer = "";
            dllACG.RDR_SendCommandGetDataTimeout("c", "", ref buffer, 1000);
            dllACG.RDR_AbortContinuousReadExt();

            dllACG.RDR_SendCommandGetDataTimeout("s", "", ref buffer, 2000);
            if (buffer == "N")
            {
                lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1;
                lst_Msg.Items.Add("No Tag");
                lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1;
                label_Serial.Text = "";
                dllACG.RDR_SendCommandGetData("poff", "", ref buffer);
                return;
            }

            label_Serial.Text = buffer;

            dllACG.RDR_EmptyCommRcvBuffer();
            buffer = "";

            if (szTagType != "use 15693")
            {
                int i = 0;
                do
                {
                    dllACG.RDR_SendCommandGetData("l", "01AAFFFFFFFFFFFF", ref buffer);
                    Thread.Sleep(100);
                    i++;
                } while (i <= 5 && buffer != "L");

                if (szTagType != "use all")
                {
                    if (buffer != "L")
                    {
                        dllACG.RDR_SendCommandGetData("poff", "", ref buffer);
                        return;
                    }
                }
            }

            buffer = "";

            dllACG.RDR_SendCommandGetData("wb", txt_Block.Text + txt_Data.Text, ref buffer);
            lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1;
            lst_Msg.Items.Add(buffer);
            lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1;

            dllACG.RDR_SendCommandGetData("poff", "", ref buffer);
        }

        #endregion

        #region Etc Button
        private void Btn_Version_Click(object sender, EventArgs e)
        {
            string buffer = "";
            lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1;
            dllACG.RDR_GetDLLVersionStr(ref buffer);
            lst_Msg.Items.Add("CFReaderDLLWrapper : " + buffer);
            lst_Msg.Items.Add("Station ID: " + dllACG.RDR_GetStationID());
            dllACG.RDR_GetReaderType(ref buffer);
            lst_Msg.Items.Add("Type: " + buffer);
            dllACG.RDR_GetDeviceID(ref buffer);
            lst_Msg.Items.Add("DeviceID: " + buffer);
            dllACG.RDR_AbortContinuousRead();
            dllACG.RDR_SendCommandGetData("v", "", ref buffer);
            lst_Msg.Items.Add("Version: " + buffer);
            lst_Msg.SelectedIndex = lst_Msg.Items.Count - 1;

        }

        private void Btn_Clear_Click(object sender, EventArgs e)
        {
            lst_Msg.Items.Clear();

        }

        #endregion

        #region Option
        private void Btn_Cancel_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
        }

        private void Btn_Reset_Click(object sender, EventArgs e)
        {
            string buffer = "";
            dllACG.RDR_SendCommandGetData("x", "", ref buffer);

        }

        private void Btn_Apply_Click(object sender, EventArgs e)
        {
            if (Cmb_WriteBtn.SelectedIndex == Cmb_ReadBtn.SelectedIndex)
            {
                MessageBox.Show("Button set fail");
                return;
            }


            if (Opt_Sync.Checked)
                nContinuous = 0;
            if (Opt_ASync.Checked)
                nContinuous = 1;
            if (Opt_Continue.Checked)
                nContinuous = 2;

            // Set Tag Type
            string buffer = "";
            string strType = "";
            int nType = Cmb_TagType.SelectedIndex;

            switch (nType)
            {
                case ISO_14443_TYPE_A:
                    strType = "a";
                    break;
                case ISO_14443_TYPE_B:
                    strType = "b";
                    break;
                case ICODE_UID:
                    strType = "d";
                    break;
                case ICODE_EPC:
                    strType = "e";
                    break;
                case ICODE:
                    strType = "i";
                    break;
                case SR176:
                    strType = "s";
                    break;
                case ACTIVATE_ALL_TAGS:
                    strType = "t";
                    break;
                case ISO_15693:
                    strType = "v";
                    break;
            }
            dllACG.RDR_SendCommandGetData("o", strType, ref buffer);
            Thread.Sleep(100);
            //

            buffer = "";
            if (Opt_AntOn.Checked)
                dllACG.RDR_SendCommandGetData("pon", "", ref buffer);
            else
                dllACG.RDR_SendCommandGetData("poff", "", ref buffer);

            int nLeftUp = m_nLeftUpKey, nLeftDown = m_nLeftDownKey, nRightUp = m_nRightUpKey, nRightDown = m_nRightDownKey,
                nSoft1 = m_nSoft1Key, nSoft2 = m_nSoft2Key;

            switch (Cmb_WriteBtn.SelectedIndex)
            {
                case 0:
                    nLeftUp = 2;
                    break;
                case 1:
                    nLeftDown = 2;
                    break;
                case 2:
                    nRightUp = 2;
                    break;
                case 3:
                    nRightDown = 2;
                    break;
                case 4:
                    nSoft1 = 2;
                    break;
                case 5:
                    nSoft2 = 2;
                    break;
            }

            switch (Cmb_ReadBtn.SelectedIndex)
            {
                case 0:
                    nLeftUp = 3;
                    break;
                case 1:
                    nLeftDown = 3;
                    break;
                case 2:
                    nRightUp = 3;
                    break;
                case 3:
                    nRightDown = 3;
                    break;
                case 4:
                    nSoft1 = 3;
                    break;
                case 5:
                    nSoft2 = 3;
                    break;
            }

            // key setting
            RegistryKey rk = null;
            m_nKeyPadType = GetKeypadType();

            if (m_nKeyPadType == KEY_SKY_ORIGINAL)
                rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\KeyPad\\SideKey", true);
            else if (m_nKeyPadType == KEY_SKY_SUMMIT_NUMERIC)
                rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\keypad\\Numeric", true);
            else if (m_nKeyPadType == KEY_SKY_SUMMIT_QWERTY)
                rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\keypad\\qwerty", true);

            if (rk == null)
            {
                MessageBox.Show("Does not setting keypad type");
            }
            else
            {
                rk.SetValue("LeftUpKey", nLeftUp);
                rk.SetValue("LeftDownKey", nLeftDown);
                rk.SetValue("RightUpKey", nRightUp);
                rk.SetValue("RightDownKey", nRightDown);
                rk.SetValue("Soft1Key", nSoft1);
                rk.SetValue("Soft2Key", nSoft2);

            }

            tabControl1.SelectedIndex = 0;
        }
        #endregion

    }
}