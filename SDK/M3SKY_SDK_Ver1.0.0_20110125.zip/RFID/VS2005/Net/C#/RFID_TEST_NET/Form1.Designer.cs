﻿namespace RF_ID_Demo_Net
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Btn_Version = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label_Version = new System.Windows.Forms.Label();
            this.label_Serial = new System.Windows.Forms.Label();
            this.lst_Msg = new System.Windows.Forms.ListBox();
            this.txt_Data = new System.Windows.Forms.TextBox();
            this.txt_Block = new System.Windows.Forms.TextBox();
            this.Btn_Write = new System.Windows.Forms.Button();
            this.Btn_Stop = new System.Windows.Forms.Button();
            this.Btn_Read = new System.Windows.Forms.Button();
            this.Btn_Clear = new System.Windows.Forms.Button();
            this.Btn_Open = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.Btn_Apply = new System.Windows.Forms.Button();
            this.Btn_Reset = new System.Windows.Forms.Button();
            this.Btn_Cancel = new System.Windows.Forms.Button();
            this.Cmb_WriteBtn = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Cmb_ReadBtn = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Cmb_TagType = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.Opt_AntOff = new System.Windows.Forms.RadioButton();
            this.Opt_AntOn = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Opt_Continue = new System.Windows.Forms.RadioButton();
            this.Opt_ASync = new System.Windows.Forms.RadioButton();
            this.Opt_Sync = new System.Windows.Forms.RadioButton();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(240, 268);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.Btn_Version);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label_Version);
            this.tabPage1.Controls.Add(this.label_Serial);
            this.tabPage1.Controls.Add(this.lst_Msg);
            this.tabPage1.Controls.Add(this.txt_Data);
            this.tabPage1.Controls.Add(this.txt_Block);
            this.tabPage1.Controls.Add(this.Btn_Write);
            this.tabPage1.Controls.Add(this.Btn_Stop);
            this.tabPage1.Controls.Add(this.Btn_Read);
            this.tabPage1.Controls.Add(this.Btn_Clear);
            this.tabPage1.Controls.Add(this.Btn_Open);
            this.tabPage1.Location = new System.Drawing.Point(0, 0);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(240, 245);
            this.tabPage1.Text = "ReadWrite";
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(75, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 18);
            this.label8.Text = "Firmm";
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(75, 49);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 18);
            this.label7.Text = "Serial";
            // 
            // Btn_Version
            // 
            this.Btn_Version.Location = new System.Drawing.Point(89, 179);
            this.Btn_Version.Name = "Btn_Version";
            this.Btn_Version.Size = new System.Drawing.Size(63, 20);
            this.Btn_Version.TabIndex = 21;
            this.Btn_Version.Text = "VERSION";
            this.Btn_Version.Click += new System.EventHandler(this.Btn_Version_Click);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(18, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(203, 18);
            this.label6.Text = "RFID Read / Write demo";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(18, 28);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 20);
            this.label5.Text = "Block";
            // 
            // label_Version
            // 
            this.label_Version.Location = new System.Drawing.Point(122, 28);
            this.label_Version.Name = "label_Version";
            this.label_Version.Size = new System.Drawing.Size(99, 18);
            // 
            // label_Serial
            // 
            this.label_Serial.Location = new System.Drawing.Point(122, 48);
            this.label_Serial.Name = "label_Serial";
            this.label_Serial.Size = new System.Drawing.Size(100, 18);
            // 
            // lst_Msg
            // 
            this.lst_Msg.Location = new System.Drawing.Point(20, 97);
            this.lst_Msg.Name = "lst_Msg";
            this.lst_Msg.Size = new System.Drawing.Size(201, 72);
            this.lst_Msg.TabIndex = 15;
            // 
            // txt_Data
            // 
            this.txt_Data.Location = new System.Drawing.Point(20, 73);
            this.txt_Data.Name = "txt_Data";
            this.txt_Data.Size = new System.Drawing.Size(201, 21);
            this.txt_Data.TabIndex = 14;
            // 
            // txt_Block
            // 
            this.txt_Block.Location = new System.Drawing.Point(20, 48);
            this.txt_Block.Name = "txt_Block";
            this.txt_Block.Size = new System.Drawing.Size(49, 21);
            this.txt_Block.TabIndex = 12;
            this.txt_Block.Text = "04";
            // 
            // Btn_Write
            // 
            this.Btn_Write.Location = new System.Drawing.Point(158, 205);
            this.Btn_Write.Name = "Btn_Write";
            this.Btn_Write.Size = new System.Drawing.Size(63, 20);
            this.Btn_Write.TabIndex = 11;
            this.Btn_Write.Text = "WRITE";
            this.Btn_Write.Click += new System.EventHandler(this.Btn_Write_Click);
            // 
            // Btn_Stop
            // 
            this.Btn_Stop.Location = new System.Drawing.Point(89, 205);
            this.Btn_Stop.Name = "Btn_Stop";
            this.Btn_Stop.Size = new System.Drawing.Size(63, 20);
            this.Btn_Stop.TabIndex = 10;
            this.Btn_Stop.Text = "STOP";
            this.Btn_Stop.Click += new System.EventHandler(this.Btn_Stop_Click);
            // 
            // Btn_Read
            // 
            this.Btn_Read.Location = new System.Drawing.Point(20, 205);
            this.Btn_Read.Name = "Btn_Read";
            this.Btn_Read.Size = new System.Drawing.Size(63, 20);
            this.Btn_Read.TabIndex = 9;
            this.Btn_Read.Text = "READ";
            this.Btn_Read.Click += new System.EventHandler(this.Btn_Read_Click);
            // 
            // Btn_Clear
            // 
            this.Btn_Clear.Location = new System.Drawing.Point(158, 179);
            this.Btn_Clear.Name = "Btn_Clear";
            this.Btn_Clear.Size = new System.Drawing.Size(63, 20);
            this.Btn_Clear.TabIndex = 8;
            this.Btn_Clear.Text = "CLEAR";
            this.Btn_Clear.Click += new System.EventHandler(this.Btn_Clear_Click);
            // 
            // Btn_Open
            // 
            this.Btn_Open.Location = new System.Drawing.Point(20, 179);
            this.Btn_Open.Name = "Btn_Open";
            this.Btn_Open.Size = new System.Drawing.Size(63, 20);
            this.Btn_Open.TabIndex = 6;
            this.Btn_Open.Text = "Open";
            this.Btn_Open.Click += new System.EventHandler(this.Btn_Open_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.Btn_Apply);
            this.tabPage2.Controls.Add(this.Btn_Reset);
            this.tabPage2.Controls.Add(this.Btn_Cancel);
            this.tabPage2.Controls.Add(this.Cmb_WriteBtn);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.Cmb_ReadBtn);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.Cmb_TagType);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.panel2);
            this.tabPage2.Controls.Add(this.panel1);
            this.tabPage2.Location = new System.Drawing.Point(0, 0);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(240, 245);
            this.tabPage2.Text = "Option";
            // 
            // Btn_Apply
            // 
            this.Btn_Apply.Location = new System.Drawing.Point(163, 213);
            this.Btn_Apply.Name = "Btn_Apply";
            this.Btn_Apply.Size = new System.Drawing.Size(64, 20);
            this.Btn_Apply.TabIndex = 17;
            this.Btn_Apply.Text = "Apply";
            this.Btn_Apply.Click += new System.EventHandler(this.Btn_Apply_Click);
            // 
            // Btn_Reset
            // 
            this.Btn_Reset.Location = new System.Drawing.Point(88, 213);
            this.Btn_Reset.Name = "Btn_Reset";
            this.Btn_Reset.Size = new System.Drawing.Size(64, 20);
            this.Btn_Reset.TabIndex = 16;
            this.Btn_Reset.Text = "Reset";
            this.Btn_Reset.Click += new System.EventHandler(this.Btn_Reset_Click);
            // 
            // Btn_Cancel
            // 
            this.Btn_Cancel.Location = new System.Drawing.Point(12, 213);
            this.Btn_Cancel.Name = "Btn_Cancel";
            this.Btn_Cancel.Size = new System.Drawing.Size(64, 20);
            this.Btn_Cancel.TabIndex = 15;
            this.Btn_Cancel.Text = "Cancel";
            this.Btn_Cancel.Click += new System.EventHandler(this.Btn_Cancel_Click);
            // 
            // Cmb_WriteBtn
            // 
            this.Cmb_WriteBtn.Items.Add("LeftUpKey");
            this.Cmb_WriteBtn.Items.Add("LeftDownKey");
            this.Cmb_WriteBtn.Items.Add("RightUpKey");
            this.Cmb_WriteBtn.Items.Add("RightDownKey");
            this.Cmb_WriteBtn.Items.Add("Soft1Key");
            this.Cmb_WriteBtn.Items.Add("Soft2Key");
            this.Cmb_WriteBtn.Location = new System.Drawing.Point(121, 158);
            this.Cmb_WriteBtn.Name = "Cmb_WriteBtn";
            this.Cmb_WriteBtn.Size = new System.Drawing.Size(107, 22);
            this.Cmb_WriteBtn.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(128, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 17);
            this.label4.Text = "Write Button";
            // 
            // Cmb_ReadBtn
            // 
            this.Cmb_ReadBtn.Items.Add("LeftUpKey");
            this.Cmb_ReadBtn.Items.Add("LeftDownKey");
            this.Cmb_ReadBtn.Items.Add("RightUpKey");
            this.Cmb_ReadBtn.Items.Add("RightDownKey");
            this.Cmb_ReadBtn.Items.Add("Soft1Key");
            this.Cmb_ReadBtn.Items.Add("Soft2Key");
            this.Cmb_ReadBtn.Location = new System.Drawing.Point(12, 158);
            this.Cmb_ReadBtn.Name = "Cmb_ReadBtn";
            this.Cmb_ReadBtn.Size = new System.Drawing.Size(107, 22);
            this.Cmb_ReadBtn.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(19, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 17);
            this.label3.Text = "Read Button";
            // 
            // Cmb_TagType
            // 
            this.Cmb_TagType.Location = new System.Drawing.Point(12, 111);
            this.Cmb_TagType.Name = "Cmb_TagType";
            this.Cmb_TagType.Size = new System.Drawing.Size(215, 22);
            this.Cmb_TagType.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(19, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 17);
            this.label2.Text = "Select Tag Type";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.Opt_AntOff);
            this.panel2.Controls.Add(this.Opt_AntOn);
            this.panel2.Location = new System.Drawing.Point(12, 7);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(216, 37);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(7, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 21);
            this.label1.Text = "Antenna";
            // 
            // Opt_AntOff
            // 
            this.Opt_AntOff.Checked = true;
            this.Opt_AntOff.Location = new System.Drawing.Point(143, 9);
            this.Opt_AntOff.Name = "Opt_AntOff";
            this.Opt_AntOff.Size = new System.Drawing.Size(51, 20);
            this.Opt_AntOff.TabIndex = 1;
            this.Opt_AntOff.Text = "Off";
            // 
            // Opt_AntOn
            // 
            this.Opt_AntOn.Location = new System.Drawing.Point(86, 9);
            this.Opt_AntOn.Name = "Opt_AntOn";
            this.Opt_AntOn.Size = new System.Drawing.Size(51, 20);
            this.Opt_AntOn.TabIndex = 0;
            this.Opt_AntOn.TabStop = false;
            this.Opt_AntOn.Text = "On";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Opt_Continue);
            this.panel1.Controls.Add(this.Opt_ASync);
            this.panel1.Controls.Add(this.Opt_Sync);
            this.panel1.Location = new System.Drawing.Point(12, 50);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(216, 37);
            // 
            // Opt_Continue
            // 
            this.Opt_Continue.Location = new System.Drawing.Point(122, 11);
            this.Opt_Continue.Name = "Opt_Continue";
            this.Opt_Continue.Size = new System.Drawing.Size(84, 20);
            this.Opt_Continue.TabIndex = 4;
            this.Opt_Continue.TabStop = false;
            this.Opt_Continue.Text = "Continuous";
            // 
            // Opt_ASync
            // 
            this.Opt_ASync.Location = new System.Drawing.Point(67, 11);
            this.Opt_ASync.Name = "Opt_ASync";
            this.Opt_ASync.Size = new System.Drawing.Size(51, 20);
            this.Opt_ASync.TabIndex = 3;
            this.Opt_ASync.TabStop = false;
            this.Opt_ASync.Text = "Sync";
            // 
            // Opt_Sync
            // 
            this.Opt_Sync.Checked = true;
            this.Opt_Sync.Location = new System.Drawing.Point(7, 11);
            this.Opt_Sync.Name = "Opt_Sync";
            this.Opt_Sync.Size = new System.Drawing.Size(57, 20);
            this.Opt_Sync.TabIndex = 2;
            this.Opt_Sync.Text = "ASync";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.tabControl1);
            this.KeyPreview = true;
            this.Menu = this.mainMenu1;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "RFID .NET";
            this.Closed += new System.EventHandler(this.Btn_Close_Click);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txt_Block;
        private System.Windows.Forms.Button Btn_Write;
        private System.Windows.Forms.Button Btn_Stop;
        private System.Windows.Forms.Button Btn_Read;
        private System.Windows.Forms.Button Btn_Clear;
        private System.Windows.Forms.Button Btn_Open;
        private System.Windows.Forms.ListBox lst_Msg;
        private System.Windows.Forms.TextBox txt_Data;
        private System.Windows.Forms.RadioButton Opt_AntOff;
        private System.Windows.Forms.RadioButton Opt_AntOn;
        private System.Windows.Forms.RadioButton Opt_Continue;
        private System.Windows.Forms.RadioButton Opt_ASync;
        private System.Windows.Forms.RadioButton Opt_Sync;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Btn_Apply;
        private System.Windows.Forms.Button Btn_Reset;
        private System.Windows.Forms.Button Btn_Cancel;
        private System.Windows.Forms.ComboBox Cmb_WriteBtn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox Cmb_ReadBtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox Cmb_TagType;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label_Serial;
        private System.Windows.Forms.Label label_Version;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Btn_Version;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
    }
}

