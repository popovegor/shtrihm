<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class M3Scanner
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Private mainMenu1 As System.Windows.Forms.MainMenu

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.Tab_Scanner = New System.Windows.Forms.TabControl
        Me.Tab_Main = New System.Windows.Forms.TabPage
        Me.Label4 = New System.Windows.Forms.Label
        Me.BTN_Close = New System.Windows.Forms.Button
        Me.BTN_Info = New System.Windows.Forms.Button
        Me.BTN_ScanCancel = New System.Windows.Forms.Button
        Me.BTN_Scan = New System.Windows.Forms.Button
        Me.LV_ScanData = New System.Windows.Forms.ListView
        Me.BarType = New System.Windows.Forms.ColumnHeader
        Me.BarData = New System.Windows.Forms.ColumnHeader
        Me.Tab_Sym = New System.Windows.Forms.TabPage
        Me.BTN_SYMCANCEL = New System.Windows.Forms.Button
        Me.BTN_Confirm = New System.Windows.Forms.Button
        Me.CB_GS1EXP = New System.Windows.Forms.CheckBox
        Me.CB_GS1LIM = New System.Windows.Forms.CheckBox
        Me.CB_GS1 = New System.Windows.Forms.CheckBox
        Me.CB_CODABAR = New System.Windows.Forms.CheckBox
        Me.CB_PLESSEY = New System.Windows.Forms.CheckBox
        Me.CB_MSI = New System.Windows.Forms.CheckBox
        Me.CB_I2OF5 = New System.Windows.Forms.CheckBox
        Me.CB_CODE11 = New System.Windows.Forms.CheckBox
        Me.CB_CODE35 = New System.Windows.Forms.CheckBox
        Me.CB_CODE93 = New System.Windows.Forms.CheckBox
        Me.CB_UCCEAN128 = New System.Windows.Forms.CheckBox
        Me.CB_CODE128 = New System.Windows.Forms.CheckBox
        Me.CB_PZN = New System.Windows.Forms.CheckBox
        Me.CB_CODE32 = New System.Windows.Forms.CheckBox
        Me.CB_CODE39 = New System.Windows.Forms.CheckBox
        Me.CB_EAN8 = New System.Windows.Forms.CheckBox
        Me.CB_BOOKLAND = New System.Windows.Forms.CheckBox
        Me.CB_EAN13 = New System.Windows.Forms.CheckBox
        Me.CB_UPCE = New System.Windows.Forms.CheckBox
        Me.CB_UPCA = New System.Windows.Forms.CheckBox
        Me.Tab_Option = New System.Windows.Forms.TabPage
        Me.BTN_OPCANCEL = New System.Windows.Forms.Button
        Me.BTN_OPTION_CONFIRM = New System.Windows.Forms.Button
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.CB_AIMID = New System.Windows.Forms.CheckBox
        Me.CB_HIGHFILTER = New System.Windows.Forms.CheckBox
        Me.CB_WIDESCAN = New System.Windows.Forms.CheckBox
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.CB_SECURITYLEVEL = New System.Windows.Forms.ComboBox
        Me.CB_TIMEOUT = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.RD_SYNC = New System.Windows.Forms.RadioButton
        Me.RD_ASYNC = New System.Windows.Forms.RadioButton
        Me.Label1 = New System.Windows.Forms.Label
        Me.Tab_Detail = New System.Windows.Forms.TabPage
        Me.BTN_DECANCEL = New System.Windows.Forms.Button
        Me.BTN_TELEPEN = New System.Windows.Forms.Button
        Me.BTN_GS1 = New System.Windows.Forms.Button
        Me.BTN_PLESSEY = New System.Windows.Forms.Button
        Me.BTN_MSI = New System.Windows.Forms.Button
        Me.BTN_CODABAR = New System.Windows.Forms.Button
        Me.BTN_I2OF5 = New System.Windows.Forms.Button
        Me.BTN_CODE11 = New System.Windows.Forms.Button
        Me.BTN_CODE35 = New System.Windows.Forms.Button
        Me.BTN_CODE93 = New System.Windows.Forms.Button
        Me.BTN_CODE128 = New System.Windows.Forms.Button
        Me.BTN_CODE39 = New System.Windows.Forms.Button
        Me.BTN_EAN8 = New System.Windows.Forms.Button
        Me.BTN_EAN13 = New System.Windows.Forms.Button
        Me.BTN_UPCE = New System.Windows.Forms.Button
        Me.BTN_UPCA = New System.Windows.Forms.Button
        Me.Tab_Scanner.SuspendLayout()
        Me.Tab_Main.SuspendLayout()
        Me.Tab_Sym.SuspendLayout()
        Me.Tab_Option.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Tab_Detail.SuspendLayout()
        Me.SuspendLayout()
        '
        'Tab_Scanner
        '
        Me.Tab_Scanner.Controls.Add(Me.Tab_Main)
        Me.Tab_Scanner.Controls.Add(Me.Tab_Sym)
        Me.Tab_Scanner.Controls.Add(Me.Tab_Option)
        Me.Tab_Scanner.Controls.Add(Me.Tab_Detail)
        Me.Tab_Scanner.Location = New System.Drawing.Point(0, 0)
        Me.Tab_Scanner.Name = "Tab_Scanner"
        Me.Tab_Scanner.SelectedIndex = 0
        Me.Tab_Scanner.Size = New System.Drawing.Size(240, 268)
        Me.Tab_Scanner.TabIndex = 0
        Me.Tab_Scanner.Tag = ""
        '
        'Tab_Main
        '
        Me.Tab_Main.Controls.Add(Me.Label4)
        Me.Tab_Main.Controls.Add(Me.BTN_Close)
        Me.Tab_Main.Controls.Add(Me.BTN_Info)
        Me.Tab_Main.Controls.Add(Me.BTN_ScanCancel)
        Me.Tab_Main.Controls.Add(Me.BTN_Scan)
        Me.Tab_Main.Controls.Add(Me.LV_ScanData)
        Me.Tab_Main.Location = New System.Drawing.Point(0, 0)
        Me.Tab_Main.Name = "Tab_Main"
        Me.Tab_Main.Size = New System.Drawing.Size(240, 245)
        Me.Tab_Main.Text = "Main"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(94, 225)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(142, 20)
        Me.Label4.Text = "Ver 3.1.0(20101119)"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'BTN_Close
        '
        Me.BTN_Close.Location = New System.Drawing.Point(128, 194)
        Me.BTN_Close.Name = "BTN_Close"
        Me.BTN_Close.Size = New System.Drawing.Size(105, 26)
        Me.BTN_Close.TabIndex = 4
        Me.BTN_Close.Text = "Close"
        '
        'BTN_Info
        '
        Me.BTN_Info.Location = New System.Drawing.Point(7, 194)
        Me.BTN_Info.Name = "BTN_Info"
        Me.BTN_Info.Size = New System.Drawing.Size(105, 26)
        Me.BTN_Info.TabIndex = 3
        Me.BTN_Info.Text = "Information"
        '
        'BTN_ScanCancel
        '
        Me.BTN_ScanCancel.Location = New System.Drawing.Point(128, 161)
        Me.BTN_ScanCancel.Name = "BTN_ScanCancel"
        Me.BTN_ScanCancel.Size = New System.Drawing.Size(105, 26)
        Me.BTN_ScanCancel.TabIndex = 2
        Me.BTN_ScanCancel.Text = "Scan Cancel"
        '
        'BTN_Scan
        '
        Me.BTN_Scan.Location = New System.Drawing.Point(7, 161)
        Me.BTN_Scan.Name = "BTN_Scan"
        Me.BTN_Scan.Size = New System.Drawing.Size(105, 26)
        Me.BTN_Scan.TabIndex = 1
        Me.BTN_Scan.Text = "Scan"
        '
        'LV_ScanData
        '
        Me.LV_ScanData.Columns.Add(Me.BarType)
        Me.LV_ScanData.Columns.Add(Me.BarData)
        Me.LV_ScanData.FullRowSelect = True
        Me.LV_ScanData.Location = New System.Drawing.Point(7, 6)
        Me.LV_ScanData.Name = "LV_ScanData"
        Me.LV_ScanData.Size = New System.Drawing.Size(226, 148)
        Me.LV_ScanData.TabIndex = 0
        Me.LV_ScanData.View = System.Windows.Forms.View.Details
        '
        'BarType
        '
        Me.BarType.Text = "Type"
        Me.BarType.Width = 80
        '
        'BarData
        '
        Me.BarData.Text = "Data"
        Me.BarData.Width = 140
        '
        'Tab_Sym
        '
        Me.Tab_Sym.Controls.Add(Me.BTN_SYMCANCEL)
        Me.Tab_Sym.Controls.Add(Me.BTN_Confirm)
        Me.Tab_Sym.Controls.Add(Me.CB_GS1EXP)
        Me.Tab_Sym.Controls.Add(Me.CB_GS1LIM)
        Me.Tab_Sym.Controls.Add(Me.CB_GS1)
        Me.Tab_Sym.Controls.Add(Me.CB_CODABAR)
        Me.Tab_Sym.Controls.Add(Me.CB_PLESSEY)
        Me.Tab_Sym.Controls.Add(Me.CB_MSI)
        Me.Tab_Sym.Controls.Add(Me.CB_I2OF5)
        Me.Tab_Sym.Controls.Add(Me.CB_CODE11)
        Me.Tab_Sym.Controls.Add(Me.CB_CODE35)
        Me.Tab_Sym.Controls.Add(Me.CB_CODE93)
        Me.Tab_Sym.Controls.Add(Me.CB_UCCEAN128)
        Me.Tab_Sym.Controls.Add(Me.CB_CODE128)
        Me.Tab_Sym.Controls.Add(Me.CB_PZN)
        Me.Tab_Sym.Controls.Add(Me.CB_CODE32)
        Me.Tab_Sym.Controls.Add(Me.CB_CODE39)
        Me.Tab_Sym.Controls.Add(Me.CB_EAN8)
        Me.Tab_Sym.Controls.Add(Me.CB_BOOKLAND)
        Me.Tab_Sym.Controls.Add(Me.CB_EAN13)
        Me.Tab_Sym.Controls.Add(Me.CB_UPCE)
        Me.Tab_Sym.Controls.Add(Me.CB_UPCA)
        Me.Tab_Sym.Location = New System.Drawing.Point(0, 0)
        Me.Tab_Sym.Name = "Tab_Sym"
        Me.Tab_Sym.Size = New System.Drawing.Size(232, 242)
        Me.Tab_Sym.Text = "Symbology"
        '
        'BTN_SYMCANCEL
        '
        Me.BTN_SYMCANCEL.Location = New System.Drawing.Point(122, 213)
        Me.BTN_SYMCANCEL.Name = "BTN_SYMCANCEL"
        Me.BTN_SYMCANCEL.Size = New System.Drawing.Size(98, 24)
        Me.BTN_SYMCANCEL.TabIndex = 21
        Me.BTN_SYMCANCEL.Text = "Cancel"
        '
        'BTN_Confirm
        '
        Me.BTN_Confirm.Location = New System.Drawing.Point(9, 213)
        Me.BTN_Confirm.Name = "BTN_Confirm"
        Me.BTN_Confirm.Size = New System.Drawing.Size(98, 24)
        Me.BTN_Confirm.TabIndex = 20
        Me.BTN_Confirm.Text = "Confirm"
        '
        'CB_GS1EXP
        '
        Me.CB_GS1EXP.Location = New System.Drawing.Point(122, 187)
        Me.CB_GS1EXP.Name = "CB_GS1EXP"
        Me.CB_GS1EXP.Size = New System.Drawing.Size(100, 20)
        Me.CB_GS1EXP.TabIndex = 19
        Me.CB_GS1EXP.Text = "GS1_EXP"
        '
        'CB_GS1LIM
        '
        Me.CB_GS1LIM.Location = New System.Drawing.Point(122, 167)
        Me.CB_GS1LIM.Name = "CB_GS1LIM"
        Me.CB_GS1LIM.Size = New System.Drawing.Size(100, 20)
        Me.CB_GS1LIM.TabIndex = 18
        Me.CB_GS1LIM.Text = "GS1_LIM"
        '
        'CB_GS1
        '
        Me.CB_GS1.Location = New System.Drawing.Point(122, 147)
        Me.CB_GS1.Name = "CB_GS1"
        Me.CB_GS1.Size = New System.Drawing.Size(100, 20)
        Me.CB_GS1.TabIndex = 17
        Me.CB_GS1.Text = "GS1"
        '
        'CB_CODABAR
        '
        Me.CB_CODABAR.Location = New System.Drawing.Point(122, 127)
        Me.CB_CODABAR.Name = "CB_CODABAR"
        Me.CB_CODABAR.Size = New System.Drawing.Size(100, 20)
        Me.CB_CODABAR.TabIndex = 16
        Me.CB_CODABAR.Text = "CODABAR"
        '
        'CB_PLESSEY
        '
        Me.CB_PLESSEY.Location = New System.Drawing.Point(122, 107)
        Me.CB_PLESSEY.Name = "CB_PLESSEY"
        Me.CB_PLESSEY.Size = New System.Drawing.Size(100, 20)
        Me.CB_PLESSEY.TabIndex = 15
        Me.CB_PLESSEY.Text = "PLESSEY"
        '
        'CB_MSI
        '
        Me.CB_MSI.Location = New System.Drawing.Point(122, 87)
        Me.CB_MSI.Name = "CB_MSI"
        Me.CB_MSI.Size = New System.Drawing.Size(100, 20)
        Me.CB_MSI.TabIndex = 14
        Me.CB_MSI.Text = "MSI"
        '
        'CB_I2OF5
        '
        Me.CB_I2OF5.Location = New System.Drawing.Point(122, 67)
        Me.CB_I2OF5.Name = "CB_I2OF5"
        Me.CB_I2OF5.Size = New System.Drawing.Size(100, 20)
        Me.CB_I2OF5.TabIndex = 13
        Me.CB_I2OF5.Text = "I2OF5"
        '
        'CB_CODE11
        '
        Me.CB_CODE11.Location = New System.Drawing.Point(122, 47)
        Me.CB_CODE11.Name = "CB_CODE11"
        Me.CB_CODE11.Size = New System.Drawing.Size(100, 20)
        Me.CB_CODE11.TabIndex = 12
        Me.CB_CODE11.Text = "CODE11"
        '
        'CB_CODE35
        '
        Me.CB_CODE35.Location = New System.Drawing.Point(122, 27)
        Me.CB_CODE35.Name = "CB_CODE35"
        Me.CB_CODE35.Size = New System.Drawing.Size(100, 20)
        Me.CB_CODE35.TabIndex = 11
        Me.CB_CODE35.Text = "CODE35"
        '
        'CB_CODE93
        '
        Me.CB_CODE93.Location = New System.Drawing.Point(122, 7)
        Me.CB_CODE93.Name = "CB_CODE93"
        Me.CB_CODE93.Size = New System.Drawing.Size(100, 20)
        Me.CB_CODE93.TabIndex = 10
        Me.CB_CODE93.Text = "CODE93"
        '
        'CB_UCCEAN128
        '
        Me.CB_UCCEAN128.Location = New System.Drawing.Point(7, 187)
        Me.CB_UCCEAN128.Name = "CB_UCCEAN128"
        Me.CB_UCCEAN128.Size = New System.Drawing.Size(109, 20)
        Me.CB_UCCEAN128.TabIndex = 9
        Me.CB_UCCEAN128.Text = "UCC/EAN-128"
        '
        'CB_CODE128
        '
        Me.CB_CODE128.Location = New System.Drawing.Point(7, 167)
        Me.CB_CODE128.Name = "CB_CODE128"
        Me.CB_CODE128.Size = New System.Drawing.Size(100, 20)
        Me.CB_CODE128.TabIndex = 8
        Me.CB_CODE128.Text = "CODE128"
        '
        'CB_PZN
        '
        Me.CB_PZN.Location = New System.Drawing.Point(7, 147)
        Me.CB_PZN.Name = "CB_PZN"
        Me.CB_PZN.Size = New System.Drawing.Size(100, 20)
        Me.CB_PZN.TabIndex = 7
        Me.CB_PZN.Text = "PZN"
        '
        'CB_CODE32
        '
        Me.CB_CODE32.Location = New System.Drawing.Point(7, 127)
        Me.CB_CODE32.Name = "CB_CODE32"
        Me.CB_CODE32.Size = New System.Drawing.Size(100, 20)
        Me.CB_CODE32.TabIndex = 6
        Me.CB_CODE32.Text = "CODE32"
        '
        'CB_CODE39
        '
        Me.CB_CODE39.Location = New System.Drawing.Point(7, 107)
        Me.CB_CODE39.Name = "CB_CODE39"
        Me.CB_CODE39.Size = New System.Drawing.Size(100, 20)
        Me.CB_CODE39.TabIndex = 5
        Me.CB_CODE39.Text = "CODE39"
        '
        'CB_EAN8
        '
        Me.CB_EAN8.Location = New System.Drawing.Point(7, 87)
        Me.CB_EAN8.Name = "CB_EAN8"
        Me.CB_EAN8.Size = New System.Drawing.Size(100, 20)
        Me.CB_EAN8.TabIndex = 4
        Me.CB_EAN8.Text = "EAN-8"
        '
        'CB_BOOKLAND
        '
        Me.CB_BOOKLAND.Location = New System.Drawing.Point(7, 67)
        Me.CB_BOOKLAND.Name = "CB_BOOKLAND"
        Me.CB_BOOKLAND.Size = New System.Drawing.Size(100, 20)
        Me.CB_BOOKLAND.TabIndex = 3
        Me.CB_BOOKLAND.Text = "BOOKLAND"
        '
        'CB_EAN13
        '
        Me.CB_EAN13.Location = New System.Drawing.Point(7, 47)
        Me.CB_EAN13.Name = "CB_EAN13"
        Me.CB_EAN13.Size = New System.Drawing.Size(100, 20)
        Me.CB_EAN13.TabIndex = 2
        Me.CB_EAN13.Text = "EAN-13"
        '
        'CB_UPCE
        '
        Me.CB_UPCE.Location = New System.Drawing.Point(7, 27)
        Me.CB_UPCE.Name = "CB_UPCE"
        Me.CB_UPCE.Size = New System.Drawing.Size(100, 20)
        Me.CB_UPCE.TabIndex = 1
        Me.CB_UPCE.Text = "UPC-E"
        '
        'CB_UPCA
        '
        Me.CB_UPCA.Location = New System.Drawing.Point(7, 7)
        Me.CB_UPCA.Name = "CB_UPCA"
        Me.CB_UPCA.Size = New System.Drawing.Size(100, 20)
        Me.CB_UPCA.TabIndex = 0
        Me.CB_UPCA.Text = "UPC-A"
        '
        'Tab_Option
        '
        Me.Tab_Option.Controls.Add(Me.BTN_OPCANCEL)
        Me.Tab_Option.Controls.Add(Me.BTN_OPTION_CONFIRM)
        Me.Tab_Option.Controls.Add(Me.Panel3)
        Me.Tab_Option.Controls.Add(Me.Panel2)
        Me.Tab_Option.Controls.Add(Me.Panel1)
        Me.Tab_Option.Location = New System.Drawing.Point(0, 0)
        Me.Tab_Option.Name = "Tab_Option"
        Me.Tab_Option.Size = New System.Drawing.Size(232, 242)
        Me.Tab_Option.Text = "Option"
        '
        'BTN_OPCANCEL
        '
        Me.BTN_OPCANCEL.Location = New System.Drawing.Point(124, 198)
        Me.BTN_OPCANCEL.Name = "BTN_OPCANCEL"
        Me.BTN_OPCANCEL.Size = New System.Drawing.Size(103, 34)
        Me.BTN_OPCANCEL.TabIndex = 7
        Me.BTN_OPCANCEL.Text = "Cancel"
        '
        'BTN_OPTION_CONFIRM
        '
        Me.BTN_OPTION_CONFIRM.Location = New System.Drawing.Point(11, 198)
        Me.BTN_OPTION_CONFIRM.Name = "BTN_OPTION_CONFIRM"
        Me.BTN_OPTION_CONFIRM.Size = New System.Drawing.Size(103, 34)
        Me.BTN_OPTION_CONFIRM.TabIndex = 3
        Me.BTN_OPTION_CONFIRM.Text = "Confirm"
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.CB_AIMID)
        Me.Panel3.Controls.Add(Me.CB_HIGHFILTER)
        Me.Panel3.Controls.Add(Me.CB_WIDESCAN)
        Me.Panel3.Location = New System.Drawing.Point(11, 128)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(215, 59)
        '
        'CB_AIMID
        '
        Me.CB_AIMID.Location = New System.Drawing.Point(8, 33)
        Me.CB_AIMID.Name = "CB_AIMID"
        Me.CB_AIMID.Size = New System.Drawing.Size(123, 20)
        Me.CB_AIMID.TabIndex = 2
        Me.CB_AIMID.Text = "Transmit AimID"
        '
        'CB_HIGHFILTER
        '
        Me.CB_HIGHFILTER.Location = New System.Drawing.Point(111, 9)
        Me.CB_HIGHFILTER.Name = "CB_HIGHFILTER"
        Me.CB_HIGHFILTER.Size = New System.Drawing.Size(100, 20)
        Me.CB_HIGHFILTER.TabIndex = 1
        Me.CB_HIGHFILTER.Text = "HighFilter"
        '
        'CB_WIDESCAN
        '
        Me.CB_WIDESCAN.Location = New System.Drawing.Point(8, 9)
        Me.CB_WIDESCAN.Name = "CB_WIDESCAN"
        Me.CB_WIDESCAN.Size = New System.Drawing.Size(89, 20)
        Me.CB_WIDESCAN.TabIndex = 0
        Me.CB_WIDESCAN.Text = "WideScan"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.CB_SECURITYLEVEL)
        Me.Panel2.Controls.Add(Me.CB_TIMEOUT)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Location = New System.Drawing.Point(11, 46)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(215, 71)
        '
        'CB_SECURITYLEVEL
        '
        Me.CB_SECURITYLEVEL.Items.Add("1")
        Me.CB_SECURITYLEVEL.Items.Add("2")
        Me.CB_SECURITYLEVEL.Items.Add("3")
        Me.CB_SECURITYLEVEL.Items.Add("4")
        Me.CB_SECURITYLEVEL.Location = New System.Drawing.Point(103, 39)
        Me.CB_SECURITYLEVEL.Name = "CB_SECURITYLEVEL"
        Me.CB_SECURITYLEVEL.Size = New System.Drawing.Size(100, 22)
        Me.CB_SECURITYLEVEL.TabIndex = 3
        '
        'CB_TIMEOUT
        '
        Me.CB_TIMEOUT.Items.Add("1")
        Me.CB_TIMEOUT.Items.Add("2")
        Me.CB_TIMEOUT.Items.Add("3")
        Me.CB_TIMEOUT.Items.Add("4")
        Me.CB_TIMEOUT.Items.Add("5")
        Me.CB_TIMEOUT.Items.Add("6")
        Me.CB_TIMEOUT.Items.Add("7")
        Me.CB_TIMEOUT.Items.Add("8")
        Me.CB_TIMEOUT.Items.Add("9")
        Me.CB_TIMEOUT.Items.Add("10")
        Me.CB_TIMEOUT.Location = New System.Drawing.Point(103, 9)
        Me.CB_TIMEOUT.Name = "CB_TIMEOUT"
        Me.CB_TIMEOUT.Size = New System.Drawing.Size(100, 22)
        Me.CB_TIMEOUT.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(8, 39)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(89, 17)
        Me.Label3.Text = "Security Level"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 20)
        Me.Label2.Text = "TimeOut"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.RD_SYNC)
        Me.Panel1.Controls.Add(Me.RD_ASYNC)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(11, 9)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(216, 29)
        '
        'RD_SYNC
        '
        Me.RD_SYNC.Location = New System.Drawing.Point(140, 6)
        Me.RD_SYNC.Name = "RD_SYNC"
        Me.RD_SYNC.Size = New System.Drawing.Size(71, 20)
        Me.RD_SYNC.TabIndex = 2
        Me.RD_SYNC.Text = "Sync"
        '
        'RD_ASYNC
        '
        Me.RD_ASYNC.Location = New System.Drawing.Point(78, 6)
        Me.RD_ASYNC.Name = "RD_ASYNC"
        Me.RD_ASYNC.Size = New System.Drawing.Size(65, 20)
        Me.RD_ASYNC.TabIndex = 1
        Me.RD_ASYNC.Text = "ASync"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 6)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 18)
        Me.Label1.Text = "SyncMode"
        '
        'Tab_Detail
        '
        Me.Tab_Detail.Controls.Add(Me.BTN_DECANCEL)
        Me.Tab_Detail.Controls.Add(Me.BTN_TELEPEN)
        Me.Tab_Detail.Controls.Add(Me.BTN_GS1)
        Me.Tab_Detail.Controls.Add(Me.BTN_PLESSEY)
        Me.Tab_Detail.Controls.Add(Me.BTN_MSI)
        Me.Tab_Detail.Controls.Add(Me.BTN_CODABAR)
        Me.Tab_Detail.Controls.Add(Me.BTN_I2OF5)
        Me.Tab_Detail.Controls.Add(Me.BTN_CODE11)
        Me.Tab_Detail.Controls.Add(Me.BTN_CODE35)
        Me.Tab_Detail.Controls.Add(Me.BTN_CODE93)
        Me.Tab_Detail.Controls.Add(Me.BTN_CODE128)
        Me.Tab_Detail.Controls.Add(Me.BTN_CODE39)
        Me.Tab_Detail.Controls.Add(Me.BTN_EAN8)
        Me.Tab_Detail.Controls.Add(Me.BTN_EAN13)
        Me.Tab_Detail.Controls.Add(Me.BTN_UPCE)
        Me.Tab_Detail.Controls.Add(Me.BTN_UPCA)
        Me.Tab_Detail.Location = New System.Drawing.Point(0, 0)
        Me.Tab_Detail.Name = "Tab_Detail"
        Me.Tab_Detail.Size = New System.Drawing.Size(232, 242)
        Me.Tab_Detail.Text = "Detail"
        '
        'BTN_DECANCEL
        '
        Me.BTN_DECANCEL.Location = New System.Drawing.Point(64, 198)
        Me.BTN_DECANCEL.Name = "BTN_DECANCEL"
        Me.BTN_DECANCEL.Size = New System.Drawing.Size(112, 36)
        Me.BTN_DECANCEL.TabIndex = 15
        Me.BTN_DECANCEL.Text = "GO MAIN PAGE"
        '
        'BTN_TELEPEN
        '
        Me.BTN_TELEPEN.Location = New System.Drawing.Point(162, 154)
        Me.BTN_TELEPEN.Name = "BTN_TELEPEN"
        Me.BTN_TELEPEN.Size = New System.Drawing.Size(72, 30)
        Me.BTN_TELEPEN.TabIndex = 14
        Me.BTN_TELEPEN.Text = "TELEPEN"
        '
        'BTN_GS1
        '
        Me.BTN_GS1.Location = New System.Drawing.Point(84, 154)
        Me.BTN_GS1.Name = "BTN_GS1"
        Me.BTN_GS1.Size = New System.Drawing.Size(72, 30)
        Me.BTN_GS1.TabIndex = 13
        Me.BTN_GS1.Text = "GS1"
        '
        'BTN_PLESSEY
        '
        Me.BTN_PLESSEY.Location = New System.Drawing.Point(6, 154)
        Me.BTN_PLESSEY.Name = "BTN_PLESSEY"
        Me.BTN_PLESSEY.Size = New System.Drawing.Size(72, 30)
        Me.BTN_PLESSEY.TabIndex = 12
        Me.BTN_PLESSEY.Text = "PLESSEY"
        '
        'BTN_MSI
        '
        Me.BTN_MSI.Location = New System.Drawing.Point(162, 118)
        Me.BTN_MSI.Name = "BTN_MSI"
        Me.BTN_MSI.Size = New System.Drawing.Size(72, 30)
        Me.BTN_MSI.TabIndex = 11
        Me.BTN_MSI.Text = "MSI"
        '
        'BTN_CODABAR
        '
        Me.BTN_CODABAR.Location = New System.Drawing.Point(84, 118)
        Me.BTN_CODABAR.Name = "BTN_CODABAR"
        Me.BTN_CODABAR.Size = New System.Drawing.Size(72, 30)
        Me.BTN_CODABAR.TabIndex = 10
        Me.BTN_CODABAR.Text = "CODABAR"
        '
        'BTN_I2OF5
        '
        Me.BTN_I2OF5.Location = New System.Drawing.Point(6, 118)
        Me.BTN_I2OF5.Name = "BTN_I2OF5"
        Me.BTN_I2OF5.Size = New System.Drawing.Size(72, 30)
        Me.BTN_I2OF5.TabIndex = 9
        Me.BTN_I2OF5.Text = "I2OF5"
        '
        'BTN_CODE11
        '
        Me.BTN_CODE11.Location = New System.Drawing.Point(162, 82)
        Me.BTN_CODE11.Name = "BTN_CODE11"
        Me.BTN_CODE11.Size = New System.Drawing.Size(72, 30)
        Me.BTN_CODE11.TabIndex = 8
        Me.BTN_CODE11.Text = "CODE11"
        '
        'BTN_CODE35
        '
        Me.BTN_CODE35.Location = New System.Drawing.Point(84, 82)
        Me.BTN_CODE35.Name = "BTN_CODE35"
        Me.BTN_CODE35.Size = New System.Drawing.Size(72, 30)
        Me.BTN_CODE35.TabIndex = 7
        Me.BTN_CODE35.Text = "CODE35"
        '
        'BTN_CODE93
        '
        Me.BTN_CODE93.Location = New System.Drawing.Point(6, 82)
        Me.BTN_CODE93.Name = "BTN_CODE93"
        Me.BTN_CODE93.Size = New System.Drawing.Size(72, 30)
        Me.BTN_CODE93.TabIndex = 6
        Me.BTN_CODE93.Text = "CODE93"
        '
        'BTN_CODE128
        '
        Me.BTN_CODE128.Location = New System.Drawing.Point(162, 46)
        Me.BTN_CODE128.Name = "BTN_CODE128"
        Me.BTN_CODE128.Size = New System.Drawing.Size(72, 30)
        Me.BTN_CODE128.TabIndex = 5
        Me.BTN_CODE128.Text = "CODE128"
        '
        'BTN_CODE39
        '
        Me.BTN_CODE39.Location = New System.Drawing.Point(84, 46)
        Me.BTN_CODE39.Name = "BTN_CODE39"
        Me.BTN_CODE39.Size = New System.Drawing.Size(72, 30)
        Me.BTN_CODE39.TabIndex = 4
        Me.BTN_CODE39.Text = "CODE39"
        '
        'BTN_EAN8
        '
        Me.BTN_EAN8.Location = New System.Drawing.Point(6, 46)
        Me.BTN_EAN8.Name = "BTN_EAN8"
        Me.BTN_EAN8.Size = New System.Drawing.Size(72, 30)
        Me.BTN_EAN8.TabIndex = 3
        Me.BTN_EAN8.Text = "EAN-8"
        '
        'BTN_EAN13
        '
        Me.BTN_EAN13.Location = New System.Drawing.Point(162, 9)
        Me.BTN_EAN13.Name = "BTN_EAN13"
        Me.BTN_EAN13.Size = New System.Drawing.Size(72, 30)
        Me.BTN_EAN13.TabIndex = 2
        Me.BTN_EAN13.Text = "EAN-13"
        '
        'BTN_UPCE
        '
        Me.BTN_UPCE.Location = New System.Drawing.Point(84, 9)
        Me.BTN_UPCE.Name = "BTN_UPCE"
        Me.BTN_UPCE.Size = New System.Drawing.Size(72, 30)
        Me.BTN_UPCE.TabIndex = 1
        Me.BTN_UPCE.Text = "UPC-E"
        '
        'BTN_UPCA
        '
        Me.BTN_UPCA.Location = New System.Drawing.Point(6, 9)
        Me.BTN_UPCA.Name = "BTN_UPCA"
        Me.BTN_UPCA.Size = New System.Drawing.Size(72, 30)
        Me.BTN_UPCA.TabIndex = 0
        Me.BTN_UPCA.Text = "UPC-A"
        '
        'M3Scanner
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(240, 268)
        Me.Controls.Add(Me.Tab_Scanner)
        Me.Menu = Me.mainMenu1
        Me.Name = "M3Scanner"
        Me.Text = "M3ScanTest_VB"
        Me.Tab_Scanner.ResumeLayout(False)
        Me.Tab_Main.ResumeLayout(False)
        Me.Tab_Sym.ResumeLayout(False)
        Me.Tab_Option.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Tab_Detail.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Tab_Scanner As System.Windows.Forms.TabControl
    Friend WithEvents Tab_Main As System.Windows.Forms.TabPage
    Friend WithEvents Tab_Sym As System.Windows.Forms.TabPage
    Friend WithEvents Tab_Option As System.Windows.Forms.TabPage
    Friend WithEvents LV_ScanData As System.Windows.Forms.ListView
    Friend WithEvents BTN_Scan As System.Windows.Forms.Button
    Friend WithEvents BarType As System.Windows.Forms.ColumnHeader
    Friend WithEvents BarData As System.Windows.Forms.ColumnHeader
    Friend WithEvents BTN_Close As System.Windows.Forms.Button
    Friend WithEvents BTN_Info As System.Windows.Forms.Button
    Friend WithEvents BTN_ScanCancel As System.Windows.Forms.Button
    Friend WithEvents CB_UCCEAN128 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_CODE128 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_PZN As System.Windows.Forms.CheckBox
    Friend WithEvents CB_CODE32 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_CODE39 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_EAN8 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_BOOKLAND As System.Windows.Forms.CheckBox
    Friend WithEvents CB_EAN13 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_UPCE As System.Windows.Forms.CheckBox
    Friend WithEvents CB_UPCA As System.Windows.Forms.CheckBox
    Friend WithEvents CB_GS1EXP As System.Windows.Forms.CheckBox
    Friend WithEvents CB_GS1LIM As System.Windows.Forms.CheckBox
    Friend WithEvents CB_GS1 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_CODABAR As System.Windows.Forms.CheckBox
    Friend WithEvents CB_PLESSEY As System.Windows.Forms.CheckBox
    Friend WithEvents CB_MSI As System.Windows.Forms.CheckBox
    Friend WithEvents CB_I2OF5 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_CODE11 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_CODE35 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_CODE93 As System.Windows.Forms.CheckBox
    Friend WithEvents BTN_Confirm As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents CB_TIMEOUT As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents RD_SYNC As System.Windows.Forms.RadioButton
    Friend WithEvents RD_ASYNC As System.Windows.Forms.RadioButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents CB_HIGHFILTER As System.Windows.Forms.CheckBox
    Friend WithEvents CB_WIDESCAN As System.Windows.Forms.CheckBox
    Friend WithEvents CB_SECURITYLEVEL As System.Windows.Forms.ComboBox
    Friend WithEvents BTN_OPTION_CONFIRM As System.Windows.Forms.Button
    Friend WithEvents Tab_Detail As System.Windows.Forms.TabPage
    Friend WithEvents BTN_TELEPEN As System.Windows.Forms.Button
    Friend WithEvents BTN_GS1 As System.Windows.Forms.Button
    Friend WithEvents BTN_PLESSEY As System.Windows.Forms.Button
    Friend WithEvents BTN_MSI As System.Windows.Forms.Button
    Friend WithEvents BTN_CODABAR As System.Windows.Forms.Button
    Friend WithEvents BTN_I2OF5 As System.Windows.Forms.Button
    Friend WithEvents BTN_CODE11 As System.Windows.Forms.Button
    Friend WithEvents BTN_CODE35 As System.Windows.Forms.Button
    Friend WithEvents BTN_CODE93 As System.Windows.Forms.Button
    Friend WithEvents BTN_CODE128 As System.Windows.Forms.Button
    Friend WithEvents BTN_CODE39 As System.Windows.Forms.Button
    Friend WithEvents BTN_EAN8 As System.Windows.Forms.Button
    Friend WithEvents BTN_EAN13 As System.Windows.Forms.Button
    Friend WithEvents BTN_UPCE As System.Windows.Forms.Button
    Friend WithEvents BTN_UPCA As System.Windows.Forms.Button
    Friend WithEvents BTN_DECANCEL As System.Windows.Forms.Button
    Friend WithEvents CB_AIMID As System.Windows.Forms.CheckBox
    Friend WithEvents BTN_SYMCANCEL As System.Windows.Forms.Button
    Friend WithEvents BTN_OPCANCEL As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label

End Class
