﻿Public Class FGS1
    Public m_bEnable As Boolean
    Public m_bGs1Lim As Boolean
    Public m_bGs1Exp As Boolean

    Private Sub FGS1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CB_GS1_ENABLE.Checked = m_bEnable
        CB_GS1LIM_ENABLE.Checked = m_bGs1Lim
        CB_GS1EXP_ENABLE.Checked = m_bGs1Exp
    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click
        m_bEnable = CB_GS1_ENABLE.Checked
        m_bGs1Lim = CB_GS1LIM_ENABLE.Checked
        m_bGs1Exp = CB_GS1EXP_ENABLE.Checked

        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class