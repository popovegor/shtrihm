﻿Public Class FEAN8
    Public m_bEnable As Boolean
    Public m_bXCD As Boolean
    Public m_bEAN8asEAN13 As Boolean

    Private Sub FEAN8_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CB_EAN8_ENABLE.Checked = m_bEnable
        CB_EAN8_XCD.Checked = m_bXCD
        CB_EAN8_AS_EAN13.Checked = m_bEAN8asEAN13
    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click
        m_bEnable = CB_EAN8_ENABLE.Checked
        m_bXCD = CB_EAN8_XCD.Checked
        m_bEAN8asEAN13 = CB_EAN8_AS_EAN13.Checked
        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class