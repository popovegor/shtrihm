﻿Public Class FPLESSEY
    Public m_bEnable As Boolean
    Public m_bCDV As Boolean
    Public m_bXCD As Boolean
    Public m_nMinLen As Integer
    Public m_nMaxLen As Integer
    Private Sub FPLESSEY_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CB_PLESSEY_ENABLE.Checked = m_bEnable
        CB_PLESSEY_CDV.Checked = m_bCDV
        CB_PLESSEY_XCD.Checked = m_bXCD

        TEXT_MINLEN.Text = m_nMinLen.ToString()
        TEXT_MAXLEN.Text = m_nMaxLen.ToString()
    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click
        m_bEnable = CB_PLESSEY_ENABLE.Checked
        m_bCDV = CB_PLESSEY_CDV.Checked
        m_bXCD = CB_PLESSEY_XCD.Checked

        m_nMinLen = Int32.Parse(TEXT_MINLEN.Text)
        m_nMaxLen = Int32.Parse(TEXT_MAXLEN.Text)
        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class