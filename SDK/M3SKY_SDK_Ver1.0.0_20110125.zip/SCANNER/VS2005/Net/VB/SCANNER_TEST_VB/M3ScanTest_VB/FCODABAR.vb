﻿Public Class FCODABAR
    Public m_bEnable As Boolean
    Public m_bXSS As Boolean
    Public m_nMinLen As Integer
    Public m_nMaxLen As Integer
    Private Sub FCODABAR_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CB_CODABAR_ENABLE.Checked = m_bEnable
        CB_CODABAR_XSS.Checked = m_bXSS

        TEXT_MINLEN.Text = m_nMinLen.ToString()
        TEXT_MAXLEN.Text = m_nMaxLen.ToString()
    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click
        m_bEnable = CB_CODABAR_ENABLE.Checked
        m_bXSS = CB_CODABAR_XSS.Checked

        m_nMinLen = Int32.Parse(TEXT_MINLEN.Text)
        m_nMaxLen = Int32.Parse(TEXT_MAXLEN.Text)

        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class