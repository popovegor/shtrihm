﻿Public Class FEAN13
    Public m_bEnable As Boolean
    Public m_bBookland As Boolean
    Public m_bXCD As Boolean
    Public m_bAddOn As Boolean

    Private Sub FEAN13_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CB_EAN13_ENABLE.Checked = m_bEnable
        CB_BOOKLAND_ENABLE.Checked = m_bBookland
        CB_EAN13_XCD.Checked = m_bXCD
        CB_EAN13_ADDON.Checked = m_bAddOn
    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click
        m_bEnable = CB_EAN13_ENABLE.Checked
        m_bBookland = CB_BOOKLAND_ENABLE.Checked
        m_bXCD = CB_EAN13_XCD.Checked
        m_bAddOn = CB_EAN13_ADDON.Checked

        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class