﻿Public Class FUPCE
    Public m_bEnable As Boolean
    Public m_bXNum As Boolean
    Public m_bXCD As Boolean
    Public m_nConvert As Integer


    Private Sub FUPCE_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CB_UPCE_ENABLE.Checked = m_bEnable
        CB_UPCE_XNUM.Checked = m_bXNum
        CB_UPCE_XCD.Checked = m_bXCD

        If m_nConvert = 1 Then
            RD_UPCE_AS_UPCA.Checked = True
        ElseIf m_nConvert = 2 Then
            RD_UPCE_AS_EAN13.Checked = True
        Else
            RD_UPCE_NOCON.Checked = True
        End If
    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click
        m_bEnable = CB_UPCE_ENABLE.Checked
        m_bXNum = CB_UPCE_XNUM.Checked
        m_bXCD = CB_UPCE_XCD.Checked

        If RD_UPCE_AS_UPCA.Checked = True Then
            m_nConvert = 1
        ElseIf RD_UPCE_AS_EAN13.Checked = True Then
            m_nConvert = 2
        Else
            m_nConvert = 0
        End If

        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class