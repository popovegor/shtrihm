Imports System
Imports Microsoft.Win32
Imports System.Threading
Imports System.Runtime.InteropServices
Imports KScanbarNet



Public Class M3Scanner

    Private ScanCtrl As KScanbarNet.ScannerControl
    Private M3BarCodeType As New KScanbarNet.MCBarCodeType
    Private M3ModuleOption As New KScanbarNet.MCModuleOption
    Private M3ReadOption As New KScanbarNet.MCReadOption

    Private pUpca As New KScanbarNet.MCBarOption_UPCA
    Private pUpce As New KScanbarNet.MCBarOption_UPCE
    Private pEan13 As New KScanbarNet.MCBarOption_EAN13
    Private pEan8 As New KScanbarNet.MCBarOption_EAN8
    Private pCode39 As New KScanbarNet.MCBarOption_CODE39
    Private pCode128 As New KScanbarNet.MCBarOption_CODE128
    Private pCode93 As New KScanbarNet.MCBarOption_CODE93
    Private pCode35 As New KScanbarNet.MCBarOption_CODE35
    Private pCode11 As New KScanbarNet.MCBarOption_CODE11
    Private pI2of5 As New KScanbarNet.MCBarOption_I2OF5
    Private pCodabar As New KScanbarNet.MCBarOption_CODABAR
    Private pMsi As New KScanbarNet.MCBarOption_MSI
    Private pPlessey As New KScanbarNet.MCBarOption_PLESSEY
    Private pGs1 As New KScanbarNet.MCBarOption_GS1
    Private pTelepen As New KScanbarNet.MCBarOption_TELEPEN

    Public m_bUpca As Boolean
    Public m_bUpce As Boolean
    Public m_bEan13 As Boolean
    Public m_bBookland As Boolean
    Public m_bEan8 As Boolean
    Public m_bCode39 As Boolean
    Public m_bCode32 As Boolean
    Public m_bPzn As Boolean
    Public m_bCode128 As Boolean
    Public m_bUccean128 As Boolean
    Public m_bCode93 As Boolean
    Public m_bCode35 As Boolean
    Public m_bCode11 As Boolean
    Public m_bI2of5 As Boolean
    Public m_bCodabar As Boolean
    Public m_bMsi As Boolean
    Public m_bPlessey As Boolean
    Public m_bGs1 As Boolean
    Public m_bGs1Lim As Boolean
    Public m_bGs1Exp As Boolean

    Public m_bKeyFlag As Boolean = False
    Public m_bReading As Boolean = False
    Public m_nSyncMode As Integer = 0


    Private Sub M3Scanner_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ScanCtrl = New KScanbarNet.ScannerControl
        AddHandler ScanCtrl.ScannerDataEvent, AddressOf Me.OnScanData

        Dim rk As RegistryKey
        rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\KeyPad\\SideKey", True)
        If rk Is Nothing Then
            rk = Registry.LocalMachine.CreateSubKey("ControlPanel\\KeyPad\\SideKey")
        Else
            rk.SetValue("RightDownKey", 3)
        End If

        ScanCtrl.ScanOpen()

        ScanCtrl.GetBarCode_Type(M3BarCodeType)
        m_bUpca = M3BarCodeType.bMC_UPCA
        m_bUpce = M3BarCodeType.bMC_UPCE
        m_bEan13 = M3BarCodeType.bMC_EAN13
        m_bBookland = M3BarCodeType.bMC_BOOKLAND
        m_bEan8 = M3BarCodeType.bMC_EAN8
        m_bCode39 = M3BarCodeType.bMC_CODE39
        m_bCode32 = M3BarCodeType.bMC_CODE32
        m_bPzn = M3BarCodeType.bMC_PZN
        m_bCode128 = M3BarCodeType.bMC_CODE128
        m_bUccean128 = M3BarCodeType.bMC_UCCEAN128
        m_bCode93 = M3BarCodeType.bMC_CODE93
        m_bCode35 = M3BarCodeType.bMC_CODE35
        m_bCode11 = M3BarCodeType.bMC_CODE11
        m_bI2of5 = M3BarCodeType.bMC_I2OF5
        m_bMsi = M3BarCodeType.bMC_MSI
        m_bPlessey = M3BarCodeType.bMC_PLESSEY
        m_bCodabar = M3BarCodeType.bMC_CODABAR
        m_bGs1 = M3BarCodeType.bMC_GS1
        m_bGs1Lim = M3BarCodeType.bMC_GS1_LIMITED
        m_bGs1Exp = M3BarCodeType.bMC_GS1_EXPANDED

        Tab_Scanner.Focus()
    End Sub
    Private Sub ScanRead()
        If m_bReading = True Then
            m_bReading = False
            ScanCtrl.ScanReadCancel()
        Else
            m_bReading = True
            ScanCtrl.ScanRead()
        End If

    End Sub

    Private Sub OnScanData(ByVal sender As System.Object, ByVal e As KScanbarNet.ScannerDataArgs)
        If (LV_ScanData.Items.Count > 7) Then
            LV_ScanData.Items.Clear()
        End If

        Dim ScanData As New ListViewItem()

        If e.ScanData <> "" Then
            ScanData.Text = e.ScanType
            ScanData.SubItems.Add(e.ScanData)

            LV_ScanData.Items.Add(ScanData)
            Call Beep()
        End If

    End Sub

    Private Sub M3Scanner_Closing(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Dim i As Integer
        Dim bResult As Boolean

        For i = 0 To 3
            bResult = ScanCtrl.ScanClose()
            Thread.Sleep(300)
            If bResult = True Then
                Exit For
            End If

            i = i + 1
        Next

        Dim rk As RegistryKey
        rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\KeyPad\\SideKey", True)
        If rk Is Nothing Then
            rk = Registry.LocalMachine.CreateSubKey("ControlPanel\\KeyPad\\SideKey")
        Else
            rk.SetValue("RightDownKey", 0)
        End If

        Application.Exit()

    End Sub

    Private Sub Tab_Scanner_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Tab_Scanner.KeyDown
        If (e.KeyCode = System.Windows.Forms.Keys.F14) Then
            If m_bKeyFlag = False Then
                m_bKeyFlag = True
                ScanCtrl.ScanRead()
            End If
        End If
    End Sub

    Private Sub Tab_Scanner_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Tab_Scanner.KeyUp
        If (e.KeyCode = System.Windows.Forms.Keys.F14) Then
            If m_bKeyFlag = True Then
                m_bKeyFlag = False
                If m_nSyncMode = 0 Then
                    ScanCtrl.ScanReadCancel()
                End If
            End If
        End If
    End Sub

    Private Sub BTN_Scan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_Scan.Click
        ScanCtrl.ScanRead()

        Tab_Scanner.Focus()
    End Sub
    Private Sub BTN_ScanCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_ScanCancel.Click
        ScanCtrl.ScanReadCancel()

        Tab_Scanner.Focus()
    End Sub

    Private Sub BTN_Info_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_Info.Click
        Dim strInfo As String = ScanCtrl.GetVersion()
        MessageBox.Show(strInfo)

        Tab_Scanner.Focus()
    End Sub

    Private Sub BTN_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_Close.Click
        Dim i As Integer
        Dim bResult As Boolean

        For i = 0 To 3
            bResult = ScanCtrl.ScanClose()
            Thread.Sleep(300)
            If bResult = True Then
                Exit For
            End If

            i = i + 1
        Next

        Dim rk As RegistryKey
        rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\KeyPad\\SideKey", True)
        If rk Is Nothing Then
            rk = Registry.LocalMachine.CreateSubKey("ControlPanel\\KeyPad\\SideKey")
        Else
            rk.SetValue("RightDownKey", 0)
        End If

        Application.Exit()

    End Sub


    Private Sub Tab_Scanner_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tab_Scanner.SelectedIndexChanged
        Select Case Tab_Scanner.SelectedIndex
            Case 0  'Main Page
                Tab_Scanner.Focus()
            Case 1  'Symbology Page
                ScanCtrl.ScanReadCancel()

                CB_UPCA.Checked = m_bUpca
                CB_UPCE.Checked = m_bUpce
                CB_EAN13.Checked = m_bEan13
                CB_BOOKLAND.Checked = m_bBookland
                CB_EAN8.Checked = m_bEan8
                CB_CODE39.Checked = m_bCode39
                CB_CODE32.Checked = m_bCode32
                CB_PZN.Checked = m_bPzn
                CB_CODE128.Checked = m_bCode128
                CB_UCCEAN128.Checked = m_bUccean128
                CB_CODE93.Checked = m_bCode93
                CB_CODE35.Checked = m_bCode35
                CB_CODE11.Checked = m_bCode11
                CB_I2OF5.Checked = m_bI2of5
                CB_MSI.Checked = m_bMsi
                CB_PLESSEY.Checked = m_bPlessey
                CB_CODABAR.Checked = m_bCodabar
                CB_GS1.Checked = m_bGs1
                CB_GS1LIM.Checked = m_bGs1Lim
                CB_GS1EXP.Checked = m_bGs1Exp

            Case 2  'Option Page
                ScanCtrl.ScanReadCancel()
                ScanCtrl.GetRead_Option(M3ReadOption)
                ScanCtrl.GetModule_Option(M3ModuleOption)

                If m_nSyncMode = 0 Then
                    RD_ASYNC.Checked = True
                Else
                    RD_SYNC.Checked = True
                End If

                Select Case M3ModuleOption.nMC_TimeOutSec
                    Case 1
                        CB_TIMEOUT.Text = "1"
                    Case 2
                        CB_TIMEOUT.Text = "2"
                    Case 3
                        CB_TIMEOUT.Text = "3"
                    Case 4
                        CB_TIMEOUT.Text = "4"
                    Case 5
                        CB_TIMEOUT.Text = "5"
                    Case 6
                        CB_TIMEOUT.Text = "6"
                    Case 7
                        CB_TIMEOUT.Text = "7"
                    Case 8
                        CB_TIMEOUT.Text = "8"
                    Case 9
                        CB_TIMEOUT.Text = "9"
                    Case 10
                        CB_TIMEOUT.Text = "10"
                End Select

                Select Case M3ModuleOption.nMC_SecurityLevel
                    Case 1
                        CB_SECURITYLEVEL.Text = "1"
                    Case 2
                        CB_SECURITYLEVEL.Text = "2"
                    Case 3
                        CB_SECURITYLEVEL.Text = "3"
                    Case 4
                        CB_SECURITYLEVEL.Text = "4"
                End Select

                CB_WIDESCAN.Checked = M3ReadOption.bMC_WIDESCANANGLE
                CB_HIGHFILTER.Checked = M3ReadOption.bMC_HIGHFILTERMODE
                CB_AIMID.Checked = ScanCtrl.Get_TransmitAimID()
            Case 3  'Detail Page
                ScanCtrl.ScanReadCancel()
        End Select



    End Sub

    Private Sub BTN_Confirm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_Confirm.Click
        m_bUpca = CB_UPCA.Checked
        m_bUpce = CB_UPCE.Checked
        m_bEan13 = CB_EAN13.Checked
        m_bBookland = CB_BOOKLAND.Checked
        m_bEan8 = CB_EAN8.Checked
        m_bCode39 = CB_CODE39.Checked
        m_bCode32 = CB_CODE32.Checked
        m_bPzn = CB_PZN.Checked
        m_bCode128 = CB_CODE128.Checked
        m_bUccean128 = CB_UCCEAN128.Checked
        m_bCode93 = CB_CODE93.Checked
        m_bCode35 = CB_CODE35.Checked
        m_bCode11 = CB_CODE11.Checked
        m_bI2of5 = CB_I2OF5.Checked
        m_bMsi = CB_MSI.Checked
        m_bPlessey = CB_PLESSEY.Checked
        m_bCodabar = CB_CODABAR.Checked
        m_bGs1 = CB_GS1.Checked
        m_bGs1Lim = CB_GS1LIM.Checked
        m_bGs1Exp = CB_GS1EXP.Checked

        M3BarCodeType.bMC_UPCA = CB_UPCA.Checked
        M3BarCodeType.bMC_UPCE = CB_UPCE.Checked
        M3BarCodeType.bMC_EAN13 = CB_EAN13.Checked
        M3BarCodeType.bMC_BOOKLAND = CB_BOOKLAND.Checked
        M3BarCodeType.bMC_EAN8 = CB_EAN8.Checked
        M3BarCodeType.bMC_CODE39 = CB_CODE39.Checked
        M3BarCodeType.bMC_CODE32 = CB_CODE32.Checked
        M3BarCodeType.bMC_PZN = CB_PZN.Checked
        M3BarCodeType.bMC_CODE128 = CB_CODE128.Checked
        M3BarCodeType.bMC_UCCEAN128 = CB_UCCEAN128.Checked
        M3BarCodeType.bMC_CODE93 = CB_CODE93.Checked
        M3BarCodeType.bMC_CODE35 = CB_CODE35.Checked
        M3BarCodeType.bMC_CODE11 = CB_CODE11.Checked
        M3BarCodeType.bMC_I2OF5 = CB_I2OF5.Checked
        M3BarCodeType.bMC_MSI = CB_MSI.Checked
        M3BarCodeType.bMC_PLESSEY = CB_PLESSEY.Checked
        M3BarCodeType.bMC_CODABAR = CB_CODABAR.Checked
        M3BarCodeType.bMC_GS1 = CB_GS1.Checked
        M3BarCodeType.bMC_GS1_LIMITED = CB_GS1LIM.Checked
        M3BarCodeType.bMC_GS1_EXPANDED = CB_GS1EXP.Checked

        ScanCtrl.SetBarCode_Type(M3BarCodeType)
        Tab_Scanner.SelectedIndex = 0
        Tab_Scanner.Focus()

    End Sub

    Private Sub BTN_OPTION_CONFIRM_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OPTION_CONFIRM.Click
        If RD_SYNC.Checked = True Then
            m_nSyncMode = 1
        Else
            m_nSyncMode = 0
        End If

        M3ModuleOption.nMC_TimeOutSec = CB_TIMEOUT.SelectedIndex + 1
        M3ModuleOption.nMC_SecurityLevel = CB_SECURITYLEVEL.SelectedIndex + 1

        M3ReadOption.bMC_WIDESCANANGLE = CB_WIDESCAN.Checked
        M3ReadOption.bMC_HIGHFILTERMODE = CB_HIGHFILTER.Checked
        ScanCtrl.Set_TransmitAimID(CB_AIMID.Checked)

        ScanCtrl.SetModule_Option(M3ModuleOption)
        ScanCtrl.SetRead_Option(M3ReadOption)

        Tab_Scanner.SelectedIndex = 0
        Tab_Scanner.Focus()

    End Sub

    Private Sub BTN_SYMCANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_SYMCANCEL.Click
        Tab_Scanner.SelectedIndex = 0
        Tab_Scanner.Focus()
    End Sub

    Private Sub BTN_OPCANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OPCANCEL.Click
        Tab_Scanner.SelectedIndex = 0
        Tab_Scanner.Focus()
    End Sub
    Private Sub BTN_DECANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_DECANCEL.Click
        Tab_Scanner.SelectedIndex = 0
        Tab_Scanner.Focus()
    End Sub

    Private Sub LV_ScanData_GotFocus(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LV_ScanData.GotFocus
        Tab_Scanner.SelectedIndex = 0
        Tab_Scanner.Focus()
    End Sub

    Private Sub BTN_UPCA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_UPCA.Click

        Dim UpcaDlg As New FUPCA()

        ScanCtrl.GetBarOptionUPCA(pUpca)

        UpcaDlg.m_bEnable = pUpca.bMC_UPCA_Enable
        UpcaDlg.m_bXNum = pUpca.bMC_UPCA_XNum
        UpcaDlg.m_bXCD = pUpca.bMC_UPCA_XCD
        UpcaDlg.m_bUPCAasEAN13 = pUpca.bMC_UPCA_AS_EAN13
        UpcaDlg.m_bAddOn = pUpca.bMC_UPCA_AddOn

        If UpcaDlg.ShowDialog() = Windows.Forms.DialogResult.OK Then
            m_bUpca = UpcaDlg.m_bEnable
            pUpca.bMC_UPCA_Enable = UpcaDlg.m_bEnable
            pUpca.bMC_UPCA_XNum = UpcaDlg.m_bXNum
            pUpca.bMC_UPCA_XCD = UpcaDlg.m_bXCD
            pUpca.bMC_UPCA_AS_EAN13 = UpcaDlg.m_bUPCAasEAN13
            pUpca.bMC_UPCA_AddOn = UpcaDlg.m_bAddOn

            ScanCtrl.SetBarOptionUPCA(pUpca)
        End If

    End Sub

    Private Sub BTN_UPCE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_UPCE.Click
        Dim UpceDlg As New FUPCE()

        ScanCtrl.GetBarOptionUPCE(pUpce)

        UpceDlg.m_bEnable = pUpce.bMC_UPCE_Enable
        UpceDlg.m_bXNum = pUpce.bMC_UPCE_XNum
        UpceDlg.m_bXCD = pUpce.bMC_UPCE_XCD
        UpceDlg.m_nConvert = pUpce.nMC_UPCE_Convert

        If UpceDlg.ShowDialog() = Windows.Forms.DialogResult.OK Then
            m_bUpce = UpceDlg.m_bEnable
            pUpce.bMC_UPCE_Enable = UpceDlg.m_bEnable
            pUpce.bMC_UPCE_XNum = UpceDlg.m_bXNum
            pUpce.bMC_UPCE_XCD = UpceDlg.m_bXCD
            pUpce.nMC_UPCE_Convert = UpceDlg.m_nConvert

            ScanCtrl.SetBarOptionUPCE(pUpce)
        End If
    End Sub

    Private Sub BTN_EAN13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_EAN13.Click
        Dim Ean13Dlg As New FEAN13()

        ScanCtrl.GetBarOptionEAN13(pEan13)

        Ean13Dlg.m_bEnable = pEan13.bMC_EAN13_Enable
        Ean13Dlg.m_bBookland = pEan13.bMC_BOOKLAND_Enable
        Ean13Dlg.m_bXCD = pEan13.bMC_EAN13_XCD
        Ean13Dlg.m_bAddOn = pEan13.bMC_EAN13_AddOn

        If Ean13Dlg.ShowDialog() = Windows.Forms.DialogResult.OK Then
            m_bEan13 = Ean13Dlg.m_bEnable
            m_bBookland = Ean13Dlg.m_bBookland
            pEan13.bMC_EAN13_Enable = Ean13Dlg.m_bEnable
            pEan13.bMC_BOOKLAND_Enable = Ean13Dlg.m_bBookland
            pEan13.bMC_EAN13_XCD = Ean13Dlg.m_bXCD
            pEan13.bMC_EAN13_AddOn = Ean13Dlg.m_bAddOn

            ScanCtrl.SetBarOptionEAN13(pEan13)
        End If
    End Sub

    Private Sub BTN_EAN8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_EAN8.Click
        Dim Ean8Dlg As New FEAN8()

        ScanCtrl.GetBarOptionEAN8(pEan8)

        Ean8Dlg.m_bEnable = pEan8.bMC_EAN8_Enable
        Ean8Dlg.m_bXCD = pEan8.bMC_EAN8_XCD
        Ean8Dlg.m_bEAN8asEAN13 = pEan8.nMC_EAN8_AS_EAN13

        If Ean8Dlg.ShowDialog() = Windows.Forms.DialogResult.OK Then
            m_bEan8 = Ean8Dlg.m_bEnable
            pEan8.bMC_EAN8_Enable = Ean8Dlg.m_bEnable
            pEan8.bMC_EAN8_XCD = Ean8Dlg.m_bXCD
            pEan8.nMC_EAN8_AS_EAN13 = Ean8Dlg.m_bEAN8asEAN13

            ScanCtrl.SetBarOptionEAN8(pEan8)
        End If
    End Sub

    Private Sub BTN_CODE39_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CODE39.Click
        Dim Code39Dlg As New FCODE39()

        ScanCtrl.GetBarOptionCODE39(pCode39)

        Code39Dlg.m_bEnable = pCode39.bMC_CODE39_Enable
        Code39Dlg.m_bCode32 = pCode39.bMC_CODE32_Enable
        Code39Dlg.m_bPzn = pCode39.bMC_PZN_Enable
        Code39Dlg.m_bCDV = pCode39.bMC_CODE39_CDV
        Code39Dlg.m_bXCD = pCode39.bMC_CODE39_XCD
        Code39Dlg.m_bFullASCII = pCode39.bMC_CODE39_FullASCII
        Code39Dlg.m_nMinLen = pCode39.nMC_CODE39_MinLen
        Code39Dlg.m_nMaxLen = pCode39.nMC_CODE39_MaxLen

        If Code39Dlg.ShowDialog() = Windows.Forms.DialogResult.OK Then
            m_bCode39 = Code39Dlg.m_bEnable
            m_bCode32 = Code39Dlg.m_bCode32
            m_bPzn = Code39Dlg.m_bPzn
            pCode39.bMC_CODE39_Enable = Code39Dlg.m_bEnable
            pCode39.bMC_CODE32_Enable = Code39Dlg.m_bCode32
            pCode39.bMC_PZN_Enable = Code39Dlg.m_bPzn
            pCode39.bMC_CODE39_CDV = Code39Dlg.m_bCDV
            pCode39.bMC_CODE39_XCD = Code39Dlg.m_bXCD
            pCode39.bMC_CODE39_FullASCII = Code39Dlg.m_bFullASCII
            pCode39.nMC_CODE39_MinLen = Code39Dlg.m_nMinLen
            pCode39.nMC_CODE39_MaxLen = Code39Dlg.m_nMaxLen

            ScanCtrl.SetBarOptionCODE39(pCode39)
        End If
    End Sub

    Private Sub BTN_CODE128_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CODE128.Click
        Dim Code128Dlg As New FCODE128()

        ScanCtrl.GetBarOptionCODE128(pCode128)

        Code128Dlg.m_bEnable = pCode128.bMC_CODE128_Enable
        Code128Dlg.m_bUccean128 = pCode128.bMC_UCCEAN128_Enable
        Code128Dlg.m_nMinLen = pCode128.nMC_CODE128_MinLen
        Code128Dlg.m_nMaxLen = pCode128.nMC_CODE128_MaxLen

        If Code128Dlg.ShowDialog() = Windows.Forms.DialogResult.OK Then
            m_bCode128 = Code128Dlg.m_bEnable
            m_bUccean128 = Code128Dlg.m_bUccean128
            pCode128.bMC_CODE128_Enable = Code128Dlg.m_bEnable
            pCode128.bMC_UCCEAN128_Enable = Code128Dlg.m_bUccean128
            pCode128.nMC_CODE128_MinLen = Code128Dlg.m_nMinLen
            pCode128.nMC_CODE128_MaxLen = Code128Dlg.m_nMaxLen

            ScanCtrl.SetBarOptionCODE128(pCode128)
        End If
    End Sub

    Private Sub BTN_CODE93_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CODE93.Click
        Dim Code93Dlg As New FCODE93()

        ScanCtrl.GetBarOptionCODE93(pCode93)

        Code93Dlg.m_bEnable = pCode93.bMC_CODE93_Enable
        Code93Dlg.m_nMinLen = pCode93.nMC_CODE93_MinLen
        Code93Dlg.m_nMaxLen = pCode93.nMC_CODE93_MaxLen

        If Code93Dlg.ShowDialog() = Windows.Forms.DialogResult.OK Then
            m_bCode93 = Code93Dlg.m_bEnable
            pCode93.bMC_CODE93_Enable = Code93Dlg.m_bEnable
            pCode93.nMC_CODE93_MinLen = Code93Dlg.m_nMinLen
            pCode93.nMC_CODE93_MaxLen = Code93Dlg.m_nMaxLen

            ScanCtrl.SetBarOptionCODE93(pCode93)
        End If
    End Sub

    Private Sub BTN_CODE35_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CODE35.Click
        Dim Code35Dlg As New FCODE35()

        ScanCtrl.GetBarOptionCODE35(pCode35)

        Code35Dlg.m_bEnable = pCode35.bMC_CODE35_Enable

        If Code35Dlg.ShowDialog() = Windows.Forms.DialogResult.OK Then
            m_bCode35 = Code35Dlg.m_bEnable
            pCode35.bMC_CODE35_Enable = Code35Dlg.m_bEnable

            ScanCtrl.SetBarOptionCODE35(pCode35)
        End If
    End Sub

    Private Sub BTN_CODE11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CODE11.Click
        Dim Code11Dlg As New FCODE11()

        ScanCtrl.GetBarOptionCODE11(pCode11)

        Code11Dlg.m_bEnable = pCode11.bMC_CODE11_Enable
        Code11Dlg.m_bXCD = pCode11.bMC_CODE11_XCD
        Code11Dlg.m_nCDV = pCode11.nMC_CODE11_CDV
        Code11Dlg.m_nMinLen = pCode11.nMC_CODE11_MinLen
        Code11Dlg.m_nMaxLen = pCode11.nMC_CODE11_MaxLen

        If Code11Dlg.ShowDialog() = Windows.Forms.DialogResult.OK Then
            m_bCode11 = Code11Dlg.m_bEnable
            pCode11.bMC_CODE11_Enable = Code11Dlg.m_bEnable
            pCode11.bMC_CODE11_XCD = Code11Dlg.m_bXCD
            pCode11.nMC_CODE11_CDV = Code11Dlg.m_nCDV
            pCode11.nMC_CODE11_MinLen = Code11Dlg.m_nMinLen
            pCode11.nMC_CODE11_MaxLen = Code11Dlg.m_nMaxLen

            ScanCtrl.SetBarOptionCODE11(pCode11)
        End If

    End Sub

    Private Sub BTN_I2OF5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_I2OF5.Click
        Dim I2of5Dlg As New FI2OF5()

        ScanCtrl.GetBarOptionI2OF5(pI2of5)

        I2of5Dlg.m_bEnable = pI2of5.bMC_I2OF5_Enable
        I2of5Dlg.m_bItf14 = pI2of5.bMC_ITF14_Enable
        I2of5Dlg.m_bMatrix2of5 = pI2of5.bMC_MATRIX2OF5_Enable
        I2of5Dlg.m_bDlogic = pI2of5.bMC_DLOGIG_Enable
        I2of5Dlg.m_bIndustry = pI2of5.bMC_INDUSTRY_Enable
        I2of5Dlg.m_bIata = pI2of5.bMC_IATA_Enable
        I2of5Dlg.m_bCDV = pI2of5.bMC_I2OF5_CDV
        I2of5Dlg.m_bXCD = pI2of5.bMC_I2OF5_XCD
        I2of5Dlg.m_nMinLen = pI2of5.nMC_I2OF5_MinLen
        I2of5Dlg.m_nMaxLen = pI2of5.nMC_I2OF5_MaxLen

        If I2of5Dlg.ShowDialog() = Windows.Forms.DialogResult.OK Then
            m_bI2of5 = I2of5Dlg.m_bEnable
            pI2of5.bMC_I2OF5_Enable = I2of5Dlg.m_bEnable
            pI2of5.bMC_ITF14_Enable = I2of5Dlg.m_bItf14
            pI2of5.bMC_MATRIX2OF5_Enable = I2of5Dlg.m_bMatrix2of5
            pI2of5.bMC_DLOGIG_Enable = I2of5Dlg.m_bDlogic
            pI2of5.bMC_INDUSTRY_Enable = I2of5Dlg.m_bIndustry
            pI2of5.bMC_IATA_Enable = I2of5Dlg.m_bIata
            pI2of5.bMC_I2OF5_CDV = I2of5Dlg.m_bCDV
            pI2of5.bMC_I2OF5_XCD = I2of5Dlg.m_bXCD
            pI2of5.nMC_I2OF5_MinLen = I2of5Dlg.m_nMinLen
            pI2of5.nMC_I2OF5_MaxLen = I2of5Dlg.m_nMaxLen

            ScanCtrl.SetBarOptionI2OF5(pI2of5)
        End If
    End Sub

    Private Sub BTN_CODABAR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CODABAR.Click
        Dim CodabarDlg As New FCODABAR()

        ScanCtrl.GetBarOptionCODABAR(pCodabar)

        CodabarDlg.m_bEnable = pCodabar.bMC_CODABAR_Enable
        CodabarDlg.m_bXSS = pCodabar.bMC_CODABAR_XSS
        CodabarDlg.m_nMinLen = pCodabar.nMC_CODABAR_MinLen
        CodabarDlg.m_nMaxLen = pCodabar.nMC_CODABAR_MaxLen

        If CodabarDlg.ShowDialog() = Windows.Forms.DialogResult.OK Then
            m_bCodabar = CodabarDlg.m_bEnable
            pCodabar.bMC_CODABAR_Enable = CodabarDlg.m_bEnable
            pCodabar.bMC_CODABAR_XSS = CodabarDlg.m_bXSS
            pCodabar.nMC_CODABAR_MinLen = CodabarDlg.m_nMinLen
            pCodabar.nMC_CODABAR_MaxLen = CodabarDlg.m_nMaxLen

            ScanCtrl.SetBarOptionCODABAR(pCodabar)
        End If
    End Sub

    Private Sub BTN_MSI_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_MSI.Click
        Dim MsiDlg As New FMSI()

        ScanCtrl.GetBarOptionMSI(pMsi)

        MsiDlg.m_bEnable = pMsi.bMC_MSI_Enable
        MsiDlg.m_bCDV = pMsi.bMC_MSI_CDV
        MsiDlg.m_bXCD = pMsi.bMC_MSI_XCD
        MsiDlg.m_nMinLen = pMsi.nMC_MSI_MinLen
        MsiDlg.m_nMaxLen = pMsi.nMC_MSI_MaxLen

        If MsiDlg.ShowDialog() = Windows.Forms.DialogResult.OK Then
            m_bMsi = MsiDlg.m_bEnable
            pMsi.bMC_MSI_Enable = MsiDlg.m_bEnable
            pMsi.bMC_MSI_CDV = MsiDlg.m_bCDV
            pMsi.bMC_MSI_XCD = MsiDlg.m_bXCD
            pMsi.nMC_MSI_MinLen = MsiDlg.m_nMinLen
            pMsi.nMC_MSI_MaxLen = MsiDlg.m_nMaxLen

            ScanCtrl.SetBarOptionMSI(pMsi)
        End If
    End Sub

    Private Sub BTN_PLESSEY_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_PLESSEY.Click
        Dim PlesseyDlg As New FPLESSEY()

        ScanCtrl.GetBarOptionPLESSEY(pPlessey)

        PlesseyDlg.m_bEnable = pPlessey.bMC_PLESSEY_Enable
        PlesseyDlg.m_bCDV = pPlessey.bMC_PLESSEY_CDV
        PlesseyDlg.m_bXCD = pPlessey.bMC_PLESSEY_XCD
        PlesseyDlg.m_nMinLen = pPlessey.nMC_PLESSEY_MinLen
        PlesseyDlg.m_nMaxLen = pPlessey.nMC_PLESSEY_MaxLen

        If PlesseyDlg.ShowDialog() = Windows.Forms.DialogResult.OK Then
            m_bPlessey = PlesseyDlg.m_bEnable
            pPlessey.bMC_PLESSEY_Enable = PlesseyDlg.m_bEnable
            pPlessey.bMC_PLESSEY_CDV = PlesseyDlg.m_bCDV
            pPlessey.bMC_PLESSEY_XCD = PlesseyDlg.m_bXCD
            pPlessey.nMC_PLESSEY_MinLen = PlesseyDlg.m_nMinLen
            pPlessey.nMC_PLESSEY_MaxLen = PlesseyDlg.m_nMaxLen

            ScanCtrl.SetBarOptionPLESSEY(pPlessey)
        End If
    End Sub

    Private Sub BTN_GS1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_GS1.Click
        Dim Gs1Dlg As New FGS1()

        ScanCtrl.GetBarOptionGS1(pGs1)

        Gs1Dlg.m_bEnable = pGs1.bMC_GS1_Enable
        Gs1Dlg.m_bGs1Lim = pGs1.bMC_GS1LIM_Enable
        Gs1Dlg.m_bGs1Exp = pGs1.bMC_GS1EXP_Enable

        If Gs1Dlg.ShowDialog() = Windows.Forms.DialogResult.OK Then
            m_bGs1 = Gs1Dlg.m_bEnable
            m_bGs1Lim = Gs1Dlg.m_bGs1Lim
            m_bGs1Exp = Gs1Dlg.m_bGs1Exp
            pGs1.bMC_GS1_Enable = Gs1Dlg.m_bEnable
            pGs1.bMC_GS1LIM_Enable = Gs1Dlg.m_bGs1Lim
            pGs1.bMC_GS1EXP_Enable = Gs1Dlg.m_bGs1Exp

            ScanCtrl.SetBarOptionGS1(pGs1)
        End If
    End Sub

    Private Sub BTN_TELEPEN_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_TELEPEN.Click
        Dim TelepenDlg As New FTELEPEN()

        ScanCtrl.GetBarOptionTELEPEN(pTelepen)

        TelepenDlg.m_bEnable = pTelepen.bMC_TELEPEN_Enable
        TelepenDlg.m_bOldStyle = pTelepen.bMC_TELEPEN_OldStyle

        If TelepenDlg.ShowDialog() = Windows.Forms.DialogResult.OK Then
            pTelepen.bMC_TELEPEN_Enable = TelepenDlg.m_bEnable
            pTelepen.bMC_TELEPEN_OldStyle = TelepenDlg.m_bOldStyle

            ScanCtrl.SetBarOptionTELEPEN(pTelepen)
        End If
    End Sub
End Class
