﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class FPLESSEY
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Private mainMenu1 As System.Windows.Forms.MainMenu

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.CB_PLESSEY_ENABLE = New System.Windows.Forms.CheckBox
        Me.CB_PLESSEY_CDV = New System.Windows.Forms.CheckBox
        Me.CB_PLESSEY_XCD = New System.Windows.Forms.CheckBox
        Me.TEXT_MAXLEN = New System.Windows.Forms.TextBox
        Me.TEXT_MINLEN = New System.Windows.Forms.TextBox
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.BTN_CANCEL = New System.Windows.Forms.Button
        Me.BTN_OK = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'CB_PLESSEY_ENABLE
        '
        Me.CB_PLESSEY_ENABLE.Location = New System.Drawing.Point(43, 40)
        Me.CB_PLESSEY_ENABLE.Name = "CB_PLESSEY_ENABLE"
        Me.CB_PLESSEY_ENABLE.Size = New System.Drawing.Size(160, 20)
        Me.CB_PLESSEY_ENABLE.TabIndex = 0
        Me.CB_PLESSEY_ENABLE.Text = "Enable"
        '
        'CB_PLESSEY_CDV
        '
        Me.CB_PLESSEY_CDV.Location = New System.Drawing.Point(43, 80)
        Me.CB_PLESSEY_CDV.Name = "CB_PLESSEY_CDV"
        Me.CB_PLESSEY_CDV.Size = New System.Drawing.Size(160, 20)
        Me.CB_PLESSEY_CDV.TabIndex = 1
        Me.CB_PLESSEY_CDV.Text = "Check Digit Verification"
        '
        'CB_PLESSEY_XCD
        '
        Me.CB_PLESSEY_XCD.Location = New System.Drawing.Point(43, 120)
        Me.CB_PLESSEY_XCD.Name = "CB_PLESSEY_XCD"
        Me.CB_PLESSEY_XCD.Size = New System.Drawing.Size(160, 20)
        Me.CB_PLESSEY_XCD.TabIndex = 2
        Me.CB_PLESSEY_XCD.Text = "Transmit Check Digit"
        '
        'TEXT_MAXLEN
        '
        Me.TEXT_MAXLEN.Location = New System.Drawing.Point(188, 177)
        Me.TEXT_MAXLEN.Name = "TEXT_MAXLEN"
        Me.TEXT_MAXLEN.Size = New System.Drawing.Size(35, 21)
        Me.TEXT_MAXLEN.TabIndex = 30
        '
        'TEXT_MINLEN
        '
        Me.TEXT_MINLEN.Location = New System.Drawing.Point(78, 177)
        Me.TEXT_MINLEN.Name = "TEXT_MINLEN"
        Me.TEXT_MINLEN.Size = New System.Drawing.Size(35, 21)
        Me.TEXT_MINLEN.TabIndex = 29
        '
        'label2
        '
        Me.label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
        Me.label2.Location = New System.Drawing.Point(126, 180)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(60, 20)
        Me.label2.Text = "Max.Len"
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
        Me.label1.Location = New System.Drawing.Point(17, 180)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(59, 20)
        Me.label1.Text = "Min.Len"
        '
        'BTN_CANCEL
        '
        Me.BTN_CANCEL.Location = New System.Drawing.Point(128, 209)
        Me.BTN_CANCEL.Name = "BTN_CANCEL"
        Me.BTN_CANCEL.Size = New System.Drawing.Size(93, 35)
        Me.BTN_CANCEL.TabIndex = 28
        Me.BTN_CANCEL.Text = "CANCEL"
        '
        'BTN_OK
        '
        Me.BTN_OK.Location = New System.Drawing.Point(20, 209)
        Me.BTN_OK.Name = "BTN_OK"
        Me.BTN_OK.Size = New System.Drawing.Size(93, 35)
        Me.BTN_OK.TabIndex = 27
        Me.BTN_OK.Text = "OK"
        '
        'FPLESSEY
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(240, 268)
        Me.Controls.Add(Me.TEXT_MAXLEN)
        Me.Controls.Add(Me.TEXT_MINLEN)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.BTN_CANCEL)
        Me.Controls.Add(Me.BTN_OK)
        Me.Controls.Add(Me.CB_PLESSEY_XCD)
        Me.Controls.Add(Me.CB_PLESSEY_CDV)
        Me.Controls.Add(Me.CB_PLESSEY_ENABLE)
        Me.Menu = Me.mainMenu1
        Me.Name = "FPLESSEY"
        Me.Text = "PLESSEY"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents CB_PLESSEY_ENABLE As System.Windows.Forms.CheckBox
    Friend WithEvents CB_PLESSEY_CDV As System.Windows.Forms.CheckBox
    Friend WithEvents CB_PLESSEY_XCD As System.Windows.Forms.CheckBox
    Private WithEvents TEXT_MAXLEN As System.Windows.Forms.TextBox
    Private WithEvents TEXT_MINLEN As System.Windows.Forms.TextBox
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents BTN_CANCEL As System.Windows.Forms.Button
    Friend WithEvents BTN_OK As System.Windows.Forms.Button
End Class
