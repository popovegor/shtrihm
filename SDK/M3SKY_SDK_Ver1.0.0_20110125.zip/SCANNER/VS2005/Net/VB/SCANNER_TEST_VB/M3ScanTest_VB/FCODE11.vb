﻿Public Class FCODE11
    Public m_bEnable As Boolean
    Public m_bXCD As Boolean
    Public m_nCDV As Integer
    Public m_nMinLen As Integer
    Public m_nMaxLen As Integer

    Private Sub FCODE11_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CB_CODE11_ENABLE.Checked = m_bEnable
        CB_CODE11_XCD.Checked = m_bXCD
        If m_nCDV = 0 Then
            RD_CODE11_NOCDV.Checked = True
        ElseIf m_nCDV = 2 Then
            RD_CODE11_2CDV.Checked = True
        Else
            RD_CODE11_1CDV.Checked = True
        End If

        TEXT_MINLEN.Text = m_nMinLen.ToString()
        TEXT_MAXLEN.Text = m_nMaxLen.ToString()
    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click
        m_bEnable = CB_CODE11_ENABLE.Checked
        m_bXCD = CB_CODE11_XCD.Checked

        If RD_CODE11_NOCDV.Checked = True Then
            m_nCDV = 0
        ElseIf RD_CODE11_2CDV.Checked = True Then
            m_nCDV = 2
        Else
            m_nCDV = 1
        End If

        m_nMinLen = Int32.Parse(TEXT_MINLEN.Text)
        m_nMaxLen = Int32.Parse(TEXT_MAXLEN.Text)

        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class