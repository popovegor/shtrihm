﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class FEAN13
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Private mainMenu1 As System.Windows.Forms.MainMenu

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.CB_EAN13_ENABLE = New System.Windows.Forms.CheckBox
        Me.CB_BOOKLAND_ENABLE = New System.Windows.Forms.CheckBox
        Me.CB_EAN13_XCD = New System.Windows.Forms.CheckBox
        Me.CB_EAN13_ADDON = New System.Windows.Forms.CheckBox
        Me.BTN_CANCEL = New System.Windows.Forms.Button
        Me.BTN_OK = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'CB_EAN13_ENABLE
        '
        Me.CB_EAN13_ENABLE.Location = New System.Drawing.Point(48, 42)
        Me.CB_EAN13_ENABLE.Name = "CB_EAN13_ENABLE"
        Me.CB_EAN13_ENABLE.Size = New System.Drawing.Size(144, 20)
        Me.CB_EAN13_ENABLE.TabIndex = 0
        Me.CB_EAN13_ENABLE.Text = "Enable"
        '
        'CB_BOOKLAND_ENABLE
        '
        Me.CB_BOOKLAND_ENABLE.Location = New System.Drawing.Point(48, 72)
        Me.CB_BOOKLAND_ENABLE.Name = "CB_BOOKLAND_ENABLE"
        Me.CB_BOOKLAND_ENABLE.Size = New System.Drawing.Size(144, 20)
        Me.CB_BOOKLAND_ENABLE.TabIndex = 1
        Me.CB_BOOKLAND_ENABLE.Text = "Enable BOOKLAND"
        '
        'CB_EAN13_XCD
        '
        Me.CB_EAN13_XCD.Location = New System.Drawing.Point(48, 102)
        Me.CB_EAN13_XCD.Name = "CB_EAN13_XCD"
        Me.CB_EAN13_XCD.Size = New System.Drawing.Size(144, 20)
        Me.CB_EAN13_XCD.TabIndex = 2
        Me.CB_EAN13_XCD.Text = "Transmit Check Digit"
        '
        'CB_EAN13_ADDON
        '
        Me.CB_EAN13_ADDON.Location = New System.Drawing.Point(48, 132)
        Me.CB_EAN13_ADDON.Name = "CB_EAN13_ADDON"
        Me.CB_EAN13_ADDON.Size = New System.Drawing.Size(144, 20)
        Me.CB_EAN13_ADDON.TabIndex = 3
        Me.CB_EAN13_ADDON.Text = "Add On 2/5"
        '
        'BTN_CANCEL
        '
        Me.BTN_CANCEL.Location = New System.Drawing.Point(128, 209)
        Me.BTN_CANCEL.Name = "BTN_CANCEL"
        Me.BTN_CANCEL.Size = New System.Drawing.Size(93, 35)
        Me.BTN_CANCEL.TabIndex = 8
        Me.BTN_CANCEL.Text = "CANCEL"
        '
        'BTN_OK
        '
        Me.BTN_OK.Location = New System.Drawing.Point(20, 209)
        Me.BTN_OK.Name = "BTN_OK"
        Me.BTN_OK.Size = New System.Drawing.Size(93, 35)
        Me.BTN_OK.TabIndex = 7
        Me.BTN_OK.Text = "OK"
        '
        'FEAN13
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(240, 268)
        Me.Controls.Add(Me.BTN_CANCEL)
        Me.Controls.Add(Me.BTN_OK)
        Me.Controls.Add(Me.CB_EAN13_ADDON)
        Me.Controls.Add(Me.CB_EAN13_XCD)
        Me.Controls.Add(Me.CB_BOOKLAND_ENABLE)
        Me.Controls.Add(Me.CB_EAN13_ENABLE)
        Me.Menu = Me.mainMenu1
        Me.Name = "FEAN13"
        Me.Text = "EAN-13"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents CB_EAN13_ENABLE As System.Windows.Forms.CheckBox
    Friend WithEvents CB_BOOKLAND_ENABLE As System.Windows.Forms.CheckBox
    Friend WithEvents CB_EAN13_XCD As System.Windows.Forms.CheckBox
    Friend WithEvents CB_EAN13_ADDON As System.Windows.Forms.CheckBox
    Friend WithEvents BTN_CANCEL As System.Windows.Forms.Button
    Friend WithEvents BTN_OK As System.Windows.Forms.Button
End Class
