﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class FUPCE
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Private mainMenu1 As System.Windows.Forms.MainMenu

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.BTN_CANCEL = New System.Windows.Forms.Button
        Me.BTN_OK = New System.Windows.Forms.Button
        Me.CB_UPCE_ENABLE = New System.Windows.Forms.CheckBox
        Me.CB_UPCE_XNUM = New System.Windows.Forms.CheckBox
        Me.CB_UPCE_XCD = New System.Windows.Forms.CheckBox
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.RD_UPCE_AS_EAN13 = New System.Windows.Forms.RadioButton
        Me.RD_UPCE_AS_UPCA = New System.Windows.Forms.RadioButton
        Me.RD_UPCE_NOCON = New System.Windows.Forms.RadioButton
        Me.Label1 = New System.Windows.Forms.Label
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'BTN_CANCEL
        '
        Me.BTN_CANCEL.Location = New System.Drawing.Point(128, 209)
        Me.BTN_CANCEL.Name = "BTN_CANCEL"
        Me.BTN_CANCEL.Size = New System.Drawing.Size(93, 35)
        Me.BTN_CANCEL.TabIndex = 8
        Me.BTN_CANCEL.Text = "CANCEL"
        '
        'BTN_OK
        '
        Me.BTN_OK.Location = New System.Drawing.Point(20, 209)
        Me.BTN_OK.Name = "BTN_OK"
        Me.BTN_OK.Size = New System.Drawing.Size(93, 35)
        Me.BTN_OK.TabIndex = 7
        Me.BTN_OK.Text = "OK"
        '
        'CB_UPCE_ENABLE
        '
        Me.CB_UPCE_ENABLE.Location = New System.Drawing.Point(36, 11)
        Me.CB_UPCE_ENABLE.Name = "CB_UPCE_ENABLE"
        Me.CB_UPCE_ENABLE.Size = New System.Drawing.Size(173, 20)
        Me.CB_UPCE_ENABLE.TabIndex = 9
        Me.CB_UPCE_ENABLE.Text = "Enable"
        '
        'CB_UPCE_XNUM
        '
        Me.CB_UPCE_XNUM.Location = New System.Drawing.Point(36, 37)
        Me.CB_UPCE_XNUM.Name = "CB_UPCE_XNUM"
        Me.CB_UPCE_XNUM.Size = New System.Drawing.Size(173, 20)
        Me.CB_UPCE_XNUM.TabIndex = 10
        Me.CB_UPCE_XNUM.Text = "Transmit Number System"
        '
        'CB_UPCE_XCD
        '
        Me.CB_UPCE_XCD.Location = New System.Drawing.Point(36, 63)
        Me.CB_UPCE_XCD.Name = "CB_UPCE_XCD"
        Me.CB_UPCE_XCD.Size = New System.Drawing.Size(173, 20)
        Me.CB_UPCE_XCD.TabIndex = 11
        Me.CB_UPCE_XCD.Text = "Transmit Check Digit"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Silver
        Me.Panel1.Controls.Add(Me.RD_UPCE_AS_EAN13)
        Me.Panel1.Controls.Add(Me.RD_UPCE_AS_UPCA)
        Me.Panel1.Controls.Add(Me.RD_UPCE_NOCON)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(20, 89)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(201, 101)
        '
        'RD_UPCE_AS_EAN13
        '
        Me.RD_UPCE_AS_EAN13.Location = New System.Drawing.Point(40, 73)
        Me.RD_UPCE_AS_EAN13.Name = "RD_UPCE_AS_EAN13"
        Me.RD_UPCE_AS_EAN13.Size = New System.Drawing.Size(120, 20)
        Me.RD_UPCE_AS_EAN13.TabIndex = 3
        Me.RD_UPCE_AS_EAN13.Text = "UPC-E as EAN-13"
        '
        'RD_UPCE_AS_UPCA
        '
        Me.RD_UPCE_AS_UPCA.Location = New System.Drawing.Point(40, 50)
        Me.RD_UPCE_AS_UPCA.Name = "RD_UPCE_AS_UPCA"
        Me.RD_UPCE_AS_UPCA.Size = New System.Drawing.Size(120, 20)
        Me.RD_UPCE_AS_UPCA.TabIndex = 2
        Me.RD_UPCE_AS_UPCA.Text = "UPC-E as UPC-A"
        '
        'RD_UPCE_NOCON
        '
        Me.RD_UPCE_NOCON.Location = New System.Drawing.Point(40, 26)
        Me.RD_UPCE_NOCON.Name = "RD_UPCE_NOCON"
        Me.RD_UPCE_NOCON.Size = New System.Drawing.Size(120, 20)
        Me.RD_UPCE_NOCON.TabIndex = 1
        Me.RD_UPCE_NOCON.Text = "No Convert"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Label1.Location = New System.Drawing.Point(54, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 20)
        Me.Label1.Text = "CONVERT"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'FUPCE
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(240, 268)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.CB_UPCE_XCD)
        Me.Controls.Add(Me.CB_UPCE_XNUM)
        Me.Controls.Add(Me.CB_UPCE_ENABLE)
        Me.Controls.Add(Me.BTN_CANCEL)
        Me.Controls.Add(Me.BTN_OK)
        Me.Menu = Me.mainMenu1
        Me.Name = "FUPCE"
        Me.Text = "UPC-E"
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents BTN_CANCEL As System.Windows.Forms.Button
    Friend WithEvents BTN_OK As System.Windows.Forms.Button
    Friend WithEvents CB_UPCE_ENABLE As System.Windows.Forms.CheckBox
    Friend WithEvents CB_UPCE_XNUM As System.Windows.Forms.CheckBox
    Friend WithEvents CB_UPCE_XCD As System.Windows.Forms.CheckBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents RD_UPCE_AS_UPCA As System.Windows.Forms.RadioButton
    Friend WithEvents RD_UPCE_NOCON As System.Windows.Forms.RadioButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents RD_UPCE_AS_EAN13 As System.Windows.Forms.RadioButton
End Class
