﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class FUPCA
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Private mainMenu1 As System.Windows.Forms.MainMenu

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.CB_UPCA_ENABLE = New System.Windows.Forms.CheckBox
        Me.CB_UPCA_XNUM = New System.Windows.Forms.CheckBox
        Me.CB_UPCA_XCD = New System.Windows.Forms.CheckBox
        Me.CB_UPCA_AS_EAN13 = New System.Windows.Forms.CheckBox
        Me.CB_UPCA_ADDON = New System.Windows.Forms.CheckBox
        Me.BTN_OK = New System.Windows.Forms.Button
        Me.BTN_CANCEL = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'CB_UPCA_ENABLE
        '
        Me.CB_UPCA_ENABLE.Location = New System.Drawing.Point(32, 28)
        Me.CB_UPCA_ENABLE.Name = "CB_UPCA_ENABLE"
        Me.CB_UPCA_ENABLE.Size = New System.Drawing.Size(178, 20)
        Me.CB_UPCA_ENABLE.TabIndex = 0
        Me.CB_UPCA_ENABLE.Text = "Enable"
        '
        'CB_UPCA_XNUM
        '
        Me.CB_UPCA_XNUM.Location = New System.Drawing.Point(32, 58)
        Me.CB_UPCA_XNUM.Name = "CB_UPCA_XNUM"
        Me.CB_UPCA_XNUM.Size = New System.Drawing.Size(178, 20)
        Me.CB_UPCA_XNUM.TabIndex = 1
        Me.CB_UPCA_XNUM.Text = "Transmit Number System"
        '
        'CB_UPCA_XCD
        '
        Me.CB_UPCA_XCD.Location = New System.Drawing.Point(32, 88)
        Me.CB_UPCA_XCD.Name = "CB_UPCA_XCD"
        Me.CB_UPCA_XCD.Size = New System.Drawing.Size(178, 20)
        Me.CB_UPCA_XCD.TabIndex = 2
        Me.CB_UPCA_XCD.Text = "Transmit Check Digit"
        '
        'CB_UPCA_AS_EAN13
        '
        Me.CB_UPCA_AS_EAN13.Location = New System.Drawing.Point(32, 118)
        Me.CB_UPCA_AS_EAN13.Name = "CB_UPCA_AS_EAN13"
        Me.CB_UPCA_AS_EAN13.Size = New System.Drawing.Size(178, 20)
        Me.CB_UPCA_AS_EAN13.TabIndex = 3
        Me.CB_UPCA_AS_EAN13.Text = "Convert UPC-A as EAN-13"
        '
        'CB_UPCA_ADDON
        '
        Me.CB_UPCA_ADDON.Location = New System.Drawing.Point(32, 148)
        Me.CB_UPCA_ADDON.Name = "CB_UPCA_ADDON"
        Me.CB_UPCA_ADDON.Size = New System.Drawing.Size(178, 20)
        Me.CB_UPCA_ADDON.TabIndex = 4
        Me.CB_UPCA_ADDON.Text = "Add On 2/5"
        '
        'BTN_OK
        '
        Me.BTN_OK.Location = New System.Drawing.Point(19, 209)
        Me.BTN_OK.Name = "BTN_OK"
        Me.BTN_OK.Size = New System.Drawing.Size(93, 35)
        Me.BTN_OK.TabIndex = 5
        Me.BTN_OK.Text = "OK"
        '
        'BTN_CANCEL
        '
        Me.BTN_CANCEL.Location = New System.Drawing.Point(127, 209)
        Me.BTN_CANCEL.Name = "BTN_CANCEL"
        Me.BTN_CANCEL.Size = New System.Drawing.Size(93, 35)
        Me.BTN_CANCEL.TabIndex = 6
        Me.BTN_CANCEL.Text = "CANCEL"
        '
        'FUPCA
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(240, 268)
        Me.Controls.Add(Me.BTN_CANCEL)
        Me.Controls.Add(Me.BTN_OK)
        Me.Controls.Add(Me.CB_UPCA_ADDON)
        Me.Controls.Add(Me.CB_UPCA_AS_EAN13)
        Me.Controls.Add(Me.CB_UPCA_XCD)
        Me.Controls.Add(Me.CB_UPCA_XNUM)
        Me.Controls.Add(Me.CB_UPCA_ENABLE)
        Me.Menu = Me.mainMenu1
        Me.Name = "FUPCA"
        Me.Text = "UPC-A"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents CB_UPCA_ENABLE As System.Windows.Forms.CheckBox
    Friend WithEvents CB_UPCA_XNUM As System.Windows.Forms.CheckBox
    Friend WithEvents CB_UPCA_XCD As System.Windows.Forms.CheckBox
    Friend WithEvents CB_UPCA_AS_EAN13 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_UPCA_ADDON As System.Windows.Forms.CheckBox
    Friend WithEvents BTN_OK As System.Windows.Forms.Button
    Friend WithEvents BTN_CANCEL As System.Windows.Forms.Button
End Class
