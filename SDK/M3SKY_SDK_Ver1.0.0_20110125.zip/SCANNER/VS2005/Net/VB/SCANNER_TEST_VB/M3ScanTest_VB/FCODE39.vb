﻿Public Class FCODE39
    Public m_bEnable As Boolean
    Public m_bCode32 As Boolean
    Public m_bPzn As Boolean
    Public m_bCDV As Boolean
    Public m_bXCD As Boolean
    Public m_bFullASCII As Boolean
    Public m_nMinLen As Integer
    Public m_nMaxLen As Integer

    Private Sub FCODE39_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CB_CODE39_ENABLE.Checked = m_bEnable
        CB_CODE32_ENABLE.Checked = m_bCode32
        CB_PZN_ENABLE.Checked = m_bPzn
        CB_CODE39_CDV.Checked = m_bCDV
        CB_CODE39_XCD.Checked = m_bXCD
        CB_CODE39_FULLASCII.Checked = m_bFullASCII

        TEXT_MINLEN.Text = m_nMinLen.ToString()
        TEXT_MAXLEN.Text = m_nMaxLen.ToString()
    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click
        m_bEnable = CB_CODE39_ENABLE.Checked
        m_bCode32 = CB_CODE32_ENABLE.Checked
        m_bPzn = CB_PZN_ENABLE.Checked
        m_bCDV = CB_CODE39_CDV.Checked
        m_bXCD = CB_CODE39_XCD.Checked
        m_bFullASCII = CB_CODE39_FULLASCII.Checked

        m_nMinLen = Int32.Parse(TEXT_MINLEN.Text)
        m_nMaxLen = Int32.Parse(TEXT_MAXLEN.Text)

        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class