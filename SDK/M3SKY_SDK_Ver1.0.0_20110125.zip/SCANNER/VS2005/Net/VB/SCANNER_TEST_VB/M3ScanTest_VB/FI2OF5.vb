﻿Public Class FI2OF5
    Public m_bEnable As Boolean
    Public m_bItf14 As Boolean
    Public m_bMatrix2of5 As Boolean
    Public m_bDlogic As Boolean
    Public m_bIndustry As Boolean
    Public m_bIata As Boolean
    Public m_bCDV As Boolean
    Public m_bXCD As Boolean
    Public m_nMinLen As Integer
    Public m_nMaxLen As Integer

    Private Sub FI2OF5_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CB_I2OF5_ENABLE.Checked = m_bEnable
        CB_ITF14_ENABLE.Checked = m_bItf14
        CB_MATRIX2OF5_ENABLE.Checked = m_bMatrix2of5
        CB_DLOGIC_ENABLE.Checked = m_bDlogic
        CB_INDUSTRY_ENABLE.Checked = m_bIndustry
        CB_IATA_ENABLE.Checked = m_bIata
        CB_I2OF5_CDV.Checked = m_bCDV
        CB_I2OF5_XCD.Checked = m_bXCD

        TEXT_MINLEN.Text = m_nMinLen.ToString()
        TEXT_MAXLEN.Text = m_nMaxLen.ToString()
    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click
        m_bEnable = CB_I2OF5_ENABLE.Checked
        m_bItf14 = CB_ITF14_ENABLE.Checked
        m_bMatrix2of5 = CB_MATRIX2OF5_ENABLE.Checked
        m_bDlogic = CB_DLOGIC_ENABLE.Checked
        m_bIndustry = CB_INDUSTRY_ENABLE.Checked
        m_bIata = CB_IATA_ENABLE.Checked
        m_bCDV = CB_I2OF5_CDV.Checked
        m_bXCD = CB_I2OF5_XCD.Checked

        m_nMinLen = Int32.Parse(TEXT_MINLEN.Text)
        m_nMaxLen = Int32.Parse(TEXT_MAXLEN.Text)

        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class