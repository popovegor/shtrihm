﻿Public Class FTELEPEN
    Public m_bEnable As Boolean
    Public m_bOldStyle As Boolean
    Private Sub FTELEPEN_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CB_TELEPEN_ENABLE.Checked = m_bEnable
        CB_TELEPEN_OLDSTYLE.Checked = m_bOldStyle
    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click
        m_bEnable = CB_TELEPEN_ENABLE.Checked
        m_bOldStyle = CB_TELEPEN_OLDSTYLE.Checked

        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class