﻿Public Class FUPCA
    Public m_bEnable As Boolean
    Public m_bXNum As Boolean
    Public m_bXCD As Boolean
    Public m_bUPCAasEAN13 As Boolean
    Public m_bAddOn As Boolean

    Private Sub FUPCA_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CB_UPCA_ENABLE.Checked = m_bEnable
        CB_UPCA_XNUM.Checked = m_bXNum
        CB_UPCA_XCD.Checked = m_bXCD
        CB_UPCA_AS_EAN13.Checked = m_bUPCAasEAN13
        CB_UPCA_ADDON.Checked = m_bAddOn
    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click
        m_bEnable = CB_UPCA_ENABLE.Checked
        m_bXNum = CB_UPCA_XNUM.Checked
        m_bXCD = CB_UPCA_XCD.Checked
        m_bUPCAasEAN13 = CB_UPCA_AS_EAN13.Checked
        m_bAddOn = CB_UPCA_ADDON.Checked

        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class