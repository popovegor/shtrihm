﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class FCODE35
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Private mainMenu1 As System.Windows.Forms.MainMenu

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.BTN_CANCEL = New System.Windows.Forms.Button
        Me.BTN_OK = New System.Windows.Forms.Button
        Me.CB_CODE35_ENABLE = New System.Windows.Forms.CheckBox
        Me.SuspendLayout()
        '
        'BTN_CANCEL
        '
        Me.BTN_CANCEL.Location = New System.Drawing.Point(128, 209)
        Me.BTN_CANCEL.Name = "BTN_CANCEL"
        Me.BTN_CANCEL.Size = New System.Drawing.Size(93, 35)
        Me.BTN_CANCEL.TabIndex = 10
        Me.BTN_CANCEL.Text = "CANCEL"
        '
        'BTN_OK
        '
        Me.BTN_OK.Location = New System.Drawing.Point(20, 209)
        Me.BTN_OK.Name = "BTN_OK"
        Me.BTN_OK.Size = New System.Drawing.Size(93, 35)
        Me.BTN_OK.TabIndex = 9
        Me.BTN_OK.Text = "OK"
        '
        'CB_CODE35_ENABLE
        '
        Me.CB_CODE35_ENABLE.Location = New System.Drawing.Point(84, 98)
        Me.CB_CODE35_ENABLE.Name = "CB_CODE35_ENABLE"
        Me.CB_CODE35_ENABLE.Size = New System.Drawing.Size(73, 20)
        Me.CB_CODE35_ENABLE.TabIndex = 11
        Me.CB_CODE35_ENABLE.Text = "Enable"
        '
        'FCODE35
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(240, 268)
        Me.Controls.Add(Me.CB_CODE35_ENABLE)
        Me.Controls.Add(Me.BTN_CANCEL)
        Me.Controls.Add(Me.BTN_OK)
        Me.Menu = Me.mainMenu1
        Me.Name = "FCODE35"
        Me.Text = "CODE35"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents BTN_CANCEL As System.Windows.Forms.Button
    Friend WithEvents BTN_OK As System.Windows.Forms.Button
    Friend WithEvents CB_CODE35_ENABLE As System.Windows.Forms.CheckBox
End Class
