﻿/********************************************************************
created		:	2009/09/20
file base	: 	M3ScanTest_Net.exe

file ext	:	cpp
author		:	Dong-Hyun, Eum(vision7901) - Applied Development Team

purpose		:	M3 SKY / MM3
Report		:	2009. 03. 25 [03/25/2009 vision7901] v1.0.0 - 버전관리 시작				
				2010. 03. 17 [03/17/2010 vision7901] v2.0.0 - Main Page/ Symbology Page/ Option Page로 구분/ GS1 바코드 추가
                2010. 04. 30 [04/30/2010 vision7901] v3.0.0 - BarCode 세부 옵션 적용
                2010. 11. 19 [11/19/2010 vision7901] v3.1.0 - 버튼을 눌렀을 때 스캔버튼이 동작안되는 이슈 수정(TabFocus 추가)
*********************************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;   // DllImport
using Microsoft.Win32;                  // Registry
using System.Threading;                 // Sleep
using KScanbarNet;                      // KScanBarNet

namespace M3ScanTest_Net
{
    public partial class M3Scanner : Form
    {
        private KScanbarNet.ScannerControl  ScanCtrl;
        private KScanbarNet.MCBarCodeType   M3BarCodeType;
        private KScanbarNet.MCModuleOption  M3ModuleOption;
        private KScanbarNet.MCReadOption    M3ReadOption;

        private KScanbarNet.MCBarOption_UPCA pUpca;
        private KScanbarNet.MCBarOption_UPCE pUpce;
        private KScanbarNet.MCBarOption_EAN13 pEan13;
        private KScanbarNet.MCBarOption_EAN8 pEan8;
        private KScanbarNet.MCBarOption_CODE39 pCode39;
        private KScanbarNet.MCBarOption_CODE128 pCode128;
        private KScanbarNet.MCBarOption_CODE93 pCode93;
        private KScanbarNet.MCBarOption_CODE35 pCode35;
        private KScanbarNet.MCBarOption_CODE11 pCode11;
        private KScanbarNet.MCBarOption_I2OF5 pI2of5;
        private KScanbarNet.MCBarOption_CODABAR pCodabar;
        private KScanbarNet.MCBarOption_MSI pMsi;
        private KScanbarNet.MCBarOption_PLESSEY pPlessey;
        private KScanbarNet.MCBarOption_GS1 pGs1;
        private KScanbarNet.MCBarOption_TELEPEN pTelepen;        

        // Barcode
        public bool m_bUpca;
        public bool m_bUpce;
        public bool m_bEan13;
        public bool m_bBookland;
        public bool m_bEan8;
        public bool m_bCode39;
        public bool m_bCode32;
        public bool m_bPzn;
        public bool m_bCode128;
        public bool m_bUccean128;
        public bool m_bCode93;
        public bool m_bCode35;
        public bool m_bCode11;
        public bool m_bI2of5;
        public bool m_bMsi;
        public bool m_bPlessey;
        public bool m_bCodabar;
        public bool m_bGs1;
        public bool m_bGs1Lim;
        public bool m_bGs1Exp;

        // Flag
        public bool m_bReading;
        public bool m_bKeyFlag;
        public bool m_bSyncMode;
        public bool m_bContinue;
        public bool m_bResult;

        public M3Scanner()
        {
            InitializeComponent();

            ScanCtrl        = new ScannerControl();
            M3BarCodeType   = new MCBarCodeType();
            M3ModuleOption  = new MCModuleOption();
            M3ReadOption    = new MCReadOption();

            ScanCtrl.ScannerDataEvent += new ScannerDataDelegate(OnScanRead);

            // SideKey Setting
            RegistryKey rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\KeyPad\\SideKey", true);
            if (rk == null)
            {
                rk = Registry.LocalMachine.CreateSubKey("ControlPanel\\KeyPad\\SideKey");
            }
            else
            {
                rk.SetValue("RightDownKey", 3);
            }

            // Scanner Open
            ScanCtrl.ScanOpen();
        }

        private void M3Scanner_Load(object sender, EventArgs e)
        {
            m_bReading  = false;
            m_bKeyFlag  = false;
            m_bSyncMode = false;
            m_bContinue = false;
            m_bResult   = false;

            ScanCtrl.GetBarCode_Type(out M3BarCodeType);

            m_bUpca = M3BarCodeType.bMC_UPCA;            
            m_bUpce = M3BarCodeType.bMC_UPCE;
            m_bEan13 = M3BarCodeType.bMC_EAN13;
            m_bBookland = M3BarCodeType.bMC_BOOKLAND;
            m_bEan8 = M3BarCodeType.bMC_EAN8;
            m_bCode39 = M3BarCodeType.bMC_CODE39;
            m_bCode32 = M3BarCodeType.bMC_CODE32;
            m_bPzn = M3BarCodeType.bMC_PZN;
            m_bCode128 = M3BarCodeType.bMC_CODE128;
            m_bUccean128 = M3BarCodeType.bMC_UCCEAN128;
            m_bCode93 = M3BarCodeType.bMC_CODE93;
            m_bCode35 = M3BarCodeType.bMC_CODE35;
            m_bCode11 = M3BarCodeType.bMC_CODE11;
            m_bI2of5 = M3BarCodeType.bMC_I2OF5;
            m_bMsi = M3BarCodeType.bMC_MSI;
            m_bPlessey = M3BarCodeType.bMC_PLESSEY;
            m_bCodabar = M3BarCodeType.bMC_CODABAR;
            m_bGs1 = M3BarCodeType.bMC_GS1;
            m_bGs1Lim = M3BarCodeType.bMC_GS1_LIMITED;
            m_bGs1Exp = M3BarCodeType.bMC_GS1_EXPANDED;

            Tab_M3Scanner.Focus();
        }

        public void ScanRead()
        {
            if (m_bReading == true)
            {
                ScanCtrl.ScanReadCancel();
                m_bReading = false;
                return;
            }            

            if (m_bContinue == false)
                m_bReading = false;
            else
                m_bReading = true;

            ScanCtrl.ScanRead();
        }

        public void OnScanRead(object sender, ScannerDataArgs e)
        {
            if (LV_ScanData.Items.Count > 7)
                LV_ScanData.Items.Clear();

            if (e.ScanData != "")
            {                
                ListViewItem ScanData = new ListViewItem();
                ScanData.Text = e.ScanType;
                ScanData.SubItems.Add(e.ScanData);

                LV_ScanData.Items.Add(ScanData);

                PlaySound("\\windows\\Alarm1.wav", 0, (int)(SND.SND_ASYNC | SND.SND_FILENAME));
            }

            if (m_bContinue == false)
                m_bReading = false;            
        }

        

        private void Tab_M3Scanner_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == System.Windows.Forms.Keys.F14)
            {
                if (m_bKeyFlag == false)
                {
                    m_bKeyFlag = true;
                    ScanRead();
                    Thread.Sleep(10);
                }
            }
        }

        private void Tab_M3Scanner_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == System.Windows.Forms.Keys.F14)
            {
                if (m_bKeyFlag == true)
                {
                    m_bKeyFlag = false;
                    if (m_bSyncMode == false)
                    {
                        ScanCtrl.ScanReadCancel();
                        Thread.Sleep(10);
                        m_bReading = false;
                    }

                }
            }
        }

        private void M3Scanner_Closing(object sender, CancelEventArgs e)
        {
            for (int i = 0; i < 3; i++)
            {
                m_bResult = ScanCtrl.ScanClose();
                Thread.Sleep(300);
                if (m_bResult == true)
                    break;
            }
        }

        private void Btn_Scan_Click(object sender, EventArgs e)
        {
            ScanCtrl.ScanRead();
            Tab_M3Scanner.Focus();
        }

        private void Btn_ScanCancel_Click(object sender, EventArgs e)
        {
            ScanCtrl.ScanReadCancel();
            Tab_M3Scanner.Focus();
        }

        private void Btn_Info_Click(object sender, EventArgs e)
        {
            String strVerInfo = ScanCtrl.GetVersion();
            MessageBox.Show(strVerInfo);

            Tab_M3Scanner.Focus();
        }

        private void Btn_Close_Click(object sender, EventArgs e)
        {
            // Scanner Close
            for (int i = 0; i < 3; i++)
            {
                m_bResult = ScanCtrl.ScanClose();
                Thread.Sleep(300);
                if (m_bResult == true)
                    break;
            }

            // SideKey 
            RegistryKey rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\KeyPad\\SideKey", true);
            if (rk == null)
            {
                rk = Registry.LocalMachine.CreateSubKey("ControlPanel\\KeyPad\\SideKey");
            }
            else
            {
                rk.SetValue("RightDownKey", 0);
            }

            Close();

            Application.Exit();
        }

        private void Tab_M3Scanner_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (Tab_M3Scanner.SelectedIndex)
            {
                case 0:
                    Tab_M3Scanner.Focus();
                    break;
                case 1:
                    ScanCtrl.ScanReadCancel();

                    CB_UPCA.Checked = m_bUpca;
                    CB_UPCE.Checked = m_bUpce;
                    CB_EAN13.Checked = m_bEan13;
                    CB_BOOKLAND.Checked = m_bBookland;
                    CB_EAN8.Checked = m_bEan8;
                    CB_CODE39.Checked = m_bCode39;
                    CB_CODE32.Checked = m_bCode32;
                    CB_PZN.Checked = m_bPzn;
                    CB_CODE128.Checked = m_bCode128;
                    CB_UCCEAN128.Checked = m_bUccean128;
                    CB_CODE93.Checked = m_bCode93;
                    CB_CODE35.Checked = m_bCode35;
                    CB_CODE11.Checked = m_bCode11;
                    CB_I2OF5.Checked = m_bI2of5;
                    CB_MSI.Checked = m_bMsi;
                    CB_PLESSEY.Checked = m_bPlessey;
                    CB_CODABAR.Checked = m_bCodabar;
                    CB_GS1.Checked = m_bGs1;
                    CB_GS1LIM.Checked = m_bGs1Lim;
                    CB_GS1EXP.Checked = m_bGs1Exp;
                    break;
                    
                case 2:
                    ScanCtrl.ScanReadCancel();
                    ScanCtrl.GetRead_Option(out M3ReadOption);
                    ScanCtrl.GetModule_Option(out M3ModuleOption);

                    switch (M3ModuleOption.nMC_TimeOutSec)
                    {
                        case 1:
                            CB_TIMEOUT.Text = "1";
                            break;
                        case 2:
                            CB_TIMEOUT.Text = "2";
                            break;
                        case 3:
                            CB_TIMEOUT.Text = "3";
                            break;
                        case 4:
                            CB_TIMEOUT.Text = "4";
                            break;
                        case 5:
                            CB_TIMEOUT.Text = "5";
                            break;
                        case 6:
                            CB_TIMEOUT.Text = "6";
                            break;
                        case 7:
                            CB_TIMEOUT.Text = "7";
                            break;
                        case 8:
                            CB_TIMEOUT.Text = "8";
                            break;
                        case 9:
                            CB_TIMEOUT.Text = "9";
                            break;
                        case 10:
                            CB_TIMEOUT.Text = "10";
                            break;
                    }

                    switch(M3ModuleOption.nMC_SecurityLevel)
                    {
                        case 1:
                            CB_SECLEVEL.Text = "1";
                            break;
                        case 2:
                            CB_SECLEVEL.Text = "2";
                            break;
                        case 3:
                            CB_SECLEVEL.Text = "3";
                            break;
                        case 4:
                            CB_SECLEVEL.Text = "4";
                            break;
                    }

                    if (m_bSyncMode == true)
                        RD_SYNC.Checked = true;
                    else
                        RD_ASYNC.Checked = true;

                    if (m_bContinue == true)
                        RD_CON.Checked = true;
                    else
                        RD_NOCON.Checked = true;

                    CB_WIDESCAN.Checked     = M3ReadOption.bMC_WIDESCANANGLE;
                    CB_HIGHFILTER.Checked   = M3ReadOption.bMC_HIGHFILTERMODE;
                    CB_AIMID.Checked        = ScanCtrl.Get_TransmitAimID();
                    break;    
                
                case 3:
                    ScanCtrl.ScanReadCancel();
                    break;
            }   
        }

        private void Btn_SymConfirm_Click(object sender, EventArgs e)
        {
            M3BarCodeType.bMC_UPCA = m_bUpca = CB_UPCA.Checked;
            M3BarCodeType.bMC_UPCE = m_bUpce = CB_UPCE.Checked;
            M3BarCodeType.bMC_EAN13 = m_bEan13 = CB_EAN13.Checked;
            M3BarCodeType.bMC_BOOKLAND = m_bBookland = CB_BOOKLAND.Checked;
            M3BarCodeType.bMC_EAN8 = m_bEan8 = CB_EAN8.Checked;
            M3BarCodeType.bMC_CODE39 = m_bCode39 = CB_CODE39.Checked;
            M3BarCodeType.bMC_CODE32 = m_bCode32 = CB_CODE32.Checked;
            M3BarCodeType.bMC_PZN = m_bPzn = CB_PZN.Checked;
            M3BarCodeType.bMC_CODE128 = m_bCode128 = CB_CODE128.Checked;
            M3BarCodeType.bMC_UCCEAN128 = m_bUccean128 = CB_UCCEAN128.Checked;
            M3BarCodeType.bMC_CODE93 = m_bCode93 = CB_CODE93.Checked;
            M3BarCodeType.bMC_CODE35 = m_bCode35 = CB_CODE35.Checked;
            M3BarCodeType.bMC_CODE11 = m_bCode11 = CB_CODE11.Checked;
            M3BarCodeType.bMC_I2OF5 = m_bI2of5 = CB_I2OF5.Checked;
            M3BarCodeType.bMC_MSI = m_bMsi = CB_MSI.Checked;
            M3BarCodeType.bMC_PLESSEY = m_bPlessey = CB_PLESSEY.Checked;
            M3BarCodeType.bMC_CODABAR = m_bCodabar = CB_CODABAR.Checked;
            M3BarCodeType.bMC_GS1 = m_bGs1 = CB_GS1.Checked;
            M3BarCodeType.bMC_GS1_LIMITED = m_bGs1Lim = CB_GS1LIM.Checked;
            M3BarCodeType.bMC_GS1_EXPANDED = m_bGs1Exp = CB_GS1EXP.Checked;

            ScanCtrl.SetBarCode_Type(ref M3BarCodeType);
            Tab_M3Scanner.SelectedIndex = 0;
            Tab_M3Scanner.Focus();
        }

        private void Btn_SymCancel_Click(object sender, EventArgs e)
        {
            Tab_M3Scanner.SelectedIndex = 0;
            Tab_M3Scanner.Focus();
        }

        private void Btn_OpConfirm_Click(object sender, EventArgs e)
        {
            if (RD_ASYNC.Checked == true)
                m_bSyncMode = false;
            else
                m_bSyncMode = true;

            if (RD_NOCON.Checked == true)
            {
                ScanCtrl.SetScan_Continue(0, false);
                m_bContinue = false;
            }
            else
            {
                ScanCtrl.SetScan_Continue(1, true);
                m_bContinue = true;
            }

            M3ModuleOption.nMC_TimeOutSec = CB_TIMEOUT.SelectedIndex + 1;
            M3ModuleOption.nMC_SecurityLevel = CB_SECLEVEL.SelectedIndex + 1;

            M3ReadOption.bMC_WIDESCANANGLE = CB_WIDESCAN.Checked;
            M3ReadOption.bMC_HIGHFILTERMODE = CB_HIGHFILTER.Checked;
            
            ScanCtrl.SetModule_Option(ref M3ModuleOption);
            ScanCtrl.SetRead_Option(ref M3ReadOption);
            ScanCtrl.Set_TransmitAimID(CB_AIMID.Checked);


            Tab_M3Scanner.SelectedIndex = 0;
            Tab_M3Scanner.Focus();
        }

        private void Btn_OpCancel_Click(object sender, EventArgs e)
        {
            Tab_M3Scanner.SelectedIndex = 0;
            Tab_M3Scanner.Focus();
        }

        private void BTN_DECANCEL_Click(object sender, EventArgs e)
        {
            Tab_M3Scanner.SelectedIndex = 0;
            Tab_M3Scanner.Focus();
        }

        private void BTN_UPCA_Click(object sender, EventArgs e)
        {            
            FUPCA UpcaDlg;
            UpcaDlg = new FUPCA();

            pUpca = new MCBarOption_UPCA();  

            ScanCtrl.GetBarOptionUPCA(out pUpca);
 
            UpcaDlg.m_bEnable= pUpca.bMC_UPCA_Enable;
            UpcaDlg.m_bXNum = pUpca.bMC_UPCA_XNum;
            UpcaDlg.m_bXCD = pUpca.bMC_UPCA_XCD;
            UpcaDlg.m_bUPCAasEAN13= pUpca.bMC_UPCA_AS_EAN13;
            UpcaDlg.m_bAddOn= pUpca.bMC_UPCA_AddOn;

            if(UpcaDlg.ShowDialog() == DialogResult.OK)
            {
                pUpca.bMC_UPCA_Enable = m_bUpca = UpcaDlg.m_bEnable;
                pUpca.bMC_UPCA_XNum = UpcaDlg.m_bXNum;
                pUpca.bMC_UPCA_XCD = UpcaDlg.m_bXCD;
                pUpca.bMC_UPCA_AS_EAN13 = UpcaDlg.m_bUPCAasEAN13;
                pUpca.bMC_UPCA_AddOn = UpcaDlg.m_bAddOn;                

                ScanCtrl.SetBarOptionUPCA(ref pUpca);
            }
        }

        private void BTN_UPCE_Click(object sender, EventArgs e)
        {
            FUPCE UpceDlg;
            UpceDlg = new FUPCE();

            pUpce = new MCBarOption_UPCE();

            ScanCtrl.GetBarOptionUPCE(out pUpce);

            UpceDlg.m_bEnable   = pUpce.bMC_UPCE_Enable;
            UpceDlg.m_bXNum     = pUpce.bMC_UPCE_XNum;
            UpceDlg.m_bXCD      = pUpce.bMC_UPCE_XCD;
            UpceDlg.m_nConvert  = pUpce.nMC_UPCE_Convert;

            if (UpceDlg.ShowDialog() == DialogResult.OK) 
            {
                pUpce.bMC_UPCE_Enable = m_bUpce = UpceDlg.m_bEnable;
                pUpce.bMC_UPCE_XNum = UpceDlg.m_bXNum;
                pUpce.bMC_UPCE_XCD = UpceDlg.m_bXCD;
                pUpce.nMC_UPCE_Convert = UpceDlg.m_nConvert;

                ScanCtrl.SetBarOptionUPCE(ref pUpce);

            }
        }

        private void BTN_EAN13_Click(object sender, EventArgs e)
        {
            FEAN13 Ean13Dlg;
            Ean13Dlg = new FEAN13();

            pEan13 = new MCBarOption_EAN13();

            ScanCtrl.GetBarOptionEAN13(out pEan13);

            Ean13Dlg.m_bEnable = pEan13.bMC_EAN13_Enable;
            Ean13Dlg.m_bBookland = pEan13.bMC_BOOKLAND_Enable;
            Ean13Dlg.m_bXCD = pEan13.bMC_EAN13_XCD;
            Ean13Dlg.m_bAddOn = pEan13.bMC_EAN13_AddOn;

            if(Ean13Dlg.ShowDialog() == DialogResult.OK)
            {
                pEan13.bMC_EAN13_Enable = m_bEan13 = Ean13Dlg.m_bEnable;
                pEan13.bMC_BOOKLAND_Enable = m_bBookland = Ean13Dlg.m_bBookland;
                pEan13.bMC_EAN13_XCD = Ean13Dlg.m_bXCD;
                pEan13.bMC_EAN13_AddOn = Ean13Dlg.m_bAddOn;

                ScanCtrl.SetBarOptionEAN13(ref pEan13);
            }
        }

        private void BTN_EAN8_Click(object sender, EventArgs e)
        {
            FEAN8 Ean8Dlg;
            Ean8Dlg = new FEAN8();

            pEan8 = new MCBarOption_EAN8();

            ScanCtrl.GetBarOptionEAN8(out pEan8);

            Ean8Dlg.m_bEnable = pEan8.bMC_EAN8_Enable;
            Ean8Dlg.m_bXCD = pEan8.bMC_EAN8_XCD;
            Ean8Dlg.m_bEAN8asEAN13 = pEan8.nMC_EAN8_AS_EAN13;

            if(Ean8Dlg.ShowDialog() == DialogResult.OK)
            {
                pEan8.bMC_EAN8_Enable = m_bEan8 = Ean8Dlg.m_bEnable;
                pEan8.bMC_EAN8_XCD = Ean8Dlg.m_bXCD;
                pEan8.nMC_EAN8_AS_EAN13 = Ean8Dlg.m_bEAN8asEAN13;

                ScanCtrl.SetBarOptionEAN8(ref pEan8);
            }
        }

        private void BTN_CODE39_Click(object sender, EventArgs e)
        {
            FCODE39 Code39Dlg;
            Code39Dlg = new FCODE39();

            pCode39 = new MCBarOption_CODE39();

            ScanCtrl.GetBarOptionCODE39(out pCode39);

            Code39Dlg.m_bEnable = pCode39.bMC_CODE39_Enable;
            Code39Dlg.m_bCode32 = pCode39.bMC_CODE32_Enable;
            Code39Dlg.m_bPzn = pCode39.bMC_PZN_Enable;
            Code39Dlg.m_bCDV = pCode39.bMC_CODE39_CDV;
            Code39Dlg.m_bXCD = pCode39.bMC_CODE39_XCD;
            Code39Dlg.m_bFullASCII = pCode39.bMC_CODE39_FullASCII;
            Code39Dlg.m_nMinLen = pCode39.nMC_CODE39_MinLen;
            Code39Dlg.m_nMaxLen = pCode39.nMC_CODE39_MaxLen;

            if (Code39Dlg.ShowDialog() == DialogResult.OK)
            {
                pCode39.bMC_CODE39_Enable = m_bCode39 = Code39Dlg.m_bEnable;
                pCode39.bMC_CODE32_Enable = m_bCode32 = Code39Dlg.m_bCode32;
                pCode39.bMC_PZN_Enable = m_bPzn = Code39Dlg.m_bPzn;
                pCode39.bMC_CODE39_CDV = Code39Dlg.m_bCDV;
                pCode39.bMC_CODE39_XCD = Code39Dlg.m_bXCD;
                pCode39.bMC_CODE39_FullASCII = Code39Dlg.m_bFullASCII;
                pCode39.nMC_CODE39_MinLen = Code39Dlg.m_nMinLen;
                pCode39.nMC_CODE39_MaxLen = Code39Dlg.m_nMaxLen;

                ScanCtrl.SetBarOptionCODE39(ref pCode39);
            }
        }

        private void BTN_CODE128_Click(object sender, EventArgs e)
        {
            FCODE128 Code128Dlg;
            Code128Dlg = new FCODE128();

            pCode128 = new MCBarOption_CODE128();

            ScanCtrl.GetBarOptionCODE128(out pCode128);

            Code128Dlg.m_bEnable = pCode128.bMC_CODE128_Enable;
            Code128Dlg.m_bUccean128 = pCode128.bMC_UCCEAN128_Enable;
            Code128Dlg.m_nMinLen = pCode128.nMC_CODE128_MinLen;
            Code128Dlg.m_nMaxLen = pCode128.nMC_CODE128_MaxLen;

            if(Code128Dlg.ShowDialog() == DialogResult.OK)
            {
                pCode128.bMC_CODE128_Enable = m_bCode128 = Code128Dlg.m_bEnable;
                pCode128.bMC_UCCEAN128_Enable = m_bUccean128 = Code128Dlg.m_bUccean128;
                pCode128.nMC_CODE128_MinLen = Code128Dlg.m_nMinLen;
                pCode128.nMC_CODE128_MaxLen = Code128Dlg.m_nMaxLen;

                ScanCtrl.SetBarOptionCODE128(ref pCode128);
            }
        }

        private void BTN_CODE93_Click(object sender, EventArgs e)
        {
            FCODE93 Code93Dlg;
            Code93Dlg = new FCODE93();

            pCode93 = new MCBarOption_CODE93();

            ScanCtrl.GetBarOptionCODE93(out pCode93);

            Code93Dlg.m_bEnable = pCode93.bMC_CODE93_Enable;
            Code93Dlg.m_nMinLen = pCode93.nMC_CODE93_MinLen;
            Code93Dlg.m_nMaxLen = pCode93.nMC_CODE93_MaxLen;

            if(Code93Dlg.ShowDialog() == DialogResult.OK)
            {
                pCode93.bMC_CODE93_Enable = m_bCode93 = Code93Dlg.m_bEnable;
                pCode93.nMC_CODE93_MinLen = Code93Dlg.m_nMinLen;
                pCode93.nMC_CODE93_MaxLen = Code93Dlg.m_nMaxLen;

                ScanCtrl.SetBarOptionCODE93(ref pCode93);
            }
        }

        private void BTN_CODE35_Click(object sender, EventArgs e)
        {
            FCODE35 Code35Dlg;
            Code35Dlg = new FCODE35();

            pCode35 = new MCBarOption_CODE35();

            ScanCtrl.GetBarOptionCODE35(out pCode35);

            Code35Dlg.m_bEnable = pCode35.bMC_CODE35_Enable;

            if(Code35Dlg.ShowDialog() == DialogResult.OK)
            {
                pCode35.bMC_CODE35_Enable = m_bCode35 = Code35Dlg.m_bEnable;

                ScanCtrl.SetBarOptionCODE35(ref pCode35);
            }
        }

        private void BTN_CODE11_Click(object sender, EventArgs e)
        {
            FCODE11 Code11Dlg;
            Code11Dlg = new FCODE11();

            pCode11 = new MCBarOption_CODE11();

            ScanCtrl.GetBarOptionCODE11(out pCode11);

            Code11Dlg.m_bEnable = pCode11.bMC_CODE11_Enable;
            Code11Dlg.m_bXCD = pCode11.bMC_CODE11_XCD;
            Code11Dlg.m_nCDV = pCode11.nMC_CODE11_CDV;
            Code11Dlg.m_nMinLen = pCode11.nMC_CODE11_MinLen;
            Code11Dlg.m_nMaxLen = pCode11.nMC_CODE11_MaxLen;

            if(Code11Dlg.ShowDialog() == DialogResult.OK)
            {
                pCode11.bMC_CODE11_Enable = m_bCode11 = Code11Dlg.m_bEnable;
                pCode11.bMC_CODE11_XCD = Code11Dlg.m_bXCD;
                pCode11.nMC_CODE11_CDV = Code11Dlg.m_nCDV;
                pCode11.nMC_CODE11_MinLen = Code11Dlg.m_nMinLen;
                pCode11.nMC_CODE11_MaxLen = Code11Dlg.m_nMaxLen;

                ScanCtrl.SetBarOptionCODE11(ref pCode11);
            }
        }

        private void BTN_I2OF5_Click(object sender, EventArgs e)
        {
            FI2OF5 I2of5Dlg;
            I2of5Dlg = new FI2OF5();

            pI2of5 = new MCBarOption_I2OF5();

            ScanCtrl.GetBarOptionI2OF5(out pI2of5);

            I2of5Dlg.m_bEnable = pI2of5.bMC_I2OF5_Enable;
            I2of5Dlg.m_bItf14 = pI2of5.bMC_ITF14_Enable;
            I2of5Dlg.m_bMatrix2of5 = pI2of5.bMC_MATRIX2OF5_Enable;
            I2of5Dlg.m_bDlogic = pI2of5.bMC_DLOGIG_Enable;
            I2of5Dlg.m_bIndustry = pI2of5.bMC_INDUSTRY_Enable;
            I2of5Dlg.m_bIata = pI2of5.bMC_IATA_Enable;
            I2of5Dlg.m_bCDV = pI2of5.bMC_I2OF5_CDV;
            I2of5Dlg.m_bXCD = pI2of5.bMC_I2OF5_XCD;
            I2of5Dlg.m_nMinLen = pI2of5.nMC_I2OF5_MinLen;
            I2of5Dlg.m_nMaxLen = pI2of5.nMC_I2OF5_MaxLen;

            if(I2of5Dlg.ShowDialog() == DialogResult.OK)
            {
                pI2of5.bMC_I2OF5_Enable = m_bI2of5 = I2of5Dlg.m_bEnable;
                pI2of5.bMC_ITF14_Enable = I2of5Dlg.m_bItf14;
                pI2of5.bMC_MATRIX2OF5_Enable = I2of5Dlg.m_bMatrix2of5;
                pI2of5.bMC_DLOGIG_Enable = I2of5Dlg.m_bDlogic;
                pI2of5.bMC_INDUSTRY_Enable = I2of5Dlg.m_bIndustry;
                pI2of5.bMC_IATA_Enable = I2of5Dlg.m_bIata;
                pI2of5.bMC_I2OF5_CDV = I2of5Dlg.m_bCDV;
                pI2of5.bMC_I2OF5_XCD = I2of5Dlg.m_bXCD;
                pI2of5.nMC_I2OF5_MinLen = I2of5Dlg.m_nMinLen;
                pI2of5.nMC_I2OF5_MaxLen = I2of5Dlg.m_nMaxLen;

                ScanCtrl.SetBarOptionI2OF5(ref pI2of5);
            }
        }

        private void BTN_CODABAR_Click(object sender, EventArgs e)
        {
            FCODABAR CodabarDlg;
            CodabarDlg = new FCODABAR();

            pCodabar = new MCBarOption_CODABAR();

            ScanCtrl.GetBarOptionCODABAR(out pCodabar);

            CodabarDlg.m_bEnable = pCodabar.bMC_CODABAR_Enable;
            CodabarDlg.m_bXSS = pCodabar.bMC_CODABAR_XSS;
            CodabarDlg.m_nMinLen = pCodabar.nMC_CODABAR_MinLen;
            CodabarDlg.m_nMaxLen = pCodabar.nMC_CODABAR_MaxLen;

            if(CodabarDlg.ShowDialog() == DialogResult.OK)
            {
                pCodabar.bMC_CODABAR_Enable = m_bCodabar = CodabarDlg.m_bEnable;
                pCodabar.bMC_CODABAR_XSS = CodabarDlg.m_bXSS;
                pCodabar.nMC_CODABAR_MinLen = CodabarDlg.m_nMinLen;
                pCodabar.nMC_CODABAR_MaxLen = CodabarDlg.m_nMaxLen;

                ScanCtrl.SetBarOptionCODABAR(ref pCodabar);
            }
        }

        private void BTN_MSI_Click(object sender, EventArgs e)
        {
            FMSI MsiDlg;
            MsiDlg = new FMSI();

            pMsi = new MCBarOption_MSI();

            ScanCtrl.GetBarOptionMSI(out pMsi);

            MsiDlg.m_bEnable = pMsi.bMC_MSI_Enable;
            MsiDlg.m_bCDV = pMsi.bMC_MSI_CDV;
            MsiDlg.m_bXCD = pMsi.bMC_MSI_XCD;
            MsiDlg.m_nMinLen = pMsi.nMC_MSI_MinLen;
            MsiDlg.m_nMaxLen = pMsi.nMC_MSI_MaxLen;

            if(MsiDlg.ShowDialog() == DialogResult.OK)
            {
                pMsi.bMC_MSI_Enable = m_bMsi = MsiDlg.m_bEnable;
                pMsi.bMC_MSI_CDV = MsiDlg.m_bCDV;
                pMsi.bMC_MSI_XCD = MsiDlg.m_bXCD;
                pMsi.nMC_MSI_MinLen = MsiDlg.m_nMinLen;
                pMsi.nMC_MSI_MaxLen = MsiDlg.m_nMaxLen;

                ScanCtrl.SetBarOptionMSI(ref pMsi);
            }
        }

        private void BTN_PLESSEY_Click(object sender, EventArgs e)
        {
            FPLESSEY PlesseyDlg;
            PlesseyDlg = new FPLESSEY();

            pPlessey = new MCBarOption_PLESSEY();

            ScanCtrl.GetBarOptionPLESSEY(out pPlessey);

            PlesseyDlg.m_bEnable = pPlessey.bMC_PLESSEY_Enable;
            PlesseyDlg.m_bCDV = pPlessey.bMC_PLESSEY_CDV;
            PlesseyDlg.m_bXCD = pPlessey.bMC_PLESSEY_XCD;
            PlesseyDlg.m_nMinLen = pPlessey.nMC_PLESSEY_MinLen;
            PlesseyDlg.m_nMaxLen = pPlessey.nMC_PLESSEY_MaxLen;

            if(PlesseyDlg.ShowDialog() == DialogResult.OK)
            {
                pPlessey.bMC_PLESSEY_Enable = m_bPlessey = PlesseyDlg.m_bEnable;
                pPlessey.bMC_PLESSEY_CDV = PlesseyDlg.m_bCDV;
                pPlessey.bMC_PLESSEY_XCD = PlesseyDlg.m_bXCD;
                pPlessey.nMC_PLESSEY_MinLen = PlesseyDlg.m_nMinLen;
                pPlessey.nMC_PLESSEY_MaxLen = PlesseyDlg.m_nMaxLen;

                ScanCtrl.SetBarOptionPLESSEY(ref pPlessey);
            }
        }

        private void BTN_GS1_Click(object sender, EventArgs e)
        {
            FGS1 Gs1Dlg;
            Gs1Dlg = new FGS1();

            pGs1 = new MCBarOption_GS1();

            ScanCtrl.GetBarOptionGS1(out pGs1);

            Gs1Dlg.m_bEnable = pGs1.bMC_GS1_Enable;
            Gs1Dlg.m_bGs1Lim = pGs1.bMC_GS1LIM_Enable;
            Gs1Dlg.m_bGs1Exp = pGs1.bMC_GS1EXP_Enable;

            if(Gs1Dlg.ShowDialog() == DialogResult.OK)
            {
                pGs1.bMC_GS1_Enable = m_bGs1 = Gs1Dlg.m_bEnable;
                pGs1.bMC_GS1LIM_Enable = m_bGs1Lim = Gs1Dlg.m_bGs1Lim;
                pGs1.bMC_GS1EXP_Enable = m_bGs1Exp = Gs1Dlg.m_bGs1Exp;

                ScanCtrl.SetBarOptionGS1(ref pGs1);
            }
        }

        private void BTN_TELEPEN_Click(object sender, EventArgs e)
        {
            FTELEPEN TelepenDlg;
            TelepenDlg = new FTELEPEN();

            pTelepen = new MCBarOption_TELEPEN();

            ScanCtrl.GetBarOptionTELEPEN(out pTelepen);

            TelepenDlg.m_bEnable = pTelepen.bMC_TELEPEN_Enable;
            TelepenDlg.m_bOldStyle = pTelepen.bMC_TELEPEN_OldStyle;

            if(TelepenDlg.ShowDialog() == DialogResult.OK)
            {
                pTelepen.bMC_TELEPEN_Enable = TelepenDlg.m_bEnable;
                pTelepen.bMC_TELEPEN_OldStyle = TelepenDlg.m_bOldStyle;

                ScanCtrl.SetBarOptionTELEPEN(ref pTelepen);
            }
        }

        [DllImport("Coredll.dll", EntryPoint = "PlaySound", CharSet = CharSet.Auto)]
        private static extern int PlaySound(String pszSound, int hmod, int falgs);
//        private static extern int PlaySound(byte[] pszSound, IntPtr hmod, SND falgs);

        public enum SND
        {
            SND_SYNC = 0x0000,/* play synchronously (default) */
            SND_ASYNC = 0x0001, /* play asynchronously */
            SND_NODEFAULT = 0x0002, /* silence (!default) if sound not found */
            SND_MEMORY = 0x0004, /* pszSound points to a memory file */
            SND_LOOP = 0x0008, /* loop the sound until next sndPlaySound */
            SND_NOSTOP = 0x0010, /* don't stop any currently playing sound */
            SND_NOWAIT = 0x00002000, /* don't wait if the driver is busy */
            SND_ALIAS = 0x00010000,/* name is a registry alias */
            SND_ALIAS_ID = 0x00110000, /* alias is a pre d ID */
            SND_FILENAME = 0x00020000, /* name is file name */
            SND_RESOURCE = 0x00040004, /* name is resource name or atom */
            SND_PURGE = 0x0040,  /* purge non-static events for task */
            SND_APPLICATION = 0x0080,  /* look for application specific */
        };     

        
    }
}