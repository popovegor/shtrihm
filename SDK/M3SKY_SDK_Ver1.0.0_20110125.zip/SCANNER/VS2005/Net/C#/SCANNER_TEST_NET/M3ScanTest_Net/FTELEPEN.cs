﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace M3ScanTest_Net
{
    public partial class FTELEPEN : Form
    {
        public bool m_bEnable;
        public bool m_bOldStyle;

        public FTELEPEN()
        {
            InitializeComponent();
        }

        private void FTELEPEN_Load(object sender, EventArgs e)
        {
            CB_TELEPEN_ENABLE.Checked = m_bEnable;
            CB_TELEPEN_OLDSTYLE.Checked = m_bOldStyle;
        }

        private void BTN_OK_Click(object sender, EventArgs e)
        {
            m_bEnable = CB_TELEPEN_ENABLE.Checked;
            m_bOldStyle = CB_TELEPEN_OLDSTYLE.Checked;
            this.DialogResult = DialogResult.OK;
        }

        private void BTN_CANCEL_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}