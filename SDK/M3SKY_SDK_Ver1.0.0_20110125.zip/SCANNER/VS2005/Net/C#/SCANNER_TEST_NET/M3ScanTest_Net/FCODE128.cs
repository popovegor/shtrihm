﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace M3ScanTest_Net
{
    public partial class FCODE128 : Form
    {
        public bool m_bEnable;
        public bool m_bUccean128;        
        public int m_nMinLen;
        public int m_nMaxLen;

        public FCODE128()
        {
            InitializeComponent();
        }

        private void FCODE128_Load(object sender, EventArgs e)
        {
            CB_CODE128_ENABLE.Checked = m_bEnable;
            CB_UCCEAN128_ENABLE.Checked = m_bUccean128;

            TEXT_MINLEN.Text = m_nMinLen.ToString();
            TEXT_MAXLEN.Text = m_nMaxLen.ToString();
        }

        private void BTN_OK_Click(object sender, EventArgs e)
        {
            m_bEnable = CB_CODE128_ENABLE.Checked;
            m_bUccean128 = CB_UCCEAN128_ENABLE.Checked;

            m_nMinLen = Int32.Parse(TEXT_MINLEN.Text);
            m_nMaxLen = Int32.Parse(TEXT_MAXLEN.Text);

            this.DialogResult = DialogResult.OK;
        }

        private void BTN_CANCEL_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}