﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace M3ScanTest_Net
{
    public partial class FCODE35 : Form
    {
        public bool m_bEnable;

        public FCODE35()
        {
            InitializeComponent();
        }

        private void FCODE35_Load(object sender, EventArgs e)
        {
            CB_CODE35_ENABLE.Checked = m_bEnable;
        }

        private void BTN_OK_Click(object sender, EventArgs e)
        {
            m_bEnable = CB_CODE35_ENABLE.Checked;

            this.DialogResult = DialogResult.OK;
        }

        private void BTN_CANCEL_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}