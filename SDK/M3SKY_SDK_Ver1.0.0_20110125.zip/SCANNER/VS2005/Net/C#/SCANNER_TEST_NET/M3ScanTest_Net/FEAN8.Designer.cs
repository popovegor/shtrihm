﻿namespace M3ScanTest_Net
{
    partial class FEAN8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.CB_EAN8_ENABLE = new System.Windows.Forms.CheckBox();
            this.CB_EAN8_XCD = new System.Windows.Forms.CheckBox();
            this.CB_EAN8_AS_EAN13 = new System.Windows.Forms.CheckBox();
            this.BTN_CANCEL = new System.Windows.Forms.Button();
            this.BTN_OK = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // CB_EAN8_ENABLE
            // 
            this.CB_EAN8_ENABLE.Location = new System.Drawing.Point(32, 54);
            this.CB_EAN8_ENABLE.Name = "CB_EAN8_ENABLE";
            this.CB_EAN8_ENABLE.Size = new System.Drawing.Size(177, 20);
            this.CB_EAN8_ENABLE.TabIndex = 0;
            this.CB_EAN8_ENABLE.Text = "Enable";
            // 
            // CB_EAN8_XCD
            // 
            this.CB_EAN8_XCD.Location = new System.Drawing.Point(32, 94);
            this.CB_EAN8_XCD.Name = "CB_EAN8_XCD";
            this.CB_EAN8_XCD.Size = new System.Drawing.Size(177, 20);
            this.CB_EAN8_XCD.TabIndex = 1;
            this.CB_EAN8_XCD.Text = "Transmit Check Digit";
            // 
            // CB_EAN8_AS_EAN13
            // 
            this.CB_EAN8_AS_EAN13.Location = new System.Drawing.Point(32, 134);
            this.CB_EAN8_AS_EAN13.Name = "CB_EAN8_AS_EAN13";
            this.CB_EAN8_AS_EAN13.Size = new System.Drawing.Size(177, 20);
            this.CB_EAN8_AS_EAN13.TabIndex = 2;
            this.CB_EAN8_AS_EAN13.Text = "Convert EAN-8 as EAN-13";
            // 
            // BTN_CANCEL
            // 
            this.BTN_CANCEL.Location = new System.Drawing.Point(128, 209);
            this.BTN_CANCEL.Name = "BTN_CANCEL";
            this.BTN_CANCEL.Size = new System.Drawing.Size(93, 35);
            this.BTN_CANCEL.TabIndex = 10;
            this.BTN_CANCEL.Text = "CANCEL";
            this.BTN_CANCEL.Click += new System.EventHandler(this.BTN_CANCEL_Click);
            // 
            // BTN_OK
            // 
            this.BTN_OK.Location = new System.Drawing.Point(19, 209);
            this.BTN_OK.Name = "BTN_OK";
            this.BTN_OK.Size = new System.Drawing.Size(93, 35);
            this.BTN_OK.TabIndex = 9;
            this.BTN_OK.Text = "OK";
            this.BTN_OK.Click += new System.EventHandler(this.BTN_OK_Click);
            // 
            // FEAN8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.BTN_CANCEL);
            this.Controls.Add(this.BTN_OK);
            this.Controls.Add(this.CB_EAN8_AS_EAN13);
            this.Controls.Add(this.CB_EAN8_XCD);
            this.Controls.Add(this.CB_EAN8_ENABLE);
            this.Menu = this.mainMenu1;
            this.Name = "FEAN8";
            this.Text = "EAN-8";
            this.Load += new System.EventHandler(this.FEAN8_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckBox CB_EAN8_ENABLE;
        private System.Windows.Forms.CheckBox CB_EAN8_XCD;
        private System.Windows.Forms.CheckBox CB_EAN8_AS_EAN13;
        private System.Windows.Forms.Button BTN_CANCEL;
        private System.Windows.Forms.Button BTN_OK;
    }
}