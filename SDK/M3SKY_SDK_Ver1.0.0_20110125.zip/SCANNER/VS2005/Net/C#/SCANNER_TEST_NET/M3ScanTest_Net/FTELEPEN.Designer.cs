﻿namespace M3ScanTest_Net
{
    partial class FTELEPEN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.BTN_CANCEL = new System.Windows.Forms.Button();
            this.BTN_OK = new System.Windows.Forms.Button();
            this.CB_TELEPEN_ENABLE = new System.Windows.Forms.CheckBox();
            this.CB_TELEPEN_OLDSTYLE = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // BTN_CANCEL
            // 
            this.BTN_CANCEL.Location = new System.Drawing.Point(128, 209);
            this.BTN_CANCEL.Name = "BTN_CANCEL";
            this.BTN_CANCEL.Size = new System.Drawing.Size(93, 35);
            this.BTN_CANCEL.TabIndex = 20;
            this.BTN_CANCEL.Text = "CANCEL";
            this.BTN_CANCEL.Click += new System.EventHandler(this.BTN_CANCEL_Click);
            // 
            // BTN_OK
            // 
            this.BTN_OK.Location = new System.Drawing.Point(19, 209);
            this.BTN_OK.Name = "BTN_OK";
            this.BTN_OK.Size = new System.Drawing.Size(93, 35);
            this.BTN_OK.TabIndex = 19;
            this.BTN_OK.Text = "OK";
            this.BTN_OK.Click += new System.EventHandler(this.BTN_OK_Click);
            // 
            // CB_TELEPEN_ENABLE
            // 
            this.CB_TELEPEN_ENABLE.Location = new System.Drawing.Point(19, 68);
            this.CB_TELEPEN_ENABLE.Name = "CB_TELEPEN_ENABLE";
            this.CB_TELEPEN_ENABLE.Size = new System.Drawing.Size(202, 20);
            this.CB_TELEPEN_ENABLE.TabIndex = 21;
            this.CB_TELEPEN_ENABLE.Text = "Enable";
            // 
            // CB_TELEPEN_OLDSTYLE
            // 
            this.CB_TELEPEN_OLDSTYLE.Location = new System.Drawing.Point(19, 124);
            this.CB_TELEPEN_OLDSTYLE.Name = "CB_TELEPEN_OLDSTYLE";
            this.CB_TELEPEN_OLDSTYLE.Size = new System.Drawing.Size(202, 20);
            this.CB_TELEPEN_OLDSTYLE.TabIndex = 22;
            this.CB_TELEPEN_OLDSTYLE.Text = "Old Style(Compressed Numeric)";
            // 
            // FTELEPEN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.CB_TELEPEN_OLDSTYLE);
            this.Controls.Add(this.CB_TELEPEN_ENABLE);
            this.Controls.Add(this.BTN_CANCEL);
            this.Controls.Add(this.BTN_OK);
            this.Menu = this.mainMenu1;
            this.Name = "FTELEPEN";
            this.Text = "TELEPEN";
            this.Load += new System.EventHandler(this.FTELEPEN_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BTN_CANCEL;
        private System.Windows.Forms.Button BTN_OK;
        private System.Windows.Forms.CheckBox CB_TELEPEN_ENABLE;
        private System.Windows.Forms.CheckBox CB_TELEPEN_OLDSTYLE;
    }
}