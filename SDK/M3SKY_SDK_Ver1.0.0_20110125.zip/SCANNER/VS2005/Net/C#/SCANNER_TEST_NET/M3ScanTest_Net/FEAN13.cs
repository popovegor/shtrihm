﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace M3ScanTest_Net
{
    public partial class FEAN13 : Form
    {
        public bool m_bEnable;
        public bool m_bBookland;
        public bool m_bXCD;
        public bool m_bAddOn;

        public FEAN13()
        {
            InitializeComponent();
        }

        private void FEAN13_Load(object sender, EventArgs e)
        {
            CB_EAN13_ENABLE.Checked = m_bEnable;
            CB_BOOKLAND_ENABLE.Checked = m_bBookland;
            CB_EAN13_XCD.Checked = m_bXCD;
            CB_EAN13_ADDON.Checked = m_bAddOn;
        }

        private void BTN_OK_Click(object sender, EventArgs e)
        {
            m_bEnable = CB_EAN13_ENABLE.Checked;
            m_bBookland = CB_BOOKLAND_ENABLE.Checked;
            m_bXCD = CB_EAN13_XCD.Checked;
            m_bAddOn = CB_EAN13_ADDON.Checked;

            this.DialogResult = DialogResult.OK;
        }

        private void BTN_CANCEL_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}