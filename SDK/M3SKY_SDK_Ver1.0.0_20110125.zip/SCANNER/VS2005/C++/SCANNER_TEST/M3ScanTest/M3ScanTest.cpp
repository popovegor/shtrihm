// M3ScanTest.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "M3ScanTestDlg.h"

#include "KScanBar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CM3ScanTestApp

BEGIN_MESSAGE_MAP(CM3ScanTestApp, CWinApp)
END_MESSAGE_MAP()


// CM3ScanTestApp construction
CM3ScanTestApp::CM3ScanTestApp()
	: CWinApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only CM3ScanTestApp object
CM3ScanTestApp theApp;

// CM3ScanTestApp initialization

HANDLE g_hMutex = NULL;
BOOL CM3ScanTestApp::InitInstance()
{
    // SHInitExtraControls should be called once during your application's initialization to initialize any
    // of the Windows Mobile specific controls such as CAPEDIT and SIPPREF.
    SHInitExtraControls();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	//M3ScanTest��� �̸��� �����찡 �����ϴ����� Ȯ���� �Ŀ� ����Ǿ������� ShowWindow���� ������ �����մϴ�.
	g_hMutex = ::CreateMutex(NULL, TRUE, _T("M3SCANNER"));
	if(GetLastError() == ERROR_ALREADY_EXISTS)
	{
		HWND hWnd =NULL;
		hWnd = FindWindow(NULL,_T("M3ScanTest"));
		if(hWnd == NULL)
		{
			MessageBox(NULL,_T("SCANNER Engine is already running!"),_T("ERROR"),MB_OK|MB_ICONWARNING);
		    return FALSE;			
		}
		ShowWindow(hWnd,SW_SHOW);
		SetForegroundWindow(hWnd);

		return FALSE;
	}

	CWnd	*pWnd;
	if(pWnd = CWnd::FindWindow(NULL,_T("M3ScanTest")))
	{
		pWnd->ShowWindow(SW_SHOW);
		pWnd->SetForegroundWindow();
		return	FALSE;
	}

	/*
	InitialDlg = new CMessageDlg;
	InitialDlg->Create(IDD_MESSAGE_DLG);
	*/

	//SHSetAppKeyWndAssoc(0xc2, this->m_hInstance);

	CM3ScanTestDlg dlg(L"M3ScanTest");

	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	ReleaseMutex(g_hMutex);	
	CloseHandle(g_hMutex);
	return FALSE;
}
