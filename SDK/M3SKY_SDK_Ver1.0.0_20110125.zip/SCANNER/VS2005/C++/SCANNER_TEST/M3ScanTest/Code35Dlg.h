#pragma once


// CCode35Dlg dialog

class CCode35Dlg : public CDialog
{
	DECLARE_DYNAMIC(CCode35Dlg)

public:
	CCode35Dlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCode35Dlg();

// Dialog Data
	enum { IDD = IDD_CODE35_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	BOOL m_bEnable;
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	void GetOption(void);
	void SetOption(void);
};
