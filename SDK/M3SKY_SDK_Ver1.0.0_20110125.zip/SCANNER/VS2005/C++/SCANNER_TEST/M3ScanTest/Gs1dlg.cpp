// Gs1dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "Gs1dlg.h"
#include "M3ScanTestDlg.h"

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;


// CGs1dlg dialog

IMPLEMENT_DYNAMIC(CGs1dlg, CDialog)

CGs1dlg::CGs1dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGs1dlg::IDD, pParent)
	, m_bEnable(FALSE)
{

}

CGs1dlg::~CGs1dlg()
{
}

void CGs1dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
}


BEGIN_MESSAGE_MAP(CGs1dlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, &CGs1dlg::OnConfirm)
END_MESSAGE_MAP()


// CGs1dlg message handlers

BOOL CGs1dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CGs1dlg::OnConfirm()
{
	SetOption();

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	dlg->SetReadOption();

	CDialog::OnOK();
}

void CGs1dlg::GetOption(void)
{
	if(kReadEx2.Gs1.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;

	UpdateData(FALSE);
}

void CGs1dlg::SetOption(void)
{
	UpdateData(TRUE);

	if(m_bEnable == TRUE)
		kReadEx2.Gs1.Enable = ENABLE;
	else
		kReadEx2.Gs1.Enable = DISABLE;
}
