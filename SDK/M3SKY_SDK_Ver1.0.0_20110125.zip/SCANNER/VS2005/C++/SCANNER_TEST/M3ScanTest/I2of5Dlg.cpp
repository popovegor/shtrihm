// I2of5Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "I2of5Dlg.h"
#include "M3ScanTestDlg.h"

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;


// CI2of5Dlg dialog

IMPLEMENT_DYNAMIC(CI2of5Dlg, CDialog)

CI2of5Dlg::CI2of5Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CI2of5Dlg::IDD, pParent)
	, m_bEnable(FALSE)
	, m_bEnableItf14(FALSE)
	, m_bEnableMatrix(FALSE)
	, m_bEnableDlogic(FALSE)
	, m_bEnableIndustry(FALSE)
	, m_bEnableIata(FALSE)
	, m_bCDV(FALSE)
	, m_bXCD(FALSE)
	, m_nMinLen(0)
	, m_nMaxLen(0)
{

}

CI2of5Dlg::~CI2of5Dlg()
{
}

void CI2of5Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_ITF14, m_bEnableItf14);
	DDX_Check(pDX, IDC_CHECK_MATRIX2OF5, m_bEnableMatrix);
	DDX_Check(pDX, IDC_CHECK_DLOGIC, m_bEnableDlogic);
	DDX_Check(pDX, IDC_CHECK_INDUSTRY, m_bEnableIndustry);
	DDX_Check(pDX, IDC_CHECK_IATA, m_bEnableIata);
	DDX_Check(pDX, IDC_CHECK_CDV, m_bCDV);
	DDX_Check(pDX, IDC_CHECK_XCD, m_bXCD);
	DDX_Text(pDX, IDC_EDIT_MIN, m_nMinLen);
	DDX_Text(pDX, IDC_EDIT_MAX, m_nMaxLen);
}


BEGIN_MESSAGE_MAP(CI2of5Dlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, &CI2of5Dlg::OnConfirm)
END_MESSAGE_MAP()


// CI2of5Dlg message handlers

BOOL CI2of5Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CI2of5Dlg::OnConfirm()
{
	SetOption();

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	dlg->SetReadOption();

	CDialog::OnOK();
}

void CI2of5Dlg::GetOption(void)
{
	if(kReadEx2.Code25.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;

	if(kReadEx2.Code25.CDV == ENABLE)
		m_bCDV = TRUE;
	else
		m_bCDV = FALSE;

	if(kReadEx2.Code25.XmitCheckDigit == XMIT_CHECK_DIGIT)
		m_bXCD = TRUE;
	else
		m_bXCD = FALSE;

	if((kReadEx2.Code25.KindofDecode & CODE25KIND_ITF14) && (kReadEx2.Code25.Enable == ENABLE))
		m_bEnableItf14 = TRUE;
	else
		m_bEnableItf14 = FALSE;

	if((kReadEx2.Code25.KindofDecode & CODE25KIND_MATRIX) && (kReadEx2.Code25.Enable == ENABLE))
		m_bEnableMatrix = TRUE;
	else
		m_bEnableMatrix = FALSE;

	if((kReadEx2.Code25.KindofDecode & CODE25KIND_DLOGIC) && (kReadEx2.Code25.Enable == ENABLE))
		m_bEnableDlogic = TRUE;
	else
		m_bEnableDlogic = FALSE;

	if((kReadEx2.Code25.KindofDecode & CODE25KIND_INDUSTRY) && (kReadEx2.Code25.Enable == ENABLE))
		m_bEnableIndustry = TRUE;
	else
		m_bEnableIndustry = FALSE;

	if((kReadEx2.Code25.KindofDecode & CODE25KIND_IATA) && (kReadEx2.Code25.Enable == ENABLE))
		m_bEnableIata = TRUE;
	else
		m_bEnableIata = FALSE;


	m_nMaxLen = kReadEx2.Code25.MaxLength;
	m_nMinLen = kReadEx2.Code25.MinLength;

	UpdateData(FALSE);
}

void CI2of5Dlg::SetOption(void)
{
	UpdateData(TRUE);

	if(m_bEnable == TRUE)
		kReadEx2.Code25.Enable = ENABLE;
	else
		kReadEx2.Code25.Enable = DISABLE;

	if(m_bCDV == TRUE)
		kReadEx2.Code25.CDV = ENABLE;
	else
		kReadEx2.Code25.CDV = DISABLE;

	if(m_bXCD == TRUE)
		kReadEx2.Code25.XmitCheckDigit = XMIT_CHECK_DIGIT;
	else
		kReadEx2.Code25.XmitCheckDigit = NO_XMIT_CHECK_DIGIT;

	kReadEx2.Code25.KindofDecode = CODE25KIND_INTER;

	if(m_bEnableItf14 == TRUE)
	{
		kReadEx2.Code25.Enable = ENABLE;
		kReadEx2.Code25.KindofDecode |= CODE25KIND_ITF14;
	}

	if(m_bEnableMatrix == TRUE)
	{
		kReadEx2.Code25.Enable = ENABLE;
		kReadEx2.Code25.KindofDecode |= CODE25KIND_MATRIX;
	}

	if(m_bEnableDlogic == TRUE)
	{
		kReadEx2.Code25.Enable = ENABLE;
		kReadEx2.Code25.KindofDecode |= CODE25KIND_DLOGIC;
	}

	if(m_bEnableIndustry == TRUE)
	{
		kReadEx2.Code25.Enable = ENABLE;
		kReadEx2.Code25.KindofDecode |= CODE25KIND_INDUSTRY;
	}

	if(m_bEnableIata == TRUE)
	{
		kReadEx2.Code25.Enable = ENABLE;
		kReadEx2.Code25.KindofDecode |= CODE25KIND_IATA;
	}

	kReadEx2.Code25.MaxLength = m_nMaxLen;
	kReadEx2.Code25.MinLength = m_nMinLen;
}
