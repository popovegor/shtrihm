// Code93Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "Code93Dlg.h"
#include "M3ScanTestDlg.h"

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;


// CCode93Dlg dialog

IMPLEMENT_DYNAMIC(CCode93Dlg, CDialog)

CCode93Dlg::CCode93Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCode93Dlg::IDD, pParent)
	, m_bEnable(FALSE)
	, m_nMinLen(0)
	, m_nMaxLen(0)
{

}

CCode93Dlg::~CCode93Dlg()
{
}

void CCode93Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Text(pDX, IDC_EDIT_MIN, m_nMinLen);
	DDX_Text(pDX, IDC_EDIT_MAX, m_nMaxLen);
}


BEGIN_MESSAGE_MAP(CCode93Dlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, &CCode93Dlg::OnConfirm)
END_MESSAGE_MAP()


// CCode93Dlg message handlers

BOOL CCode93Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CCode93Dlg::OnConfirm()
{
	SetOption();

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	dlg->SetReadOption();

	CDialog::OnOK();
}

void CCode93Dlg::GetOption(void)
{
	if(kReadEx2.Code93.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;

	m_nMaxLen = kReadEx2.Code93.MaxLength;
	m_nMinLen = kReadEx2.Code93.MinLength;

	UpdateData(FALSE);
}

void CCode93Dlg::SetOption(void)
{
	UpdateData(TRUE);

	if(m_bEnable == TRUE)
		kReadEx2.Code93.Enable = ENABLE;
	else
		kReadEx2.Code93.Enable = DISABLE;


	kReadEx2.Code93.MaxLength = m_nMaxLen;
	kReadEx2.Code93.MinLength = m_nMinLen;
}
