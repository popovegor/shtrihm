#pragma once
#include "afxcmn.h"
#include "afxwin.h"

#include "Reg.h"


// CScanPage dialog

class CScanPage : public CPropertyPage
{
	DECLARE_DYNAMIC(CScanPage)

public:
	CScanPage();
	virtual ~CScanPage();
	void Write_ListCtrl(CString& BarType, CString& BarValue);

// Dialog Data
	enum { IDD = IDD_SCAN_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedScanButton();
	afx_msg void OnBnClickedInfoBtn();

public:
	virtual BOOL OnInitDialog();

protected:

public:
	CListCtrl	m_BarCode_ListCtrl;

	CReg		m_Reg;
	int			m_nDisplayType;
	afx_msg void OnBnClickedBtnScancancel();
	afx_msg void OnBnClickedBtnClear();
};
