#pragma once


// CGs1Expanded dialog

class CGs1Expanded : public CDialog
{
	DECLARE_DYNAMIC(CGs1Expanded)

public:
	CGs1Expanded(CWnd* pParent = NULL);   // standard constructor
	virtual ~CGs1Expanded();

// Dialog Data
	enum { IDD = IDD_GS1EXPANDED_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	BOOL m_bEnable;
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	void GetOption(void);
	void SetOption(void);
};
