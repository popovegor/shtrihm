// Code39Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "Code39Dlg.h"
#include "M3ScanTestDlg.h"

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;


// CCode39Dlg dialog

IMPLEMENT_DYNAMIC(CCode39Dlg, CDialog)

CCode39Dlg::CCode39Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCode39Dlg::IDD, pParent)
	, m_bEnable(FALSE)
	, m_bEnableCode32(FALSE)
	, m_bEnablePzn(FALSE)
	, m_bCDV(FALSE)
	, m_bXCD(FALSE)
	, m_bFullASCII(FALSE)
	, m_nMinLen(0)
	, m_nMaxLen(0)
{

}

CCode39Dlg::~CCode39Dlg()
{
}

void CCode39Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_CODE32, m_bEnableCode32);
	DDX_Check(pDX, IDC_CHECK_PZN, m_bEnablePzn);
	DDX_Check(pDX, IDC_CHECK_CDV, m_bCDV);
	DDX_Check(pDX, IDC_CHECK_XCD, m_bXCD);
	DDX_Check(pDX, IDC_CHECK_FullASCII, m_bFullASCII);
	DDX_Text(pDX, IDC_EDIT_MIN, m_nMinLen);
	DDX_Text(pDX, IDC_EDIT_MAX, m_nMaxLen);
}


BEGIN_MESSAGE_MAP(CCode39Dlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, &CCode39Dlg::OnConfirm)
END_MESSAGE_MAP()


// CCode39Dlg message handlers

BOOL CCode39Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

		GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CCode39Dlg::OnConfirm()
{
	SetOption();

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	dlg->SetReadOption();

	CDialog::OnOK();
}

void CCode39Dlg::GetOption(void)
{
	if(kReadEx2.Code39.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;

	if(kReadEx2.Code39.SetAscii == FULL_ASCII)
		m_bFullASCII = TRUE;
	else
		m_bFullASCII = FALSE;

	if(kReadEx2.Code39.CDV == ENABLE)
		m_bCDV = TRUE;
	else
		m_bCDV = FALSE;

	if(kReadEx2.Code39.XmitCheckDigit == XMIT_CHECK_DIGIT)
		m_bXCD = TRUE;
	else
		m_bXCD = FALSE;

	if((kReadEx2.Code39.AsCode32 == ENABLE) && (kReadEx2.Code39.Enable == ENABLE))
		m_bEnableCode32 = TRUE;
	else
		m_bEnableCode32 = FALSE;

	if((kReadEx2.Code39.AsPZN == ENABLE) && (kReadEx2.Code39.Enable == ENABLE))
		m_bEnablePzn = TRUE;
	else
		m_bEnablePzn = FALSE;

	m_nMaxLen = kReadEx2.Code39.MaxLength;
	m_nMinLen = kReadEx2.Code39.MinLength;

	UpdateData(FALSE);
}

void CCode39Dlg::SetOption(void)
{
	UpdateData(TRUE);

	if(m_bEnable == TRUE)
		kReadEx2.Code39.Enable = ENABLE;
	else
		kReadEx2.Code39.Enable = DISABLE;

	if(m_bFullASCII == TRUE)
		kReadEx2.Code39.SetAscii = FULL_ASCII;
	else
		kReadEx2.Code39.SetAscii = STD_ASCII;

	if(m_bCDV == TRUE)
		kReadEx2.Code39.CDV = ENABLE;
	else
		kReadEx2.Code39.CDV = DISABLE;

	if(m_bXCD == TRUE)
		kReadEx2.Code39.XmitCheckDigit = XMIT_CHECK_DIGIT;
	else
		kReadEx2.Code39.XmitCheckDigit = NO_XMIT_CHECK_DIGIT;

	if(m_bEnableCode32 == TRUE)
	{
		kReadEx2.Code39.Enable		= ENABLE;
		kReadEx2.Code39.AsCode32	= ENABLE;
	}
	else
	{
		kReadEx2.Code39.AsCode32	= DISABLE;
	}

	if(m_bEnablePzn == TRUE)
	{
		kReadEx2.Code39.Enable	= ENABLE;
		kReadEx2.Code39.AsPZN	= ENABLE;
	}
	else
	{
		kReadEx2.Code39.AsPZN = DISABLE;
	}

	kReadEx2.Code39.MaxLength = m_nMaxLen;
	kReadEx2.Code39.MinLength = m_nMinLen;
}
