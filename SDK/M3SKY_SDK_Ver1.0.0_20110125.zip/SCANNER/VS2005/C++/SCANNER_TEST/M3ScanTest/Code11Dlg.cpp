// Code11Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "Code11Dlg.h"
#include "M3ScanTestDlg.h"

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;


// CCode11Dlg dialog

IMPLEMENT_DYNAMIC(CCode11Dlg, CDialog)

CCode11Dlg::CCode11Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCode11Dlg::IDD, pParent)
	, m_bEnable(FALSE)
	, m_bXCD(FALSE)
	, m_nMinLen(0)
	, m_nMaxLen(0)
	, m_nCdv(0)
{

}

CCode11Dlg::~CCode11Dlg()
{
}

void CCode11Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_XCD, m_bXCD);
	DDX_Text(pDX, IDC_EDIT_MIN, m_nMinLen);
	DDX_Text(pDX, IDC_EDIT_MAX, m_nMaxLen);
	DDX_Radio(pDX, IDC_RADIO_NOCDV, m_nCdv);
}


BEGIN_MESSAGE_MAP(CCode11Dlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, &CCode11Dlg::OnConfirm)
END_MESSAGE_MAP()


// CCode11Dlg message handlers

BOOL CCode11Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CCode11Dlg::OnConfirm()
{
	SetOption();

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	dlg->SetReadOption();

	CDialog::OnOK();
}

void CCode11Dlg::GetOption(void)
{
	if(kReadEx2.Code11.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;

	m_nCdv = (int)kReadEx2.Code11.CheckDigit;

	if(kReadEx2.Code11.XmitCheckDigit == XMIT_CHECK_DIGIT)
		m_bXCD = TRUE;
	else
		m_bXCD = FALSE;

	m_nMaxLen = kReadEx2.Code11.MaxLength;
	m_nMinLen = kReadEx2.Code11.MinLength;

	UpdateData(FALSE);
}

void CCode11Dlg::SetOption(void)
{
	UpdateData(TRUE);

	if(m_bEnable == TRUE)
		kReadEx2.Code11.Enable = ENABLE;
	else
		kReadEx2.Code11.Enable = DISABLE;

	kReadEx2.Code11.CheckDigit = (CHECK_DIGIT)m_nCdv;

	if(m_bXCD == TRUE)
		kReadEx2.Code11.XmitCheckDigit = XMIT_CHECK_DIGIT;
	else
		kReadEx2.Code11.XmitCheckDigit = NO_XMIT_CHECK_DIGIT;

	kReadEx2.Code11.MaxLength = m_nMaxLen;
	kReadEx2.Code11.MinLength = m_nMinLen;
}
