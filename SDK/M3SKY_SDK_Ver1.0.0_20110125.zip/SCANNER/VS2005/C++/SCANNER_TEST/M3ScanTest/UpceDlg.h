#pragma once


// CUpceDlg dialog

class CUpceDlg : public CDialog
{
	DECLARE_DYNAMIC(CUpceDlg)

public:
	CUpceDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CUpceDlg();

// Dialog Data
	enum { IDD = IDD_UPCE_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	BOOL m_bEnable;
	BOOL m_bXmitNum;
	BOOL m_bXCD;
	int m_nConvert;
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	void GetOption(void);
	void SetOption(void);
};
