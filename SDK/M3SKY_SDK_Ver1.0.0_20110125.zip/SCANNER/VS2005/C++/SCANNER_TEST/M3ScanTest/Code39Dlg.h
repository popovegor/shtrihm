#pragma once


// CCode39Dlg dialog

class CCode39Dlg : public CDialog
{
	DECLARE_DYNAMIC(CCode39Dlg)

public:
	CCode39Dlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCode39Dlg();

// Dialog Data
	enum { IDD = IDD_CODE39_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	BOOL m_bEnable;
	BOOL m_bEnableCode32;
	BOOL m_bEnablePzn;
	BOOL m_bCDV;
	BOOL m_bXCD;
	BOOL m_bFullASCII;
	int m_nMinLen;
	int m_nMaxLen;
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	void GetOption(void);
	void SetOption(void);
};
