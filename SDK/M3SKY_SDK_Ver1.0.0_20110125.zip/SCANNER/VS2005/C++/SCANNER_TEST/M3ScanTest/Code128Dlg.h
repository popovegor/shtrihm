#pragma once


// CCode128Dlg dialog

class CCode128Dlg : public CDialog
{
	DECLARE_DYNAMIC(CCode128Dlg)

public:
	CCode128Dlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCode128Dlg();

// Dialog Data
	enum { IDD = IDD_CODE128_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	BOOL m_bEnable;
	BOOL m_bEnableUccEan128;
	int m_nMinLen;
	int m_nMaxLen;
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	void GetOption(void);
	void SetOption(void);
	CString m_strFNC_ASCII;
};
