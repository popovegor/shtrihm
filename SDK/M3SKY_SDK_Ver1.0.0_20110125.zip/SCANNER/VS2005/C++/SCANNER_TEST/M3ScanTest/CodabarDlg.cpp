// CodabarDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "CodabarDlg.h"
#include "M3ScanTestDlg.h"

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;


// CCodabarDlg dialog

IMPLEMENT_DYNAMIC(CCodabarDlg, CDialog)

CCodabarDlg::CCodabarDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCodabarDlg::IDD, pParent)
	, m_bEnable(FALSE)
	, m_bXSS(FALSE)
	, m_nMinLen(0)
	, m_nMaxLen(0)
{

}

CCodabarDlg::~CCodabarDlg()
{
}

void CCodabarDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_XMITSS, m_bXSS);
	DDX_Text(pDX, IDC_EDIT_MIN, m_nMinLen);
	DDX_Text(pDX, IDC_EDIT_MAX, m_nMaxLen);
}


BEGIN_MESSAGE_MAP(CCodabarDlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, &CCodabarDlg::OnConfirm)
END_MESSAGE_MAP()


// CCodabarDlg message handlers

BOOL CCodabarDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

		GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CCodabarDlg::OnConfirm()
{
	SetOption();

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();
	dlg->SetReadOption();

	CDialog::OnOK();
}

void CCodabarDlg::GetOption(void)
{
	if(kReadEx2.Codabar.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;

	if(kReadEx2.Codabar.XmitStartStop == XMIT)
		m_bXSS = TRUE;
	else
		m_bXSS = FALSE;

	m_nMaxLen = kReadEx2.Codabar.MaxLength;
	m_nMinLen = kReadEx2.Codabar.MinLength;

	UpdateData(FALSE);
}

void CCodabarDlg::SetOption(void)
{
	UpdateData(TRUE);

	if(m_bEnable == TRUE)
		kReadEx2.Codabar.Enable = ENABLE;
	else
		kReadEx2.Codabar.Enable = DISABLE;

	if(m_bXSS == TRUE)
		kReadEx2.Codabar.XmitStartStop = XMIT;
	else
		kReadEx2.Codabar.XmitStartStop = NO_XMIT;	

	kReadEx2.Codabar.MaxLength = m_nMaxLen;
	kReadEx2.Codabar.MinLength = m_nMinLen;
}
