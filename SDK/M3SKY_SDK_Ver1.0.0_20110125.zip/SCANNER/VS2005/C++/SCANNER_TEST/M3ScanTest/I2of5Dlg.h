#pragma once


// CI2of5Dlg dialog

class CI2of5Dlg : public CDialog
{
	DECLARE_DYNAMIC(CI2of5Dlg)

public:
	CI2of5Dlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CI2of5Dlg();

// Dialog Data
	enum { IDD = IDD_I2OF5_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	BOOL m_bEnable;
	BOOL m_bEnableItf14;
	BOOL m_bEnableMatrix;
	BOOL m_bEnableDlogic;
	BOOL m_bEnableIndustry;
	BOOL m_bEnableIata;
	BOOL m_bCDV;
	BOOL m_bXCD;
	int m_nMinLen;
	int m_nMaxLen;
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	void GetOption(void);
	void SetOption(void);
};
