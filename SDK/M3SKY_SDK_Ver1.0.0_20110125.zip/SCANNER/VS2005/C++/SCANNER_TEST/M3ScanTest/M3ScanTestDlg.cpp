/********************************************************************
created		:	2009/09/20
file base	: 	M3ScanTest.exe

file ext	:	cpp
author		:	Dong-Hyun, Eum(vision7901) - Applied Development Team

purpose		:	M3 SKY / MM3
Report		:	2009. 03. 25 [03/25/2009 vision7901] v1.1.0 - �������� ����
				2009. 06. 22 [06/22/2009 vision7901] v1.2.0 - Option2Page �߰�(���ڵ庰 Check Digit�� Convert , Vibrate �߰�)
				2009. 07. 06 [07/06/2009 vision7901] v1.3.0 - M3 SKY/MM3 ���չ���
				2009. 09. 20 [09/20/2009 vision7901] v2.0.0 - ���Ӱ� ���α׷� ����/ ���Ӱ� ���ڵ庰�� �ɼ� ����
				2009. 10. 08 [10/08/2009 vision7901] v2.0.0 - UCC/EAN128 FNC1 ASCII����, AIM ID�߰�, I2of5 CDV, EAN13/UPCA �и�
				2009. 11. 02 [11/02/2009 vision7901] v2.0.0 - UPCA Addon ���� ���� / I2OF5 ���� Enable ���� ����
				2009. 12. 15 [12/15/2009 vision7901] v2.0.0 - MM3 QVGA ����
				2010. 01. 06 [01/06/2010 vision7901] v2.0.0 - WideScan �� ��Ÿ ���� ����/ Beep Sound �߰�
				2010. 01. 25 [01/25/2010 vision7901] v2.0.1 - MC7200S ����
				2010. 02. 26 [02/26/2010 vision7901] v2.1.0 - Telepen �߰�
				2010. 03. 17 [03/17/2010 vision7901] v2.2.0 - Code11/Code39/MSI ����/ Sound���� ����/ ��� ���ڵ� Enable/ 
															  Min,Max Length 6-30���� �ʱ�ȭ 
			    2010. 04. 22 [04/22/2010 vision7901] v2.3.0 - Min,Max Length 4-50���� �ʱ�ȭ. TimeOut �ɼ� �޺��ڽ��� ����/ Device���� ��� ��� ����
				2010. 06. 21 [06/21/2010 vision7901] v2.5.0 - WinCE, WM ���� ����(Ȧ�� WinCE, ¦�� WM) / Continue ��� �߰�
				2010. 08. 05 [08/05/2010 vision7901] v2.5.1 - Continue Mode���� Sync��� ���� ����
				2010. 08. 18 [08/18/2010 vision7901] v2.5.2 - �ʱ� ASynMode�� �����ϵ��� ����
				2010. 10. 25 [10/25/2010 vision7901] v2.6.0 - M3SKY Summit/M3Orange SideKey ���� / Continue ���� ����
*********************************************************************/
// M3ScanTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "M3ScanTestDlg.h"

int KSCANAPI KScanReadCallBack(LPVOID pRead);


#define DEVICE_M3SKY	1
#define DEVICE_MM3		2
#define DEVICE_M3ORANGE	3

#define KEYPAD_NUMERIC	0
#define KEYPAD_QWERTY	1

int			g_nDeviceType	= 0;
int			g_nKeyPadType	= 0;
int			g_nRightDownKey	= 0;
TCHAR		g_szSideKeyReg[1024] = {0, };

CString		g_strType;

KSCANREAD	 kRead;
KSCANREADEX	 kReadEx;
KSCANREADEX2 kReadEx2;

BOOL			m_bKeyFlag;

BYTE         FNC1_Ascii[]="";


// CM3ScanTestDlg

IMPLEMENT_DYNAMIC(CM3ScanTestDlg, CPropertySheet)

CM3ScanTestDlg::CM3ScanTestDlg(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
}

CM3ScanTestDlg::CM3ScanTestDlg(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	m_bSyncMode = FALSE;
	m_bReading	= FALSE;
	m_bKeyFlag	= FALSE;
	m_bCon		= FALSE;
	m_bConCheck	= FALSE;
	m_bUpca		= TRUE;
	m_bUpca_AddOn	= FALSE;
	
	AddPage(&m_ScanPage);
	AddPage(&m_SymbologyPage);
	AddPage(&m_OptionPage);

	InitCommonControls();

}

CM3ScanTestDlg::~CM3ScanTestDlg()
{
	RemovePage(&m_ScanPage);
	RemovePage(&m_SymbologyPage);
	RemovePage(&m_OptionPage);
}

BEGIN_MESSAGE_MAP(CM3ScanTestDlg, CPropertySheet)
	ON_MESSAGE(WM_SCANDATA,OnScanRead)
	ON_WM_DESTROY()
END_MESSAGE_MAP()


// CM3ScanTestDlg message handlers

BOOL CM3ScanTestDlg::OnInitDialog()
{
	BOOL bResult = CPropertySheet::OnInitDialog();

	//////////////////////////////////////////////////////////////////////////
	// Device
	TCHAR szModel[33]= {0, };	
	SystemParametersInfo(SPI_GETOEMINFO, 64, szModel, SPIF_SENDCHANGE);

	if(wcscmp(szModel, L"MM3") == 0)
	{
		g_nDeviceType = DEVICE_MM3;
	}
	else if((wcscmp(szModel, L"M3ORANGE") == 0) || (wcscmp(szModel, L"MC7101") == 0) || (wcscmp(szModel, L"MC7X01") == 0))
	{		
		g_nDeviceType	= DEVICE_M3ORANGE;	
		g_nKeyPadType	= m_Reg.GetRegValue(HKEY_LOCAL_MACHINE, L"ControlPanel\\keypad", L"KeypadType");
	}
	else
	{
		g_nDeviceType = DEVICE_M3SKY;
	}

	M3_ScanInit();
	
	return bResult;
}


BOOL CM3ScanTestDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_F14)
	{
		m_bKeyFlag == TRUE;

		if(m_bCon == TRUE)
		{
			if(m_bConCheck == FALSE)
			{
				ScanReadNB();
				m_bConCheck = TRUE;
			}
			else
			{
				ReadCancel();			
				m_bConCheck = FALSE;
			}
		}
		else
		{
			ScanReadNB();

			if(g_nDeviceType == DEVICE_MM3)
				Sleep(10);		

		}		

		return	TRUE;

	}
	else if(pMsg->message == WM_KEYUP && pMsg->wParam == VK_F14)
	{
		if(m_bKeyFlag == TRUE)
		{
			m_bKeyFlag = FALSE;

			if(m_bCon == FALSE)
			{
				if(m_bSyncMode == FALSE)
				{		
					ReadCancel();

					if(g_nDeviceType == DEVICE_MM3)
						Sleep(10);	

					m_bReading = FALSE;						
				}			
			}

			return	TRUE;
		}
	}

	return CPropertySheet::PreTranslateMessage(pMsg);
}

void CM3ScanTestDlg::OnDestroy()
{
	CPropertySheet::OnDestroy();

	M3_ScanClose();
}

void CM3ScanTestDlg::M3_ScanInit()
{
		

	BOOL bRet = KScanOpen(6, FALSE,	230400,	FALSE, NULL);
	if(!bRet)
	{
		TCHAR Str;
		wcscpy(&Str, KScanGetLastErrorMsg());
		AfxMessageBox(&Str);		
	}

	// DefaultOption Setting
	SetDefaultOption();
}

void CM3ScanTestDlg::M3_ScanClose(void)
{
	int i = 0;

	for(i=0;i<3;i++)
	{		
		if(KScanClose())
			break;
		Sleep(100);
	}
}

void CM3ScanTestDlg::SetDefaultOption(void)
{
	//////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////
	// KSCANREAD kRead �ʱ�ȭ
	memset(&kRead, 0, sizeof(kRead));
	kRead.nSize = sizeof(kRead);

	// KSCANREADEX2 kReadEx2 �ʱ�ȭ
	memset(&kReadEx2, 0, sizeof(kReadEx2));
	strcat(kReadEx2.Signature, "KSCANEX2");

	kRead.nTimeInSeconds	= 10;	// time out
	kRead.nMinLength		= 2;	// minimum data length
	kRead.nSecurity			= 1;    // security
	kReadEx2.XmitAIMID		= DISABLE;

	//User Message ��� 
	kReadEx2.hwnd = this->m_hWnd;	
	kReadEx2.UserMsg= WM_SCANDATA;

	kRead.fnCallBack = NULL; //Callback ��� ����

	kRead.dwFlags = KSCAN_FLAG_REVERSEDIRECTION;
	kRead.dwFlags |= KSCAN_FLAG_WIDESCANANGLE;


	//UPCA
	kReadEx2.UpcA.Enable		= ENABLE;
	kReadEx2.UpcA.Format		= AS_UPCA;
	kReadEx2.UpcA.XmitNumber	= XMIT_NUMBER;
	kReadEx2.UpcA.XmitCheckDigit= XMIT_CHECK_DIGIT;
	kReadEx2.UpcA.Supp			= NO_Supp;  

	//UPCE
	kReadEx2.UpcE.Enable		= ENABLE;
	kReadEx2.UpcE.Format		= AS_UPCE;
	kReadEx2.UpcE.XmitNumber	= XMIT_NUMBER;
	kReadEx2.UpcE.XmitCheckDigit= XMIT_CHECK_DIGIT;
	kReadEx2.UpcE.Supp			= NO_Supp;	// Not Supported

	//EAN13
	kReadEx2.Ean13.Enable		= ENABLE;
	kReadEx2.Ean13.Format		= AS_BOOKLAND;		// Including AS_EAN13;
	kReadEx2.Ean13.XmitNumber	= NO_XMIT_NUMBER;
	kReadEx2.Ean13.XmitCheckDigit= XMIT_CHECK_DIGIT;
	kReadEx2.Ean13.Supp			= NO_Supp;			

	//EAN8
	kReadEx2.Ean8.Enable		= ENABLE;
	kReadEx2.Ean8.Format		= AS_EAN8;
	kReadEx2.Ean8.XmitNumber	= NO_XMIT_NUMBER;
	kReadEx2.Ean8.XmitCheckDigit= XMIT_CHECK_DIGIT;   
	kReadEx2.Ean8.Supp			= NO_Supp;	// Not Supported

	//Code39
	kReadEx2.Code39.Enable		= ENABLE;
	kReadEx2.Code39.MinLength	= 4;
	kReadEx2.Code39.MaxLength	= 30;
	kReadEx2.Code39.SetAscii	= STD_ASCII;
	kReadEx2.Code39.CDV			= DISABLE;      
	kReadEx2.Code39.XmitCheckDigit= NO_XMIT_CHECK_DIGIT;
	kReadEx2.Code39.AsCode32	= ENABLE;
	kReadEx2.Code39.AsPZN		= ENABLE;

	//Code128
	kReadEx2.Code128.Enable		= ENABLE;
	kReadEx2.Code128.AsUCCEAN128= ENABLE;
	kReadEx2.Code128.FNC1_ASCII = FNC1_Ascii; //NULL: No FNC1 conversion
	kReadEx2.Code128.MinLength	= 4;
	kReadEx2.Code128.MaxLength	= 30;

	//Code93
	kReadEx2.Code93.Enable		= ENABLE;
	kReadEx2.Code93.MinLength	= 4;
	kReadEx2.Code93.MaxLength	= 30;

	//Code35
	kReadEx2.Code35.Enable		= ENABLE;

	//Code11
	kReadEx2.Code11.Enable		= ENABLE;
	kReadEx2.Code11.MinLength	= 4;
	kReadEx2.Code11.MaxLength	= 30;
	kReadEx2.Code11.CheckDigit	= DIGIT1;                          
	kReadEx2.Code11.XmitCheckDigit= NO_XMIT_CHECK_DIGIT; 

	//Interleaved 2of5
	kReadEx2.Code25.Enable		= ENABLE;
	kReadEx2.Code25.MinLength	= 4;
	kReadEx2.Code25.MaxLength	= 30;
	kReadEx2.Code25.CDV			= DISABLE;       
	kReadEx2.Code25.XmitCheckDigit= NO_XMIT_CHECK_DIGIT; 
	kReadEx2.Code25.KindofDecode = (CODE25KIND_INTER | CODE25KIND_ITF14|CODE25KIND_MATRIX | CODE25KIND_INDUSTRY | CODE25KIND_DLOGIC | CODE25KIND_IATA); 

	//Codabar
	kReadEx2.Codabar.Enable			= ENABLE;
	kReadEx2.Codabar.XmitStartStop	= NO_XMIT;
	kReadEx2.Codabar.MinLength		= 4;
	kReadEx2.Codabar.MaxLength		= 30;

	//MSI
	kReadEx2.Msi.Enable			= ENABLE;
	kReadEx2.Msi.CDV			= ENABLE;                         
	kReadEx2.Msi.XmitCheckDigit	= NO_XMIT_CHECK_DIGIT; 
	kReadEx2.Msi.MinLength		= 4;
	kReadEx2.Msi.MaxLength		= 30;

	//Plessey
	kReadEx2.Plessey.Enable		= ENABLE;
	kReadEx2.Plessey.CDV		= ENABLE;                          
	kReadEx2.Plessey.XmitCheckDigit= NO_XMIT_CHECK_DIGIT;  
	kReadEx2.Plessey.MinLength	= 4;
	kReadEx2.Plessey.MaxLength	= 30;

	//GS1
	kReadEx2.Gs1.Enable			= ENABLE;

	//GS1 Limited
	kReadEx2.Gs1Limited.Enable	= ENABLE;

	//GS1 Expanded
	kReadEx2.Gs1Expanded.Enable	= ENABLE;

	//Telepen
	kReadEx2.Telepen.Enable		= ENABLE;
	kReadEx2.Telepen.OldStyle	= DISABLE;

	kRead.pReadEx=&kReadEx2;

	SetOption(&kRead);

	SetReturn(0, NULL);	
}


LPCTSTR CM3ScanTestDlg::GetInfo()
{
	return KScanGetVersionInfo();
}

void CM3ScanTestDlg::ScanReadNB()
{
	BOOL		bRet;	

	if(m_bKeyFlag == FALSE)
	{
		if (m_bReading) 
		{	// Reading already in progress, now cancel it.
			bRet = KScanReadCancel();
			
			if (bRet) 
			{
				m_bReading = FALSE;
				return;
			} 
			else 
			{
				::MessageBox(NULL, KScanGetLastErrorMsg(), NULL, NULL);
			}
		}
		m_bKeyFlag = TRUE;

		if(m_bCon)
			m_bReading = TRUE;
		else
			m_bReading = FALSE;

		bRet =	KScanRead();	
		if (!bRet) {
			m_bReading = FALSE;
		}
	}
}

void CM3ScanTestDlg::ReadCancel()
{
	KScanReadCancel();
}

LRESULT CM3ScanTestDlg::OnScanRead(WPARAM wParam, LPARAM lParam)
{
	ScanRead((LPVOID)wParam);
	return FALSE;
}

int KSCANAPI KScanReadCallBack(LPVOID pRead)
{
	CM3ScanTestApp * pApp = (CM3ScanTestApp*)AfxGetApp();
	CM3ScanTestDlg * pDlg = (CM3ScanTestDlg *)pApp->GetMainWnd();

	pDlg->ScanRead(pRead); 

	return ((PKSCANREAD)pRead)->out_Status;
}

void CM3ScanTestDlg::ScanRead(LPVOID pRead)
{

	pRead	= &kRead;

	int			Status = kRead.out_Status;
	int			Type;
	CString		strData;
	HINSTANCE hInst = AfxGetInstanceHandle();

	CString aa;

	

	switch(Status) {
		case KSCAN_RET_TIMEOUT:			// Timed out.
		case KSCAN_RET_USER_CANCEL:		// User called stop
		case KSCAN_RET_NORMAL:		// Barcode was read
		case KSCAN_RET_TYPE_UNKNOWN: 
			Status = 0;
			m_bReading = FALSE;
			break;

		case KSCAN_RET_BAR_NOTFOUND:	// Not yet found - Continue.
		case KSCAN_RET_NORMAL_SWEEP:	// barcode was read, and security criteria was not met yet
			Status = 1;
			break;

		default:	// Other error.
			Status = 0;					// just continue reading until barcode was read with security criteria met
			m_bReading = FALSE;
			break;
	}
	if (Status == 0)
	{
		
		if(((PKSCANREAD)pRead)->out_Status == KSCAN_RET_NORMAL)
		{
			Type = ((PKSCANREAD)pRead)->out_Type;
			g_strType = KScanSetBarCodeString(Type);
			strData.Format(_T("%S"), ((PKSCANREAD)pRead)->out_Barcode);
			m_ScanPage.Write_ListCtrl(g_strType, strData);

			if(m_SymbologyPage.m_bVibrate == TRUE)
			{
				VibrateOn(TRUE);
				Sleep(100);
				VibrateOn(FALSE);	
			}
			

			if(m_SymbologyPage.m_nSound == 0)
				PlaySound(MAKEINTRESOURCE(IDR_SCAN_WAVE), hInst, SND_RESOURCE|SND_ASYNC);
			else if(m_SymbologyPage.m_nSound == 1)
					PlaySound(MAKEINTRESOURCE(IDR_WAVE_BEEP), hInst, SND_RESOURCE|SND_ASYNC);	
			
		}		
	}
}

void CM3ScanTestDlg::SetReadOption(void)
{
	kReadEx2.UpcA.Enable = (ABLE)m_bUpca;
	kRead.pReadEx=&kReadEx2;	

	SetOption(&kRead);

	m_SymbologyPage.m_bUpce			= kReadEx2.UpcE.Enable;
	m_SymbologyPage.m_bEan13		= kReadEx2.Ean13.Enable;
	m_SymbologyPage.m_bEan8			= kReadEx2.Ean8.Enable;
	m_SymbologyPage.m_bCode39		= kReadEx2.Code39.Enable;
	m_SymbologyPage.m_bCode128		= kReadEx2.Code128.Enable;
	m_SymbologyPage.m_bCode93		= kReadEx2.Code93.Enable;
	m_SymbologyPage.m_bCode35		= kReadEx2.Code35.Enable;
	m_SymbologyPage.m_bCode11		= kReadEx2.Code11.Enable;
	m_SymbologyPage.m_bI2of5		= kReadEx2.Code25.Enable;
	m_SymbologyPage.m_bCodabar		= kReadEx2.Codabar.Enable;
	m_SymbologyPage.m_bMsi			= kReadEx2.Msi.Enable;
	m_SymbologyPage.m_bPlessey		= kReadEx2.Plessey.Enable;
	m_SymbologyPage.m_bGs1			= kReadEx2.Gs1.Enable;
	m_SymbologyPage.m_bGs1Expanded	= kReadEx2.Gs1Expanded.Enable;
	m_SymbologyPage.m_bGs1Limited	= kReadEx2.Gs1Limited.Enable;
	m_SymbologyPage.m_bUccean128	= kReadEx2.Code128.AsUCCEAN128;
	m_SymbologyPage.m_bCode32		= kReadEx2.Code39.AsCode32;
	m_SymbologyPage.m_bPzn			= kReadEx2.Code39.AsPZN;
	m_SymbologyPage.m_bTelepen		= kReadEx2.Telepen.Enable;

	if(kReadEx2.Ean13.Format == AS_BOOKLAND)
		m_SymbologyPage.m_bBookLand = TRUE;
	else
		m_SymbologyPage.m_bBookLand = FALSE;

	m_SymbologyPage.m_ctrlComboTimeOut.SetCurSel(kRead.nTimeInSeconds-1);
	m_SymbologyPage.m_ctrlComboSecurityLevel.SetCurSel(kRead.nSecurity-1);
	m_SymbologyPage.m_bXmitAIMID	= kReadEx2.XmitAIMID;
	m_SymbologyPage.m_bUpca			= m_bUpca;

	UpdateData(FALSE);
}


void CM3ScanTestDlg::Set_ContinueMode(BOOL bContinue)
{
	SetContinueMode(bContinue);
}

BOOL CM3ScanTestDlg::Get_ContinueMode(void)
{
	return GetContinueMode();
}
