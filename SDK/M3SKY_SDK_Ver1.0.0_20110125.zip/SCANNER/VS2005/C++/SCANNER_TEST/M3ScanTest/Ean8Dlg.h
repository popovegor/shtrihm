#pragma once


// CEan8Dlg dialog

class CEan8Dlg : public CDialog
{
	DECLARE_DYNAMIC(CEan8Dlg)

public:
	CEan8Dlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CEan8Dlg();

// Dialog Data
	enum { IDD = IDD_EAN8_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	BOOL m_bEnable;
	BOOL m_bXCD;
	BOOL m_bEan8AsEan13;
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	void GetOption(void);
	void SetOption(void);
};
