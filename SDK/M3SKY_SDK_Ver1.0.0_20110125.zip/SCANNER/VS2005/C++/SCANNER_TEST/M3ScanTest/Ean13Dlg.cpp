// Ean13Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "Ean13Dlg.h"
#include "M3ScanTestDlg.h"

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;


// CEan13Dlg dialog

IMPLEMENT_DYNAMIC(CEan13Dlg, CDialog)

CEan13Dlg::CEan13Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEan13Dlg::IDD, pParent)
	, m_bEnable(FALSE)
	, m_bEnableBookland(FALSE)
	, m_bXCD(FALSE)
	, m_bSupp(FALSE)
{

}

CEan13Dlg::~CEan13Dlg()
{
}

void CEan13Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_BOOKLAND, m_bEnableBookland);
	DDX_Check(pDX, IDC_CHECK_XCD, m_bXCD);
	DDX_Check(pDX, IDC_CHECK_SUPP, m_bSupp);
}


BEGIN_MESSAGE_MAP(CEan13Dlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, &CEan13Dlg::OnConfirm)
END_MESSAGE_MAP()


// CEan13Dlg message handlers

BOOL CEan13Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CEan13Dlg::OnConfirm()
{
	SetOption();

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	dlg->SetReadOption();

	CDialog::OnOK();
}

void CEan13Dlg::GetOption(void)
{
	if(kReadEx2.Ean13.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;

	if((kReadEx2.Ean13.Format == AS_BOOKLAND) && (kReadEx2.Ean13.Enable == ENABLE))
		m_bEnableBookland = TRUE;
	else
		m_bEnableBookland = FALSE;

	if(kReadEx2.Ean13.XmitCheckDigit == XMIT_CHECK_DIGIT)
		m_bXCD = TRUE;
	else
		m_bXCD = FALSE;

	if(kReadEx2.Ean13.Supp == WITH_OR_WITHOUT)
		m_bSupp = TRUE;
	else
		m_bSupp = FALSE;

	UpdateData(FALSE);
}

void CEan13Dlg::SetOption(void)
{
	UpdateData(TRUE);

	if(m_bEnable == TRUE)
		kReadEx2.Ean13.Enable = ENABLE;
	else
		kReadEx2.Ean13.Enable = DISABLE;

	if(m_bEnableBookland == TRUE)
	{
		kReadEx2.Ean13.Enable = ENABLE;
		kReadEx2.Ean13.Format = AS_BOOKLAND;
	}
	else
		kReadEx2.Ean13.Format = AS_EAN13;

	if(m_bXCD == TRUE)
		kReadEx2.Ean13.XmitCheckDigit = XMIT_CHECK_DIGIT;
	else
		kReadEx2.Ean13.XmitCheckDigit = NO_XMIT_CHECK_DIGIT;

	if(m_bSupp == TRUE)
		kReadEx2.Ean13.Supp = WITH_OR_WITHOUT;
	else
		kReadEx2.Ean13.Supp = NO_Supp;
}
