// TelepenDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "TelepenDlg.h"
#include "M3ScanTestDlg.h"

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;


// CTelepenDlg dialog

IMPLEMENT_DYNAMIC(CTelepenDlg, CDialog)

CTelepenDlg::CTelepenDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTelepenDlg::IDD, pParent)
	, m_bEnable(FALSE)
	, m_bOldStyle(FALSE)
{

}

CTelepenDlg::~CTelepenDlg()
{
}

void CTelepenDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_OLDSTYLE, m_bOldStyle);
}


BEGIN_MESSAGE_MAP(CTelepenDlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, &CTelepenDlg::OnConfirm)
END_MESSAGE_MAP()


// CTelepenDlg message handlers

BOOL CTelepenDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CTelepenDlg::OnConfirm()
{
	SetOption();

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	dlg->SetReadOption();

	CDialog::OnOK();
}

void CTelepenDlg::GetOption(void)
{
	if(kReadEx2.Telepen.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;

	if(kReadEx2.Telepen.OldStyle == ENABLE)
		m_bOldStyle = TRUE;
	else
		m_bOldStyle = FALSE;

	UpdateData(FALSE);
}

void CTelepenDlg::SetOption(void)
{
	UpdateData(TRUE);

	if(m_bEnable == TRUE)
		kReadEx2.Telepen.Enable = ENABLE;
	else
		kReadEx2.Telepen.Enable = DISABLE;

	if(m_bOldStyle == TRUE)
		kReadEx2.Telepen.OldStyle = ENABLE;
	else
		kReadEx2.Telepen.OldStyle = DISABLE;

}
