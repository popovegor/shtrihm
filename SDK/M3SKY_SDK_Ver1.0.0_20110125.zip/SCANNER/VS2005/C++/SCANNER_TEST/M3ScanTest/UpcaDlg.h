#pragma once


// CUpcaDlg dialog

class CUpcaDlg : public CDialog
{
	DECLARE_DYNAMIC(CUpcaDlg)

public:
	CUpcaDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CUpcaDlg();

// Dialog Data
	enum { IDD = IDD_UPCA_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	void GetOption(void);
	void SetOption(void);
	BOOL m_bEnable;
	BOOL m_bXmitNum;
	BOOL m_bXCD;
	BOOL m_bUpcaAsEan13;
	BOOL m_bSupp;
};
