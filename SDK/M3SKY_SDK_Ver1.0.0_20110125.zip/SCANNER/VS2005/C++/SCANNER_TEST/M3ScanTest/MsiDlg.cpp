// MsiDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "MsiDlg.h"
#include "M3ScanTestDlg.h"

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;


// CMsiDlg dialog

IMPLEMENT_DYNAMIC(CMsiDlg, CDialog)

CMsiDlg::CMsiDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMsiDlg::IDD, pParent)
	, m_bEnable(FALSE)
	, m_bCDV(FALSE)
	, m_bXCD(FALSE)
	, m_nMinLen(0)
	, m_nMaxLen(0)
{

}

CMsiDlg::~CMsiDlg()
{
}

void CMsiDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_CDV, m_bCDV);
	DDX_Check(pDX, IDC_CHECK_XCD, m_bXCD);
	DDX_Text(pDX, IDC_EDIT_MIN, m_nMinLen);
	DDX_Text(pDX, IDC_EDIT_MAX, m_nMaxLen);
}


BEGIN_MESSAGE_MAP(CMsiDlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, &CMsiDlg::OnConfirm)
END_MESSAGE_MAP()


// CMsiDlg message handlers

BOOL CMsiDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CMsiDlg::OnConfirm()
{
	SetOption();

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	dlg->SetReadOption();

	CDialog::OnOK();
}

void CMsiDlg::GetOption(void)
{
	if(kReadEx2.Msi.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;

	if(kReadEx2.Msi.CDV == ENABLE)
		m_bCDV = TRUE;
	else
		m_bCDV = FALSE;

	if(kReadEx2.Msi.XmitCheckDigit == XMIT_CHECK_DIGIT)
		m_bXCD = TRUE;
	else
		m_bXCD = FALSE;

	m_nMaxLen = kReadEx2.Msi.MaxLength;
	m_nMinLen = kReadEx2.Msi.MinLength;

	UpdateData(FALSE);
}

void CMsiDlg::SetOption(void)
{
	UpdateData(TRUE);

	if(m_bEnable == TRUE)
		kReadEx2.Msi.Enable = ENABLE;
	else
		kReadEx2.Msi.Enable = DISABLE;

	if(m_bCDV == TRUE)
		kReadEx2.Msi.CDV = ENABLE;
	else
		kReadEx2.Msi.CDV = DISABLE;

	if(m_bXCD == TRUE)
		kReadEx2.Msi.XmitCheckDigit = XMIT_CHECK_DIGIT;
	else
		kReadEx2.Msi.XmitCheckDigit = NO_XMIT_CHECK_DIGIT;

	kReadEx2.Msi.MaxLength = m_nMaxLen;
	kReadEx2.Msi.MinLength = m_nMinLen;
}
