// Ean8Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "Ean8Dlg.h"
#include "M3ScanTestDlg.h"

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;


// CEan8Dlg dialog

IMPLEMENT_DYNAMIC(CEan8Dlg, CDialog)

CEan8Dlg::CEan8Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEan8Dlg::IDD, pParent)
	, m_bEnable(FALSE)
	, m_bXCD(FALSE)
	, m_bEan8AsEan13(FALSE)
{

}

CEan8Dlg::~CEan8Dlg()
{
}

void CEan8Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_XCD, m_bXCD);
	DDX_Check(pDX, IDC_CHECK_CONVERT, m_bEan8AsEan13);
}


BEGIN_MESSAGE_MAP(CEan8Dlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, &CEan8Dlg::OnConfirm)
END_MESSAGE_MAP()


// CEan8Dlg message handlers

BOOL CEan8Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CEan8Dlg::OnConfirm()
{
	SetOption();

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	dlg->SetReadOption();

	CDialog::OnOK();
}

void CEan8Dlg::GetOption(void)
{
	if(kReadEx2.Ean8.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;

	if(kReadEx2.Ean8.XmitCheckDigit == XMIT_CHECK_DIGIT)
		m_bXCD = TRUE;
	else
		m_bXCD = FALSE;

	if(kReadEx2.Ean8.Format == AS_EAN13)
		m_bEan8AsEan13 = TRUE;
	else
		m_bEan8AsEan13 = FALSE;

	UpdateData(FALSE);
}

void CEan8Dlg::SetOption(void)
{
	UpdateData(TRUE);

	if(m_bEnable == TRUE)
		kReadEx2.Ean8.Enable = ENABLE;
	else
		kReadEx2.Ean8.Enable = DISABLE;

	if(m_bXCD == TRUE)
		kReadEx2.Ean8.XmitCheckDigit = XMIT_CHECK_DIGIT;
	else
		kReadEx2.Ean8.XmitCheckDigit = NO_XMIT_CHECK_DIGIT;

	if(m_bEan8AsEan13 == TRUE)
		kReadEx2.Ean8.Format = AS_EAN13;
	else
		kReadEx2.Ean8.Format = AS_EAN8;
}
