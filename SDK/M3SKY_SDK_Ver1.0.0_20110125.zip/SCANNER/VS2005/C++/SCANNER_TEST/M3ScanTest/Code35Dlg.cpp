// Code35Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "Code35Dlg.h"
#include "M3ScanTestDlg.h"

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;


// CCode35Dlg dialog

IMPLEMENT_DYNAMIC(CCode35Dlg, CDialog)

CCode35Dlg::CCode35Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCode35Dlg::IDD, pParent)
	, m_bEnable(FALSE)
{

}

CCode35Dlg::~CCode35Dlg()
{
}

void CCode35Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
}


BEGIN_MESSAGE_MAP(CCode35Dlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, &CCode35Dlg::OnConfirm)
END_MESSAGE_MAP()


// CCode35Dlg message handlers

BOOL CCode35Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CCode35Dlg::OnConfirm()
{
	SetOption();

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	dlg->SetReadOption();

	CDialog::OnOK();
}

void CCode35Dlg::GetOption(void)
{
	if(kReadEx2.Code35.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;

	UpdateData(FALSE);
}

void CCode35Dlg::SetOption(void)
{
	UpdateData(TRUE);

	if(m_bEnable == TRUE)
		kReadEx2.Code35.Enable = ENABLE;
	else
		kReadEx2.Code35.Enable = DISABLE;
}
