// OptionPage.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "OptionPage.h"
#include "M3ScanTestDlg.h"

//BarCode Dialog
#include "UpcaDlg.h"
#include "UpceDlg.h"
#include "Ean13Dlg.h"
#include "Ean8Dlg.h"
#include "Code39Dlg.h"
#include "Code128Dlg.h"
#include "Code93Dlg.h"
#include "Code35Dlg.h"
#include "Code11Dlg.h"
#include "I2of5Dlg.h"
#include "CodabarDlg.h"
#include "MsiDlg.h"
#include "PlesseyDlg.h"
#include "Gs1dlg.h"
#include "Gs1LimitedDlg.h"
#include "Gs1Expanded.h"
#include "TelepenDlg.h"

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;

// COptionPage dialog

IMPLEMENT_DYNAMIC(COptionPage, CPropertyPage)

COptionPage::COptionPage()
	: CPropertyPage(COptionPage::IDD)
	, m_bWideScan(FALSE)
	, m_bHighFilter(FALSE)
	, m_nContinue(0)
{

}

COptionPage::~COptionPage()
{
}

void COptionPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_WIDESCAN, m_bWideScan);
	DDX_Check(pDX, IDC_CHECK_HIGHFILTER, m_bHighFilter);
	DDX_Radio(pDX, IDC_RADIO_NOCON, m_nContinue);
}


BEGIN_MESSAGE_MAP(COptionPage, CPropertyPage)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, &COptionPage::OnConfirm)
	ON_BN_CLICKED(IDC_BTN_UPCA, &COptionPage::OnUpca)
	ON_BN_CLICKED(IDC_BTN_UPCE, &COptionPage::OnUpce)
	ON_BN_CLICKED(IDC_BTN_EAN13, &COptionPage::OnEan13)
	ON_BN_CLICKED(IDC_BTN_EAN8, &COptionPage::OnEan8)
	ON_BN_CLICKED(IDC_BTN_CODE39, &COptionPage::OnCode39)
	ON_BN_CLICKED(IDC_BTN_CODE128, &COptionPage::OnCode128)
	ON_BN_CLICKED(IDC_BTN_CODE93, &COptionPage::OnCode93)
	ON_BN_CLICKED(IDC_BTN_CODE35, &COptionPage::OnCode35)
	ON_BN_CLICKED(IDC_BTN_CODE11, &COptionPage::OnCode11)
	ON_BN_CLICKED(IDC_BTN_I2OF5, &COptionPage::OnI2of5)
	ON_BN_CLICKED(IDC_BTN_CODABAR, &COptionPage::OnCodabar)
	ON_BN_CLICKED(IDC_BTN_MSI, &COptionPage::OnMsi)
	ON_BN_CLICKED(IDC_BTN_PLESSEY, &COptionPage::OnPlessey)
	ON_BN_CLICKED(IDC_BTN_GS1, &COptionPage::OnGs1)
	ON_BN_CLICKED(IDC_BTN_GS1LIMITED, &COptionPage::OnGs1Limited)
	ON_BN_CLICKED(IDC_BTN_GS1EXPANDED, &COptionPage::OnGs1Expanded)
	ON_BN_CLICKED(IDC_BTN_TELEPEN, &COptionPage::OnTelepen)
END_MESSAGE_MAP()


// COptionPage message handlers

BOOL COptionPage::OnInitDialog()
{
	CPropertyPage::OnInitDialog();

	GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void COptionPage::OnConfirm()
{
	SetOption();

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	if(m_nContinue == 1)
	{
		dlg->Set_ContinueMode(TRUE);
		dlg->m_bCon = TRUE;
		dlg->m_bSyncMode = TRUE;
	}
	else
	{
		dlg->Set_ContinueMode(FALSE);
		dlg->m_bCon = FALSE;		
	}

	dlg->SetReadOption();

	(CPropertySheet *)GetParent()->SendMessage(PSM_SETCURSEL, 0);	
}

void COptionPage::GetOption(void)
{
	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();
	
	if(dlg->Get_ContinueMode() == TRUE)
		m_nContinue = 1;
	else
		m_nContinue = 0;

	if(kRead.dwFlags & KSCAN_FLAG_HIGHFILTERMODE)
		m_bHighFilter = TRUE;
	else
		m_bHighFilter = FALSE;

	if(kRead.dwFlags & KSCAN_FLAG_WIDESCANANGLE)
		m_bWideScan=TRUE;
	else
		m_bWideScan=FALSE;



	UpdateData(FALSE);
}

void COptionPage::SetOption(void)
{
	UpdateData(TRUE);

	kRead.dwFlags = 0;

	kRead.dwFlags = KSCAN_FLAG_REVERSEDIRECTION;

	if(m_bHighFilter == TRUE)
		kRead.dwFlags |= KSCAN_FLAG_HIGHFILTERMODE;

	if(m_bWideScan == TRUE)
		kRead.dwFlags |= KSCAN_FLAG_WIDESCANANGLE;
}



void COptionPage::OnUpca()
{
	CUpcaDlg dlg;
	dlg.DoModal();
}

void COptionPage::OnUpce()
{
	CUpceDlg dlg;
	dlg.DoModal();
}

void COptionPage::OnEan13()
{
	CEan13Dlg dlg;
	dlg.DoModal();
}

void COptionPage::OnEan8()
{
	CEan8Dlg dlg;
	dlg.DoModal();
}

void COptionPage::OnCode39()
{
	CCode39Dlg dlg;
	dlg.DoModal();
}

void COptionPage::OnCode128()
{
	CCode128Dlg dlg;
	dlg.DoModal();
}

void COptionPage::OnCode93()
{
	CCode93Dlg dlg;
	dlg.DoModal();
}

void COptionPage::OnCode35()
{
	CCode35Dlg dlg;
	dlg.DoModal();
}

void COptionPage::OnCode11()
{
	CCode11Dlg dlg;
	dlg.DoModal();
}

void COptionPage::OnI2of5()
{
	CI2of5Dlg dlg;
	dlg.DoModal();
}

void COptionPage::OnCodabar()
{
	CCodabarDlg dlg;
	dlg.DoModal();
}

void COptionPage::OnMsi()
{
	CMsiDlg dlg;
	dlg.DoModal();
}

void COptionPage::OnPlessey()
{
	CPlesseyDlg dlg;
	dlg.DoModal();
}

void COptionPage::OnGs1()
{
	CGs1dlg dlg;
	dlg.DoModal();
}

void COptionPage::OnGs1Limited()
{
	CGs1LimitedDlg dlg;
	dlg.DoModal();
}

void COptionPage::OnGs1Expanded()
{
	CGs1Expanded dlg;
	dlg.DoModal();
}

void COptionPage::OnTelepen()
{
	CTelepenDlg dlg;
	dlg.DoModal();
}
