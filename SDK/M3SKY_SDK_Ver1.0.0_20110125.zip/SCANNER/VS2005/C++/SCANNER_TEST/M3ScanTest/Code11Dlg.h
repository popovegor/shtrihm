#pragma once


// CCode11Dlg dialog

class CCode11Dlg : public CDialog
{
	DECLARE_DYNAMIC(CCode11Dlg)

public:
	CCode11Dlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCode11Dlg();

// Dialog Data
	enum { IDD = IDD_CODE11_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	BOOL m_bEnable;
	BOOL m_bXCD;
	int m_nCdv;
	int m_nMinLen;
	int m_nMaxLen;
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	void GetOption(void);
	void SetOption(void);
	
};
