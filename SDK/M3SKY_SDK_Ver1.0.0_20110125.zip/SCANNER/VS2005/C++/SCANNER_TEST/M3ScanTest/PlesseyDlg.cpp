// PlesseyDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "PlesseyDlg.h"
#include "M3ScanTestDlg.h"

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;


// CPlesseyDlg dialog

IMPLEMENT_DYNAMIC(CPlesseyDlg, CDialog)

CPlesseyDlg::CPlesseyDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPlesseyDlg::IDD, pParent)
	, m_bEnable(FALSE)
	, m_bCDV(FALSE)
	, m_bXCD(FALSE)
	, m_nMinLen(0)
	, m_nMaxLen(0)
{

}

CPlesseyDlg::~CPlesseyDlg()
{
}

void CPlesseyDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_CDV, m_bCDV);
	DDX_Check(pDX, IDC_CHECK_XCD, m_bXCD);
	DDX_Text(pDX, IDC_EDIT_MIN, m_nMinLen);
	DDX_Text(pDX, IDC_EDIT_MAX, m_nMaxLen);
}


BEGIN_MESSAGE_MAP(CPlesseyDlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, &CPlesseyDlg::OnConfirm)
END_MESSAGE_MAP()


// CPlesseyDlg message handlers

BOOL CPlesseyDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CPlesseyDlg::OnConfirm()
{
	SetOption();

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	dlg->SetReadOption();

	CDialog::OnOK();
}

void CPlesseyDlg::GetOption(void)
{
	if(kReadEx2.Plessey.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;

	if(kReadEx2.Plessey.CDV == ENABLE)
		m_bCDV = TRUE;
	else
		m_bCDV = FALSE;

	if(kReadEx2.Plessey.XmitCheckDigit == XMIT_CHECK_DIGIT)
		m_bXCD = TRUE;
	else
		m_bXCD = FALSE;

	m_nMaxLen = kReadEx2.Plessey.MaxLength;
	m_nMinLen = kReadEx2.Plessey.MinLength;

	UpdateData(FALSE);
}

void CPlesseyDlg::SetOption(void)
{
	UpdateData(TRUE);

	if(m_bEnable == TRUE)
		kReadEx2.Plessey.Enable = ENABLE;
	else
		kReadEx2.Plessey.Enable = DISABLE;

	if(m_bCDV == TRUE)
		kReadEx2.Plessey.CDV = ENABLE;
	else
		kReadEx2.Plessey.CDV = DISABLE;

	if(m_bXCD == TRUE)
		kReadEx2.Plessey.XmitCheckDigit = XMIT_CHECK_DIGIT;
	else
		kReadEx2.Plessey.XmitCheckDigit = NO_XMIT_CHECK_DIGIT;

	kReadEx2.Plessey.MaxLength = m_nMaxLen;
	kReadEx2.Plessey.MinLength = m_nMinLen;
}
