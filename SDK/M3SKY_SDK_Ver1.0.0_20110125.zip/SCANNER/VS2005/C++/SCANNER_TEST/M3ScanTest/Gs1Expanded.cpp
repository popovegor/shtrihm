// Gs1Expanded.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "Gs1Expanded.h"
#include "M3ScanTestDlg.h"

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;


// CGs1Expanded dialog

IMPLEMENT_DYNAMIC(CGs1Expanded, CDialog)

CGs1Expanded::CGs1Expanded(CWnd* pParent /*=NULL*/)
	: CDialog(CGs1Expanded::IDD, pParent)
	, m_bEnable(FALSE)
{

}

CGs1Expanded::~CGs1Expanded()
{
}

void CGs1Expanded::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
}


BEGIN_MESSAGE_MAP(CGs1Expanded, CDialog)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, &CGs1Expanded::OnConfirm)
END_MESSAGE_MAP()


// CGs1Expanded message handlers

BOOL CGs1Expanded::OnInitDialog()
{
	CDialog::OnInitDialog();

	GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CGs1Expanded::OnConfirm()
{
	SetOption();

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	dlg->SetReadOption();

	CDialog::OnOK();
}

void CGs1Expanded::GetOption(void)
{
	if(kReadEx2.Gs1Expanded.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;

	UpdateData(FALSE);
}

void CGs1Expanded::SetOption(void)
{
	UpdateData(TRUE);

	if(m_bEnable == TRUE)
		kReadEx2.Gs1Expanded.Enable = ENABLE;
	else
		kReadEx2.Gs1Expanded.Enable = DISABLE;
}
