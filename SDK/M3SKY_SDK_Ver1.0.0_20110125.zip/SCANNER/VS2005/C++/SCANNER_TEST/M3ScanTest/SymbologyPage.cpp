// SymbologyPage.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "SymbologyPage.h"
#include "M3ScanTestDlg.h"

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;

// CSymbologyPage dialog

IMPLEMENT_DYNAMIC(CSymbologyPage, CPropertyPage)

CSymbologyPage::CSymbologyPage()
	: CPropertyPage(CSymbologyPage::IDD)
	, m_nSound(0)
{
	m_bCodabar		= TRUE;
	m_bCode11		= TRUE;
	m_bCode128		= TRUE;
	m_bCode35		= TRUE;
	m_bCode39		= TRUE;
	m_bCode93		= TRUE;
	m_bEan13		= TRUE;
	m_bEan8			= TRUE;
	m_bGs1			= TRUE;
	m_bGs1Expanded	= TRUE;
	m_bGs1Limited	= TRUE;
	m_bI2of5		= TRUE;
	m_bMsi			= TRUE;
	m_bPlessey		= TRUE;
	m_bUpca			= TRUE;
	m_bUpce			= TRUE;
	m_bBookLand		= TRUE;
	m_bCode32		= TRUE;
	m_bPzn			= TRUE;
	m_bUccean128	= TRUE;
	m_bTelepen		= TRUE;

	m_bXmitAIMID	= FALSE;
	m_bVibrate		= FALSE;
	m_nSyncMode		= 0;

}

CSymbologyPage::~CSymbologyPage()
{
}

void CSymbologyPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_UPCA, m_bUpca);
	DDX_Check(pDX, IDC_CHECK_UPCE, m_bUpce);
	DDX_Check(pDX, IDC_CHECK_EAN13, m_bEan13);
	DDX_Check(pDX, IDC_CHECK_BOOKLAND, m_bBookLand);
	DDX_Check(pDX, IDC_CHECK_EAN8, m_bEan8);
	DDX_Check(pDX, IDC_CHECK_CODE32, m_bCode32);
	DDX_Check(pDX, IDC_CHECK_CODE39, m_bCode39);
	DDX_Check(pDX, IDC_CHECK_PZN, m_bPzn);
	DDX_Check(pDX, IDC_CHECK_CODE128, m_bCode128);
	DDX_Check(pDX, IDC_CHECK_UCCEAN128, m_bUccean128);
	DDX_Check(pDX, IDC_CHECK_CODE93, m_bCode93);
	DDX_Check(pDX, IDC_CHECK_CODE35, m_bCode35);
	DDX_Check(pDX, IDC_CHECK_CODE11, m_bCode11);
	DDX_Check(pDX, IDC_CHECK_I2OF5, m_bI2of5);
	DDX_Check(pDX, IDC_CHECK_MSI, m_bMsi);
	DDX_Check(pDX, IDC_CHECK_PLESSEY, m_bPlessey);
	DDX_Check(pDX, IDC_CHECK_CODABAR, m_bCodabar);
	DDX_Check(pDX, IDC_CHECK_GS1, m_bGs1);
	DDX_Check(pDX, IDC_CHECK_GS1LIMITED, m_bGs1Limited);
	DDX_Check(pDX, IDC_CHECK_EXPANDED, m_bGs1Expanded);
	DDX_Check(pDX, IDC_CHECK_VIBRATE, m_bVibrate);
	DDX_Radio(pDX, IDC_RADIO_ASYNC, m_nSyncMode);
	DDX_Check(pDX, IDC_CHECK_XMITAIMID, m_bXmitAIMID);
	DDX_Check(pDX, IDC_CHECK_TELEPEN, m_bTelepen);
	DDX_Radio(pDX, IDC_RADIO_DEFAULT, m_nSound);
	DDX_Control(pDX, IDC_COMBO_TIMEOUT, m_ctrlComboTimeOut);
	DDX_Control(pDX, IDC_COMBO_SECURITYLEVEL, m_ctrlComboSecurityLevel);
}


BEGIN_MESSAGE_MAP(CSymbologyPage, CPropertyPage)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, &CSymbologyPage::OnConfirm)
END_MESSAGE_MAP()


// CSymbologyPage message handlers

BOOL CSymbologyPage::OnInitDialog()
{
	CPropertyPage::OnInitDialog();

	m_ctrlComboTimeOut.InsertString(0, L"1");
	m_ctrlComboTimeOut.InsertString(1, L"2");
	m_ctrlComboTimeOut.InsertString(2, L"3");
	m_ctrlComboTimeOut.InsertString(3, L"4");
	m_ctrlComboTimeOut.InsertString(4, L"5");
	m_ctrlComboTimeOut.InsertString(5, L"6");
	m_ctrlComboTimeOut.InsertString(6, L"7");
	m_ctrlComboTimeOut.InsertString(7, L"8");
	m_ctrlComboTimeOut.InsertString(8, L"9");
	m_ctrlComboTimeOut.InsertString(9, L"10");

	m_ctrlComboSecurityLevel.InsertString(0, L"1");
	m_ctrlComboSecurityLevel.InsertString(1, L"2");
	m_ctrlComboSecurityLevel.InsertString(2, L"3");
	m_ctrlComboSecurityLevel.InsertString(3, L"4");

	GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CSymbologyPage::OnConfirm()
{
	SetOption();

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	dlg->SetReadOption();

	//���� ��ư�� Ŭ���ϸ� �� �������� �̵��մϴ�.
	(CPropertySheet *)GetParent()->SendMessage(PSM_SETCURSEL, 0);
}

void CSymbologyPage::GetOption(void)
{
//	m_bUpca			= kReadEx2.UpcA.Enable;

	if(kReadEx2.UpcA.Enable == DISABLE)
	{
		m_bUpca = FALSE;
	}
	else
	{
		m_bUpca = TRUE;
	}

	m_bUpce			= kReadEx2.UpcE.Enable;
	m_bEan13		= kReadEx2.Ean13.Enable;
	m_bEan8			= kReadEx2.Ean8.Enable;
	m_bCode39		= kReadEx2.Code39.Enable;
	m_bCode128		= kReadEx2.Code128.Enable;
	m_bCode93		= kReadEx2.Code93.Enable;
	m_bCode35		= kReadEx2.Code35.Enable;
	m_bCode11		= kReadEx2.Code11.Enable;
	m_bI2of5		= kReadEx2.Code25.Enable;
	m_bCodabar		= kReadEx2.Codabar.Enable;
	m_bMsi			= kReadEx2.Msi.Enable;
	m_bPlessey		= kReadEx2.Plessey.Enable;
	m_bGs1			= kReadEx2.Gs1.Enable;
	m_bGs1Expanded	= kReadEx2.Gs1Expanded.Enable;
	m_bGs1Limited	= kReadEx2.Gs1Limited.Enable;
	m_bUccean128	= kReadEx2.Code128.AsUCCEAN128;
	m_bCode32		= kReadEx2.Code39.AsCode32;
	m_bPzn			= kReadEx2.Code39.AsPZN;
	m_bTelepen		= kReadEx2.Telepen.Enable;

	if(kReadEx2.Ean13.Format == AS_BOOKLAND)
		m_bBookLand = TRUE;
	else
		m_bBookLand = FALSE;

	m_ctrlComboTimeOut.SetCurSel(kRead.nTimeInSeconds-1);
	m_ctrlComboSecurityLevel.SetCurSel(kRead.nSecurity-1);
	m_bXmitAIMID	= kReadEx2.XmitAIMID;

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();
	if(dlg->m_bSyncMode == TRUE)
		m_nSyncMode = 1;
	else
		m_nSyncMode = 0;

	UpdateData(FALSE);
}

void CSymbologyPage::SetOption(void)
{
	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();
	UpdateData(TRUE);

	kReadEx2.UpcA.Enable		= (ABLE)m_bUpca;
	kReadEx2.UpcE.Enable		= (ABLE)m_bUpce;
	kReadEx2.Ean13.Enable		= (ABLE)m_bEan13;
	kReadEx2.Ean8.Enable		= (ABLE)m_bEan8;
	kReadEx2.Code39.Enable		= (ABLE)m_bCode39;
	kReadEx2.Code128.Enable		= (ABLE)m_bCode128;
	kReadEx2.Code93.Enable		= (ABLE)m_bCode93;
	kReadEx2.Code35.Enable		= (ABLE)m_bCode35;
	kReadEx2.Code11.Enable		= (ABLE)m_bCode11;
	kReadEx2.Code25.Enable		= (ABLE)m_bI2of5;
	kReadEx2.Codabar.Enable		= (ABLE)m_bCodabar;
	kReadEx2.Msi.Enable			= (ABLE)m_bMsi;
	kReadEx2.Plessey.Enable		= (ABLE)m_bPlessey;
	kReadEx2.Gs1.Enable			= (ABLE)m_bGs1;
	kReadEx2.Gs1Limited.Enable	= (ABLE)m_bGs1Limited;
	kReadEx2.Gs1Expanded.Enable	= (ABLE)m_bGs1Expanded;
	kReadEx2.Code128.AsUCCEAN128= (ABLE)m_bUccean128;
	kReadEx2.Code39.AsCode32	= (ABLE)m_bCode32;
	kReadEx2.Code39.AsPZN		= (ABLE)m_bPzn;
	kReadEx2.Telepen.Enable		= (ABLE)m_bTelepen;

	if(m_bBookLand == TRUE)
		kReadEx2.Ean13.Format = AS_BOOKLAND;
	else
		kReadEx2.Ean13.Format = AS_EAN13;

	kRead.nTimeInSeconds		= m_ctrlComboTimeOut.GetCurSel()+1;
	kRead.nSecurity				= m_ctrlComboSecurityLevel.GetCurSel()+1;
	kReadEx2.XmitAIMID			= (ABLE)m_bXmitAIMID;
	dlg->m_bUpca				= m_bUpca;

	if(m_nSyncMode == 1)
		dlg->m_bSyncMode = TRUE;
	else
		dlg->m_bSyncMode = FALSE;
}
