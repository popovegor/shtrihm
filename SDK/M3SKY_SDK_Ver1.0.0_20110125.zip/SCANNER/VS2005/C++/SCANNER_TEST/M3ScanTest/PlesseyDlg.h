#pragma once


// CPlesseyDlg dialog

class CPlesseyDlg : public CDialog
{
	DECLARE_DYNAMIC(CPlesseyDlg)

public:
	CPlesseyDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CPlesseyDlg();

// Dialog Data
	enum { IDD = IDD_PLESSEY_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	BOOL m_bEnable;
	BOOL m_bCDV;
	BOOL m_bXCD;
	int m_nMinLen;
	int m_nMaxLen;
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	void GetOption(void);
	void SetOption(void);
};
