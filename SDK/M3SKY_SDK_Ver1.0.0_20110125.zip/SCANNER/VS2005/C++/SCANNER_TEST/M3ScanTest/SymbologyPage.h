#pragma once
#include "afxwin.h"
#include "afxcmn.h"


// CSymbologyPage dialog

class CSymbologyPage : public CPropertyPage
{
	DECLARE_DYNAMIC(CSymbologyPage)

public:
	CSymbologyPage();
	virtual ~CSymbologyPage();

// Dialog Data
	enum { IDD = IDD_SYM_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	BOOL m_bUpca;
	BOOL m_bUpce;
	BOOL m_bEan13;
	BOOL m_bBookLand;
	BOOL m_bEan8;
	BOOL m_bCode39;
	BOOL m_bCode32;	
	BOOL m_bPzn;
	BOOL m_bCode128;
	BOOL m_bUccean128;
	BOOL m_bCode93;
	BOOL m_bCode35;
	BOOL m_bCode11;
	BOOL m_bI2of5;
	BOOL m_bMsi;
	BOOL m_bPlessey;
	BOOL m_bCodabar;
	BOOL m_bGs1;
	BOOL m_bGs1Limited;
	BOOL m_bGs1Expanded;
	BOOL m_bVibrate;
	BOOL m_nSyncMode;
	
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	void GetOption(void);
	void SetOption(void);
	BOOL m_bXmitAIMID;
	BOOL m_bTelepen;
	int m_nSound;
	CComboBox m_ctrlComboTimeOut;
	CComboBox m_ctrlComboSecurityLevel;
};
