#pragma once


// CGs1LimitedDlg dialog

class CGs1LimitedDlg : public CDialog
{
	DECLARE_DYNAMIC(CGs1LimitedDlg)

public:
	CGs1LimitedDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CGs1LimitedDlg();

// Dialog Data
	enum { IDD = IDD_GS1LIMITED_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	BOOL m_bEnable;
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	void GetOption(void);
	void SetOption(void);
};
