// Gs1LimitedDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "Gs1LimitedDlg.h"
#include "M3ScanTestDlg.h"

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;


// CGs1LimitedDlg dialog

IMPLEMENT_DYNAMIC(CGs1LimitedDlg, CDialog)

CGs1LimitedDlg::CGs1LimitedDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGs1LimitedDlg::IDD, pParent)
	, m_bEnable(FALSE)
{

}

CGs1LimitedDlg::~CGs1LimitedDlg()
{
}

void CGs1LimitedDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
}


BEGIN_MESSAGE_MAP(CGs1LimitedDlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, &CGs1LimitedDlg::OnConfirm)
END_MESSAGE_MAP()


// CGs1LimitedDlg message handlers

BOOL CGs1LimitedDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CGs1LimitedDlg::OnConfirm()
{
	SetOption();

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	dlg->SetReadOption();

	CDialog::OnOK();
}

void CGs1LimitedDlg::GetOption(void)
{
	if(kReadEx2.Gs1Limited.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;

	UpdateData(FALSE);
}

void CGs1LimitedDlg::SetOption(void)
{
	UpdateData(TRUE);

	if(m_bEnable == TRUE)
		kReadEx2.Gs1Limited.Enable = ENABLE;
	else
		kReadEx2.Gs1Limited.Enable = DISABLE;
}
