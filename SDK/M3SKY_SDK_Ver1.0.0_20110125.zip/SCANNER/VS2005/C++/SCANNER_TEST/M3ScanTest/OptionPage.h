#pragma once


// COptionPage dialog

class COptionPage : public CPropertyPage
{
	DECLARE_DYNAMIC(COptionPage)

public:
	COptionPage();
	virtual ~COptionPage();

// Dialog Data
	enum { IDD = IDD_OPTION_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	void SetOption(void);
	void GetOption(void);
	BOOL m_bWideScan;
	BOOL m_bHighFilter;
	afx_msg void OnUpca();
	afx_msg void OnUpce();
	afx_msg void OnEan13();
	afx_msg void OnEan8();
	afx_msg void OnCode39();
	afx_msg void OnCode128();
	afx_msg void OnCode93();
	afx_msg void OnCode35();
	afx_msg void OnCode11();
	afx_msg void OnI2of5();
	afx_msg void OnCodabar();
	afx_msg void OnMsi();
	afx_msg void OnPlessey();
	afx_msg void OnGs1();
	afx_msg void OnGs1Limited();
	afx_msg void OnGs1Expanded();
	afx_msg void OnTelepen();
	int m_nContinue;
};
