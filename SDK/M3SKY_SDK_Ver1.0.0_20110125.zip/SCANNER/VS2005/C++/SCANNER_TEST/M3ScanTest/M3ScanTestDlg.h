#pragma once



// CM3ScanTestDlg

/*������Ƽ ������*/
#include "scanpage.h"
#include "SymbologyPage.h"
#include "OptionPage.h"

#include "kscanbar.h" //��ĵ����

#include "Reg.h"

class CM3ScanTestDlg : public CPropertySheet
{
	DECLARE_DYNAMIC(CM3ScanTestDlg)

public:   


	CScanPage		m_ScanPage;
	CSymbologyPage	m_SymbologyPage;
	COptionPage		m_OptionPage;

	CReg			m_Reg;

	int				m_bUpca;
	int				m_bUpca_AddOn;

	BOOL			m_bCon;
	BOOL			m_bConCheck;
	BOOL			m_bReading;
	BOOL			m_bSyncMode;

	CM3ScanTestDlg(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CM3ScanTestDlg(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	virtual ~CM3ScanTestDlg();

	void SetReadStruct(KSCANREAD &kRead);
	LPCTSTR GetInfo();
	void ScanReadNB();
	void ReadCancel();
	void ScanRead(LPVOID pRead);
	void M3_ScanInit();


protected:

	DECLARE_MESSAGE_MAP()
protected:
	LRESULT OnScanRead(WPARAM wParam, LPARAM lParam);
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	void M3_ScanClose(void);
	void SetDefaultOption(void);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	void SetReadOption(void);
	void Set_ContinueMode(BOOL bContinue);
	BOOL Get_ContinueMode(void);
};
