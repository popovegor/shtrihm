#pragma once


// CEan13Dlg dialog

class CEan13Dlg : public CDialog
{
	DECLARE_DYNAMIC(CEan13Dlg)

public:
	CEan13Dlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CEan13Dlg();

// Dialog Data
	enum { IDD = IDD_EAN13_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	BOOL m_bEnable;
	BOOL m_bEnableBookland;
	BOOL m_bXCD;
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	void GetOption(void);
	void SetOption(void);
	BOOL m_bSupp;
};
