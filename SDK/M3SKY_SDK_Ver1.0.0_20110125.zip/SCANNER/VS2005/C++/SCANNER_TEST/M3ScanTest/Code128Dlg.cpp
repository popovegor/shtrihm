// Code128Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "Code128Dlg.h"
#include "M3ScanTestDlg.h"

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;

BYTE temp[] = "";

// CCode128Dlg dialog

IMPLEMENT_DYNAMIC(CCode128Dlg, CDialog)

CCode128Dlg::CCode128Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCode128Dlg::IDD, pParent)
	, m_bEnable(FALSE)
	, m_bEnableUccEan128(FALSE)
	, m_nMinLen(0)
	, m_nMaxLen(0)
	, m_strFNC_ASCII(_T(""))
{

}

CCode128Dlg::~CCode128Dlg()
{
}

void CCode128Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_UCCEAN128, m_bEnableUccEan128);
	DDX_Text(pDX, IDC_EDIT_MIN, m_nMinLen);
	DDX_Text(pDX, IDC_EDIT_MAX, m_nMaxLen);
	DDX_Text(pDX, IDC_EDIT_FNCASCII, m_strFNC_ASCII);
}


BEGIN_MESSAGE_MAP(CCode128Dlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, &CCode128Dlg::OnConfirm)
END_MESSAGE_MAP()


// CCode128Dlg message handlers

BOOL CCode128Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CCode128Dlg::OnConfirm()
{
	SetOption();

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	dlg->SetReadOption();

	CDialog::OnOK();
}

void CCode128Dlg::GetOption(void)
{
	if(kReadEx2.Code128.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;

	if((kReadEx2.Code128.AsUCCEAN128 == ENABLE) && (kReadEx2.Code128.Enable == ENABLE))
		m_bEnableUccEan128 = TRUE;
	else
		m_bEnableUccEan128 = FALSE;	


	m_nMaxLen = kReadEx2.Code128.MaxLength;
	m_nMinLen = kReadEx2.Code128.MinLength;

	mbstowcs(m_strFNC_ASCII.GetBuffer(0), (char*)kReadEx2.Code128.FNC1_ASCII, 1024);

	UpdateData(FALSE);
}

void CCode128Dlg::SetOption(void)
{
	UpdateData(TRUE);

	if(m_bEnable == TRUE)
		kReadEx2.Code128.Enable = ENABLE;
	else
		kReadEx2.Code128.Enable = DISABLE;

	if(m_bEnableUccEan128 == TRUE)
	{
		kReadEx2.Code128.Enable			= ENABLE;
		kReadEx2.Code128.AsUCCEAN128	= ENABLE;
	}
	else
		kReadEx2.Code128.AsUCCEAN128 = DISABLE;	

	kReadEx2.Code128.MaxLength = m_nMaxLen;
	kReadEx2.Code128.MinLength = m_nMinLen;

	wcstombs((char*)temp, m_strFNC_ASCII.GetBuffer(0), 1024);
	kReadEx2.Code128.FNC1_ASCII = temp;
}
