#pragma once


// CCodabarDlg dialog

class CCodabarDlg : public CDialog
{
	DECLARE_DYNAMIC(CCodabarDlg)

public:
	CCodabarDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCodabarDlg();

// Dialog Data
	enum { IDD = IDD_CODABAR_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	BOOL m_bEnable;
	BOOL m_bXSS;
	int m_nMinLen;
	int m_nMaxLen;
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	void GetOption(void);
	void SetOption(void);
};
