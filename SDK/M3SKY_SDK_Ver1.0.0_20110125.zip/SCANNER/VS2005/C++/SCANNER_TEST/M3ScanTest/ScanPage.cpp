// ScanPage.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "ScanPage.h"
#include "M3ScanTestDlg.h"
//#include "KScanBar.h"

#define DEVICE_M3SKY	1
#define DEVICE_MM3		2


extern BOOL		m_bKeyFlag;
extern int		g_nDeviceType;

// CScanPage dialog

IMPLEMENT_DYNAMIC(CScanPage, CPropertyPage)

CScanPage::CScanPage()
	: CPropertyPage(CScanPage::IDD)
{

}

CScanPage::~CScanPage()
{
}

void CScanPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SCAN_LIST, m_BarCode_ListCtrl);
}


BEGIN_MESSAGE_MAP(CScanPage, CPropertyPage)
	ON_BN_CLICKED(IDC_SCAN_BUTTON, &CScanPage::OnBnClickedScanButton)
	ON_BN_CLICKED(IDC_INFO_BTN, &CScanPage::OnBnClickedInfoBtn)
	ON_BN_CLICKED(IDC_BTN_SCANCANCEL, &CScanPage::OnBnClickedBtnScancancel)
	ON_BN_CLICKED(IDC_BTN_CLEAR, &CScanPage::OnBnClickedBtnClear)
END_MESSAGE_MAP()


// CScanPage message handlers

BOOL CScanPage::OnInitDialog()
{
	CPropertyPage::OnInitDialog();	
	
	m_nDisplayType	= m_Reg.GetRegValue(HKEY_LOCAL_MACHINE, L"\\Drivers\\Display\\PXA27x\\Config", L"CyScreen");

	ListView_SetExtendedListViewStyle(m_BarCode_ListCtrl.GetSafeHwnd(),LVS_EX_FULLROWSELECT);
	if((g_nDeviceType == DEVICE_MM3) && (m_nDisplayType == 640))
	{
		m_BarCode_ListCtrl.InsertColumn(0,L"BarCode Type",LVCFMT_LEFT,180);
		m_BarCode_ListCtrl.InsertColumn(1,L"BarCode Number",LVCFMT_LEFT,286);
	}
	else
	{
		m_BarCode_ListCtrl.InsertColumn(0,L"BarCode Type",LVCFMT_LEFT,90);
		m_BarCode_ListCtrl.InsertColumn(1,L"BarCode Number",LVCFMT_LEFT,143);
	}
	

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CScanPage::OnBnClickedScanButton()
{
	CM3ScanTestDlg * dlg = (CM3ScanTestDlg *)AfxGetMainWnd();
	dlg->ScanReadNB();
	m_bKeyFlag = FALSE;
}

void CScanPage::OnBnClickedBtnScancancel()
{	
	KScanReadCancel();
}

void CScanPage::OnBnClickedBtnClear()
{
	m_BarCode_ListCtrl.DeleteAllItems();
}

void CScanPage::OnBnClickedInfoBtn()
{
	CM3ScanTestDlg * dlg = (CM3ScanTestDlg *)AfxGetMainWnd();
	AfxMessageBox(dlg->GetInfo());
}

void CScanPage::Write_ListCtrl(CString& BarType, CString& BarValue)
{
	m_BarCode_ListCtrl.InsertItem(0, BarType,0);
	m_BarCode_ListCtrl.SetItemText(0, 1, BarValue);
}


