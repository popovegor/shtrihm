// UpcaDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "UpcaDlg.h"
#include "M3ScanTestDlg.h"

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;


// CUpcaDlg dialog

IMPLEMENT_DYNAMIC(CUpcaDlg, CDialog)

CUpcaDlg::CUpcaDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUpcaDlg::IDD, pParent)
	, m_bEnable(FALSE)
	, m_bXmitNum(FALSE)
	, m_bXCD(FALSE)
	, m_bUpcaAsEan13(FALSE)
	, m_bSupp(FALSE)
{

}

CUpcaDlg::~CUpcaDlg()
{
}

void CUpcaDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_XMIT_NUM, m_bXmitNum);
	DDX_Check(pDX, IDC_CHECK_XCD, m_bXCD);
	DDX_Check(pDX, IDC_CHECK_CONBERT, m_bUpcaAsEan13);
	DDX_Check(pDX, IDC_CHECK_SUPP, m_bSupp);
}


BEGIN_MESSAGE_MAP(CUpcaDlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, &CUpcaDlg::OnConfirm)
END_MESSAGE_MAP()


// CUpcaDlg message handlers

BOOL CUpcaDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CUpcaDlg::OnConfirm()
{
	SetOption();

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	dlg->SetReadOption();

	CDialog::OnOK();
}

void CUpcaDlg::GetOption(void)
{
	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();
	
	m_bEnable = dlg->m_bUpca;

	if(kReadEx2.UpcA.XmitNumber == NO_XMIT_NUMBER)
		m_bXmitNum = FALSE;
	else
		m_bXmitNum = TRUE;

	if(kReadEx2.UpcA.XmitCheckDigit == XMIT_CHECK_DIGIT)
		m_bXCD = TRUE;
	else
		m_bXCD = FALSE;

	if(kReadEx2.UpcA.Format == AS_EAN13)
		m_bUpcaAsEan13 = TRUE;
	else
		m_bUpcaAsEan13 = FALSE;

	if(dlg->m_bUpca_AddOn == WITH_OR_WITHOUT)
		m_bSupp = TRUE;
	else
		m_bSupp = FALSE;

	UpdateData(FALSE);
}

void CUpcaDlg::SetOption(void)
{
	UpdateData(TRUE);

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	if(m_bEnable == TRUE)
	{
		kReadEx2.UpcA.Enable = ENABLE;
		dlg->m_bUpca = TRUE;
	}
	else
	{
		kReadEx2.UpcA.Enable = DISABLE;
		dlg->m_bUpca = FALSE;
	}

	if(m_bXmitNum == TRUE)
		kReadEx2.UpcA.XmitNumber = XMIT_NUMBER;
	else
		kReadEx2.UpcA.XmitNumber = NO_XMIT_NUMBER;

	if(m_bXCD == TRUE)
		kReadEx2.UpcA.XmitCheckDigit = XMIT_CHECK_DIGIT;
	else
		kReadEx2.UpcA.XmitCheckDigit = NO_XMIT_CHECK_DIGIT;

	if(m_bUpcaAsEan13 == TRUE)
		kReadEx2.UpcA.Format = AS_EAN13;
	else
		kReadEx2.UpcA.Format = AS_UPCA;

	if(m_bSupp == TRUE)
	{
		kReadEx2.UpcA.Supp = WITH_OR_WITHOUT;
		dlg->m_bUpca_AddOn = TRUE;
	}
	else
	{
		kReadEx2.UpcA.Supp = NO_Supp;
		dlg->m_bUpca_AddOn = FALSE;
	}
}
