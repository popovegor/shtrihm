// UpceDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "UpceDlg.h"
#include "M3ScanTestDlg.h"

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;


// CUpceDlg dialog

IMPLEMENT_DYNAMIC(CUpceDlg, CDialog)

CUpceDlg::CUpceDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUpceDlg::IDD, pParent)
	, m_bEnable(FALSE)
	, m_bXmitNum(FALSE)
	, m_bXCD(FALSE)
	, m_nConvert(0)
{

}

CUpceDlg::~CUpceDlg()
{
}

void CUpceDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_XMIT_NUM, m_bXmitNum);
	DDX_Check(pDX, IDC_CHECK_XCD, m_bXCD);
	DDX_Radio(pDX, IDC_RADIO_NOTCONVERT, m_nConvert);
}


BEGIN_MESSAGE_MAP(CUpceDlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, &CUpceDlg::OnConfirm)
END_MESSAGE_MAP()


// CUpceDlg message handlers

BOOL CUpceDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	GetOption();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CUpceDlg::OnConfirm()
{
	SetOption();

	CM3ScanTestDlg* dlg = (CM3ScanTestDlg*)AfxGetMainWnd();

	dlg->SetReadOption();

	CDialog::OnOK();
}

void CUpceDlg::GetOption(void)
{
	if(kReadEx2.UpcE.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;

	if(kReadEx2.UpcE.XmitNumber == XMIT_NUMBER)
		m_bXmitNum = TRUE;
	else
		m_bXmitNum = FALSE;

	if(kReadEx2.UpcE.XmitCheckDigit == XMIT_CHECK_DIGIT)
		m_bXCD = TRUE;
	else
		m_bXCD = FALSE;

	if(kReadEx2.UpcE.Format == AS_UPCA)
	{
		m_nConvert = 1;
	}
	else if(kReadEx2.UpcE.Format == AS_EAN13)
	{
		m_nConvert = 2;
	}
	else
	{
		m_nConvert = 0;
	}
	UpdateData(FALSE);
}

void CUpceDlg::SetOption(void)
{
	UpdateData(TRUE);

	if(m_bEnable == TRUE)
		kReadEx2.UpcE.Enable = ENABLE;
	else
		kReadEx2.UpcE.Enable = DISABLE;

	if(m_bXmitNum == TRUE)
		kReadEx2.UpcE.XmitNumber = XMIT_NUMBER;
	else
		kReadEx2.UpcE.XmitNumber = NO_XMIT_NUMBER;

	if(m_bXCD == TRUE)
		kReadEx2.UpcE.XmitCheckDigit = XMIT_CHECK_DIGIT;
	else
		kReadEx2.UpcE.XmitCheckDigit = NO_XMIT_CHECK_DIGIT;

	if(m_nConvert == 1)
		kReadEx2.UpcE.Format = AS_UPCA;
	else if(m_nConvert == 2)
		kReadEx2.UpcE.Format = AS_EAN13;
	else
		kReadEx2.UpcE.Format = AS_UPCE;
}
