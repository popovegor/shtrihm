#pragma once


// CCode93Dlg dialog

class CCode93Dlg : public CDialog
{
	DECLARE_DYNAMIC(CCode93Dlg)

public:
	CCode93Dlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCode93Dlg();

// Dialog Data
	enum { IDD = IDD_CODE93_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	BOOL m_bEnable;
	int m_nMinLen;
	int m_nMaxLen;
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	void GetOption(void);
	void SetOption(void);
};
