#pragma once
#include "afxwin.h"


// CViewer dialog

class CViewer : public CDialog
{
	DECLARE_DYNAMIC(CViewer)

public:
	CViewer(CWnd* pParent = NULL);   // standard constructor
	virtual ~CViewer();

// Dialog Data
	enum { IDD = IDD_VIEWER_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedLeft();
	afx_msg void OnBnClickedRight();
	CStatic m_ctlView;
	virtual BOOL OnInitDialog();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);

	CPoint m_pt;
};
