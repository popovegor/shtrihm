// Cam2Dlg.h : header file
//

#pragma once

#include "M3MobileImager.h"
#include "afxwin.h"

#include "Option.h"

// CCam2Dlg dialog
class CCam2Dlg : public CDialog
{
private:
	BOOL	m_bCapturring;		
	
// Construction
public:
	CCam2Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_CAM2_DIALOG };


	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
#if defined(_DEVICE_RESOLUTION_AWARE) && !defined(WIN32_PLATFORM_WFSP)
	afx_msg void OnSize(UINT /*nType*/, int /*cx*/, int /*cy*/);

#endif
	DECLARE_MESSAGE_MAP()

	afx_msg LRESULT OnImageView(WPARAM wParam, LPARAM lParam);
public:
	afx_msg void OnBnClickedButtonStart();
	afx_msg void OnBnClickedButtonStop();
	afx_msg void OnBnClickedButtonCapture();
	afx_msg void OnBnClickedButtonOption();
	afx_msg void OnBnClickedButtonViewer();
	afx_msg void OnBnClickedButtonInfo();

//private:
//	CAM_OPTION m_option;
public:
	CButton m_btnStart;
	CButton m_btnStop;
	CButton m_btnCapture;
	CStatic m_staticImage;

	DWORD m_dwButtonValue;
	COption m_OptionDlg;

	afx_msg void OnDestroy();


	CList<TCHAR *, TCHAR *> m_filelist;	
	POSITION				m_listpos;

	void ImageLoad(WCHAR *FileName, CStatic *ImageCtl=NULL);

	TCHAR m_tcFileFullName[MAX_PATH];


	HANDLE					m_hFind;
	WIN32_FIND_DATA	 m_fd;

	BOOL ImageFileLoad(PTCHAR pstrPath, BOOL bFullPath  = FALSE);
	void ViewDown() ;
	void ViewUp() ;

	CStatic	*m_ViewImageCtl;
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};
