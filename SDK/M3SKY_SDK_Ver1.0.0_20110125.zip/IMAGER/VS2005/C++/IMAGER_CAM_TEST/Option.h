#pragma once
#include "afxwin.h"
#include "afxcmn.h"


// COption dialog

class COption : public CDialog
{
	DECLARE_DYNAMIC(COption)

public:
	COption(CWnd* pParent = NULL);   // standard constructor
	virtual ~COption();

// Dialog Data
	enum { IDD = IDD_OPTION_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	UINT m_nLeft;
	UINT m_nTop;
	UINT m_nRight;
	UINT m_nBottom;
	UINT m_nJpegQuality;
	CComboBox m_cbctlResolution;
	CComboBox m_cbctlSaveFormat;

	CSpinButtonCtrl m_ctlspinLeft;
	CSpinButtonCtrl m_ctlspinTop;
	CSpinButtonCtrl m_ctlspinRight;
	CSpinButtonCtrl m_ctlspinBottom;
	CSpinButtonCtrl m_ctlspinJpegQuality;
	afx_msg void OnBnClickedOk();
	CString m_strSaveFolder;
	CComboBox m_cbctlNameType;
	CEdit m_ebctlCustomName;
	CString m_strCustomName;

	BOOL m_bDateNameType;
	BOOL m_bBMTSaveFormat;
	CStatic m_scctlNameType;
	afx_msg void OnCbnSelchangeNameTypeCombo();
};
