// Info.cpp : implementation file
//

#include "stdafx.h"
#include "Cam2.h"
#include "Info.h"

#include "M3MobileImager.h"

// CInfo dialog

IMPLEMENT_DYNAMIC(CInfo, CDialog)

CInfo::CInfo(CWnd* pParent /*=NULL*/)
	: CDialog(CInfo::IDD, pParent)
	, m_strInfo(_T(""))
{

}

CInfo::~CInfo()
{
}

void CInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_INFO, m_strInfo);
	DDX_Control(pDX, IDC_STATIC_PICTURE, m_ctlLogo);
}


BEGIN_MESSAGE_MAP(CInfo, CDialog)
END_MESSAGE_MAP()


// CInfo message handlers

BOOL CInfo::OnInitDialog()
{
	CDialog::OnInitDialog();


	// If screen resolution is 320*240 IDB_BITMAP_LOGO_QVGA				[2009/6/2 15:16:08 JU]
	//						   640*480 IDB_BITMAP_LOGO_VGA 

	BOOL bVGA = FALSE;

	if(::GetSystemMetrics(SM_CXSCREEN)  == 480)
	{
		bVGA = TRUE;
	}

	RECT rt;	
	if(bVGA)
	{
		rt.bottom	= 104;
		rt.left		= 48;
		rt.right	= 432;
		rt.top		= 2;
	}
	else
	{
		rt.bottom	= 55;
		rt.left		= 42;
		rt.right	= 193;
		rt.top		= 9;
	}

	m_ctlLogo.MoveWindow(&rt);
	m_ctlLogo.SetBitmap(LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE((bVGA)?IDB_BITMAP_LOGO_VGA: IDB_BITMAP_LOGO_QVGA)));


	IMAGER_VERSION_INFO info;

	GetInfo(&info);

//	CInfo dlg;

	m_strInfo.Format(L"%s \r\n%s \r\n%s \r\nFirmwareVersion:%d \r\nFirmwareCksum:%d \r\nEngineID:%d \r\n\r\n%s\
						  \r\n\r\nProgram Version 2.2.1 \r\nBuild Date 2011.01.14.", 
						  info.tcAPIRev, info.tcDecoderRev, info.tcScanDriverRev, 
						  info.dwFirmwareVersion, info.dwFirmwareCksum, info.dwEngineId,
						  info.tcEtcInfo);

	UpdateData(FALSE);


	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
