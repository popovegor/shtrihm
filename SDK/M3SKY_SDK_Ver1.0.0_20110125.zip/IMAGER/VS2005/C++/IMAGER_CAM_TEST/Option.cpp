// Option.cpp : implementation file
//

#include "stdafx.h"
#include "Cam2.h"
#include "Option.h"


#include "M3MobileImager.h"

// COption dialog

IMPLEMENT_DYNAMIC(COption, CDialog)

COption::COption(CWnd* pParent /*=NULL*/)
	: CDialog(COption::IDD, pParent)
	, m_nLeft(0)
	, m_nTop(0)
	, m_nRight(0)
	, m_nBottom(0)
	, m_nJpegQuality(0)
	, m_strSaveFolder(_T(""))
	, m_strCustomName(_T(""))
{

}

COption::~COption()
{
}

void COption::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_LEFT, m_nLeft);
	DDX_Text(pDX, IDC_EDIT_TOP, m_nTop);
	DDX_Text(pDX, IDC_EDIT_RIGHT, m_nRight);
	DDX_Text(pDX, IDC_EDIT_BOTTOM, m_nBottom);
	DDX_Text(pDX, IDC_EDIT_JPEG_QUALITY, m_nJpegQuality);
	DDX_Control(pDX, IDC_COMBO_RESOLUTION, m_cbctlResolution);
	DDX_Control(pDX, IDC_COMBO_FORMAT, m_cbctlSaveFormat);
	DDX_Control(pDX, IDC_SPIN_LEFT, m_ctlspinLeft);
	DDX_Control(pDX, IDC_SPIN_TOP, m_ctlspinTop);
	DDX_Control(pDX, IDC_SPIN_RIGHT, m_ctlspinRight);
	DDX_Control(pDX, IDC_SPIN_BOTTOM, m_ctlspinBottom);
	DDX_Control(pDX, IDC_SPIN_JPEG_QUALITY, m_ctlspinJpegQuality);
	DDX_Text(pDX, IDC_EDIT_SAVE_FOLDER, m_strSaveFolder);
	DDX_Control(pDX, IDC_NAME_TYPE_COMBO, m_cbctlNameType);
	DDX_Control(pDX, IDC_EDIT_CUSTOM_NAME, m_ebctlCustomName);
	DDX_Text(pDX, IDC_EDIT_CUSTOM_NAME, m_strCustomName);
	DDX_Control(pDX, IDC_STATIC_CUSTOM_NAME, m_scctlNameType);
}


BEGIN_MESSAGE_MAP(COption, CDialog)
	
	ON_CBN_SELCHANGE(IDC_NAME_TYPE_COMBO, &COption::OnCbnSelchangeNameTypeCombo)
END_MESSAGE_MAP()


// COption message handlers

BOOL COption::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here


	m_cbctlResolution.InsertString(0, L"640x480");
	m_cbctlResolution.InsertString(1, L"320x240");
	m_cbctlResolution.InsertString(2, L"160x120");

	m_cbctlSaveFormat.InsertString(0, L"BMP");
	m_cbctlSaveFormat.InsertString(1, L"JPG");

	m_cbctlNameType.InsertString(0, L"Custom");
	m_cbctlNameType.InsertString(1, L"Date");

	m_ctlspinLeft.SetRange32(0, 640);
	m_ctlspinTop.SetRange32(0, 480);
	m_ctlspinRight.SetRange32(0, 640);
	m_ctlspinBottom.SetRange32(0, 480);
	m_ctlspinJpegQuality.SetRange32(0, 100);

//////////////////////////////////////////////////////////////////////////
///		������ initialize
	CAM_OPTION option;

	CamGetOption(&option);

	m_nTop				= option.nTop;
	m_nLeft				= option.nLeft;
	m_nRight			= option.nRight;
	m_nBottom			= option.nBottom;
	

	m_nJpegQuality		= option.nJpegQuality;
	m_cbctlResolution.SetCurSel(option.nResolution);
	m_cbctlSaveFormat.SetCurSel(option.nSaveFormat);

	switch(option.nSaveFormat)
	{
		case 0:
			NKDbgPrintfW(L"app option: bmp \n");
			m_bBMTSaveFormat = TRUE;
			break;

		case 1:
			NKDbgPrintfW(L"app option: jpg \n");
			m_bBMTSaveFormat = FALSE;
			break;
	}


	if(m_bDateNameType)
	{
		m_cbctlNameType.SetCurSel(1);
		m_scctlNameType.EnableWindow(FALSE);
		m_ebctlCustomName.EnableWindow(FALSE);
	}
	else
	{
		m_cbctlNameType.SetCurSel(0);
		m_scctlNameType.EnableWindow(TRUE);
		m_ebctlCustomName.EnableWindow(TRUE);
	}

///		������ initialize
//////////////////////////////////////////////////////////////////////////

	UpdateData(FALSE);
	


	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void COption::OnOK()
{
	UpdateData(TRUE);

	if((m_cbctlNameType.GetCurSel() == 0) && (0 == m_strCustomName.GetLength()))
	{
		MessageBox(L"Custom Name edit box is blank.");
		return;
	}

	CAM_OPTION option;

	if(m_cbctlNameType.GetCurSel() == 0)
		m_bDateNameType = FALSE;
	else
		m_bDateNameType = TRUE;

	option.nTop = m_nTop;
	option.nLeft = m_nLeft;
	option.nRight = m_nRight;
	option.nBottom = m_nBottom;

	if((m_nJpegQuality>100) || (m_nJpegQuality<1))
	{
		AfxMessageBox(L"The Jpeg Quality should be 1-100");		
		m_nJpegQuality = 20;
		UpdateData(FALSE);
		return;
	}

	option.nJpegQuality = m_nJpegQuality;
	option.nResolution  = m_cbctlResolution.GetCurSel();
	option.nSaveFormat = m_cbctlSaveFormat.GetCurSel();
	option.bInvert = FALSE;


	switch(option.nSaveFormat)
	{
	case 0:
		m_bBMTSaveFormat = TRUE;
		break;

	case 1:
		m_bBMTSaveFormat = FALSE;
		break;
	}

	CamSetOption(option);
	// TODO: Add your control notification handler code here
	CDialog::OnOK();
}

void COption::OnCbnSelchangeNameTypeCombo()
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);

	if(m_cbctlNameType.GetCurSel() == 0)
	{
		m_scctlNameType.EnableWindow(TRUE);
		m_ebctlCustomName.EnableWindow(TRUE);
	}
	else
	{
		m_scctlNameType.EnableWindow(FALSE);
		m_ebctlCustomName.EnableWindow(FALSE);
	}
}
