// Cam2.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Cam2.h"
#include "Cam2Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CCam2App

BEGIN_MESSAGE_MAP(CCam2App, CWinApp)
END_MESSAGE_MAP()


// CCam2App construction
CCam2App::CCam2App()
	: CWinApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only CCam2App object
CCam2App theApp;

// CCam2App initialization

BOOL CCam2App::InitInstance()
{
	HANDLE hMutex = NULL;

	//	���� Camera���� ���α׷��� ��������� Ȯ���Ѵ�.
	HWND hFwnd = FindWindow(NULL, L"Pictures & Videos");

	if(hFwnd)
	{
		int result = MessageBox(NULL, L"Pictres & Videos program is running!\nDo you want to run the scanner", NULL, MB_YESNO);

		if(IDYES != result)		// ��ĳ�� ����̹� unload
		{
			return FALSE;
		}
		SendMessage(hFwnd, WM_DESTROY, NULL, NULL);
	}


	hMutex = ::CreateMutex(NULL, TRUE, _T("M3SKYCAMERA"));
	if(GetLastError() == ERROR_ALREADY_EXISTS)
	{
		int result;
		result = MessageBox(NULL,_T("Camera program is already running!\nDo you want to run the scanner"),_T("ERROR"),MB_YESNO|MB_ICONWARNING);

		if(IDYES == result)		// ��ĳ�� ����̹� unload
		{
			hFwnd = FindWindow(NULL, L"Camera");
			if(hFwnd)
			{
				SendMessage(hFwnd, WM_DESTROY, NULL, NULL);
			}
		}
		else 
		{
			return FALSE;
		}

	}
	else
	{
		ReleaseMutex(hMutex);
		CloseHandle(hMutex);
	}

	hMutex = ::CreateMutex(NULL, TRUE, _T("2D IMAGER"));
	if(GetLastError() == ERROR_ALREADY_EXISTS)
	{

		MessageBox(NULL,_T("IMAGER Engine is already running!"),_T("ERROR"),MB_OK|MB_ICONWARNING);
		return FALSE;
	}




    // SHInitExtraControls should be called once during your application's initialization to initialize any
    // of the Windows Mobile specific controls such as CAPEDIT and SIPPREF.
    SHInitExtraControls();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	CCam2Dlg dlg;
	m_pMainWnd = &dlg;
	INT_PTR nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}

	ReleaseMutex(hMutex);
	CloseHandle(hMutex);

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
