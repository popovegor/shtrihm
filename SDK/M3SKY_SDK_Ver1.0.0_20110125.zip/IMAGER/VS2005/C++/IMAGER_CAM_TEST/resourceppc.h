//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Cam2ppc.rc
//
#define IDD_CAM2_DIALOG                 102
#define IDD_CAM2_DIALOG_WIDE            103
#define IDR_MAINFRAME                   128
#define IDD_OPTION_DLG                  129
#define IDD_VIEWER_DLG                  130
#define IDB_BITMAP_LOGO_VGA             131
#define IDB_BITMAP2                     132
#define IDB_BITMAP_LOGO_QVGA            132
#define IDD_INFO                        153
#define IDC_STATIC_1                    200
#define IDC_BUTTON_CAPTURE              1000
#define IDC_NAME_TYPE_COMBO             1000
#define IDC_BUTTON_START                1001
#define IDC_EDIT_CUSTOM_NAME            1001
#define IDC_BUTTON_OPTION               1002
#define IDC_STATIC_CUSTOM_NAME          1002
#define IDC_BUTTON_STOP                 1003
#define IDC_STATIC_PICTURE              1003
#define IDC_STATIC_IMAGE                1004
#define IDC_EDIT_INFO                   1004
#define IDC_EDIT_LEFT                   1008
#define IDC_EDIT_TOP                    1009
#define IDC_EDIT_RIGHT                  1010
#define IDC_EDIT_BOTTOM                 1011
#define IDC_SPIN_LEFT                   1013
#define IDC_SPIN_TOP                    1014
#define IDC_SPIN_RIGHT                  1015
#define IDC_SPIN_BOTTOM                 1016
#define IDC_COMBO_FORMAT                1017
#define IDC_EDIT_SAVE_FOLDER            1018
#define IDC_EDIT_JPEG_QUALITY           1019
#define IDC_SPIN_JPEG_QUALITY           1020
#define IDC_BUTTON_VIEWER               1021
#define IDC_BUTTON_INFO                 1022
#define IDC_COMBO_RESOLUTION            1030
#define IDC_LEFT                        1031
#define IDC_RIGHT                       1032
#define IDC_STATIC_VIEWER               1033

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
