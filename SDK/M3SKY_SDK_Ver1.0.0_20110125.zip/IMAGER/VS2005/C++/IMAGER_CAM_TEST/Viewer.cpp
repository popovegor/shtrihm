// Viewer.cpp : implementation file
//

#include "stdafx.h"
#include "Cam2.h"
#include "Viewer.h"

#include "Cam2Dlg.h"


DWORD FirstViewThreadFunc(LPVOID pParam);

// CViewer dialog

IMPLEMENT_DYNAMIC(CViewer, CDialog)

CViewer::CViewer(CWnd* pParent /*=NULL*/)
	: CDialog(CViewer::IDD, pParent)
{

}

CViewer::~CViewer()
{
}

void CViewer::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_VIEWER, m_ctlView);
}


BEGIN_MESSAGE_MAP(CViewer, CDialog)
	ON_BN_CLICKED(IDC_LEFT, &CViewer::OnBnClickedLeft)
	ON_BN_CLICKED(IDC_RIGHT, &CViewer::OnBnClickedRight)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
END_MESSAGE_MAP()


// CViewer message handlers

void CViewer::OnBnClickedLeft()
{

	CCam2Dlg *dlg = (CCam2Dlg *)AfxGetMainWnd();
	dlg->ViewUp();
}

void CViewer::OnBnClickedRight()
{
	CCam2Dlg *dlg = (CCam2Dlg *)AfxGetMainWnd();
	dlg->ViewDown();
}

BOOL CViewer::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here

	if(::GetSystemMetrics(SM_CXSCREEN)  == 480)
		MoveWindow(-1, -1, 480, 640);
	else
		MoveWindow(-1, -1, 242, 295);

// 	DWORD ThreadID;
// 	HANDLE hThread = CreateThread(NULL, 0, FirstViewThreadFunc, this, 0, &ThreadID);
// 	CloseHandle(hThread);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

DWORD FirstViewThreadFunc(LPVOID pParam)
{
	CCam2Dlg * dlg = (CCam2Dlg  *)AfxGetMainWnd();

	Sleep(200);

	dlg->ViewDown();

	return 1;

}


void CViewer::OnLButtonDown(UINT nFlags, CPoint point)
{
	m_pt = point;

	CDialog::OnLButtonDown(nFlags, point);
}

void CViewer::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	CPoint result;

	result =  m_pt - point;

	if(result.x<-4)
		OnBnClickedRight();

	if(result.x>4)
		OnBnClickedLeft();

	CDialog::OnLButtonUp(nFlags, point);
}
