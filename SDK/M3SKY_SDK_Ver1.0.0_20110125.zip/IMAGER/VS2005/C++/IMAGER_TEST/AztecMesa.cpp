// AztecMesa.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "AztecMesa.h"

#include "M3MobileImager.h"

extern IScan g_scan;


// CAztecMesa dialog

IMPLEMENT_DYNAMIC(CAztecMesa, CDialog)

CAztecMesa::CAztecMesa(CWnd* pParent /*=NULL*/)
	: CDialog(CAztecMesa::IDD, pParent)
	, m_bEnable(FALSE)
	, m_bIMS(FALSE)
	, m_b1MS(FALSE)
	, m_b3MS(FALSE)
	, m_b9MS(FALSE)
	, m_bUMS(FALSE)
	, m_bEMS(FALSE)
{

}

CAztecMesa::~CAztecMesa()
{
}

void CAztecMesa::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_MESA_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_MESA_ENIMS, m_bIMS);
	DDX_Check(pDX, IDC_CHECK_MESA_EN1MS, m_b1MS);
	DDX_Check(pDX, IDC_CHECK_MESA_EN3MS, m_b3MS);
	DDX_Check(pDX, IDC_CHECK_MESA_EN9MS, m_b9MS);
	DDX_Check(pDX, IDC_CHECK_MESA_ENUMS, m_bUMS);
	DDX_Check(pDX, IDC_CHECK_MESA_ENEMS, m_bEMS);
}


BEGIN_MESSAGE_MAP(CAztecMesa, CDialog)
END_MESSAGE_MAP()


// CAztecMesa message handlers

BOOL CAztecMesa::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here
	SymFlagsOnly config;
	
	g_scan.ReadSymbologyConfig(SETUP_CURRENT, ID_MESA, &config);

	if(config.dwFlags & SYM_ENABLE)
		m_bEnable = TRUE;

	if(config.dwFlags & SYM_ENABLE_MESA_IMS)
		m_bIMS = TRUE;

	if(config.dwFlags & SYM_ENABLE_MESA_1MS)
		m_b1MS = TRUE;

	if(config.dwFlags & SYM_ENABLE_MESA_3MS)
		m_b3MS = TRUE;

	if(config.dwFlags & SYM_ENABLE_MESA_9MS)
		m_b9MS = TRUE;

	if(config.dwFlags & SYM_ENABLE_MESA_UMS)
		m_bUMS = TRUE;

	if(config.dwFlags & SYM_ENABLE_MESA_EMS)
		m_bEMS = TRUE;

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CAztecMesa::OnOK()
{
	SymFlagsOnly config;

	UpdateData(TRUE);

	if(m_bEnable)
		config.dwFlags = SYM_ENABLE;
	else
		config.dwFlags = 0;

	if(m_bIMS)
		config.dwFlags |= SYM_ENABLE_MESA_IMS;

	if(m_b1MS)
		config.dwFlags |= SYM_ENABLE_MESA_1MS;
		

	if(m_b3MS)
		config.dwFlags |= SYM_ENABLE_MESA_3MS;

	if(m_b9MS)
		config.dwFlags |= SYM_ENABLE_MESA_9MS;

	if(m_bUMS)
		config.dwFlags |= SYM_ENABLE_MESA_UMS;

	if(m_bEMS)
		config.dwFlags |= SYM_ENABLE_MESA_EMS;

	
	g_scan.WriteSymbologyConfig(ID_MESA, config);

	CDialog::OnOK();
}