// OptionPage.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "OptionPage.h"

#include "M3MobileImager.h"
#include "MainSheet.h"


// COptionPage dialog

IMPLEMENT_DYNAMIC(COptionPage, CPropertyPage)

COptionPage::COptionPage()
	: CPropertyPage(COptionPage::IDD)
	, m_bMultiDecode(FALSE)
	, m_bBeep(FALSE)
	, m_bAimID(FALSE)
{

}

COptionPage::~COptionPage()
{
}

void COptionPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);

	DDX_Radio(pDX, IDC_RADIO_SYNC, m_nSyncMode);
	DDX_Check(pDX, IDC_CHECK_MULTIDECODEMODE, m_bMultiDecode);
	DDX_Control(pDX, IDC_COMBO_SCANNING_LIGHT_MODE, m_ctlScanningLightMode);
	DDX_Check(pDX, IDC_CHECK_BEEP, m_bBeep);
	DDX_Control(pDX, IDC_COMBO_TIMEOUT, m_ctrlComboTimeOut);
	DDX_Check(pDX, IDC_CHECK_AIMID, m_bAimID);
}


BEGIN_MESSAGE_MAP(COptionPage, CPropertyPage)
	ON_BN_CLICKED(IDC_BUTTON_CONFIRM, &COptionPage::OnBnClickedButtonConfirm)
	ON_BN_CLICKED(IDCANCEL, &COptionPage::OnBnClickedCancel)
END_MESSAGE_MAP()


// COptionPage message handlers
BOOL COptionPage::OnInitDialog()
{
	CPropertyPage::OnInitDialog();

	CMainSheet* dlg = (CMainSheet*)AfxGetMainWnd();

	m_ctlScanningLightMode.InsertString(0, L"ILLUM_AIMER_OFF");
	m_ctlScanningLightMode.InsertString(1, L"ILLUM_ONLY_ON");
	m_ctlScanningLightMode.InsertString(2, L"AIMER_ONLY_ON");
	m_ctlScanningLightMode.InsertString(3, L"ILLUM_AIMER_ON");
	m_ctlScanningLightMode.SetCurSel(3);

	m_ctrlComboTimeOut.InsertString(0, L"1");
	m_ctrlComboTimeOut.InsertString(1, L"2");
	m_ctrlComboTimeOut.InsertString(2, L"3");
	m_ctrlComboTimeOut.InsertString(3, L"4");
	m_ctrlComboTimeOut.InsertString(4, L"5");
	m_ctrlComboTimeOut.InsertString(5, L"6");
	m_ctrlComboTimeOut.InsertString(6, L"7");
	m_ctrlComboTimeOut.InsertString(7, L"8");
	m_ctrlComboTimeOut.InsertString(8, L"9");
	m_ctrlComboTimeOut.InsertString(9, L"10");
	m_ctrlComboTimeOut.SetCurSel(dlg->m_nTimeOut - 1);

	m_bAimID = GetTransmitAIMID();

	UpdateData(FALSE);
	


	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void COptionPage::OnBnClickedButtonConfirm()
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);

	SetScanningLightsMode((ScanIlluminat)m_ctlScanningLightMode.GetCurSel());
	MultiDecodeModeEnable(m_bMultiDecode);

	SetTransmitAIMID(m_bAimID);

	CMainSheet* dlg = (CMainSheet*)AfxGetMainWnd();
	dlg->m_nTimeOut = m_ctrlComboTimeOut.GetCurSel()+1;

	//���� ��ư�� Ŭ���ϸ� �� �������� �̵��մϴ�.
	(CPropertySheet *)GetParent()->SendMessage(PSM_SETCURSEL, 0);
}


void COptionPage::OnBnClickedCancel()
{
	(CPropertySheet *)GetParent()->SendMessage(PSM_SETCURSEL, 0);
}
