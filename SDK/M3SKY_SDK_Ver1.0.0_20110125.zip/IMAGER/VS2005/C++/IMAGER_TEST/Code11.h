#pragma once


// CCode11 dialog

class CCode11 : public CDialog
{
	DECLARE_DYNAMIC(CCode11)

public:
	CCode11(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCode11();

// Dialog Data
	enum { IDD = IDD_CODE11 };


protected:
	virtual void OnOK();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	DWORD m_dwMinLen;
	DWORD m_dwMaxLen;
	BOOL m_bEnable;
	BOOL m_bCheck;
	virtual BOOL OnInitDialog();
};
