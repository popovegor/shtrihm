// InitMessage.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "InitMessage.h"


// CInitMessage dialog

IMPLEMENT_DYNAMIC(CInitMessage, CDialog)

CInitMessage::CInitMessage(CWnd* pParent /*=NULL*/)
	: CDialog(CInitMessage::IDD, pParent)
{

}

CInitMessage::~CInitMessage()
{
}

void CInitMessage::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CInitMessage, CDialog)
END_MESSAGE_MAP()


// CInitMessage message handlers

BOOL CInitMessage::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here
	CenterWindow(GetDesktopWindow());


	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
