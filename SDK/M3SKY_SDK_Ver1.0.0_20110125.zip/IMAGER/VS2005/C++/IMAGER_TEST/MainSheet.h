#pragma once




#include "ScanPage.h"
#include "SymPage.h"
#include "OptionPage.h"
#include "Reg.h"

#include "M3MobileImager.h"



// CMainSheet

class CMainSheet : public CPropertySheet
{
	DECLARE_DYNAMIC(CMainSheet)


private:
	DWORD m_dwButtonValue;
	
public:
//	IScan				m_scanner;

	CScanPage	m_scan;
	CSymPage	m_symbol;
	COptionPage	m_option;

	int			m_nTimeOut;
	BOOL		m_bKeyFlag;
	BOOL		m_bEnableISBN;
	CReg		m_Reg;

	void Check_Barcode(TCHAR chId, TCHAR chSymLetter, TCHAR chSymModifier, CString szCode);

//	static BOOL CALLBACK fnScan(EVENT_TYPE eventType, DWORD dwBytes);
	static BOOL fnScan();

	BOOL ScanRead();
	void GetInfo();

public:
	CMainSheet(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CMainSheet(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

	virtual ~CMainSheet();



protected:
	DECLARE_MESSAGE_MAP()
	afx_msg LRESULT OnDataRead(WPARAM wParam, LPARAM lParam);
public:
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnDestroy();
};


