// Msi.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "Msi.h"

#include "M3MobileImager.h"

extern IScan g_scan;


// CMsi dialog

IMPLEMENT_DYNAMIC(CMsi, CDialog)

CMsi::CMsi(CWnd* pParent /*=NULL*/)
	: CDialog(CMsi::IDD, pParent)
	, m_dwMinLen(0)
	, m_dwMaxLen(0)
	, m_bEnable(FALSE)
	, m_bCheckSend(FALSE)
{

}

CMsi::~CMsi()
{
}

void CMsi::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_MSI_MIN, m_dwMinLen);
	DDX_Text(pDX, IDC_EDIT_MSI_MAX, m_dwMaxLen);
	DDX_Check(pDX, IDC_CHECK_MSI_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_MSI_CHECK_SEND, m_bCheckSend);
}


BEGIN_MESSAGE_MAP(CMsi, CDialog)
END_MESSAGE_MAP()


// CMsi message handlers

BOOL CMsi::OnInitDialog()
{
	CDialog::OnInitDialog();

	SymFlagsRange config;

	g_scan.ReadSymbologyConfig(SETUP_CURRENT, ID_MSI, &config);

	if(config.dwFlags & SYM_ENABLE)
		m_bEnable = TRUE;

	if(config.dwFlags & SYM_CHECK_TRANSMIT)
		m_bCheckSend = TRUE;

	m_dwMaxLen = config.dwMaxLen;
	m_dwMinLen = config.dwMinLen;

	UpdateData(FALSE);

	return TRUE; // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}



void CMsi::OnOK()
{
	UpdateData(TRUE);

	SymFlagsRange config;


	CString errMessage;
	g_scan.ReadSymbologyConfig(SETUP_DEFAULT, ID_MSI, &config);
	if((m_dwMaxLen<config.dwMinLen) || (m_dwMaxLen >config.dwMaxLen) || (m_dwMaxLen<config.dwMinLen) )
	{
		errMessage.Format(L"The maximum length of the corresponding barcode is from %d to %d, maximum length should be bigger than minimum length", config.dwMinLen, config.dwMaxLen);
		MessageBox(errMessage, L"Max Length");
		return;
	}

	if(m_dwMinLen <config.dwMinLen)
	{
		errMessage.Format(L"The minimum length of the corresponding barcode is  from %d to %d, minimum length should be shorter than maximum lenght", config.dwMinLen, config.dwMaxLen);
		MessageBox(errMessage, L"Min Length");
		return;
	}



	if(m_bEnable)
		config.dwFlags = SYM_ENABLE;
	else
		config.dwFlags = 0;

	if(	m_bCheckSend)
		config.dwFlags |= SYM_CHECK_TRANSMIT;

	config.dwMaxLen = m_dwMaxLen;
	config.dwMinLen = m_dwMinLen;

	g_scan.WriteSymbologyConfig(ID_MSI, config);

	// TODO: Add your control notification handler code here
	CDialog::OnOK();
}
