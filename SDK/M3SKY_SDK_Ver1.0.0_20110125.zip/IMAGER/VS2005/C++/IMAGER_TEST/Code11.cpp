// Code11.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "Code11.h"


#include "M3MobileImager.h"

extern IScan g_scan;


// CCode11 dialog

IMPLEMENT_DYNAMIC(CCode11, CDialog)

CCode11::CCode11(CWnd* pParent /*=NULL*/)
	: CDialog(CCode11::IDD, pParent)
	, m_dwMinLen(0)
	, m_dwMaxLen(0)
	, m_bEnable(FALSE)
	, m_bCheck(FALSE)
{

}

CCode11::~CCode11()
{
}

void CCode11::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_CODE11_MIN, m_dwMinLen);
	DDX_Text(pDX, IDC_EDIT_CODE11_MAX, m_dwMaxLen);
	DDX_Check(pDX, IDC_CHECK_CODE11_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_CODE11_CHECK, m_bCheck);
}


BEGIN_MESSAGE_MAP(CCode11, CDialog)
END_MESSAGE_MAP()


// CCode11 message handlers

BOOL CCode11::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here

	SymFlagsRange config;

	g_scan.ReadSymbologyConfig(SETUP_CURRENT, ID_CODE11, &config);

	if(config.dwFlags & SYM_ENABLE)
		m_bEnable = TRUE;

	if(config.dwFlags & SYM_CHECK_ENABLE)
		m_bCheck = TRUE;

	m_dwMinLen = config.dwMinLen;
	m_dwMaxLen = config.dwMaxLen;

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CCode11::OnOK()
{
	UpdateData(TRUE);

	SymFlagsRange config;


	CString errMessage;
//	code11�� 1~80�����̸�, HHP ���� ����
	config.dwMinLen = 1;
	config.dwMaxLen = 80;
	



	if((m_dwMaxLen<config.dwMinLen) || (m_dwMaxLen >config.dwMaxLen) || (m_dwMaxLen<config.dwMinLen) )
	{
		errMessage.Format(L"The maximum length of the corresponding barcode is from %d to %d, maximum length should be bigger than minimum length", config.dwMinLen, config.dwMaxLen);
		MessageBox(errMessage, L"Max Length");
		return;
	}

	if(m_dwMinLen <config.dwMinLen)
	{
		errMessage.Format(L"The minimum length of the corresponding barcode is  from %d to %d, minimum length should be shorter than maximum lenght", config.dwMinLen, config.dwMaxLen);
		MessageBox(errMessage, L"Min Length");
		return;
	}



	if(m_bEnable)
		config.dwFlags = SYM_ENABLE;
	else 
		config.dwFlags = 0;

	if(m_bCheck)
		config.dwFlags |= SYM_CHECK_ENABLE;

	config.dwMinLen = m_dwMinLen;
	config.dwMaxLen = m_dwMaxLen;

	g_scan.WriteSymbologyConfig(ID_CODE11, config);

	CDialog::OnOK();

}