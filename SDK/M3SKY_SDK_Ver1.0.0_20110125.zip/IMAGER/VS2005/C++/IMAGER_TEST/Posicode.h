#pragma once
#include "afxwin.h"


// CPosicode dialog

class CPosicode : public CDialog
{
	DECLARE_DYNAMIC(CPosicode)

public:
	CPosicode(CWnd* pParent = NULL);   // standard constructor
	virtual ~CPosicode();

// Dialog Data
	enum { IDD = IDD_POSICODE };

protected:
	virtual void OnOK();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	DWORD m_dwMinLen;
	DWORD m_dwMaxLen;
	BOOL m_bEnable;
	CComboBox m_cbctlLimit;

	virtual BOOL OnInitDialog();
};
