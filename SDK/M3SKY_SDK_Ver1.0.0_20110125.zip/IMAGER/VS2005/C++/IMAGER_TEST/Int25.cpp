// Int25.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "Int25.h"


#include "M3MobileImager.h"

extern IScan g_scan;


// CInt25 dialog

IMPLEMENT_DYNAMIC(CInt25, CDialog)

CInt25::CInt25(CWnd* pParent /*=NULL*/)
	: CDialog(CInt25::IDD, pParent)
	, m_dwMinLen(0)
	, m_dwMaxLen(0)
	, m_bEnable(FALSE)
	, m_bCheck(FALSE)
	, m_bCheckSend(FALSE)
{

}

CInt25::~CInt25()
{
}

void CInt25::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_INT25_MIN, m_dwMinLen);
	DDX_Text(pDX, IDC_EDIT_INT25_MAX, m_dwMaxLen);
	DDX_Check(pDX, IDC_CHECK_INT25_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_INT25_CHECK, m_bCheck);
	DDX_Check(pDX, IDC_CHECK_INT25_CHECK_SEND, m_bCheckSend);
	DDX_Control(pDX, IDC_CHECK_INT25_CHECK_SEND, m_chctlCheckSend);
}


BEGIN_MESSAGE_MAP(CInt25, CDialog)
	ON_BN_CLICKED(IDC_CHECK_INT25_CHECK, &CInt25::OnBnClickedCheckInt25Check)
END_MESSAGE_MAP()


// CInt25 message handlers

BOOL CInt25::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here

	SymFlagsRange config;
	g_scan.ReadSymbologyConfig(SETUP_CURRENT, ID_INT25, &config);

	if(config.dwFlags & SYM_ENABLE)
		m_bEnable = TRUE;

	if(config.dwFlags & SYM_CHECK_ENABLE)
		m_bCheck = TRUE;

	if(config.dwFlags & SYM_CHECK_TRANSMIT)
		m_bCheckSend = TRUE;

	m_dwMinLen = config.dwMinLen;
	m_dwMaxLen = config.dwMaxLen;


	if(m_bCheck)
		m_chctlCheckSend.EnableWindow(TRUE);
	else
		m_chctlCheckSend.EnableWindow(FALSE);

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CInt25::OnOK()
{
	SymFlagsRange config;

	UpdateData(TRUE);



	CString errMessage;
	g_scan.ReadSymbologyConfig(SETUP_DEFAULT, ID_INT25, &config);
	if((m_dwMaxLen<config.dwMinLen) || (m_dwMaxLen >config.dwMaxLen) || (m_dwMaxLen<config.dwMinLen) )
	{
		errMessage.Format(L"The maximum length of the corresponding barcode is from %d to %d, maximum length should be bigger than minimum length", config.dwMinLen, config.dwMaxLen);
		MessageBox(errMessage, L"Max Length");
		return;
	}

	if(m_dwMinLen <config.dwMinLen)
	{
		errMessage.Format(L"The minimum length of the corresponding barcode is  from %d to %d, minimum length should be shorter than maximum lenght", config.dwMinLen, config.dwMaxLen);
		MessageBox(errMessage, L"Min Length");
		return;
	}




	if(m_bEnable)
		config.dwFlags = SYM_ENABLE;
	else
		config.dwFlags = 0;

	if(m_bCheck)
		config.dwFlags |= SYM_CHECK_ENABLE;

	if(m_bCheckSend)
		config.dwFlags |= SYM_CHECK_TRANSMIT;


	config.dwMinLen = m_dwMinLen;
	config.dwMaxLen = m_dwMaxLen;
	
	g_scan.WriteSymbologyConfig(ID_INT25, config);


	// TODO: Add your control notification handler code here
	CDialog::OnOK();
}

void CInt25::OnBnClickedCheckInt25Check()
{
	UpdateData(TRUE);
	
	if(m_bCheck)
		m_chctlCheckSend.EnableWindow(TRUE);
	else
		m_chctlCheckSend.EnableWindow(FALSE);
}
