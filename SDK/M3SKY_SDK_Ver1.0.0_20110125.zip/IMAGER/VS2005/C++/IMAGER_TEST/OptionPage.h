#pragma once
#include "afxwin.h"


// COptionPage dialog

class COptionPage : public CPropertyPage
{
	DECLARE_DYNAMIC(COptionPage)

public:
	COptionPage();
	virtual ~COptionPage();

// Dialog Data
	enum { IDD = IDD_OPTIONPAGE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()


public:
	int		m_nSyncMode;
	afx_msg void OnBnClickedButtonConfirm();
	virtual BOOL OnInitDialog();
	BOOL m_bMultiDecode;
	CComboBox m_ctlScanningLightMode;
	afx_msg void OnBnClickedCancel();
	BOOL m_bBeep;
	CComboBox m_ctrlComboTimeOut;
	BOOL m_bAimID;
};
