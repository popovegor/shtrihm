#pragma once


// CFlagsRange dialog

class CFlagsRange : public CDialog
{
	DECLARE_DYNAMIC(CFlagsRange)

private:
	int			m_SymID;

public:
	CFlagsRange(CWnd* pParent = NULL);   // standard constructor
	CFlagsRange(CString title, int SymID, CWnd* pParent = NULL);   // standard constructor

	virtual ~CFlagsRange();

// Dialog Data
	enum { IDD = IDD_FLAGS_RANGE };

protected:
	virtual void OnOK();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CString		m_strBarcodeName;
	DWORD		m_dwMaxLen;
	DWORD		m_dwMinLen;
	BOOL		m_bEnable;
	

	virtual BOOL OnInitDialog();
};
