// FlagsOnly.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "FlagsOnly.h"

#include "M3MobileImager.h"

extern IScan g_scan;
// CFlagsOnly dialog

IMPLEMENT_DYNAMIC(CFlagsOnly, CDialog)

CFlagsOnly::CFlagsOnly(CWnd* pParent /*=NULL*/)
	: CDialog(CFlagsOnly::IDD, pParent)
	, m_strBarcodeName(_T(""))
	, m_bEnable(FALSE)
{

}

CFlagsOnly::CFlagsOnly(CString title, int SymID, CWnd* pParent /*= NULL*/): CDialog(CFlagsOnly::IDD, pParent)
, m_strBarcodeName(_T(""))
, m_bEnable(FALSE)
{
	m_strBarcodeName = title;
	m_SymID = SymID;
}

CFlagsOnly::~CFlagsOnly()
{
}

void CFlagsOnly::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_STATIC_BARCODE_NAME, m_strBarcodeName);
	DDX_Check(pDX, IDC_CHECK_FLAGS_ONLY_ENABLE, m_bEnable);
}


BEGIN_MESSAGE_MAP(CFlagsOnly, CDialog)
END_MESSAGE_MAP()


// CFlagsOnly message handlers
BOOL CFlagsOnly::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here
	SetWindowText(m_strBarcodeName);

	SymFlagsOnly config;

	g_scan.ReadSymbologyConfig(SETUP_CURRENT, m_SymID, &config);

	if(config.dwFlags & SYM_ENABLE)
		m_bEnable = TRUE;

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CFlagsOnly::OnOK()
{
	UpdateData(TRUE);
	SymFlagsOnly config;

	
	if(m_bEnable)
		config.dwFlags = SYM_ENABLE;
	else
		config.dwFlags = 0;

	g_scan.WriteSymbologyConfig(m_SymID, config);

	// TODO: Add your control notification handler code here
	CDialog::OnOK();
}
