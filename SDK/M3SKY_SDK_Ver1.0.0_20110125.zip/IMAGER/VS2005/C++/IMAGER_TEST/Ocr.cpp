// Ocr.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "Ocr.h"

#include "M3MobileImager.h"

extern IScan g_scan;


// COcr dialog

IMPLEMENT_DYNAMIC(COcr, CDialog)

COcr::COcr(CWnd* pParent /*=NULL*/)
	: CDialog(COcr::IDD, pParent)
	, m_strTemplate(_T(""))
	, m_strGroupG(_T(""))
	, m_strGroupH(_T(""))
	, m_strCheckChar(_T(""))
{

}

COcr::~COcr()
{
}

void COcr::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_OCR_MODE, m_cbctlMode);
	DDX_Control(pDX, IDC_COMBO_OCR_DIRECTION, m_cbctlDirection);
	DDX_Text(pDX, IDC_EDIT_TEMPLATE, m_strTemplate);
	DDX_Text(pDX, IDC_EDIT_GROUPG, m_strGroupG);
	DDX_Text(pDX, IDC_EDIT_GROUPH, m_strGroupH);
	DDX_Text(pDX, IDC_EDIT_CHECK_CHAR, m_strCheckChar);
}


BEGIN_MESSAGE_MAP(COcr, CDialog)
END_MESSAGE_MAP()


// COcr message handlers

BOOL COcr::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here
	m_cbctlMode.InsertString(0, L"Disable");
	m_cbctlMode.InsertString(1, L"OCR-A");
	m_cbctlMode.InsertString(2, L"OCR-B");
	m_cbctlMode.InsertString(3, L"OCR-Money");
	m_cbctlMode.InsertString(4, L"OCR-Micr");

	m_cbctlDirection.InsertString(0, L"LeftToRight");
	m_cbctlDirection.InsertString(0, L"TopToBotton");
	m_cbctlDirection.InsertString(0, L"RightToLeft");
	m_cbctlDirection.InsertString(0, L"BottomToTop");

	SymCodeOCR	config;

	g_scan.ReadSymbologyConfig(SETUP_CURRENT, &config);

	m_cbctlMode.SetCurSel(config.ocrMode);
	m_cbctlDirection.SetCurSel(config.ocrDirection);

	m_strTemplate		= config.tcTemplate;
	m_strGroupG		= config.tcGroupG;
	m_strGroupH		= config.tcGroupH;
	m_strCheckChar	= config.tcCheckChar;

	

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void COcr::OnOK()
{
	UpdateData(TRUE);

	SymCodeOCR	config;

	config.ocrMode = (OCRMode)m_cbctlMode.GetCurSel();
	config.ocrDirection = (OCRDirection)m_cbctlDirection.GetCurSel();

	const TCHAR *pp = (LPCTSTR)(m_strTemplate);
	wcscpy(config.tcTemplate, pp);

	pp = (LPCTSTR)m_strGroupG;
	wcscpy(config.tcGroupG, pp);

	pp = (LPCTSTR)m_strGroupH;
	wcscpy(config.tcGroupH, pp);

	pp = (LPCTSTR)m_strCheckChar;
	wcscpy(config.tcCheckChar, pp);

	g_scan.WriteSymbologyConfig(config);

	CDialog::OnOK();
}