#pragma once


// CPlanetPostnet dialog

class CPlanetPostnet : public CDialog
{
	DECLARE_DYNAMIC(CPlanetPostnet)

public:
	CPlanetPostnet(CWnd* pParent = NULL);   // standard constructor
	CPlanetPostnet(CString title, int SymID, CWnd* pParent = NULL);

	virtual ~CPlanetPostnet();

// Dialog Data
	enum { IDD = IDD_PLANET_POSTNET };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnOK();

	DECLARE_MESSAGE_MAP()
public:
	int m_nSymID;

	CString m_strBarcodeName;
	BOOL m_bEnable;
	BOOL m_bCheckSend;

	virtual BOOL OnInitDialog();
};
