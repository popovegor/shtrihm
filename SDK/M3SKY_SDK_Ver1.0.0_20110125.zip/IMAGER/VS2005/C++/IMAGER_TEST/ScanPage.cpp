// ScanPage.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "ScanPage.h"

#include "MainSheet.h"

#include "Centering.h"		// Centering setting Dialog
#include "Preview.h"



// CScanPage dialog

IMPLEMENT_DYNAMIC(CScanPage, CPropertyPage)

CScanPage::CScanPage()
	: CPropertyPage(CScanPage::IDD)
{
	m_bFirstCentering = TRUE;
}

CScanPage::~CScanPage()
{
}

void CScanPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_BARCODE, m_BarcodeList);
}


BEGIN_MESSAGE_MAP(CScanPage, CPropertyPage)
	ON_BN_CLICKED(IDC_BTN_SCAN, &CScanPage::OnBnClickedBtnScan)
	ON_BN_CLICKED(IDC_BTN_CLEAR, &CScanPage::OnBnClickedBtnClear)
	ON_BN_CLICKED(IDC_BTN_INFO, &CScanPage::OnBnClickedBtnInfo)
	ON_BN_CLICKED(IDC_BTN_CENTERING, &CScanPage::OnBnClickedBtnCentering)
END_MESSAGE_MAP()


// CScanPage message handlers

BOOL CScanPage::OnInitDialog()
{
	CPropertyPage::OnInitDialog();

	// TODO:  Add extra initialization here
	switch(GetSystemMetrics(SM_CXSCREEN))
	{
	case 240:
		m_BarcodeList.InsertColumn(0,L"Type",LVCFMT_LEFT,80);
		m_BarcodeList.InsertColumn(1,L"Data",LVCFMT_LEFT,152);
		break;
	case 480:
		m_BarcodeList.InsertColumn(0,L"Type",LVCFMT_LEFT,162);
		m_BarcodeList.InsertColumn(1,L"Data",LVCFMT_LEFT,312);
		break;
	}

	

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}


void CScanPage::OnBnClickedBtnScan()
{
 	CMainSheet *dlg = (CMainSheet *)AfxGetMainWnd();
 	dlg->ScanRead();

}

void CScanPage::OnBnClickedBtnClear()
{
	m_BarcodeList.DeleteAllItems();
}

void CScanPage::OnBnClickedBtnInfo()
{
	CMainSheet *dlg = (CMainSheet *)AfxGetMainWnd();
	dlg->GetInfo();

}




void CScanPage::OnBnClickedBtnCentering()
{

// 	DEVMODE devmode = {0};
// 
// 	devmode.dmSize = sizeof(DEVMODE);
// 	devmode.dmDisplayOrientation = DMDO_90; //landscape mode
// 	devmode.dmFields = DM_DISPLAYORIENTATION;
// 	ChangeDisplaySettingsEx(NULL, &devmode, NULL, 0, NULL);
// 	::ShowWindow( ::SHFindMenuBar(m_hWnd), SW_HIDE );


/*
	BOOL rb;
	BOOL chgScreen;
	int rc;
	RECT rect;
	HWND hWnd;

	rb = SystemParametersInfo(SPI_GETWORKAREA, 0, &rect, 0);
	if (rb == FALSE)  // SystemParametersInfo failed.
	{
		rc = MessageBox(_T("Could not get work area."),
			_T("Error"), MB_OK);
		if (rc == 0)  // Not enough memory to create MessageBox.
			return ;//E_OUTOFMEMORY;
		return;// E_FAIL;  // Replace with specific error handling.
	}

	GetWindowRect(&rect);
	chgScreen = SHFullScreen(hWnd, SHFS_HIDETASKBAR | SHFS_HIDESIPBUTTON | 
		SHFS_HIDESTARTICON);
	if (chgScreen == FALSE);
	{
		// SHFullScreen failed.
		rc = MessageBox(_T("Could not modify the window."),
			_T("Error"), MB_OK);
		if (rc == 0)  // Not enough memory to create MessageBox.
			return;// E_OUTOFMEMORY;
		return;// E_FAIL;  // Replace with specific error handling.
	}
	MoveWindow( 
		rect.left, 
		rect.top - 20, 
		rect.right, 
		rect.bottom + 20, 
		TRUE);


	
	*/ 


	if(m_bFirstCentering)
	{
		RECT rect;
		BOOL bEnableCentering;
		if(GetDecodeCenteringWindow(SETUP_CURRENT, &bEnableCentering, &rect))
		{
			//	���͸� ������ �ʹ� ũ�� �ٸ����� ������ ������ �־ �⺻���� ���� �۰� ������  [2009/1/28 11:50:25 JU]
			//	Width range (0 ~ 479) width = 150, 
			//	Hight range (0 ~ 751) hight = 150 , 

			//	left = (width max<480> - width default <150>) / 2
			//	right = width max<480> - ((width max<480> - width default <150>) / 2)			
			rect.left	= 165;//90;
			rect.right	= 315;//390;
			rect.top	= 301;//276;
			rect.bottom	= 451;//476;
			if(SetDecodeCenteringWindow(bEnableCentering, &rect))
			{
				m_bFirstCentering = FALSE;
			}
		}
	}



	CPreview dlg; //CCentering dlg;
	dlg.DoModal();

	HWND hTaskBar   = ::FindWindow(TEXT("HHTaskBar"),NULL);
	::ShowWindow(hTaskBar, SW_SHOW);

// 	devmode.dmSize = sizeof(DEVMODE);
// 	devmode.dmDisplayOrientation = DMDO_0; //landscape mode
// 	devmode.dmFields = DM_DISPLAYORIENTATION;
// 	ChangeDisplaySettingsEx(NULL, &devmode, NULL, 0, NULL);
// 	::ShowWindow( ::SHFindMenuBar(m_hWnd), SW_SHOW );
}
