// Preview.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "Preview.h"
#include "M3MobileImager.h"


#define MM3_WIDTH	480

// CPreview dialog

IMPLEMENT_DYNAMIC(CPreview, CDialog)

CPreview::CPreview(CWnd* pParent /*=NULL*/)
	: CDialog(CPreview::IDD, pParent)
	, m_bEnableCentering(FALSE)
	, m_nWidth(0)
	, m_nHight(0)
{

}

CPreview::~CPreview()
{
}

void CPreview::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_ENABLE_CENTERING, m_bEnableCentering);
	DDX_Text(pDX, IDC_EDIT_WIDTH, m_nWidth);
	DDX_Text(pDX, IDC_EDIT_HIGHT, m_nHight);
}


BEGIN_MESSAGE_MAP(CPreview, CDialog)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_BN_CLICKED(IDOK, &CPreview::OnBnClickedOk)
	ON_WM_MOUSEMOVE()
END_MESSAGE_MAP()


int rate = 3;

// CPreview message handlers

BOOL CPreview::OnInitDialog()
{

//	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here

	::ShowWindow(::SHFindMenuBar(this->m_hWnd), SW_HIDE); // ���� �׶��� ���� 
	::SetForegroundWindow(m_hWnd); // �׽�ũ�� ���� 
	::SHFullScreen(m_hWnd, SHFS_HIDETASKBAR|SHFS_HIDESIPBUTTON); // ��üȭ������ ���� �κ�������Ʈ ��Ŵ 

	int width = GetSystemMetrics (SM_CXSCREEN);
	int height = GetSystemMetrics(SM_CYSCREEN);

	MoveWindow(0, 0, width, height, TRUE);
	
	GetDecodeCenteringWindow(SETUP_CURRENT, &m_bEnableCentering, &m_Rect);

	//	m_bSetMode = FALSE;


	if(MM3_WIDTH == width)
	{
		m_nLeft		= m_Rect.left*2/3;
		m_nRight	= m_Rect.right*2/3;
		m_nTop		= m_Rect.top*2/3;
		m_nBottom	= m_Rect.bottom*2/3;
	}
	else
	{
		m_nLeft		= m_Rect.left/rate;
		m_nRight	= m_Rect.right/rate;
		m_nTop		= m_Rect.top/rate;
		m_nBottom	= m_Rect.bottom/rate;
	}


	m_nWidth = m_Rect.right  - m_Rect.left;
	m_nHight = m_Rect.bottom - m_Rect.top;


	// ó�� ��ġ�� ��ǥ�� ��� ������ �Ѿ��� 
	if(MM3_WIDTH == width)
	{
		m_PrePoint.x = m_nLeft + m_nWidth *4/3	+ 60;
		m_PrePoint.y = m_nTop + m_nHight *4/3	+ 94;
	}
	else
	{
		m_PrePoint.x = m_nLeft + m_nWidth / rate*2 + 40;
		m_PrePoint.y = m_nTop + m_nHight / rate*2 + 35;
	}

	UpdateData(FALSE);



	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CPreview::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: Add your message handler code here
	// Do not call CDialog::OnPaint() for painting messages



	//	�ܸ��� ȭ���� resolution�� ���� ó���� �ϵ��� ����, ���� ������ �����Ǹ� vga, qvga �Լ��� ���� ó���ϱ� 
	//	�켱 if ������ ó���ϱ� 

	CRect rect;

	int width = GetSystemMetrics(SM_CXSCREEN);

	if(240 == width)	//	screen 240 * 320 size 
	{	
		if((m_nLeft >= 0) && (m_nRight <= 480/rate))
		{
			if((m_nTop >= 0) && (m_nBottom <= 752/rate))//245))
			{
				CBitmap bmp;
				if(bmp.LoadBitmap(IDB_BITMAP_CENTERING))
				{
					// Get the size of the bitmap
					BITMAP bmpInfo;
					bmp.GetBitmap(&bmpInfo);

					// Create an in-memory DC compatible with the
					// display DC we're using to paint
					CDC dcMemory;
					dcMemory.CreateCompatibleDC(&dc);

					// Select the bitmap into the in-memory DC
					CBitmap* pOldBitmap = dcMemory.SelectObject(&bmp);

					dc.StretchBlt(40, 35, 160, 250, &dcMemory, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY);

				}

				CBrush nullBrush;

				dc.SelectObject(GetStockObject(NULL_BRUSH));

				CPen penRed;
				penRed.CreatePen(PS_SOLID, 1, RGB(255, 0, 0));
				CPen* pOldPen = dc.SelectObject(&penRed);
				dc.Rectangle(m_nLeft+40, m_nTop+35, m_nRight+40, m_nBottom+35);

				// put back the old objects
				dc.SelectObject(pOldPen);
			}			
		}
	}
	else
	{	
		if((m_nLeft >= 0) && (m_nRight <= 480*2/3))
		{
			if((m_nTop >= 0) && (m_nBottom <= 752*2/3))//245))
			{
				CBitmap bmp;
				if(bmp.LoadBitmap(IDB_BITMAP_CENTERING))
				{
					// Get the size of the bitmap
					BITMAP bmpInfo;
					bmp.GetBitmap(&bmpInfo);

					// Create an in-memory DC compatible with the
					// display DC we're using to paint
					CDC dcMemory;
					dcMemory.CreateCompatibleDC(&dc);

					// Select the bitmap into the in-memory DC
					CBitmap* pOldBitmap = dcMemory.SelectObject(&bmp);

					dc.StretchBlt(80, 69, 320, 501, &dcMemory, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY);

				}

				CBrush nullBrush;

				dc.SelectObject(GetStockObject(NULL_BRUSH));

				CPen penRed;
				penRed.CreatePen(PS_SOLID, 1, RGB(255, 0, 0));
				CPen* pOldPen = dc.SelectObject(&penRed);
				dc.Rectangle(m_nLeft+80, m_nTop+69, m_nRight+80, m_nBottom+69);

				// put back the old objects
				dc.SelectObject(pOldPen);
			}			
		}
	}


}

void CPreview::OnLButtonDown(UINT nFlags, CPoint point)
{
	m_nTempWidth = m_nWidth;
	m_nTempHight = m_nHight;

	UpdateData(TRUE);

	if((m_nWidth>479) || (m_nHight>751))
	{
		m_nWidth = m_nTempWidth;
		m_nHight = m_nTempHight;
		
		UpdateData(FALSE);
	}

	// TODO: Add your message handler code here and/or call default
	CWnd* WndStaticMsg = GetDlgItem(IDC_STATIC_MSG);
	if(WndStaticMsg->IsWindowVisible())
	{
		WndStaticMsg->ShowWindow(FALSE);		
	}
	else
	{
		DrawSet(point);	
		
//		if((m_nLeft >= 0) && (m_nTop >= 0) && (m_nRight <= 480/rate) && (m_nBottom <= 752/rate))//245))

		if((m_nLeft >= 0) && (m_nTop >= 0)) //245))
		{
			int width = GetSystemMetrics (SM_CXSCREEN);

			if(MM3_WIDTH == width)
			{
				if((m_nRight <= 480 *2 /3 ) && (m_nBottom <= 752 *2 /3))
				{
					m_PrePoint = point;

					CDialog::OnLButtonDown(nFlags, point);
				}
			}
			else
			{
				if((m_nRight <= 480/rate) && (m_nBottom <= 752/rate))
				{
					m_PrePoint = point;

					CDialog::OnLButtonDown(nFlags, point);
				}
			}
		}
			
		DrawSet(m_PrePoint);
		
	}


	CDialog::OnLButtonDown(nFlags, point);
}

void CPreview::DrawSet(CPoint point)
{
	//	if(m_bSetMode)	//	setting mode
	{
		int width = GetSystemMetrics(SM_CXSCREEN);

		if(240 == width)	//	screen 240 * 320 size 
		{

			int nWidthValue = m_nWidth / 6;
			m_nLeft = point.x - nWidthValue - 40;
			m_nRight = point.x + nWidthValue - 40;

			int nHightValue = m_nHight / 6;
			m_nTop = point.y - nHightValue - 35;
			m_nBottom = point.y + nHightValue - 35;

			RECT rect;
			rect.left	= 0;
			rect.bottom = 320;
			rect.right	= 240;
			rect.top	= 0;
			InvalidateRect(&rect, FALSE);
		}
		else
		{
			int nWidthValue = m_nWidth / 3;
			m_nLeft = point.x - nWidthValue - 80;
			m_nRight = point.x + nWidthValue - 80;

			int nHightValue = m_nHight / 3;
			m_nTop = point.y - nHightValue - 69;
			m_nBottom = point.y + nHightValue - 69;

			RECT rect;
			rect.left	= 0;
			rect.bottom = 640;
			rect.right	= 480;
			rect.top	= 0;
			InvalidateRect(&rect, FALSE);
		}

	}
}
void CPreview::OnBnClickedOk()
{
	UpdateData(TRUE);

	int width = GetSystemMetrics (SM_CXSCREEN);
	
	if(MM3_WIDTH == width)
	{
		m_Rect.left		= m_nLeft	* 3 /2;
		m_Rect.top		= m_nTop	* 3 /2 ;
		m_Rect.right	= m_Rect.left + m_nWidth;
		m_Rect.bottom	= m_Rect.top  + m_nHight;
	}
	else
	{
		m_Rect.left		= m_nLeft	* rate;
		m_Rect.top		= m_nTop	* rate;
		m_Rect.right	= m_Rect.left + m_nWidth;
		m_Rect.bottom	= m_Rect.top  + m_nHight;

	}

	SetDecodeCenteringWindow(m_bEnableCentering, &m_Rect);

	// TODO: Add your control notification handler code here
	OnOK();
}



void CPreview::OnMouseMove(UINT nFlags, CPoint point)
{
	CWnd* WndStaticMsg = GetDlgItem(IDC_STATIC_MSG);
	if(WndStaticMsg->IsWindowVisible())
	{
		WndStaticMsg->ShowWindow(FALSE);		
	}
	else
	{
		DrawSet(point);	

		if((m_nLeft >= 0) && (m_nTop >= 0))
		{
			int width = GetSystemMetrics (SM_CXSCREEN);

			if(MM3_WIDTH == width)
			{	
				if((m_nRight <= 480 *2 /3 ) && (m_nBottom <= 752 *2 /3))
				{
					m_PrePoint = point;
					CDialog::OnMouseMove(nFlags, point);
				}
			}
			else
			{
				if((m_nRight <= 480/rate) && (m_nBottom <= 752/rate))
				{
					m_PrePoint = point;
					CDialog::OnMouseMove(nFlags, point);
				}

			}
		}
			DrawSet(m_PrePoint);
	}
	// TODO: Add your message handler code here and/or call default

	CDialog::OnMouseMove(nFlags, point);
}
