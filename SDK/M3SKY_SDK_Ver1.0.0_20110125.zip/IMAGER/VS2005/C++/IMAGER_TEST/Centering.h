#pragma once
#include "afxwin.h"
#include "afxcmn.h"


// CCentering dialog

class CCentering : public CDialog
{
	DECLARE_DYNAMIC(CCentering)

public:
	CCentering(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCentering();

// Dialog Data
	enum { IDD = IDD_CENTERING };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCheckEnableCentering();


//	control
	CStatic m_ctlgrIntersectionWindow;

	CEdit m_ctledLeft;
	CEdit m_ctledTop;
	CEdit m_ctledRight;
	CEdit m_ctledBottom;

	CSpinButtonCtrl m_ctlspLeft;
	CSpinButtonCtrl m_ctlspTop;
	CSpinButtonCtrl m_ctlspRight;
	CSpinButtonCtrl m_ctlspBottom;

//	value
	BOOL m_bEnableCentering;
	
	LONG m_lnedLeft;
	LONG m_lnedTop;
	LONG m_lnedRight;
	LONG m_lnedBottom;
	
	
	
	
	CStatic m_ctlstLeft;
	CStatic m_ctlstTop;
	CStatic m_ctlstRight;
	CStatic m_ctlstBottom;
};
