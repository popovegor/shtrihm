#pragma once


// CTelepen dialog

class CTelepen : public CDialog
{
	DECLARE_DYNAMIC(CTelepen)

public:
	CTelepen(CWnd* pParent = NULL);   // standard constructor
	virtual ~CTelepen();

// Dialog Data
	enum { IDD = IDD_TELEPEN };

protected:
	virtual void OnOK();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	DWORD m_dwMinLen;
	DWORD m_dwMaxLen;
	BOOL	m_bEnable;
	BOOL	m_bOldStyle;
	virtual BOOL OnInitDialog();
};
