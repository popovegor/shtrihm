#pragma once


// CUPCE dialog

class CUPCE : public CDialog
{
	DECLARE_DYNAMIC(CUPCE)

public:
	CUPCE(CWnd* pParent = NULL);   // standard constructor
	virtual ~CUPCE();

// Dialog Data
	enum { IDD = IDD_UPCE };

protected:
	virtual void OnOK();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	BOOL m_bE0Enable;
	BOOL m_bE1Enable;
	BOOL m_bCheckSend;
	BOOL m_bExpandeE;
	BOOL m_bAddenda2;
	BOOL m_bAddenda5;
	BOOL m_bAddendaReq;
	BOOL m_bAddendaSep;
	BOOL m_bNumSysTrans;
	virtual BOOL OnInitDialog();
};
