#pragma once
#include "afxcmn.h"


// CSymPage dialog

class CSymPage : public CPropertyPage
{
	DECLARE_DYNAMIC(CSymPage)

private:
	BOOL m_Symbology[ 50 ]; // Array passed to symbology


public:
	CSymPage();
	virtual ~CSymPage();

// Dialog Data
	enum { IDD = IDD_SYMPAGE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CListCtrl		m_listctlSymbol;

	virtual BOOL OnInitDialog();

	afx_msg void OnBnClickedButtonAll();
	afx_msg void OnBnClickedButtonDefault();
	afx_msg void OnNMClickListSymbology(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMCustomdrawListSymbology(NMHDR *pNMHDR, LRESULT *pResult);
	

public:
};
