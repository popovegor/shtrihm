/********************************************************************
	created:	2008/12/30
	created:	30:12:2008   10:26
	filename: 	c:\data\01. �۾�\1. ���And������Ʈ\01.��ĳ�� ������Ʈ\7700s\7700_Scanner(20081230)\Scan3\Centering.cpp
	file path:	c:\data\01. �۾�\1. ���And������Ʈ\01.��ĳ�� ������Ʈ\7700s\7700_Scanner(20081230)\Scan3
	file base:	Centering
	file ext:	cpp
	author:		JU
	
	purpose:	Centering setting 
	report:		CCentering class��  ��Ʈ�ѷ� �����ϱ�
				Centering�� ���� �� �� �ִ� �ּ� �ִ밪�� �ľ��Ͽ��� �Է� ���� ���� ����ó�� �߰�  [2008/12/30 16:07:14 JU]

*********************************************************************/
#include "stdafx.h"
#include "Scan3.h"
#include "Centering.h"

#include "M3MobileImager.h"


// CCentering dialog

IMPLEMENT_DYNAMIC(CCentering, CDialog)

CCentering::CCentering(CWnd* pParent /*=NULL*/)
	: CDialog(CCentering::IDD, pParent)
	, m_bEnableCentering(FALSE)
	, m_lnedLeft(0)
	, m_lnedTop(0)
	, m_lnedRight(0)
	, m_lnedBottom(0)
{

}

CCentering::~CCentering()
{
}

void CCentering::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_ENABLE_CENTERING, m_bEnableCentering);
	DDX_Control(pDX, IDC_EDIT_LEFT, m_ctledLeft);
	DDX_Control(pDX, IDC_EDIT_TOP, m_ctledTop);
	DDX_Control(pDX, IDC_EDIT_RIGHT, m_ctledRight);
	DDX_Control(pDX, IDC_EDIT_BOTTOM, m_ctledBottom);
	DDX_Text(pDX, IDC_EDIT_LEFT, m_lnedLeft);
	DDX_Text(pDX, IDC_EDIT_TOP, m_lnedTop);
	DDX_Text(pDX, IDC_EDIT_RIGHT, m_lnedRight);
	DDX_Text(pDX, IDC_EDIT_BOTTOM, m_lnedBottom);
	DDX_Control(pDX, IDC_SPIN_LEFT, m_ctlspLeft);
	DDX_Control(pDX, IDC_SPIN_TOP, m_ctlspTop);
	DDX_Control(pDX, IDC_SPIN_RIGHT, m_ctlspRight);
	DDX_Control(pDX, IDC_SPIN_BOTTOM, m_ctlspBottom);
	DDX_Control(pDX, IDC_STATIC_INTERSECTION_WINDOW, m_ctlgrIntersectionWindow);
	DDX_Control(pDX, IDC_STATIC_LEFT, m_ctlstLeft);
	DDX_Control(pDX, IDC_STATIC_TOP, m_ctlstTop);
	DDX_Control(pDX, IDC_STATIC_RIGHT, m_ctlstRight);
	DDX_Control(pDX, IDC_STATIC_BOTTOM, m_ctlstBottom);
}


BEGIN_MESSAGE_MAP(CCentering, CDialog)
	ON_BN_CLICKED(IDOK, &CCentering::OnBnClickedOk)
	ON_BN_CLICKED(IDC_CHECK_ENABLE_CENTERING, &CCentering::OnBnClickedCheckEnableCentering)
END_MESSAGE_MAP()


// CCentering message handlers
BOOL CCentering::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here

	RECT	rect;

	if(!GetDecodeCenteringWindow(SETUP_CURRENT, &m_bEnableCentering, &rect))
	{
		MessageBox(L"Retry please");
		return FALSE;
	}

	m_ctlspLeft.SetRange32(0,478);
	m_ctlspTop.SetRange32(0,750);
	m_ctlspRight.SetRange32(1,479);
	m_ctlspBottom.SetRange32(1, 751);


	m_lnedLeft		= rect.left;
	m_lnedTop	    = rect.top;
	m_lnedRight		= rect.right;
	m_lnedBottom	= rect.bottom;
	

	if(!m_bEnableCentering)
	{
		m_ctlstLeft.EnableWindow(FALSE);
		m_ctlstTop.EnableWindow(FALSE);
		m_ctlstRight.EnableWindow(FALSE);
		m_ctlstBottom.EnableWindow(FALSE);

		m_ctledLeft.EnableWindow(FALSE);
		m_ctledTop.EnableWindow(FALSE);
		m_ctledRight.EnableWindow(FALSE);
		m_ctledBottom.EnableWindow(FALSE);

		m_ctlspLeft.EnableWindow(FALSE);
		m_ctlspTop.EnableWindow(FALSE);
		m_ctlspRight.EnableWindow(FALSE);
		m_ctlspBottom.EnableWindow(FALSE);
	}

	UpdateData(FALSE);
	


	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}


void CCentering::OnBnClickedOk()
{
	UpdateData(TRUE);

	if((0 > m_lnedLeft) || (m_lnedLeft >= m_lnedRight))
	{
		MessageBox(L"Left: 0 ~ right");
		return;
	}

	if(m_lnedRight > 479)
	{
		MessageBox(L"Right: left+1 ~ 479");
		return;
	}

	if((0 >  m_lnedTop) || (m_lnedTop >= m_lnedBottom))
	{
		MessageBox(L"Top: 0 ~ right");
		return;
	}

	if(m_lnedBottom > 751)
	{
		MessageBox(L"Bottom: Top+1 ~ 751");
		return;
	}
	
	RECT rect;

	rect.left		= m_lnedLeft;
	rect.top		= m_lnedTop;
	rect.right		= m_lnedRight;
	rect.bottom		= m_lnedBottom;

	SetDecodeCenteringWindow(m_bEnableCentering, &rect);



	OnOK();
}


void CCentering::OnBnClickedCheckEnableCentering()
{
	UpdateData(TRUE);

	m_ctlgrIntersectionWindow.EnableWindow(m_bEnableCentering);

	m_ctlstLeft.EnableWindow(m_bEnableCentering);
	m_ctlstTop.EnableWindow(m_bEnableCentering);
	m_ctlstRight.EnableWindow(m_bEnableCentering);
	m_ctlstBottom.EnableWindow(m_bEnableCentering);

	m_ctledLeft.EnableWindow(m_bEnableCentering);
	m_ctledTop.EnableWindow(m_bEnableCentering);
	m_ctledRight.EnableWindow(m_bEnableCentering);
	m_ctledBottom.EnableWindow(m_bEnableCentering);

	m_ctlspLeft.EnableWindow(m_bEnableCentering);
	m_ctlspTop.EnableWindow(m_bEnableCentering);
	m_ctlspRight.EnableWindow(m_bEnableCentering);
	m_ctlspBottom.EnableWindow(m_bEnableCentering);
}
