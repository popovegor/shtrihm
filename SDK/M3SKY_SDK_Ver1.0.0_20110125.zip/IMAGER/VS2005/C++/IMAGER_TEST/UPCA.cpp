// UPCA.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "UPCA.h"

#include "M3MobileImager.h"

extern IScan g_scan;

// CUPCA dialog

IMPLEMENT_DYNAMIC(CUPCA, CDialog)

CUPCA::CUPCA(CWnd* pParent /*=NULL*/)
	: CDialog(CUPCA::IDD, pParent)
	, m_bEnable(FALSE)
	, m_bCheckSend(FALSE)
	, m_bAddenda2(FALSE)
	, m_bAddenda5(FALSE)
	, m_bAddendaReq(FALSE)
	, m_bAddendaSep(FALSE)
	, m_bNumSysTrans(FALSE)
{

}

CUPCA::~CUPCA()
{
}

void CUPCA::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_UPCA_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_CHECKSEND_UPCA, m_bCheckSend);
	DDX_Check(pDX, IDC_CHECK_UPCA_ADDENDA2, m_bAddenda2);
	DDX_Check(pDX, IDC_CHECK_UPCA_ADDENDA5, m_bAddenda5);
	DDX_Check(pDX, IDC_CHECK_UPCA_ADDENDAREQ, m_bAddendaReq);
	DDX_Check(pDX, IDC_CHECK_UPCA_ADDENDASEP, m_bAddendaSep);
	DDX_Check(pDX, IDC_CHECK_UPCA_NUMSYSTRANS, m_bNumSysTrans);
}


BEGIN_MESSAGE_MAP(CUPCA, CDialog)
END_MESSAGE_MAP()


// CUPCA message handlers

BOOL CUPCA::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here

	SymFlagsOnly config;

	g_scan.ReadSymbologyConfig(SETUP_CURRENT, ID_UPCA, &config);

	if(config.dwFlags & SYM_ENABLE)
		m_bEnable = TRUE;

	if(config.dwFlags & SYM_CHECK_TRANSMIT)
		m_bCheckSend = TRUE;

	if(config.dwFlags & SYM_2_DIGIT_ADDENDA)
		m_bAddenda2 = TRUE;

	if(config.dwFlags & SYM_5_DIGIT_ADDENDA)
		m_bAddenda5 = TRUE;

	if(config.dwFlags & SYM_ADDENDA_REQUIRED)
		m_bAddendaReq = TRUE;

	if(config.dwFlags & SYM_ADDENDA_SEPARATOR)
		m_bAddendaSep = TRUE;

	if(config.dwFlags & SYM_NUM_SYS_TRANSMIT)
		m_bNumSysTrans = TRUE;

	UpdateData(FALSE);


	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
void CUPCA::OnOK()
{
	UpdateData(TRUE);

	SymFlagsOnly config;

	if(m_bEnable)
		config.dwFlags = SYM_ENABLE;
	else
		config.dwFlags = 0;

	if(m_bCheckSend)
		config.dwFlags |= SYM_CHECK_TRANSMIT;

	if(	m_bAddenda2)
		config.dwFlags |= SYM_2_DIGIT_ADDENDA;

	if(m_bAddenda5)
		config.dwFlags |= SYM_5_DIGIT_ADDENDA;		

	if(m_bAddendaReq )
		config.dwFlags |= SYM_ADDENDA_REQUIRED;		

	if(m_bAddendaSep)
		config.dwFlags |= SYM_ADDENDA_SEPARATOR;

	if(m_bNumSysTrans)
		config.dwFlags |= SYM_NUM_SYS_TRANSMIT;

	g_scan.WriteSymbologyConfig(ID_UPCA, config);

	// TODO: Add your control notification handler code here
	CDialog::OnOK();
}

