// PlanetPostnet.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "PlanetPostnet.h"

#include "M3MobileImager.h"

extern IScan g_scan;


// CPlanetPostnet dialog

IMPLEMENT_DYNAMIC(CPlanetPostnet, CDialog)

CPlanetPostnet::CPlanetPostnet(CWnd* pParent /*=NULL*/)
	: CDialog(CPlanetPostnet::IDD, pParent)
	, m_strBarcodeName(_T(""))
	, m_bEnable(FALSE)
	, m_bCheckSend(FALSE)
{

}

CPlanetPostnet::CPlanetPostnet(CString title, int SymID, CWnd* pParent /*= NULL*/): CDialog(CPlanetPostnet::IDD, pParent)
, m_strBarcodeName(_T(""))
, m_bEnable(FALSE)
, m_bCheckSend(FALSE)
{
	m_strBarcodeName = title;
	m_nSymID = SymID;
	
}

CPlanetPostnet::~CPlanetPostnet()
{
}

void CPlanetPostnet::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_STATIC_TITLE, m_strBarcodeName);
	DDX_Check(pDX, IDC_CHECK_PLANETPOSTNET_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_PLANETPOSTNET_CHECKSEND, m_bCheckSend);
}


BEGIN_MESSAGE_MAP(CPlanetPostnet, CDialog)
END_MESSAGE_MAP()


// CPlanetPostnet message handlers
BOOL CPlanetPostnet::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here
	SetWindowText(m_strBarcodeName);

	SymFlagsOnly config;
	g_scan.ReadSymbologyConfig(SETUP_CURRENT, m_nSymID, &config);

	if(config.dwFlags & SYM_ENABLE)
		m_bEnable = TRUE;

	if(config.dwFlags & SYM_CHECK_TRANSMIT)
		m_bCheckSend = TRUE;

	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}


void CPlanetPostnet::OnOK()
{
	UpdateData(TRUE);
	SymFlagsOnly config;

	if(m_bEnable)
		config.dwFlags = SYM_ENABLE;
	else
		config.dwFlags = 0;

	if(m_bCheckSend)
		config.dwFlags |= SYM_CHECK_TRANSMIT;

	g_scan.WriteSymbologyConfig(m_nSymID, config);
	
	// TODO: Add your control notification handler code here
	CDialog::OnOK();
}

