#pragma once


// CMsi dialog

class CMsi : public CDialog
{
	DECLARE_DYNAMIC(CMsi)

public:
	CMsi(CWnd* pParent = NULL);   // standard constructor
	virtual ~CMsi();

// Dialog Data
	enum { IDD = IDD_MSI };

protected:
	virtual void OnOK();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

public:
	DWORD m_dwMinLen;
	DWORD m_dwMaxLen;
	BOOL m_bEnable;
	BOOL m_bCheckSend;

	virtual BOOL OnInitDialog();
};
