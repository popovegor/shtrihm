#pragma once
#include "afxwin.h"


// CCode39 dialog

class CCode39 : public CDialog
{
	DECLARE_DYNAMIC(CCode39)

public:
	CCode39(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCode39();

// Dialog Data
	enum { IDD = IDD_CODE39 };

protected:
	virtual void OnOK();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	DWORD m_dwMinLen;
	DWORD m_dwMaxLen;
	BOOL m_bEnable;
	BOOL m_bCheck;
	BOOL m_bCheckSend;
	BOOL m_bStartStop;
	BOOL m_bAppend;
	BOOL m_bFullAscii;
	virtual BOOL OnInitDialog();
	CButton m_chctlCheckSend;
	afx_msg void OnBnClickedCheckCode39Check();
};
