// Code39.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "Code39.h"

#include "M3MobileImager.h"

extern IScan g_scan;
// CCode39 dialog

IMPLEMENT_DYNAMIC(CCode39, CDialog)

CCode39::CCode39(CWnd* pParent /*=NULL*/)
	: CDialog(CCode39::IDD, pParent)
	, m_dwMinLen(0)
	, m_dwMaxLen(0)
	, m_bEnable(FALSE)
	, m_bCheck(FALSE)
	, m_bCheckSend(FALSE)
	, m_bStartStop(FALSE)
	, m_bAppend(FALSE)
	, m_bFullAscii(FALSE)
{

}

CCode39::~CCode39()
{
}

void CCode39::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_CODE39_MIN, m_dwMinLen);
	DDX_Text(pDX, IDC_EDIT_CODE39_MAX, m_dwMaxLen);
	DDX_Check(pDX, IDC_CHECK_CODE39_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_CODE39_CHECK, m_bCheck);
	DDX_Check(pDX, IDC_CHECK_CODE39_CHECKSEND, m_bCheckSend);
	DDX_Check(pDX, IDC_CHECK_CODE39_STARTSTOP, m_bStartStop);
	DDX_Check(pDX, IDC_CHECK_CODE39_APPEND, m_bAppend);
	DDX_Check(pDX, IDC_CHECK_CODE39_FULLASCII, m_bFullAscii);
	DDX_Control(pDX, IDC_CHECK_CODE39_CHECKSEND, m_chctlCheckSend);
}


BEGIN_MESSAGE_MAP(CCode39, CDialog)
	ON_BN_CLICKED(IDC_CHECK_CODE39_CHECK, &CCode39::OnBnClickedCheckCode39Check)
END_MESSAGE_MAP()


// CCode39 message handlers


BOOL CCode39::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here

	SymFlagsRange config;

	g_scan.ReadSymbologyConfig(SETUP_CURRENT, ID_CODE39, &config);

	if(config.dwFlags & SYM_ENABLE)
		m_bEnable = TRUE;

	if(config.dwFlags & SYM_CHECK_ENABLE)
		m_bCheck = TRUE;

	if(config.dwFlags & SYM_CHECK_TRANSMIT)
		m_bCheckSend = TRUE;

	if(config.dwFlags & SYM_START_STOP_XMIT)
		m_bStartStop = TRUE;

	if(config.dwFlags & SYM_ENABLE_APPEND_MODE)
		m_bAppend = TRUE;

	if(config.dwFlags & SYM_ENABLE_FULLASCII)
		m_bFullAscii = TRUE;

	m_dwMaxLen = config.dwMaxLen;
	m_dwMinLen = config.dwMinLen;

	if(m_bCheck)
		m_chctlCheckSend.EnableWindow(TRUE);
	else
		m_chctlCheckSend.EnableWindow(FALSE);

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CCode39::OnOK()
{
	UpdateData(TRUE);

	SymFlagsRange config;

	CString errMessage;

//	code39�� 0~48�����̸�, HHP ���� ����
	config.dwMinLen = 0;
	config.dwMaxLen = 48;

	if((m_dwMaxLen<config.dwMinLen) || (m_dwMaxLen >config.dwMaxLen) || (m_dwMaxLen<config.dwMinLen) )
	{
		errMessage.Format(L"The maximum length of the corresponding barcode is from %d to %d, maximum length should be bigger than minimum length", config.dwMinLen, config.dwMaxLen);
		MessageBox(errMessage, L"Max Length");
		return;
	}

	if(m_dwMinLen <config.dwMinLen)
	{
		errMessage.Format(L"The minimum length of the corresponding barcode is  from %d to %d, minimum length should be shorter than maximum lenght", config.dwMinLen, config.dwMaxLen);
		MessageBox(errMessage, L"Min Length");
		return;
	}

	if(m_bEnable)
		config.dwFlags = SYM_ENABLE;
	else
		config.dwFlags = 0;
	
	if(m_bCheck)
		config.dwFlags |= SYM_CHECK_ENABLE;

	if(	m_bCheckSend)
		config.dwFlags |= SYM_CHECK_TRANSMIT;
	
	if(m_bStartStop)
		config.dwFlags |= SYM_START_STOP_XMIT;		

	if(m_bAppend )
		config.dwFlags |= SYM_ENABLE_APPEND_MODE;		

	if(m_bFullAscii)
		config.dwFlags |= SYM_ENABLE_FULLASCII;

	config.dwMaxLen = m_dwMaxLen;
	config.dwMinLen = m_dwMinLen;

	g_scan.WriteSymbologyConfig(ID_CODE39, config);

	// TODO: Add your control notification handler code here
	CDialog::OnOK();
}

void CCode39::OnBnClickedCheckCode39Check()
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);

	if(m_bCheck)
		m_chctlCheckSend.EnableWindow(TRUE);
	else
		m_chctlCheckSend.EnableWindow(FALSE);
}
