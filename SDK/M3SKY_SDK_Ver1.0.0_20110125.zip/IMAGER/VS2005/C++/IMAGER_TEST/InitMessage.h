#pragma once


// CInitMessage dialog

class CInitMessage : public CDialog
{
	DECLARE_DYNAMIC(CInitMessage)

public:
	CInitMessage(CWnd* pParent = NULL);   // standard constructor
	virtual ~CInitMessage();

// Dialog Data
	enum { IDD = IDD_INIT_MESSAGE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
};
