#pragma once


// CFlagsOnly dialog

class CFlagsOnly : public CDialog
{
	DECLARE_DYNAMIC(CFlagsOnly)

private:
	int m_SymID;
public:
	CFlagsOnly(CWnd* pParent = NULL);   // standard constructor
	CFlagsOnly(CString title, int SymID, CWnd* pParent = NULL);  
	virtual ~CFlagsOnly();

// Dialog Data
	enum { IDD = IDD_FLAGS_ONLY };

protected:
	virtual void OnOK();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CString m_strBarcodeName;
	BOOL m_bEnable;
	
	
	virtual BOOL OnInitDialog();
};
