#pragma once


// CAztecMesa dialog

class CAztecMesa : public CDialog
{
	DECLARE_DYNAMIC(CAztecMesa)

public:
	CAztecMesa(CWnd* pParent = NULL);   // standard constructor
	virtual ~CAztecMesa();

// Dialog Data
	enum { IDD = IDD_MESA };

protected:
	virtual void OnOK();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	BOOL m_bEnable;
	BOOL m_bIMS;
	BOOL m_b1MS;
	BOOL m_b3MS;
	BOOL m_b9MS;
	BOOL m_bUMS;
	BOOL m_bEMS;

	
	virtual BOOL OnInitDialog();
};