#pragma once
#include "afxwin.h"


// COcr dialog

class COcr : public CDialog
{
	DECLARE_DYNAMIC(COcr)

public:
	COcr(CWnd* pParent = NULL);   // standard constructor
	virtual ~COcr();

// Dialog Data
	enum { IDD = IDD_OCR };

protected:
	virtual void OnOK();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CComboBox m_cbctlMode;
	CComboBox m_cbctlDirection;
	CString m_strTemplate;
	CString m_strGroupG;
	CString m_strGroupH;
	CString m_strCheckChar;
	virtual BOOL OnInitDialog();
};
