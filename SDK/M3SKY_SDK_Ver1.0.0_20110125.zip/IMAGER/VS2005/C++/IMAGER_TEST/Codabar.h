#pragma once
#include "afxwin.h"


// CCodabar dialog

class CCodabar : public CDialog
{
	DECLARE_DYNAMIC(CCodabar)

public:
	CCodabar(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCodabar();

// Dialog Data
	enum { IDD = IDD_CODABAR };

protected:
	virtual void OnOK();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	
	DWORD m_dwMinLen;
	DWORD m_dwMaxLen;
	BOOL m_bEnable;
	BOOL m_bCheck;
	BOOL m_bCheckSend;
	BOOL m_bStartStop;
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedCheckCodabarCheck();
	CButton m_chctlCheckSend;
};
