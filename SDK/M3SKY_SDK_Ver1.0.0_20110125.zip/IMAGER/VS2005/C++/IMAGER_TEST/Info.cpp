// Info.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "Info.h"


// CInfo dialog

IMPLEMENT_DYNAMIC(CInfo, CDialog)

CInfo::CInfo(CWnd* pParent /*=NULL*/)
	: CDialog(CInfo::IDD, pParent)
	, m_strInfo(_T(""))
{

}

CInfo::~CInfo()
{
}

void CInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_INFO, m_strInfo);
	DDX_Control(pDX, IDC_STATIC_LOGO, m_ptLogo);
}


BEGIN_MESSAGE_MAP(CInfo, CDialog)
END_MESSAGE_MAP()


// CInfo message handlers

BOOL CInfo::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here

	if(GetSystemMetrics (SM_CXSCREEN)>240)	//	VGA
	{
		m_ptLogo.SetBitmap(LoadBitmap(AfxGetApp()->m_hInstance, MAKEINTRESOURCE(IDB_BITMAP_M3MOBILE_VGA_LOGO)));
		m_ptLogo.MoveWindow(36, 0, 383, 102, FALSE);
	}
	else
	{
		m_ptLogo.MoveWindow(43, 5, 151, 46, FALSE);
		m_ptLogo.SetBitmap(LoadBitmap(AfxGetApp()->m_hInstance, MAKEINTRESOURCE(IDB_BITMAP_M3MOBILE_QVGA_LOGO)));
	}

//	m_ptLogo.ShowWindow(SW_SHOW);

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
