#pragma once


// CEan8Ean13 dialog

class CEan8Ean13 : public CDialog
{
	DECLARE_DYNAMIC(CEan8Ean13)

public:
	CEan8Ean13(CWnd* pParent = NULL);   // standard constructor
	CEan8Ean13(CString title, int SymID, CWnd* pParent = NULL);

	virtual ~CEan8Ean13();

// Dialog Data
	enum { IDD = IDD_EAN8_EAN13 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnOK();

	DECLARE_MESSAGE_MAP()

public:
	int m_nSymID;
	CString m_strBarcodeName;
	virtual BOOL OnInitDialog();

	BOOL m_bEnable;
	BOOL m_bCheckSend;
	BOOL m_bAddenda2;
	BOOL m_bAddenda5;
	BOOL m_bAddendaReq;
	BOOL m_bAddendaSep;
	BOOL m_bISBN;
};
