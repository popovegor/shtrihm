#pragma once


// CUPCA dialog

class CUPCA : public CDialog
{
	DECLARE_DYNAMIC(CUPCA)

public:
	CUPCA(CWnd* pParent = NULL);   // standard constructor
	virtual ~CUPCA();

// Dialog Data
	enum { IDD = IDD_UPCA };

protected:
	virtual void OnOK();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	BOOL m_bEnable;
	BOOL m_bCheckSend;
	BOOL m_bAddenda2;
	BOOL m_bAddenda5;
	BOOL m_bAddendaReq;
	BOOL m_bAddendaSep;
	BOOL m_bNumSysTrans;
	virtual BOOL OnInitDialog();
};
