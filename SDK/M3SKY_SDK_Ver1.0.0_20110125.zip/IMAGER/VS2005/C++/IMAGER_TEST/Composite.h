#pragma once


// CComposite dialog

class CComposite : public CDialog
{
	DECLARE_DYNAMIC(CComposite)

public:
	CComposite(CWnd* pParent = NULL);   // standard constructor
	virtual ~CComposite();

// Dialog Data
	enum { IDD = IDD_COMPOSITE };

protected:
	virtual void OnOK();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	DWORD m_dwMinLen;
	DWORD m_dwMaxLen;
	BOOL m_bEnable;
	BOOL m_bEnableUPC;
	virtual BOOL OnInitDialog();
};
