#pragma once
#include "afxcmn.h"


// CScanPage dialog

class CScanPage : public CPropertyPage
{
	DECLARE_DYNAMIC(CScanPage)

public:
	BOOL m_bFirstCentering;

	CScanPage();
	virtual ~CScanPage();

// Dialog Data
	enum { IDD = IDD_SCANPAGE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CListCtrl m_BarcodeList;

	virtual BOOL OnInitDialog();
	
	afx_msg void OnBnClickedBtnScan();
	afx_msg void OnBnClickedBtnClear();
	afx_msg void OnBnClickedBtnInfo();
	
	afx_msg void OnBnClickedBtnCentering();
};
