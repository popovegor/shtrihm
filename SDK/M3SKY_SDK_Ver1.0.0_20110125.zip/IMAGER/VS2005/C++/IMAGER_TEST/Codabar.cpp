// Codabar.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "Codabar.h"

#include "M3MobileImager.h"

extern IScan g_scan;


// CCodabar dialog

IMPLEMENT_DYNAMIC(CCodabar, CDialog)

CCodabar::CCodabar(CWnd* pParent /*=NULL*/)
	: CDialog(CCodabar::IDD, pParent)
	, m_dwMinLen(0)
	, m_dwMaxLen(0)
	, m_bEnable(FALSE)
	, m_bCheck(FALSE)
	, m_bCheckSend(FALSE)
	, m_bStartStop(FALSE)
{

}

CCodabar::~CCodabar()
{
}

void CCodabar::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_CODABAR_MIN, m_dwMinLen);
	DDX_Text(pDX, IDC_EDIT_CODABAR_MAX, m_dwMaxLen);
	DDX_Check(pDX, IDC_CHECK_CODABAR_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_CODABAR_CHECK, m_bCheck);
	DDX_Check(pDX, IDC_CHECK_CODABAR_CHECKSEND, m_bCheckSend);
	DDX_Check(pDX, IDC_CHECK_CODABAR_STARTSTOP, m_bStartStop);
	DDX_Control(pDX, IDC_CHECK_CODABAR_CHECKSEND, m_chctlCheckSend);
}


BEGIN_MESSAGE_MAP(CCodabar, CDialog)
	ON_BN_CLICKED(IDC_CHECK_CODABAR_CHECK, &CCodabar::OnBnClickedCheckCodabarCheck)
END_MESSAGE_MAP()


// CCodabar message handlers


BOOL CCodabar::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here

	SymFlagsRange config;

	g_scan.ReadSymbologyConfig(SETUP_CURRENT, ID_CODABAR, &config);

	if(config.dwFlags & SYM_ENABLE)
		m_bEnable = TRUE;
	
	if(config.dwFlags & SYM_START_STOP_XMIT)
		m_bStartStop = TRUE;

	if(config.dwFlags & SYM_CHECK_ENABLE)
		m_bCheck = TRUE;

	if(config.dwFlags & SYM_CHECK_TRANSMIT)
		m_bCheckSend = TRUE;

	m_dwMaxLen = config.dwMaxLen;
	m_dwMinLen = config.dwMinLen;

	if(m_bCheck)
		m_chctlCheckSend.EnableWindow(TRUE);
	else
		m_chctlCheckSend.EnableWindow(FALSE);

	UpdateData(FALSE);


	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}


void CCodabar::OnOK()
{
	UpdateData(TRUE);
	SymFlagsRange config;

	CString errMessage;
	g_scan.ReadSymbologyConfig(SETUP_DEFAULT, ID_CODABAR, &config);
	if((m_dwMaxLen<config.dwMinLen) || (m_dwMaxLen >config.dwMaxLen) || (m_dwMaxLen<config.dwMinLen) )
	{
		errMessage.Format(L"The maximum length of the corresponding barcode is from %d to %d, maximum length should be bigger than minimum length", config.dwMinLen, config.dwMaxLen);
		MessageBox(errMessage, L"Max Length");
		return;
	}

	if(m_dwMinLen <config.dwMinLen)
	{
		errMessage.Format(L"The minimum length of the corresponding barcode is  from %d to %d, minimum length should be shorter than maximum lenght", config.dwMinLen, config.dwMaxLen);
		MessageBox(errMessage, L"Min Length");
		return;
	}

















	if(m_bEnable)
		config.dwFlags = SYM_ENABLE;
	else
		config.dwFlags = 0;

	if(m_bCheck)
	{
		config.dwFlags |= SYM_CHECK_ENABLE;

		if(m_bCheckSend)
			config.dwFlags |= SYM_CHECK_TRANSMIT;
	}

	if(m_bStartStop)
		config.dwFlags |= SYM_START_STOP_XMIT;

	config.dwMaxLen = m_dwMaxLen;
	config.dwMinLen = m_dwMinLen;

	g_scan.WriteSymbologyConfig(ID_CODABAR, config);

	// TODO: Add your control notification handler code here
	CDialog::OnOK();
}

void CCodabar::OnBnClickedCheckCodabarCheck()
{
	UpdateData(TRUE);

	if(m_bCheck)
		m_chctlCheckSend.EnableWindow(TRUE);
	else
		m_chctlCheckSend.EnableWindow(FALSE);

}
