#pragma once


// CPreview dialog

class CPreview : public CDialog
{
	DECLARE_DYNAMIC(CPreview)

private:
	long	m_nTempWidth;
	long	m_nTempHight;


	long	m_nLeft;
	long	m_nRight;
	long	m_nTop;
	long	m_nBottom;
	RECT	m_Rect;

	CPoint	m_PrePoint;

public:
	CPreview(CWnd* pParent = NULL);   // standard constructor
//	CPreview(RECT *rect, CWnd* pParent = NULL); 
	void DrawSet(CPoint point);
	
	virtual ~CPreview();


	BOOL IsMM3();

// Dialog Data
	enum { IDD = IDD_PREVIEW };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	BOOL m_bEnableCentering;
	long m_nWidth;
	long m_nHight;
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnEnChangeEditWidth();
	afx_msg void OnEnChangeEditHight();
	afx_msg void OnBnClickedOk();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnEnKillfocusEditWidth();
};
