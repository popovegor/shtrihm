#pragma once
#include "afxwin.h"


// CInt25 dialog

class CInt25 : public CDialog
{
	DECLARE_DYNAMIC(CInt25)

public:
	CInt25(CWnd* pParent = NULL);   // standard constructor
	virtual ~CInt25();

// Dialog Data
	enum { IDD = IDD_INT25 };

protected:
	virtual void OnOK();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	DWORD m_dwMinLen;
	DWORD m_dwMaxLen;
	BOOL m_bEnable;
	BOOL m_bCheck;
	BOOL m_bCheckSend;
	
	virtual BOOL OnInitDialog();
	CButton m_chctlCheckSend;
	afx_msg void OnBnClickedCheckInt25Check();
};
