/********************************************************************
created		:	2008/09/19
file base	: 	M3ScanTest.exe

file ext	:	cpp
author		:	Dong-Hyun, Eum(vision7901)

purpose		:	M3 SKY / MM3
Report		:	2008. 09. 19 [09/19/2008 ju]		 v0.0.0 - ó�� ����Ǿ ���� ����
				2008. 09. 19 [09/19/2008 ju]		 v0.0.0 - WM_AUTOSCAN ���� ���� �ʿ��ϸ� �߰���
				2008. 10. 16 [10/16/2008 ju]		 v0.9.1 - ���̾�α� ��Ʈ������ - �������� �⺻��Ʈ ����� �޶����°� ����
				2008. 11. 24 [11/24/2008 ju]		 v1.0.0 - �ʱ�ȭ�� Symbology enable all
				2008. 12. 30 [12/30/2008 ju]		 v1.0.1 - Centering ��� �߰�
				2008. 10. 10 [10/10/2008 ju]		 v1.0.3 - Multidecoding, ScanningLight��� �߰�
															  MM3 ���� OS������Ʈ�� SystemParametersInfo�� ���� Ȯ���Ͽ��� �ϳ��� ���α׷����� ������ �� �ֵ��� ��
				2010. 01. 12 [01/12/2010 vision7901] v1.0.3 - Imager �μ��ΰ� 
				2010. 03. 08 [03/08/2010 vision7901] v2.0.0 - Dialog ����/ Beep �߰�/ GS1 ����
				2010. 04. 22 [04/22/2010 vision7901] v2.1.0 - TimeOut ���� �޺��ڽ��� ����
				2010. 08. 04 [08/04/2010 vision7901] v2.1.1 - Transmit AIMID �ɼ� �߰�
				2010. 10. 05 [10/05/2010 vision7901] v2.2.0 - M3SKY Summit/M3Orange SideKey ����
				2010. 10. 25 [10/25/2010 vision7901] v2.3.0 - SideKey Setting Dll�� �����Ͽ� ����
*********************************************************************/

#include "stdafx.h"
#include "Scan3.h"
#include "MainSheet.h"

#include "M3MobileImager.h"
#include "Info.h"

// #define WM_AUTOSCAN (WM_USER + 1025)		// auto 

IScan g_scan;

//	Global functions

// CMainSheet

IMPLEMENT_DYNAMIC(CMainSheet, CPropertySheet)

CMainSheet::CMainSheet(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{

}

CMainSheet::CMainSheet(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	AddPage(&m_scan);
	AddPage(&m_symbol);
	AddPage(&m_option);
}

CMainSheet::~CMainSheet()
{
	RemovePage(&m_option);
	RemovePage(&m_symbol);
	RemovePage(&m_option);
}


BEGIN_MESSAGE_MAP(CMainSheet, CPropertySheet)
	ON_WM_DESTROY()
	ON_MESSAGE(WM_SCAN_DATA,OnDataRead)
	ON_MESSAGE(WM_USER + 10043, OnDataRead)
END_MESSAGE_MAP()


// CMainSheet message handlers
BOOL CMainSheet::OnInitDialog()
{
	BOOL bResult = CPropertySheet::OnInitDialog();

	// TODO:  Add your specialized code here
	
	m_bEnableISBN	= FALSE;
	m_bKeyFlag		= FALSE;
	m_nTimeOut		= 5;	
	m_option.m_nSyncMode = 0;

	if(g_scan.Connect(TRUE) != TRUE)
		MessageBox(L"M3Imager Connect Failed");

	g_scan.SetScanMethods(NULL, m_hWnd, NULL);

	SHSetAppKeyWndAssoc(VK_F14, this->m_hWnd);				// Ű�߰� 

	
	SetEnableDisableSymbology(ID_ALL, TRUE);	

	EndWaitCursor();		// BeginWaitCursor(); Scan3.cpp
	return bResult;
}

BOOL CMainSheet::fnScan()
{

	g_scan.ScanLed(TRUE);

	g_scan.ScanLed(FALSE);	

	
	return TRUE;
}



BOOL CMainSheet::PreTranslateMessage(MSG* pMsg)
{

	if((pMsg->message == WM_KEYDOWN) && ((pMsg->wParam == VK_F14)))
	{
		if(m_bKeyFlag == FALSE)
		{
			m_bKeyFlag = TRUE;
			ScanRead();
		}
	}
	else
		if(pMsg->message == WM_KEYUP && pMsg->wParam == VK_F14)
			if(m_bKeyFlag == TRUE)
			{
				if(m_option.m_nSyncMode == 0)
					g_scan.CancelIO();

				m_bKeyFlag = FALSE;
			}

	return CPropertySheet::PreTranslateMessage(pMsg);
}



void CMainSheet::Check_Barcode(TCHAR chId, TCHAR chSymLetter, TCHAR chSymModifier, CString szCode)
{
	CString szSymbol;

	switch(chSymLetter)
	{
	case '<':
		szSymbol = L"CODE32";
		break;
	case 'l':
		szSymbol = L"CODE49";
		break;
	case 'M':
		szSymbol =L"USPS4CB";
		break;
	case 'w':
		szSymbol =L"DATAMATRIX";
		break;
	case 'j':
		if(chSymModifier == '4')
			szSymbol = L"ISBT128";
		else
			szSymbol = L"CODE128";
		break;
	case 'J':
		szSymbol = L"JAPAN POST";
		break;
	case 'K':
		szSymbol = L"DUTCH POST";
		break;
	case 'm':
		szSymbol =L"MATRIX 2OF5";
		break;
	case 'x':
		szSymbol = L"MAXICODE";
		break;
	case 'g':
		szSymbol =L"MSI";
		break;
	case 'R':
		szSymbol = L"Micro PDF417";
		break;
	case 'L':
		szSymbol = L"PLANET";
		break;
	case 'n':
		szSymbol = L"PLESSEY";
		break;
	case 'W':
		szSymbol = L"POSICODE";
		break; 
	case 'P':
		szSymbol = L"POSTNET";
		break;
	case 's':
		szSymbol = L"QR CODE";
		break;
	case 'f':
		if(chId == 'R')
			szSymbol = L"CODE25 IATA";
		else
			szSymbol = L"CODE25 INDUSTRIAL";
		break;
	case 'T':
		szSymbol = L"TLC39";
		break;
	case 't':
		szSymbol =L"TELEPEN";
		break;
	case '=':
		szSymbol = L"TRIOPTIC";
		break;
	case 'A':
		szSymbol = L"AUS POST";
		break;
	case 'z':
		szSymbol = L"AZTEC";
		break;
	case 'Z':
		szSymbol = L"MESA";
		break;
	case 'B':
		szSymbol = L"BPO";
		break;
	case 'C':
		szSymbol = L"CANADA POST";
		break;
	case 'Q':
		szSymbol = L"CHINA POST";
		break;
	case 'q':
		szSymbol =L"CODABLOCK";
		break;
	case 'a':
		szSymbol = L"CODABAR";
		break;

	case 'h':
		szSymbol = L"CODE11";
		break;
	case 'o':
		szSymbol =L"CODE 16K";
		break;
	case 'b':
		szSymbol = L"CODE39";
		break;

	case 'D':
		szSymbol = L"EAN-8";
		break;

	case 'd':
		szSymbol = L"EAN-13";
		
		if(m_bEnableISBN)
		{		
			if((wcsncmp(L"978", (LPCTSTR)szCode, 3) == 0)  || (wcsncmp(L"979", (LPCTSTR)szCode, 3) == 0))
			{
				TCHAR strData[10];
				int sum = 0;

				wcscpy(strData, (LPCTSTR)szCode + 3);

				for(int i=0; i<9; i++)
				sum += (strData[i]-L'0') * (10 - i);

				sum %= 11;
				if(sum != 0)
				sum = 11 - sum;

				szCode.Format(L"%s%d", strData, sum);
				m_scan.m_BarcodeList.InsertItem(0, L"ISBN",0);
				m_scan.m_BarcodeList.SetItemText(0, 1, szCode);
	
				HINSTANCE hInst = AfxGetInstanceHandle();
				if(m_option.m_bBeep == TRUE)
					PlaySound(MAKEINTRESOURCE(IDR_WAVE_BEEP), hInst, SND_RESOURCE|SND_ASYNC);
				else
					PlaySound(MAKEINTRESOURCE(IDR_WAVE_SCAN), hInst, SND_RESOURCE|SND_ASYNC);

				return;
			}
		}
		break;

	case 'e':
		szSymbol = L"Interleaved 2of5";
		break;

	case '?':
		szSymbol = L"KOREA POST";
		break;

	case 'r':
		szSymbol = L"PDF417";
		break;

	case 'c':
		szSymbol = L"UPC-A";
		break;

	case 'E':
		if(chId == 'E')
			szSymbol = L"UPC-E";
		else
			szSymbol = L"UPC-E1";
		break;

	case 'i':
		szSymbol = L"CODE93";
		break;
	case 'y':
		szSymbol = L"GS1(RSS)";
		break;
	case 'I':
		szSymbol = L"GS1-128";
		break;
	case 'O':
		szSymbol = L"OCR";
		break;		
	case 'N':
		szSymbol = L"ID TAG";
		break;

	default:
		szSymbol = L"UNKNOWN TYPE";
		break;
	}

 	m_scan.m_BarcodeList.InsertItem(0, szSymbol,0);
 	m_scan.m_BarcodeList.SetItemText(0, 1, szCode);

	HINSTANCE hInst = AfxGetInstanceHandle();
	if(m_option.m_bBeep)
		PlaySound(MAKEINTRESOURCE(IDR_WAVE_BEEP), hInst, SND_RESOURCE|SND_ASYNC);
	else
		PlaySound(MAKEINTRESOURCE(IDR_WAVE_SCAN), hInst, SND_RESOURCE|SND_ASYNC);

}

BOOL CMainSheet::ScanRead()
{
	return g_scan.ScanRead(m_nTimeOut, NULL);
}

void CMainSheet::GetInfo()
{
	IMAGER_VERSION_INFO info;

	g_scan.GetInfo(&info);
	
	CInfo dlg;

	
	dlg.m_strInfo.Format(L"%s \r\n%s \r\n%s \r\nFirmwareVersion:%d \r\nFirmwareCksum:%d \r\nEngineID:%d \r\n\r\n%s\
	\r\n\r\nProgram Version 2.3.0 \r\nBuild Date 2010.10.25", 
		info.tcAPIRev, info.tcDecoderRev, info.tcScanDriverRev, 
		info.dwFirmwareVersion, info.dwFirmwareCksum, info.dwEngineId,
		info.tcEtcInfo);

	dlg.DoModal();
}
void CMainSheet::OnDestroy()
{
	CPropertySheet::OnDestroy();

	g_scan.Connect(FALSE);

}

LRESULT CMainSheet::OnDataRead(WPARAM wParam, LPARAM lParam)
{
	g_scan.ScanLed(TRUE);

	DECODE_MSG decodeInfo;	
	EventType_t eventType;
	g_scan.GetScanResult(&eventType, &decodeInfo);

	Check_Barcode(decodeInfo.chCodeID, decodeInfo.chSymLetter, decodeInfo.chSymModifier, decodeInfo.pchMessage);

	g_scan.ScanLed(FALSE);

	return 0;
}
