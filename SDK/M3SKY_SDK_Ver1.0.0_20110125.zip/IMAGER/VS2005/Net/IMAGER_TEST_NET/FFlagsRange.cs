﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using M3MobileImagerNet;

namespace Scan3Net
{
	public partial class FFlagsRange : Form
	{
		private Scanner m_scan;
		private SYMID m_id;
		Scanner.SymFlagsRange m_config;


		public FFlagsRange(string BarCodeName, SYMID SymID, Scanner scan)
		{
			InitializeComponent();

			m_scan = scan;
			lblTitle.Text = BarCodeName;
			m_id = SymID;

			m_scan.ReadSymbologyConfig(SetupType.SETUP_CURRENT, m_id, ref m_config);

			if (Scanner.SYM_ENABLE == (m_config.nFlags & Scanner.SYM_ENABLE))
				chbEnable.Checked = true;
			else
				chbEnable.Checked = false;

			nudMaxLen.Value = m_config.nMaxLen;
			nudMinLen.Value = m_config.nMinLen;
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			if (chbEnable.Checked)
				m_config.nFlags = Scanner.SYM_ENABLE;
			else
				m_config.nFlags = 0;

			m_config.nMaxLen = (int)nudMaxLen.Value;
			m_config.nMinLen = (int)nudMinLen.Value;

			m_scan.WriteSymbologyConfig(m_id, m_config);
			DialogResult = DialogResult.OK;

		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			DialogResult = DialogResult.Cancel;
		}
	}
}