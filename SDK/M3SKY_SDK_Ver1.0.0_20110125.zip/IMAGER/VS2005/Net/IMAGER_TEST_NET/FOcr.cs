﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using M3MobileImagerNet;

namespace Scan3Net
{
	public partial class FOcr : Form
	{
		private Scanner m_scan;
		private Scanner.SymCodeOCR m_config;

		public FOcr(Scanner scan)
		{
			InitializeComponent();

			m_scan = scan;

			m_scan.ReadSymbologyConfig(SetupType.SETUP_CURRENT, ref m_config);

			
			switch (m_config.ocrMode)
			{
				case OCRMode.OCR_MODE_DISABLED:
					cbMode.SelectedIndex = 0;
					break;
				case OCRMode.OCR_MODE_A:
					cbMode.SelectedIndex = 1;
					break;
				case OCRMode.OCR_MODE_B:
					cbMode.SelectedIndex = 2;
					break;
				case OCRMode.OCR_MODE_MONEY:
					cbMode.SelectedIndex = 3;
					break;
				case OCRMode.OCR_MODE_MICR_UNSUPPORTED:
					cbMode.SelectedIndex = 4;
					break;
			}

			tbTemplate.Text = m_config.tcTemplate;
			tbGroupG.Text = m_config.tcGroupG;
			tbGroupH.Text = m_config.tcGroupH;
			tbCheckChar.Text = m_config.tcCheckChar;

		}

	

		private void btnOK_Click(object sender, EventArgs e)
		{
			switch (cbMode.SelectedIndex)
			{
				case 0:
					m_config.ocrMode = OCRMode.OCR_MODE_DISABLED;
					break;
				case 1:
					m_config.ocrMode = OCRMode.OCR_MODE_A;
					break;
				case 2:
					m_config.ocrMode = OCRMode.OCR_MODE_B;
					break;
				case 3:
					m_config.ocrMode = OCRMode.OCR_MODE_MONEY;
					break;
				case 4:
					m_config.ocrMode = OCRMode.OCR_MODE_MICR_UNSUPPORTED;
					break;
			}

			m_config.tcTemplate = tbTemplate.Text;
			m_config.tcGroupG = tbGroupG.Text;
			m_config.tcGroupH = tbGroupH.Text;
			m_config.tcCheckChar = tbCheckChar.Text;

			m_scan.WriteSymbologyConfig(m_config);

			DialogResult = DialogResult.OK;
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			DialogResult = DialogResult.Cancel;
		}

	

	}
}