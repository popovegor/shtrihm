﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using M3MobileImagerNet;

namespace Scan3Net
{
	public partial class FComposite : Form
	{
		private Scanner m_scan;
		private Scanner.SymFlagsRange m_config;

		public FComposite(Scanner scan)
		{
			InitializeComponent();


			m_scan = scan;
			m_scan.ReadSymbologyConfig(SetupType.SETUP_CURRENT, SYMID.ID_COMPOSITE, ref m_config);

			chbEnable.Checked = (Scanner.SYM_ENABLE == (m_config.nFlags & Scanner.SYM_ENABLE)) ? true : false;
			chbCompositeUPC.Checked = (Scanner.SYM_COMPOSITE_UPC == (m_config.nFlags & Scanner.SYM_COMPOSITE_UPC)) ? true : false;
		
			nudMaxLen.Value = m_config.nMaxLen;
			nudMinLen.Value = m_config.nMinLen;
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			m_config.nFlags = (chbEnable.Checked) ? Scanner.SYM_ENABLE : 0;
			m_config.nFlags |= (chbCompositeUPC.Checked) ? Scanner.SYM_COMPOSITE_UPC : 0;

			m_config.nMaxLen = (int)nudMaxLen.Value;
			m_config.nMinLen = (int)nudMinLen.Value;

			m_scan.WriteSymbologyConfig(SYMID.ID_COMPOSITE, m_config);
			DialogResult = DialogResult.OK;
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			DialogResult = DialogResult.Cancel;
		}
	}
}