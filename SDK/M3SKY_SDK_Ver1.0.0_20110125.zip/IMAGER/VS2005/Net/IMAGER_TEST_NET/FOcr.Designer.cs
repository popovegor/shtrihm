﻿namespace Scan3Net
{
	partial class FOcr
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.MainMenu mainMenu1;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.cbMode = new System.Windows.Forms.ComboBox();
			this.tbTemplate = new System.Windows.Forms.TextBox();
			this.tbGroupG = new System.Windows.Forms.TextBox();
			this.tbGroupH = new System.Windows.Forms.TextBox();
			this.tbCheckChar = new System.Windows.Forms.TextBox();
			this.btnCancel = new System.Windows.Forms.Button();
			this.btnOK = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(6, 6);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(100, 20);
			this.label1.Text = "OCR";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(6, 31);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(72, 20);
			this.label2.Text = "Mode :";
			this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(6, 60);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(72, 20);
			this.label3.Text = "Template :";
			this.label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(6, 89);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(72, 20);
			this.label4.Text = "GroupG :";
			this.label4.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(6, 118);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(72, 20);
			this.label5.Text = "GroupH :";
			this.label5.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(6, 147);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(72, 20);
			this.label6.Text = "CheckChar :";
			this.label6.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(17, 173);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(204, 30);
			this.label7.Text = "‘d’ - decimal, ‘a’ - ASCII,  \'l\' - letter, \'e\' -extended";
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(2, 203);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(235, 16);
			this.label8.Text = "ex) OCR - 1234ABCDE Template - ddddlllll";
			// 
			// cbMode
			// 
			this.cbMode.Items.Add("Disable");
			this.cbMode.Items.Add("OCR-A");
			this.cbMode.Items.Add("OCR-B");
			this.cbMode.Items.Add("OCR-Money");
			this.cbMode.Items.Add("OCR-Micr");
			this.cbMode.Location = new System.Drawing.Point(84, 29);
			this.cbMode.Name = "cbMode";
			this.cbMode.Size = new System.Drawing.Size(100, 22);
			this.cbMode.TabIndex = 8;
			// 
			// tbTemplate
			// 
			this.tbTemplate.Location = new System.Drawing.Point(83, 59);
			this.tbTemplate.Name = "tbTemplate";
			this.tbTemplate.Size = new System.Drawing.Size(100, 21);
			this.tbTemplate.TabIndex = 9;
			// 
			// tbGroupG
			// 
			this.tbGroupG.Location = new System.Drawing.Point(83, 88);
			this.tbGroupG.Name = "tbGroupG";
			this.tbGroupG.Size = new System.Drawing.Size(100, 21);
			this.tbGroupG.TabIndex = 10;
			// 
			// tbGroupH
			// 
			this.tbGroupH.Location = new System.Drawing.Point(83, 117);
			this.tbGroupH.Name = "tbGroupH";
			this.tbGroupH.Size = new System.Drawing.Size(100, 21);
			this.tbGroupH.TabIndex = 11;
			// 
			// tbCheckChar
			// 
			this.tbCheckChar.Location = new System.Drawing.Point(83, 146);
			this.tbCheckChar.Name = "tbCheckChar";
			this.tbCheckChar.Size = new System.Drawing.Size(100, 21);
			this.tbCheckChar.TabIndex = 12;
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(137, 231);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(72, 20);
			this.btnCancel.TabIndex = 52;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// btnOK
			// 
			this.btnOK.Location = new System.Drawing.Point(31, 231);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(72, 20);
			this.btnOK.TabIndex = 51;
			this.btnOK.Text = "OK";
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// FOcr
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
			this.AutoScroll = true;
			this.ClientSize = new System.Drawing.Size(240, 268);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.tbCheckChar);
			this.Controls.Add(this.tbGroupH);
			this.Controls.Add(this.tbGroupG);
			this.Controls.Add(this.tbTemplate);
			this.Controls.Add(this.cbMode);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Menu = this.mainMenu1;
			this.Name = "FOcr";
			this.Text = "FOcr";
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.ComboBox cbMode;
		private System.Windows.Forms.TextBox tbTemplate;
		private System.Windows.Forms.TextBox tbGroupG;
		private System.Windows.Forms.TextBox tbGroupH;
		private System.Windows.Forms.TextBox tbCheckChar;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Button btnOK;
	}
}