﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using M3MobileImagerNet;

namespace Scan3Net
{
	public partial class About : Form
	{
		public Scanner m_scan;

		public About()
		{
			InitializeComponent();
		}

		private void About_Load(object sender, EventArgs e)
		{
			Scanner.IMAGER_VERSION_INFO verinfo = new Scanner.IMAGER_VERSION_INFO();

			if (m_scan.GetInfo(ref verinfo))
			{
                textBoxInfo.Text = verinfo.tcAPIRev +"\r\n"+ verinfo.tcDecoderRev +"\r\n"+ verinfo.tcScanDriverRev +
                   "\r\nFirmwareVersion: "+verinfo.dwFirmwareVersion + "\r\nFirmwareCksum:"+verinfo.dwFirmwareCksum + "\r\nEngineID:"+verinfo.dwEngineId +"\r\n"+ verinfo.tcEtcInfo + "\r\n\r\nProgram Version 2.0.0 \r\nBuild Date 2010.03.08";
			}
		}
	}
}