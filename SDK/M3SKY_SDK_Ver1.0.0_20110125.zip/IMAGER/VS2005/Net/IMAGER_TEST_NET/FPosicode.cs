﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using M3MobileImagerNet;

namespace Scan3Net
{
	public partial class FPosicode : Form
	{

		private Scanner m_scan;
		private Scanner.SymFlagsRange m_config;

		public FPosicode(Scanner scan)
		{
			InitializeComponent();

			m_scan = scan;
			m_scan.ReadSymbologyConfig(SetupType.SETUP_CURRENT, SYMID.ID_POSICODE, ref m_config);

			chbEnable.Checked = (Scanner.SYM_ENABLE == (m_config.nFlags & Scanner.SYM_ENABLE)) ? true : false;

			if (Scanner.SYM_POSICODE_LIMITED_1 == (m_config.nFlags & Scanner.SYM_POSICODE_LIMITED_1))
				cbLimit.SelectedIndex = 1;
			else
			{
				if (Scanner.SYM_POSICODE_LIMITED_2==(m_config.nFlags & Scanner.SYM_POSICODE_LIMITED_2))
					cbLimit.SelectedIndex = 2;
				else
					cbLimit.SelectedIndex = 0;
			}

			nudMaxLen.Value = m_config.nMaxLen;
			nudMinLen.Value = m_config.nMinLen;
			
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			m_config.nFlags = (chbEnable.Checked) ? Scanner.SYM_ENABLE : 0;

			switch (cbLimit.SelectedIndex)
			{
				case 1:
					m_config.nFlags |= Scanner.SYM_POSICODE_LIMITED_1;
					break;

				case 2:
					m_config.nFlags |= Scanner.SYM_POSICODE_LIMITED_2;
					break;
			}


			m_config.nMaxLen = (int)nudMaxLen.Value;
			m_config.nMinLen = (int)nudMinLen.Value;

			m_scan.WriteSymbologyConfig(SYMID.ID_POSICODE, m_config);
			DialogResult = DialogResult.OK;
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			DialogResult = DialogResult.Cancel;
		}
	}
}