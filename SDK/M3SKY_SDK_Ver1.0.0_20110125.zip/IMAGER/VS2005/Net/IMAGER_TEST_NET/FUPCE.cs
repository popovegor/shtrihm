﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using M3MobileImagerNet;

namespace Scan3Net
{
	public partial class FUPCE : Form
	{
		private Scanner m_scan;
		private Scanner.SymFlagsOnly m_config;

		public FUPCE(Scanner scan)
		{
			InitializeComponent();

			m_scan = scan;

			m_scan.ReadSymbologyConfig(SetupType.SETUP_CURRENT, SYMID.ID_UPCE0, ref m_config);

			chbEnableE0.Checked = (Scanner.SYM_ENABLE == (m_config.nFlags & Scanner.SYM_ENABLE)) ? true : false;
			chbEnableE1.Checked = (Scanner.SYM_UPCE1_ENABLE == (m_config.nFlags & Scanner.SYM_UPCE1_ENABLE)) ? true : false;
			chbCheckSend.Checked = (Scanner.SYM_CHECK_TRANSMIT == (m_config.nFlags & Scanner.SYM_CHECK_TRANSMIT)) ? true : false;
			chbAddenda2.Checked = (Scanner.SYM_2_DIGIT_ADDENDA == (m_config.nFlags & Scanner.SYM_2_DIGIT_ADDENDA)) ? true : false;
			chbAddenda5.Checked = (Scanner.SYM_5_DIGIT_ADDENDA == (m_config.nFlags & Scanner.SYM_5_DIGIT_ADDENDA)) ? true : false;
			chbAddendaReq.Checked = (Scanner.SYM_ADDENDA_REQUIRED == (m_config.nFlags & Scanner.SYM_ADDENDA_REQUIRED)) ? true : false;
			chbAddendaSep.Checked = (Scanner.SYM_ADDENDA_SEPARATOR == (m_config.nFlags & Scanner.SYM_ADDENDA_SEPARATOR)) ? true : false;
			chbNumSysTrans.Checked = (Scanner.SYM_NUM_SYS_TRANSMIT == (m_config.nFlags & Scanner.SYM_NUM_SYS_TRANSMIT)) ? true : false;
			
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			m_config.nFlags = (chbEnableE0.Checked) ? Scanner.SYM_ENABLE : 0;
			m_config.nFlags |= (chbEnableE1.Checked) ? Scanner.SYM_UPCE1_ENABLE : 0;
			m_config.nFlags |= (chbCheckSend.Checked) ? Scanner.SYM_CHECK_TRANSMIT : 0;
			m_config.nFlags |= (chbAddenda2.Checked) ? Scanner.SYM_2_DIGIT_ADDENDA : 0;
			m_config.nFlags |= (chbAddenda5.Checked) ? Scanner.SYM_5_DIGIT_ADDENDA : 0;
			m_config.nFlags |= (chbAddendaReq.Checked) ? Scanner.SYM_ADDENDA_REQUIRED : 0;
			m_config.nFlags |= (chbAddendaSep.Checked) ? Scanner.SYM_ADDENDA_SEPARATOR : 0;
			m_config.nFlags |= (chbNumSysTrans.Checked) ? Scanner.SYM_NUM_SYS_TRANSMIT : 0;

			m_scan.WriteSymbologyConfig(SYMID.ID_UPCE0, m_config);
			DialogResult = DialogResult.OK;
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			DialogResult = DialogResult.Cancel;
		}

	}
}