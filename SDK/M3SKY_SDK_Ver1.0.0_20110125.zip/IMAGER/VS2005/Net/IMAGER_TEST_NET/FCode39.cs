﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using M3MobileImagerNet;

namespace Scan3Net
{
	public partial class FCode39 : Form
	{
		private Scanner m_scan;
		private Scanner.SymFlagsRange m_config;

		public FCode39(Scanner scan)
		{
			InitializeComponent();

			m_scan = scan;
			m_scan.ReadSymbologyConfig(SetupType.SETUP_CURRENT, SYMID.ID_CODE39, ref m_config);
			
			chbEnable.Checked = (Scanner.SYM_ENABLE == (m_config.nFlags & Scanner.SYM_ENABLE)) ? true : false;
			chbCheck.Checked = (Scanner.SYM_CHECK_ENABLE == (m_config.nFlags & Scanner.SYM_CHECK_ENABLE)) ? true : false;
			chbCheckSend.Checked = (Scanner.SYM_CHECK_TRANSMIT == (m_config.nFlags & Scanner.SYM_CHECK_TRANSMIT)) ? true : false;
			chbStartStop.Checked = (Scanner.SYM_START_STOP_XMIT == (m_config.nFlags & Scanner.SYM_START_STOP_XMIT)) ? true : false;
			chbAppend.Checked = (Scanner.SYM_ENABLE_APPEND_MODE  == (m_config.nFlags & Scanner.SYM_ENABLE_APPEND_MODE )) ? true : false;
			chbFullAscii.Checked = (Scanner.SYM_ENABLE_FULLASCII == (m_config.nFlags & Scanner.SYM_ENABLE_FULLASCII)) ? true : false;


			nudMaxLen.Value = m_config.nMaxLen;
			nudMinLen.Value = m_config.nMinLen;
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			m_config.nFlags = (chbEnable.Checked) ? Scanner.SYM_ENABLE : 0;
			m_config.nFlags |= (chbCheck.Checked) ? Scanner.SYM_CHECK_ENABLE : 0;
			m_config.nFlags |= (chbCheckSend.Checked) ? Scanner.SYM_CHECK_TRANSMIT : 0;
			m_config.nFlags |= (chbStartStop.Checked) ? Scanner.SYM_START_STOP_XMIT : 0;
			m_config.nFlags |= (chbAppend.Checked) ? Scanner.SYM_ENABLE_APPEND_MODE : 0;
			m_config.nFlags |= (chbFullAscii.Checked) ? Scanner.SYM_ENABLE_FULLASCII : 0;


			m_config.nMaxLen = (int)nudMaxLen.Value;
			m_config.nMinLen = (int)nudMinLen.Value;

			m_scan.WriteSymbologyConfig(SYMID.ID_CODE39, m_config);
			DialogResult = DialogResult.OK;
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			DialogResult = DialogResult.Cancel;
		}
	}
}