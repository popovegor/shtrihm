﻿namespace Scan3Net
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.MainMenu mainMenu1;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.ScanTabControl = new System.Windows.Forms.TabControl();
            this.ScanTab = new System.Windows.Forms.TabPage();
            this.btn_Close = new System.Windows.Forms.Button();
            this.InfoButton = new System.Windows.Forms.Button();
            this.ListCleanButton = new System.Windows.Forms.Button();
            this.ScanButton = new System.Windows.Forms.Button();
            this.ScanListView = new System.Windows.Forms.ListView();
            this.TypeColumn = new System.Windows.Forms.ColumnHeader();
            this.DataColumn = new System.Windows.Forms.ColumnHeader();
            this.SymbologyTab = new System.Windows.Forms.TabPage();
            this.SymbologyDefaultButton = new System.Windows.Forms.Button();
            this.SymbologyAllButton = new System.Windows.Forms.Button();
            this.SymbologyListView = new System.Windows.Forms.ListView();
            this.SymbologyIndex = new System.Windows.Forms.ColumnHeader();
            this.SymbologyBarCode = new System.Windows.Forms.ColumnHeader();
            this.CenteringTab = new System.Windows.Forms.TabPage();
            this.btnCenteringConfirm = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.nudBottom = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.nudRight = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.nudTop = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.nudLeft = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.cbEnableCentering = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.OptionTab = new System.Windows.Forms.TabPage();
            this.label10 = new System.Windows.Forms.Label();
            this.cbMultiDecodeMode = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbScanningLightsMode = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SyncRadio = new System.Windows.Forms.RadioButton();
            this.AsyncRadio = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.OptionConfirm = new System.Windows.Forms.Button();
            this.TimoutTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ScanTabControl.SuspendLayout();
            this.ScanTab.SuspendLayout();
            this.SymbologyTab.SuspendLayout();
            this.CenteringTab.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.OptionTab.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ScanTabControl
            // 
            this.ScanTabControl.Controls.Add(this.ScanTab);
            this.ScanTabControl.Controls.Add(this.SymbologyTab);
            this.ScanTabControl.Controls.Add(this.CenteringTab);
            this.ScanTabControl.Controls.Add(this.OptionTab);
            this.ScanTabControl.Location = new System.Drawing.Point(0, 0);
            this.ScanTabControl.Name = "ScanTabControl";
            this.ScanTabControl.SelectedIndex = 0;
            this.ScanTabControl.Size = new System.Drawing.Size(240, 268);
            this.ScanTabControl.TabIndex = 2;
            // 
            // ScanTab
            // 
            this.ScanTab.Controls.Add(this.btn_Close);
            this.ScanTab.Controls.Add(this.InfoButton);
            this.ScanTab.Controls.Add(this.ListCleanButton);
            this.ScanTab.Controls.Add(this.ScanButton);
            this.ScanTab.Controls.Add(this.ScanListView);
            this.ScanTab.Location = new System.Drawing.Point(0, 0);
            this.ScanTab.Name = "ScanTab";
            this.ScanTab.Size = new System.Drawing.Size(240, 245);
            this.ScanTab.Text = "Scan";
            // 
            // btn_Close
            // 
            this.btn_Close.Location = new System.Drawing.Point(184, 223);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(53, 20);
            this.btn_Close.TabIndex = 4;
            this.btn_Close.Text = "Close";
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // InfoButton
            // 
            this.InfoButton.Location = new System.Drawing.Point(124, 223);
            this.InfoButton.Name = "InfoButton";
            this.InfoButton.Size = new System.Drawing.Size(53, 20);
            this.InfoButton.TabIndex = 3;
            this.InfoButton.Text = "Info";
            this.InfoButton.Click += new System.EventHandler(this.InfoButton_Click);
            // 
            // ListCleanButton
            // 
            this.ListCleanButton.Location = new System.Drawing.Point(63, 223);
            this.ListCleanButton.Name = "ListCleanButton";
            this.ListCleanButton.Size = new System.Drawing.Size(53, 20);
            this.ListCleanButton.TabIndex = 2;
            this.ListCleanButton.Text = "Clear";
            this.ListCleanButton.Click += new System.EventHandler(this.ListCleanButton_Click);
            // 
            // ScanButton
            // 
            this.ScanButton.Location = new System.Drawing.Point(3, 223);
            this.ScanButton.Name = "ScanButton";
            this.ScanButton.Size = new System.Drawing.Size(53, 20);
            this.ScanButton.TabIndex = 1;
            this.ScanButton.Text = "Scan";
            this.ScanButton.Click += new System.EventHandler(this.ScanButton_Click);
            // 
            // ScanListView
            // 
            this.ScanListView.Columns.Add(this.TypeColumn);
            this.ScanListView.Columns.Add(this.DataColumn);
            this.ScanListView.Location = new System.Drawing.Point(3, 3);
            this.ScanListView.Name = "ScanListView";
            this.ScanListView.Size = new System.Drawing.Size(234, 216);
            this.ScanListView.TabIndex = 0;
            this.ScanListView.View = System.Windows.Forms.View.Details;
            // 
            // TypeColumn
            // 
            this.TypeColumn.Text = "Type";
            this.TypeColumn.Width = 60;
            // 
            // DataColumn
            // 
            this.DataColumn.Text = "Data";
            this.DataColumn.Width = 150;
            // 
            // SymbologyTab
            // 
            this.SymbologyTab.Controls.Add(this.SymbologyDefaultButton);
            this.SymbologyTab.Controls.Add(this.SymbologyAllButton);
            this.SymbologyTab.Controls.Add(this.SymbologyListView);
            this.SymbologyTab.Location = new System.Drawing.Point(0, 0);
            this.SymbologyTab.Name = "SymbologyTab";
            this.SymbologyTab.Size = new System.Drawing.Size(232, 242);
            this.SymbologyTab.Text = "Symbology";
            // 
            // SymbologyDefaultButton
            // 
            this.SymbologyDefaultButton.Location = new System.Drawing.Point(125, 222);
            this.SymbologyDefaultButton.Name = "SymbologyDefaultButton";
            this.SymbologyDefaultButton.Size = new System.Drawing.Size(109, 20);
            this.SymbologyDefaultButton.TabIndex = 2;
            this.SymbologyDefaultButton.Text = "Default";
            this.SymbologyDefaultButton.Click += new System.EventHandler(this.SymbologyDefaultButton_Click);
            // 
            // SymbologyAllButton
            // 
            this.SymbologyAllButton.Location = new System.Drawing.Point(6, 222);
            this.SymbologyAllButton.Name = "SymbologyAllButton";
            this.SymbologyAllButton.Size = new System.Drawing.Size(109, 20);
            this.SymbologyAllButton.TabIndex = 1;
            this.SymbologyAllButton.Text = "All";
            this.SymbologyAllButton.Click += new System.EventHandler(this.SymbologyAllButton_Click);
            // 
            // SymbologyListView
            // 
            this.SymbologyListView.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.SymbologyListView.Columns.Add(this.SymbologyIndex);
            this.SymbologyListView.Columns.Add(this.SymbologyBarCode);
            this.SymbologyListView.FullRowSelect = true;
            this.SymbologyListView.Location = new System.Drawing.Point(3, 1);
            this.SymbologyListView.Name = "SymbologyListView";
            this.SymbologyListView.Size = new System.Drawing.Size(234, 216);
            this.SymbologyListView.TabIndex = 0;
            this.SymbologyListView.View = System.Windows.Forms.View.Details;
            this.SymbologyListView.ItemActivate += new System.EventHandler(this.SymbologyListView_ItemActivate);
            // 
            // SymbologyIndex
            // 
            this.SymbologyIndex.Text = "Index";
            this.SymbologyIndex.Width = 60;
            // 
            // SymbologyBarCode
            // 
            this.SymbologyBarCode.Text = "BarCode";
            this.SymbologyBarCode.Width = 120;
            // 
            // CenteringTab
            // 
            this.CenteringTab.Controls.Add(this.btnCenteringConfirm);
            this.CenteringTab.Controls.Add(this.panel2);
            this.CenteringTab.Controls.Add(this.label9);
            this.CenteringTab.Location = new System.Drawing.Point(0, 0);
            this.CenteringTab.Name = "CenteringTab";
            this.CenteringTab.Size = new System.Drawing.Size(232, 242);
            this.CenteringTab.Text = "Centering";
            // 
            // btnCenteringConfirm
            // 
            this.btnCenteringConfirm.Location = new System.Drawing.Point(75, 203);
            this.btnCenteringConfirm.Name = "btnCenteringConfirm";
            this.btnCenteringConfirm.Size = new System.Drawing.Size(90, 37);
            this.btnCenteringConfirm.TabIndex = 4;
            this.btnCenteringConfirm.Text = "OK";
            this.btnCenteringConfirm.Click += new System.EventHandler(this.btnCenteringConfirm_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.cbEnableCentering);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Location = new System.Drawing.Point(4, 18);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(233, 180);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.panel3.Controls.Add(this.nudBottom);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.nudRight);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.nudTop);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.nudLeft);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Location = new System.Drawing.Point(4, 50);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(225, 125);
            // 
            // nudBottom
            // 
            this.nudBottom.Location = new System.Drawing.Point(109, 80);
            this.nudBottom.Maximum = new decimal(new int[] {
            724,
            0,
            0,
            0});
            this.nudBottom.Name = "nudBottom";
            this.nudBottom.Size = new System.Drawing.Size(66, 22);
            this.nudBottom.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(49, 80);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 20);
            this.label5.Text = "Bottom";
            // 
            // nudRight
            // 
            this.nudRight.Location = new System.Drawing.Point(109, 58);
            this.nudRight.Maximum = new decimal(new int[] {
            479,
            0,
            0,
            0});
            this.nudRight.Name = "nudRight";
            this.nudRight.Size = new System.Drawing.Size(66, 22);
            this.nudRight.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(49, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 20);
            this.label4.Text = "Right";
            // 
            // nudTop
            // 
            this.nudTop.Location = new System.Drawing.Point(109, 36);
            this.nudTop.Maximum = new decimal(new int[] {
            723,
            0,
            0,
            0});
            this.nudTop.Name = "nudTop";
            this.nudTop.Size = new System.Drawing.Size(66, 22);
            this.nudTop.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(49, 38);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 20);
            this.label6.Text = "Top";
            // 
            // nudLeft
            // 
            this.nudLeft.Location = new System.Drawing.Point(109, 14);
            this.nudLeft.Maximum = new decimal(new int[] {
            478,
            0,
            0,
            0});
            this.nudLeft.Name = "nudLeft";
            this.nudLeft.Size = new System.Drawing.Size(66, 22);
            this.nudLeft.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(49, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(30, 20);
            this.label7.Text = "Left";
            // 
            // cbEnableCentering
            // 
            this.cbEnableCentering.Location = new System.Drawing.Point(8, 7);
            this.cbEnableCentering.Name = "cbEnableCentering";
            this.cbEnableCentering.Size = new System.Drawing.Size(163, 20);
            this.cbEnableCentering.TabIndex = 0;
            this.cbEnableCentering.Text = "Enable Center Decoding";
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.Control;
            this.label8.Location = new System.Drawing.Point(6, 36);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(124, 20);
            this.label8.Text = "Intersection Window";
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(4, 2);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(116, 20);
            this.label9.Text = "Centered Decoding";
            // 
            // OptionTab
            // 
            this.OptionTab.Controls.Add(this.label10);
            this.OptionTab.Controls.Add(this.cbMultiDecodeMode);
            this.OptionTab.Controls.Add(this.label2);
            this.OptionTab.Controls.Add(this.cbScanningLightsMode);
            this.OptionTab.Controls.Add(this.panel1);
            this.OptionTab.Controls.Add(this.label3);
            this.OptionTab.Controls.Add(this.OptionConfirm);
            this.OptionTab.Controls.Add(this.TimoutTextBox);
            this.OptionTab.Controls.Add(this.label1);
            this.OptionTab.Location = new System.Drawing.Point(0, 0);
            this.OptionTab.Name = "OptionTab";
            this.OptionTab.Size = new System.Drawing.Size(232, 242);
            this.OptionTab.Text = "Option";
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(16, 115);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(69, 20);
            this.label10.Text = "Light Mode";
            // 
            // cbMultiDecodeMode
            // 
            this.cbMultiDecodeMode.Location = new System.Drawing.Point(101, 143);
            this.cbMultiDecodeMode.Name = "cbMultiDecodeMode";
            this.cbMultiDecodeMode.Size = new System.Drawing.Size(125, 20);
            this.cbMultiDecodeMode.TabIndex = 9;
            this.cbMultiDecodeMode.Text = "MultiDecodeMode";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(16, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 20);
            this.label2.Text = "TimeOut";
            // 
            // cbScanningLightsMode
            // 
            this.cbScanningLightsMode.Items.Add("ILLUM_AIMER_OFF");
            this.cbScanningLightsMode.Items.Add("ILLUM_ONLY_ON");
            this.cbScanningLightsMode.Items.Add("AIMER_ONLY_ON");
            this.cbScanningLightsMode.Items.Add("ILLUM_AIMER_ON");
            this.cbScanningLightsMode.Location = new System.Drawing.Point(101, 114);
            this.cbScanningLightsMode.Name = "cbScanningLightsMode";
            this.cbScanningLightsMode.Size = new System.Drawing.Size(125, 22);
            this.cbScanningLightsMode.TabIndex = 8;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.panel1.Controls.Add(this.SyncRadio);
            this.panel1.Controls.Add(this.AsyncRadio);
            this.panel1.Location = new System.Drawing.Point(7, 23);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(226, 42);
            // 
            // SyncRadio
            // 
            this.SyncRadio.Checked = true;
            this.SyncRadio.Location = new System.Drawing.Point(13, 12);
            this.SyncRadio.Name = "SyncRadio";
            this.SyncRadio.Size = new System.Drawing.Size(100, 20);
            this.SyncRadio.TabIndex = 1;
            this.SyncRadio.Text = "Sync Mode";
            // 
            // AsyncRadio
            // 
            this.AsyncRadio.Location = new System.Drawing.Point(119, 12);
            this.AsyncRadio.Name = "AsyncRadio";
            this.AsyncRadio.Size = new System.Drawing.Size(100, 20);
            this.AsyncRadio.TabIndex = 2;
            this.AsyncRadio.TabStop = false;
            this.AsyncRadio.Text = "ASync Mode";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(143, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 20);
            this.label3.Text = "Secs";
            // 
            // OptionConfirm
            // 
            this.OptionConfirm.Location = new System.Drawing.Point(64, 197);
            this.OptionConfirm.Name = "OptionConfirm";
            this.OptionConfirm.Size = new System.Drawing.Size(114, 39);
            this.OptionConfirm.TabIndex = 6;
            this.OptionConfirm.Text = "Confirm";
            this.OptionConfirm.Click += new System.EventHandler(this.OptionConfirm_Click);
            // 
            // TimoutTextBox
            // 
            this.TimoutTextBox.Location = new System.Drawing.Point(101, 84);
            this.TimoutTextBox.Name = "TimoutTextBox";
            this.TimoutTextBox.Size = new System.Drawing.Size(39, 21);
            this.TimoutTextBox.TabIndex = 4;
            this.TimoutTextBox.Text = "5";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(7, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 20);
            this.label1.Text = "Sync / Async";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.ScanTabControl);
            this.KeyPreview = true;
            this.Menu = this.mainMenu1;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "M3ScanTest_Net";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Closing += new System.ComponentModel.CancelEventHandler(this.Form1_Closing);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.ScanTabControl.ResumeLayout(false);
            this.ScanTab.ResumeLayout(false);
            this.SymbologyTab.ResumeLayout(false);
            this.CenteringTab.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.OptionTab.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TabControl ScanTabControl;
		private System.Windows.Forms.TabPage ScanTab;
		private System.Windows.Forms.Button InfoButton;
		private System.Windows.Forms.Button ListCleanButton;
		private System.Windows.Forms.Button ScanButton;
		private System.Windows.Forms.ListView ScanListView;
		private System.Windows.Forms.ColumnHeader TypeColumn;
		private System.Windows.Forms.ColumnHeader DataColumn;
		private System.Windows.Forms.TabPage SymbologyTab;
		private System.Windows.Forms.Button SymbologyDefaultButton;
		private System.Windows.Forms.Button SymbologyAllButton;
		private System.Windows.Forms.ListView SymbologyListView;
		private System.Windows.Forms.ColumnHeader SymbologyIndex;
		private System.Windows.Forms.ColumnHeader SymbologyBarCode;
		private System.Windows.Forms.TabPage OptionTab;
		private System.Windows.Forms.Button OptionConfirm;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox TimoutTextBox;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.RadioButton AsyncRadio;
		private System.Windows.Forms.RadioButton SyncRadio;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cbScanningLightsMode;
        private System.Windows.Forms.CheckBox cbMultiDecodeMode;
        private System.Windows.Forms.TabPage CenteringTab;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.NumericUpDown nudBottom;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nudRight;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nudTop;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown nudLeft;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox cbEnableCentering;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnCenteringConfirm;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btn_Close;

	}
}

