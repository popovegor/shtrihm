﻿namespace Cam2Net
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.MainMenu mainMenu1;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.Infobutton = new System.Windows.Forms.Button();
            this.PictureBox = new System.Windows.Forms.PictureBox();
            this.OptionButton = new System.Windows.Forms.Button();
            this.CaptureButton = new System.Windows.Forms.Button();
            this.StopButton = new System.Windows.Forms.Button();
            this.StartButton = new System.Windows.Forms.Button();
            this.btn_Close = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Infobutton
            // 
            this.Infobutton.Location = new System.Drawing.Point(82, 244);
            this.Infobutton.Name = "Infobutton";
            this.Infobutton.Size = new System.Drawing.Size(75, 22);
            this.Infobutton.TabIndex = 13;
            this.Infobutton.Text = "Info";
            this.Infobutton.Click += new System.EventHandler(this.Infobutton_Click);
            // 
            // PictureBox
            // 
            this.PictureBox.Location = new System.Drawing.Point(4, 2);
            this.PictureBox.Name = "PictureBox";
            this.PictureBox.Size = new System.Drawing.Size(232, 214);
            // 
            // OptionButton
            // 
            this.OptionButton.Location = new System.Drawing.Point(4, 244);
            this.OptionButton.Name = "OptionButton";
            this.OptionButton.Size = new System.Drawing.Size(75, 22);
            this.OptionButton.TabIndex = 12;
            this.OptionButton.Text = "Option";
            this.OptionButton.Click += new System.EventHandler(this.OptionButton_Click);
            // 
            // CaptureButton
            // 
            this.CaptureButton.Location = new System.Drawing.Point(160, 218);
            this.CaptureButton.Name = "CaptureButton";
            this.CaptureButton.Size = new System.Drawing.Size(76, 22);
            this.CaptureButton.TabIndex = 11;
            this.CaptureButton.Text = "Capture";
            this.CaptureButton.Click += new System.EventHandler(this.CaptureButton_Click);
            // 
            // StopButton
            // 
            this.StopButton.Enabled = false;
            this.StopButton.Location = new System.Drawing.Point(82, 218);
            this.StopButton.Name = "StopButton";
            this.StopButton.Size = new System.Drawing.Size(75, 22);
            this.StopButton.TabIndex = 10;
            this.StopButton.Text = "Stop";
            this.StopButton.Click += new System.EventHandler(this.StopButton_Click);
            // 
            // StartButton
            // 
            this.StartButton.Location = new System.Drawing.Point(4, 218);
            this.StartButton.Name = "StartButton";
            this.StartButton.Size = new System.Drawing.Size(75, 22);
            this.StartButton.TabIndex = 9;
            this.StartButton.Text = "Start";
            this.StartButton.Click += new System.EventHandler(this.StartButton_Click);
            // 
            // btn_Close
            // 
            this.btn_Close.Location = new System.Drawing.Point(160, 244);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(75, 22);
            this.btn_Close.TabIndex = 15;
            this.btn_Close.Text = "Close";
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.btn_Close);
            this.Controls.Add(this.Infobutton);
            this.Controls.Add(this.PictureBox);
            this.Controls.Add(this.OptionButton);
            this.Controls.Add(this.CaptureButton);
            this.Controls.Add(this.StopButton);
            this.Controls.Add(this.StartButton);
            this.KeyPreview = true;
            this.Menu = this.mainMenu1;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "TestCam_Net";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Closing += new System.ComponentModel.CancelEventHandler(this.Form1_Closing);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button Infobutton;
		private System.Windows.Forms.PictureBox PictureBox;
		private System.Windows.Forms.Button OptionButton;
		private System.Windows.Forms.Button CaptureButton;
		private System.Windows.Forms.Button StopButton;
		private System.Windows.Forms.Button StartButton;
        private System.Windows.Forms.Button btn_Close;
	}
}

