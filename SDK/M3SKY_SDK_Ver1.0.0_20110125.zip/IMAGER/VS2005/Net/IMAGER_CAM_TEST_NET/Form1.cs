﻿/********************************************************************
created		:	2009/06/01
file base	: 	CamTest_Net.exe

file ext	:	C#.Net
author		:	Dong-Hyun, Eum(vision7901) - Applied Development Team

purpose		:	M3 SKY / MM3
Report		:	2009. 06. 01 [06/01/2008 ju]		 v1.0.1 - MM3에서는 camera 버튼이 없어서 enter key로 사진찍도록 설정함
						                                      버튼설정 하는 레지스트리 fail message 처리 지움
				2010. 01. 12 [01/12/2010 vision7901] v1.0.1 - Imager 인수인계 
                2010. 03. 08 [03/08/2010 vision7901] v2.0.0 - Key Value 얻는 부분 수정(KeyValue->KeyCode) / Close 수정/ Closing 할 때 종료처리 부분 수정                
*********************************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using M3MobileImagerNet;
using System.Runtime.InteropServices;
using System.Threading;

using Microsoft.WindowsCE.Forms;

using Microsoft.Win32;		//	RegistryKey

namespace Cam2Net
{
	public partial class Form1 : Form
	{
		private Camera m_cam;
		public string m_strFolder = "\\Flash Disk";
//        private int m_CamKeyValue;

		public Form1()
		{
			InitializeComponent();

			m_cam = new Camera();

			if (!m_cam.Connect(true))
			{
				MessageBox.Show("fail");
			}

			m_cam.Init(this.Handle, PictureBox.Handle);
            
		}

		private void Form1_Load(object sender, EventArgs e)
		{
            RegistryKey rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\KeyPad\\SideKey", true);
            if (rk == null)
            {
                rk = Registry.LocalMachine.CreateSubKey("ControlPanel\\KeyPad\\SideKey");
            }
            else
            {
                rk.SetValue("RightUpKey", 2);
            }

		}

		private void StartButton_Click(object sender, EventArgs e)
		{
			m_cam.PreviewStart();
			StartButton.Enabled = false;
			StopButton.Enabled = true;
		}

		private void StopButton_Click(object sender, EventArgs e)
		{
			m_cam.PreviewStop();
			StopButton.Enabled = false;
			StartButton.Enabled = true;

		}

		private void CaptureButton_Click(object sender, EventArgs e)
		{
			DateTime time;
			time = DateTime.Now;

			string filename = m_strFolder + "\\" + time.Hour + time.Minute + time.Second;
			if (m_cam.option.nSaveFormat == 0)
				filename += ".bmp";
			else
				filename += ".jpg";

			m_cam.Capture(filename);

			PlaySound("\\windows\\ShutterSound.wav", 0, (int)(SND.SND_ASYNC | SND.SND_FILENAME | SND.SND_NOWAIT));
		}

		private void Infobutton_Click(object sender, EventArgs e)
		{
            Scanner.IMAGER_VERSION_INFO verinfo = new Scanner.IMAGER_VERSION_INFO();
            if (m_cam.GetInfo(ref verinfo))
            {
                About dlg = new About();
                dlg.m_cam = m_cam;

                dlg.ShowDialog();
            }
		}

		private void OptionButton_Click(object sender, EventArgs e)
		{
			OptionForm option = new OptionForm(m_cam);
			option.m_strFolder = m_strFolder;
			option.ShowDialog();
		}

		[DllImport("Coredll.dll", EntryPoint = "PlaySound", CharSet = CharSet.Auto)]
		private static extern int PlaySound(String pszSound, int hmod, int falgs);

		public enum SND
		{
			SND_SYNC = 0x0000,/* play synchronously (default) */
			SND_ASYNC = 0x0001, /* play asynchronously */
			SND_NODEFAULT = 0x0002, /* silence (!default) if sound not found */
			SND_MEMORY = 0x0004, /* pszSound points to a memory file */
			SND_LOOP = 0x0008, /* loop the sound until next sndPlaySound */
			SND_NOSTOP = 0x0010, /* don't stop any currently playing sound */
			SND_NOWAIT = 0x00002000, /* don't wait if the driver is busy */
			SND_ALIAS = 0x00010000,/* name is a registry alias */
			SND_ALIAS_ID = 0x00110000, /* alias is a pre d ID */
			SND_FILENAME = 0x00020000, /* name is file name */
			SND_RESOURCE = 0x00040004, /* name is resource name or atom */
			SND_PURGE = 0x0040,  /* purge non-static events for task */
			SND_APPLICATION = 0x0080,  /* look for application specific */
		};

        private void Form1_Closing(object sender, CancelEventArgs e)
        {
            m_cam.PreviewStop();
            Thread.Sleep(300);
            m_cam.Connect(false);

            RegistryKey rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\KeyPad\\SideKey", true);
            if (rk == null)
            {
                rk = Registry.LocalMachine.CreateSubKey("ControlPanel\\KeyPad\\SideKey");
            }
            else
            {
                rk.SetValue("RightUpKey", 0);
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {           
            if ((e.KeyCode == System.Windows.Forms.Keys.F13) || (e.KeyCode == System.Windows.Forms.Keys.Enter))
            {
                e.Handled = true;

                DateTime time;
                time = DateTime.Now;

                string filename = m_strFolder + "\\" + time.Hour + time.Minute + time.Second;
                if (m_cam.option.nSaveFormat == 0)
                    filename += ".bmp";
                else
                    filename += ".jpg";

                m_cam.Capture(filename);

                PlaySound("\\windows\\ShutterSound.wav", 0, (int)(SND.SND_ASYNC | SND.SND_FILENAME | SND.SND_NOWAIT));
            }
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            m_cam.PreviewStop();
            Thread.Sleep(300);
            m_cam.Connect(false);

            RegistryKey rk = Registry.LocalMachine.OpenSubKey("ControlPanel\\KeyPad\\SideKey", true);
            if (rk == null)
            {
                rk = Registry.LocalMachine.CreateSubKey("ControlPanel\\KeyPad\\SideKey");
            }
            else
            {
                rk.SetValue("RightUpKey", 0);
            }

            Application.Exit();
        }
	}



}