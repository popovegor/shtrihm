﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using M3MobileImagerNet;


namespace Cam2Net
{
	public partial class OptionForm : Form
	{
		public string  m_strFolder= "";
		private Camera m_cam;

		public OptionForm(Camera cam)
		{
			InitializeComponent();

			m_cam = cam;
		}

		private void OptionForm_Load(object sender, EventArgs e)
		{
			m_cam.GetOption(ref m_cam.option);

// 			nudLeft.Value				= m_cam.option.nLeft;
// 			nudRight.Value				= m_cam.option.nRight;
// 			nudTop.Value				= m_cam.option.nTop;
// 			nudBottom.Value			= m_cam.option.nBottom;

			nudJpegQuality.Value	= m_cam.option.nJpegQuality;

			cbResolution.SelectedIndex		= m_cam.option.nResolution;
			cbSaveFormat.SelectedIndex	= m_cam.option.nSaveFormat;
			tbSaveFolder.Text = m_strFolder;
			}



		private void btnOK_Click(object sender, EventArgs e)
		{
// 			m_cam.option.nLeft		= (int)nudLeft.Value;
// 			m_cam.option.nRight = (int)nudRight.Value;
// 			m_cam.option.nTop = (int)nudTop.Value;
// 			nudBottom.Value = (int)m_cam.option.nBottom;

			m_cam.option.nJpegQuality = (int)nudJpegQuality.Value;

			m_cam.option.nResolution = cbResolution.SelectedIndex;
			m_cam.option.nSaveFormat = (short)cbSaveFormat.SelectedIndex;

			m_strFolder = tbSaveFolder.Text;
			m_cam.SetOption(m_cam.option);
		
			DialogResult = DialogResult.OK;

		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
		}
	}
}