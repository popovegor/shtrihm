using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using M3p_cam_net;

namespace M3P_Cam_Net_Test
{
    public partial class OptionForm : Form
    {
        private CAM_OPTION m_camoption;
        private string m_szfoldername;
        private CamCore m_pcamcore;

        private bool m_b2MCam;

//         public OptionForm()
//         {
//             InitializeComponent();
//             
// 
//         }
        public OptionForm(CAM_OPTION option ,string  szfoldername,CamCore camctrl)
        {
            InitializeComponent();                

            m_pcamcore = camctrl;
            m_camoption = option;

            string version;

            camctrl.MC3P_GetVersion(out version);
            labelInfo.Text = version;

            if (version.IndexOf("2M") == -1)
                m_b2MCam = false;
            else
                m_b2MCam = true;


            if (true == m_b2MCam)
            {
                comboBox_Resolution.Items.Add("1600 x 1200");
                comboBox_Resolution.Items.Add("1280 x 1024");
                comboBox_Resolution.Items.Add("640 x  480");
                comboBox_Resolution.Items.Add("320 x  240");            
            }
            else
            {
                comboBox_Resolution.Items.Add("1280 x 1024");
                comboBox_Resolution.Items.Add("640 x  480");
                comboBox_Resolution.Items.Add("320 x  240");
            }     

            
            if (option.nInFormat == 5)
                comboBox_Format.SelectedIndex = 1;
            else
                comboBox_Format.SelectedIndex = 0;

            comboBox_Resolution.SelectedIndex = option.nResolution ;

            comboBox_saveformat.SelectedIndex = option.nSaveFormat;
            comboBox_picturename.SelectedIndex = option.nNamePrefix;

            numericUpDown_jpec.Value = option.nJpegQuality;

            

            textBox_savefolder.Text = szfoldername;
            
            
            
            comboBox_Effect.SelectedIndex = option.nImgEffect;

            //labelInfo.Text = camctrl.

        }
      
        private void button_ok_Click(object sender, EventArgs e)
        {
            if (comboBox_Format.SelectedIndex == 1)
                m_camoption.nInFormat = 5;
            else
                m_camoption.nInFormat = 15;
            m_camoption.nResolution = comboBox_Resolution.SelectedIndex;



            if (true == m_b2MCam)
            {
                if (m_camoption.nResolution == 0)
                {
                    m_camoption.nImgWidth = 1600;
                    m_camoption.nImgHeight = 1200;
                }
                if (m_camoption.nResolution == 1)
                {
                    m_camoption.nImgWidth = 1280;
                    m_camoption.nImgHeight = 1024;
                }
                else if (m_camoption.nResolution == 2)
                {
                    m_camoption.nImgWidth = 640;
                    m_camoption.nImgHeight = 480;
                }
                else if (m_camoption.nResolution == 3)
                {
                    m_camoption.nImgWidth = 320;
                    m_camoption.nImgHeight = 240;
                }
            }
            else
            {
                if (m_camoption.nResolution == 0)
                {
                    m_camoption.nImgWidth = 1280;
                    m_camoption.nImgHeight = 1024;
                }
                if (m_camoption.nResolution == 1)
                {
                    m_camoption.nImgWidth = 640;
                    m_camoption.nImgHeight = 480;
                }
                else if (m_camoption.nResolution == 2)
                {
                    m_camoption.nImgWidth = 320;
                    m_camoption.nImgHeight = 240;
                }                
            }


            

            m_camoption.nSaveFormat = comboBox_saveformat.SelectedIndex;
            m_camoption.nNamePrefix = comboBox_picturename.SelectedIndex;
            m_camoption.nJpegQuality = (int)numericUpDown_jpec.Value;
            m_camoption.nImgRotatesave = 1;
            m_camoption.nImgRotateview = 1;
            m_szfoldername = textBox_savefolder.Text;
            
            m_pcamcore.MC3P_Set_CAMERA_OPTION(ref m_camoption, ref m_szfoldername);
            base.Dispose();
        }

        private void button_cancel_Click(object sender, EventArgs e)
        {
            base.Dispose();
        }
    }
}