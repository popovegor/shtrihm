﻿namespace M3P_Cam_Net_Test
{
    partial class CameraForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_capture = new System.Windows.Forms.Button();
            this.button_option = new System.Windows.Forms.Button();
            this.button_start = new System.Windows.Forms.Button();
            this.button_stop = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button_FlashON = new System.Windows.Forms.Button();
            this.button_FlashOFF = new System.Windows.Forms.Button();
            this.cbZomm = new System.Windows.Forms.ComboBox();
            this.cbBright = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // button_capture
            // 
            this.button_capture.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button_capture.Location = new System.Drawing.Point(2, 209);
            this.button_capture.Name = "button_capture";
            this.button_capture.Size = new System.Drawing.Size(70, 19);
            this.button_capture.TabIndex = 1;
            this.button_capture.Text = "CAPTURE";
            this.button_capture.Click += new System.EventHandler(this.button_capture_Click);
            this.button_capture.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // button_option
            // 
            this.button_option.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button_option.Location = new System.Drawing.Point(75, 209);
            this.button_option.Name = "button_option";
            this.button_option.Size = new System.Drawing.Size(70, 19);
            this.button_option.TabIndex = 2;
            this.button_option.Text = "OPTION";
            this.button_option.Click += new System.EventHandler(this.button_option_Click);
            this.button_option.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // button_start
            // 
            this.button_start.Location = new System.Drawing.Point(2, 230);
            this.button_start.Name = "button_start";
            this.button_start.Size = new System.Drawing.Size(70, 19);
            this.button_start.TabIndex = 3;
            this.button_start.Text = "START";
            this.button_start.Click += new System.EventHandler(this.button_start_Click);
            this.button_start.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // button_stop
            // 
            this.button_stop.Location = new System.Drawing.Point(75, 230);
            this.button_stop.Name = "button_stop";
            this.button_stop.Size = new System.Drawing.Size(70, 19);
            this.button_stop.TabIndex = 4;
            this.button_stop.Text = "STOP";
            this.button_stop.Click += new System.EventHandler(this.button_stop_Click);
            this.button_stop.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(1, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(237, 189);
            // 
            // button_FlashON
            // 
            this.button_FlashON.Location = new System.Drawing.Point(2, 250);
            this.button_FlashON.Name = "button_FlashON";
            this.button_FlashON.Size = new System.Drawing.Size(70, 19);
            this.button_FlashON.TabIndex = 5;
            this.button_FlashON.Text = "FLASH ON";
            this.button_FlashON.Click += new System.EventHandler(this.button_FlashON_Click);
            this.button_FlashON.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // button_FlashOFF
            // 
            this.button_FlashOFF.Location = new System.Drawing.Point(75, 250);
            this.button_FlashOFF.Name = "button_FlashOFF";
            this.button_FlashOFF.Size = new System.Drawing.Size(70, 19);
            this.button_FlashOFF.TabIndex = 6;
            this.button_FlashOFF.Text = "FLASH OFF";
            this.button_FlashOFF.Click += new System.EventHandler(this.button_FlashOFF_Click);
            this.button_FlashOFF.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // cbZomm
            // 
            this.cbZomm.Enabled = false;
            this.cbZomm.Items.Add("Zoom x 1");
            this.cbZomm.Items.Add("Zoom x 1.5");
            this.cbZomm.Items.Add("Zoom x 2");
            this.cbZomm.Items.Add("Zoom x 2.5");
            this.cbZomm.Location = new System.Drawing.Point(148, 209);
            this.cbZomm.Name = "cbZomm";
            this.cbZomm.Size = new System.Drawing.Size(88, 23);
            this.cbZomm.TabIndex = 8;
            this.cbZomm.SelectedIndexChanged += new System.EventHandler(this.cbZomm_SelectedIndexChanged);
            // 
            // cbBright
            // 
            this.cbBright.Enabled = false;
            this.cbBright.Items.Add("Bright 1");
            this.cbBright.Items.Add("Bright 2");
            this.cbBright.Items.Add("Bright 3");
            this.cbBright.Items.Add("Bright 4");
            this.cbBright.Items.Add("Bright 5");
            this.cbBright.Location = new System.Drawing.Point(148, 238);
            this.cbBright.Name = "cbBright";
            this.cbBright.Size = new System.Drawing.Size(88, 23);
            this.cbBright.TabIndex = 9;
            this.cbBright.SelectedIndexChanged += new System.EventHandler(this.cbBright_SelectedIndexChanged);
            // 
            // CameraForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(242, 303);
            this.Controls.Add(this.cbBright);
            this.Controls.Add(this.cbZomm);
            this.Controls.Add(this.button_FlashOFF);
            this.Controls.Add(this.button_FlashON);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button_stop);
            this.Controls.Add(this.button_start);
            this.Controls.Add(this.button_option);
            this.Controls.Add(this.button_capture);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CameraForm";
            this.Text = "CAMERA V#1.0.1";
            this.TopMost = true;
            this.Closing += new System.ComponentModel.CancelEventHandler(this.Form1_Closing);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_capture;
        private System.Windows.Forms.Button button_option;
        private System.Windows.Forms.Button button_start;
        private System.Windows.Forms.Button button_stop;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button_FlashON;
        private System.Windows.Forms.Button button_FlashOFF;
        private System.Windows.Forms.ComboBox cbZomm;
        private System.Windows.Forms.ComboBox cbBright;
    }
}

