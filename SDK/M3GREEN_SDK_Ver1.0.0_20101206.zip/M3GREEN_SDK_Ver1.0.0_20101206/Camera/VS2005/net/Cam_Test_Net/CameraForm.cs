﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using M3p_cam_net;

using System.Runtime.InteropServices;
using System.Reflection;



namespace M3P_Cam_Net_Test
{
    public partial class CameraForm : Form
    {
        private M3p_cam_net.CamCore camctrl;
        private OptionForm option;

        public CameraForm()
        {            
            InitializeComponent();

            camctrl = new CamCore();
            camctrl.MC3P_Init(this.Handle, pictureBox1.Handle);
            button_capture.Enabled = false;
            button_stop.Enabled = false;

            cbZomm.SelectedIndex = 0;      //  default setting value is Zoom x1
            cbBright.SelectedIndex = 2;        //  default setting value is Bright 3(index 2)

            if (!camctrl.MC3P_Open())
            {
                MessageBox.Show("open error");
            }

            string version;

            button_start.Enabled = true;
            camctrl.MC3P_GetVersion(out version);

            if (version.IndexOf("2M") == -1)
            {
                cbZomm.Visible = false;
                cbBright.Visible = false;
            }

            camctrl.CaptureNotifyEvent += new CaptureNotifyEventHandler(OnCaptureNotify);
        }

        private void OnCaptureNotify(CAP_STATUS status)
        {
            if (status == CAP_STATUS.CAP_STATUS_IMG_TRANSFORM)
                ShutterSound();
        }

        private void button_capture_Click(object sender, EventArgs e)
        {
            camctrl.MC3P_Capture();

//            ShutterSound();          
            
        }

        private void button_option_Click(object sender, EventArgs e)
        {
            CAM_OPTION pcam_option;
            string szfolder;

            camctrl.MC3P_Get_CAMERA_OPTION(out pcam_option,out szfolder);

            option = new OptionForm(pcam_option, szfolder, camctrl);

            option.Show();

            
        }

        private void button_start_Click(object sender, EventArgs e)
        {
            
            if (!camctrl.MC3P_PreViewStart())
                MessageBox.Show("view start error");
           
            button_capture.Enabled = true;
            button_stop.Enabled = true;
            button_option.Enabled = false;
            button_start.Enabled = false;
            cbBright.Enabled = true;
            cbZomm.Enabled = true;
        }

        private void button_stop_Click(object sender, EventArgs e)
        {
            if(!camctrl.MC3P_PreViewStop())
            {
                MessageBox.Show("view stop error");
            }
            pictureBox1.Invalidate();
            button_capture.Enabled = false;
            button_stop.Enabled = false;
            button_option.Enabled = true;
            button_start.Enabled = true;
            cbBright.Enabled = false;
            cbZomm.Enabled = false;            
        }

      

        private void Form1_Closing(object sender, CancelEventArgs e)
        {
 //           camctrl.MC3P_Close();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F23)
            {
                camctrl.MC3P_Capture();
//                ShutterSound();
            }
        }

        private void button_FlashON_Click(object sender, EventArgs e)
        {
            camctrl.MC3P_FlashON();
        }

        private void button_FlashOFF_Click(object sender, EventArgs e)
        {
            camctrl.MC3P_FlashOFF();
        }

        private void cbZomm_SelectedIndexChanged(object sender, EventArgs e)
        {
            camctrl.MC3P_Zoom(cbZomm.SelectedIndex);
        }

        private void cbBright_SelectedIndexChanged(object sender, EventArgs e)
        {
            camctrl.MC3P_Bright(cbBright.SelectedIndex);
        }

        private void ShutterSound()
        {
            System.IO.Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("M3P_Cam_Net_Test.Resources.shutter.wav");

            if (stream == null)
                MessageBox.Show("Sound Error");

            byte[] bStr = new Byte[stream.Length];
            stream.Read(bStr, 0, (int)stream.Length);

            PlaySound(bStr, IntPtr.Zero, SND.SND_ASYNC | SND.SND_MEMORY);
        }


        [DllImport("Coredll.dll", EntryPoint = "PlaySound", CharSet = CharSet.Auto)]
        private static extern int PlaySound(byte[] pszSound, IntPtr hmod, SND falgs);


        public enum SND
        {
            SND_SYNC = 0x0000,/* play synchronously (default) */
            SND_ASYNC = 0x0001, /* play asynchronously */
            SND_NODEFAULT = 0x0002, /* silence (!default) if sound not found */
            SND_MEMORY = 0x0004, /* pszSound points to a memory file */
            SND_LOOP = 0x0008, /* loop the sound until next sndPlaySound */
            SND_NOSTOP = 0x0010, /* don't stop any currently playing sound */
            SND_NOWAIT = 0x00002000, /* don't wait if the driver is busy */
            SND_ALIAS = 0x00010000,/* name is a registry alias */
            SND_ALIAS_ID = 0x00110000, /* alias is a pre d ID */
            SND_FILENAME = 0x00020000, /* name is file name */
            SND_RESOURCE = 0x00040004, /* name is resource name or atom */
            SND_PURGE = 0x0040,  /* purge non-static events for task */
            SND_APPLICATION = 0x0080,  /* look for application specific */
        };


        private void button_Start_cam_Click(object sender, EventArgs e)
        {
            
        }

    }
}