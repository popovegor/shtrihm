namespace M3P_Cam_Net_Test
{
    partial class OptionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboBox_Effect = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBox_Format = new System.Windows.Forms.ComboBox();
            this.comboBox_Resolution = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.numericUpDown_jpec = new System.Windows.Forms.NumericUpDown();
            this.textBox_savefolder = new System.Windows.Forms.TextBox();
            this.comboBox_saveformat = new System.Windows.Forms.ComboBox();
            this.comboBox_picturename = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button_ok = new System.Windows.Forms.Button();
            this.button_cancel = new System.Windows.Forms.Button();
            this.labelInfo = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.comboBox_Effect);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.comboBox_Format);
            this.panel1.Controls.Add(this.comboBox_Resolution);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(3, 16);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(235, 91);
            // 
            // comboBox_Effect
            // 
            this.comboBox_Effect.Items.Add("Nomal");
            this.comboBox_Effect.Items.Add("Sepia");
            this.comboBox_Effect.Items.Add("BlackWhite");
            this.comboBox_Effect.Items.Add("Negative");
            this.comboBox_Effect.Items.Add("UvRed");
            this.comboBox_Effect.Items.Add("UvBlue");
            this.comboBox_Effect.Items.Add("UvGreen");
            this.comboBox_Effect.Location = new System.Drawing.Point(109, 60);
            this.comboBox_Effect.Name = "comboBox_Effect";
            this.comboBox_Effect.Size = new System.Drawing.Size(96, 23);
            this.comboBox_Effect.TabIndex = 15;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.label12.Location = new System.Drawing.Point(48, 63);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(64, 16);
            this.label12.Text = "Effect";
            // 
            // comboBox_Format
            // 
            this.comboBox_Format.Items.Add("YUV(YCbCr)");
            this.comboBox_Format.Items.Add("RGB565");
            this.comboBox_Format.Location = new System.Drawing.Point(109, 8);
            this.comboBox_Format.Name = "comboBox_Format";
            this.comboBox_Format.Size = new System.Drawing.Size(96, 23);
            this.comboBox_Format.TabIndex = 1;
            // 
            // comboBox_Resolution
            // 
            this.comboBox_Resolution.DisplayMember = "2";
            this.comboBox_Resolution.Location = new System.Drawing.Point(109, 34);
            this.comboBox_Resolution.Name = "comboBox_Resolution";
            this.comboBox_Resolution.Size = new System.Drawing.Size(96, 23);
            this.comboBox_Resolution.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.label3.Location = new System.Drawing.Point(48, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 16);
            this.label3.Text = "Resolution";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.label2.Location = new System.Drawing.Point(48, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 16);
            this.label2.Text = "Format";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.label1.Location = new System.Drawing.Point(20, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 14);
            this.label1.Text = "Image Option";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.numericUpDown_jpec);
            this.panel2.Controls.Add(this.textBox_savefolder);
            this.panel2.Controls.Add(this.comboBox_saveformat);
            this.panel2.Controls.Add(this.comboBox_picturename);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new System.Drawing.Point(3, 136);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(235, 73);
            // 
            // numericUpDown_jpec
            // 
            this.numericUpDown_jpec.Location = new System.Drawing.Point(159, 6);
            this.numericUpDown_jpec.Minimum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numericUpDown_jpec.Name = "numericUpDown_jpec";
            this.numericUpDown_jpec.Size = new System.Drawing.Size(73, 24);
            this.numericUpDown_jpec.TabIndex = 12;
            this.numericUpDown_jpec.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // textBox_savefolder
            // 
            this.textBox_savefolder.Location = new System.Drawing.Point(48, 39);
            this.textBox_savefolder.Name = "textBox_savefolder";
            this.textBox_savefolder.Size = new System.Drawing.Size(66, 23);
            this.textBox_savefolder.TabIndex = 6;
            // 
            // comboBox_saveformat
            // 
            this.comboBox_saveformat.DisplayMember = "2";
            this.comboBox_saveformat.Items.Add("BMP");
            this.comboBox_saveformat.Items.Add("JPG");
            this.comboBox_saveformat.Location = new System.Drawing.Point(48, 6);
            this.comboBox_saveformat.Name = "comboBox_saveformat";
            this.comboBox_saveformat.Size = new System.Drawing.Size(66, 23);
            this.comboBox_saveformat.TabIndex = 5;
            // 
            // comboBox_picturename
            // 
            this.comboBox_picturename.DisplayMember = "1";
            this.comboBox_picturename.Items.Add("Date");
            this.comboBox_picturename.Items.Add("Custom");
            this.comboBox_picturename.Location = new System.Drawing.Point(159, 43);
            this.comboBox_picturename.Name = "comboBox_picturename";
            this.comboBox_picturename.Size = new System.Drawing.Size(73, 23);
            this.comboBox_picturename.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.label8.Location = new System.Drawing.Point(120, 39);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 27);
            this.label8.Text = "Picture Name";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.label7.Location = new System.Drawing.Point(3, 38);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 24);
            this.label7.Text = "Save Folder";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.label6.Location = new System.Drawing.Point(120, 4);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 27);
            this.label6.Text = "Jpec Quality";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.label5.Location = new System.Drawing.Point(3, 4);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 25);
            this.label5.Text = "Save Format";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.label4.Location = new System.Drawing.Point(6, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 18);
            this.label4.Text = "Save Option";
            // 
            // button_ok
            // 
            this.button_ok.Location = new System.Drawing.Point(39, 268);
            this.button_ok.Name = "button_ok";
            this.button_ok.Size = new System.Drawing.Size(78, 22);
            this.button_ok.TabIndex = 4;
            this.button_ok.Text = "OK";
            this.button_ok.Click += new System.EventHandler(this.button_ok_Click);
            // 
            // button_cancel
            // 
            this.button_cancel.Location = new System.Drawing.Point(139, 268);
            this.button_cancel.Name = "button_cancel";
            this.button_cancel.Size = new System.Drawing.Size(72, 22);
            this.button_cancel.TabIndex = 5;
            this.button_cancel.Text = "CANCEL";
            this.button_cancel.Click += new System.EventHandler(this.button_cancel_Click);
            // 
            // labelInfo
            // 
            this.labelInfo.Location = new System.Drawing.Point(5, 217);
            this.labelInfo.Name = "labelInfo";
            this.labelInfo.Size = new System.Drawing.Size(231, 48);
            // 
            // OptionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(241, 293);
            this.Controls.Add(this.labelInfo);
            this.Controls.Add(this.button_cancel);
            this.Controls.Add(this.button_ok);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "OptionForm";
            this.Text = "CAMERA OPTION";
            this.TopMost = true;
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_savefolder;
        private System.Windows.Forms.ComboBox comboBox_saveformat;
        private System.Windows.Forms.ComboBox comboBox_picturename;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox_Format;
        private System.Windows.Forms.ComboBox comboBox_Resolution;
        private System.Windows.Forms.NumericUpDown numericUpDown_jpec;
        private System.Windows.Forms.ComboBox comboBox_Effect;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button_ok;
        private System.Windows.Forms.Button button_cancel;
        private System.Windows.Forms.Label labelInfo;
    }
}