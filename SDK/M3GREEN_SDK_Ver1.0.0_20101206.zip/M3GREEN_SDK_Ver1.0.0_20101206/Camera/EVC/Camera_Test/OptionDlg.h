#if !defined(AFX_OPTIONDLG_H__0094CA0B_D515_4773_9DC6_762CD7E41437__INCLUDED_)
#define AFX_OPTIONDLG_H__0094CA0B_D515_4773_9DC6_762CD7E41437__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OptionDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COptionDlg dialog

class COptionDlg : public CDialog
{
// Construction
public:

	COptionDlg(CWnd* pParent = NULL);   // standard constructor

	void InitControlValue();
	void SaveCamOption();
	void LoadCamOption();
	BOOL CheckValue();
	void EnablePrevRGBDepth(BOOL bEnable);
	void EnableJpegQuality(BOOL bEnable);
	LPCAM_OPTION  m_pCamOption;
	CString		m_ver;
// Dialog Data
	//{{AFX_DATA(COptionDlg)
	enum { IDD = IDD_DLG_OPTION };
	CComboBox	m_cbRotatesave;
	CComboBox	m_cbRotateview;
	CComboBox	m_cbEffect;
	CSpinButtonCtrl	m_spJpegQuality;
	CComboBox	m_cbSaveFormat;
	CComboBox	m_cbResolution;
	CComboBox	m_cbImgFormat;
	CComboBox	m_cbPrefix;
	int		m_edJpegQuality;
	CString		m_edSaveFolder;
	BOOL		m_b16Bit;
	BOOL		m_b24Bit;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COptionDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(COptionDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnOK();
	afx_msg void OnBtnCancel();
	afx_msg void OnSelchangeCbImgFormat();
	afx_msg void OnSelChangeCbSaveFormat();
	afx_msg void OnButVer();
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTIONDLG_H__0094CA0B_D515_4773_9DC6_762CD7E41437__INCLUDED_)
