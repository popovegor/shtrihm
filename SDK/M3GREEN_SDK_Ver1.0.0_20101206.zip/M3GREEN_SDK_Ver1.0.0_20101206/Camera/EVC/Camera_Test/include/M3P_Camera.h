
// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the M3P_CAMERA_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// M3P_CAMERA_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#ifdef M3P_CAMERA_EXPORTS
#define M3P_CAMERA_API __declspec(dllexport)
#else
#define M3P_CAMERA_API __declspec(dllimport)
#endif

#include "M3P_CameraDataType.h"

//Image Lux
#define OPTION_IMAGE_NOMAL_LUX		0
#define OPTION_IMAGE_NIGHT_LUX		1

//Image Exposure
#define OPTION_IMAGE_EXPOSURE_ZERO		0
#define OPTION_IMAGE_EXPOSURE_ONE		1
#define OPTION_IMAGE_EXPOSURE_TWO		2
#define OPTION_IMAGE_EXPOSURE_THREE		3
#define OPTION_IMAGE_EXPOSURE_FOUR		4
#define OPTION_IMAGE_EXPOSURE_FIVE		5

//Image Effect
#define OPTION_IMAGE_NOMAL_EFFECT		0
#define OPTION_IMAGE_SEPIA_EFFECT		1
#define OPTION_IMAGE_BLACKWHITE_EFFECT	2
#define OPTION_IMAGE_NEGATIVE_EFFECT	3
#define	OPTION_IMAGE_UVRED_EFFECT		4
#define OPTION_IMAGE_UVBLUE_EFFECT		5
#define OPTION_IMAGE_UVGREEN_EFFECT		6

//Image Balance
#define OPTION_IMAGE_BALANCE_AUTO			0
#define OPTION_IMAGE_BALANCE_SUNNY			1		
#define OPTION_IMAGE_BALANCE_DAY			2
#define OPTION_IMAGE_BALANCE_CWF			3		//������
#define OPTION_IMGAE_BALANCE_INCANDESENCE	4		//�鿭��


//Image Exposure
#define IMAGE_EXPOSURE_ZERO		0
#define IMAGE_EXPOSURE_ONE		1
#define IMAGE_EXPOSURE_TWO		2
#define IMAGE_EXPOSURE_THREE	3
#define IMAGE_EXPOSURE_FOUR		4
#define IMAGE_EXPOSURE_FIVE		5


// This class is exported from the M3P_Camera.dll
//Resolution 
#define OPTION_RESOLUTION_1600X1200		4
#define OPTION_RESOLUTION_1280X1024		0
#define OPTION_RESOLUTION_640X480		1
#define OPTION_RESOLUTION_320X240		2


//PREVIEW RGB DEPTH
#define OPTION_PREV_RGB_DEPTH_16BIT		0
#define OPTION_PREV_RGB_DEPTH_24BIT		1

//Save Format
#define OPTION_SAVE_FORMAT_BMP			0
#define OPTION_SAVE_FORMAT_JPG			1

//Image File Name Prefix
#define OPTION_IMAGE_FILENAME_PREF_DATE		0
#define OPTION_IMAGE_FILENAME_PREF_SERIAL	1

#if !defined(XLLP_CAMERA_IMAGE_FORMAT_RAW8)
// only for eVC
#define OPTION_XLLP_CAMERA_IMAGE_FORMAT_RAW8                0
#define OPTION_XLLP_CAMERA_IMAGE_FORMAT_RAW9                1
#define OPTION_XLLP_CAMERA_IMAGE_FORMAT_RAW10               2
                                                     
#define OPTION_XLLP_CAMERA_IMAGE_FORMAT_RGB444              3
#define OPTION_XLLP_CAMERA_IMAGE_FORMAT_RGB555              4
#define OPTION_XLLP_CAMERA_IMAGE_FORMAT_RGB565              5
#define OPTION_XLLP_CAMERA_IMAGE_FORMAT_RGB666_PACKED       6
#define OPTION_XLLP_CAMERA_IMAGE_FORMAT_RGB666_PLANAR       7
#define OPTION_XLLP_CAMERA_IMAGE_FORMAT_RGB888_PACKED	    8
#define OPTION_XLLP_CAMERA_IMAGE_FORMAT_RGB888_PLANAR       9
#define OPTION_XLLP_CAMERA_IMAGE_FORMAT_RGBT555_0          10  //RGB+Transparent bit 0
#define OPTION_XLLP_CAMERA_IMAGE_FORMAT_RGBT888_0          11
#define OPTION_XLLP_CAMERA_IMAGE_FORMAT_RGBT555_1          12  //RGB+Transparent bit 1  
#define OPTION_XLLP_CAMERA_IMAGE_FORMAT_RGBT888_1          13

#define OPTION_XLLP_CAMERA_IMAGE_FORMAT_YCBCR400           14
#define OPTION_XLLP_CAMERA_IMAGE_FORMAT_YCBCR422_PACKED    15
#define OPTION_XLLP_CAMERA_IMAGE_FORMAT_YCBCR422_PLANAR    16
#define OPTION_XLLP_CAMERA_IMAGE_FORMAT_YCBCR444_PACKED    17
#define OPTION_XLLP_CAMERA_IMAGE_FORMAT_YCBCR444_PLANAR    18
#define OPTION_XLLP_CAMERA_IMAGE_FORMAT_MAX                OPTION_XLLP_CAMERA_IMAGE_FORMAT_YCBCR444_PLANAR
#endif


#define IMAGE_ROTATE_0		0
#define IMAGE_ROTATE_90		1
#define IMAGE_ROTATE_180	2
#define IMAGE_ROTATE_270	3



// typedef struct
// {
// 	INT		nInFormat;		// IN Stream Format
// 	INT		nResolution;    // Resolution
// 	INT		nPrevRGBDepth;  // IN Stream RGB Depth
// 	INT		nSaveFormat;	// SaveFormat
// 	INT		nJpegQuality;   // Jpeg Quality
// 	INT		nImgWidth;		// Image WIdth
// 	INT		nImgHeight;     // Image Height
// 	INT		nNamePrefix;	// Image File Name Prefix
// 
// 
// 	INT		nImgLux;		// Image Lux
// 	INT		nImgExposure;	// Image exposure
// 	INT		nImgEffect;		// Image Effect
// 	INT		nImgbalance;	// Image Balance
// 
// 	INT		nImgRotatesave;		//Image Rotate
// 	INT		nImgRotateview;		//Image Rotate
// } CAM_OPTION, *LPCAM_OPTION;

class M3P_CAMERA_API CM3P_Camera {
public:
	void MC3P_Zoom(int nzoom);
	void MC3P_Bright(int nbright);

	void MC3P_GetVersion(TCHAR* ver);
	
	int		MC3P_Init(HWND hWnd,HWND p_hWnd);		
	int		MC3P_Open();
	int		MC3P_Close();
	int		MC3P_PreViewStart();
	int		MC3P_PreViewStop();
	int		MC3P_Capture();
	int		MC3P_Capture(TCHAR* tzFileName);
	int		MC3P_FlashON();
	int		MC3P_FlashOFF();

	void	MC3P_ReceiveEvent();
	void	MC3P_Set_CAMERA_OPTION(LPCAM_OPTION option,TCHAR * savefolder);
	void	MC3P_Get_CAMERA_OPTION(LPCAM_OPTION option,TCHAR * savefolder);
	DWORD	MC3P_GetBuffSize();
	void	MC3P_RowData(byte* data);	
	
	BOOL	MC3P_SaveSettingFile(TCHAR* tzFilePath);
	BOOL	MC3P_LoadSettingFile(TCHAR* tzFilePath);
};


EXTERN_C M3P_CAMERA_API	int		Kcam_MC3P_Init(HWND hWnd,HWND p_hWnd);
EXTERN_C M3P_CAMERA_API	int		Kcam_MC3P_Open();
EXTERN_C M3P_CAMERA_API int		Kcam_MC3P_Close();	
EXTERN_C M3P_CAMERA_API int		Kcam_MC3P_PreViewStart();
EXTERN_C M3P_CAMERA_API int		Kcam_MC3P_PreViewStop();
EXTERN_C M3P_CAMERA_API int		Kcam_MC3P_Capture();
EXTERN_C M3P_CAMERA_API int		Kcam_MC3P_Capture_To_File(TCHAR* tzFileName);
EXTERN_C M3P_CAMERA_API int		Kcam_MC3P_FlashON();
EXTERN_C M3P_CAMERA_API int		Kcam_MC3P_FlashOFF();
EXTERN_C M3P_CAMERA_API void	Kcam_MC3P_ReceiveEvent();
EXTERN_C M3P_CAMERA_API void	Kcam_MC3P_Set_CAMERA_OPTION(LPCAM_OPTION option,byte *szfolder);
EXTERN_C M3P_CAMERA_API void	Kcam_MC3P_Get_CAMERA_OPTION(LPCAM_OPTION option,byte *szfolder);
EXTERN_C M3P_CAMERA_API void	Kcam_MC3P_GetVersion(byte *szversion);
EXTERN_C M3P_CAMERA_API void	Kcam_MC3P_RowData(byte *data);
EXTERN_C M3P_CAMERA_API DWORD	Kcam_MC3P_GetBuffSize();
EXTERN_C M3P_CAMERA_API void	Kcam_MC3P_Zoom(int nzoom);
EXTERN_C M3P_CAMERA_API	void	Kcam_MC3P_Bright(int nbright);
EXTERN_C M3P_CAMERA_API void	MC3P_Bright(int nbright);
EXTERN_C M3P_CAMERA_API void	MC3P_Zoom(int nzoom);
EXTERN_C M3P_CAMERA_API BOOL	MC3P_Cam_SaveSettingFile(TCHAR* tzFilePath);
EXTERN_C M3P_CAMERA_API BOOL	MC3P_Cam_LoadSettingFile(TCHAR* tzFilePath);
