
#ifndef	M3P_CAMERADATATYPE_H
#define	M3P_CAMERADATATYPE_H

typedef struct
{
	INT		nInFormat;		// IN Stream Format
	INT		nResolution;    // Resolution
	INT		nPrevRGBDepth;  // IN Stream RGB Depth
	INT		nSaveFormat;	// SaveFormat
	INT		nJpegQuality;   // Jpeg Quality
	INT		nImgWidth;		// Image WIdth
	INT		nImgHeight;     // Image Height
	INT		nNamePrefix;	// Image File Name Prefix
	
	
	INT		nImgLux;		// Image Lux
	INT		nImgExposure;	// Image exposure
	INT		nImgEffect;		// Image Effect
	INT		nImgbalance;	// Image Balance
	
	INT		nImgRotatesave;		//Image Rotate
	INT		nImgRotateview;		//Image Rotate
} CAM_OPTION, *LPCAM_OPTION;


#endif
