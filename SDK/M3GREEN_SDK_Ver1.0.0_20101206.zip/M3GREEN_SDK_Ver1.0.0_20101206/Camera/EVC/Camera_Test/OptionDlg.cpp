// OptionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3P_CameraTest.h"
#include "OptionDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COptionDlg dialog


COptionDlg::COptionDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COptionDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(COptionDlg)
	m_edJpegQuality = 0;
	m_edSaveFolder = _T("");
	//}}AFX_DATA_INIT
	m_pCamOption = new CAM_OPTION();
}


void COptionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COptionDlg)
	DDX_Control(pDX, IDC_CB_ROSAVE, m_cbRotatesave);
	DDX_Control(pDX, IDC_CB_ROVIEW, m_cbRotateview);
	DDX_Control(pDX, IDC_CB_IMG_EFFECT, m_cbEffect);
	DDX_Control(pDX, IDC_SPIN_JEPG_QUALITY, m_spJpegQuality);
	DDX_Control(pDX, IDC_CB_SAVE_FORMAT, m_cbSaveFormat);
	DDX_Control(pDX, IDC_CB_IMG_RES, m_cbResolution);
	DDX_Control(pDX, IDC_CB_IMG_FORMAT, m_cbImgFormat);
	DDX_Control(pDX, IDC_CB_FICTURE_NAME, m_cbPrefix);
	DDX_Text(pDX, IDC_ED_JPEG_QUALITY, m_edJpegQuality);
	DDV_MinMaxInt(pDX, m_edJpegQuality, 30, 100);
	DDX_Text(pDX, IDC_ED_SAVEFOLDER, m_edSaveFolder);
	//DDX_Check(pDX, IDC_RD_16BIT, m_b16Bit);  by swjeon
	//DDX_Check(pDX, IDC_RD_24BIT, m_b24Bit);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COptionDlg, CDialog)
	//{{AFX_MSG_MAP(COptionDlg)
	ON_BN_CLICKED(IDC_BTN_OK, OnBtnOK)
	ON_BN_CLICKED(IDC_BTN_CANCEL, OnBtnCancel)
	ON_CBN_SELCHANGE(IDC_CB_IMG_FORMAT, OnSelchangeCbImgFormat)
	ON_CBN_SELCHANGE(IDC_CB_SAVE_FORMAT, OnSelChangeCbSaveFormat)
	ON_BN_CLICKED(IDC_BUT_VER, OnButVer)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptionDlg message handlers

BOOL COptionDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	InitControlValue();
	LoadCamOption();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void COptionDlg::InitControlValue()
{
	CEdit* pEdit = (CEdit*) GetDlgItem(IDC_ED_JPEG_QUALITY);
	// Image Format --------------------------
	m_cbImgFormat.AddString(_T("YUV(YCbCr)"));
	//m_cbImgFormat.AddString(_T("RGB565"));

	// Resolution ----------------------------
	m_cbResolution.AddString(_T("1600 x 1200"));
	m_cbResolution.AddString(_T("1280 x 1024"));
	m_cbResolution.AddString(_T(" 640 x  480"));
	m_cbResolution.AddString(_T(" 320 x  240"));

	// Save Format
	m_cbSaveFormat.AddString(_T("BMP"));
	m_cbSaveFormat.AddString(_T("JPG"));

	//Image File Name prefix
	m_cbPrefix.AddString(_T("Date"));
	m_cbPrefix.AddString(_T("custom"));
	//m_cbPrefix.SetCurSel(0);

	//Jpeg Image Quality
	m_spJpegQuality.SetRange(30, 100);
//	m_spJpegQuality.SetBuddy(pEdit);



	//Image Effect
	m_cbEffect.AddString(_T("Nomal"));
	m_cbEffect.AddString(_T("Sepia"));
	m_cbEffect.AddString(_T("BlackWhite"));
	m_cbEffect.AddString(_T("Negative"));
	m_cbEffect.AddString(_T("UvRed"));
	m_cbEffect.AddString(_T("UvBlue"));
	m_cbEffect.AddString(_T("UvGreen"));

	// Rotate Save
	m_cbRotatesave.InsertString(IMAGE_ROTATE_0, L"0");
	m_cbRotatesave.InsertString(IMAGE_ROTATE_90, L"90");
	m_cbRotatesave.InsertString(IMAGE_ROTATE_180, L"180");
	m_cbRotatesave.InsertString(IMAGE_ROTATE_270, L"270");
	
	// Rotate View
	m_cbRotateview.InsertString(IMAGE_ROTATE_0, L"0");
	m_cbRotateview.InsertString(IMAGE_ROTATE_90, L"90");
	m_cbRotateview.InsertString(IMAGE_ROTATE_180, L"180");
	m_cbRotateview.InsertString(IMAGE_ROTATE_270, L"270");

}

void COptionDlg::SaveCamOption()
{
	INT		nIdx;
	
	UpdateData();

	//Image Format
	nIdx = m_cbImgFormat.GetCurSel();
	if		( nIdx == 0) m_pCamOption->nInFormat = OPTION_XLLP_CAMERA_IMAGE_FORMAT_YCBCR422_PACKED;
	else if ( nIdx == 1) m_pCamOption->nInFormat = OPTION_XLLP_CAMERA_IMAGE_FORMAT_RGB565;

	//Resolution
	nIdx = m_cbResolution.GetCurSel();
	if (nIdx == 0)
	{		
		m_pCamOption->nResolution = OPTION_RESOLUTION_1600X1200;
		m_pCamOption->nImgWidth = 1600;
		m_pCamOption->nImgHeight = 1200;
	}	
	else if		(nIdx == 1) 
	{
		m_pCamOption->nResolution = OPTION_RESOLUTION_1280X1024;
		m_pCamOption->nImgWidth = 1280;
		m_pCamOption->nImgHeight = 1024;
	}
	else if	(nIdx == 2) 
	{
		m_pCamOption->nResolution = OPTION_RESOLUTION_640X480;
		m_pCamOption->nImgWidth = 640;
		m_pCamOption->nImgHeight = 480;

	
	}
	else if	(nIdx == 3) 
	{
		m_pCamOption->nResolution = OPTION_RESOLUTION_320X240;
		m_pCamOption->nImgWidth = 320;
		m_pCamOption->nImgHeight = 240;

	
	}

	//Display RGB Depth
	if		(m_b16Bit == TRUE) m_pCamOption->nPrevRGBDepth = OPTION_PREV_RGB_DEPTH_16BIT;
	else if (m_b24Bit == TRUE) m_pCamOption->nPrevRGBDepth = OPTION_PREV_RGB_DEPTH_24BIT;

	//Save Format
	nIdx = m_cbSaveFormat.GetCurSel();
	if		(nIdx == 0) m_pCamOption->nSaveFormat = OPTION_SAVE_FORMAT_BMP;
	else if	(nIdx == 1) m_pCamOption->nSaveFormat = OPTION_SAVE_FORMAT_JPG;

	//Jpeg Quality

	m_pCamOption->nJpegQuality = m_edJpegQuality;

	//Save Folder
//	_tcscpy(m_pCamOption->szSaveFolder, m_edSaveFolder.GetBuffer(0));
//	strcpy(m_pCamOption->szSaveFolder, (char*)m_edSaveFolder.GetBuffer(0));
	//m_pCamOption->szSaveFolder = m_edSaveFolder;
	//Picture Name Prefix

	//Image Effect
	nIdx = m_cbEffect.GetCurSel();
	if(nIdx == 0)		m_pCamOption->nImgEffect = OPTION_IMAGE_NOMAL_EFFECT;	
	else if(nIdx == 1)	m_pCamOption->nImgEffect = OPTION_IMAGE_SEPIA_EFFECT;
	else if(nIdx == 2)	m_pCamOption->nImgEffect = OPTION_IMAGE_BLACKWHITE_EFFECT;
	else if(nIdx == 3)	m_pCamOption->nImgEffect = OPTION_IMAGE_NEGATIVE_EFFECT;
	else if(nIdx == 4)	m_pCamOption->nImgEffect = OPTION_IMAGE_UVRED_EFFECT;	
	else if(nIdx == 5)	m_pCamOption->nImgEffect = OPTION_IMAGE_UVBLUE_EFFECT;	
	else if(nIdx == 6)	m_pCamOption->nImgEffect = OPTION_IMAGE_UVGREEN_EFFECT;	  

	
	nIdx = m_cbPrefix.GetCurSel();
	if(nIdx == 0)		m_pCamOption->nNamePrefix = OPTION_IMAGE_FILENAME_PREF_DATE;
	else if(nIdx == 1)	m_pCamOption->nNamePrefix = OPTION_IMAGE_FILENAME_PREF_SERIAL;


	nIdx = m_cbRotatesave.GetCurSel();
	if(nIdx == 0)	{		m_pCamOption->nImgRotatesave = IMAGE_ROTATE_0;}
	else if(nIdx == 1){		m_pCamOption->nImgRotatesave = IMAGE_ROTATE_90;}
	else if(nIdx == 2){		m_pCamOption->nImgRotatesave = IMAGE_ROTATE_180;}
	else if(nIdx == 3){		m_pCamOption->nImgRotatesave = IMAGE_ROTATE_270;}

	nIdx = m_cbRotateview.GetCurSel();
	if(nIdx == 0)	{		m_pCamOption->nImgRotateview = IMAGE_ROTATE_0;}
	else if(nIdx == 1){		m_pCamOption->nImgRotateview = IMAGE_ROTATE_90;}
	else if(nIdx == 2){		m_pCamOption->nImgRotateview = IMAGE_ROTATE_180;}
	else if(nIdx == 3){		m_pCamOption->nImgRotateview = IMAGE_ROTATE_270;}
}

void COptionDlg::LoadCamOption()
{
	//Image Format
	if      (m_pCamOption->nInFormat == OPTION_XLLP_CAMERA_IMAGE_FORMAT_YCBCR422_PACKED)  m_cbImgFormat.SetCurSel(0);
	else if (m_pCamOption->nInFormat == OPTION_XLLP_CAMERA_IMAGE_FORMAT_RGB565)           m_cbImgFormat.SetCurSel(1);

	//Resolution
	if (m_pCamOption->nResolution == OPTION_RESOLUTION_1600X1200)	m_cbResolution.SetCurSel(0);
	else if	(m_pCamOption->nResolution == OPTION_RESOLUTION_1280X1024)	m_cbResolution.SetCurSel(1);
	else if (m_pCamOption->nResolution == OPTION_RESOLUTION_640X480)	m_cbResolution.SetCurSel(2);
	else if (m_pCamOption->nResolution == OPTION_RESOLUTION_320X240)	m_cbResolution.SetCurSel(3);

	//Display RGB Depth
	if		(m_pCamOption->nPrevRGBDepth == OPTION_PREV_RGB_DEPTH_16BIT) m_b16Bit = TRUE;
	else if (m_pCamOption->nPrevRGBDepth == OPTION_PREV_RGB_DEPTH_24BIT) m_b24Bit = TRUE;

	//Save Format
	if		(m_pCamOption->nSaveFormat == OPTION_SAVE_FORMAT_BMP)	m_cbSaveFormat.SetCurSel(0);
	else if	(m_pCamOption->nSaveFormat == OPTION_SAVE_FORMAT_JPG)	m_cbSaveFormat.SetCurSel(1);

	//Jpeg Qualty
//	m_spJpegQuality.SetPos(m_pCamOption->nJpegQuality);
	m_edJpegQuality = m_pCamOption->nJpegQuality;

	//Save Folder
//	m_edSaveFolder = m_pCamOption->szSaveFolder;

	//Picture Name Prefix
	if(m_pCamOption->nNamePrefix == OPTION_IMAGE_FILENAME_PREF_DATE) m_cbPrefix.SetCurSel(0);
	else if(m_pCamOption->nNamePrefix == OPTION_IMAGE_FILENAME_PREF_SERIAL) m_cbPrefix.SetCurSel(1);

	  //Image Effect
	
	if(m_pCamOption->nImgEffect == OPTION_IMAGE_NOMAL_EFFECT)				m_cbEffect.SetCurSel(0);	
	else if(m_pCamOption->nImgEffect == OPTION_IMAGE_SEPIA_EFFECT)			m_cbEffect.SetCurSel(1);	
	else if(m_pCamOption->nImgEffect == OPTION_IMAGE_BLACKWHITE_EFFECT)		m_cbEffect.SetCurSel(2);
	else if(m_pCamOption->nImgEffect == OPTION_IMAGE_NEGATIVE_EFFECT)		m_cbEffect.SetCurSel(3);
	else if(m_pCamOption->nImgEffect == OPTION_IMAGE_UVRED_EFFECT)			m_cbEffect.SetCurSel(4);	
	else if(m_pCamOption->nImgEffect == OPTION_IMAGE_UVBLUE_EFFECT)			m_cbEffect.SetCurSel(5);	
	else if(m_pCamOption->nImgEffect == OPTION_IMAGE_UVGREEN_EFFECT)		m_cbEffect.SetCurSel(6);	  


	if(m_pCamOption->nImgRotatesave == IMAGE_ROTATE_0)				m_cbRotatesave.SetCurSel(0);
	else if(m_pCamOption->nImgRotatesave == IMAGE_ROTATE_90)		m_cbRotatesave.SetCurSel(1);
	else if(m_pCamOption->nImgRotatesave == IMAGE_ROTATE_180)		m_cbRotatesave.SetCurSel(2);
	else if(m_pCamOption->nImgRotatesave == IMAGE_ROTATE_270)		m_cbRotatesave.SetCurSel(3);


	if(m_pCamOption->nImgRotateview == IMAGE_ROTATE_0)				m_cbRotateview.SetCurSel(0);
	else if(m_pCamOption->nImgRotateview == IMAGE_ROTATE_90)		m_cbRotateview.SetCurSel(1);
	else if(m_pCamOption->nImgRotateview == IMAGE_ROTATE_180)		m_cbRotateview.SetCurSel(2);
	else if(m_pCamOption->nImgRotateview == IMAGE_ROTATE_270)		m_cbRotateview.SetCurSel(3);

	UpdateData(FALSE);

	if(m_pCamOption->nInFormat == OPTION_XLLP_CAMERA_IMAGE_FORMAT_YCBCR422_PACKED) EnablePrevRGBDepth(TRUE);
	else EnablePrevRGBDepth(FALSE);

	if(m_pCamOption->nSaveFormat == OPTION_SAVE_FORMAT_JPG) EnableJpegQuality(TRUE);
	else EnableJpegQuality(FALSE);
}

BOOL COptionDlg::CheckValue()
{
	BOOL bRet = TRUE;
	INT	 nIdx;	
	UpdateData();

	if(m_edSaveFolder.IsEmpty())
	{
		::AfxMessageBox(_T("Input Save Folder!"));
		return FALSE;
	}
	nIdx = m_cbPrefix.GetCurSel();
	if(GetFileAttributes(m_edSaveFolder.GetBuffer(0)) == 0xFFFFFFFF && nIdx ==0 )
	{
		bRet = CreateDirectory(m_edSaveFolder.GetBuffer(0), NULL);
		if(!bRet)
		{
			::AfxMessageBox(_T("Can not create folder"));
			return bRet;
		}
		return bRet;
	}
/*	if(m_edJpegQuality < 30 || m_edJpegQuality > 100)
	{
		::AfxMessageBox(_T("Input jpegquality "));
		return FALSE
	}*/
	return TRUE;
	
}

void COptionDlg::OnSelchangeCbImgFormat()
{
	CString		szText;
	INT nIdx = m_cbImgFormat.GetCurSel();
	m_cbImgFormat.GetLBText(nIdx, szText);

	if(szText.Find(_T("RGB"), 0) != -1) // RGB565
	{
		EnablePrevRGBDepth(FALSE);
		m_b16Bit = TRUE;
	}
	else // YUV
	{
		EnablePrevRGBDepth(TRUE);
	}
}

void COptionDlg::OnSelChangeCbSaveFormat()
{
	CString		szText;
	INT nIdx = m_cbSaveFormat.GetCurSel();
	m_cbSaveFormat.GetLBText(nIdx, szText);

	if(szText.Find(_T("BMP"), 0) != -1) // BMP
	{
		EnableJpegQuality(FALSE);
	}
	else // JPEG
	{
		EnableJpegQuality(TRUE);
	}
	

}

void COptionDlg::OnBtnOK()
{
	if(CheckValue()) 
	{
		SaveCamOption();
		CDialog::OnOK();
	}
	else return;
}

void COptionDlg::OnBtnCancel()
{
	CDialog::OnCancel();
}

void COptionDlg::EnablePrevRGBDepth(BOOL bEnable)
{
/*	CButton		*pRd16Bit, *pRd24Bit;

	pRd16Bit = (CButton*) GetDlgItem(IDC_RD_16BIT);
	pRd24Bit = (CButton*) GetDlgItem(IDC_RD_24BIT);

	if(bEnable) // YUV
	{
		pRd16Bit->EnableWindow(TRUE);
		pRd24Bit->EnableWindow(TRUE);
		if(m_pCamOption->nPrevRGBDepth == OPTION_PREV_RGB_DEPTH_16BIT) 
		{
			m_b16Bit = TRUE; 
			m_b24Bit = FALSE;
		}
		else 
		{
			m_b16Bit = FALSE;
			m_b24Bit = TRUE;
		}		
		m_cbEffect.EnableWindow(TRUE);
	}
	else // RGB565
	{
		pRd16Bit->EnableWindow(FALSE);
		pRd24Bit->EnableWindow(FALSE);
		m_b16Bit = TRUE; m_b24Bit = FALSE;
		m_cbEffect.EnableWindow(FALSE);
	}
	
	UpdateData(FALSE);*/
}

void COptionDlg::EnableJpegQuality(BOOL bEnable)
{
	CEdit	*pEdit = (CEdit*) GetDlgItem(IDC_ED_JPEG_QUALITY);
	if(bEnable)
	{
		pEdit->EnableWindow(TRUE);
		m_spJpegQuality.EnableWindow(TRUE);
	}
	else
	{
		pEdit->EnableWindow(FALSE);
		m_spJpegQuality.EnableWindow(FALSE);
	}
}

void COptionDlg::OnButVer() 
{
 
	MessageBox(m_ver,L"Version",MB_OK);
}

void COptionDlg::OnClose() 
{
	delete m_pCamOption;
	CDialog::OnClose();
}
