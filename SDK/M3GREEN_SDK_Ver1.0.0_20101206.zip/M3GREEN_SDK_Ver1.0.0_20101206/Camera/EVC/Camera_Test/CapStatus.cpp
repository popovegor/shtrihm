// CapStatus.cpp : implementation file
//

#include "stdafx.h"
#include "M3P_CameraTest.h"
#include "CapStatus.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCapStatus dialog


CCapStatus::CCapStatus(CWnd* pParent /*=NULL*/)
	: CDialog(CCapStatus::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCapStatus)
	m_szCapStatus = _T("");
	//}}AFX_DATA_INIT
}


void CCapStatus::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCapStatus)
	DDX_Text(pDX, IDC_STATIC_CAP_STAUS, m_szCapStatus);
	DDV_MaxChars(pDX, m_szCapStatus, 64);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCapStatus, CDialog)
	//{{AFX_MSG_MAP(CCapStatus)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCapStatus message handlers
