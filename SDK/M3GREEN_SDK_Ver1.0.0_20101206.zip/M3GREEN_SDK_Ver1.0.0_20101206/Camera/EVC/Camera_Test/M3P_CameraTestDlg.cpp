// M3P_CameraTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include <pkfuncs.h>
#include "M3P_CameraTest.h"
#include "M3P_CameraTestDlg.h"
//#include <capstatus.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#define WM_GETBMP		(WM_USER+100)
#define WM_USER_POWERNOTI	(WM_USER + 124)
int		g_device_type;


#define	WM_CAPTURE_NOTIFY (WM_USER + 1001)

#define SAVE_FILE		TEXT("Flash Disk\\Camera\\CameraSetting.ini")

DWORD ThreadFuncCapStatus(LPVOID pParam);

/////////////////////////////////////////////////////////////////////////////
// CM3P_CameraTestDlg dialog

CM3P_CameraTestDlg::CM3P_CameraTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CM3P_CameraTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CM3P_CameraTestDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_bCamerOnoff = FALSE;
}

void CM3P_CameraTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CM3P_CameraTestDlg)
	//DDX_Control(pDX, IDC_SLIDER1, m_ctrlslider);
	DDX_Control(pDX, IDC_STATIC_TEST, m_ctrltestview);
	DDX_Control(pDX, IDC_STATIC_PREVIEW, m_ctrlpreview);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_COMBO1, m_ctrlcombo);
}

BEGIN_MESSAGE_MAP(CM3P_CameraTestDlg, CDialog)
	//{{AFX_MSG_MAP(CM3P_CameraTestDlg)
	ON_BN_CLICKED(IDC_BUT_PREVIEW_START, OnButPreviewStart)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BUT_PREVIEW_STOP, OnButPreviewStop)
	ON_BN_CLICKED(IDC_BUT_CAPTURE, OnButCapture)
	ON_BN_CLICKED(IDC_BUT_OPTION, OnButOption)
	ON_BN_CLICKED(IDC_BUT_FLASHON, OnButFlashon)
	ON_BN_CLICKED(IDC_BUT_FLASHOFF, OnButFlashoff)
	ON_BN_CLICKED(IDC_BUT_ROWDATA, OnButRowdata)
	ON_NOTIFY(NM_OUTOFMEMORY, IDC_SLIDER1, OnOutofmemorySlider1)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER1, OnCustomdrawSlider1)	
	ON_WM_VSCROLL()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON5, OnButton5)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_CBN_SELENDOK(IDC_COMBO1, OnSelendokCombo1)
	ON_BN_CLICKED(IDCANCLE, OnCancle)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_GETBMP,				OnReceiveEvent)
	ON_MESSAGE(WM_USER_POWERNOTI,			OnPowerResume)
//	ON_MESSAGE(WM_HSCROLL,				OnVScroll)   //by swjeon
	ON_MESSAGE(WM_SHOW_CAP_STATUS,		OnShowCaptureStatus)	
//	ON_MESSAGE(WM_CAPTURE_NOTIFY,		OnShowCaptureStatus)
//	ON_CBN_SELENDOK(IDC_COMBO1, &CM3P_CameraTestDlg::OnCbnSelendokCombo1)

ON_WM_TIMER()
END_MESSAGE_MAP()



/////////////////////////////////////////////////////////////////////////////
// CM3P_CameraTestDlg message handlers

BOOL CM3P_CameraTestDlg::OnInitDialog()
{
	DWORD dwThreadID;
	
	RETAILMSG(1, (TEXT("+CM3P_CameraTestDlg::OnInitDialog\r\n")));

	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	//Rotate_270();
	CenterWindow(GetDesktopWindow());	// center to the hpc screen
	CRect    rect;
	
	GetWindowRect(rect);
//	m_ctrlslider.SetRange(0,5, TRUE);
	MoveWindow(0,-1,rect.Width(),rect.Height());
	m_ctrlcombo.AddString(L"1");
	m_ctrlcombo.AddString(L"2");
	m_ctrlcombo.AddString(L"3");
	m_ctrlcombo.AddString(L"4");
	m_ctrlcombo.AddString(L"5");
	m_ctrlcombo.SetCurSel(2);
	// ???? ���α׷� ���۽� ���� 0���� �ʱ�ȭ �ʿ�
	// landscape
/*	DEVMODE de;
	memset( &de, 0, sizeof( DEVMODE ) );
	de.dmSize = sizeof( DEVMODE );
	de.dmFields = DM_DISPLAYORIENTATION;
	de.dmDisplayOrientation  = DMDO_270;
	ChangeDisplaySettingsEx( NULL, &de, NULL, 0, NULL );
*/
	// ȭ�� ������ �� ��ġ ����
//	ShowWindow(SW_SHOW);
//	MoveWindow(0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), TRUE);	
//	SetWindowPos(&CWnd::wndTopMost, 0, 0, 0, 0, SWP_NOSIZE);	

	
	m_ctrlpreview.MoveWindow(0,0,240,320);
	
	SetWindowPos(&CWnd::wndTopMost, 0, 0, 240, 320, SWP_NOSIZE);	
	MoveWindow(0,0,240,320);


	 if(!m_m3p_camera.MC3P_Init(m_hWnd,m_ctrlpreview.m_hWnd)) //return device type  0: 6300, 1: 6400, 2:6500
	 {
		// GetDlgItem(IDC_BUT_FLASHON)->EnableWindow(FALSE);
		// GetDlgItem(IDC_BUT_FLASHOFF)->EnableWindow(FALSE);
		 ;
	 }

//	GetDlgItem(IDC_BUT_CAPTURE)->EnableWindow(FALSE);
//	GetDlgItem(IDC_BUT_PREVIEW_STOP)->EnableWindow(FALSE);	

	 if(!m_m3p_camera.MC3P_Open())
	{
		AfxMessageBox(L"Com Open Error");
		return FALSE;
	}

	m_pDlgCapStatus = new CCapStatus; 
	m_bThreadExit = FALSE;

	
	m_hCapStatusEvent = CreateEvent(NULL, FALSE, 0, _T("CapStatusEvent"));
	if (m_hCapStatusEvent == NULL)
		return FALSE;

	m_hCapStatusThread = CreateThread(0, 0, ThreadFuncCapStatus, this, 0, &dwThreadID);

	if (m_hCapStatusThread == NULL) {
		RETAILMSG(1, (TEXT("CM3CamAppView:CreateThread, ThreadFuncCapStatus failed, %d\r\n"), GetLastError()));
		return FALSE;
	}

	SetThreadPriority (m_hCapStatusThread, THREAD_PRIORITY_HIGHEST);
	

	RETAILMSG(1, (TEXT("-CM3P_CameraTestDlg::OnInitDialog\r\n")));
	UpdateData();

	m_m3p_camera.MC3P_LoadSettingFile(SAVE_FILE);

	return TRUE;  // return TRUE  unless you set the focus to a control
}



void CM3P_CameraTestDlg::OnButPreviewStart() 
{	
	//m_ctrlslider.SetPos(3);

	m_m3p_camera.MC3P_PreViewStart();

	
	
	GetDlgItem(IDC_BUT_OPTION)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUT_PREVIEW_START)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUT_CAPTURE)->EnableWindow(TRUE);
	GetDlgItem(IDC_BUT_PREVIEW_STOP)->EnableWindow(TRUE);
	m_bCamerOnoff = TRUE;
}

void CM3P_CameraTestDlg::OnButPreviewStop() 
{

	m_m3p_camera.MC3P_PreViewStop();
	m_ctrlpreview.Invalidate();
	GetDlgItem(IDC_BUT_OPTION)->EnableWindow(TRUE);
	GetDlgItem(IDC_BUT_PREVIEW_START)->EnableWindow(TRUE);
	GetDlgItem(IDC_BUT_CAPTURE)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUT_PREVIEW_STOP)->EnableWindow(FALSE);

	m_bCamerOnoff = FALSE;
	if(m_bFlash)
		OnButFlashoff();
}
void CM3P_CameraTestDlg::OnClose() 
{
/*		DEVMODE de;
	memset( &de, 0, sizeof( DEVMODE ) );
	de.dmSize = sizeof( DEVMODE );
	de.dmFields = DM_DISPLAYORIENTATION;
	de.dmDisplayOrientation  = DMDO_0;
	ChangeDisplaySettingsEx( NULL, &de, NULL, 0, NULL );*/
//	Rotate_0();
	if(m_bCamerOnoff)
	m_m3p_camera.MC3P_PreViewStop();
	if(m_bFlash)
		OnButFlashoff();
	m_m3p_camera.MC3P_Close();

	CDialog::OnClose();
}
LRESULT CM3P_CameraTestDlg::OnReceiveEvent(WPARAM wParam, LPARAM lParam)
{
	m_m3p_camera.MC3P_ReceiveEvent();
    return 0;
}

void CM3P_CameraTestDlg::OnButCapture() 
{
	if(m_bCamerOnoff)
	{	
		m_m3p_camera.MC3P_Capture();	
	}
	if(m_bFlash)
		OnButFlashoff();


}



void CM3P_CameraTestDlg::OnButOption() 
{
	  
	TCHAR szfolder[260]={0,};
	TCHAR szversion[260]={0,};

	m_m3p_camera.MC3P_Get_CAMERA_OPTION(m_dlgoption.m_pCamOption,szfolder);
	m_dlgoption.m_edSaveFolder = szfolder;
	m_m3p_camera.MC3P_GetVersion(szversion);
	m_dlgoption.m_ver = szversion;
	if(IDCANCEL == m_dlgoption.DoModal())
	{
		return;
	}
	else
	{		

	
		m_m3p_camera.MC3P_Set_CAMERA_OPTION(m_dlgoption.m_pCamOption,m_dlgoption.m_edSaveFolder.GetBuffer(0));
		
		m_m3p_camera.MC3P_SaveSettingFile(SAVE_FILE);
		
	}
return;	
}

BOOL CM3P_CameraTestDlg::PreTranslateMessage(MSG* pMsg) 
{
	if(pMsg->message == WM_KEYDOWN|| pMsg->message == WM_SYSKEYDOWN)
	{	
		if(pMsg->wParam == VK_F23)
		{			
			OnButCapture();	
		}
	}
	return CDialog::PreTranslateMessage(pMsg);
	

}

void CM3P_CameraTestDlg::OnButFlashon() 
{


	m_m3p_camera.MC3P_FlashON();
	m_bFlash = TRUE;
		
}

void CM3P_CameraTestDlg::OnButFlashoff() 
{
	m_m3p_camera.MC3P_FlashOFF();
	m_bFlash = FALSE;
}
LRESULT CM3P_CameraTestDlg::OnPowerResume(WPARAM wParam, LPARAM lParam)
{
	OnButPreviewStop();
	OnButPreviewStart();
	return TRUE;
}

void CM3P_CameraTestDlg::sound()
{
	TCHAR		szResID[50] = {0, };

	wsprintf(szResID, _T("#%d"), IDR_WAVE_SHUTTER);

	PlaySound(szResID, ::AfxGetResourceHandle(), SND_RESOURCE | SND_ASYNC | SND_NODEFAULT);
}

void CM3P_CameraTestDlg::OnButRowdata() 
{
	byte   *m_data;
	DWORD   dsize;
	RECT	rect;

	HDC		hPreviewDC = NULL;
	HBITMAP		hBitmap = NULL;
	HBITMAP		hOldBitmap = NULL;
	HDC			hMemoryDC = NULL;

	dsize = m_m3p_camera.MC3P_GetBuffSize();
	m_data = new byte[dsize];
	memset(m_data,0,dsize);
	m_m3p_camera.MC3P_RowData(m_data);
	
	
	hPreviewDC = ::GetDC(m_ctrltestview.m_hWnd);
	hMemoryDC = CreateCompatibleDC(hPreviewDC);
	
	::GetClientRect(m_ctrltestview.m_hWnd, &rect);
	hBitmap = CreateBitmap ( 320,240, 1, 24, (char*)m_data);
	hOldBitmap = (HBITMAP)SelectObject (hMemoryDC, hBitmap);
	
	
	StretchBlt(hPreviewDC, 0, 0, rect.right-rect.left, rect.bottom-rect.top, hMemoryDC, 0, 0, 320, 240, SRCCOPY); 
	
	SelectObject(hMemoryDC,hOldBitmap);
	
	DeleteObject(hBitmap);
	
	DeleteDC (hMemoryDC);
	
	::ReleaseDC (m_ctrltestview.m_hWnd, hPreviewDC);
	delete  [] m_data;
	
}

void CM3P_CameraTestDlg::OnOutofmemorySlider1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	
	
	
	*pResult = 0;
}

void CM3P_CameraTestDlg::OnCustomdrawSlider1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	
	
	*pResult = 0;
}


void CM3P_CameraTestDlg::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	CSliderCtrl* pSlider = (CSliderCtrl*)pScrollBar;

	RETAILMSG(1, (TEXT("CM3P_CameraTestDlg::OnVScroll, nPos:%d\r\n"), nPos));

    //switch(pSlider->GetDlgCtrlID())

    //{

    //case IDC_SLIDER1:

     if(nSBCode == SB_ENDSCROLL )

     {

	  //    m_m3p_camera.MC3P_Bright(m_ctrlslider.GetPos());    

     }

     //   break;

    //}

	
//	CDialog::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CM3P_CameraTestDlg::OnButton1() 
{
	SendMessage(WM_CLOSE);
	
}

void CM3P_CameraTestDlg::OnButton5() 
{
	
	m_m3p_camera.MC3P_Zoom(0);
}

void CM3P_CameraTestDlg::OnButton3() 
{
	m_m3p_camera.MC3P_Zoom(1);
}

void CM3P_CameraTestDlg::OnButton4() 
{
	m_m3p_camera.MC3P_Zoom(2);
}


LRESULT CM3P_CameraTestDlg::OnShowCaptureStatus(UINT wParam, LONG lParam)
{
	RETAILMSG(1, (TEXT("OnShowCaptureStatus wParam:x%x, lParam:x%x\r\n"), wParam, lParam));

	switch (wParam) {
		case CAP_STATUS_START:
			m_pDlgCapStatus->m_szCapStatus = _T("                           ");
			m_pDlgCapStatus->Create(IDD_DIALOG_CAP_STATUS, NULL);
			break;

		case CAP_STATUS_IMG_TRANSFORM:

			m_pDlgCapStatus->m_szCapStatus = _T("Image transform...");
			m_pDlgCapStatus->UpdateData(FALSE);
			break;
				
		case CAP_STATUS_IMG_SCALE_UP:
			m_pDlgCapStatus->m_szCapStatus = _T("Scale up image size...");
			m_pDlgCapStatus->UpdateData(FALSE);
			break;
				
		case CAP_STATUS_IMG_SAVE:
			m_pDlgCapStatus->m_szCapStatus = _T("Image saving...");
			m_pDlgCapStatus->UpdateData(FALSE);
			break;
				
		case CAP_STATUS_END:
			Sleep(1000);
			m_pDlgCapStatus->DestroyWindow();
			break;
				
		default:
			break;
	}
		
	return 0L;
}



DWORD ThreadFuncCapStatus(LPVOID pParam)
{
	CM3P_CameraTestDlg *pDlg = (CM3P_CameraTestDlg *)pParam;
//	CCapStatus *pCapState = pDlg->m_pDlgCapStatus;
	DWORD CapStatus;
	
	while(1) {
		RETAILMSG(1, (TEXT("Wait CapStatusEvent\r\n")));
		WaitForSingleObject(pDlg->m_hCapStatusEvent, INFINITE);

		if (pDlg->m_bThreadExit) {
			RETAILMSG(1, (TEXT("CapStatusEvent exited\r\n")));
			return 0;
		}

		CapStatus = GetEventData(pDlg->m_hCapStatusEvent);

		if(CAP_STATUS_IMG_TRANSFORM == CapStatus)
			pDlg->sound();
//		pDlg->SendMessage(WM_SHOW_CAP_STATUS, CapStatus, 0);

//		SetTimer(pDlg->m_hWnd, CapStatus, 10, NULL);

	}
}
/*
void CM3P_CameraTestDlg::OnCbnSelendokCombo1()
{
	int i = m_ctrlcombo.GetCurSel();

	
	m_m3p_camera.MC3P_Bright(m_ctrlcombo.GetCurSel());
	
}*/

void CM3P_CameraTestDlg::OnSelendokCombo1() 
{
	int i = m_ctrlcombo.GetCurSel();

	
	m_m3p_camera.MC3P_Bright(m_ctrlcombo.GetCurSel());
	
}

void CM3P_CameraTestDlg::Rotate_0(void)
{



		DEVMODE DeviceMode;
    
	memset(&DeviceMode, NULL, sizeof(DeviceMode));
	DeviceMode.dmSize=sizeof(DeviceMode);
	DeviceMode.dmFields = DM_DISPLAYORIENTATION;
	DeviceMode.dmDisplayOrientation = DMDO_0; //Put your desired 
	//position right here.
	
	if (DISP_CHANGE_SUCCESSFUL == ChangeDisplaySettingsEx(
		NULL,
		&DeviceMode,
		NULL,
		CDS_RESET,
		NULL
		)
		)
		;
	else
		AfxMessageBox(L"fail");
}

void CM3P_CameraTestDlg::Rotate_270(void)
{
			DEVMODE DeviceMode;
    
	memset(&DeviceMode, NULL, sizeof(DeviceMode));
	DeviceMode.dmSize=sizeof(DeviceMode);
	DeviceMode.dmFields = DM_DISPLAYORIENTATION;
	DeviceMode.dmDisplayOrientation = DMDO_270; //Put your desired 
	//position right here.
	
	if (DISP_CHANGE_SUCCESSFUL == ChangeDisplaySettingsEx(
		NULL,
		&DeviceMode,
		NULL,
		CDS_RESET,
		NULL
		)
		)
		;
	else
		AfxMessageBox(L"fail");
}



void CM3P_CameraTestDlg::OnCancle() 
{
	SendMessage(WM_CLOSE);
	
}

void CM3P_CameraTestDlg::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: Add your message handler code here and/or call default
	KillTimer(nIDEvent);
	switch(nIDEvent)
	{
	case CAP_STATUS_START:
		m_pDlgCapStatus->m_szCapStatus = _T("                           ");
		m_pDlgCapStatus->Create(IDD_DIALOG_CAP_STATUS, NULL);
		break;

	case CAP_STATUS_IMG_TRANSFORM:
		m_pDlgCapStatus->m_szCapStatus = _T("Image transform...");
		m_pDlgCapStatus->UpdateData(FALSE);
		break;

	case CAP_STATUS_IMG_SCALE_UP:
		m_pDlgCapStatus->m_szCapStatus = _T("Scale up image size...");
		m_pDlgCapStatus->UpdateData(FALSE);
		break;

	case CAP_STATUS_IMG_SAVE:
		m_pDlgCapStatus->m_szCapStatus = _T("Image saving...");
		m_pDlgCapStatus->UpdateData(FALSE);
		break;

	case CAP_STATUS_END:
//		Sleep(1000);
		m_pDlgCapStatus->DestroyWindow();
		break;

	default:
		break;
	}


	CDialog::OnTimer(nIDEvent);
}
