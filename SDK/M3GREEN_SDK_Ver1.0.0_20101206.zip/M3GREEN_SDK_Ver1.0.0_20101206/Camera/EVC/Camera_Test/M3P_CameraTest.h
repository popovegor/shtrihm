// M3P_CameraTest.h : main header file for the M3P_CAMERATEST application
//

#if !defined(AFX_M3P_CAMERATEST_H__1C7FF57F_99C8_487D_AAC1_014951751901__INCLUDED_)
#define AFX_M3P_CAMERATEST_H__1C7FF57F_99C8_487D_AAC1_014951751901__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CM3P_CameraTestApp:
// See M3P_CameraTest.cpp for the implementation of this class
//

class CM3P_CameraTestApp : public CWinApp
{
public:
	CM3P_CameraTestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CM3P_CameraTestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CM3P_CameraTestApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_M3P_CAMERATEST_H__1C7FF57F_99C8_487D_AAC1_014951751901__INCLUDED_)
