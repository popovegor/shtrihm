//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by M3P_CameraTest.rc
//
#define IDR_WAVE_SHUTTER                101
#define IDD_M3P_CAMERATEST_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDD_DLG_CAMOPTION               130
#define IDD_DLG_OPTION                  131
#define IDD_DIALOG1                     134
#define IDD_DIALOG2                     135
#define IDD_DIALOG_CAP_STATUS           137
#define IDC_BUT_CAPTURE                 1000
#define IDC_BUT_OPTION                  1001
#define IDC_BUT_PREVIEW_START           1002
#define IDC_BUT_PREVIEW_STOP            1003
#define IDC_BUT_FLASHON                 1004
#define IDC_BUT_FLASHOFF                1005
#define IDC_STATIC_PREVIEW              1006
#define IDC_COMBO_FORMAT                1007
#define IDC_BUT_ROWDATA                 1007
#define IDC_BUT_PREVIEW_STOP2           1007
#define IDC_COMBO_RESOULUTION           1008
#define IDC_RADIO1                      1009
#define IDC_RADIO2                      1010
#define IDC_COMBO_SAVEFORMAT            1011
#define IDC_EDIT_JPECQUALITY            1012
#define IDC_SCROLLBAR1                  1013
#define IDC_EDIT_SAVEFOLDER             1014
#define IDC_COMBO_PICTURENAME           1015
#define ID_BTN_OK                       1016
#define ID_BTN_CANCEL                   1017
#define IDC_SPIN1                       1018
#define IDC_CB_IMG_LUX                  1021
#define IDC_CB_IMG_EXPOSURE             1022
#define IDC_BUT_VER                     1022
#define IDC_CB_IMG_BALANCE              1023
#define IDC_STATIC_TEST                 1023
#define IDC_CB_IMG_EFFECT               1024
#define IDC_CB_ROTATE                   1025
#define IDC_CB_ROSAVE                   1025
#define IDC_CB_ROVIEW                   1026
#define IDC_CB_IMG_FORMAT               1028
#define IDC_SLIDER1                     1028
#define IDC_BUTTON1                     1029
#define IDCANCLE                        1029
#define IDC_CB_IMG_RES                  1030
#define IDC_CB_SAVE_FORMAT              1031
#define IDC_BUTTON3                     1031
#define IDC_ED_JPEG_QUALITY             1032
#define IDC_BUTTON4                     1032
#define IDC_BUTTON5                     1033
#define IDC_SPIN_JEPG_QUALITY           1034
#define IDC_STATIC_CAP_STAUS            1034
#define IDC_ED_SAVEFOLDER               1035
#define IDC_COMBO1                      1035
#define IDC_RD_16BIT                    1036
#define IDC_RD_24BIT                    1037
#define IDC_CB_FICTURE_NAME             1039
#define IDC_BTN_OK                      1040
#define IDC_BTN_CANCEL                  1041

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
