// M3P_CameraTestDlg.h : header file
//

#if !defined(AFX_M3P_CAMERATESTDLG_H__79A7EF66_0EA4_4489_9A4D_46191BAED389__INCLUDED_)
#define AFX_M3P_CAMERATESTDLG_H__79A7EF66_0EA4_4489_9A4D_46191BAED389__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define WM_SHOW_CAP_STATUS			(WM_USER + 5)

/////////////////////////////////////////////////////////////////////////////
// CM3P_CameraTestDlg dialog

#include "OptionDlg.h"
#include "CapStatus.h"
#include "afxwin.h"

typedef enum
{
	CAP_STATUS_START = 0x1,
	CAP_STATUS_IMG_TRANSFORM = 0x2,
	CAP_STATUS_IMG_SCALE_UP = 0x4,
	CAP_STATUS_IMG_SAVE = 0x8,
	CAP_STATUS_END = 0x10,
} CAP_STATUS;
class CM3P_CameraTestDlg : public CDialog
{
// Construction
public:
	CM3P_CameraTestDlg(CWnd* pParent = NULL);	// standard constructor
public:
	void sound();
	BOOL m_bFlash;
	
	CM3P_Camera		m_m3p_camera;
	COptionDlg	  m_dlgoption;
	BOOL		   m_bCamerOnoff;
	CCapStatus	*	m_pDlgCapStatus;
	BOOL			m_bThreadExit;
	HANDLE			m_hCapStatusEvent;
	HANDLE			m_hCapStatusThread;
	LRESULT OnShowCaptureStatus(UINT wParam, LONG lParam);

// Dialog Data
	//{{AFX_DATA(CM3P_CameraTestDlg)
	enum { IDD = IDD_M3P_CAMERATEST_DIALOG };
	//CSliderCtrl	m_ctrlslider;
	CStatic	m_ctrltestview;
	CStatic	m_ctrlpreview;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CM3P_CameraTestDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CM3P_CameraTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnButPreviewStart();
	afx_msg void OnClose();
	afx_msg void OnButPreviewStop();
	afx_msg void OnButCapture();
	afx_msg void OnButOption();
	afx_msg void OnButFlashon();
	afx_msg void OnButFlashoff();
	afx_msg void OnButRowdata();
	afx_msg void OnOutofmemorySlider1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnCustomdrawSlider1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnButton1();
	afx_msg void OnButton5();
	afx_msg void OnButton3();
	afx_msg void OnButton4();
	afx_msg void OnSelendokCombo1();
	afx_msg void OnCancle();
	//}}AFX_MSG
	afx_msg LRESULT OnReceiveEvent(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnPowerResume(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
public:
	CComboBox m_ctrlcombo;
//	afx_msg void OnCbnSelendokCombo1();
	void Rotate_0(void);
	void Rotate_270(void);
//	afx_msg void OnBnClickedCancle();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_M3P_CAMERATESTDLG_H__79A7EF66_0EA4_4489_9A4D_46191BAED389__INCLUDED_)
