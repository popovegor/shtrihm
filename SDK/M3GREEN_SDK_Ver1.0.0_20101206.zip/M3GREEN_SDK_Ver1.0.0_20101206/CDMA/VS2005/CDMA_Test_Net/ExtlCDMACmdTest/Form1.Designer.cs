﻿namespace ExtlCDMACmdTest
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lst_Msg = new System.Windows.Forms.ListBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Dlg1 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.Btn_Sendsms = new System.Windows.Forms.Button();
            this.Btn_Hangup = new System.Windows.Forms.Button();
            this.Btn_Call = new System.Windows.Forms.Button();
            this.Txt_Sms = new System.Windows.Forms.TextBox();
            this.Txt_Callback = new System.Windows.Forms.TextBox();
            this.Txt_Phonenum = new System.Windows.Forms.TextBox();
            this.Dlg2 = new System.Windows.Forms.TabPage();
            this.Btn_Rssi = new System.Windows.Forms.Button();
            this.Btn_RssiGrade = new System.Windows.Forms.Button();
            this.Btn_Phonenum = new System.Windows.Forms.Button();
            this.Btn_Regwnd = new System.Windows.Forms.Button();
            this.Dlg3 = new System.Windows.Forms.TabPage();
            this.Chk_Callblock = new System.Windows.Forms.CheckBox();
            this.Btn_CallBlockState = new System.Windows.Forms.Button();
            this.Btn_SetCallBlock = new System.Windows.Forms.Button();
            this.Btn_HangUpRas = new System.Windows.Forms.Button();
            this.Btn_RasDialUp = new System.Windows.Forms.Button();
            this.Btn_GetRasState = new System.Windows.Forms.Button();
            this.Dlg4 = new System.Windows.Forms.TabPage();
            this.Btn_ClosePowerNoti = new System.Windows.Forms.Button();
            this.Btn_SetupPowerNoti = new System.Windows.Forms.Button();
            this.Btn_GetDateTime = new System.Windows.Forms.Button();
            this.Btn_CDMASerial = new System.Windows.Forms.Button();
            this.Dlg5 = new System.Windows.Forms.TabPage();
            this.Btn_SmsCnt = new System.Windows.Forms.Button();
            this.Btn_SmsData = new System.Windows.Forms.Button();
            this.Btn_SmsRemove = new System.Windows.Forms.Button();
            this.Txt_SmsIndex = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.Dlg1.SuspendLayout();
            this.Dlg2.SuspendLayout();
            this.Dlg3.SuspendLayout();
            this.Dlg4.SuspendLayout();
            this.Dlg5.SuspendLayout();
            this.SuspendLayout();
            // 
            // Lst_Msg
            // 
            this.Lst_Msg.Location = new System.Drawing.Point(5, 4);
            this.Lst_Msg.Name = "Lst_Msg";
            this.Lst_Msg.Size = new System.Drawing.Size(228, 82);
            this.Lst_Msg.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Dlg1);
            this.tabControl1.Controls.Add(this.Dlg2);
            this.tabControl1.Controls.Add(this.Dlg3);
            this.tabControl1.Controls.Add(this.Dlg4);
            this.tabControl1.Controls.Add(this.Dlg5);
            this.tabControl1.Location = new System.Drawing.Point(5, 92);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(228, 172);
            this.tabControl1.TabIndex = 1;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // Dlg1
            // 
            this.Dlg1.Controls.Add(this.label1);
            this.Dlg1.Controls.Add(this.Btn_Sendsms);
            this.Dlg1.Controls.Add(this.Btn_Hangup);
            this.Dlg1.Controls.Add(this.Btn_Call);
            this.Dlg1.Controls.Add(this.Txt_Sms);
            this.Dlg1.Controls.Add(this.Txt_Callback);
            this.Dlg1.Controls.Add(this.Txt_Phonenum);
            this.Dlg1.Location = new System.Drawing.Point(4, 25);
            this.Dlg1.Name = "Dlg1";
            this.Dlg1.Size = new System.Drawing.Size(220, 143);
            this.Dlg1.Text = "   1   ";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(12, 120);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 20);
            this.label1.Text = "CallBack";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Btn_Sendsms
            // 
            this.Btn_Sendsms.Location = new System.Drawing.Point(145, 117);
            this.Btn_Sendsms.Name = "Btn_Sendsms";
            this.Btn_Sendsms.Size = new System.Drawing.Size(64, 23);
            this.Btn_Sendsms.TabIndex = 5;
            this.Btn_Sendsms.Text = "SendSms";
            this.Btn_Sendsms.Click += new System.EventHandler(this.Btn_Sendsms_Click);
            // 
            // Btn_Hangup
            // 
            this.Btn_Hangup.Location = new System.Drawing.Point(153, 15);
            this.Btn_Hangup.Name = "Btn_Hangup";
            this.Btn_Hangup.Size = new System.Drawing.Size(56, 23);
            this.Btn_Hangup.TabIndex = 4;
            this.Btn_Hangup.Text = "HangUp";
            this.Btn_Hangup.Click += new System.EventHandler(this.Btn_Hangup_Click);
            // 
            // Btn_Call
            // 
            this.Btn_Call.Location = new System.Drawing.Point(99, 15);
            this.Btn_Call.Name = "Btn_Call";
            this.Btn_Call.Size = new System.Drawing.Size(56, 23);
            this.Btn_Call.TabIndex = 3;
            this.Btn_Call.Text = "Call";
            this.Btn_Call.Click += new System.EventHandler(this.Btn_Call_Click);
            // 
            // Txt_Sms
            // 
            this.Txt_Sms.Location = new System.Drawing.Point(12, 47);
            this.Txt_Sms.Multiline = true;
            this.Txt_Sms.Name = "Txt_Sms";
            this.Txt_Sms.Size = new System.Drawing.Size(197, 67);
            this.Txt_Sms.TabIndex = 2;
            // 
            // Txt_Callback
            // 
            this.Txt_Callback.Location = new System.Drawing.Point(71, 117);
            this.Txt_Callback.Name = "Txt_Callback";
            this.Txt_Callback.Size = new System.Drawing.Size(70, 23);
            this.Txt_Callback.TabIndex = 1;
            // 
            // Txt_Phonenum
            // 
            this.Txt_Phonenum.Location = new System.Drawing.Point(12, 15);
            this.Txt_Phonenum.Name = "Txt_Phonenum";
            this.Txt_Phonenum.Size = new System.Drawing.Size(81, 23);
            this.Txt_Phonenum.TabIndex = 0;
            // 
            // Dlg2
            // 
            this.Dlg2.Controls.Add(this.Btn_Rssi);
            this.Dlg2.Controls.Add(this.Btn_RssiGrade);
            this.Dlg2.Controls.Add(this.Btn_Phonenum);
            this.Dlg2.Controls.Add(this.Btn_Regwnd);
            this.Dlg2.Location = new System.Drawing.Point(4, 25);
            this.Dlg2.Name = "Dlg2";
            this.Dlg2.Size = new System.Drawing.Size(220, 143);
            this.Dlg2.Text = "   2   ";
            // 
            // Btn_Rssi
            // 
            this.Btn_Rssi.Location = new System.Drawing.Point(112, 73);
            this.Btn_Rssi.Name = "Btn_Rssi";
            this.Btn_Rssi.Size = new System.Drawing.Size(93, 42);
            this.Btn_Rssi.TabIndex = 4;
            this.Btn_Rssi.Text = "RSSI";
            this.Btn_Rssi.Click += new System.EventHandler(this.Btn_Rssi_Click);
            // 
            // Btn_RssiGrade
            // 
            this.Btn_RssiGrade.Location = new System.Drawing.Point(13, 73);
            this.Btn_RssiGrade.Name = "Btn_RssiGrade";
            this.Btn_RssiGrade.Size = new System.Drawing.Size(93, 42);
            this.Btn_RssiGrade.TabIndex = 3;
            this.Btn_RssiGrade.Text = "RSSI Grade";
            this.Btn_RssiGrade.Click += new System.EventHandler(this.Btn_RssiGrade_Click);
            // 
            // Btn_Phonenum
            // 
            this.Btn_Phonenum.Location = new System.Drawing.Point(112, 23);
            this.Btn_Phonenum.Name = "Btn_Phonenum";
            this.Btn_Phonenum.Size = new System.Drawing.Size(93, 42);
            this.Btn_Phonenum.TabIndex = 1;
            this.Btn_Phonenum.Text = "Phone Num";
            this.Btn_Phonenum.Click += new System.EventHandler(this.Btn_Phonenum_Click);
            // 
            // Btn_Regwnd
            // 
            this.Btn_Regwnd.Location = new System.Drawing.Point(13, 23);
            this.Btn_Regwnd.Name = "Btn_Regwnd";
            this.Btn_Regwnd.Size = new System.Drawing.Size(93, 42);
            this.Btn_Regwnd.TabIndex = 0;
            this.Btn_Regwnd.Text = "Reg Wnd";
            this.Btn_Regwnd.Click += new System.EventHandler(this.Btn_Regwnd_Click);
            // 
            // Dlg3
            // 
            this.Dlg3.Controls.Add(this.Chk_Callblock);
            this.Dlg3.Controls.Add(this.Btn_CallBlockState);
            this.Dlg3.Controls.Add(this.Btn_SetCallBlock);
            this.Dlg3.Controls.Add(this.Btn_HangUpRas);
            this.Dlg3.Controls.Add(this.Btn_RasDialUp);
            this.Dlg3.Controls.Add(this.Btn_GetRasState);
            this.Dlg3.Location = new System.Drawing.Point(4, 25);
            this.Dlg3.Name = "Dlg3";
            this.Dlg3.Size = new System.Drawing.Size(220, 143);
            this.Dlg3.Text = "   3   ";
            // 
            // Chk_Callblock
            // 
            this.Chk_Callblock.Location = new System.Drawing.Point(9, 73);
            this.Chk_Callblock.Name = "Chk_Callblock";
            this.Chk_Callblock.Size = new System.Drawing.Size(62, 42);
            this.Chk_Callblock.TabIndex = 5;
            this.Chk_Callblock.Text = "CallBack";
            // 
            // Btn_CallBlockState
            // 
            this.Btn_CallBlockState.Location = new System.Drawing.Point(147, 73);
            this.Btn_CallBlockState.Name = "Btn_CallBlockState";
            this.Btn_CallBlockState.Size = new System.Drawing.Size(63, 42);
            this.Btn_CallBlockState.TabIndex = 4;
            this.Btn_CallBlockState.Text = "CallBlockState";
            this.Btn_CallBlockState.Click += new System.EventHandler(this.Btn_CallBlockState_Click);
            // 
            // Btn_SetCallBlock
            // 
            this.Btn_SetCallBlock.Location = new System.Drawing.Point(78, 73);
            this.Btn_SetCallBlock.Name = "Btn_SetCallBlock";
            this.Btn_SetCallBlock.Size = new System.Drawing.Size(63, 42);
            this.Btn_SetCallBlock.TabIndex = 3;
            this.Btn_SetCallBlock.Text = "SetCallBlock";
            this.Btn_SetCallBlock.Click += new System.EventHandler(this.Btn_SetCallBlock_Click);
            // 
            // Btn_HangUpRas
            // 
            this.Btn_HangUpRas.Location = new System.Drawing.Point(147, 25);
            this.Btn_HangUpRas.Name = "Btn_HangUpRas";
            this.Btn_HangUpRas.Size = new System.Drawing.Size(63, 42);
            this.Btn_HangUpRas.TabIndex = 2;
            this.Btn_HangUpRas.Text = "HangUpRas";
            this.Btn_HangUpRas.Click += new System.EventHandler(this.Btn_HangUpRas_Click);
            // 
            // Btn_RasDialUp
            // 
            this.Btn_RasDialUp.Location = new System.Drawing.Point(78, 25);
            this.Btn_RasDialUp.Name = "Btn_RasDialUp";
            this.Btn_RasDialUp.Size = new System.Drawing.Size(63, 42);
            this.Btn_RasDialUp.TabIndex = 1;
            this.Btn_RasDialUp.Text = "RasDialUp";
            this.Btn_RasDialUp.Click += new System.EventHandler(this.Btn_RasDialUp_Click);
            // 
            // Btn_GetRasState
            // 
            this.Btn_GetRasState.Location = new System.Drawing.Point(9, 25);
            this.Btn_GetRasState.Name = "Btn_GetRasState";
            this.Btn_GetRasState.Size = new System.Drawing.Size(63, 42);
            this.Btn_GetRasState.TabIndex = 0;
            this.Btn_GetRasState.Text = "GetRasState";
            this.Btn_GetRasState.Click += new System.EventHandler(this.Btn_GetRasState_Click);
            // 
            // Dlg4
            // 
            this.Dlg4.Controls.Add(this.Btn_ClosePowerNoti);
            this.Dlg4.Controls.Add(this.Btn_SetupPowerNoti);
            this.Dlg4.Controls.Add(this.Btn_GetDateTime);
            this.Dlg4.Controls.Add(this.Btn_CDMASerial);
            this.Dlg4.Location = new System.Drawing.Point(4, 25);
            this.Dlg4.Name = "Dlg4";
            this.Dlg4.Size = new System.Drawing.Size(220, 143);
            this.Dlg4.Text = "   4   ";
            // 
            // Btn_ClosePowerNoti
            // 
            this.Btn_ClosePowerNoti.Location = new System.Drawing.Point(112, 71);
            this.Btn_ClosePowerNoti.Name = "Btn_ClosePowerNoti";
            this.Btn_ClosePowerNoti.Size = new System.Drawing.Size(93, 42);
            this.Btn_ClosePowerNoti.TabIndex = 3;
            this.Btn_ClosePowerNoti.Text = "ClosePowerNoti";
            this.Btn_ClosePowerNoti.Click += new System.EventHandler(this.Btn_ClosePowerNoti_Click);
            // 
            // Btn_SetupPowerNoti
            // 
            this.Btn_SetupPowerNoti.ForeColor = System.Drawing.Color.Black;
            this.Btn_SetupPowerNoti.Location = new System.Drawing.Point(13, 71);
            this.Btn_SetupPowerNoti.Name = "Btn_SetupPowerNoti";
            this.Btn_SetupPowerNoti.Size = new System.Drawing.Size(93, 42);
            this.Btn_SetupPowerNoti.TabIndex = 2;
            this.Btn_SetupPowerNoti.Text = "SetupPowerNoti";
            this.Btn_SetupPowerNoti.Click += new System.EventHandler(this.Btn_SetupPowerNoti_Click);
            // 
            // Btn_GetDateTime
            // 
            this.Btn_GetDateTime.Location = new System.Drawing.Point(112, 23);
            this.Btn_GetDateTime.Name = "Btn_GetDateTime";
            this.Btn_GetDateTime.Size = new System.Drawing.Size(93, 42);
            this.Btn_GetDateTime.TabIndex = 1;
            this.Btn_GetDateTime.Text = "GetDateTime";
            this.Btn_GetDateTime.Click += new System.EventHandler(this.Btn_GetDateTime_Click);
            // 
            // Btn_CDMASerial
            // 
            this.Btn_CDMASerial.Location = new System.Drawing.Point(13, 23);
            this.Btn_CDMASerial.Name = "Btn_CDMASerial";
            this.Btn_CDMASerial.Size = new System.Drawing.Size(93, 42);
            this.Btn_CDMASerial.TabIndex = 0;
            this.Btn_CDMASerial.Text = "GetCDMASerial";
            this.Btn_CDMASerial.Click += new System.EventHandler(this.Btn_CDMASerial_Click);
            // 
            // Dlg5
            // 
            this.Dlg5.Controls.Add(this.Txt_SmsIndex);
            this.Dlg5.Controls.Add(this.Btn_SmsRemove);
            this.Dlg5.Controls.Add(this.Btn_SmsData);
            this.Dlg5.Controls.Add(this.Btn_SmsCnt);
            this.Dlg5.Location = new System.Drawing.Point(4, 25);
            this.Dlg5.Name = "Dlg5";
            this.Dlg5.Size = new System.Drawing.Size(220, 143);
            this.Dlg5.Text = "   5   ";
            // 
            // Btn_SmsCnt
            // 
            this.Btn_SmsCnt.Location = new System.Drawing.Point(13, 23);
            this.Btn_SmsCnt.Name = "Btn_SmsCnt";
            this.Btn_SmsCnt.Size = new System.Drawing.Size(93, 42);
            this.Btn_SmsCnt.TabIndex = 0;
            this.Btn_SmsCnt.Text = "GetSmsCnt";
            this.Btn_SmsCnt.Click += new System.EventHandler(this.Btn_SmsCnt_Click);
            // 
            // Btn_SmsData
            // 
            this.Btn_SmsData.Location = new System.Drawing.Point(112, 23);
            this.Btn_SmsData.Name = "Btn_SmsData";
            this.Btn_SmsData.Size = new System.Drawing.Size(93, 42);
            this.Btn_SmsData.TabIndex = 1;
            this.Btn_SmsData.Text = "GetSmsData";
            this.Btn_SmsData.Click += new System.EventHandler(this.Btn_SmsData_Click);
            // 
            // Btn_SmsRemove
            // 
            this.Btn_SmsRemove.Location = new System.Drawing.Point(112, 71);
            this.Btn_SmsRemove.Name = "Btn_SmsRemove";
            this.Btn_SmsRemove.Size = new System.Drawing.Size(93, 42);
            this.Btn_SmsRemove.TabIndex = 2;
            this.Btn_SmsRemove.Text = "SmsRemove";
            this.Btn_SmsRemove.Click += new System.EventHandler(this.Btn_SmsRemove_Click);
            // 
            // Txt_SmsIndex
            // 
            this.Txt_SmsIndex.Location = new System.Drawing.Point(13, 81);
            this.Txt_SmsIndex.Name = "Txt_SmsIndex";
            this.Txt_SmsIndex.Size = new System.Drawing.Size(93, 23);
            this.Txt_SmsIndex.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.ClientSize = new System.Drawing.Size(239, 269);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.Lst_Msg);
            this.Name = "Form1";
            this.Text = "ExtlCDMACmdTest";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Closing += new System.ComponentModel.CancelEventHandler(this.Form1_Closing);
            this.tabControl1.ResumeLayout(false);
            this.Dlg1.ResumeLayout(false);
            this.Dlg2.ResumeLayout(false);
            this.Dlg3.ResumeLayout(false);
            this.Dlg4.ResumeLayout(false);
            this.Dlg5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox Lst_Msg;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Dlg1;
        private System.Windows.Forms.TabPage Dlg2;
        private System.Windows.Forms.TabPage Dlg3;
        private System.Windows.Forms.TabPage Dlg4;
        private System.Windows.Forms.Button Btn_Call;
        private System.Windows.Forms.TextBox Txt_Sms;
        private System.Windows.Forms.TextBox Txt_Callback;
        private System.Windows.Forms.TextBox Txt_Phonenum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Btn_Sendsms;
        private System.Windows.Forms.Button Btn_Hangup;
        private System.Windows.Forms.Button Btn_Rssi;
        private System.Windows.Forms.Button Btn_RssiGrade;
        private System.Windows.Forms.Button Btn_Phonenum;
        private System.Windows.Forms.Button Btn_Regwnd;
        private System.Windows.Forms.Button Btn_GetRasState;
        private System.Windows.Forms.CheckBox Chk_Callblock;
        private System.Windows.Forms.Button Btn_CallBlockState;
        private System.Windows.Forms.Button Btn_SetCallBlock;
        private System.Windows.Forms.Button Btn_HangUpRas;
        private System.Windows.Forms.Button Btn_RasDialUp;
        private System.Windows.Forms.Button Btn_CDMASerial;
        private System.Windows.Forms.Button Btn_ClosePowerNoti;
        private System.Windows.Forms.Button Btn_SetupPowerNoti;
        private System.Windows.Forms.Button Btn_GetDateTime;
        private System.Windows.Forms.TabPage Dlg5;
        private System.Windows.Forms.TextBox Txt_SmsIndex;
        private System.Windows.Forms.Button Btn_SmsRemove;
        private System.Windows.Forms.Button Btn_SmsData;
        private System.Windows.Forms.Button Btn_SmsCnt;
    }
}

