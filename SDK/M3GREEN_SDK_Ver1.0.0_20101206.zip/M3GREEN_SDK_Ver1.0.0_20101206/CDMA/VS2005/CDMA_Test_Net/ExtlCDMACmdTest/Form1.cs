﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.WindowsCE.Forms;
using System.Runtime.InteropServices;

namespace ExtlCDMACmdTest
{
    public partial class Form1 : Form
    {
        public struct SYSTEMTIME
        {
            public ushort wYear;
            public ushort wMonth;
            public ushort wDayOfWeek;
            public ushort wDay;
            public ushort wHour;
            public ushort wMinute;
            public ushort wSecond;
            public ushort wMilliseconds;
        };

        public struct SMSDATA_st
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 18)] public string DateTime;

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 40)] public string PhoneNum;

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 30)] public string Name;

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 100)] public string Memo;

            //public ushort[18] DateTime;// = new ushort[18];
            //public ushort[40] PhoneNum;// = new ushort[40] ;
            //public ushort[30] Name;// = new ushort[30] ;
            //public ushort[100] Memo;// = new ushort[100];
            public ushort Mflag;
        };

        #region ExtlCDMACmd.dll Import

        [DllImport("ExtlCDMACmd.dll")]
        public static extern bool SetUseLib();

        [DllImport("ExtlCDMACmd.dll")]
        public static extern void SetUnUseLib();

        [DllImport("ExtlCDMACmd.dll")]
        public static extern int CallInitialize(IntPtr hNotiTaker, bool bGetCDMANoti);

        [DllImport("ExtlCDMACmd.dll")]
        public static extern void CallUnInitialize();

        [DllImport("ExtlCDMACmd.dll")]
        public static extern int CallMakePhoneCallW(string szPhoneNum);

        [DllImport("ExtlCDMACmd.dll")]
        public static extern int CallHangup();

        [DllImport("ExtlCDMACmd.dll")]
        public static extern int CallSendSMSW(string szPhoneNo, string szSMSm, string szCallBack, int nPriority);

        [DllImport("ExtlCDMACmd.dll")]
        public static extern int CallRegisterNotiReceiver(IntPtr hWnd, bool bRegister);

        [DllImport("ExtlCDMACmd.dll")]
        public static extern int CallGetNotiDataW(int nSlotNo, StringBuilder szParam, ref uint pParamLen, StringBuilder szDesc, ref uint pszDescLen);
        
        [DllImport("ExtlCDMACmd.dll")]
        public static extern int CallGetPhoneW(StringBuilder phonenum);

        [DllImport("ExtlCDMACmd.dll")]
        public static extern int CallGetRSSIGrade();

        [DllImport("ExtlCDMACmd.dll")]
        public static extern int CallGetRSSIValue(ref int pRssi);
        
        [DllImport("ExtlCDMACmd.dll")]
        public static extern uint CallDialUp(IntPtr hwnd, string szPhoneNum, string szUserName, string szPassword, string szEntryName);

        [DllImport("ExtlCDMACmd.dll")]
        public static extern uint CallGetRasState();

        [DllImport("ExtlCDMACmd.dll")]
        public static extern bool CallHangUpRas();

        [DllImport("ExtlCDMACmd.dll")]
        public static extern uint CallHandleRasEvent(int wParam, int lParam, StringBuilder NotiString);

        [DllImport("ExtlCDMACmd.dll")]
        public static extern bool CallSetCallBlock(bool bBlock);

        [DllImport("ExtlCDMACmd.dll")]
        public static extern bool CallRequestCallBlockStatus(IntPtr hWnd);

        [DllImport("ExtlCDMACmd.dll")]
        public static extern bool CallGetCDMASerial(StringBuilder szSerial, StringBuilder szErrStr);
        
        [DllImport("ExtlCDMACmd.dll")]
        public static extern bool CallGetDateTime(ref SYSTEMTIME pSt, StringBuilder szErrString);
        
        [DllImport("ExtlCDMACmd.dll")]
        public static extern bool CallSetupPowerNoti(IntPtr hwnd);
        
        [DllImport("ExtlCDMACmd.dll")]
        public static extern void CallClosePowerNoti();

        [DllImport("ExtlCDMACmd.dll")]
        public static extern int CallSMSCnt();

        [DllImport("ExtlCDMACmd.dll")]
        public static extern int CallSMSRead(int lm_iIndex, ref SMSDATA_st lm_pData);

        [DllImport("ExtlCDMACmd.dll")]
        public static extern int CallSMSRemove(int lm_iIndex);

        #endregion

        bool m_bRegistered = false;
        private CDMAMsgWnd MsgWnd;

        public Form1()
        {
            InitializeComponent();
            MsgWnd = new CDMAMsgWnd(this);
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        // CDMA 초기화 -->>
        private void Form1_Load(object sender, EventArgs e)
        {
            int nRet;

            SetUseLib();
            nRet = CallInitialize(this.Handle, false);
            if (nRet == 0)
            {
                Lst_AddMsg("Module Initialized.");
            }
            else
            {
                Lst_AddMsg("Can not initialize module (Error Code " + nRet.ToString() + ")");
            }
        }
        // CDMA 초기화 <<--

        // 전화 걸기 -->>
        private void Btn_Call_Click(object sender, EventArgs e)
        {
            int nRet;
            string PhoneNum;
            PhoneNum = Txt_Phonenum.Text.ToString();

            nRet = CallMakePhoneCallW(PhoneNum);
            if(nRet != 0)
	        {
                Lst_AddMsg("Error Occured" + "(Error Code : " + nRet.ToString() + ")");
	        }
        }
        // 전화 걸기 <<--

        // 전화 끊기 -->>
        private void Btn_Hangup_Click(object sender, EventArgs e)
        {
            int nRet;

            nRet = CallHangup();
            if(nRet != 0)
	        {
                Lst_AddMsg("Error Occured" + "(Error Code : " + nRet.ToString() + ")");
	        }
        }
        // 전화 끊기 <<--

        // SMS 송신 -->>
        private void Btn_Sendsms_Click(object sender, EventArgs e)
        {
            int nRet = 0;
	        //Check Data..
	        if(Txt_Phonenum.Text == "")
	        {
                Lst_AddMsg("Input phone number!!");
		        return;
	        }
        	
	        if(Txt_Sms.Text == "")
	        {
                Lst_AddMsg("Input SMS content!!");
		        return;
	        }
        	
	        if(Txt_Callback.Text == "")
	        {
                Lst_AddMsg("Input SMS callback number!!");
		        return;
	        }
        	
	        CallSendSMSW(Txt_Phonenum.Text,   // 받을 전화번호
		        Txt_Sms.Text,       // 메세지 --> 최장 80 Byte.
		       Txt_Callback.Text,  // Callback 번호
		        0);	   // 우선순위	
	        if(nRet != 0)
	        {
                Lst_AddMsg("Error Occured" + "(Error Code : " + Convert.ToString(nRet) + ")");
	        }
        }
        // SMS 송신 <<--

        // CDMA 메세지 수신여부 -->>
        private void Btn_Regwnd_Click(object sender, EventArgs e)
        {
            if(m_bRegistered)
	        {
		        //CallRegisterNotiReceiver(this.Handle, false);
                CallRegisterNotiReceiver(MsgWnd.Hwnd, false);
		        m_bRegistered = false;
                Btn_Regwnd.Text = "Reg Wnd";
                Lst_AddMsg("0x" + Convert.ToString(this.Handle.ToInt32(), 16) + " is Unregistered");
	        }
	        else
	        {
		        //CallRegisterNotiReceiver(this.Handle, true);
                CallRegisterNotiReceiver(MsgWnd.Hwnd, true);
		        m_bRegistered = true;
		        Btn_Regwnd.Text = "Unreg Wnd";

                Lst_AddMsg("0x" + Convert.ToString(this.Handle.ToInt32(), 16) + " is Registered");
	        }	

        }
        // CDMA 메세지 수신여부 <<--

        // CDMA 메세지 확인 -->>
        public void OnCDMANotiMsg(int wParam, int lParam)
        {
            int nRet;
            uint dwParamLen = 256;
            uint dwDescLen = 64;
            StringBuilder szParam = new StringBuilder(256);
            StringBuilder szDesc = new StringBuilder(64);

            nRet = CallGetNotiDataW(lParam, szParam, ref dwParamLen, szDesc, ref dwDescLen);
            if (nRet >= 0)
            {
                Lst_AddMsg("Code : " + nRet + ", Param - " + szParam + ", Desc- " + szDesc);
            }
            else
            {
                Lst_AddMsg("Fail to process - Error Code - " + nRet);
            }
        }
        // CDMA 메세지 확인 <<--

        // Phone Number -->>
        private void Btn_Phonenum_Click(object sender, EventArgs e)
        {
            StringBuilder PhoneNum = new StringBuilder(20);
            CallGetPhoneW(PhoneNum);

            Lst_AddMsg("Phone Number : " + PhoneNum);
        }
        // Phone Number <<--

        // CDMA 감도 확인 -->>
        private void Btn_RssiGrade_Click(object sender, EventArgs e)
        {
            int nRet;
            nRet = CallGetRSSIGrade();
            if(nRet >=0 ) 
	        {
                Lst_AddMsg("RSSI Grade : " + Convert.ToString(nRet));
	        }
	        else
	        {
                Lst_AddMsg("Get RSSI Grade Fail");
	        }

        }

        //======================================================================
        /*
                Value == -128       Grade = 0;
		-120 <= Value <  -110       Grade = 1;
		-110 <= Value <  -100       Grade = 2;
		-100 <= Value <   -97       Grade = 3;
		 -97 <= Value <   -92       Grade = 4;
		 -92 <= Value <   -87       Grade = 5;
		 -87 <= Value <   -82       Grade = 6;
		        Value >=  -82       Grade = 7;
        */
        //======================================================================
        private void Btn_Rssi_Click(object sender, EventArgs e)
        {
            int pRssi = 0;
            int nRet;
            nRet = CallGetRSSIValue(ref pRssi);
            if (nRet >= 0)
            {
                Lst_AddMsg("RSSI : " + Convert.ToString(pRssi));
            }
            else
            {
                Lst_AddMsg("Get RSSI Fail");
            }

        }
        // CDMA 감도 확인 <<--

        // Ras 연결 여부 확인 -->>
        private void Btn_GetRasState_Click(object sender, EventArgs e)
        {
            uint dwRet = 0;
        	
	        //현재 "인터넷"이 활성화 되어 있으면 TRUE
        	
	        dwRet = CallGetRasState();
            if (dwRet == (uint)8193)
	        {
                Lst_AddMsg("Ras Disconnected");
	        }
            else if (dwRet == (uint)8192)
	        {
                Lst_AddMsg("Ras Connected");
	        }
	        else
	        {
                Lst_AddMsg("Ras Status - " + dwRet);
	        }

        }
        // Ras 연결 여부 확인 <<--

        // Ras 연결 -->>
        private void Btn_RasDialUp_Click(object sender, EventArgs e)
        {
            uint dwDial = CallDialUp(MsgWnd.Hwnd, "1501", "sktelecom", "", "인터넷");
        	
	        if(dwDial != 0)
	        {
                Lst_AddMsg("DialUp Err- " + dwDial); //raserror.h 참고
	        }
	        else
	        {
                Lst_AddMsg("Ras Connecting");
	        }
        }
        // Ras 연결 <<--

        // Ras 연결 해제 -->>
        private void Btn_HangUpRas_Click(object sender, EventArgs e)
        {
            HangUpRas();
        }

        public bool HangUpRas()
        {
            bool bDial = CallHangUpRas();
	        
            if(bDial == true)
                Lst_AddMsg("Disconnected"); //raserror.h 참고
            return true;
        }
        // Ras 연결 해제 <<--

        // Ras Event 확인 -->>
        public bool OnRasEvent(int wParam, int lParam)
        {
            StringBuilder ErrorStr = new StringBuilder(128);
            CallHandleRasEvent(wParam, lParam, ErrorStr);
            Lst_AddMsg(ErrorStr);
            return true;

        }
        // Ras Event 확인 <<--

        // 발신통화 가능 및 제한 -->>
        private void Btn_SetCallBlock_Click(object sender, EventArgs e)
        {
            if(Chk_Callblock.Checked == true)
                CallSetCallBlock(true);
            else
                CallSetCallBlock(false);
            CallRequestCallBlockStatus(MsgWnd.Hwnd);
        }
        // 발신제한 상태 확인
        private void Btn_CallBlockState_Click(object sender, EventArgs e)
        {
            CallRequestCallBlockStatus(MsgWnd.Hwnd);
        }
        // 발신통화 가능 및 제한 <<--

        // CDMA Serial Number -->>
        private void Btn_CDMASerial_Click(object sender, EventArgs e)
        {
            StringBuilder CDMA_Serial = new StringBuilder(10);
            StringBuilder szErrStr = new StringBuilder(40);
            bool bRet = CallGetCDMASerial(CDMA_Serial, szErrStr);

            if(!bRet)
                Lst_AddMsg(szErrStr);
            else
                Lst_AddMsg("CDMA Serial : " + CDMA_Serial);
        }
        // CDMA Serial Number <<--

        // CDMA의 현재 시간 -->>
        private void Btn_GetDateTime_Click(object sender, EventArgs e)
        {
	        SYSTEMTIME pSt = new SYSTEMTIME();
	        StringBuilder szErrString = new StringBuilder(40);

            bool bRet = CallGetDateTime(ref pSt, szErrString);
	        if(!bRet)
	        {
                Lst_AddMsg(szErrString);
	        }
	        else 
	        {
                Lst_AddMsg(pSt.wYear + "년 " + pSt.wMonth + "월 " + pSt.wDay + "일 " + pSt.wHour + "시 " + pSt.wMinute + "분 ");
	        }
        }
        // CDMA의 현재 시간 <<--

        // Power Status를 받을 것인지 설정 -->>
        private void Btn_SetupPowerNoti_Click(object sender, EventArgs e)
        {
            bool nRet = CallSetupPowerNoti(MsgWnd.Hwnd);
            Lst_AddMsg("Noti 수신");
        }

        private void Btn_ClosePowerNoti_Click(object sender, EventArgs e)
        {	
	        CallClosePowerNoti();
            Lst_AddMsg("Noti 미수신");
        }
        // Power Status를 받을 것인지 설정 <<--

        // ListBox에 메세지 쓰기 -->>
        public void Lst_AddMsg(string szaddmsg)
        {
            Lst_Msg.SelectedIndex = Lst_Msg.Items.Count - 1;
            Lst_Msg.Items.Add(szaddmsg);
            Lst_Msg.SelectedIndex = Lst_Msg.Items.Count - 1;
        }

        public void Lst_AddMsg(StringBuilder szaddmsg)
        {
            Lst_Msg.SelectedIndex = Lst_Msg.Items.Count - 1;
            Lst_Msg.Items.Add(szaddmsg);
            Lst_Msg.SelectedIndex = Lst_Msg.Items.Count - 1;
        }
        // ListBox에 메세지 쓰기 <<--

        // 프로그램 종료시 -->>
        private void Form1_Closing(object sender, CancelEventArgs e)
        {
            CallUnInitialize();
            SetUnUseLib();
        }

        private void Btn_SmsCnt_Click(object sender, EventArgs e)
        {
            int nRet;

            nRet = CallSMSCnt();
            Lst_AddMsg(nRet.ToString());

        }

        private void Btn_SmsData_Click(object sender, EventArgs e)
        {
            SMSDATA_st lm_pData = new SMSDATA_st();

            CallSMSRead(Convert.ToInt32(Txt_SmsIndex.Text), ref lm_pData);
            Lst_AddMsg(lm_pData.Mflag + " : " + lm_pData.DateTime + " : " + lm_pData.Memo + " : " + lm_pData.PhoneNum); 
        }

        private void Btn_SmsRemove_Click(object sender, EventArgs e)
        {
            int nRet;
            nRet = CallSMSRemove(Convert.ToInt32(Txt_SmsIndex.Text));
            if(nRet == 0)
            {
                Lst_AddMsg("삭제 실패");
            }
            else
            {
                Lst_AddMsg(Txt_SmsIndex.Text + "번째 문자 삭제되었었습니다");
            }
        }
        // 프로그램 종료시 <<--
    }
    public partial class CDMAMsgWnd : MessageWindow
    {
        private Form1 container;

        public const int WM_CDMA_NOTI = 0x8000 + 31;
        public const int WM_RASDIALEVENT = 0xCCCD;
        public const int WM_POWERRESUME = 0x8000 + 1000;
        public const int WM_POWERSTATECHANGE = 0x8000 + 1001;
        public const int AC_LINE_OFFLINE = 0x00;
        public const int AC_LINE_ONLINE = 0x01;
        public const int WM_NETRELEASE = 0x0400 + 25;
        public const int WM_BLOCKCALL_REPLY = 0x0400 + 51;

        public CDMAMsgWnd()
        {

        }

        public CDMAMsgWnd(Form1 container)
        {
            this.container = container;
        }

        protected override void WndProc(ref Message msg)
        {
            switch (msg.Msg)
            {
                    //Ras 이벤트 발생
                case WM_RASDIALEVENT:
                    this.container.OnRasEvent((int)msg.WParam, (int)msg.LParam);
                    break;

                    //CDMA 메세지
                case WM_CDMA_NOTI:
                    this.container.OnCDMANotiMsg((int)msg.WParam, (int)msg.LParam);
                    break;

                    //Power Status에 관한 메세지
	            case WM_POWERRESUME:
                    this.container.Lst_AddMsg("Wake Up");
                    break;
	            case WM_POWERSTATECHANGE:
                    switch ((int)msg.WParam)
                    {
		                case AC_LINE_OFFLINE:
                            this.container.Lst_AddMsg("DC Power");
                            break;
		                case AC_LINE_ONLINE:
                            this.container.Lst_AddMsg("AC Power");
                            break;
                    }
                    break;

                    // Ras 연결 해제에 관한 메세지
	            case WM_NETRELEASE:
                    this.container.Lst_AddMsg("Disconnected");
                    this.container.HangUpRas();
                    break;

                    // CallBlock에 관한 응답
                case WM_BLOCKCALL_REPLY:
                    if((int)msg.WParam == 0)
                        this.container.Lst_AddMsg("발신통화 가능");
	                else
                        this.container.Lst_AddMsg("발신통화 잠김");
                    break;
            }
            base.WndProc(ref msg);
        }

    }

}