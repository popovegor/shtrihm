//Definition of Data Type and constant
#ifndef _GLOBAL_TYPE_H_
#define _GLOBAL_TYPE_H_

#define	MAX_SMS_DATA				250

#define WM_CDMA_NOTI				WM_APP + 31
// WPARAM : 0
// LPARAM : Slot Number of Memory Map

#define WM_CDMA_CMD					WM_APP + 32		//�ܺ� ���α׷����� ������ ����
// WPARAM : Window Handle of Sender
// LPARAM : Slot Number of Memory Map

#define WM_CDMA_REPLY				WM_APP + 33		//�ܺ� ���α׷����� ������ �������� ������ ��
// WPARAM : Result of Command
// LPARAM : Slot Number of Memory Map

#define WM_CDMA_REG_NOTIHANDLE		WM_APP + 34		//CDMA�� ���� ���� Noti�� ���۹ޱ� ���� �����츦 ��� / ����
// WPARAM : Windows Handle of Receiver
// LPARAM : BOOL(Registration or Unregistration)


#define WM_CDMA_CMD2				WM_APP + 40     //�ܺ�  ���α׷� ���� 
//Command Type
typedef enum _tagCmdType{
	CMD_GENERAL,
	CMD_CALL,
	CMD_SMS,
	CMD_DATA,
} CMDTYPE;

//Flag in return value (CReadData.m_Flags)
typedef enum _tagReplyFlag{
	FLAG_NONE  = 1,
	FLAG_REPLY = 2,
	FLAG_NOTIFY= 4,
	FLAG_ACK   = 8,
	FLAG_NAK   = 16,
	FLAG_QUERY = 32,
	FLAG_SET   = 64
} REPLYFLAG;

#define	NOTI_MUTEXNAME			_T("NOTIFY_MUTEX")
#define MEMMAP_TO_CDMA			_T("MEMMAP_TO_CDMA")
#define MEMMAP_FROM_CDMA		_T("MEMMAP_FROM_CDMA")

#define MEMMAP_SIZE				(sizeof(CReadData) * 4)

//------------------------------------------------------------------------------------------------------------
// Error Code definition
#define ERROR_FAIL				-1
#define ERROR_NONE				0
#define ERROR_NAK				1
#define ERROR_CDMA_NORESPONSE	2

#define ERROR_OPEN_PORT			10
#define ERROR_BUFFER_NOT_ENOUGH	20
#define ERROR_OUT_OF_RANGE		21
#define ERROR_PORT_CLOSED		22
#define ERROR_FAIL_HANDLE_NOTI  23
#define	ERROR_FILE_OPEN_FAIL	24
#define ERROR_CMD_BLOCKED		25
#define ERROR_BATT_OFF			30

//------------------------------------------
#define ERROR_NO_HOST					40
#define ERROR_MODULE_NOT_INITIALIZED	41
#define ERROR_NOT_REPLY					42
#define ERROR_FAIL_READ_MEMMAP			43
#define ERROR_CDMA_OFF					44

#define EXTL_CMD_REPLY_EVENT			TEXT("CDMA\\CMDReplyEvent")

#define ERROR_TIME_OUT			100

#define MAX_CMD_LENGTH			50
#define MAX_CMD_PARAM			256

#define ND						0				//Not Defined

#define WRITE_TIMEOUT			3000			//TimeOut of Port Writing

//-----------------------------------------------------
#define INVALID_NOTIFY			0xFFFFFFFF
#define CDMA_READY				0  	
#define CDMA_NOSERVICE			1  	
#define CALL_DISP				4  	
#define CDMA_LOCK				5  	
#define CDMA_PREV				14 	
#define RSSI_NOTI				15 	
#define EARMIC_IN				34 	
#define EARMIC_OUT				35 	
#define VCALL_CNID				2  	
#define VCALL_CNAP				3  	
#define VCALL_CONNECTING		17 	
#define DATA_RI				    23 	
#define VCALL_RI				24 	
#define VCALL_CDNIP			    25 	
#define VCALL_DISCONNECTED 	    51 	
#define VCALL_CONNECTED    	    52    
#define VCALL_RINGING			53   
#define SMS_ACK				    6  	
#define SMS_NAK				    7  	
#define SMS_NEW				    8  	
#define DATA_CONNECTED			9  	
#define DATA_DISCONNECTED  	    10 	
#define DATA_ENTER_DORMANT 	    11 	
#define DATA_EXIT_DORMENT  	    12 	
#define BATT_CHANGED			13   

#define DIM(Array)				(sizeof(Array) / sizeof(Array[0]))
#define MAX_DESC_LENGTH			64

#define SMS_PRIORITY_NORMAL		0
#define SMS_PRIORITY_FAST		1
#define SMS_PRIORITY_URGENT		2

typedef struct
{
	char	szNoti[20];
	UINT	uCode;
	char	szDesc[MAX_DESC_LENGTH];
}NOTIDATA, *LPNOTIDATA;


//SMS ���ſ� ����ü ----------------
typedef struct 
{
	char	szDatetime[15];
	char  	szCallNumber[15];
	char  	szCallBack[20];  //20060421 kbj 12 --> 20
	char  	szTI[5];
	int     nEncode;
	BOOL	bReply;
	int		nPriority;
	char	szData[MAX_SMS_DATA];
}SMSRECVSTRUCT, *LPSMSRECVSTRUCT;

#endif  //_GLOBAL_TYPE_H_