// MemoryMap.h: interface for the CMemoryMap class.
//
// This class is for the inter process communication.
// The conceptual block(slot) is used to write / read data.
//
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MEMORYMAP_H__5F4B8E7E_595D_4930_9AF4_A5CBEA3CF6DD__INCLUDED_)
#define AFX_MEMORYMAP_H__5F4B8E7E_595D_4930_9AF4_A5CBEA3CF6DD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
class CReadData;
class AFX_EXT_CLASS CMemoryMap  
{
public:
	CMemoryMap(TCHAR* szObjName, int nMaxSharedMem, DWORD dwDesiredAccess);
	
	char* GetBasePtr() const;
	BOOL  Write(char* ptrStart, char* pWriteBuf, DWORD dwSize);
	BOOL  Write(UINT uSlotNo, CReadData* pWd);

	BOOL  Read(char* ptrStart, char* pWriteBuf, DWORD dwSize);
	BOOL  Read(UINT uSlotNo, CReadData* pRd);
	int	  FindAvailableSlot();
	BOOL  SetSlotSize(UINT uSize);
	UINT  GetSlotSize();
	virtual ~CMemoryMap();

protected:
	HANDLE	m_hMap;
	char*	m_pBase;
	UINT	m_uSlotSize;
	UINT	m_uSlotCnt;
	UINT	m_uSharedMem;
	DWORD	m_dwfProtected;
};

#endif // !defined(AFX_MEMORYMAP_H__5F4B8E7E_595D_4930_9AF4_A5CBEA3CF6DD__INCLUDED_)
