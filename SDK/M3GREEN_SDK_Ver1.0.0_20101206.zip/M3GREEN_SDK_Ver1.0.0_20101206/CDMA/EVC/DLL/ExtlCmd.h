#ifndef _EXTL_CMD_H_
#define _EXTL_CMD_H_

#include "global_type.h"
#include "MemoryMap.h"
#include "ReadData.h"

typedef struct 
{
	CEOID	ceoID;
	short	index;				// ����
	short	FirstNum;			// ��ǥ��ȣ
	TCHAR	szName[50];			// �̸�
	TCHAR	szMobileTel[20];	// �ڵ���
	TCHAR	szHomeTel[20];		// ����ȭ
	TCHAR	szOfficeTel[20];	// �繫�� ��ȭ
//	TCHAR	szBellPath[MAX_PATH];		// ���Ҹ�
	short	Group;				// Group
}PBITEM, *LPPBITEM;

//Data Type definition  ----------------------------------------------------------------
typedef struct SMSDATA_st  
{
	TCHAR	DateTime[18];		// SMS ���� �Ͻ�
	TCHAR	PhoneNum[40];		// �߽Ź�ȣ
	TCHAR	Name[30];			// ������
	TCHAR	Memo[100];			// Data
	TCHAR	Mflag;				// ������
} SMSDATA_ST;



class AFX_EXT_CLASS CExtlCmd
{
public:
	CExtlCmd();
	~CExtlCmd();

	INT  GetRSSIValue(INT* pRssi);
	INT  MakePhoneCall(char* szPhoneNum);
	INT  MakePhoneCall(WCHAR* szPhoneNum);
	INT  Hangup();
	INT  SendSMS(WCHAR* szPhoneNo, WCHAR* szSms, WCHAR* szCallBack, INT nPriority);
	INT	 SendSMS(char* szPhoneNo, char* szSms, char* szCallBack, INT nPriority);
	INT  Process_CDMA_Reply(INT nErrorCode, INT nSlot, CReadData* pRd);
	INT  Initialize(HWND hNotiTaker, BOOL bGetCDMANoti = FALSE);
	INT  GetRSSIGrade();
	INT	 GetPhoneNumber(TCHAR* szPhoneNo);
	INT	 GetPhoneNumber(char* szPhoneNo);
	void UnInitialize();
	INT  RegisterNotiReceiver(HWND hWnd, BOOL bRegister);
	DWORD GetCmdTimeout() {return m_WaitTimeout;}
	INT	 ReadNotiData(WPARAM wParam, LPARAM lParam, CReadData* pRd);
	INT  GetNotiData(int nSlotNo, char* szParam, PDWORD pParamLen, char* szDesc, PDWORD pszDescLen);
	void SetCmdTimeOut(DWORD dwTimeout) { m_WaitTimeout = dwTimeout;}
	DWORD DialUp(HWND hwnd, TCHAR* szPhoneNum, TCHAR* szUserName, TCHAR* szPassword, TCHAR* szEntryName); // = _T("���ͳ�"));
	DWORD DialUp(HWND hwnd, char* szPhoneNum, char* szUserName, char* szPassword, char* szEntryName);
	DWORD HandleRasEvent(WPARAM wParam, LPARAM lParam, TCHAR* NotiString);
	DWORD HandleRasEvent(WPARAM wParam, LPARAM lParam, char* NotiString);
	DWORD GetRasState();
	BOOL HangUpRas();
	BOOL SetCallBlock(BOOL bBlock);
	BOOL SetSmsPopupBlock(BOOL bBlock);
	BOOL RequestCallBlockStatus(HWND hWnd);
	int  SMSCnt();
	int  SMSRead(int lm_iIndex, void* lm_pData);
	int  SMSRemove(int lm_iIndex);
	BOOL SMSSetMarker(TCHAR* szMarker);
	BOOL SMSGetMarker(TCHAR* szMarker);
	BOOL SMSSetReceiveWindow(TCHAR* szWindowTitle);
	BOOL SMSSetReceiveHwnd(HWND hSender);
	BOOL SMSGetReceiveWindow(TCHAR* szWindowTitle);
	BOOL GetCDMASerial(TCHAR* szSerial, TCHAR* szErrStr);
	BOOL GetCDMASerial(char* szSerial, char* szErrString);
	BOOL GetDateTime(SYSTEMTIME* pSt, TCHAR* szErrString);
	BOOL GetDateTime(SYSTEMTIME* pSt, char* szErrString);
	BOOL SetupPowerNoti(HWND hwnd);
	void ClosePowerNoti();

	//20060830 kbj -------------------------------------------------------
	INT	  ReadSMS(int nNotiCode, char* szDatetime, char* szCallback, char* szTI, char* szData);
	INT	  ReadSMS(int nNotiCode, LPSMSRECVSTRUCT pSmsFormat);

	//20070613------------------------------------------------
	INT	  SetVibration(BOOL bVibration);
	char	szDatetime[15];
	char  	szCallNumber[15];
	char  	szCallBack[20];  //20060421 kbj 12 --> 20
	char  	szTI[5];
	int     nEncode;
	BOOL	bReply;
	int		nPriority;
	char	szData[MAX_SMS_DATA];

protected:
	
	INT ExecCmd(CReadData* pRd);	
	BOOL GetResultNReplySlot(DWORD* pdwRet);
	INT StringToHexaString(TCHAR* szSource, char* szHexaString);
	BOOL CopyCommModule();

	//20060830  added by kbj
	void HexaStringToString(char* szHexaString, char* szString);
	INT ParseSMS(char* szData, LPSMSRECVSTRUCT pSmsFormat);

protected:
	CMemoryMap*		m_pInMap;
	CMemoryMap*		m_pOutMap;
	HWND			m_hNotiTaker;
	BOOL			m_bInitilized;
	DWORD			m_WaitTimeout;
	BOOL			m_bGetCDMANoti;
	HANDLE			m_hReplyEvent;
	HMODULE			m_hCommModule;
};

extern "C" __declspec(dllexport) UINT CallSendSMSU(UCHAR *szPhoneNo, UCHAR *szSMSm, UCHAR *szCallBack, INT nPriority);
extern "C" __declspec(dllexport) UINT CallSendSMSW(WCHAR *szPhoneNo, WCHAR *szSMSm, WCHAR *szCallBack, INT nPriority);
extern "C" __declspec(dllexport) INT CallReadSMS(int nNotiCode, char* szDatetime, char* szCallback, char* szTI, char* szData);
extern "C" __declspec(dllexport) INT CallInitialize(HWND hNotiTaker, BOOL bGetCDMANoti);
extern "C" __declspec(dllexport) void CallUnInitialize();
extern "C" __declspec(dllexport) BOOL SetUseLib();
extern "C" __declspec(dllexport) void SetUnUseLib();
extern "C" __declspec(dllexport) INT CallRegisterNotiReceiver(HWND hWnd, BOOL bRegister);
extern "C" __declspec(dllexport) INT CallGetNotiData(int nSlotNo, char* szParam, PDWORD pParamLen, char* szDesc, PDWORD pszDescLen);
extern "C" __declspec(dllexport) INT CallGetNotiDataW(int nSlotNo, WCHAR* szParam, PDWORD pParamLen, WCHAR* szDesc, PDWORD pszDescLen);
extern "C" __declspec(dllexport) INT CallGetPhone(char *phonenum);
extern "C" __declspec(dllexport) INT CallGetPhoneW(WCHAR *phonenum);
extern "C" __declspec(dllexport) INT CallGetRSSIGrade();
extern "C" __declspec(dllexport) INT CallGetRSSIValue(INT* pRssi);
extern "C" __declspec(dllexport) INT CallMakePhoneCallC(char* szPhoneNum);
extern "C" __declspec(dllexport) INT CallMakePhoneCallW(WCHAR* szPhoneNum);
extern "C" __declspec(dllexport) INT CallHangup();
extern "C" __declspec(dllexport) DWORD CallDialUp(HWND hwnd, TCHAR* szPhoneNum, TCHAR* szUserName, TCHAR* szPassword, TCHAR* szEntryName);
extern "C" __declspec(dllexport) DWORD CallHandleRasEvent(WPARAM wParam, LPARAM lParam, TCHAR* NotiString);
extern "C" __declspec(dllexport) DWORD CallGetRasState();
extern "C" __declspec(dllexport) BOOL CallHangUpRas();
extern "C" __declspec(dllexport) BOOL CallSetCallBlock(BOOL bBlock);
extern "C" __declspec(dllexport) BOOL CallSetSmsPopupBlock(BOOL bBlock);
extern "C" __declspec(dllexport) BOOL CallRequestCallBlockStatus(HWND hWnd);
extern "C" __declspec(dllexport) BOOL CallGetCDMASerial(TCHAR* szSerial, TCHAR* szErrStr);
extern "C" __declspec(dllexport) BOOL CallGetDateTime(SYSTEMTIME* pSt, TCHAR* szErrString);
extern "C" __declspec(dllexport) BOOL CallSetupPowerNoti(HWND hwnd);
extern "C" __declspec(dllexport) void CallClosePowerNoti();
extern "C" __declspec(dllexport) int CallSMSCnt();
extern "C" __declspec(dllexport) int CallSMSRead(int lm_iIndex, void* lm_pData);
extern "C" __declspec(dllexport) int CallSMSRemove(int lm_iIndex);
extern "C" __declspec(dllexport) int CallSMSReadDateTime(int lm_iIndex, TCHAR* pDateTime);
extern "C" __declspec(dllexport) int CallSMSReadPhoneNum(int lm_iIndex, TCHAR* pPhoneNum);
extern "C" __declspec(dllexport) int CallSMSReadName(int lm_iIndex, TCHAR* pName);
extern "C" __declspec(dllexport) int CallSMSReadMemo(int lm_iIndex, TCHAR* pMemo);
#endif