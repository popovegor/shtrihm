#if !defined(AFX_READDATA_H__D35BDC29_77E0_4A85_AB1E_5832F14652CC__INCLUDED_)
#define AFX_READDATA_H__D35BDC29_77E0_4A85_AB1E_5832F14652CC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ReadData.h : header file
//
//#include "global.h"

/////////////////////////////////////////////////////////////////////////////
// CReadData command target

//class MCMODULE_CLASS CReadData : public CObject
class AFX_EXT_CLASS CReadData : public CObject
{
	DECLARE_DYNCREATE(CReadData)

// Operations
public:
	REPLYFLAG m_Flag;
	CMDTYPE   m_CmdType;				// for future use
	char	  m_szCmd[MAX_CMD_LENGTH];
	char	  m_szCmdParam[MAX_CMD_PARAM];
	UINT	  m_uParamLength;
	BOOL	  m_bLocked;
	DWORD	  m_dwTimeStamp;

	void	  ClearData();
	void	  Duplicate(CReadData* pSrc);
	void	  MakeCommand(/*out*/ char* szCommand,  /*out*/int* nComSize);

	CReadData();           // protected constructor used by dynamic creation
	~CReadData();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReadData)
	//}}AFX_VIRTUAL

// Implementation
protected:
	
	// Generated message map functions
	//{{AFX_MSG(CReadData)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

//	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_READDATA_H__D35BDC29_77E0_4A85_AB1E_5832F14652CC__INCLUDED_)
