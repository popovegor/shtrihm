#if !defined(AFX_TABDLG1_H__8F0EC238_AEE4_4424_9E9E_CA0B8405C0B6__INCLUDED_)
#define AFX_TABDLG1_H__8F0EC238_AEE4_4424_9E9E_CA0B8405C0B6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TabDlg1.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTabDlg1 dialog

class CTabDlg1 : public CDialog
{
// Construction
public:
	CTabDlg1(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTabDlg1)
	enum { IDD = IDD_DIALOG1 };
	CString	m_szCallBack;
	CString	m_szPhoneNo;
	CString	m_szSms;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTabDlg1)
	public:
	virtual BOOL Create(CWnd* pParentWnd);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HWND m_hwndParent;

	// Generated message map functions
	//{{AFX_MSG(CTabDlg1)
	afx_msg void OnBtnCall();
	afx_msg void OnBtnCallend();
	afx_msg void OnBtnSendSms();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TABDLG1_H__8F0EC238_AEE4_4424_9E9E_CA0B8405C0B6__INCLUDED_)
