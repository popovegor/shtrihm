// TabDlg4.cpp : implementation file
//

#include "stdafx.h"
#include "ExtlCmdTest.h"
#include "TabDlg4.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTabDlg4 dialog


CTabDlg4::CTabDlg4(CWnd* pParent /*=NULL*/)
	: CDialog(CTabDlg4::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTabDlg4)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CTabDlg4::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTabDlg4)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTabDlg4, CDialog)
	//{{AFX_MSG_MAP(CTabDlg4)
	ON_BN_CLICKED(IDC_BTN_CDMA_SERIAL, OnBtnCdmaSerial)
	ON_BN_CLICKED(IDC_BTN_DATETIME, OnBtnDatetime)
	ON_BN_CLICKED(IDC_BTN_SETUP_POWERNOTI, OnBtnSetupPowernoti)
	ON_BN_CLICKED(IDC_BTN_CLOSE_POWERNOTI, OnBtnClosePowernoti)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTabDlg4 message handlers

BOOL CTabDlg4::Create(CWnd* pParentWnd) 
{
	m_hwndParent = pParentWnd->m_hWnd;
	
	return CDialog::Create(IDD, pParentWnd);
}


void CTabDlg4::OnBtnCdmaSerial() 
{
	CString szMsg;
	TCHAR szSerial[64];
	TCHAR szErrString[128];
	BOOL nRet = g_pCdmaCmd->GetCDMASerial(szSerial, szErrString);
	if(!nRet)
	{
		szMsg =  szErrString;
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
	}
	else 
	{
		szMsg.Format(_T("CDMA Serial : %s"), szSerial);
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
	}	
}

void CTabDlg4::OnBtnDatetime() 
{
	CString szMsg;
	SYSTEMTIME pSt;
	TCHAR* szErrString;
	
	BOOL nRet = g_pCdmaCmd->GetDateTime(&pSt, szErrString);
	if(!nRet)
	{
		szMsg =  szErrString;
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
	}
	else 
	{
		szMsg.Format(L"%d�� %d�� %d�� %d�� %d�� ",pSt.wYear,pSt.wMonth,pSt.wDay,pSt.wHour,pSt.wMinute);
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
	}
}

void CTabDlg4::OnBtnSetupPowernoti() 
{
	CString szMsg;
	
	BOOL	nRet = g_pCdmaCmd->SetupPowerNoti(m_hwndParent);
	szMsg = _T("Noti ����");
	::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);	
}

void CTabDlg4::OnBtnClosePowernoti() 
{
	CString szMsg;
	
	g_pCdmaCmd->ClosePowerNoti();
	szMsg = _T("Noti �̼���");
	::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);	
}
