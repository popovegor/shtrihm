// ExtlCmdTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ExtlCmdTest.h"
#include "ExtlCmdTestDlg.h"

#include <ras.h>

//#include "ReadData.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CCdmaCmd * g_pCdmaCmd = NULL;

/////////////////////////////////////////////////////////////////////////////
// CExtlCmdTestDlg dialog

CExtlCmdTestDlg::CExtlCmdTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CExtlCmdTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CExtlCmdTestDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_pTabDlg1 = NULL;
	m_pTabDlg2 = NULL;
	m_pTabDlg3 = NULL;
	m_pTabDlg4 = NULL;
	m_pTabDlg5 = NULL;
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CExtlCmdTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CExtlCmdTestDlg)
	DDX_Control(pDX, IDC_LT_LOG, m_listLog);
	DDX_Control(pDX, IDC_TAB1, m_TabCtrl);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CExtlCmdTestDlg, CDialog)
	//{{AFX_MSG_MAP(CExtlCmdTestDlg)
	//lms add-- <<--
	//ON_BN_CLICKED(IDC_BTN_RSSI, OnBtnRssi)
	ON_WM_CLOSE()
	//lms add-- <<--
	//ON_BN_CLICKED(IDC_BTN_CALLEND, OnBtnCallend)
	//ON_BN_CLICKED(IDC_BTN_CALL, OnBtnCall)
	//ON_BN_CLICKED(IDC_BTN_REG_HWND, OnBtnRegHwnd)
	//ON_BN_CLICKED(IDC_BTN_RSSI_GRADE, OnBtnRssiGrade)
	//ON_BN_CLICKED(IDC_BTN_SEND_SMS, OnBtnSendSms)
	//ON_BN_CLICKED(IDC_BTN_PHONENO, OnBtnPhoneno)
	//ON_BN_CLICKED(IDC_BUT_RSSI2, OnButRssi2)

	//lms add-- <<--
	//ON_BN_CLICKED(IDC_BUT_VIB, OnButVib)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_CDMA_NOTI, OnCDMANotiMsg)
	ON_MESSAGE(WM_LOG, LOG)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExtlCmdTestDlg message handlers

BOOL CExtlCmdTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	MoveWindow(0, -1, 240, 300);
//	CenterWindow(GetDesktopWindow());	// center to the hpc screen

	// TODO: Add extra initialization here
	m_CdmaCmd.Create(this);
	g_pCdmaCmd = &m_CdmaCmd;

	CString szMsg;

	int nRet = g_pCdmaCmd->Initialize();

	if(nRet == ERROR_SUCCESS)
	{
		szMsg.Format(_T("Module Initialized."));
		LOG((WPARAM)szMsg.GetBuffer(0), NULL);
	}
	else
	{
		szMsg.Format(_T("Can not initialize module (Error Code %d)"), nRet);
		LOG((WPARAM)szMsg.GetBuffer(0), NULL);
	}	

	CreateControls();

	m_bRegistered = FALSE;

//	m_szPhoneNo = _T("131");
//	UpdateData(FALSE);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CExtlCmdTestDlg::CreateControls()
{
	TCITEM   item;
	item.mask  = TCIF_TEXT;
	item.pszText = _T("  1  ");
	m_TabCtrl.InsertItem(0, &item);
	item.pszText = _T("  2  ");
	m_TabCtrl.InsertItem(1, &item);
	item.pszText = _T("  3  ");
	m_TabCtrl.InsertItem(2, &item);
	item.pszText = _T("  4  ");
	m_TabCtrl.InsertItem(3, &item);
	item.pszText = _T("  5  ");
	m_TabCtrl.InsertItem(4, &item);

	if(!m_pTabDlg1)
	{
		m_pTabDlg1 = new CTabDlg1();
		m_pTabDlg1->Create(this);
	}
	m_pTabDlg1->SetWindowPos(&CWnd::wndTop, 
							10, 
							140, 
							220, 
							100,
							SWP_SHOWWINDOW);
	m_pTabDlg1->ShowWindow(SW_SHOW);
	
	if(!m_pTabDlg2)
	{
		m_pTabDlg2 = new CTabDlg2();
		m_pTabDlg2->Create(this);
	}
	m_pTabDlg2->SetWindowPos(m_pTabDlg1, 
							10, 
							140, 
							220, 
							100,
							SWP_SHOWWINDOW);						
	m_pTabDlg2->ShowWindow(SW_HIDE);
	
	if(!m_pTabDlg3)
	{
		m_pTabDlg3 = new CTabDlg3();
		m_pTabDlg3->Create(this);
	}
	m_pTabDlg3->SetWindowPos(m_pTabDlg1, 
							10, 
							140, 
							220, 
							100,
							SWP_SHOWWINDOW);
	m_pTabDlg3->ShowWindow(SW_HIDE);
	
	if(!m_pTabDlg4)
	{
		m_pTabDlg4 = new CTabDlg4();
		m_pTabDlg4->Create(this);
	}
	m_pTabDlg4->SetWindowPos(m_pTabDlg1, 
							10, 
							130, 
							220, 
							135,
							SWP_SHOWWINDOW);						
	m_pTabDlg4->ShowWindow(SW_HIDE);

	if(!m_pTabDlg5)
	{
		m_pTabDlg5 = new CTabDlgSms();
		m_pTabDlg5->Create(this);
	}
	m_pTabDlg5->SetWindowPos(m_pTabDlg1, 
							10, 
							130, 
							220, 
							135,
							SWP_SHOWWINDOW);						
	m_pTabDlg5->ShowWindow(SW_HIDE);
	
}

void CExtlCmdTestDlg::OnShowTabPage(BYTE nIndex)
{
	//lms add-- 070530 -->> ����� ��ũ�� �� ��������...
	switch(nIndex)
	{
	case 1:
	{
		m_pTabDlg5->ShowWindow(SW_HIDE);
		m_pTabDlg4->ShowWindow(SW_HIDE);
		m_pTabDlg3->ShowWindow(SW_HIDE);
		m_pTabDlg2->ShowWindow(SW_HIDE);
	
		m_pTabDlg1->ShowWindow(SW_SHOW);
	}
	break;
	  
	case 2:
	{
		m_pTabDlg5->ShowWindow(SW_HIDE);
		m_pTabDlg4->ShowWindow(SW_HIDE);
		m_pTabDlg3->ShowWindow(SW_HIDE);
		m_pTabDlg1->ShowWindow(SW_HIDE);
		
		m_pTabDlg2->ShowWindow(SW_SHOW);
	}
	break;
		  
	case 3:
	{
		m_pTabDlg5->ShowWindow(SW_HIDE);
		m_pTabDlg4->ShowWindow(SW_HIDE);
		m_pTabDlg2->ShowWindow(SW_HIDE);
		m_pTabDlg1->ShowWindow(SW_HIDE);
	
		m_pTabDlg3->ShowWindow(SW_SHOW);
	}
	break;
			  
	case 4:
	{
		m_pTabDlg5->ShowWindow(SW_HIDE);
		m_pTabDlg3->ShowWindow(SW_HIDE);
		m_pTabDlg2->ShowWindow(SW_HIDE);
		m_pTabDlg1->ShowWindow(SW_HIDE);
				
		m_pTabDlg4->ShowWindow(SW_SHOW);
	}
	break;

	case 5:
	{
		m_pTabDlg4->ShowWindow(SW_HIDE);
		m_pTabDlg3->ShowWindow(SW_HIDE);
		m_pTabDlg2->ShowWindow(SW_HIDE);
		m_pTabDlg1->ShowWindow(SW_HIDE);
				
		m_pTabDlg5->ShowWindow(SW_SHOW);
	}

	break;
				 
	}
	
}

BOOL CExtlCmdTestDlg::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult) 
{
	LPNMHDR hdr ; 
	NMLVDISPINFO * ndi ;
	
	hdr = (LPNMHDR)lParam ; 
	ndi = (NMLVDISPINFO *)lParam ;
	
	if(hdr->hwndFrom == m_TabCtrl.m_hWnd)
	{
		switch(hdr->code)
		{
		case TCN_SELCHANGE:
			{
				int nCurSel = m_TabCtrl.GetCurSel();
				OnShowTabPage(nCurSel+1);
			}
			break;
			
		default:
			break;
		}
	}	
	return CDialog::OnNotify(wParam, lParam, pResult);
}

//------------------------------------------------------------
// Notification Receiver Window �� ��ϵ� ������ ���Ͽ� 
// CDMA�� ���� ���۵� Notification�� ó�����ش�.
// ���� �� �ڵ� �Ľ�..
//-----------------------------------------------------------
LRESULT CExtlCmdTestDlg::OnCDMANotiMsg(WPARAM wParam, LPARAM lParam)
{
	CReadData	rd;
	INT			nRet;
	CString		msg;
	char		szParam[MAX_CMD_PARAM] = {0, };
	char		szDesc[MAX_DESC_LENGTH] = {0, };
	DWORD		dwParamLen = MAX_CMD_PARAM;
	DWORD		dwDescLen = MAX_DESC_LENGTH;
 
	SMSRECVSTRUCT SmsFormat;


	nRet = g_pCdmaCmd->GetNotiData(int(lParam), szParam, &dwParamLen, szDesc, &dwDescLen);
	if(nRet >= 0)
	{
		msg.Format(_T("Code : %d, Param - %s, Desc- %s"), nRet, CString(szParam), CString(szDesc));
	}
	else
	{
		msg.Format(_T("Fail to process - Error Code - %d"), nRet);
	}

	LOG((WPARAM)msg.GetBuffer(0), NULL);


	if(nRet == SMS_NEW)
	{
//		::AfxMessageBox(CString(szParam));
		memset(&SmsFormat, 0x00, sizeof(SMSRECVSTRUCT));
//		m_pCmd->ReadSMS(nRet, &SmsFormat);
		//m_szCallBack = CString(SmsFormat.szCallBack);
		//m_szSms = CString(SmsFormat.szData);

		UpdateData(FALSE);
	}

	return TRUE;
}

long CExtlCmdTestDlg::LOG(WPARAM szLog, LPARAM lParam)
{
	m_listLog.AddString((TCHAR *)szLog);
	m_listLog.SetCurSel(m_listLog.GetCount()-1);

	return FALSE;
}

void CExtlCmdTestDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	//delete m_pCmd;
	delete m_pTabDlg1;
	delete m_pTabDlg2;
	delete m_pTabDlg3;
	delete m_pTabDlg4;
	delete m_pTabDlg5;
	g_pCdmaCmd->DeleteCmd();
	delete g_pCdmaCmd;
	CDialog::OnClose();
}


BOOL CExtlCmdTestDlg::PreTranslateMessage(MSG* pMsg) 
{
	CString szTemp;
	
	if		(pMsg->message == WM_RASDIALEVENT)
		OnRasEvent(pMsg->wParam, pMsg->lParam);
	else if (pMsg->message == WM_POWERRESUME)
	{
		szTemp.Format(L"WakeUp");
		LOG((WPARAM)szTemp.GetBuffer(0), NULL);
	}
	else if (pMsg->message == WM_POWERSTATECHANGE)
	{
		if(pMsg->wParam == AC_LINE_OFFLINE)
		{
			szTemp.Format(L"DC Power");
			LOG((WPARAM)szTemp.GetBuffer(0), NULL);
		}
		else if(pMsg->wParam == AC_LINE_ONLINE)
		{
			szTemp.Format(L"AC Power");
			LOG((WPARAM)szTemp.GetBuffer(0), NULL);
		}
	}
	else if (pMsg->message == WM_NETRELEASE)
	{
		szTemp.Format(L"Disconnected");
		LOG((WPARAM)szTemp.GetBuffer(0), NULL);
		g_pCdmaCmd->HangUpRas();
	}
	
	return CDialog::PreTranslateMessage(pMsg);
}

BOOL CExtlCmdTestDlg::OnRasEvent(WPARAM wParam, LPARAM lParam)
{
	CString szTemp;
	TCHAR ErrorStr[128] = {0, };
	g_pCdmaCmd->HandleRasEvent(wParam, lParam, ErrorStr);
	szTemp = ErrorStr;
	LOG((WPARAM)szTemp.GetBuffer(0), NULL);
	return TRUE;
}

