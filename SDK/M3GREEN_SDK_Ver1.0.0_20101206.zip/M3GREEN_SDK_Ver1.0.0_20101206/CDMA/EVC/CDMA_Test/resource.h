//{{NO_DEPENDENCIES}}
// Microsoft eMbedded Visual C++ generated include file.
// Used by ExtlCmdTest.rc
//
#define IDD_EXTLCMDTEST_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define IDD_DIALOG2                     130
#define IDD_DIALOG3                     131
#define IDD_DIALOG4                     132
#define IDD_DIALOG6                     136
#define IDD_DIALOG5                     136
#define IDC_LT_LOG                      1000
#define IDC_BTN_RSSI                    1001
#define IDC_BTN_CALL                    1002
#define IDC_BTN_CALLEND                 1003
#define IDC_BTN_REG_HWND                1004
#define IDC_ED_PHONENO                  1005
#define IDC_BTN_RSSI_GRADE              1006
#define IDC_ED_SMS                      1007
#define IDC_BTN_SEND_SMS                1008
#define IDC_BTN_PHONENO                 1009
#define IDC_ED_CALLBACK                 1010
#define IDC_BUT_RSSI2                   1011
#define IDC_BUTTON2                     1012
#define IDC_BTN_DIAL_UP                 1012
#define IDC_BUT_VIB                     1013
#define IDC_BTN_RAS_STATE               1014
#define IDC_BTN_RAS_EVENT               1015
#define IDC_TAB1                        1015
#define IDC_BTN_SMSSETRECEIVE_WINDOW    1015
#define IDC_BTN_SET_CALLBLOCK           1016
#define IDC_BTN_SMS_REMOVE              1016
#define IDC_BTN_RAS_HANGUP              1017
#define IDC_BTN_SMS_GETRECEIVEWWINDOW   1017
#define IDC_BTN_CALLBLOCK_STATUS        1018
#define IDC_BTN_SMS_GETMAKER            1018
#define IDC_BTN_SMSBLOCK_STATUS         1019
#define IDC_BTN_SMS_SETRECEIVE_HWND     1019
#define IDC_BTN_SET_SMSPOPUP            1019
#define IDC_BTN_SET_SMSBLOCK            1020
#define IDC_CHECK1                      1020
#define IDC_BTN_SMS_READ                1020
#define IDC_BTN_CDMA_SERIAL             1021
#define IDC_BTN_ADD_PBITEM              1022
#define IDC_BTN_DATETIME                1023
#define IDC_ED_NAME                     1023
#define IDC_BTN_ADD_PBGROUP             1024
#define IDC_BUTTON1                     1024
#define IDC_BTN_CLOSE_POWERNOTI         1025
#define IDC_ED_PHONENUM                 1025
#define IDC_BTN_SETUP_POWERNOTI         1026
#define IDC_ED_OFFICENUM                1026
#define IDC_ED_HOMENUM                  1027
#define IDC_BTN_SMS_CNT                 1027
#define IDC_ED_GROUP                    1028
#define IDC_EDT_SMS                     1028
#define IDC_ED_GROUPNAME                1029

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
