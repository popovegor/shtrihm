// CdmaCmd.cpp : implementation file
//

#include "stdafx.h"
#include "ExtlCmdTest.h"
#include "CdmaCmd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCdmaCmd

CCdmaCmd::CCdmaCmd()
{
	m_pCmd = new CExtlCmd();
}

CCdmaCmd::~CCdmaCmd()
{
}


BEGIN_MESSAGE_MAP(CCdmaCmd, CWnd)
	//{{AFX_MSG_MAP(CCdmaCmd)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CCdmaCmd message handlers

BOOL CCdmaCmd::Create(CWnd* pParentWnd) 
{
	m_hwndParent = pParentWnd->m_hWnd;
	
	return CWnd::Create(NULL, NULL, NULL, CRect(0, 0, 1, 1), pParentWnd, NULL, NULL);
}
int CCdmaCmd::Initialize()
{
	return m_pCmd->Initialize(this->GetSafeHwnd());
}
int CCdmaCmd::PhoneCall(CString szPhoneNo)
{
	return m_pCmd->MakePhoneCall(szPhoneNo.GetBuffer(0));
}
int CCdmaCmd::Hangup()
{
	return m_pCmd->Hangup();
}
int CCdmaCmd::SendSMS(WCHAR* szPhoneNo, WCHAR* szSms, WCHAR* szCallBack, INT nPriority)
{
	return m_pCmd->SendSMS(szPhoneNo, szSms, szCallBack, nPriority);
}
int CCdmaCmd::RegisterNotiReceiver(HWND hWnd, BOOL bRegister)
{
	return m_pCmd->RegisterNotiReceiver(hWnd, bRegister);
}
int CCdmaCmd::GetPhoneNumber(TCHAR* szPhoneNo)
{
	return m_pCmd->GetPhoneNumber(szPhoneNo);
}
int CCdmaCmd::SetVibration(BOOL bVibration)
{
	//return m_pCmd->SetVibration(bVibration);
	return 0;
}
int CCdmaCmd::GetRSSIGrade()
{
	return m_pCmd->GetRSSIGrade();
}
int CCdmaCmd::GetRSSIValue(INT* pRssi)
{
	return m_pCmd->GetRSSIValue(pRssi);
}
int CCdmaCmd::GetPhoneNumber(char* szPhoneNo)
{
	return m_pCmd->GetPhoneNumber(szPhoneNo);
}
int CCdmaCmd::GetRasState()
{
	return m_pCmd->GetRasState();
}
int CCdmaCmd::DialUp(HWND hwnd, TCHAR* szPhoneNum, TCHAR* szUserName, TCHAR* szPassword, TCHAR* szEntryName)
{
	return m_pCmd->DialUp(hwnd, szPhoneNum, szUserName, szPassword, szEntryName);
}
int CCdmaCmd::HangUpRas()
{
	return m_pCmd->HangUpRas();
}
int CCdmaCmd::HandleRasEvent(WPARAM wParam, LPARAM lParam, TCHAR* NotiString)
{
	return m_pCmd->HandleRasEvent(wParam, lParam, NotiString);
}
int CCdmaCmd::SetCallBlock(BOOL bBlock)
{
	return m_pCmd->SetCallBlock(bBlock);
}
int CCdmaCmd::SetSmsPopupBlock(BOOL bBlock)
{
	return m_pCmd->SetSmsPopupBlock(bBlock);
}
int CCdmaCmd::RequestCallBlockStatus(HWND hWnd)
{
	return m_pCmd->RequestCallBlockStatus(hWnd);
}
BOOL CCdmaCmd::GetCDMASerial(TCHAR* szSerial,TCHAR* szErrString)
{
	return m_pCmd->GetCDMASerial(szSerial,szErrString);
}
BOOL CCdmaCmd::GetDateTime(SYSTEMTIME* pSt, TCHAR* szErrString)
{
	return m_pCmd->GetDateTime(pSt, szErrString);
}
BOOL CCdmaCmd::SetupPowerNoti(HWND hwnd)
{
	return m_pCmd->SetupPowerNoti(hwnd);
}
void CCdmaCmd::ClosePowerNoti()
{
	m_pCmd->ClosePowerNoti();
}
INT CCdmaCmd::GetNotiData(int nSlotNo, char* szParam, PDWORD pParamLen, char* szDesc, PDWORD pszDescLen)
{
	return m_pCmd->GetNotiData(nSlotNo, szParam, pParamLen, szDesc, pszDescLen);
}
int CCdmaCmd::SMSCnt()
{
	return m_pCmd->SMSCnt();
}
int CCdmaCmd::SMSRead(int lm_iIndex, void* lm_pData)
{
	return m_pCmd->SMSRead(lm_iIndex, lm_pData);
}
int CCdmaCmd::SMSRemove (int lm_iIndex)
{
	return m_pCmd->SMSRemove(lm_iIndex);
}
void CCdmaCmd::DeleteCmd()
{
	delete m_pCmd;
}