// TabDlgSms.cpp : implementation file
//

#include "stdafx.h"
#include "ExtlCmdTest.h"
#include "TabDlgSms.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTabDlgSms dialog


CTabDlgSms::CTabDlgSms(CWnd* pParent /*=NULL*/)
	: CDialog(CTabDlgSms::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTabDlgSms)
	m_szSmsNum = _T("");
	//}}AFX_DATA_INIT
}


void CTabDlgSms::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTabDlgSms)
	DDX_Text(pDX, IDC_EDT_SMS, m_szSmsNum);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTabDlgSms, CDialog)
	//{{AFX_MSG_MAP(CTabDlgSms)
	ON_BN_CLICKED(IDC_BTN_SMS_CNT, OnBtnSmsCnt)
	ON_BN_CLICKED(IDC_BTN_SMS_READ, OnBtnSmsRead)
	ON_BN_CLICKED(IDC_BTN_SMS_REMOVE, OnBtnSmsRemove)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTabDlgSms message handlers

BOOL CTabDlgSms::Create(CWnd* pParentWnd) 
{
	m_hwndParent = pParentWnd->m_hWnd;
	
	return CDialog::Create(IDD, pParentWnd);
}

void CTabDlgSms::OnBtnSmsCnt() 
{
	CString szMsg;
	int nRet = g_pCdmaCmd->SMSCnt();
	if(nRet == -1)
	{
		szMsg =  _T("�б� ����");
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
	}
	else 
	{
		szMsg.Format(_T("SMS Cnt : %d"), nRet);
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
	}
}

void CTabDlgSms::OnBtnSmsRead() 
{
	CString szMsg, szMsg1, szMsg2, szMsg3;
	int lm_iIndex;
	SMSDATA_st lm_pData[100];
	int nRet = g_pCdmaCmd->SMSRead(lm_iIndex, lm_pData);
	if(!nRet)
	{
		szMsg =  _T("�б� ����");
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
	}
	else 
	{
		if(nRet != 0)
		{
			szMsg.Format(_T("Index : %d"), lm_pData[nRet-1].Mflag);
			::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);

			szMsg1.Format(_T("Date-Time : %s"), lm_pData[nRet-1].DateTime);
			::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg1.GetBuffer(0), NULL);

			szMsg2.Format(_T("Name : %s"), lm_pData[nRet-1].Name);
			::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg2.GetBuffer(0), NULL);

			szMsg3.Format(_T("Msg : %s"), lm_pData[nRet-1].Memo);
			::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg3.GetBuffer(0), NULL);
		}
		else
		{
			szMsg =  _T("�޼����� �����ϴ�");
			::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
		}
		
	}
}

void CTabDlgSms::OnBtnSmsRemove() 
{
	//index : lm_pData[�ش絥����].Mflag
	//������ ��ü ���� : index = -1

	CString szMsg;
	int nindex;
	UpdateData(TRUE);
	nindex = _ttoi(m_szSmsNum);
	int nRet = g_pCdmaCmd->SMSRemove(nindex);
	if(!nRet)
	{
		szMsg = _T("���� ����");
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
	}
	else 
	{
		szMsg.Format(_T("%d ��° ���� �����Ǿ������ϴ�"), nindex);
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
	}
}
