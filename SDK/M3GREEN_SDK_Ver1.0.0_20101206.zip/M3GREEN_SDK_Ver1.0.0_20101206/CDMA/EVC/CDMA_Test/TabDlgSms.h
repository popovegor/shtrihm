#if !defined(AFX_TABDLGSMS_H__DA7B2E34_9173_4349_86BD_17DE885D4290__INCLUDED_)
#define AFX_TABDLGSMS_H__DA7B2E34_9173_4349_86BD_17DE885D4290__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TabDlgSms.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTabDlgSms dialog

class CTabDlgSms : public CDialog
{
// Construction
public:
	CTabDlgSms(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTabDlgSms)
	enum { IDD = IDD_DIALOG5 };
	CString	m_szSmsNum;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTabDlgSms)
	public:
	virtual BOOL Create(CWnd* pParentWnd);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HWND m_hwndParent;

	// Generated message map functions
	//{{AFX_MSG(CTabDlgSms)
	afx_msg void OnBtnSmsCnt();
	afx_msg void OnBtnSmsRead();
	afx_msg void OnBtnSmsRemove();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TABDLGSMS_H__DA7B2E34_9173_4349_86BD_17DE885D4290__INCLUDED_)
