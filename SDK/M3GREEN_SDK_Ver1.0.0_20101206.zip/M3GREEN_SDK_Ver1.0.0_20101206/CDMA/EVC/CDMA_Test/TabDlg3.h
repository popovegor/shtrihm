#if !defined(AFX_TABDLG3_H__6B8BF909_3996_4924_966B_2858306EE538__INCLUDED_)
#define AFX_TABDLG3_H__6B8BF909_3996_4924_966B_2858306EE538__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TabDlg3.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTabDlg3 dialog

class CTabDlg3 : public CDialog
{
// Construction
public:
	CTabDlg3(CWnd* pParent = NULL);   // standard constructor
	BOOL OnRasEvent(WPARAM wParam, LPARAM lParam);

// Dialog Data
	//{{AFX_DATA(CTabDlg3)
	enum { IDD = IDD_DIALOG3 };
	BOOL	m_bCallBlock;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTabDlg3)
	public:
	virtual BOOL Create(CWnd* pParentWnd);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HWND m_hwndParent;

	// Generated message map functions
	//{{AFX_MSG(CTabDlg3)
	afx_msg void OnBtnRasState();
	afx_msg void OnBtnDialUp();
	afx_msg void OnBtnRasHangup();
	afx_msg void OnBtnSetCallblock();
	afx_msg void OnBtnCallblockStatus();
	afx_msg BOOL OnBlockCallQueryReply(WPARAM wParam, LPARAM lParam);
	afx_msg void OnBtnSetSmspopup();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TABDLG3_H__6B8BF909_3996_4924_966B_2858306EE538__INCLUDED_)
