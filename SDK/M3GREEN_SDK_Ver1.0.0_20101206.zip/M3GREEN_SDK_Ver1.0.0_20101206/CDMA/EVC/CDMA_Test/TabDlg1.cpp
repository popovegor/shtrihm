// TabDlg1.cpp : implementation file
//

#include "stdafx.h"
#include "ExtlCmdTest.h"
#include "TabDlg1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTabDlg1 dialog


CTabDlg1::CTabDlg1(CWnd* pParent /*=NULL*/)
	: CDialog(CTabDlg1::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTabDlg1)
	m_szCallBack = _T("");
	m_szPhoneNo = _T("");
	m_szSms = _T("");
	//}}AFX_DATA_INIT

}


void CTabDlg1::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTabDlg1)
	DDX_Text(pDX, IDC_ED_CALLBACK, m_szCallBack);
	DDX_Text(pDX, IDC_ED_PHONENO, m_szPhoneNo);
	DDX_Text(pDX, IDC_ED_SMS, m_szSms);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTabDlg1, CDialog)
	//{{AFX_MSG_MAP(CTabDlg1)
	ON_BN_CLICKED(IDC_BTN_CALL, OnBtnCall)
	ON_BN_CLICKED(IDC_BTN_CALLEND, OnBtnCallend)
	ON_BN_CLICKED(IDC_BTN_SEND_SMS, OnBtnSendSms)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTabDlg1 message handlers

BOOL CTabDlg1::Create(CWnd* pParentWnd) 
{
	m_hwndParent = pParentWnd->m_hWnd;
	
	return CDialog::Create(IDD, pParentWnd);
}

//----------------------------------------------
//��ȭ�ɱ�
//---------------------------------------------

void CTabDlg1::OnBtnCall() 
{
	UpdateData();
	
	m_szPhoneNo.TrimLeft();
	m_szPhoneNo.TrimRight();
	
	if(m_szPhoneNo.IsEmpty())
	{
		::AfxMessageBox(_T("��ȣ�� �Է��ϼ���"));
		return;
	}
	
	CString szMsg;
	int	nRet = g_pCdmaCmd->PhoneCall(m_szPhoneNo);
	if(nRet != ERROR_NONE)
	{
		szMsg.Format(_T("Error Occured(Error Code : %d)"), nRet);
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
	}
}

//----------------------------------------------
//��ȭ ����
//---------------------------------------------
void CTabDlg1::OnBtnCallend() 
{
	CString szMsg;

	int	nRet = g_pCdmaCmd->Hangup();
	if(nRet != ERROR_NONE)
	{
		szMsg.Format(_T("Error Occured(Error Code : %d)"), nRet);
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
	}
}

//------------------------------------------------------------
// SMS �����ϱ�
//-----------------------------------------------------------
void CTabDlg1::OnBtnSendSms() 
{
	INT		nRet = 0;
	CString szMsg;
	// TODO: Add your control notification handler code here
	//Check Data..
	UpdateData();
	if(m_szPhoneNo.IsEmpty())
	{
		szMsg = _T("Input phone number!!");
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
		return;
	}
	
	if(m_szSms.IsEmpty())
	{
		szMsg = _T("Input SMS content!!");
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
		return;
	}
	
	if(m_szCallBack.IsEmpty())
	{
		szMsg = _T("Input SMS callback number!!");
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
		return;
	}
	
	nRet = g_pCdmaCmd->SendSMS(m_szPhoneNo.GetBuffer(0),   // ���� ��ȭ��ȣ
		m_szSms.GetBuffer(0),       // �޼��� --> ���� 80 Byte.
		m_szCallBack.GetBuffer(0),  // Callback ��ȣ
		SMS_PRIORITY_NORMAL);	   // �켱����	
	if(nRet != ERROR_NONE)
	{
		szMsg.Format(_T("Error Occured(Error Code : %d)"), nRet);
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
	}
	
}
