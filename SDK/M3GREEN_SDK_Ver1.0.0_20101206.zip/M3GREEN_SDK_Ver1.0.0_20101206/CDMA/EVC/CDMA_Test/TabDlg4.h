#if !defined(AFX_TABDLG4_H__9A998A3A_BC42_48C3_8AE4_3725CC681D6C__INCLUDED_)
#define AFX_TABDLG4_H__9A998A3A_BC42_48C3_8AE4_3725CC681D6C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TabDlg4.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTabDlg4 dialog

class CTabDlg4 : public CDialog
{
// Construction
public:
	CTabDlg4(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTabDlg4)
	enum { IDD = IDD_DIALOG4 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTabDlg4)
	public:
	virtual BOOL Create(CWnd* pParentWnd);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HWND m_hwndParent;

	// Generated message map functions
	//{{AFX_MSG(CTabDlg4)
	afx_msg void OnBtnCdmaSerial();
	afx_msg void OnBtnDatetime();
	afx_msg void OnBtnSetupPowernoti();
	afx_msg void OnBtnClosePowernoti();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TABDLG4_H__9A998A3A_BC42_48C3_8AE4_3725CC681D6C__INCLUDED_)
