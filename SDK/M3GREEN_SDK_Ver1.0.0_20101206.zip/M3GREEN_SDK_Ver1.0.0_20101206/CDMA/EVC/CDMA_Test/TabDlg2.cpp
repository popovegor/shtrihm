// TabDlg2.cpp : implementation file
//

#include "stdafx.h"
#include "ExtlCmdTest.h"
#include "TabDlg2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTabDlg2 dialog


CTabDlg2::CTabDlg2(CWnd* pParent /*=NULL*/)
	: CDialog(CTabDlg2::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTabDlg2)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CTabDlg2::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTabDlg2)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTabDlg2, CDialog)
	//{{AFX_MSG_MAP(CTabDlg2)
	ON_BN_CLICKED(IDC_BTN_REG_HWND, OnBtnRegHwnd)
	ON_BN_CLICKED(IDC_BTN_RSSI_GRADE, OnBtnRssiGrade)
	ON_BN_CLICKED(IDC_BTN_RSSI, OnBtnRssi)
	ON_BN_CLICKED(IDC_BTN_PHONENO, OnBtnPhoneno)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTabDlg2 message handlers

BOOL CTabDlg2::Create(CWnd* pParentWnd) 
{
	m_hwndParent = pParentWnd->m_hWnd;
	m_bRegistered = FALSE;
	
	return CDialog::Create(IDD, pParentWnd);
}

//-------------------------------------------------------------------
//Notification Receiver Window ����ϱ� / �����ϱ�
//��ϵ� Window�� CDMA ���� ���� ���۵Ǵ� Notification�� �ް� �ȴ�.
//--------------------------------------------------------------------
void CTabDlg2::OnBtnRegHwnd() 
{
	CButton* pBtn;
	CString szMsg;
	// TODO: Add your control notification handler code here
	pBtn = (CButton*)GetDlgItem(IDC_BTN_REG_HWND);
	
	if(m_bRegistered)
	{
		g_pCdmaCmd->RegisterNotiReceiver(m_hwndParent, FALSE);
		m_bRegistered = FALSE;
		pBtn->SetWindowText(_T("Reg Wnd"));
		
		szMsg.Format(_T("0x%X is Unregistered"), m_hwndParent);
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
	}
	else
	{
		g_pCdmaCmd->RegisterNotiReceiver(m_hwndParent, TRUE);
		m_bRegistered = TRUE;
		pBtn->SetWindowText(_T("Unreg Wnd"));
		
		szMsg.Format(_T("0x%X is Registered"), m_hwndParent);
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
	}	
}


//----------------------------------------------
//RSSI Grade ���
//
// 		if		(nValue == -128)					nGrade = 0;
// 		else if (nValue < -110 && nValue >= -120)	nGrade = 1;
// 		else if (nValue < -100 && nValue >= -110)	nGrade = 2;
// 		else if (nValue < -97  && nValue >= -100)	nGrade = 3;
// 		else if (nValue < -92  && nValue >= -97)	nGrade = 4;
// 		else if (nValue < -87  && nValue >= -92)	nGrade = 5;
// 		else if (nValue < -82  && nValue >= -87)	nGrade = 6;
// 		else if (nValue >= -82)						nGrade = 7;
// 
// 		return nGrade;
//---------------------------------------------
void CTabDlg2::OnBtnRssiGrade() 
{
	INT			nRet = 0;
	CString		szMsg;
	// TODO: Add your control notification handler code here
	nRet = g_pCdmaCmd->GetRSSIGrade();
	//nRet = CallGetRSSIGrade();
	if(nRet >=0 ) 
	{
		szMsg.Format(_T("RSSI Grade : %d"), nRet);
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
	}
	else
	{
		szMsg = _T("Get RSSI Grade Fail");
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
	}	
}

//----------------------------------------------
//RSSI ���� ��������
//---------------------------------------------
void CTabDlg2::OnBtnRssi() 
{
	INT		nRet, nRssi;
	CString szMsg;
	// TODO: Add your control notification handler code here
	nRet = g_pCdmaCmd->GetRSSIValue(&nRssi);
	
	if(nRet == ERROR_NONE)
	{
		szMsg.Format(_T("RSSI : %d"), nRssi);
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
	}
	else
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
}

//------------------------------------------------------------
// �ڱ� ��ȭ��ȣ �˾ƿ���
//-----------------------------------------------------------
void CTabDlg2::OnBtnPhoneno() 
{
	TCHAR	szPhoneNo[20] = {0, };
	INT		nRet;
	CString szMsg;
	// TODO: Add your control notification handler code here
	nRet = g_pCdmaCmd->GetPhoneNumber(szPhoneNo);
	if(nRet != ERROR_NONE)
	{
		szMsg.Format(_T("Error Occured(Error Code : %d)"), nRet);
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
	}
	else 
	{
		szMsg.Format(_T("Phone Number : %s"), szPhoneNo);
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szMsg.GetBuffer(0), NULL);
	}	
}
