// TabDlg3.cpp : implementation file
//

#include "stdafx.h"
#include "ExtlCmdTest.h"
#include "TabDlg3.h"

#include <ras.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#define	WM_BLOCKCALL_REPLY	WM_USER+51

/////////////////////////////////////////////////////////////////////////////
// CTabDlg3 dialog


CTabDlg3::CTabDlg3(CWnd* pParent /*=NULL*/)
	: CDialog(CTabDlg3::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTabDlg3)
	m_bCallBlock = FALSE;
	//}}AFX_DATA_INIT
}


void CTabDlg3::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTabDlg3)
	DDX_Check(pDX, IDC_CHECK1, m_bCallBlock);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTabDlg3, CDialog)
	//{{AFX_MSG_MAP(CTabDlg3)
	ON_BN_CLICKED(IDC_BTN_RAS_STATE, OnBtnRasState)
	ON_BN_CLICKED(IDC_BTN_DIAL_UP, OnBtnDialUp)
	ON_BN_CLICKED(IDC_BTN_RAS_HANGUP, OnBtnRasHangup)
	ON_BN_CLICKED(IDC_BTN_SET_CALLBLOCK, OnBtnSetCallblock)
	ON_BN_CLICKED(IDC_BTN_CALLBLOCK_STATUS, OnBtnCallblockStatus)
	ON_BN_CLICKED(IDC_BTN_SET_SMSPOPUP, OnBtnSetSmspopup)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_BLOCKCALL_REPLY, OnBlockCallQueryReply)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTabDlg3 message handlers

BOOL CTabDlg3::Create(CWnd* pParentWnd) 
{
	m_hwndParent = pParentWnd->m_hWnd;

	return CDialog::Create(IDD, pParentWnd);
}

void CTabDlg3::OnBtnRasState() 
{
	DWORD dwRet = 0;
	CString szTemp;
	
	//���� "���ͳ�"�� Ȱ��ȭ �Ǿ� ������ TRUE
	
	dwRet = g_pCdmaCmd->GetRasState();
	if(dwRet == RASCS_Disconnected)
	{
		szTemp.Format(_T("Ras Disconnected"));
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szTemp.GetBuffer(0), NULL);
	}
	else if(dwRet == RASCS_Connected)
	{
		szTemp.Format(_T("Ras Connected"));
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szTemp.GetBuffer(0), NULL);
	}
	else
	{
		szTemp.Format(L"Ras Status - %d",dwRet);
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szTemp.GetBuffer(0), NULL);
	}
}

void CTabDlg3::OnBtnDialUp() 
{
	DWORD dwDial = g_pCdmaCmd->DialUp(this->GetSafeHwnd(), _T("1501"), _T("sktelecom"),_T(""), _T("���ͳ�"));
	CString szTemp;
	
	if(dwDial != 0)
	{
		szTemp.Format(L"DialUp Err- %d",dwDial); //raserror.h ����
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szTemp.GetBuffer(0), NULL);
	}
	else
	{
		szTemp.Format(L"Ras Connecting");
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szTemp.GetBuffer(0), NULL);
	}
}

void CTabDlg3::OnBtnRasHangup() 
{
	BOOL bDial = g_pCdmaCmd->HangUpRas();
	CString szTemp;
	
	if(bDial == TRUE)
	{
		szTemp.Format(L"Disconnected"); //raserror.h ����
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szTemp.GetBuffer(0), NULL);
	}
}

void CTabDlg3::OnBtnSetCallblock() 
{
	UpdateData();
	if(m_bCallBlock == FALSE)
		g_pCdmaCmd->SetCallBlock(FALSE);
	else
		g_pCdmaCmd->SetCallBlock(TRUE);
	g_pCdmaCmd->RequestCallBlockStatus(this->m_hWnd);	
}

void CTabDlg3::OnBtnSetSmspopup() 
{
	UpdateData();
	if(m_bCallBlock == FALSE)
		g_pCdmaCmd->SetSmsPopupBlock(FALSE);
	else
		g_pCdmaCmd->SetSmsPopupBlock(TRUE);
}

void CTabDlg3::OnBtnCallblockStatus() 
{
	g_pCdmaCmd->RequestCallBlockStatus(this->m_hWnd);
}

BOOL CTabDlg3::OnBlockCallQueryReply(WPARAM wParam, LPARAM lParam)
{
	CString szTemp;
	if((BOOL)wParam == TRUE)
	{
		szTemp.Format(L"�߽���ȭ ���");
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szTemp.GetBuffer(0), NULL);
	}
	else
	{
		szTemp.Format(L"�߽���ȭ ����");
		::PostMessage(m_hwndParent, WM_LOG, (WPARAM)szTemp.GetBuffer(0), NULL);
	}
	
	UpdateData(FALSE);
	return  TRUE;
}
