// DlgTab5.h: interface for the CDlgTab5 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DLGTAB5_H__630E8D01_F6D6_4CA9_AEF7_67859D1623AC__INCLUDED_)
#define AFX_DLGTAB5_H__630E8D01_F6D6_4CA9_AEF7_67859D1623AC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDlgTab5  
{
public:
	CDlgTab5();
	virtual ~CDlgTab5();

};

#endif // !defined(AFX_DLGTAB5_H__630E8D01_F6D6_4CA9_AEF7_67859D1623AC__INCLUDED_)
