// ExtlCmdTestDlg.h : header file
//

#include "TabDlg1.h"
#include "TabDlg2.h"
#include "TabDlg3.h"
#include "TabDlg4.h"
#include "TabDlgSms.h"

#if !defined(AFX_EXTLCMDTESTDLG_H__D7B01AB6_690E_42EC_BA1F_7F6ED8A27410__INCLUDED_)
#define AFX_EXTLCMDTESTDLG_H__D7B01AB6_690E_42EC_BA1F_7F6ED8A27410__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CExtlCmdTestDlg dialog

#define WM_NETRELEASE		WM_USER+25
#define WM_POWERRESUME		WM_APP + 1000
#define WM_POWERSTATECHANGE WM_APP + 1001

class CExtlCmdTestDlg : public CDialog
{
// Construction
public:
	CExtlCmdTestDlg(CWnd* pParent = NULL);	// standard constructor
	void CreateControls();
	void OnShowTabPage(BYTE nIndex);
	void LOG(TCHAR* szLog);
	BOOL OnRasEvent(WPARAM wParam, LPARAM lParam);

	CCdmaCmd m_CdmaCmd;
// Dialog Data
	//{{AFX_DATA(CExtlCmdTestDlg)
	enum { IDD = IDD_EXTLCMDTEST_DIALOG };
	CListBox	m_listLog;
	CTabCtrl	m_TabCtrl;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CExtlCmdTestDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	//}}AFX_VIRTUAL

// Implementation
	BOOL m_bRegistered;
protected:
	HICON m_hIcon;
	CTabDlg1* m_pTabDlg1;
	CTabDlg2* m_pTabDlg2;
	CTabDlg3* m_pTabDlg3;
	CTabDlg4* m_pTabDlg4;
	CTabDlgSms* m_pTabDlg5;
	// Generated message map functions
	//{{AFX_MSG(CExtlCmdTestDlg)
	virtual BOOL OnInitDialog();
	//lms add-- <<--
	//afx_msg void OnBtnRssi();
	afx_msg void OnClose();
	//afx_msg void OnBtnCallend();
	//afx_msg void OnBtnCall();
	//afx_msg void OnBtnRegHwnd();
	afx_msg LRESULT OnCDMANotiMsg(WPARAM wParam, LPARAM lParam);
	//afx_msg void OnBtnRssiGrade();
	//afx_msg void OnBtnSendSms();
	//afx_msg void OnBtnPhoneno();
	//afx_msg void OnButRssi2();
	//afx_msg void OnButton2();
	//afx_msg void OnButVib();
	afx_msg long LOG(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EXTLCMDTESTDLG_H__D7B01AB6_690E_42EC_BA1F_7F6ED8A27410__INCLUDED_)
