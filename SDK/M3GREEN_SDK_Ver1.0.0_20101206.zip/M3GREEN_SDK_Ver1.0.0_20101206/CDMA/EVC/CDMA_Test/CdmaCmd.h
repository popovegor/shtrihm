#if !defined(AFX_CDMACMD_H__365D073A_0F52_44D8_A179_22206D79A6FB__INCLUDED_)
#define AFX_CDMACMD_H__365D073A_0F52_44D8_A179_22206D79A6FB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CdmaCmd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCdmaCmd window
#include "ExtlCmd.h"

class CCdmaCmd : public CWnd
{
// Construction
public:
	CCdmaCmd();

// Attributes
public:

// Operations
public:
	int PhoneCall(CString szPhoneNo);
	int Initialize();
	int Hangup();
	int SendSMS(WCHAR* szPhoneNo, WCHAR* szSms, WCHAR* szCallBack, INT nPriority);
	int RegisterNotiReceiver(HWND hWnd, BOOL bRegister);
	int GetPhoneNumber(TCHAR* szPhoneNo);
	int SetVibration(BOOL bVibration);
	int GetRSSIGrade();
	int GetRSSIValue(INT* pRssi);
	int GetPhoneNumber(char* szPhoneNo);
	int GetRasState();
	int DialUp(HWND hwnd, TCHAR* szPhoneNum, TCHAR* szUserName, TCHAR* szPassword, TCHAR* szEntryName);
	int HangUpRas();
	int HandleRasEvent(WPARAM wParam, LPARAM lParam, TCHAR* NotiString);
	int SetCallBlock(BOOL bBlock);
	int SetSmsPopupBlock(BOOL bBlock);
	int RequestCallBlockStatus(HWND hWnd);
	BOOL GetCDMASerial(TCHAR* szSerial,TCHAR* szErrString);
	BOOL GetDateTime(SYSTEMTIME* pSt, TCHAR* szErrString);
	BOOL SetupPowerNoti(HWND hwnd);
	void ClosePowerNoti();
	INT GetNotiData(int nSlotNo, char* szParam, PDWORD pParamLen, char* szDesc, PDWORD pszDescLen);
	int SMSCnt();
	int SMSRead(int lm_iIndex, void* lm_pData);
	int SMSRemove (int lm_iIndex);
	void DeleteCmd();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCdmaCmd)
	public:
	virtual BOOL Create(CWnd* pParentWnd);
	//}}AFX_VIRTUAL

// Implementation
	HWND m_hwndParent;
public:
	virtual ~CCdmaCmd();

	// Generated message map functions
protected:
	CExtlCmd* m_pCmd;
	//{{AFX_MSG(CCdmaCmd)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CDMACMD_H__365D073A_0F52_44D8_A179_22206D79A6FB__INCLUDED_)
