-------------------------------------------------------------------------------
                       aveLinkBT SDK for Windows CE (.NET)
				  
              (c) 1997-2005 Atinav LLC.  100 Franklin Square Drive
		        Suite # 304, Somerset, NJ 08873., USA
-------------------------------------------------------------------------------


        Abstarct
-------------------------------------------

 			Congratulations!  You have obtained the aveLinkBT SDK for Windows CE.NET. 

The purpose of the aveLinkBT SDK is to provide an easy to use programming interface for developing Bluetooth software.The SDK provides a high-level abstraction of the Bluetooth Core specifications.Using the SDK, bluetooth applications can be written without the knowledge of original Bluetooth specifications.Some of the functions provided by the API are identical to the functions described in the Bluetooth Core specifications, others provideenhanced functionality and still others provide completely new functionality.The API provides a layer of abstraction,which separates the programmer from the technical details of the Bluetooth stack and the hardware on which it runs.


       

Supported Platforms  :  	Windows CE 5.0 based devices.	
	


        Index
-------------------------------------------
  1. Installation/Uninstallation instructions
  2. Version Information	
  3. Installed Components
  4. Usage
  5. Features
  6. Programing M3 Built-in Bluetooth
  7. Errors
  8. Contact
  9. Copyright

1. 	Installation/Uninstallation instructions
-------------------------------------------

Installation
------------

aveLinkBT SDK can be installed using the aveLinkBT setup program. To install, first Connect the target device to your desktop computer using its craddle and execute the installation file from the desktop Computer.The installation wizard will pop up and guide you through the installation.

Uninstallation
--------------
Installed components in the desktop PC can be removed from 'Start �> programs �> aveLinkBT -> WindowsCENetSDK-> UnInstallation' which will uninstall the SDK components from the desktop system.

Installed components in the windows CE device can be removed using RemovePrograms in StartMenu-->Settings-->System  of the Windows CE device.

2. 	Version Information
----------------------------

Version 0.9-CE2.1.0-CS11018 Build 06AUG18CE-M3-NET-DESKTOP
3.       Installed Components
-------------------------------------------

The avelinkBT SDK for Windows CE .NET is organized as a class library for developing Bluetooth applications using .NET languages such as C#. The class library relies on the avelinkBT Core stack for providing Bluetoooth functionality.  

On installation, the SDK copies api reference documentaion, library files and sample applications in to the installation folder of the development machine. 

Note : This setup will not install device side components required for Bluetooth application development.The user has to install another SDK, avelinkBT SDK for WindowsCE for installing Bluetooth SDK components in to the target device, if  not present.  


4.       Usage
-------------------------------------------

 a) For SDK documentation please refer the NetAPIreferenceguide.chm in the installation directory of the desktop system.You can also access the same from Start menu/Programs/aveLinkBT SDK for Windows CE.
 
 b) For deatils on usage of libraries please refer "Getting started"  section in the NetAPIreferenceguide.chm.

  

5.       profile Support
-------------------------------------------

 The SDK supports following core profiles
 
   a) GAP
   b) SDAP
   c) SPP 
   d) Security Manager

 This   version DOESNOT support other profiles such as FTP, Object push etc.  	


6.  Programing M3 built-in Bluetooth
---------------------------------------------
   
 The following values are relevant for Mobile compia M3 built-in Bluetooth,
 
 Bluetooth  Transport	: BCSP
 BCSP Port 		: COM7:
 Baudrate		: 921600 

 Serial Ports 		: COM4:, COM9  
 
7.	Errors
---------------------------------------------
 In any case of abnormality, reset the windows CE device and try again.



8.	Contact
---------------------------------------------
	100 FRANKLIN SQUARE DRIVE, 
	SUITE # 304, SOMERSET, 
	NEW JERSEY 08873 
	PHONE: 732.412.3000 
	FAX: 732.412.2145 

Email : support@atinav.com


9.	Copyright
---------------------------------------------

(c) 2003-2004 Atinav LLC.  100 Franklin Square Drive, Suite # 304, Somerset, NJ 08873., USA



 



