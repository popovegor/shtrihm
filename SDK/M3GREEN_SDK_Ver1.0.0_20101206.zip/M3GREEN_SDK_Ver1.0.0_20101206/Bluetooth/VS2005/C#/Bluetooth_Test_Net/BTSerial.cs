using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;
using Microsoft.WindowsCE.Forms;
using System.IO;

// Make sure that the albtcoreNet.dll is referenced.

using AveBluetooth;  // Name space for atinav Bluetooth


namespace SampleBT
{
	/// <summary>
	/// Summary description for BTSerial.
	/// </summary>
	public class BTSerial : System.Windows.Forms.Form
	{
		
		public BTSerial()
        {
            BTSerial.myForm = this;
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		private const string PORT_NAME = "COM7:";
		private const int BT_BAUDRATE = 921600;
		private const string Device_Name = "M3 .Net Device";
        
		BTCore bTCore;
		bool btOn, devFound, servFound, connected;// To check for bluetooth iniialized, device found, service found and spp connected
		int deviceIndex = 0; // Selected device index 
		public static BTSerial myForm;
		BT_DEVICE []devices; //Devices found in the device search
		BT_SERVICE[] services;// Services of the selected device found in the service search
        IntPtr g_sppHandle;
		StreamWriter sw;
       // CallBack callback;
		string err;

		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button sppconn;
		private System.Windows.Forms.Button servsearch;
		private System.Windows.Forms.ListBox devlist;
		private System.Windows.Forms.Button devsearch;
		private System.Windows.Forms.Button btonoff;
		public System.Windows.Forms.Label label;
		
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.panel1 = new System.Windows.Forms.Panel();
            this.devlist = new System.Windows.Forms.ListBox();
            this.devsearch = new System.Windows.Forms.Button();
            this.btonoff = new System.Windows.Forms.Button();
            this.sppconn = new System.Windows.Forms.Button();
            this.servsearch = new System.Windows.Forms.Button();
            this.label = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.devlist);
            this.panel1.Controls.Add(this.devsearch);
            this.panel1.Controls.Add(this.btonoff);
            this.panel1.Controls.Add(this.sppconn);
            this.panel1.Controls.Add(this.servsearch);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(272, 224);
            // 
            // devlist
            // 
            this.devlist.Location = new System.Drawing.Point(8, 48);
            this.devlist.Name = "devlist";
            this.devlist.Size = new System.Drawing.Size(208, 114);
            this.devlist.TabIndex = 0;
            // 
            // devsearch
            // 
            this.devsearch.Location = new System.Drawing.Point(112, 16);
            this.devsearch.Name = "devsearch";
            this.devsearch.Size = new System.Drawing.Size(104, 24);
            this.devsearch.TabIndex = 1;
            this.devsearch.Text = "Device Search";
            this.devsearch.Click += new System.EventHandler(this.devsearch_Click);
            // 
            // btonoff
            // 
            this.btonoff.Location = new System.Drawing.Point(8, 16);
            this.btonoff.Name = "btonoff";
            this.btonoff.Size = new System.Drawing.Size(96, 24);
            this.btonoff.TabIndex = 2;
            this.btonoff.Text = "Bluetooth On";
            this.btonoff.Click += new System.EventHandler(this.btonoff_Click);
            // 
            // sppconn
            // 
            this.sppconn.Location = new System.Drawing.Point(112, 184);
            this.sppconn.Name = "sppconn";
            this.sppconn.Size = new System.Drawing.Size(104, 24);
            this.sppconn.TabIndex = 3;
            this.sppconn.Text = "SPP Connect";
            this.sppconn.Click += new System.EventHandler(this.sppconn_Click);
            // 
            // servsearch
            // 
            this.servsearch.Location = new System.Drawing.Point(8, 184);
            this.servsearch.Name = "servsearch";
            this.servsearch.Size = new System.Drawing.Size(96, 24);
            this.servsearch.TabIndex = 4;
            this.servsearch.Text = "Service Search";
            this.servsearch.Click += new System.EventHandler(this.servsearch_Click);
            // 
            // label
            // 
            this.label.Location = new System.Drawing.Point(8, 232);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(208, 20);
            // 
            // BTSerial
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.ClientSize = new System.Drawing.Size(277, 337);
            this.Controls.Add(this.label);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable;
            this.Location = new System.Drawing.Point(0, 192);
            this.Name = "BTSerial";
            this.Text = "Sample UI";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Closed += new System.EventHandler(this.BTSerial_Closed);
            this.Load += new System.EventHandler(this.BTSerial_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new BTSerial());
		}

		private void BTSerial_Load(object sender, System.EventArgs e)
		{
			// Class represnding the Bluetooth SDK
			bTCore = new BTCore();

			//Initializing the states
			btOn = false;
			devFound = false;
			servFound = false;
            connected = false;

   			sw = File.CreateText("log.txt");

			label.Text = "Bluetooth not Initialized";
		}
		
		private void btonoff_Click(object sender, System.EventArgs e)
		{			
			bool retVal = false;
			label.Text = "";
			
			if (!btOn)
			{
				// Initializes the Bluetooth Hardware and the Bluetooth SDK

				// You have to power-up the Bluetooth hardware before using any of 
				// the SDK apis, if the Bluetooth hardware is built-in with the device.

				// Power-up Bluetooth

				label.Text = "Initializing...";
	
				retVal = bTCore.BTPowerUp();

                if (retVal)
				{
					label.Text = "BTPowerUp success";
					sw.WriteLine("BTPowerUp success");
					// Bluetooth hardware successfully powered
					// Now we can initialize the Bluetooth hardware and SDK using the
					// SDK APIs.

					if (bTCore.BTIsInitialized()) 
					{
						// Open an instance of the SDK
						retVal = bTCore.BTOpen();	
						if (retVal)
							sw.WriteLine("BTOpen success");
						else
						{
							err = "BTOpen failed";
							label.Text = err;
							writeLog(err);		
						}
					}
					else
					{
						// Bluetooth not initialised...Trying to initialize...
						// Set the Bluetooth transport type of Bluetooth hardware 
						// M3 builtin chip is BCSP.      
						retVal = bTCore.BTSetTransportLayer(BTCore.TL_BCSP);
						if (retVal)
						{
							sw.WriteLine("BTSetTransportLayer success");
							// Transport Successfully set.
							// Now specify the Tranport specific settings,
							// such as port and baudrate to communicate with
							// the Bluetooth hardware(If it has UART/BCSP interface)

							retVal = bTCore.BTSetBCSPDefaultPortParams(PORT_NAME, BT_BAUDRATE);
							if(retVal)
								sw.WriteLine("BTSetBCSPDefaultPortParams success");
							else
							{
								err = "BTSetBCSPDefaultPortParams failed";
								label.Text = err;
								writeLog(err);		
							}
						}
						else
						{
							label.Text = "BTSetTransportLayer failed";
							err = label.Text;
							writeLog(err);		
						}

						// The above two settings can also failed if it has already been set by 
						// some other application.So to confirm this, Get the error code using
						// BTGetErrorCode() API. if the error is 'already initialized', we can 
						// proceed... To do.
						
						// Now try to initialize Bluetooth with the specified 
						// settings.
						// In an multi-application scenario, this method is confined to call 
						// only by the control application.

						// If the avelinBT application Suite is active in the system,
						// just open an instance of the stack using BTOpen().

						// Initialize Bluetooth SDK 
						retVal = bTCore.BTInit();
						if (retVal)
							sw.WriteLine("BTInit success");                            
						else
						{
							err = "BTInit failed";
							label.Text = err;
							writeLog(err);								
							
						}
					}

					if(retVal)
					{
						// Initialization success
						bTCore.GAPSetDiscoverableMode(true, null, 1);//Setting the device to Discoverable mode
						bTCore.GAPSetConnectableMode(true);//Setting the device to Connectable mode
						bTCore.GAPSetLocalDeviceName(Device_Name);//Setting the device name
						btOn = true;
						btonoff.Text = "Bluetooth Off";
				
						//class representing the message window to recieve asynchronous messages from the BT SDK
						
						//Registering the event for security notififcation

						//Setting the Security Notification function to get security notifications
						//(by invoking SecurityNotifyProc)during authentication and authorization processes.  
                        BTCore.SecurityNotifyProc proc = new BTCore.SecurityNotifyProc(SecurityNotifyProc);
                        retVal = bTCore.GAPSetSecurityNotifyProc(proc);
						label.Text = "Bluetooth Initialized";
    				}	
				}
				else
				{
					err = "BTPowerUp failed..."; 
					label.Text = err;
					writeLog(err);		
				}
			}
			else
			{
				bTCore.BTDeInit();
				bTCore.BTPowerDown();
				btonoff.Text = "Bluetooth On";
				btOn = false;
				devFound = false;
				servFound = false;
				devlist.Items.Clear();			
                label.Text = "Bluetooth not initialized";
			}
		}		
		
		// Searches for the devices in the vicinity

		private void devsearch_Click(object sender, System.EventArgs e)
		{
			bool retVal = false;
			label.Text = "";
			if(btOn)
			{
				label.Text = "Searching for devices....";
				devices = new BT_DEVICE[6];
				for (int i = 0; i < 6; i++)
				{
					devices[i] = new BT_DEVICE();
					devices[i].bdAddress = new byte[6];
					devices[i].clockOffset = new byte[2];
				}

				byte retCount;
				
				devlist.Items.Clear();

				// Call the SDK Api to find the devices in the vicinity
				retVal = bTCore.GAPInquireAndRetrieveDevices(BTCore.BT_GIAC, 6, ref devices, 6, out retCount);
				if (retVal)
				{
					if (retCount > 0)
					{
						for (int i = 0; i < retCount; i++)
						{
							string[] address = new string[6];

							for (int j = 0; j < 6; j++)
							{
								address[j] = String.Format("{0:x2}", devices[i].bdAddress[j]);
								label.Text = "Devices Found...";
							}
							//Adding the devices in the listbox
							devlist.Items.Add(address[0] + ":" + address[1] + ":" + address[2] + ":" +
								address[3] + ":" + address[4] + ":" + address[5]);

						}
						devFound = true;
					}
					else
						label.Text = "No device found in the vicinity";
				}
				else
				{
					err = "Device search failed";//Device Inquiry failed		
					label.Text = err;
					writeLog(err);		
				}
			}
			else
				label.Text = "Bluetooth not initialized";				
		}

		// Searches the SPP services in the selected Bluetooth device
		private void servsearch_Click(object sender, System.EventArgs e)
		{
			bool retVal = false;
			label.Text = " ";
			if(devFound)
			{
				label.Text = "Searching for services....";

				deviceIndex = devlist.SelectedIndex;//Save the index of the selected device from the devices array
				if (deviceIndex == -1)
					label.Text = "Select a Device";
				else
				{
					BT_DEVICE device = devices[deviceIndex];//Fetching the selected device from the devices array
					BT_UUID newuuid = new BT_UUID();
					newuuid.length = 2;
					newuuid.uuid = new byte[16];// UUID for SPP
					newuuid.uuid[0] = 0x11;
					newuuid.uuid[1] = 0x01;

					ushort numServices;
					services = new BT_SERVICE[2];
					for (int i = 0; i < 2; i++)
					{
						services[i] = new BT_SERVICE();
						services[i].serviceName = new byte[255];
					}
  
					// Call the SDK Api to find the services of the selected device
					retVal = bTCore.SPPGetRemoteServices(device, newuuid, ref services, 2, out numServices);

					devlist.Items.Clear();
					if (retVal)
					{
						// searvice search sucess.Let us check whether we got atleast
						// one service.
						sw.WriteLine("Service search success");
						if (numServices > 0)
						{
							for (int j = 0; j < numServices; j++)
							{
								System.Text.ASCIIEncoding enc = new System.Text.ASCIIEncoding();
								string nname = enc.GetString(services[j].serviceName, 0, services[j].serviceName.Length);

								devlist.Items.Add(nname);
								label.Text = "Services Found...";
							}
							servFound = true;
                            devFound = false;
						}
						else
							label.Text = "No services found";
					}
					else
					{
						err = "Service search failed";
						label.Text = err;
						writeLog(err);		
					}
				}
			}
			else
				label.Text = "No devices selected";
				
		}

		// Establish Serial connection with the selected device
		private void sppconn_Click(object sender, System.EventArgs e)
		{
            if (!connected)
            {
                if (servFound)
			    {
				    label.Text = "Connecting....";

				    int serviceIndex = devlist.SelectedIndex;
				    if (serviceIndex == -1)
					    label.Text = "Select a Service";
				    else
				    {
					    BT_SERVICE selectedService = services[serviceIndex];
					    BT_DEVICE selectedDevice = devices[deviceIndex];
					    ushort frameSize = 1500;
					    string comPort = "COM4:";
                            IntPtr sppHandle = IntPtr.Zero;

					    //Creating serial Connection
                            sppHandle = bTCore.SPPConnect(selectedDevice, selectedService, ref frameSize, comPort);

                            if (sppHandle != IntPtr.Zero)
					    {
						    label.Text = "SPPConnect success";
						    sw.WriteLine("SPPConnect success");
                                g_sppHandle = sppHandle;
                                connected = true;
                                sppconn.Text = "SPP DisConnect";
                                
						    //Registering the event for SPP event notification
                       
                            //Setting the SPP Event Notification function for gettng the status of 
						    //the SPP Connection by invoking SPPEventInd
                                BTCore.SPPEventInd sppEventProc = new BTCore.SPPEventInd(SPPEventInd);
                                bTCore.SPPSetEventNotifyProc(sppHandle, sppEventProc);
					    }
					    else
					    {
						    err = "SPPConnect failed";
						    label.Text = err;
						    writeLog(err);		
					    }
				    }
			    }
			    else
				    label.Text = "Select a device and search for services";				
		    }
            else
            {               
                bool retVal = bTCore.SPPClose(g_sppHandle);
                if (retVal)
                {
                    label.Text = "SPPClose success";
                    sppconn.Text = "SPP Connect";
                    connected = false;
                }
                else
                {
                    err = "SPPClose failed";
                    sppconn.Text = "SPP Connect";
                    connected = false;
                    label.Text = err;
                    writeLog(err);
                }
            }
        }


        // Delegate for SPP connection notifications......
        static void SPPEventInd(IntPtr sppHandle, uint sppevent)
        {
            if (BTSerial.myForm.InvokeRequired)
            {
                // we were called on a separate thread
                // marshal the call to the user interface thread
                BTSerial.myForm.Invoke(new BTCore.SPPEventInd(SPPEventInd), 
                    new object[] { sppHandle, sppevent });
            }
            else
            {
                if (sppevent == BTCore.EVENT_DISCONNECT)
                {
  
                    BTSerial.myForm.label.Text = "Connection closed by peer";
                    myForm.connected = false;
                    myForm.sppconn.Text = "SPP Connect";
                    MessageBox.Show("Connection Terminated");
   
                }
                else if (sppevent == BTCore.EVENT_COM_OPENED)
                {
                    myForm.label.Text = "The in-bound COM port was opened by an application.";
                    MessageBox.Show("The in-bound COM port was opened by an application");
                }
                else if (sppevent == BTCore.EVENT_COM_CLOSED)
                {
                    myForm.label.Text = "The in-bound COM port was closed by an application.";
                    MessageBox.Show("The in-bound COM port was closed by an application");
                }
            }
        }


		// Delegate for Security notifications......
        // Passkey is hardcoded as "00". The developer can modify it with option for 
        // asking from the user.
        static void SecurityNotifyProc(byte type, BT_DEVICE btDevice, BT_SERVICE service)
        {
            BTCore bTCore = new BTCore();
    
            // If you want to update the UI components such as label, you need to 
            // uncomment the following block. In that case, the blocking methods such
            //  as SPPConnect Should be called in a separate thread.

            /*   if (BTSerial.myForm.InvokeRequired)
            {
                // we were called on a separate thread
                // marshal the call to the user interface thread
                BTSerial.myForm.Invoke(new BTCore.SecurityNotifyProc(SecurityNotifyProc),
                    new object[] { type, btDevice, service });
            }
            else
          */
            {
                // Passkey Request
                if (type == BTCore.AUTHENTICATE)
                {
                    string passkey = "00";
                    sbyte length = 2;

                    MessageBox.Show("PassKey Request- sent hardcoded value");
                    if (bTCore.GAPAcceptPasskeyReq(btDevice.bdAddress, passkey, length, true))
                    {
                       // myForm.label.Text = "GAPAcceptPasskeyReq success";
                    }
                    else
                    {
                        string err = "GAPAcceptPasskeyReq failed";
                        // myForm.label.Text = err;
                        myForm.writeLog(err);
                    }
                }
                // Pairing Success
                else if (type == BTCore.PAIRING_SUCCESS)
                {
                    string err = "Pairing Success";
                    // myForm.label.Text = err;
                    myForm.writeLog(err);
                }
                // Pairing Failed
                else if (type == BTCore.PAIRING_FAILED)
                {
                    string err = "Pairing failure";
                    // myForm.label.Text = err;
                    myForm.writeLog(err);
                }
                // Service Autherization Req
                else if (type == BTCore.AUTHORIZE)
                {
                    // myForm.label.Text = "In AuthoriseRequest";

                    if (bTCore.GAPAcceptAuthorizeReq(btDevice.bdAddress, service))
                    {
                        // myForm.label.Text = "GAPAcceptAuthorizeReq success";
                    }
                    else
                    {
                        string err = "GAPAcceptAuthorizeReq failed";
                        // myForm.label.Text = err;
                        myForm.writeLog(err);
                    }
                }
            }
        }

		private void BTSerial_Closed(object sender, System.EventArgs e)
		{			
			sw.Close();
		}	
		
		private void writeLog(string s)
		{
			uint errorCode = bTCore.BTGetErrorCode();
			string err = String.Format("{0:x2}", errorCode);							
			sw.WriteLine("{0} : {1}", s,err);
		}
	}
}
