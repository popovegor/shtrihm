/****************************************************************************
* FILE NAME	:	albtradio.h									 				*
*																 		    *
* MODULE	:	aveLink BT SDK For Windows CE - Utility						*
*																 		    *
* PURPOSE	:	The header file containing exported functions 				*
*				for initializing/deinitializing integrated bluetooth modules*
*				(For use with applications)									*
****************************************************************************/



#ifdef __cplusplus
#define ALBT_EXPORT extern "C" __declspec(dllexport)
#else
#define ALBT_EXPORT __declspec(dllexport)
#endif


// Exported functioms

ALBT_EXPORT BOOLEAN BTRadioOn();
ALBT_EXPORT BOOLEAN BTRadioOff();
ALBT_EXPORT BOOLEAN BTRadioStatus(DWORD *status);





