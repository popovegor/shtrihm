// TestStataionDlg.h : header file
//

#if !defined(AFX_TESTSTATAIONDLG_H__D323AD4F_3FBD_4BC9_A375_0F6E063E2046__INCLUDED_)
#define AFX_TESTSTATAIONDLG_H__D323AD4F_3FBD_4BC9_A375_0F6E063E2046__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CTestStataionDlg dialog

class CTestStataionDlg : public CDialog
{
// Construction
public:
	CTestStataionDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CTestStataionDlg();

	BOOL String2HexaStream(CString& strInput, BYTE* btOutBuff);	

// Dialog Data
	//{{AFX_DATA(CTestStataionDlg)
	enum { IDD = IDD_TESTSTATAION_DIALOG };
	CString	m_strMsg;
	CString	m_strWData;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestStataionDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	HANDLE m_hComHandle;

	bool m_bContinuousMode;

	// Generated message map functions
	//{{AFX_MSG(CTestStataionDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnOpen();
	afx_msg void OnBtnClose();
	afx_msg void OnBtnRead();
	afx_msg void OnBtnWrite();
	afx_msg void OnBtnClear();
	afx_msg void OnBtnMode();
	afx_msg void OnBtnInventory();
	//}}AFX_MSG

	afx_msg LRESULT OnUserMsg_EditUpdate(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTSTATAIONDLG_H__D323AD4F_3FBD_4BC9_A375_0F6E063E2046__INCLUDED_)
