//{{NO_DEPENDENCIES}}
// Microsoft eMbedded Visual C++ generated include file.
// Used by TestStataion.rc
//
#define IDD_TESTSTATAION_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDR_READ_WAVE                   131
#define IDC_BTN_OPEN                    1000
#define IDC_BTN_CLOSE                   1001
#define IDC_EDT_MSG                     1002
#define IDC_BTN_READ                    1003
#define IDC_EDT_WDATA                   1004
#define IDC_BTN_WRITE                   1005
#define IDC_BTN_CLEAR                   1006
#define IDC_BTN_MODE                    1007
#define IDC_MODE                        1008
#define IDC_BTN_INVENTORY               1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
