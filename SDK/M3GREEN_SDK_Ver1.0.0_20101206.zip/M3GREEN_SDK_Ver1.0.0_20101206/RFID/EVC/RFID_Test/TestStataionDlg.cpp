// TestStataionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TestStataion.h"
#include "TestStataionDlg.h"

#include "CAP20_Mobile.h"

#include <pkfuncs.h>

// RFID Type(0:Sleep�� ���� ���� ����(�ڷ�ǳ��), 1:Sleep�� �׻� LOW(HHE), 2:Sleep�� �׻� HIGH(), 0xFF:Type Read)
#define IOCTL_HAL_RFID_TYPE_SEL		CTL_CODE(FILE_DEVICE_HAL, 2117 , METHOD_BUFFERED, FILE_ANY_ACCESS)

// RFID Power Control(0:Low, 1:High, 0x2:Status)
#define IOCTL_HAL_RFID_PWR_SEL		CTL_CODE(FILE_DEVICE_HAL, 2118 , METHOD_BUFFERED, FILE_ANY_ACCESS)

// RFID Reset Control(0:Low, 1:High, 0x2:Status)
#define IOCTL_HAL_RFID_RST_SEL		CTL_CODE(FILE_DEVICE_HAL, 2119 , METHOD_BUFFERED, FILE_ANY_ACCESS)


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

HWND	g_hWnd = NULL;


int HandleRcvData(HANDLE hHandle, UCHAR *pucDataBuf)
{
	CString strAsc,	
		    strTemp;
	
	int i ;
/*
	switch(pucDataBuf[5])
	{
	case CMD_UNSELECT_READ:

		if(pucDataBuf[7] == 0x00)
		{
			int nLen = pucDataBuf[11]*4;
			for(i = 0 ; i < nLen ; i++)
			{
				strTemp.Format(L"%c", pucDataBuf[i + 12]);
				strAsc += strTemp;
			}	
			A
			sndPlaySound( L"\\windows\\decode.wav", SND_ASYNC );
			::SendMessage(g_hWnd, WM_USER + 100 , (WPARM)&strAsc, 0);		
		}
		break;

	case CMD_UNSELECT_WRITE:
		if(pucDataBuf[7] == 0x00 )
		{	
			strAsc = L"TRUE";
//			::SendMessage(g_hWndTarget, WM_COMM_READ, (WPARAM)&strAsc, 1);	
		}
		else
		{
			

			strAsc = L"FALSE";

			strTemp.Format(L"%02X", pucDataBuf[8]);
			strAsc += strTemp;

//			::SendMessage(g_hWndTarget, WM_COMM_READ, (WPARAM)&strAsc, 1);	
		}

		::SendMessage(g_hWnd, WM_USER + 100 , (WPARAM)&strAsc, 0);		
		break;
	}
*/

	strAsc +="I-Frame(";
	HINSTANCE hInst = AfxGetInstanceHandle();

		for(i = 0; i < (pucDataBuf[0]); i++)
		{
			strTemp.Format(L"%02X ", pucDataBuf[i +1]);
			if(i == 5 && strTemp != _T("01 "))
				PlaySound(MAKEINTRESOURCE(IDR_READ_WAVE), hInst, SND_RESOURCE|SND_ASYNC);
			strAsc += strTemp; 
		}
		strAsc += ")";


		::SendMessage(g_hWnd, WM_USER + 100, (WPARAM)&strAsc, 0);	


	memset(pucDataBuf, 0x00, pucDataBuf[0]);
	
	return 1;
}


/////////////////////////////////////////////////////////////////////////////
// CTestStataionDlg dialog

CTestStataionDlg::CTestStataionDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestStataionDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestStataionDlg)
	m_strMsg = _T("");
	m_strWData = _T("111111111111111");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_hComHandle = INVALID_HANDLE_VALUE;
	m_bContinuousMode = false;
	unsigned char ucSel = 1;

	KernelIoControl(IOCTL_HAL_RFID_PWR_SEL, &ucSel, 1, NULL, 0, NULL);
}

CTestStataionDlg::~CTestStataionDlg()
{
	if(m_hComHandle != INVALID_HANDLE_VALUE)
	{
		CAP20_CloseCommPort();
		m_hComHandle = INVALID_HANDLE_VALUE;	
	}	
	unsigned char ucSel = 0;
	KernelIoControl(IOCTL_HAL_RFID_PWR_SEL, &ucSel, 1, NULL, 0, NULL);
}


BOOL CTestStataionDlg::String2HexaStream(CString &strInput, BYTE *btOutBuff)
{
	memset(btOutBuff,0x00,sizeof(btOutBuff));

	int i, iDataLength;
	char ch;
	BYTE bt;

	CString strAsciiToHexa;

	//�빮�ڷ� ��ȯ
	strInput.MakeUpper();
	strInput.Replace(_T("<cr>"), _T("\r"));

	iDataLength = strInput.GetLength();

	if(iDataLength == 13){

		//��Ʈ���� ���� �ڵ�� ��ȯ �Ѵ�
		strAsciiToHexa.Format(L"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x"							
								,strInput[0]
								,strInput[1]
								,strInput[2]
								,strInput[3]
								,strInput[4]
								,strInput[5]
								,strInput[6]
								,strInput[7]
								,strInput[8]
								,strInput[9]
								,strInput[10]
								,strInput[11]
								,strInput[12]
								);	

	}else if(iDataLength == 14){

		//��Ʈ���� ���� �ڵ�� ��ȯ �Ѵ�
		strAsciiToHexa.Format(L"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x"							
								,strInput[0]
								,strInput[1]
								,strInput[2]
								,strInput[3]
								,strInput[4]
								,strInput[5]
								,strInput[6]
								,strInput[7]
								,strInput[8]
								,strInput[9]
								,strInput[10]
								,strInput[11]
								,strInput[12]
								,strInput[13]
								);	

	}else if(iDataLength == 15){

		//��Ʈ���� ���� �ڵ�� ��ȯ �Ѵ�
		strAsciiToHexa.Format(L"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x"							
								,strInput[0]
								,strInput[1]
								,strInput[2]
								,strInput[3]
								,strInput[4]
								,strInput[5]
								,strInput[6]
								,strInput[7]
								,strInput[8]
								,strInput[9]
								,strInput[10]
								,strInput[11]
								,strInput[12]
								,strInput[13]
								,strInput[14]								
								);	

	}else if(iDataLength == 16){

		//��Ʈ���� ���� �ڵ�� ��ȯ �Ѵ�
		strAsciiToHexa.Format(L"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x"							
								,strInput[0]
								,strInput[1]
								,strInput[2]
								,strInput[3]
								,strInput[4]
								,strInput[5]
								,strInput[6]
								,strInput[7]
								,strInput[8]
								,strInput[9]
								,strInput[10]
								,strInput[11]
								,strInput[12]
								,strInput[13]
								,strInput[14]
								,strInput[15]
								);	

	}else{

		AfxMessageBox(L"RFID tag length is not match");
		return FALSE;	

	}
		
	for( i=0 ; i < (iDataLength*2) ; i++ ){

		ch = (BYTE)strAsciiToHexa[i];
		
		if(ch >= '0' && ch <= '9'){
			bt = (ch -'0');
		}else if(ch >= 'A' && ch <= 'F'){
			bt = (ch -'A')+10;
		}else if(ch >= 'a' && ch <= 'f'){
			bt = (ch -'a')+10;
		}else{
			AfxMessageBox(L"Can not change hexa code");
			return FALSE;
		}
		
		if(!(i%2))
		{
			btOutBuff[int(i/2)] = bt << 4;
		}
		else
		{
			btOutBuff[int(i/2)] = BYTE(btOutBuff[int(i/2)] | bt); 
		}

		
	}	

	return TRUE;
}


void CTestStataionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestStataionDlg)
	DDX_Text(pDX, IDC_EDT_MSG, m_strMsg);
	DDX_Text(pDX, IDC_EDT_WDATA, m_strWData);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTestStataionDlg, CDialog)
	//{{AFX_MSG_MAP(CTestStataionDlg)
	ON_BN_CLICKED(IDC_BTN_OPEN, OnBtnOpen)
	ON_BN_CLICKED(IDC_BTN_CLOSE, OnBtnClose)
	ON_BN_CLICKED(IDC_BTN_READ, OnBtnRead)
	ON_BN_CLICKED(IDC_BTN_WRITE, OnBtnWrite)
	ON_BN_CLICKED(IDC_BTN_CLEAR, OnBtnClear)
	ON_BN_CLICKED(IDC_BTN_MODE, OnBtnMode)
	ON_BN_CLICKED(IDC_BTN_INVENTORY, OnBtnInventory)
	//}}AFX_MSG_MAP

	ON_MESSAGE(WM_USER + 100, OnUserMsg_EditUpdate)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestStataionDlg message handlers

BOOL CTestStataionDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	CenterWindow(GetDesktopWindow());	// center to the hpc screen

	// TODO: Add extra initialization here
	g_hWnd = this->m_hWnd;

	GetDlgItem(IDC_BTN_READ)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_WRITE)->EnableWindow(FALSE);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// �ؽ�Ʈ â�� Frame ���� �ѷ���
LRESULT CTestStataionDlg::OnUserMsg_EditUpdate(WPARAM wParam, LPARAM lParam)
{
	CString *tmpStr = (CString *)wParam;
	m_strMsg = *tmpStr + "\r\n" + m_strMsg ;
	UpdateData(FALSE);
	return 0;
}

void CTestStataionDlg::OnBtnOpen() 
{
	// TODO: Add your control notification handler code here
	//���� ������ �Ǿ����� �Ǵ� 
	if( m_hComHandle != INVALID_HANDLE_VALUE)
	{		
		AfxMessageBox(L"RFID port already open");	
		
	}
	
	//�ø��� ��Ʈ Open ���̹� ��ũ ���� COM5:
	if((m_hComHandle = CAP20_OpenCommPort((unsigned short*)LPCTSTR(L"COM8:"))) != INVALID_HANDLE_VALUE)
	{
		// Reader�� ���� ���� Frame ������ ó���� 
		//Callback Func ���� DLL���� �����͸� �޾� �ִ� �κ� 
		CAP20_RegisterAddRcvData(HandleRcvData);

		//BaudRate ���� 
		CAP20_ConfigCommPort(CBR_115200);	

		//���� �б� ��� ����	
		CAP20_SetConfig(0x01, 0x0b, 0x86);

		//Registry Save 	
		CAP20_SendCmd(0x01, 0x05);	

		GetDlgItem(IDC_BTN_READ)->EnableWindow(TRUE);
		GetDlgItem(IDC_BTN_WRITE)->EnableWindow(TRUE);
		
	}
	else
	{
		AfxMessageBox(_T("1fail"));
	}

	
}

void CTestStataionDlg::OnBtnClose() 
{
	// TODO: Add your control notification handler code here
	CAP20_CloseCommPort();
	m_hComHandle = INVALID_HANDLE_VALUE;

	GetDlgItem(IDC_BTN_READ)->EnableWindow(FALSE);
	GetDlgItem(IDC_BTN_WRITE)->EnableWindow(FALSE);

	UpdateData(FALSE);
	
}

void CTestStataionDlg::OnBtnRead() 
{
	// TODO: Add your control notification handler code here

	if(!CAP20_Unselect_Read(0x01, 0, 4))
	{

	}		
}

void CTestStataionDlg::OnBtnWrite() 
{
	// TODO: Add your control notification handler code here
	UpdateData();


	if( m_hComHandle == INVALID_HANDLE_VALUE ){
		AfxMessageBox(_T("Handle error") );
		return ;
	}
/*
	if( m_strWData.GetLength() < 13){
		AfxMessageBox(_T("RFID tag length is not match (more than 13)") );
		return ;
	}
	
	if( m_strWData.GetLength() > 16){
		AfxMessageBox(_T("RFID tag length is not match (less than 16)") );
		return ;
	}
	
*/
	int nWriteDataLen = 0;
	BYTE btWriteData[100];
	memset(btWriteData,0x00,sizeof(btWriteData));


	///////////////////buzz, continuous, 1send, FT//////////////////////////
	CAP20_SetConfig(0x01, 0x0b, 0x86);
	Sleep(50);                            
	
	
	nWriteDataLen = m_strWData.GetLength();
	String2HexaStream(m_strWData,btWriteData);	

	if(!CAP20_Unselect_Write(0x01, nWriteDataLen, btWriteData))
	{	
		AfxMessageBox(_T("Send Error : Write Cmd") );
/*
		CloseRFID();

		if(OpenRFID(g_hWndTarget)){

			memset(btWriteData,0x00,sizeof(btWriteData));

			nWriteDataLen = strWriteTag.GetLength();

			String2HexaStream(strWriteTag,btWriteData);

			if(!CAP20_Unselect_Write(0x01, nWriteDataLen, btWriteData)){
				return FALSE;
			}
			
		}
*/
	}

}

void CTestStataionDlg::OnBtnClear() 
{
	// TODO: Add your control notification handler code here
	m_strMsg = "";
	UpdateData(FALSE);
	
}

void CTestStataionDlg::OnBtnMode() 
{
	unsigned char ucSel = 0;
	KernelIoControl(IOCTL_HAL_RFID_PWR_SEL, &ucSel, 1, NULL, 0, NULL);

	Sleep(500);
	ucSel = 1;
	KernelIoControl(IOCTL_HAL_RFID_PWR_SEL, &ucSel, 1, NULL, 0, NULL);

	Sleep(1000);
	// TODO: Add your control notification handler code here
	if(m_bContinuousMode)
	{
		//����������
		SetDlgItemText(IDC_MODE, _T(""));
		UpdateData();
		CAP20_SetConfig(0x01, 0x0b, 0x86);
		Sleep(50);
	}
	else
	{
		//��Ƽ������
		SetDlgItemText(IDC_MODE, _T("Continuous"));
		UpdateData();
		CAP20_SetConfig(0x01, 0x1b, 0x04);
		Sleep(50);

		CAP20_SetConfig(0x01, 0x0b, 0x8c);
		Sleep(50);
	}
	m_bContinuousMode = !m_bContinuousMode; 
}

// Add 100930 jj 
void CTestStataionDlg::OnBtnInventory() 
{
	CAP20_Inventory(0x01);
}
