﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;


namespace RFID_Demo_net
{
    public class CAP20_mobile
    {

        #region define const

        public const uint READER_ID             = 0x01;

        public const uint FC_NONE               = 0x00;

        public const uint MAX_RX_SIZE           = 4096;
        public const uint RX_CMD_BUF            = 128;

        public const uint STX                   = 0x02;
        public const uint ETX                   = 0x03;
        public const uint DLE                   = 0x10;

        public const uint F_TYPE                = 0x01;

        //Register Configuration
        public const uint CMD_SET_CONFIG        = 0x01;
        public const uint CMD_GET_CONFIG        = 0x02;
        public const uint CMD_GET_PROTO_INFO    = 0x03;
        public const uint CMD_GET_FW_INFO       = 0x04;
        public const uint CMD_SAVE_CONFIG       = 0x05;
        public const uint CMD_SET_DEFAULT       = 0x06;

        //Command Frame
        public const uint CMD_REPORT_TAG_LIST   = 0x10;
        public const uint CMD_INVENTORY         = 0x12;
        public const uint CMD_SELECT            = 0x13;
        public const uint CMD_UNSELECT_READ     = 0x14;
        public const uint CMD_SELECT_READ       = 0x15;
        public const uint CMD_UNSELECT_WRITE    = 0x16;
        public const uint CMD_SELECT_WRITE      = 0x17;


        public const uint CMD_EAS               = 0x20;

        //Reader Management
        public const uint CMD_ENABLE            = 0x40;
        public const uint CMD_DISABLE           = 0x41;

        //EAS Status
        public const uint EAS_ENABLE            = 0x01;
        public const uint EAS_DISABLE           = 0x00;


        public const uint CRC_PRELOAD           = 0x00000000;
        public const uint CRC_POLY              = 0x00001021;

        
        // 13.56MHz
        public const uint TY_ISO15693           = 0x23;

               
        //
        // Baud rates at which the communication device operates
        //       
        public static UInt32 CBR_110 = 110;
        public static UInt32 CBR_300 = 300;
        public static UInt32 CBR_600 = 600;
        public static UInt32 CBR_1200 = 1200;
        public static UInt32 CBR_2400 = 2400;
        public static UInt32 CBR_4800 = 4800;
        public static UInt32 CBR_9600 = 9600;
        public static UInt32 CBR_14400 = 14400;
        public static UInt32 CBR_19200 = 19200;
        public static UInt32 CBR_38400 = 38400;
        public static UInt32 CBR_56000 = 56000;
        public static UInt32 CBR_57600 = 57600;
        public static UInt32 CBR_115200 = 115200;
        public static UInt32 CBR_128000 = 128000;
        public static UInt32 CBR_256000 = 256000;

        public struct OVERLAPPED {
            public static UInt32 Internal;
            public static UInt32 InternalHigh;
            public static UInt32 Offset;
            public static UInt32 OffsetHigh;
            public static IntPtr hEvent;
        };

        public struct CommPortInfo
        {
            public static IntPtr dev_hdl;            /* COM port device handle */
            public static byte port_num;           /* COM port number */
            public static byte is_connected;       /* TRUE if port ready for data transfer */
            public static byte byte_size;          /* 8 bits every time?? */
            public static byte flow_ctrl;          /* flow control used, if any */
            public static byte parity;             /* parity bit used? */
            public static byte num_stop_bits;      /* num of stop bits */
            public static UInt32 baud_rate;          /* baud rate */
            public static IntPtr thread_hdl;	        /* handle for rx buffer reading thread */
            public static UInt32 thread_id;          /* thread identifier for rx buffer reading thread */
            public static OVERLAPPED io_write;           /* info for asynchronous I/O write object */
            public static OVERLAPPED io_read;            /* info for asynchronous I/O read object */
            public static short len_in_buf;         /* length of input buffer */
            public static short len_out_buf;        /* length of output buffer */

        };

        #endregion

        #region function

        //--------------------------------------------------
        // Host의 app내의 리더 Frame을 처리하는 Callback func.
        // proto type.
        //
        // INPUT : 
        //  hHandle - OpenComPort에서 할당 받은 port handle
        //  *buf - 리더에서 전송해 주는 data buffer 포인터.
        //         첫번째byte는 전체 data buffer의 길이, 
        //         두번째 byte부터 실제 data 가 저장된다.
        //--------------------------------------------------
                                         // (HANDLE hHandle, UCHAR *buf);
        public delegate int FuncAddRcvData(IntPtr hHandle, IntPtr buf);
        //--------------------------------------------------
        // FUNCTION : CAP20_RegisterAddRcvData()
        //
        // DESCRIPTION : 
        //  Host의 app에서 리더에서 주는 Frame을 처리하는  
        //  Callback func.을 등록해 준다.
        //  이 함수는 리더와 통신이 되기전 먼저 실행 되어야 한다.
        //  리더에서 오는 모든 응답이나 tag data는 이 함수에서 처리된다.
        //
        // INPUT :
        //	*func - App 내의 태그 데이타를 처리하는 함수 포인터.
        //--------------------------------------------------
        [DllImport("CAP20_Mobile.dll")]         // (FuncAddRcvData *func);
        public static extern void CAP20_RegisterAddRcvData(FuncAddRcvData func);

        //---------------------------------------------------------------------------
        // FUNCTION : STRLIB_RegisterAppHandle()
        //
        // DESCRIPTION : ( [C#/ ]에서 사용)
        //  Host의 app에서 리더에서 주는 Frame을 받을   
        //  App Window Handle를 등록해 준다 .
        //  이 함수는 리더기로부터 데이터를 받기전에 먼저 실행 되어야 한다.
        //  리더에서 오는 모든 응답이나 tag data는 이 handle로 
        //  메세지를 보내게 된다.
        //
        // INPUT :
        //	hWnd - App. handle
        //---------------------------------------------------------------------------
        [DllImport("CAP20_Mobile.dll")]                 //(HWND hWnd);
        public static extern void CAP20_RegisterAppHandle(IntPtr hWnd);

        //--------------------------------------------------
        // FUNCTION : CAP20_OpenCommPort()
        //
        // DESCRIPTION :
        //  리더와 Host간의 시리얼 포트를 열어 준다.
        //  이 함수는 app가 시작되고 리더와의 통신을 하기위해서
        //  가장 먼전 실행 되어야 한다.
        //
        // INPUT :
        //	*pszPort_name - Port name
        //  dwRate - BaudRate (Default CBR_9600)
        // OUTPUT :
        //  Com port Handle, 실패시 Null
        //--------------------------------------------------
        [DllImport("CAP20_Mobile.dll")]             //(_TCHAR *port_name, DWORD dwRate = CBR_9600)
        public static extern IntPtr CAP20_OpenCommPort(string port_name, UInt32 dwRate);

        //--------------------------------------------------
        // FUNCTION : CAP20_CloseCommPort()
        //
        // DESCRIPTION :
        //	App 종료시 호출되어 할당된 모든 리소스를 release하도록 한다.
        //
        // OUTPUT :
        //  TRUE or FALSE
        //--------------------------------------------------
        [DllImport("CAP20_Mobile.dll")]
        public static extern int CAP20_CloseCommPort();

        //--------------------------------------------------
        // FUNCTION : CAP20_ConfigCommPort()
        //
        // DESCRIPTION :
        //  Host와 리더간 시리얼 통신 속도를 변경하기 위해 사용한다.
        //
        // INPUT :
        //	dwBaudRate - 시리얼 통신 속도 (default:CBR_9600)
        // OUTPUT :
        //  TRUE or FALSE
        //--------------------------------------------------
        [DllImport("CAP20_Mobile.dll")]             // (DWORD dwBaudRate)
        public static extern int CAP20_ConfigCommPort(UInt32 dwBaudRate);


        //--------------------------------------------------
        // FUNCTION : CAP20_SetConfig()
        //
        // DESCRIPTION :
        //  리더의 configuration register의 특정 번지에 값을 설정한다.
        //
        // INPUT :
        //	ucReaderID - 리더 기기 번호
        //  ucRegAddr - configuration register 번지
        //  ucVal - register 설정을 위한 1byte 값
        // OUTPUT :
        //  TRUE or FALSE
        //  
        //--------------------------------------------------
        [DllImport("CAP20_Mobile.dll")] // (UCHAR ucReaderID, UCHAR ucRegAddr, UCHAR ucVal)
        public static extern bool CAP20_SetConfig(Byte cReaderID, Byte cRegAddr, Byte cVal);


        //--------------------------------------------------
        // FUNCTION : CAP20_GetConfig()
        //
        // DESCRIPTION :
        //  리더의 configuration register의 특정 번지 값을 읽는다.
        //
        // INPUT :
        //	ucReaderID - 리더 기기 번호
        //  ucRegAddr - configuration register 번지
        //  
        // OUTPUT :
        //  TRUE or FALSE
        //  
        //--------------------------------------------------
        [DllImport("CAP20_Mobile.dll")] // (UCHAR ucReaderID, UCHAR ucRegAddr)
        public static extern bool CAP20_GetConfig(Byte cReaderID, Byte cRegAddr);

        //--------------------------------------------------
        // FUNCTION : CAP20_SendCmd()
        //
        // DESCRIPTION :
        //  리더에 Get_Proto_Info, Get_FW_Info, Save config, Set default
        //  와 같은 command를 전송시 호출된다.
        //
        // INPUT :
        //	ucReaderID - 리더 기기 번호
        //  ucCmd - 전송할 command
        //  
        // OUTPUT :
        //	함수 수행결과를 TRUE/FALSE로 return
        //	
        //--------------------------------------------------
        [DllImport("CAP20_Mobile.dll")] // (UCHAR ucReaderID, UCHAR ucCmd)
        public static extern bool CAP20_SendCmd(Byte cReaderID, Byte cCmd);



        [DllImport("CAP20_M3.dll", EntryPoint = "M3CallBackTest")] // (UCHAR ucReaderID, UCHAR ucCmd)
        public static extern void CallBackTest();


        //*****************************************************************************************
        // Command Frame Function
        //*****************************************************************************************
        [DllImport("CAP20_Mobile.dll")] // (UCHAR ucReaderID)
        public static extern bool CAP20_Inventory(Byte cReaderID);

        //--------------------------------------------------
        // FUNCTION : CAP20_Unselect_Read()
        //
        // DESCRIPTION :
        //  리더에 태그 데이터 읽기를 요청할떄 쓰인다.
        //  ISO 15693 태그를 읽을 때만 쓴다
        //
        // INPUT :
        //	ucReaderID - 리더 기기 번호
        //  
        // OUTPUT :
        //	함수 수행결과를 TRUE/FALSE로 return
        //	
        // 참고_ 
        // Continuous Mode >> 
        //                    val[0] = 0x0b;
        //                    val[1] = 0x8c;
        //                    CAP20_SetConfig(0x01, val[0], val[1]);
        //  Not Continuous >>
        //                    val[0] = 0x0b;
        //                    val[1] = 0x86;
        //                    CAP20_SetConfig(0x01, val[0], val[1]);
        //--------------------------------------------------
        [DllImport("CAP20_Mobile.dll")] // (UCHAR ucReaderID, UCHAR ucStartBlock, UCHAR ucSize)
        public static extern bool CAP20_Unselect_Read(Byte cReaderID, Byte cStartblock, Byte cSize);

        //--------------------------------------------------
        // FUNCTION : CAP20_UnselectRead()
        //
        // DESCRIPTION :
        //  리더에 태그 데이터 읽기를 요청할떄 쓰인다.
        //
        // INPUT :
        //	ucReaderID - 리더 기기 번호
        //	ucOTDLen - pucOTD의 길이
        //	*pucOTD  - Parameter (CAP20 문서 참고)
        //  
        // OUTPUT :
        //	함수 수행결과를 TRUE/FALSE로 return
        //	
        // 참고_ 
        // 리더기의 응답은 등록된 콜백함수를 통해 확인 할 수 있다.
        //--------------------------------------------------
        [DllImport("CAP20_Mobile.dll")] // (UCHAR ucReaderID, UCHAR ucOTDLen, UCHAR *pucOTD)
        public static extern bool CAP20_UnselectRead(Byte cReaderID, Byte cOTDLen, Byte[] pucOTD);

        [DllImport("CAP20_Mobile.dll")] // (UCHAR ucReaderID, UCHAR ucLen, UCHAR* pucData)
        public static extern bool CAP20_Unselect_Write(Byte cReaderID, Byte ucLen, Byte[] pucData);

        //--------------------------------------------------
        // FUNCTION : CAP20_UnselectWrite()
        //
        // DESCRIPTION :
        //  태그에 데이터를 저장을 요청할 때 쓰인다.
        //
        // INPUT :
        //	ucReaderID - 리더 기기 번호
        //	ucOTDLen - *pucOTD 길이
        //	*pucOTD  - Parameter Data1(CAP20 문서 참고)
        //  
        // OUTPUT :
        //	함수 수행결과를 TRUE/FALSE로 return
        //	
        // 참고_ 
        // 리더기의 응답은 등록된 콜백함수를 통해 확인 할 수 있다.
        //--------------------------------------------------
        [DllImport("CAP20_Mobile.dll")] // (UCHAR ucReaderID, UCHAR ucOTDLen, UCHAR* pucOTD)
        public static extern bool CAP20_UnselectWrite(Byte cReaderID, Byte cOTDLen, IntPtr pucOTD);

        #endregion
    }
}
