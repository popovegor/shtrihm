﻿namespace RFID_Demo_net
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnOpen = new System.Windows.Forms.Button();
            this.BtnClose = new System.Windows.Forms.Button();
            this.BtnMode = new System.Windows.Forms.Button();
            this.BtnRead = new System.Windows.Forms.Button();
            this.BtnClear = new System.Windows.Forms.Button();
            this.BtnWrite = new System.Windows.Forms.Button();
            this.textBoxWData = new System.Windows.Forms.TextBox();
            this.textBoxMsg = new System.Windows.Forms.TextBox();
            this.label_Mode = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnOpen
            // 
            this.BtnOpen.Location = new System.Drawing.Point(14, 13);
            this.BtnOpen.Name = "BtnOpen";
            this.BtnOpen.Size = new System.Drawing.Size(98, 24);
            this.BtnOpen.TabIndex = 0;
            this.BtnOpen.Text = "Open";
            this.BtnOpen.Click += new System.EventHandler(this.BtnOpen_Click);
            // 
            // BtnClose
            // 
            this.BtnClose.Location = new System.Drawing.Point(118, 13);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(103, 24);
            this.BtnClose.TabIndex = 1;
            this.BtnClose.Text = "Close";
            this.BtnClose.Click += new System.EventHandler(this.BtnClose_Click);
            // 
            // BtnMode
            // 
            this.BtnMode.Location = new System.Drawing.Point(14, 43);
            this.BtnMode.Name = "BtnMode";
            this.BtnMode.Size = new System.Drawing.Size(98, 24);
            this.BtnMode.TabIndex = 2;
            this.BtnMode.Text = "Mode";
            this.BtnMode.Click += new System.EventHandler(this.BtnMode_Click);
            // 
            // BtnRead
            // 
            this.BtnRead.Location = new System.Drawing.Point(118, 43);
            this.BtnRead.Name = "BtnRead";
            this.BtnRead.Size = new System.Drawing.Size(103, 24);
            this.BtnRead.TabIndex = 3;
            this.BtnRead.Text = "Read";
            this.BtnRead.Click += new System.EventHandler(this.BtnRead_Click);
            // 
            // BtnClear
            // 
            this.BtnClear.Location = new System.Drawing.Point(14, 73);
            this.BtnClear.Name = "BtnClear";
            this.BtnClear.Size = new System.Drawing.Size(98, 24);
            this.BtnClear.TabIndex = 4;
            this.BtnClear.Text = "Clear";
            this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // BtnWrite
            // 
            this.BtnWrite.Location = new System.Drawing.Point(118, 73);
            this.BtnWrite.Name = "BtnWrite";
            this.BtnWrite.Size = new System.Drawing.Size(103, 24);
            this.BtnWrite.TabIndex = 5;
            this.BtnWrite.Text = "Write";
            this.BtnWrite.Click += new System.EventHandler(this.BtnWrite_Click);
            // 
            // textBoxWData
            // 
            this.textBoxWData.Location = new System.Drawing.Point(15, 128);
            this.textBoxWData.Name = "textBoxWData";
            this.textBoxWData.Size = new System.Drawing.Size(206, 23);
            this.textBoxWData.TabIndex = 6;
            // 
            // textBoxMsg
            // 
            this.textBoxMsg.AcceptsReturn = true;
            this.textBoxMsg.Location = new System.Drawing.Point(14, 159);
            this.textBoxMsg.Multiline = true;
            this.textBoxMsg.Name = "textBoxMsg";
            this.textBoxMsg.ReadOnly = true;
            this.textBoxMsg.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxMsg.Size = new System.Drawing.Size(207, 106);
            this.textBoxMsg.TabIndex = 8;
            this.textBoxMsg.Text = "textBox1";
            // 
            // label_Mode
            // 
            this.label_Mode.Location = new System.Drawing.Point(15, 103);
            this.label_Mode.Name = "label_Mode";
            this.label_Mode.Size = new System.Drawing.Size(206, 24);
            this.label_Mode.Text = "label1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(238, 295);
            this.Controls.Add(this.label_Mode);
            this.Controls.Add(this.textBoxMsg);
            this.Controls.Add(this.textBoxWData);
            this.Controls.Add(this.BtnWrite);
            this.Controls.Add(this.BtnClear);
            this.Controls.Add(this.BtnRead);
            this.Controls.Add(this.BtnMode);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.BtnOpen);
            this.Name = "Form1";
            this.Text = "RFID Demo net Ce";
            this.Closed += new System.EventHandler(this.Form1_Closed);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnOpen;
        private System.Windows.Forms.Button BtnClose;
        private System.Windows.Forms.Button BtnMode;
        private System.Windows.Forms.Button BtnRead;
        private System.Windows.Forms.Button BtnClear;
        private System.Windows.Forms.Button BtnWrite;
        private System.Windows.Forms.TextBox textBoxWData;
        private System.Windows.Forms.TextBox textBoxMsg;
        private System.Windows.Forms.Label label_Mode;
    }
}

