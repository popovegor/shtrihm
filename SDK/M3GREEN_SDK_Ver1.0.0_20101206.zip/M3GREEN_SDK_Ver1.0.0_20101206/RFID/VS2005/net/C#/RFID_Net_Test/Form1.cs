﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Runtime.InteropServices;

namespace RFID_Demo_net
{

    public partial class Form1 : Form
    {
        #region define
        // define
        public IntPtr m_hWnd = IntPtr.Zero;   // HWND

        private const uint FILE_DEVICE_HAL = 0x00000101;
        private const uint METHOD_BUFFERED = 0;
        private const uint FILE_ANY_ACCESS = 0;
        private IntPtr INVALID_HANDLE_VALUE = new IntPtr(-1);

        // Kernel
        [DllImport("Coredll.dll")]
        public static extern int KernelIoControl
                               (uint dwIoControlCode,
                               ref uint lpInBuf,
                               int nInBufSize,
                               out uint lpOutBuf,
                               int nOutBufSize,
                               ref uint lpBytesReturned);


        // RFID Type(0:Sleep시 현재 상태 유지(텔레풍켄), 1:Sleep시 항상 LOW(HHE), 2:Sleep시 항상 HIGH(), 0xFF:Type Read)
        public uint IOCTL_HAL_RFID_TYPE_SEL = CTL_CODE(FILE_DEVICE_HAL, 2117, METHOD_BUFFERED, FILE_ANY_ACCESS);

        // RFID Power Control(0:Low, 1:High, 0x2:Status)
        public uint IOCTL_HAL_RFID_PWR_SEL = CTL_CODE(FILE_DEVICE_HAL, 2118, METHOD_BUFFERED, FILE_ANY_ACCESS);

        // RFID Reset Control(0:Low, 1:High, 0x2:Status)
        public uint IOCTL_HAL_RFID_RST_SEL = CTL_CODE(FILE_DEVICE_HAL, 2119, METHOD_BUFFERED, FILE_ANY_ACCESS);

        // sound
        [DllImport("Coredll.dll", EntryPoint = "PlaySound", CharSet = CharSet.Auto)]
        private static extern int PlaySound(String pszSound, int hmod, int falgs);

        // Variable
        public string m_strMsg = "";
        public string m_strWData = "";

        public IntPtr m_ComHandle;    // HANDLE

        public bool m_bContinuousMode;

        public enum SND
        {
            SND_SYNC = 0x0000,/* play synchronously (default) */
            SND_ASYNC = 0x0001, /* play asynchronously */
            SND_NODEFAULT = 0x0002, /* silence (!default) if sound not found */
            SND_MEMORY = 0x0004, /* pszSound points to a memory file */
            SND_LOOP = 0x0008, /* loop the sound until next sndPlaySound */
            SND_NOSTOP = 0x0010, /* don't stop any currently playing sound */
            SND_NOWAIT = 0x00002000, /* don't wait if the driver is busy */
            SND_ALIAS = 0x00010000,/* name is a registry alias */
            SND_ALIAS_ID = 0x00110000, /* alias is a pre d ID */
            SND_FILENAME = 0x00020000, /* name is file name */
            SND_RESOURCE = 0x00040004, /* name is resource name or atom */
            SND_PURGE = 0x0040,  /* purge non-static events for task */
            SND_APPLICATION = 0x0080,  /* look for application specific */
        };
        #endregion

        #region Open and Close
        public static uint CTL_CODE(uint DeviceType, uint Function, uint Method, uint Access)
        {

            return ((DeviceType << 16) | (Access << 14) | (Function << 2) | Method);
        }


        public Form1()
        {
            InitializeComponent();

            uint unSel = 1, cout = 0, bytesReturn = 0;

            m_ComHandle = INVALID_HANDLE_VALUE;
            m_bContinuousMode = false;


            KernelIoControl(IOCTL_HAL_RFID_PWR_SEL, ref unSel, 1, out cout, 0, ref bytesReturn);
            label_Mode.Text = "Read mode: Normal";
            textBoxMsg.Text = "";
            textBoxWData.Text = "";
        }

        private void Form1_Closed(object sender, EventArgs e)
        {

            if (m_ComHandle != INVALID_HANDLE_VALUE)
            {
                CAP20_mobile.CAP20_CloseCommPort();
                m_ComHandle = INVALID_HANDLE_VALUE;
            }

            uint unSel = 0, cout = 0, bytesReturn = 0;

            KernelIoControl(IOCTL_HAL_RFID_PWR_SEL, ref unSel, 1, out cout, 0, ref bytesReturn);

        }

        /************************************************************************/
        /* 데이터를 받아서 처리하는 부분                                        */
        /************************************************************************/
        public int HandleRcvData(IntPtr hHandle, IntPtr pucDataBuf)
        {
  
            unsafe
            {
                Byte* btPtr = (Byte*)pucDataBuf.ToPointer();

                string strAsc, strTemp;
                int i;

                strAsc = "I-Frame(";

                for (i = 0; i < (btPtr[0]); i++)
                {
                    strTemp = string.Format("{0:X2} ", btPtr[i + 1]);

                    if (i == 5 && strTemp != "01 ")
                        PlaySound("\\windows\\decode.wav", 0, (int)(SND.SND_ASYNC | SND.SND_FILENAME | SND.SND_NOWAIT));

                    strAsc += strTemp;
                }
                strAsc += ")";

                this.ReadMsg(strAsc);
            }

            return 1;
            
        }

        // 콜백함수 데이터 읽기
        private delegate void myDelegate(string strString);

        public void ReadMsg(string strString)
        {
            if (this.textBoxMsg.InvokeRequired)
            {
                myDelegate d = new myDelegate(ReadMsg);
                this.Invoke(d, new object[] { strString });
            }
            else
            {
                this.textBoxMsg.Text = strString + "\r\n" + this.textBoxMsg.Text;
            }
 
        }


        private void BtnOpen_Click(object sender, EventArgs e)
        {
            if(m_ComHandle != INVALID_HANDLE_VALUE)
                MessageBox.Show("RFID Port already open","Open");

            m_ComHandle = CAP20_mobile.CAP20_OpenCommPort("COM8:", CAP20_mobile.CBR_9600);

            if (m_ComHandle != INVALID_HANDLE_VALUE)
            {

                CAP20_mobile.FuncAddRcvData fp = new CAP20_mobile.FuncAddRcvData(HandleRcvData); 
                                
                // Reader로 부터 받은 Frame 정보를 처리할 
                // Callback Func 설정 DLL에서 데이터를 받아 주는 부분 
                CAP20_mobile.CAP20_RegisterAddRcvData(fp);
                
                CAP20_mobile.CAP20_ConfigCommPort(CAP20_mobile.CBR_115200);

                //단일 읽기 모드 세팅	
                CAP20_mobile.CAP20_SetConfig(0x01, 0x0b, 0x86);

                //Registry Save 	
                CAP20_mobile.CAP20_SendCmd(0x01, 0x05);

                textBoxMsg.Text = "Open success\r\n" + textBoxMsg.Text;
            }
            else
            {
                textBoxMsg.Text = "Open fail\r\n" + textBoxMsg.Text;
            }

        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            textBoxMsg.Text = "Close port\r\n" + textBoxMsg.Text;

            CAP20_mobile.CAP20_CloseCommPort();
            m_ComHandle = INVALID_HANDLE_VALUE;
        }
        #endregion

        #region Read and Write
        private void BtnRead_Click(object sender, EventArgs e)
        {
            if (m_ComHandle != INVALID_HANDLE_VALUE)
            {
                textBoxMsg.Text = "Read tag\r\n" + textBoxMsg.Text;
                CAP20_mobile.CAP20_Unselect_Read(0x01, 0, 4);
            }
        }

        private void BtnWrite_Click(object sender, EventArgs e)
        {
            if(m_ComHandle == INVALID_HANDLE_VALUE)
            {
                MessageBox.Show("Handle error");
                return;
            }

            int nWriteDataLen = 0;
            Byte[] btWriteData;

            nWriteDataLen = textBoxWData.TextLength;

            string strText = textBoxWData.Text;
            btWriteData = new Byte[nWriteDataLen];

            // 데이터 유효성 검사
            bool bRet = IsValidateData(strText);

            if (bRet == false)
            {
                textBoxMsg.Text = "Invalidate data\r\n" + textBoxMsg.Text;
            }
            else
            {
                strText = strText.ToUpper();

                for (int i = 0; i < nWriteDataLen; i++)
                    btWriteData[i] = Convert.ToByte(strText[i]);

                ///////////////////buzz, continuous, 1send, FT//////////////////////////
                CAP20_mobile.CAP20_SetConfig(0x01, 0x0b, 0x86);
                Thread.Sleep(50);
                bRet = CAP20_mobile.CAP20_Unselect_Write(0x01, (Byte)nWriteDataLen, btWriteData);

                if (bRet == false)
                    textBoxMsg.Text = "Send error: Write Cmd\r\n" + textBoxMsg.Text;
            }                     


  
        }

        /************************************************************************/
        /* 데이터 유효성 검사: 0~f , 13~16 자리여부 검사                        */
        /************************************************************************/
        private bool IsValidateData(string strData)
        {
            int nLength = strData.Length;
            int i;
            char ch;
            bool result;

            if (nLength != 13 && nLength != 14 && nLength != 15 && nLength != 16)
                return false;
            else
                result = true;


            for (i = 0; i < nLength; i++)
            {
                ch = strData[i];

                if (ch >= '0' && ch <= '9') 
                    result = true;
                else if (ch >= 'A' && ch <= 'F')
                    result = true;
                else if (ch >= 'a' && ch <= 'f')
                    result = true;
                else
                    return false;
            }

            return result;
        }


        private void BtnClear_Click(object sender, EventArgs e)
        {
            textBoxMsg.Text = "";
            textBoxWData.Text = "";
        }

        private void BtnMode_Click(object sender, EventArgs e)
        {
            uint unSel = 0, cout = 0, bytesReturn = 0;

            KernelIoControl(IOCTL_HAL_RFID_PWR_SEL, ref unSel, 1, out cout, 0, ref bytesReturn);
            Thread.Sleep(500);

            unSel = 1;
            KernelIoControl(IOCTL_HAL_RFID_PWR_SEL, ref unSel, 1, out cout, 0, ref bytesReturn);
            Thread.Sleep(1000);

            if(m_bContinuousMode == true)
            {
                // 버버보스로
                label_Mode.Text = "Read mode: Normal";
                CAP20_mobile.CAP20_SetConfig(0x01, 0x0b, 0x86);
                Thread.Sleep(50);
            }
            else
            {
                // continuous
                label_Mode.Text = "Read mode: Continuous";
                CAP20_mobile.CAP20_SetConfig(0x01, 0x1b, 0x04);
                Thread.Sleep(50);

                CAP20_mobile.CAP20_SetConfig(0x01, 0x0b, 0x8c);
                Thread.Sleep(50);

            }
            m_bContinuousMode = !m_bContinuousMode;

        }


        #endregion
        
    }
}