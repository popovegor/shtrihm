﻿/********************************************************************
created		:	2010/03/08
file base	: 	TestCam_Net.exe

file ext	:	cs
author		:	Dong-Hyun, Eum(vision7901) - Applied Development Team

purpose		:	WinCE Imager 
Report		:	2010. 01. 12 [01/12/2010 vision7901] v1.0.0 - Imager 인수인계 
                2010. 03. 08 [03/08/2010 vision7901] v2.0.0 - 버전관리 시작
*********************************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using M3MobileImagerNet;
using System.Runtime.InteropServices;
using System.Reflection;
using System.IO;


namespace Cam2Net
{
	public partial class Form1 : Form
	{
		private Camera m_cam;
		public string m_strFolder = "\\Flash Disk";

		public Form1()
		{
			InitializeComponent();

			m_cam = new Camera();

			if (!m_cam.Connect(true))
			{
				MessageBox.Show("fail");
			}

			m_cam.Init(this.Handle, PictureBox.Handle);

		}

		private void Form1_Load(object sender, EventArgs e)
		{

		}

		private void StartButton_Click(object sender, EventArgs e)
		{
			m_cam.PreviewStart();
			StartButton.Enabled = false;
			StopButton.Enabled = true;
		}

		private void StopButton_Click(object sender, EventArgs e)
		{
			m_cam.PreviewStop();
			StopButton.Enabled = false;
			StartButton.Enabled = true;

		}

		private void CaptureButton_Click(object sender, EventArgs e)
		{
			DateTime time;
			time = DateTime.Now;

			string filename = m_strFolder + "\\" + time.Hour + time.Minute + time.Second;
			if (m_cam.option.nSaveFormat == 0)
				filename += ".bmp";
			else
				filename += ".jpg";

			m_cam.Capture(filename);

            System.IO.Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Cam2Net.Resources.camera77.wav");

            if (stream == null)
                MessageBox.Show("error");

            byte[] bStr = new Byte[stream.Length];
            stream.Read(bStr, 0, (int)stream.Length);

            PlaySound(bStr, IntPtr.Zero, SND.SND_ASYNC | SND.SND_MEMORY);
		}

		private void Infobutton_Click(object sender, EventArgs e)
		{
            Scanner.IMAGER_VERSION_INFO verinfo = new Scanner.IMAGER_VERSION_INFO();
            if (m_cam.GetInfo(ref verinfo))
            {
                About dlg = new About();
                dlg.m_cam = m_cam;

                dlg.ShowDialog();
            }
		}

		private void OptionButton_Click(object sender, EventArgs e)
		{
			OptionForm option = new OptionForm(m_cam);
			option.m_strFolder = m_strFolder;
			option.ShowDialog();
		}

        [DllImport("Coredll.dll", EntryPoint = "PlaySound", CharSet = CharSet.Auto)]
        //		private static extern int PlaySound(String pszSound, int hmod, int falgs);
        private static extern int PlaySound(byte[] pszSound, IntPtr hmod, SND falgs);

		public enum SND
		{
			SND_SYNC = 0x0000,/* play synchronously (default) */
			SND_ASYNC = 0x0001, /* play asynchronously */
			SND_NODEFAULT = 0x0002, /* silence (!default) if sound not found */
			SND_MEMORY = 0x0004, /* pszSound points to a memory file */
			SND_LOOP = 0x0008, /* loop the sound until next sndPlaySound */
			SND_NOSTOP = 0x0010, /* don't stop any currently playing sound */
			SND_NOWAIT = 0x00002000, /* don't wait if the driver is busy */
			SND_ALIAS = 0x00010000,/* name is a registry alias */
			SND_ALIAS_ID = 0x00110000, /* alias is a pre d ID */
			SND_FILENAME = 0x00020000, /* name is file name */
			SND_RESOURCE = 0x00040004, /* name is resource name or atom */
			SND_PURGE = 0x0040,  /* purge non-static events for task */
			SND_APPLICATION = 0x0080,  /* look for application specific */
		};

        private void Form1_Closing(object sender, CancelEventArgs e)
        {
            m_cam.Connect(false);
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if((e.KeyCode == Keys.F23) || (e.KeyCode == Keys.Return))
            {
                DateTime time;
                time = DateTime.Now;

                string filename = m_strFolder + "\\" + time.Hour + time.Minute + time.Second;
                if (m_cam.option.nSaveFormat == 0)
                    filename += ".bmp";
                else
                    filename += ".jpg";

                m_cam.Capture(filename);

                System.IO.Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Cam2Net.Resources.camera77.wav");

                if (stream == null)
                    MessageBox.Show("error");

                byte[] bStr = new Byte[stream.Length];
                stream.Read(bStr, 0, (int)stream.Length);

                PlaySound(bStr, IntPtr.Zero, SND.SND_ASYNC | SND.SND_MEMORY);
            }
        }
	}
}