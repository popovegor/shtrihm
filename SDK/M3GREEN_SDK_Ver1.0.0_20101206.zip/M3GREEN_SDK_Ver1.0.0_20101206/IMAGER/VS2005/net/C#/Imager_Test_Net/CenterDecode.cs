﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using M3MobileImagerNet;

namespace Scan3Net
{
    public partial class CenterDecode : Form
    {
        private Scanner m_scan;
        private Scanner.RECT m_rect;                                                                                                                                                                
        private bool m_EnableCenterDecoding;

        public CenterDecode(Scanner scan)
        {
            InitializeComponent();

            m_scan = scan;

            m_scan.GetDecodeCenteringWindow(SetupType.SETUP_CURRENT, ref m_EnableCenterDecoding, ref m_rect);

            cbEnableCenterDecoding.Checked = m_EnableCenterDecoding;
            nudLeft.Value = m_rect.left;
            nudTop.Value = m_rect.top;
            nudRight.Value = m_rect.right;
            nudBottom.Value = m_rect.bottom;

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            m_EnableCenterDecoding = cbEnableCenterDecoding.Checked;
            m_rect.left = (int)nudLeft.Value;
            m_rect.top = (int)nudTop.Value;
            m_rect.right = (int)nudRight.Value;
            m_rect.bottom = (int)nudBottom.Value;

            m_scan.SetDecodeCenteringWindow(m_EnableCenterDecoding, ref m_rect);
        }
    }
}