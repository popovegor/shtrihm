﻿namespace Scan3Net
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.MainMenu mainMenu1;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.ScanTabControl = new System.Windows.Forms.TabControl();
            this.ScanTab = new System.Windows.Forms.TabPage();
            this.btnCentering = new System.Windows.Forms.Button();
            this.InfoButton = new System.Windows.Forms.Button();
            this.ListCleanButton = new System.Windows.Forms.Button();
            this.ScanButton = new System.Windows.Forms.Button();
            this.ScanListView = new System.Windows.Forms.ListView();
            this.TypeColumn = new System.Windows.Forms.ColumnHeader();
            this.DataColumn = new System.Windows.Forms.ColumnHeader();
            this.SymbologyTab = new System.Windows.Forms.TabPage();
            this.SymbologyDefaultButton = new System.Windows.Forms.Button();
            this.SymbologyAllButton = new System.Windows.Forms.Button();
            this.SymbologyListView = new System.Windows.Forms.ListView();
            this.SymbologyIndex = new System.Windows.Forms.ColumnHeader();
            this.SymbologyBarCode = new System.Windows.Forms.ColumnHeader();
            this.OptionTab = new System.Windows.Forms.TabPage();
            this.cbScanningLightMode = new System.Windows.Forms.ComboBox();
            this.cbMultiDecodeMode = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SyncRadio = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.AsyncRadio = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.TimoutTextBox = new System.Windows.Forms.TextBox();
            this.OptionConfirm = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.ScanTabControl.SuspendLayout();
            this.ScanTab.SuspendLayout();
            this.SymbologyTab.SuspendLayout();
            this.OptionTab.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ScanTabControl
            // 
            this.ScanTabControl.Controls.Add(this.ScanTab);
            this.ScanTabControl.Controls.Add(this.SymbologyTab);
            this.ScanTabControl.Controls.Add(this.OptionTab);
            this.ScanTabControl.Location = new System.Drawing.Point(0, 0);
            this.ScanTabControl.Name = "ScanTabControl";
            this.ScanTabControl.SelectedIndex = 0;
            this.ScanTabControl.Size = new System.Drawing.Size(240, 274);
            this.ScanTabControl.TabIndex = 2;
            // 
            // ScanTab
            // 
            this.ScanTab.Controls.Add(this.label4);
            this.ScanTab.Controls.Add(this.btnCentering);
            this.ScanTab.Controls.Add(this.InfoButton);
            this.ScanTab.Controls.Add(this.ListCleanButton);
            this.ScanTab.Controls.Add(this.ScanButton);
            this.ScanTab.Controls.Add(this.ScanListView);
            this.ScanTab.Location = new System.Drawing.Point(4, 25);
            this.ScanTab.Name = "ScanTab";
            this.ScanTab.Size = new System.Drawing.Size(232, 245);
            this.ScanTab.Text = "Scan";
            // 
            // btnCentering
            // 
            this.btnCentering.Location = new System.Drawing.Point(117, 197);
            this.btnCentering.Name = "btnCentering";
            this.btnCentering.Size = new System.Drawing.Size(62, 30);
            this.btnCentering.TabIndex = 4;
            this.btnCentering.Text = "Centering";
            this.btnCentering.Click += new System.EventHandler(this.btnCentering_Click);
            // 
            // InfoButton
            // 
            this.InfoButton.Location = new System.Drawing.Point(179, 197);
            this.InfoButton.Name = "InfoButton";
            this.InfoButton.Size = new System.Drawing.Size(49, 30);
            this.InfoButton.TabIndex = 3;
            this.InfoButton.Text = "Info";
            this.InfoButton.Click += new System.EventHandler(this.InfoButton_Click);
            // 
            // ListCleanButton
            // 
            this.ListCleanButton.Location = new System.Drawing.Point(52, 197);
            this.ListCleanButton.Name = "ListCleanButton";
            this.ListCleanButton.Size = new System.Drawing.Size(65, 30);
            this.ListCleanButton.TabIndex = 2;
            this.ListCleanButton.Text = "Clear List";
            this.ListCleanButton.Click += new System.EventHandler(this.ListCleanButton_Click);
            // 
            // ScanButton
            // 
            this.ScanButton.Location = new System.Drawing.Point(6, 197);
            this.ScanButton.Name = "ScanButton";
            this.ScanButton.Size = new System.Drawing.Size(46, 30);
            this.ScanButton.TabIndex = 1;
            this.ScanButton.Text = "Scan";
            this.ScanButton.Click += new System.EventHandler(this.ScanButton_Click);
            // 
            // ScanListView
            // 
            this.ScanListView.Columns.Add(this.TypeColumn);
            this.ScanListView.Columns.Add(this.DataColumn);
            this.ScanListView.Location = new System.Drawing.Point(1, 3);
            this.ScanListView.Name = "ScanListView";
            this.ScanListView.Size = new System.Drawing.Size(231, 190);
            this.ScanListView.TabIndex = 0;
            this.ScanListView.View = System.Windows.Forms.View.Details;
            // 
            // TypeColumn
            // 
            this.TypeColumn.Text = "Type";
            this.TypeColumn.Width = 60;
            // 
            // DataColumn
            // 
            this.DataColumn.Text = "Data";
            this.DataColumn.Width = 150;
            // 
            // SymbologyTab
            // 
            this.SymbologyTab.Controls.Add(this.SymbologyDefaultButton);
            this.SymbologyTab.Controls.Add(this.SymbologyAllButton);
            this.SymbologyTab.Controls.Add(this.SymbologyListView);
            this.SymbologyTab.Location = new System.Drawing.Point(4, 25);
            this.SymbologyTab.Name = "SymbologyTab";
            this.SymbologyTab.Size = new System.Drawing.Size(232, 245);
            this.SymbologyTab.Text = "Symbology";
            // 
            // SymbologyDefaultButton
            // 
            this.SymbologyDefaultButton.Location = new System.Drawing.Point(120, 223);
            this.SymbologyDefaultButton.Name = "SymbologyDefaultButton";
            this.SymbologyDefaultButton.Size = new System.Drawing.Size(72, 20);
            this.SymbologyDefaultButton.TabIndex = 2;
            this.SymbologyDefaultButton.Text = "Default";
            this.SymbologyDefaultButton.Click += new System.EventHandler(this.SymbologyDefaultButton_Click);
            // 
            // SymbologyAllButton
            // 
            this.SymbologyAllButton.Location = new System.Drawing.Point(42, 223);
            this.SymbologyAllButton.Name = "SymbologyAllButton";
            this.SymbologyAllButton.Size = new System.Drawing.Size(72, 20);
            this.SymbologyAllButton.TabIndex = 1;
            this.SymbologyAllButton.Text = "All";
            this.SymbologyAllButton.Click += new System.EventHandler(this.SymbologyAllButton_Click);
            // 
            // SymbologyListView
            // 
            this.SymbologyListView.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.SymbologyListView.Columns.Add(this.SymbologyIndex);
            this.SymbologyListView.Columns.Add(this.SymbologyBarCode);
            this.SymbologyListView.FullRowSelect = true;
            this.SymbologyListView.Location = new System.Drawing.Point(1, 1);
            this.SymbologyListView.Name = "SymbologyListView";
            this.SymbologyListView.Size = new System.Drawing.Size(231, 216);
            this.SymbologyListView.TabIndex = 0;
            this.SymbologyListView.View = System.Windows.Forms.View.Details;
            this.SymbologyListView.ItemActivate += new System.EventHandler(this.SymbologyListView_ItemActivate);
            // 
            // SymbologyIndex
            // 
            this.SymbologyIndex.Text = "Index";
            this.SymbologyIndex.Width = 60;
            // 
            // SymbologyBarCode
            // 
            this.SymbologyBarCode.Text = "BarCode";
            this.SymbologyBarCode.Width = 120;
            // 
            // OptionTab
            // 
            this.OptionTab.Controls.Add(this.cbScanningLightMode);
            this.OptionTab.Controls.Add(this.cbMultiDecodeMode);
            this.OptionTab.Controls.Add(this.panel1);
            this.OptionTab.Controls.Add(this.OptionConfirm);
            this.OptionTab.Controls.Add(this.label1);
            this.OptionTab.Location = new System.Drawing.Point(4, 25);
            this.OptionTab.Name = "OptionTab";
            this.OptionTab.Size = new System.Drawing.Size(232, 245);
            this.OptionTab.Text = "Option";
            // 
            // cbScanningLightMode
            // 
            this.cbScanningLightMode.Items.Add("IllumAimerOff");
            this.cbScanningLightMode.Items.Add("IllumOnlyOn");
            this.cbScanningLightMode.Items.Add("AimerOnlyOn");
            this.cbScanningLightMode.Items.Add("IllumAimerOn");
            this.cbScanningLightMode.Location = new System.Drawing.Point(7, 119);
            this.cbScanningLightMode.Name = "cbScanningLightMode";
            this.cbScanningLightMode.Size = new System.Drawing.Size(202, 23);
            this.cbScanningLightMode.TabIndex = 9;
            // 
            // cbMultiDecodeMode
            // 
            this.cbMultiDecodeMode.Location = new System.Drawing.Point(7, 148);
            this.cbMultiDecodeMode.Name = "cbMultiDecodeMode";
            this.cbMultiDecodeMode.Size = new System.Drawing.Size(142, 20);
            this.cbMultiDecodeMode.TabIndex = 8;
            this.cbMultiDecodeMode.Text = "MultiDecodeMode";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.panel1.Controls.Add(this.SyncRadio);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.AsyncRadio);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.TimoutTextBox);
            this.panel1.Location = new System.Drawing.Point(7, 23);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(219, 86);
            // 
            // SyncRadio
            // 
            this.SyncRadio.Checked = true;
            this.SyncRadio.Location = new System.Drawing.Point(13, 3);
            this.SyncRadio.Name = "SyncRadio";
            this.SyncRadio.Size = new System.Drawing.Size(100, 20);
            this.SyncRadio.TabIndex = 1;
            this.SyncRadio.Text = "Sync Mode";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(35, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 20);
            this.label2.Text = "Sync Timeout";
            // 
            // AsyncRadio
            // 
            this.AsyncRadio.Location = new System.Drawing.Point(13, 60);
            this.AsyncRadio.Name = "AsyncRadio";
            this.AsyncRadio.Size = new System.Drawing.Size(100, 20);
            this.AsyncRadio.TabIndex = 2;
            this.AsyncRadio.TabStop = false;
            this.AsyncRadio.Text = "ASync Mode";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(162, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 20);
            this.label3.Text = "Secs";
            // 
            // TimoutTextBox
            // 
            this.TimoutTextBox.Location = new System.Drawing.Point(120, 23);
            this.TimoutTextBox.Name = "TimoutTextBox";
            this.TimoutTextBox.Size = new System.Drawing.Size(39, 23);
            this.TimoutTextBox.TabIndex = 4;
            this.TimoutTextBox.Text = "5";
            // 
            // OptionConfirm
            // 
            this.OptionConfirm.Location = new System.Drawing.Point(63, 171);
            this.OptionConfirm.Name = "OptionConfirm";
            this.OptionConfirm.Size = new System.Drawing.Size(114, 31);
            this.OptionConfirm.TabIndex = 6;
            this.OptionConfirm.Text = "Confirm";
            this.OptionConfirm.Click += new System.EventHandler(this.OptionConfirm_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(7, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 20);
            this.label1.Text = "Sync / Async";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(104, 228);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(136, 13);
            this.label4.Text = "Ver 2.0.0 (20100308)";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 294);
            this.Controls.Add(this.ScanTabControl);
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Closing += new System.ComponentModel.CancelEventHandler(this.Form1_Closing);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.ScanTabControl.ResumeLayout(false);
            this.ScanTab.ResumeLayout(false);
            this.SymbologyTab.ResumeLayout(false);
            this.OptionTab.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TabControl ScanTabControl;
		private System.Windows.Forms.TabPage ScanTab;
		private System.Windows.Forms.Button InfoButton;
		private System.Windows.Forms.Button ListCleanButton;
		private System.Windows.Forms.Button ScanButton;
		private System.Windows.Forms.ListView ScanListView;
		private System.Windows.Forms.ColumnHeader TypeColumn;
		private System.Windows.Forms.ColumnHeader DataColumn;
		private System.Windows.Forms.TabPage SymbologyTab;
		private System.Windows.Forms.Button SymbologyDefaultButton;
		private System.Windows.Forms.Button SymbologyAllButton;
		private System.Windows.Forms.ListView SymbologyListView;
		private System.Windows.Forms.ColumnHeader SymbologyIndex;
		private System.Windows.Forms.ColumnHeader SymbologyBarCode;
		private System.Windows.Forms.TabPage OptionTab;
		private System.Windows.Forms.Button OptionConfirm;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox TimoutTextBox;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.RadioButton AsyncRadio;
		private System.Windows.Forms.RadioButton SyncRadio;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox cbMultiDecodeMode;
        private System.Windows.Forms.ComboBox cbScanningLightMode;
        private System.Windows.Forms.Button btnCentering;
        private System.Windows.Forms.Label label4;

	}
}

