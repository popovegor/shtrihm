﻿namespace Scan3Net
{
	partial class FEan8Ean13
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.MainMenu mainMenu1;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.chbAddenda5 = new System.Windows.Forms.CheckBox();
            this.chbCheckSend = new System.Windows.Forms.CheckBox();
            this.chbAddenda2 = new System.Windows.Forms.CheckBox();
            this.chbEnable = new System.Windows.Forms.CheckBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.chbAddendaReq = new System.Windows.Forms.CheckBox();
            this.chbISBN = new System.Windows.Forms.CheckBox();
            this.chbAddendaSep = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(127, 211);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(72, 20);
            this.btnCancel.TabIndex = 19;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(21, 211);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(72, 20);
            this.btnOK.TabIndex = 18;
            this.btnOK.Text = "OK";
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // chbAddenda5
            // 
            this.chbAddenda5.Location = new System.Drawing.Point(132, 91);
            this.chbAddenda5.Name = "chbAddenda5";
            this.chbAddenda5.Size = new System.Drawing.Size(100, 20);
            this.chbAddenda5.TabIndex = 17;
            this.chbAddenda5.Text = "Addenda5";
            // 
            // chbCheckSend
            // 
            this.chbCheckSend.Location = new System.Drawing.Point(132, 60);
            this.chbCheckSend.Name = "chbCheckSend";
            this.chbCheckSend.Size = new System.Drawing.Size(90, 20);
            this.chbCheckSend.TabIndex = 16;
            this.chbCheckSend.Text = "CheckSend";
            // 
            // chbAddenda2
            // 
            this.chbAddenda2.Location = new System.Drawing.Point(7, 91);
            this.chbAddenda2.Name = "chbAddenda2";
            this.chbAddenda2.Size = new System.Drawing.Size(93, 20);
            this.chbAddenda2.TabIndex = 15;
            this.chbAddenda2.Text = "Addenda2";
            // 
            // chbEnable
            // 
            this.chbEnable.Location = new System.Drawing.Point(7, 60);
            this.chbEnable.Name = "chbEnable";
            this.chbEnable.Size = new System.Drawing.Size(67, 20);
            this.chbEnable.TabIndex = 14;
            this.chbEnable.Text = "Enable";
            // 
            // lblTitle
            // 
            this.lblTitle.Location = new System.Drawing.Point(17, 19);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(87, 20);
            // 
            // chbAddendaReq
            // 
            this.chbAddendaReq.Location = new System.Drawing.Point(7, 122);
            this.chbAddendaReq.Name = "chbAddendaReq";
            this.chbAddendaReq.Size = new System.Drawing.Size(100, 20);
            this.chbAddendaReq.TabIndex = 22;
            this.chbAddendaReq.Text = "AddendaReq";
            // 
            // chbISBN
            // 
            this.chbISBN.Location = new System.Drawing.Point(7, 153);
            this.chbISBN.Name = "chbISBN";
            this.chbISBN.Size = new System.Drawing.Size(100, 20);
            this.chbISBN.TabIndex = 23;
            this.chbISBN.Text = "ISBN";
            this.chbISBN.Visible = false;
            // 
            // chbAddendaSep
            // 
            this.chbAddendaSep.Location = new System.Drawing.Point(132, 122);
            this.chbAddendaSep.Name = "chbAddendaSep";
            this.chbAddendaSep.Size = new System.Drawing.Size(100, 20);
            this.chbAddendaSep.TabIndex = 24;
            this.chbAddendaSep.Text = "AddendaSep";
            // 
            // FEan8Ean13
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.chbAddendaSep);
            this.Controls.Add(this.chbISBN);
            this.Controls.Add(this.chbAddendaReq);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.chbAddenda5);
            this.Controls.Add(this.chbCheckSend);
            this.Controls.Add(this.chbAddenda2);
            this.Controls.Add(this.chbEnable);
            this.Name = "FEan8Ean13";
            this.Text = "FEan8Ean13";
            this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.CheckBox chbAddenda5;
		private System.Windows.Forms.CheckBox chbCheckSend;
		private System.Windows.Forms.CheckBox chbAddenda2;
		private System.Windows.Forms.CheckBox chbEnable;
		private System.Windows.Forms.Label lblTitle;
		private System.Windows.Forms.CheckBox chbAddendaReq;
		private System.Windows.Forms.CheckBox chbISBN;
		private System.Windows.Forms.CheckBox chbAddendaSep;
	}
}