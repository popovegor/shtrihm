﻿namespace Scan3Net
{
	partial class FMesa
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.MainMenu mainMenu1;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.chbEnableUMS = new System.Windows.Forms.CheckBox();
            this.chbEnableEMS = new System.Windows.Forms.CheckBox();
            this.chbEnable9MS = new System.Windows.Forms.CheckBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.chbEnable3MS = new System.Windows.Forms.CheckBox();
            this.chbEnableIMS = new System.Windows.Forms.CheckBox();
            this.chbEnable1MS = new System.Windows.Forms.CheckBox();
            this.chbEnable = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // chbEnableUMS
            // 
            this.chbEnableUMS.Location = new System.Drawing.Point(133, 131);
            this.chbEnableUMS.Name = "chbEnableUMS";
            this.chbEnableUMS.Size = new System.Drawing.Size(100, 20);
            this.chbEnableUMS.TabIndex = 34;
            this.chbEnableUMS.Text = "EnableUMS";
            // 
            // chbEnableEMS
            // 
            this.chbEnableEMS.Location = new System.Drawing.Point(8, 162);
            this.chbEnableEMS.Name = "chbEnableEMS";
            this.chbEnableEMS.Size = new System.Drawing.Size(100, 20);
            this.chbEnableEMS.TabIndex = 33;
            this.chbEnableEMS.Text = "EnableEMS";
            this.chbEnableEMS.Visible = false;
            // 
            // chbEnable9MS
            // 
            this.chbEnable9MS.Location = new System.Drawing.Point(8, 131);
            this.chbEnable9MS.Name = "chbEnable9MS";
            this.chbEnable9MS.Size = new System.Drawing.Size(100, 20);
            this.chbEnable9MS.TabIndex = 32;
            this.chbEnable9MS.Text = "Enable9MS";
            // 
            // lblTitle
            // 
            this.lblTitle.Location = new System.Drawing.Point(18, 28);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(87, 20);
            this.lblTitle.Text = "Aztec Mesa";
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(128, 220);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(72, 20);
            this.btnCancel.TabIndex = 31;
            this.btnCancel.Text = "Cancel";
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(22, 220);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(72, 20);
            this.btnOK.TabIndex = 30;
            this.btnOK.Text = "OK";
            // 
            // chbEnable3MS
            // 
            this.chbEnable3MS.Location = new System.Drawing.Point(133, 100);
            this.chbEnable3MS.Name = "chbEnable3MS";
            this.chbEnable3MS.Size = new System.Drawing.Size(100, 20);
            this.chbEnable3MS.TabIndex = 29;
            this.chbEnable3MS.Text = "Enable3MS";
            // 
            // chbEnableIMS
            // 
            this.chbEnableIMS.Location = new System.Drawing.Point(133, 69);
            this.chbEnableIMS.Name = "chbEnableIMS";
            this.chbEnableIMS.Size = new System.Drawing.Size(90, 20);
            this.chbEnableIMS.TabIndex = 28;
            this.chbEnableIMS.Text = "EnableIMS";
            // 
            // chbEnable1MS
            // 
            this.chbEnable1MS.Location = new System.Drawing.Point(8, 100);
            this.chbEnable1MS.Name = "chbEnable1MS";
            this.chbEnable1MS.Size = new System.Drawing.Size(93, 20);
            this.chbEnable1MS.TabIndex = 27;
            this.chbEnable1MS.Text = "Enable1MS";
            // 
            // chbEnable
            // 
            this.chbEnable.Location = new System.Drawing.Point(8, 69);
            this.chbEnable.Name = "chbEnable";
            this.chbEnable.Size = new System.Drawing.Size(67, 20);
            this.chbEnable.TabIndex = 26;
            this.chbEnable.Text = "Enable";
            // 
            // FMesa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.chbEnableUMS);
            this.Controls.Add(this.chbEnableEMS);
            this.Controls.Add(this.chbEnable9MS);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.chbEnable3MS);
            this.Controls.Add(this.chbEnableIMS);
            this.Controls.Add(this.chbEnable1MS);
            this.Controls.Add(this.chbEnable);
            this.Name = "FMesa";
            this.Text = "FMesa";
            this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.CheckBox chbEnableUMS;
		private System.Windows.Forms.CheckBox chbEnableEMS;
		private System.Windows.Forms.CheckBox chbEnable9MS;
		private System.Windows.Forms.Label lblTitle;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.CheckBox chbEnable3MS;
		private System.Windows.Forms.CheckBox chbEnableIMS;
		private System.Windows.Forms.CheckBox chbEnable1MS;
		private System.Windows.Forms.CheckBox chbEnable;
	}
}