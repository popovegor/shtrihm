﻿/********************************************************************
created		:	2010/03/08
file base	: 	M3ScanTest_Net.exe

file ext	:	cs
author		:	Dong-Hyun, Eum(vision7901) - Applied Development Team

purpose		:	WinCE Imager 
Report		:	2010. 01. 12 [01/12/2010 vision7901] v1.0.0 - Imager 인수인계 
                2010. 03. 08 [03/08/2010 vision7901] v2.0.0 - 버전관리 시작
*********************************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using M3MobileImagerNet;
using System.Runtime.InteropServices;
using System.Threading;		//	Sleep
using System.Reflection;
using System.IO;

namespace Scan3Net
{
	public partial class Form1 : Form
	{
		private Scanner m_scan;
		private ScannerControl ScanCtrl;
		private bool m_bKeyFlag;
		private bool m_bSyncMode;

		public Form1()
		{
			InitializeComponent();
			
			m_scan = new Scanner();
			ScanCtrl = new ScannerControl();

			m_bKeyFlag = false;

			ScanCtrl.ScannerDataEvent += new ScannerDataDelegate(OnScanData);
			ScanCtrl.ScannerTimeoutEvent += new ScannerTimeoutDelegate(OnScanTimeout);

			if (!m_scan.Connect(true))
				MessageBox.Show("fail");


            cbScanningLightMode.SelectedIndex = 2;

            m_scan.SetEnableDisableSymbology(SYMID.ID_ALL, true);

			SybologyInit();                 // Symbology ListView control item setting
          
			m_bSyncMode = true;

		}
		private void OnScanTimeout(object sender)
		{
			MessageBox.Show("Read Timeout");
		}
		private void OnScanData(object sender, ScannerDataArgs e)
		{

			m_scan.GetScanResult(ref m_scan.m_event, ref m_scan.m_msg);

			ListViewItem BarcodeItem = new ListViewItem();

			switch (m_scan.m_msg.chSymLetter)
			{
				case '<':
					BarcodeItem.Text = "Code 32";
					break;

				case 'l':
					BarcodeItem.Text = "Code 49";
					break;
				case 'M':
					BarcodeItem.Text = "Code 4CB";
					break;
				case 'w':
					BarcodeItem.Text = "DATA Matrix";
					break;
				case 'j':
					if (m_scan.m_msg.chSymModifier == '4')
						BarcodeItem.Text = "ISBT 128";
					else
						BarcodeItem.Text = "Code 128";
					break;
				case 'J':
					BarcodeItem.Text = "Japan POST";
					break;
				case 'K':
					BarcodeItem.Text = "KIX POST";
					break;
				case 'm':
					BarcodeItem.Text = "MATRIX 2of5";
					break;
				case 'x':
					BarcodeItem.Text = "MaxiCode";
					break;
				case 'g':
					BarcodeItem.Text = "MSI";
					break;
				case 'R':
					BarcodeItem.Text = "Micro PDF417";
					break;
				case 'L':
					BarcodeItem.Text = "Planet Code";
					break;
				case 'n':
					BarcodeItem.Text = "Plessey Code";
					break;
				case 'W':
					BarcodeItem.Text = "PosiCode";
					break;
				case 'P':
					BarcodeItem.Text = "Postnet";
					break;
				case 's':
					BarcodeItem.Text = "QR Code";
					break;
				case 'f':
					if (m_scan.m_msg.chCodeID == 'R')
						BarcodeItem.Text = "Straight 2of5 IATA";
					else
						BarcodeItem.Text = "Straight 2of5 Industria";
					break;
				case 'T':
					BarcodeItem.Text = "TCIF Linked Code39";
					break;
				case 't':
					BarcodeItem.Text = "Telepen";
					break;
				case '=':
					BarcodeItem.Text = "Trioptic Code";
					break;
				case 'A':
					BarcodeItem.Text = "Austria POST";
					break;
				case 'z':
					BarcodeItem.Text = "Aztec Code";
					break;
				case 'Z':
					BarcodeItem.Text = "Aztec Mesa";
					break;
				case 'B':
					BarcodeItem.Text = "British POST";
					break;
				case 'C':
					BarcodeItem.Text = "Canada POST";
					break;
				case 'Q':
					BarcodeItem.Text = "China POST";
					break;
				case 'q':
					BarcodeItem.Text = "Codablock F";
					break;
				case 'a':
					BarcodeItem.Text = "Codabar";
					break;

				case 'h':
					BarcodeItem.Text = "Code11";
					break;
				case 'o':
					BarcodeItem.Text = "Code 16K";
					break;
				case 'b':
					BarcodeItem.Text = "Code39";
					break;

				case 'D':
					BarcodeItem.Text = "EAN8";
					break;

				case 'd':
					BarcodeItem.Text = "EAN13";
					break;

				case 'e':
					BarcodeItem.Text = "Interleaved 2of5";
					break;

				case '?':
					BarcodeItem.Text = "KOREA POST";
					break;

				case 'r':
					BarcodeItem.Text = "PDF417";
					break;

				case 'c':
					BarcodeItem.Text = "UPC-A";
					break;

				case 'E':
					if (m_scan.m_msg.chCodeID == 'E')
						BarcodeItem.Text = "UPC-E";
					else
						BarcodeItem.Text = "UPC-E1";
					break;

				case 'i':
					BarcodeItem.Text = "Code93";
					break;
				case 'y':
					BarcodeItem.Text = "EAN/UCC Composite or Reduced Space Symbology";
					break;
				case 'I':
					BarcodeItem.Text = "GS1-128";
					break;
				case 'O':
					BarcodeItem.Text = "OCR";
					break;
				case 'N':
					BarcodeItem.Text = "UPU 4 State ID Tag";
					break;

				default:
					BarcodeItem.Text = "ETC";
					break;
			}

			BarcodeItem.SubItems.Add(m_scan.m_msg.pchMessage);	// data;
			ScanListView.Items.Insert(0, BarcodeItem);

            System.IO.Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Scan3Net.Resources.Scan_Sound.wav");

            if (stream == null)
                MessageBox.Show("error");

            byte[] bStr = new Byte[stream.Length];
            stream.Read(bStr, 0, (int)stream.Length);

            PlaySound(bStr, IntPtr.Zero, SND.SND_ASYNC | SND.SND_MEMORY);


		}

		private void ScanButton_Click(object sender, EventArgs e)
		{

			int nTimeout = int.Parse(TimoutTextBox.Text);
			m_scan.ScanRead(nTimeout, ref m_scan.m_msg);

		}

		private void ListCleanButton_Click(object sender, EventArgs e)
		{
			ScanListView.Items.Clear();
		}

		private void InfoButton_Click(object sender, EventArgs e)
		{
			Scanner.IMAGER_VERSION_INFO verinfo = new Scanner.IMAGER_VERSION_INFO();
			if (m_scan.GetInfo(ref verinfo))
			{
				About dlg = new About();
				dlg.m_scan = m_scan;

				dlg.ShowDialog();
			}

		}

		private void Form1_Load(object sender, EventArgs e)
		{
			//If a form is intended to process scan message, this function should be called 
			//when a form is initialized or activated.
			//메시지 받을 form을 등록합니다.
			ScanCtrl.RegisterRecieveForm();
		}

		private void Form1_KeyDown(object sender, KeyEventArgs e)
		{
//			MessageBox.Show("key : " + e.KeyValue);
            if (e.KeyCode == Keys.F22)
			{
				if (m_bKeyFlag == false)
				{
					m_bKeyFlag = true;
					Scanner.DECODE_MSG msg = new Scanner.DECODE_MSG();
					int nTimeout = int.Parse(TimoutTextBox.Text);
					m_scan.ScanRead(nTimeout, ref msg);
				}
			}
		}

		private void Form1_KeyUp(object sender, KeyEventArgs e)
		{
            if (e.KeyCode == Keys.F22)
			{
				if (m_bKeyFlag == true)
				{

					if (m_bSyncMode == false)
						m_scan.CancelIO();

					m_bKeyFlag = false;
				}
			}
		}
		
		private void OptionConfirm_Click(object sender, EventArgs e)
		{
            if (AsyncRadio.Checked == true)
                m_bSyncMode = false;

            int nTimeout = int.Parse(TimoutTextBox.Text);


            m_scan.MultiDecodeModeEnable(cbMultiDecodeMode.Checked);
            m_scan.SetScanningLightsMode((ScanIlluminat)(cbScanningLightMode.SelectedIndex));

		}

		private void SybologyInit()
		{
			ListViewItem data = new ListViewItem();

			data.Text = "1";
			data.SubItems.Add("Austria POST");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "2";
			data.SubItems.Add("Aztec Code");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "3";
			data.SubItems.Add("Aztec Mesa");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "4";
			data.SubItems.Add("British POST");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "5";
			data.SubItems.Add("Canada POST");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "6";
			data.SubItems.Add("China POST");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "7";
			data.SubItems.Add("Codabar");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "8";
			data.SubItems.Add("Codablock F");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "9";
			data.SubItems.Add("Code 11");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "10";
			data.SubItems.Add("Code 16K");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "11";
			data.SubItems.Add("Code 128");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "12";
			data.SubItems.Add("Code 32");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "13";
			data.SubItems.Add("Code 39");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "14";
			data.SubItems.Add("Code 49");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "15";
			data.SubItems.Add("Code 4CB");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "16";
			data.SubItems.Add("Code 93");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "17";
			data.SubItems.Add("DATA Matrix");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "18";
			data.SubItems.Add("EAN-8");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "19";
			data.SubItems.Add("EAN-13");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "20";
			data.SubItems.Add("EAN/UCC Composite");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "21";
			data.SubItems.Add("Interleaved 2of5");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "22";
			data.SubItems.Add("ISBT 128");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "23";
			data.SubItems.Add("Japan POST");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "24";
			data.SubItems.Add("KIX POST");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "25";
			data.SubItems.Add("Korea POST");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "26";
			data.SubItems.Add("MATRIX 2of5");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "27";
			data.SubItems.Add("MaxiCode");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "28";
			data.SubItems.Add("Micor PDF417");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "29";
			data.SubItems.Add("MSI");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "30";
			data.SubItems.Add("OCR");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "31";
			data.SubItems.Add("PDF417");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "32";
			data.SubItems.Add("Planet Code");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "33";
			data.SubItems.Add("Plessey Code");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "34";
			data.SubItems.Add("PosiCode");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "35";
			data.SubItems.Add("Postnet");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "36";
			data.SubItems.Add("QR Code");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "37";
			data.SubItems.Add("Reduced Space Symbology");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "38";
			data.SubItems.Add("Straight 2of5 Industria");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "39";
			data.SubItems.Add("Straight 2of5 IATA");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "40";
			data.SubItems.Add("TCIF Linked Code39");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "41";
			data.SubItems.Add("Telepen");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "42";
			data.SubItems.Add("Trioptic Code");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "43";
			data.SubItems.Add("UPC-A");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "44";
			data.SubItems.Add("UPC-A with COUPON");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "45";
			data.SubItems.Add("UPC-E");
			this.SymbologyListView.Items.Add(data);

			data = new ListViewItem();
			data.Text = "46";
			data.SubItems.Add("UPU 4 State ID Tag");
			this.SymbologyListView.Items.Add(data);

			int index;
			bool enable = false;

			for (index = 0; index < 46; index++)
			{
				m_scan.GetEnableDisableSymbology(SetupType.SETUP_CURRENT, m_scan.num[index], ref enable);
				//	enable : true : blue, disable: false : red
				SymbologyListView.Items[index].ForeColor = (enable) ? Color.Blue : Color.Red;
			}

		}

		private void SymbologyAllButton_Click(object sender, EventArgs e)
		{
			m_scan.SetEnableDisableSymbology(SYMID.ID_ALL, true);


			int index;
			bool enable = false;

			for (index = 0; index < 46; index++)
			{
				m_scan.GetEnableDisableSymbology(SetupType.SETUP_CURRENT, m_scan.num[index], ref enable);
				//	enable : true : blue, disable: false : red
				SymbologyListView.Items[index].ForeColor = (enable) ? Color.Blue : Color.Red;
			}
		}

        [DllImport("Coredll.dll", EntryPoint = "PlaySound", CharSet = CharSet.Auto)]
        //		private static extern int PlaySound(String pszSound, int hmod, int falgs);
        private static extern int PlaySound(byte[] pszSound, IntPtr hmod, SND falgs);


        public enum SND
        {
            SND_SYNC = 0x0000,/* play synchronously (default) */
            SND_ASYNC = 0x0001, /* play asynchronously */
            SND_NODEFAULT = 0x0002, /* silence (!default) if sound not found */
            SND_MEMORY = 0x0004, /* pszSound points to a memory file */
            SND_LOOP = 0x0008, /* loop the sound until next sndPlaySound */
            SND_NOSTOP = 0x0010, /* don't stop any currently playing sound */
            SND_NOWAIT = 0x00002000, /* don't wait if the driver is busy */
            SND_ALIAS = 0x00010000,/* name is a registry alias */
            SND_ALIAS_ID = 0x00110000, /* alias is a pre d ID */
            SND_FILENAME = 0x00020000, /* name is file name */
            SND_RESOURCE = 0x00040004, /* name is resource name or atom */
            SND_PURGE = 0x0040,  /* purge non-static events for task */
            SND_APPLICATION = 0x0080,  /* look for application specific */
        };

		private void Form1_Closing(object sender, CancelEventArgs e)
		{
			m_scan.Connect(false);
		}

		private void SymbologyDefaultButton_Click(object sender, EventArgs e)
		{
			m_scan.DefaultSymbology(SYMID.ID_ALL);

			int index;
			bool enable = false;
			for (index = 0; index < 46; index++)
			{
				m_scan.GetEnableDisableSymbology(SetupType.SETUP_CURRENT, m_scan.num[index], ref enable);
				//	enable : true : blue, disable: false : red
				SymbologyListView.Items[index].ForeColor = (enable) ? Color.Blue : Color.Red;
			}

		}

		private void SymbologyListView_ItemActivate(object sender, EventArgs e)
		{
			int index = SymbologyListView.FocusedItem.Index;

			switch (m_scan.num[index])
			{
				case SYMID.ID_AUSPOST:
				case SYMID.ID_BPO:
				case SYMID.ID_CANPOST:
				case SYMID.ID_JAPOST:
				case SYMID.ID_DUTCHPOST:
				case SYMID.ID_TLCODE39:
				case SYMID.ID_TRIOPTIC:
				case SYMID.ID_CODE32:
				case SYMID.ID_COUPONCODE:
				case SYMID.ID_ISBT:
				case SYMID.ID_USPS4CB:
				case SYMID.ID_IDTAG:
				case SYMID.ID_MESA:
					{
						FFlagsOnly FlagsOnly = new FFlagsOnly(m_scan.BarCodeName[index], m_scan.num[index], m_scan);
						FlagsOnly.ShowDialog();
					}
					break;

				case SYMID.ID_IATA25:
				case SYMID.ID_CODABLOCK:
				case SYMID.ID_AZTEC:
				case SYMID.ID_CODE49:
				case SYMID.ID_CODE128:
				case SYMID.ID_CODE93:
				case SYMID.ID_DATAMATRIX:
				case SYMID.ID_MAXICODE:
				case SYMID.ID_MICROPDF:
				case SYMID.ID_PDF417:
				case SYMID.ID_QR:
				case SYMID.ID_RSS:
				case SYMID.ID_STRT25:
				case SYMID.ID_MATRIX25:
				case SYMID.ID_PLESSEY:
				case SYMID.ID_CHINAPOST:
				case SYMID.ID_KOREAPOST:
				case SYMID.ID_CODE16K:
					{
						FFlagsRange FlagsRange = new FFlagsRange(m_scan.BarCodeName[index], m_scan.num[index], m_scan);
						FlagsRange.ShowDialog();
					}
					break;



				case SYMID.ID_CODABAR:
					{
						FCodabar codabar = new FCodabar(m_scan);
						codabar.ShowDialog();
					}
					break;

				case SYMID.ID_CODE11:
					{
						FCode11 code11 = new FCode11(m_scan);
						code11.ShowDialog();
					}
					break;


				case SYMID.ID_CODE39:
					{
						FCode39 code39 = new FCode39(m_scan);
						code39.ShowDialog();
					}
					break;

				case SYMID.ID_COMPOSITE:
					{
						FComposite composite = new FComposite(m_scan);
						composite.ShowDialog();
					}
					break;


				case SYMID.ID_EAN8:
				case SYMID.ID_EAN13:
					{
						FEan8Ean13 ean8ean13 = new FEan8Ean13(m_scan.BarCodeName[index], m_scan.num[index], m_scan);
						ean8ean13.ShowDialog();
					}
					break;


				case SYMID.ID_INT25:
					{
						FINT25 int25 = new FINT25(m_scan);
						int25.ShowDialog();
					}
					break;

				case SYMID.ID_OCR:
					{
						FOcr ocr = new FOcr(m_scan);
						ocr.ShowDialog();
					}
					break;

				case SYMID.ID_MSI:
					{
						FMSI msi = new FMSI(m_scan);
						msi.ShowDialog();
					}
					break;

				case SYMID.ID_PLANET:
				case SYMID.ID_POSTNET:
					{
						FPlanetPostnet planetpostnet = new FPlanetPostnet(m_scan.BarCodeName[index], m_scan.num[index], m_scan);
						planetpostnet.ShowDialog();
					}
					break;

				case SYMID.ID_POSICODE:
					{
						FPosicode posicode = new FPosicode(m_scan);
						posicode.ShowDialog();
					}
					break;

				case SYMID.ID_UPCA:
					{
						FUPCA upca = new FUPCA(m_scan.BarCodeName[index], m_scan.num[index], m_scan);
						upca.ShowDialog();
					}
					break;

				case SYMID.ID_UPCE0:
				case SYMID.ID_UPCE1:
					{
						FUPCE upce = new FUPCE(m_scan);
						upce.ShowDialog();
					}
					break;



				case SYMID.ID_TELEPEN:
					{
						FTelepen telepen = new FTelepen(m_scan);
						telepen.ShowDialog();
					}
					break;

			}
			bool enable = false;
			m_scan.GetEnableDisableSymbology(SetupType.SETUP_CURRENT, m_scan.num[index], ref enable);

			//	enable : true : blue, disable: false : red
			SymbologyListView.FocusedItem.ForeColor = (enable)?Color.Blue:Color.Red;

		}

        private void btnCentering_Click(object sender, EventArgs e)
        {
            CenterDecode CenterDecodeForm = new CenterDecode(m_scan);
            CenterDecodeForm.ShowDialog();
        }
			 

	}
}