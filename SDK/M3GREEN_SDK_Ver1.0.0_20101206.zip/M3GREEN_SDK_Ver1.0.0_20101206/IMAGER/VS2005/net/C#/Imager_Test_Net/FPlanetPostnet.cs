﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using M3MobileImagerNet;

namespace Scan3Net
{
	public partial class FPlanetPostnet : Form
	{
		private Scanner m_scan;
		private SYMID m_id;
		private Scanner.SymFlagsOnly m_config;

		public FPlanetPostnet(string BarCodeName, SYMID SymID, Scanner scan)
		{
			InitializeComponent();


			m_scan = scan;
			lblTitle.Text = BarCodeName;
			m_id = SymID;

			m_scan.ReadSymbologyConfig(SetupType.SETUP_CURRENT, m_id, ref m_config);

			chbEnable.Checked = (Scanner.SYM_ENABLE == (m_config.nFlags & Scanner.SYM_ENABLE)) ? true : false;
			chbCheckSend.Checked = (Scanner.SYM_CHECK_TRANSMIT == (m_config.nFlags & Scanner.SYM_CHECK_TRANSMIT)) ? true : false;
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			m_config.nFlags = (chbEnable.Checked) ? Scanner.SYM_ENABLE : 0;
			m_config.nFlags |= (chbCheckSend.Checked) ? Scanner.SYM_CHECK_TRANSMIT : 0;

			m_scan.WriteSymbologyConfig(m_id, m_config);
			DialogResult = DialogResult.OK;
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			DialogResult = DialogResult.Cancel;
		}
	}
}