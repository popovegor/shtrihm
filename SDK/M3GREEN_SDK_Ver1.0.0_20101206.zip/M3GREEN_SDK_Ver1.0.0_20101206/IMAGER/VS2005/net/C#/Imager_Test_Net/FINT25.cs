﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using M3MobileImagerNet;


namespace Scan3Net
{
	public partial class FINT25 : Form
	{
		private Scanner m_scan;
		private Scanner.SymFlagsRange m_config;

		public FINT25(Scanner scan)
		{
			InitializeComponent();

			m_scan = scan;
			m_scan.ReadSymbologyConfig(SetupType.SETUP_CURRENT, SYMID.ID_INT25, ref m_config);

			chbEnable.Checked = (Scanner.SYM_ENABLE == (m_config.nFlags & Scanner.SYM_ENABLE)) ? true : false;
			chbCheck.Checked = (Scanner.SYM_CHECK_ENABLE == (m_config.nFlags & Scanner.SYM_CHECK_ENABLE)) ? true : false;
			chbCheckSend.Checked = (Scanner.SYM_CHECK_TRANSMIT == (m_config.nFlags & Scanner.SYM_CHECK_TRANSMIT)) ? true : false;
			
			nudMaxLen.Value = m_config.nMaxLen;
			nudMinLen.Value = m_config.nMinLen;

		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			m_config.nFlags = (chbEnable.Checked) ? Scanner.SYM_ENABLE : 0;
			m_config.nFlags |= (chbCheck.Checked) ? Scanner.SYM_CHECK_ENABLE : 0;
			m_config.nFlags |= (chbCheckSend.Checked) ? Scanner.SYM_CHECK_TRANSMIT : 0;

			m_config.nMaxLen = (int)nudMaxLen.Value;
			m_config.nMinLen = (int)nudMinLen.Value;

			m_scan.WriteSymbologyConfig(SYMID.ID_INT25, m_config);
			DialogResult = DialogResult.OK;

		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
            DialogResult = DialogResult.Cancel;
		}
	}
}