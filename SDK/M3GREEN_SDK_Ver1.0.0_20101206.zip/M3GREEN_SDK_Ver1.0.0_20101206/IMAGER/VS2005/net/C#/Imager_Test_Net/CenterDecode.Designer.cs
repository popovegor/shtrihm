﻿namespace Scan3Net
{
    partial class CenterDecode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.nudTop = new System.Windows.Forms.NumericUpDown();
            this.nudBottom = new System.Windows.Forms.NumericUpDown();
            this.nudRight = new System.Windows.Forms.NumericUpDown();
            this.nudLeft = new System.Windows.Forms.NumericUpDown();
            this.cbEnableCenterDecoding = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.cbEnableCenterDecoding);
            this.panel1.Location = new System.Drawing.Point(19, 22);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(202, 199);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.nudTop);
            this.panel2.Controls.Add(this.nudBottom);
            this.panel2.Controls.Add(this.nudRight);
            this.panel2.Controls.Add(this.nudLeft);
            this.panel2.Location = new System.Drawing.Point(13, 42);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(176, 147);
            // 
            // nudTop
            // 
            this.nudTop.Location = new System.Drawing.Point(66, 49);
            this.nudTop.Maximum = new decimal(new int[] {
            750,
            0,
            0,
            0});
            this.nudTop.Name = "nudTop";
            this.nudTop.Size = new System.Drawing.Size(100, 24);
            this.nudTop.TabIndex = 3;
            // 
            // nudBottom
            // 
            this.nudBottom.Location = new System.Drawing.Point(66, 109);
            this.nudBottom.Maximum = new decimal(new int[] {
            751,
            0,
            0,
            0});
            this.nudBottom.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudBottom.Name = "nudBottom";
            this.nudBottom.Size = new System.Drawing.Size(100, 24);
            this.nudBottom.TabIndex = 2;
            this.nudBottom.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nudRight
            // 
            this.nudRight.Location = new System.Drawing.Point(66, 79);
            this.nudRight.Maximum = new decimal(new int[] {
            479,
            0,
            0,
            0});
            this.nudRight.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudRight.Name = "nudRight";
            this.nudRight.Size = new System.Drawing.Size(100, 24);
            this.nudRight.TabIndex = 1;
            this.nudRight.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nudLeft
            // 
            this.nudLeft.Location = new System.Drawing.Point(66, 19);
            this.nudLeft.Maximum = new decimal(new int[] {
            478,
            0,
            0,
            0});
            this.nudLeft.Name = "nudLeft";
            this.nudLeft.Size = new System.Drawing.Size(100, 24);
            this.nudLeft.TabIndex = 0;
            // 
            // cbEnableCenterDecoding
            // 
            this.cbEnableCenterDecoding.Location = new System.Drawing.Point(12, 6);
            this.cbEnableCenterDecoding.Name = "cbEnableCenterDecoding";
            this.cbEnableCenterDecoding.Size = new System.Drawing.Size(176, 20);
            this.cbEnableCenterDecoding.TabIndex = 0;
            this.cbEnableCenterDecoding.Text = "Enable Center Decoding";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(24, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 20);
            this.label1.Text = "Centered Decoding";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(11, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 20);
            this.label2.Text = "Left";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(11, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 20);
            this.label3.Text = "Top";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(11, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 20);
            this.label4.Text = "Right";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(11, 112);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 20);
            this.label5.Text = "Bottom";
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(28, 227);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(89, 32);
            this.btnOK.TabIndex = 2;
            this.btnOK.Text = "OK";
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(123, 227);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(89, 32);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "Cancel";
            // 
            // CenterDecode
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Menu = this.mainMenu1;
            this.Name = "CenterDecode";
            this.Text = "Center Barcode Setup";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox cbEnableCenterDecoding;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.NumericUpDown nudTop;
        private System.Windows.Forms.NumericUpDown nudBottom;
        private System.Windows.Forms.NumericUpDown nudRight;
        private System.Windows.Forms.NumericUpDown nudLeft;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
    }
}