﻿namespace Scan3Net
{
	partial class FCodabar
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.MainMenu mainMenu1;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.nudMinLen = new System.Windows.Forms.NumericUpDown();
            this.nudMaxLen = new System.Windows.Forms.NumericUpDown();
            this.chbEnable = new System.Windows.Forms.CheckBox();
            this.chbCheck = new System.Windows.Forms.CheckBox();
            this.chbCheckSend = new System.Windows.Forms.CheckBox();
            this.chbStartStop = new System.Windows.Forms.CheckBox();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(16, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 20);
            this.label1.Text = "Codabar";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(20, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 20);
            this.label2.Text = "Min Length:";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(16, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 20);
            this.label3.Text = "Max Length:";
            // 
            // nudMinLen
            // 
            this.nudMinLen.Location = new System.Drawing.Point(95, 42);
            this.nudMinLen.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.nudMinLen.Name = "nudMinLen";
            this.nudMinLen.Size = new System.Drawing.Size(100, 23);
            this.nudMinLen.TabIndex = 3;
            // 
            // nudMaxLen
            // 
            this.nudMaxLen.Location = new System.Drawing.Point(95, 81);
            this.nudMaxLen.Name = "nudMaxLen";
            this.nudMaxLen.Size = new System.Drawing.Size(100, 23);
            this.nudMaxLen.TabIndex = 4;
            // 
            // chbEnable
            // 
            this.chbEnable.Location = new System.Drawing.Point(13, 131);
            this.chbEnable.Name = "chbEnable";
            this.chbEnable.Size = new System.Drawing.Size(67, 20);
            this.chbEnable.TabIndex = 5;
            this.chbEnable.Text = "Enable";
            // 
            // chbCheck
            // 
            this.chbCheck.Location = new System.Drawing.Point(126, 131);
            this.chbCheck.Name = "chbCheck";
            this.chbCheck.Size = new System.Drawing.Size(62, 20);
            this.chbCheck.TabIndex = 6;
            this.chbCheck.Text = "Check";
            // 
            // chbCheckSend
            // 
            this.chbCheckSend.Location = new System.Drawing.Point(13, 169);
            this.chbCheckSend.Name = "chbCheckSend";
            this.chbCheckSend.Size = new System.Drawing.Size(90, 20);
            this.chbCheckSend.TabIndex = 7;
            this.chbCheckSend.Text = "CheckSend";
            // 
            // chbStartStop
            // 
            this.chbStartStop.Location = new System.Drawing.Point(126, 169);
            this.chbStartStop.Name = "chbStartStop";
            this.chbStartStop.Size = new System.Drawing.Size(100, 20);
            this.chbStartStop.TabIndex = 8;
            this.chbStartStop.Text = "StartStop";
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(20, 215);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(72, 20);
            this.btnOK.TabIndex = 12;
            this.btnOK.Text = "OK";
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(126, 215);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(72, 20);
            this.btnCancel.TabIndex = 13;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // FCodabar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.chbStartStop);
            this.Controls.Add(this.chbCheckSend);
            this.Controls.Add(this.chbCheck);
            this.Controls.Add(this.chbEnable);
            this.Controls.Add(this.nudMaxLen);
            this.Controls.Add(this.nudMinLen);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FCodabar";
            this.Text = "FCodabar";
            this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.NumericUpDown nudMinLen;
		private System.Windows.Forms.NumericUpDown nudMaxLen;
		private System.Windows.Forms.CheckBox chbEnable;
		private System.Windows.Forms.CheckBox chbCheck;
		private System.Windows.Forms.CheckBox chbCheckSend;
		private System.Windows.Forms.CheckBox chbStartStop;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
	}
}