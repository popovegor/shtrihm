﻿namespace Scan3Net
{
	partial class FCode11
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.MainMenu mainMenu1;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.chbCheck = new System.Windows.Forms.CheckBox();
            this.chbEnable = new System.Windows.Forms.CheckBox();
            this.nudMaxLen = new System.Windows.Forms.NumericUpDown();
            this.nudMinLen = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(133, 218);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(72, 20);
            this.btnCancel.TabIndex = 50;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(27, 218);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(72, 20);
            this.btnOK.TabIndex = 49;
            this.btnOK.Text = "OK";
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // chbCheck
            // 
            this.chbCheck.Location = new System.Drawing.Point(138, 147);
            this.chbCheck.Name = "chbCheck";
            this.chbCheck.Size = new System.Drawing.Size(90, 20);
            this.chbCheck.TabIndex = 48;
            this.chbCheck.Text = "Check";
            // 
            // chbEnable
            // 
            this.chbEnable.Location = new System.Drawing.Point(13, 147);
            this.chbEnable.Name = "chbEnable";
            this.chbEnable.Size = new System.Drawing.Size(67, 20);
            this.chbEnable.TabIndex = 47;
            this.chbEnable.Text = "Enable";
            // 
            // nudMaxLen
            // 
            this.nudMaxLen.Location = new System.Drawing.Point(105, 102);
            this.nudMaxLen.Name = "nudMaxLen";
            this.nudMaxLen.Size = new System.Drawing.Size(100, 23);
            this.nudMaxLen.TabIndex = 46;
            // 
            // nudMinLen
            // 
            this.nudMinLen.Location = new System.Drawing.Point(105, 63);
            this.nudMinLen.Name = "nudMinLen";
            this.nudMinLen.Size = new System.Drawing.Size(100, 23);
            this.nudMinLen.TabIndex = 45;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(26, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 20);
            this.label3.Text = "Max Length:";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(30, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 20);
            this.label2.Text = "Min Length:";
            // 
            // lblTitle
            // 
            this.lblTitle.Location = new System.Drawing.Point(26, 31);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(87, 20);
            this.lblTitle.Text = "Code11";
            // 
            // FCode11
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.chbCheck);
            this.Controls.Add(this.chbEnable);
            this.Controls.Add(this.nudMaxLen);
            this.Controls.Add(this.nudMinLen);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblTitle);
            this.Name = "FCode11";
            this.Text = "FCode11";
            this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.CheckBox chbCheck;
		private System.Windows.Forms.CheckBox chbEnable;
		private System.Windows.Forms.NumericUpDown nudMaxLen;
		private System.Windows.Forms.NumericUpDown nudMinLen;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label lblTitle;
	}
}