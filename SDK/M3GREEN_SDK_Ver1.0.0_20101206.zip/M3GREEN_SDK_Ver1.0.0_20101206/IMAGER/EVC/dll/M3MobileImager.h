// M3MobileImager.h : main header file for the M3MOBILEIMAGER DLL
//

#if !defined(AFX_M3MOBILEIMAGER_H__9C2ABC8E_CC44_4EBC_A186_18AB706D1F06__INCLUDED_)
#define AFX_M3MOBILEIMAGER_H__9C2ABC8E_CC44_4EBC_A186_18AB706D1F06__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// #ifndef __AFXWIN_H__
// 	#error include 'stdafx.h' before including this file for PCH
// #endif

#include "resource.h"		// main symbols




#define  WM_SCAN_DATA				WM_USER + 14534
#define  WM_STILL_COMPLETED		WM_USER + 14535



typedef enum {
	ID_AZTEC = 0,
	ID_MESA,
	ID_CODABAR,
	ID_CODE11,
	ID_CODE128,
	ID_CODE39,
	ID_CODE49,
	ID_CODE93,
	ID_COMPOSITE,
	ID_DATAMATRIX,
	ID_EAN8,
	ID_EAN13,
	ID_INT25,
	ID_MAXICODE,
	ID_MICROPDF,
	ID_OCR,
	ID_PDF417,
	ID_POSTNET,
	ID_QR,
	ID_RSS,
	ID_UPCA,
	ID_UPCE0,
	ID_UPCE1,
	ID_ISBT,
	ID_BPO,
	ID_CANPOST,
	ID_AUSPOST,
	ID_IATA25,
	ID_CODABLOCK,
	ID_JAPOST,
	ID_PLANET,
	ID_DUTCHPOST,
	ID_MSI,
	ID_TLCODE39,
	ID_TRIOPTIC,
	ID_CODE32,
	ID_STRT25,
	ID_MATRIX25,
	ID_PLESSEY,
	ID_CHINAPOST,
	ID_KOREAPOST,
	ID_TELEPEN,
	ID_CODE16K,
	ID_POSICODE,
	ID_COUPONCODE,
	ID_USPS4CB,
	ID_IDTAG,				//a
	ID_GS1_128,
	ID_GEN_CODE128,
	ID_ALL = 100
}ID_SYM;

typedef enum
{
	SETUP_DEFAULT = 0,
	SETUP_CURRENT,
}SetupType;

typedef struct _tagCamOption
{
	LONG		nTop;
	LONG		nLeft;
	LONG		nRight;
	LONG		nBottom;
	WORD		nSaveFormat;			// file Format		0: raw, 1: bmp, 2: jpg
	DWORD		nJpegQuality;		// Jpeg Quality
	DWORD		nWhiteValue;
	DWORD		nResolution;
	BOOL		bInvert;
} CAM_OPTION, *LPCAM_OPTION;

typedef enum
{
	BARCODE_EVENT=0,         // HHP_DECODE_MSG
	IMAGE_EVENT,             // HHP_IMAGE
	TEXT_MSG_EVENT,          // HHP_TEXT_MSG
	INTELIMG_BARCODE_EVENT,  // HHP_DECODE_MSG
	INTELIMG_IMAGE_EVENT,    // HHP_IMAGE
	TRIGGER_EVENT            // BOOL pointer (on/off) Notification of
} EventType_t, EVENT_TYPE, *PEVENT_TYPE;


typedef struct _tagDECODE_MSG
{
	DWORD   dwStructSize;                       // Size of decode structure.
	TCHAR   pchMessage[ 4096 ];    // decoded message data			
	TCHAR   chCodeID;                           // AIM Id of symbology
	TCHAR   chSymLetter;                        // HHP Id of symbology
	TCHAR   chSymModifier;                      // Modifier characters.
	DWORD   nLength;                            // length of the decoded message
} DECODE_MSG, *PDECODE_MSG;	//, DecodeMsg_t ;

#define MAX_VERSION_STRING_LEN          128
#define MAX_DEVICE_TYPE_STRING_LEN      64
#define MAX_MANUFACTURERS_ID_LEN        16


typedef struct _tagVERSION_INFO
{
	TCHAR   tcAPIRev[ MAX_VERSION_STRING_LEN ];             // SDK API version string
	TCHAR   tcDecoderRev[ MAX_VERSION_STRING_LEN ];         // Decoder Revision
	TCHAR   tcScanDriverRev[ MAX_VERSION_STRING_LEN ];      // Scan Driver Revision
	TCHAR  tcEtcInfo[1000];
	DWORD dwFirmwareVersion;        // Imager firmware version
	DWORD dwFirmwareCksum;
	DWORD dwEngineId;	
} IMAGER_VERSION_INFO, *PIMAGER_VERSION_INFO;



typedef struct __tagSymFlagsOnly
{
	DWORD dwFlags;//; OR of valid flags for the given symbology.
}SymFlagsOnly, *PSymFlagsOnly;

typedef struct __tagSymFlagsRange
{
	DWORD dwFlags; //OR of valid flags for the given symbology.
	DWORD dwMinLen; //Minimum length for valid barcode string for this symbology.
	DWORD dwMaxLen; //Maximum length for valid bar code string for this symbology.
} SymFlagsRange, *PSymFlagsRange;


#define SYM_ENABLE 0x00000001 //	Enable Symbology bit
#define SYM_CHECK_ENABLE 0x00000002	// Enable usage of check character.
#define SYM_CHECK_TRANSMIT 0x00000004 //Send check character.
#define SYM_START_STOP_XMIT 0x00000008 //Include the start and stop characters in the decoded result string.
#define SYM_ENABLE_APPEND_MODE 0x00000010 //Code39 append mode.
#define SYM_ENABLE_FULLASCII 0x00000020 //Enable Code39 Full ASCII.
#define SYM_NUM_SYS_TRANSMIT 0x00000040 //UPC-A/UPC-E Send Num Sys
#define SYM_2_DIGIT_ADDENDA 0x00000080 //Enable 2 digit Addenda (UPC and EAN).
#define SYM_5_DIGIT_ADDENDA 0x00000100 //Enable 5 digit Addenda (UPC and EAN).
#define SYM_ADDENDA_REQUIRED 0x00000200 //Only allow codes with addenda (UPC and EAN).
#define SYM_ADDENDA_SEPARATOR 0x00000400 //Include Addenda separator space in returned string.

#define SYM_EXPANDED_UPCE 0x00000800 //Extended UPC-E.

#define SYM_UPCE1_ENABLE 0x00001000 // UPC-E1 enable (use SYMBOLOGY_ENABLE for UPC-E0).

#define SYM_ENABLE_MESA_IMS 0x00020000 //Mesa IMS enable.
#define SYM_ENABLE_MESA_1MS 0x00040000 //Mesa 1MS enable.
#define SYM_ENABLE_MESA_3MS 0x00080000 //Mesa 3MS enable.
#define SYM_ENABLE_MESA_9MS 0x00100000 //Mesa 9MS enable.
#define SYM_ENABLE_MESA_UMS 0x00200000 //Mesa UMS enable.
#define SYM_ENABLE_MESA_EMS 0x00400000 //Mesa EMS enable.

#define SYM_TELEPEN_OLD_STYLE 0x04000000 //Telepen Old Style mode.:

#define SYM_COMPOSITE_UPC 0x00002000 //Enable UPC Composite codes.

#define SYM_POSICODE_LIMITED_1 0x08000000 //PosiCode Limited of 1
#define SYM_POSICODE_LIMITED_2 0x10000000 //PosiCode Limited of 2

#define SYM_MAXICODE_CARRIERMSGONLY 0x40000000 // maxicode option

#define SYM_EAN13_ISBN 0x80000000 // ean13 isbn




#define MAX_TEMPLATE_LEN 256
#define MAX_GROUP_H_LEN 256
#define MAX_GROUP_G_LEN 256
#define MAX_CHECK_CHAR_LEN 64

//---------------------------------------------------------------------
// Supported OCR Fonts
//---------------------------------------------------------------------
typedef enum {
	OCR_MODE_DISABLED = 0,
	OCR_MODE_A,
	OCR_MODE_B,
	OCR_MODE_MONEY,
	OCR_MODE_MICR_UNSUPPORTED,
} OCRMode;

//---------------------------------------------------------------------
// OCR directions
//---------------------------------------------------------------------
typedef enum {
	OCR_DIRECTION_LeftToRight = 0,
	OCR_DIRECTION_TopToBottom,
	OCR_DIRECTION_RightToLeft,
	OCR_DIRECTION_BottomToTop,
} OCRDirection;

//---------------------------------------------------------------------
// Image formats
//---------------------------------------------------------------------
typedef enum {
	RAW_BINARY = 0,
		RAW_GRAY = 1,
		TIFF_BINARY_COMP4 = 3,
		BMP_GRAY = 6,
} FileFormat;

typedef struct {
	unsigned int Xdimension; 					// in 1000s of mils, so 13.5 mil would be 13500 (accuracy is important for all math)
	unsigned int BarcodeHeight;					// in mils
	int XDistanceFromCenterBarcodeToCenterROI;	// in mils
	int YDistanceFromCenterBarcodeToCenterROI;	// in mils
	unsigned int RoiWidth;						// in mil
	unsigned int RoiHeight;						// in mil
	unsigned int RoiNaturalWidthInPixels;		//output width and height to come up with natural DPI ... also reported
	unsigned int RoiNaturalHeightInPixels;
	unsigned int NaturalDpi; 					// natural DPI (output of function call)
	unsigned int RoiDpi;						// generated DPI = Pixels per inch, if RoiDpi = 0, then use pixel setting exactly below
	unsigned int RoiWidthInPixels;				// alternative to DPI request is to request pixel dimensions of region of interest
	unsigned int RoiHeightInPixels;
	int ZoomLimit;								// zoom limit in terms of zoom factor
	FileFormat format;
} RegionOfInterest;


typedef struct __tagSymCodeOCR
{
	OCRMode ocrMode;				//OCR Enable/Mode structure.
	OCRDirection ocrDirection;	//OCR direction structure.
	TCHAR tcTemplate[ MAX_TEMPLATE_LEN ]; //Template for decoded data (��d�� - decimal, ��a�� - ASCII, ��l�� - letter, ��e�� - extended).
	TCHAR tcGroupG[ MAX_GROUP_H_LEN ]; //Group G character string.
	TCHAR tcGroupH[ MAX_GROUP_G_LEN ]; //Group H character string.
	TCHAR tcCheckChar[ MAX_CHECK_CHAR_LEN ]; //Check character string.
} SymCodeOCR, *PSymCodeOCR;

typedef BOOL (CALLBACK *EVENTCALLBACK)(EVENT_TYPE eventType,DWORD dwBytes );


typedef enum {
	SCAN_ILLUM_AIMER_OFF=0,			// Neither aimers nor illumination
		SCAN_ILLUM_ONLY_ON,					// Illumination only
		SCAN_AIMER_ONLY_ON,					// Aimers only
		SCAN_ILLUM_AIMER_ON,				// Both aimers and illumination
}ScanIlluminat;

#ifdef __cplusplus
extern "C" {
#endif
	

#if !defined( PASCAL )
#define PASCAL  __pascal
#endif
#if !defined( WINAPI )
#define WINAPI	PASCAL
#endif
#if !defined( M3MOBILEIMAGERAPI )
#define M3MOBILEIMAGERAPI	WINAPI
#endif
#define M3MOBILEIMAGER_API __declspec(dllimport)

class __declspec(dllexport) Imager
{
public:
//	BOOL VibrateOn(BOOL bOn);
	BOOL AimerOn(BOOL bOn);
	BOOL LightsOn(BOOL bOn);
	BOOL SetScanningLightsMode(ScanIlluminat nIllumMode );
	BOOL Connect(BOOL bOn);	//	On is TRUE, connect On is FALSE, disconnect
	BOOL GetErrorMessage();
	BOOL GetInfo(PIMAGER_VERSION_INFO info);
};

class __declspec(dllexport) IScan: public Imager
{
public :
	IScan();
	~IScan();

	BOOL CancelIO();

	BOOL ReadSymbologyConfig(SetupType SetupType, int nSymbol, PSymFlagsOnly config);	
	BOOL ReadSymbologyConfig(SetupType SetupType, int nSymbol, PSymFlagsRange config);
	BOOL ReadSymbologyConfig(SetupType SetupType, PSymCodeOCR config);

	BOOL WriteSymbologyConfig(int nSymbol, SymFlagsOnly config);	
	BOOL WriteSymbologyConfig(int nSymbol, SymFlagsRange config);
	BOOL WriteSymbologyConfig(SymCodeOCR config);
	
	BOOL SetScanMethods(HANDLE hEventHandle, HWND hWnd, EVENTCALLBACK EventCallback);
	BOOL GetScanResult(EventType_t *pEventType, PVOID pResultStruct);
	BOOL GetScanResultNet(EventType_t *pEventType, PDECODE_MSG pResultStruct);
	BOOL ScanRead(DWORD dwTimeout, PDECODE_MSG pmsg);

	BOOL DefaultSymbology(int nSymId);
	BOOL SetEnableDisableSymbology(int nSymId, BOOL bEnable);
	BOOL GetEnableDisableSymbology(SetupType SetupType, int nSymId, BOOL *pEnable);

	BOOL ScanRegisterWindow(HWND hWnd);	
	BOOL ScanLed(BOOL bOn);	
	
	BOOL SetDecodeCenteringWindow(BOOL bEnable, PRECT pIntersectRect);
	BOOL GetDecodeCenteringWindow(SetupType SetupType,	PBOOL pbEnabled,	PRECT pIntersectRect);
	
	BOOL MultiDecodeModeEnable(BOOL bEnable);

	
};

class __declspec(dllexport) ICam:public Imager
{
public :
	ICam();
	~ICam();

	BOOL CamInit(HWND hMainWnd, HWND hPictureWnd);
	BOOL CamUninit();
	BOOL PreviewStart();
	BOOL PreviewStop();

	BOOL CamImageStreamInit(WORD nSkip, RECT * imgRect, BOOL bFlip);
	BOOL CamImageStreamRead(PBYTE pImageBuffer, PDWORD pdwSize);
	BOOL CamImageStreamStart();
	BOOL CamImageStreamStop();
	BOOL CamGetLastImageSize(PWORD pnCols, PWORD pnRows, PDWORD pdwSize);	
	
	BOOL Capture(WCHAR  *FileFullName);
	BOOL CamGetOption(LPCAM_OPTION pOption);
	BOOL CamSetOption(CAM_OPTION Option);
};

M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI MultiDecodeModeEnable(BOOL bEnable);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI SetDecodeCenteringWindow(BOOL bEnable, PRECT pIntersectRect);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI GetDecodeCenteringWindow(SetupType SetupType,	PBOOL pbEnabled,	PRECT pIntersectRect);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI VibrateOn(BOOL bOn);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI AimerOn(BOOL bOn);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI LightsOn (BOOL bOn);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI CancelIO();
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI Connect(BOOL bOn);	//	On is TRUE, connect On is FALSE, disconnect
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI GetErrorMessage();
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI SetScanningLightsMode(ScanIlluminat nIllumMode );
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI SetScanMethods(HANDLE hEventHandle, HWND hWnd, EVENTCALLBACK EventCallback);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI GetScanResult(EventType_t *pEventType, PVOID pResultStruct);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI GetScanResultNet(EventType_t *pEventType, PDECODE_MSG pResultStruct);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI ScanRead(DWORD dwTimeout, PDECODE_MSG pmsg);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI DefaultSymbology(int nSymId);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI SetEnableDisableSymbology(int nSymId, BOOL bEnable);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI GetEnableDisableSymbology(SetupType SetupType, int nSymId, BOOL *pEnable);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI ScanRegisterWindow(HWND hWnd);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI GetInfo(PIMAGER_VERSION_INFO info);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI ScanLed(BOOL on);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI ReadSymbologyFlagsOnlyConfig(SetupType SetupType, int nSymbol, PSymFlagsOnly config);	
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI ReadSymbologyFlagsRangeConfig(SetupType SetupType, int nSymbol, PSymFlagsRange config);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI ReadSymbologyOCRConfig(SetupType SetupType, PSymCodeOCR config);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI WriteSymbologyFlagsOnlyConfig(int nSymbol, SymFlagsOnly config);	
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI WriteSymbologyFlagsRangeConfig(int nSymbol, SymFlagsRange config);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI WriteSymbologyOCRConfig(SymCodeOCR config);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI CamInit(HWND hMainWnd, HWND hPictureWnd);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI CamUninit();
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI PreviewStart();
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI PreviewStop();
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI Capture(WCHAR  *FileFullName);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI CamGetOption(LPCAM_OPTION pOption);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI CamSetOption(CAM_OPTION Option);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI CaptureRegionOfInterest(RegionOfInterest *pRoiCfg);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI GetImageData(DWORD dwNumberToRead, BYTE *pBuffer, DWORD *pNumBytesRead);
M3MOBILEIMAGER_API BOOL M3MOBILEIMAGERAPI WaitForDecode(DWORD dwTimeout, TCHAR *pchMessage, TCHAR *pchCodeID, TCHAR *pchAIMID, TCHAR *pchSymModifier, WORD *pnLength, BOOL (*fpCallBack) (void));

#ifdef __cplusplus
}
#endif // __cplusplus




//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_M3MOBILEIMAGER_H__9C2ABC8E_CC44_4EBC_A186_18AB706D1F06__INCLUDED_)
