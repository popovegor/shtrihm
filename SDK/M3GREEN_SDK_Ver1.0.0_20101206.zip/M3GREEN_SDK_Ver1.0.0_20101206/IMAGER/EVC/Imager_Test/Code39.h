#if !defined(AFX_CODE39_H__1C0ED488_E999_46DB_AE2F_C8F5AACE3D08__INCLUDED_)
#define AFX_CODE39_H__1C0ED488_E999_46DB_AE2F_C8F5AACE3D08__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Code39.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCode39 dialog

class CCode39 : public CDialog
{
// Construction
public:
	CCode39(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCode39)
	enum { IDD = IDD_CODE39 };
	CButton	m_chctlCheckSend;
	BOOL	m_bEnable;
	BOOL	m_bCheck;
	BOOL	m_bCheckSend;
	BOOL	m_bFullAscii;
	BOOL	m_bStartStop;
	BOOL	m_bAppend;
	DWORD	m_dwMaxLen;
	DWORD	m_dwMinLen;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCode39)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCode39)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnCheckCode39Check();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CODE39_H__1C0ED488_E999_46DB_AE2F_C8F5AACE3D08__INCLUDED_)
