#if !defined(AFX_POSICODE_H__BEE5FC15_792F_4C7F_B5F6_6002D293CADD__INCLUDED_)
#define AFX_POSICODE_H__BEE5FC15_792F_4C7F_B5F6_6002D293CADD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Posicode.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPosicode dialog

class CPosicode : public CDialog
{
// Construction
public:
	CPosicode(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPosicode)
	enum { IDD = IDD_POSICODE };
	CComboBox	m_cbctlLimit;
	DWORD	m_dwMaxLen;
	DWORD	m_dwMinLen;
	BOOL	m_bEnable;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPosicode)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPosicode)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_POSICODE_H__BEE5FC15_792F_4C7F_B5F6_6002D293CADD__INCLUDED_)
