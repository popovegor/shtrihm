#if !defined(AFX_MSI_H__015994E1_BCEE_4CEF_AD02_D94E066055A0__INCLUDED_)
#define AFX_MSI_H__015994E1_BCEE_4CEF_AD02_D94E066055A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Msi.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMsi dialog

class CMsi : public CDialog
{
// Construction
public:
	CMsi(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMsi)
	enum { IDD = IDD_MSI };
	BOOL	m_bCheckSend;
	BOOL	m_bEnable;
	DWORD	m_dwMaxLen;
	DWORD	m_dwMinLen;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMsi)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMsi)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MSI_H__015994E1_BCEE_4CEF_AD02_D94E066055A0__INCLUDED_)
