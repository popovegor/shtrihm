// Ean8Ean13.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "Ean8Ean13.h"

#include "M3MobileImager.h"
#include "MainSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEan8Ean13 dialog


CEan8Ean13::CEan8Ean13(CWnd* pParent /*=NULL*/)
	: CDialog(CEan8Ean13::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEan8Ean13)
	m_bAddenda2 = FALSE;
	m_bAddenda5 = FALSE;
	m_bAddendaReq = FALSE;
	m_bAddendaSep = FALSE;
	m_bCheckSend = FALSE;
	m_bEnable = FALSE;
	m_bISBN = FALSE;
	//}}AFX_DATA_INIT
}

CEan8Ean13::CEan8Ean13(PTCHAR title, int SymID, CWnd* pParent /*=NULL*/)
	: CDialog(CEan8Ean13::IDD, pParent)
{
	m_bAddenda2 = FALSE;
	m_bAddenda5 = FALSE;
	m_bAddendaReq = FALSE;
	m_bAddendaSep = FALSE;
	m_bCheckSend = FALSE;
	m_bEnable = FALSE;
	m_bISBN = FALSE;
	m_strCodeName.Format(L"%s", title);
	m_SymID = SymID;
}


void CEan8Ean13::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEan8Ean13)
	DDX_Check(pDX, IDC_CHECK_EAN8_13_ADDENDA2, m_bAddenda2);
	DDX_Check(pDX, IDC_CHECK_EAN8_13_ADDENDA5, m_bAddenda5);
	DDX_Check(pDX, IDC_CHECK_EAN8_13_ADDENDAREQ, m_bAddendaReq);
	DDX_Check(pDX, IDC_CHECK_EAN8_13_ADDENDASEP, m_bAddendaSep);
	DDX_Check(pDX, IDC_CHECK_EAN8_13_CHECKSEND, m_bCheckSend);
	DDX_Check(pDX, IDC_CHECK_EAN8_13_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_EAN8_13_ISBN, m_bISBN);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEan8Ean13, CDialog)
	//{{AFX_MSG_MAP(CEan8Ean13)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEan8Ean13 message handlers

BOOL CEan8Ean13::OnInitDialog() 
{
	CDialog::OnInitDialog();


	MoveWindow(-1, -1, 242, 295);						// ȭ�� ũ�� ����
	
	SetWindowText(m_strCodeName.GetBuffer(0));

	CMainSheet *dlg = (CMainSheet *)AfxGetMainWnd();
	SymFlagsOnly config;
	
	ReadSymbologyFlagsOnlyConfig(SETUP_CURRENT, m_SymID, &config);
	
	if(config.dwFlags & SYM_ENABLE)
		m_bEnable = TRUE;
	
	if(config.dwFlags & SYM_CHECK_TRANSMIT)
		m_bCheckSend = TRUE;
	
	if(config.dwFlags & SYM_2_DIGIT_ADDENDA)
		m_bAddenda2 = TRUE;
	
	if(config.dwFlags & SYM_5_DIGIT_ADDENDA)
		m_bAddenda5 = TRUE;
	
	if(config.dwFlags & SYM_ADDENDA_REQUIRED)
		m_bAddendaReq = TRUE;

	if(config.dwFlags & SYM_ADDENDA_SEPARATOR)
		m_bAddendaSep = TRUE;
	
	if(config.dwFlags & SYM_5_DIGIT_ADDENDA)
		m_bAddenda5 = TRUE;
		
	if(dlg->m_bEnableISBN)
	{
		m_bISBN = TRUE;
	}
	else
	m_bISBN = FALSE;
	
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CEan8Ean13::OnOK() 
{
	CMainSheet *dlg = (CMainSheet *)AfxGetMainWnd();
	
	UpdateData(TRUE);
	
	SymFlagsOnly config;
	
	if(m_bEnable)
		config.dwFlags = SYM_ENABLE;
	else
		config.dwFlags = 0;
	
	if(m_bCheckSend)
		config.dwFlags |= SYM_CHECK_TRANSMIT;
	
	if(m_bAddenda2)
		config.dwFlags |= SYM_2_DIGIT_ADDENDA;
	
	if(m_bAddenda5)
		config.dwFlags |= SYM_5_DIGIT_ADDENDA;
	
	if(m_bAddendaReq)
		config.dwFlags |= SYM_ADDENDA_REQUIRED;
	
	if(m_bAddendaSep)
		config.dwFlags |= SYM_ADDENDA_SEPARATOR;
	
	if(m_bISBN)	
		dlg->m_bEnableISBN = TRUE;
	else
		dlg->m_bEnableISBN = FALSE;
	
	
	WriteSymbologyFlagsOnlyConfig(m_SymID, config);
	
	CDialog::OnOK();
}
