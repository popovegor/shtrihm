#if !defined(AFX_UPCA_H__3597BEA5_C388_4DE5_AC68_6DA43ED564A3__INCLUDED_)
#define AFX_UPCA_H__3597BEA5_C388_4DE5_AC68_6DA43ED564A3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UPCA.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CUPCA dialog

class CUPCA : public CDialog
{
// Construction
public:
	CUPCA(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CUPCA)
	enum { IDD = IDD_UPCA };
	BOOL	m_bAddenda2;
	BOOL	m_bAddenda5;
	BOOL	m_bAddendaReq;
	BOOL	m_bAddendaSep;
	BOOL	m_bCheckSend;
	BOOL	m_bEnable;
	BOOL	m_bNumSysTrans;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUPCA)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CUPCA)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UPCA_H__3597BEA5_C388_4DE5_AC68_6DA43ED564A3__INCLUDED_)
