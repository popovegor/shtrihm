// FlagsRange.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "FlagsRange.h"

#include "M3MobileImager.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFlagsRange dialog


CFlagsRange::CFlagsRange(CWnd* pParent /*=NULL*/)
	: CDialog(CFlagsRange::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFlagsRange)
	m_bEnable = FALSE;
	m_dwMaxLen = 0;
	m_dwMinLen = 0;
	//}}AFX_DATA_INIT
}

CFlagsRange::CFlagsRange(PTCHAR title, int SymID, CWnd* pParent /*=NULL*/)
: CDialog(CFlagsRange::IDD, pParent)
{
	m_bEnable = FALSE;
	m_dwMaxLen = 0;
	m_dwMinLen = 0;
	m_strCodeName.Format(L"%s",title);
	m_SymID = SymID;
}

void CFlagsRange::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFlagsRange)
	DDX_Check(pDX, IDC_CHECK_FLAGS_RANGE_ENABLE, m_bEnable);
	DDX_Text(pDX, IDC_EDIT_FLAGS_RANGE_MAN, m_dwMaxLen);
	DDX_Text(pDX, IDC_EDIT_FLAGS_RANGE_MIN, m_dwMinLen);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFlagsRange, CDialog)
	//{{AFX_MSG_MAP(CFlagsRange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFlagsRange message handlers

BOOL CFlagsRange::OnInitDialog() 
{
	CDialog::OnInitDialog();


	MoveWindow(-1, -1, 242, 295);						// ȭ�� ũ�� ����
	SetWindowText(m_strCodeName.GetBuffer(0));

	SymFlagsRange config;
	
	ReadSymbologyFlagsRangeConfig(SETUP_CURRENT, m_SymID, &config);
	
	if(config.dwFlags & SYM_ENABLE)
		m_bEnable = TRUE;
	
	m_dwMaxLen = config.dwMaxLen;
	m_dwMinLen = config.dwMinLen;

	UpdateData(FALSE);


	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CFlagsRange::OnOK() 
{
	UpdateData(TRUE);
	
	SymFlagsRange config;
	
	
	CString errMessage;
	
	ReadSymbologyFlagsRangeConfig(SETUP_DEFAULT, m_SymID, &config);
	
	
	if((m_dwMaxLen<config.dwMinLen) || (m_dwMaxLen >config.dwMaxLen) || (m_dwMaxLen<config.dwMinLen) )
	{
		errMessage.Format(L"The maximum length of the corresponding barcode is from %d to %d, maximum length should be bigger than minimum length", config.dwMinLen, config.dwMaxLen);
		MessageBox(errMessage, L"Max Length");
		return;
	}
	
	if(m_dwMinLen <config.dwMinLen)
	{
		errMessage.Format(L"The minimum length of the corresponding barcode is  from %d to %d, minimum length should be shorter than maximum lenght", config.dwMinLen, config.dwMaxLen);
		MessageBox(errMessage, L"Min Length");
		return;
	}
	
	if(m_bEnable)
		config.dwFlags = SYM_ENABLE;
	else
		config.dwFlags = 0;
	
	config.dwMaxLen = m_dwMaxLen;
	config.dwMinLen = m_dwMinLen;
	
	WriteSymbologyFlagsRangeConfig(m_SymID, config);
	
	CDialog::OnOK();
}
