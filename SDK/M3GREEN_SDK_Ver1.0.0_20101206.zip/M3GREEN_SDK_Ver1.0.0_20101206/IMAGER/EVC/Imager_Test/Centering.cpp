/********************************************************************
	created:	2009/01/13
	created:	13:1:2009   17:30
	filename: 	C:\data\01. �۾�\1. ���And������Ʈ\01.��ĳ�� ������Ʈ\6100s\SDK\M3MobileImager(20090113)\Scan3\Centering.cpp
	file path:	C:\data\01. �۾�\1. ���And������Ʈ\01.��ĳ�� ������Ʈ\6100s\SDK\M3MobileImager(20090113)\Scan3
	file base:	Centering
	file ext:	cpp
	author:		JU
	
	purpose:	centering setting 
	report:		CCentering class��  ��Ʈ�ѷ� �����ϱ�
				Centering�� ���� �� �� �ִ� �ּ� �ִ밪�� �ľ��Ͽ��� �Է� ���� ���� ����ó�� �߰�		[2009/1/13 17:31:58 JU]	


*********************************************************************/


#include "stdafx.h"
#include "Scan3.h"
#include "Centering.h"

#include "M3MobileImager.h"

#include "Preview.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCentering dialog


CCentering::CCentering(CWnd* pParent /*=NULL*/)
	: CDialog(CCentering::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCentering)
	m_bEnableCentering = FALSE;
	m_lnedBottom = 0;
	m_lnedLeft = 0;
	m_lnedRight = 0;
	m_lnedTop = 0;
	//}}AFX_DATA_INIT
}


void CCentering::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCentering)
	DDX_Control(pDX, IDC_STATIC_BOTTOM, m_ctlstBottom);
	DDX_Control(pDX, IDC_STATIC_RIGHT, m_ctlstRight);
	DDX_Control(pDX, IDC_STATIC_TOP, m_ctlstTop);
	DDX_Control(pDX, IDC_STATIC_LEFT, m_ctlstLeft);
	DDX_Control(pDX, IDC_STATIC_INTERSECTION_WINDOW, m_ctlgrIntersectionWindow);
	DDX_Control(pDX, IDC_SPIN_TOP, m_ctlspTop);
	DDX_Control(pDX, IDC_SPIN_RIGHT, m_ctlspRight);
	DDX_Control(pDX, IDC_SPIN_LEFT, m_ctlspLeft);
	DDX_Control(pDX, IDC_SPIN_BOTTOM, m_ctlspBottom);
	DDX_Control(pDX, IDC_EDIT_BOTTOM, m_ctledBottom);
	DDX_Control(pDX, IDC_EDIT_RIGHT, m_ctledRight);
	DDX_Control(pDX, IDC_EDIT_TOP, m_ctledTop);
	DDX_Control(pDX, IDC_EDIT_LEFT, m_ctledLeft);
	DDX_Check(pDX, IDC_CHECK_ENABLE_CENTERING, m_bEnableCentering);
	DDX_Text(pDX, IDC_EDIT_BOTTOM, m_lnedBottom);
	DDX_Text(pDX, IDC_EDIT_LEFT, m_lnedLeft);
	DDX_Text(pDX, IDC_EDIT_RIGHT, m_lnedRight);
	DDX_Text(pDX, IDC_EDIT_TOP, m_lnedTop);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCentering, CDialog)
	//{{AFX_MSG_MAP(CCentering)
	ON_BN_CLICKED(IDC_CHECK_ENABLE_CENTERING, OnCheckEnableCentering)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_BUTTON_PREVIEW, OnButtonPreview)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCentering message handlers

BOOL CCentering::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	if(!GetDecodeCenteringWindow(SETUP_CURRENT, &m_bEnableCentering, &m_rect))
	{
		MessageBox(L"Retry please");
		return FALSE;
	}
	
	m_ctlspLeft.SetRange32(0,478);
	m_ctlspTop.SetRange32(0,750);
	m_ctlspRight.SetRange32(1,479);
	m_ctlspBottom.SetRange32(1, 751);
	
	
	m_lnedLeft		= m_rect.left;
	m_lnedTop	    = m_rect.top;
	m_lnedRight		= m_rect.right;
	m_lnedBottom	= m_rect.bottom;
	
	
	if(!m_bEnableCentering)
	{
		m_ctlstLeft.EnableWindow(FALSE);
		m_ctlstTop.EnableWindow(FALSE);
		m_ctlstRight.EnableWindow(FALSE);
		m_ctlstBottom.EnableWindow(FALSE);
		
		m_ctledLeft.EnableWindow(FALSE);
		m_ctledTop.EnableWindow(FALSE);
		m_ctledRight.EnableWindow(FALSE);
		m_ctledBottom.EnableWindow(FALSE);
		
		m_ctlspLeft.EnableWindow(FALSE);
		m_ctlspTop.EnableWindow(FALSE);
		m_ctlspRight.EnableWindow(FALSE);
		m_ctlspBottom.EnableWindow(FALSE);
	}
	
	UpdateData(FALSE);


	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}



void CCentering::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData(TRUE);
	
	if((0 > m_lnedLeft) || (m_lnedLeft >= m_lnedRight))
	{
		MessageBox(L"Left: 0 ~ right");
		return;
	}
	
	if(m_lnedRight > 479)
	{
		MessageBox(L"Right: left+1 ~ 479");
		return;
	}
	
	if((0 >  m_lnedTop) || (m_lnedTop >= m_lnedBottom))
	{
		MessageBox(L"Top: 0 ~ right");
		return;
	}
	
	if(m_lnedBottom > 751)
	{
		MessageBox(L"Bottom: Top+1 ~ 751");
		return;
	}
	
	m_rect.left		= m_lnedLeft;
	m_rect.top		= m_lnedTop;
	m_rect.right	= m_lnedRight;
	m_rect.bottom	= m_lnedBottom;
	
	SetDecodeCenteringWindow(m_bEnableCentering, &m_rect);
	
	CDialog::OnOK();
}

void CCentering::OnCheckEnableCentering() 
{
	UpdateData(TRUE);
	
	m_ctlgrIntersectionWindow.EnableWindow(m_bEnableCentering);
	
	m_ctlstLeft.EnableWindow(m_bEnableCentering);
	m_ctlstTop.EnableWindow(m_bEnableCentering);
	m_ctlstRight.EnableWindow(m_bEnableCentering);
	m_ctlstBottom.EnableWindow(m_bEnableCentering);
	
	m_ctledLeft.EnableWindow(m_bEnableCentering);
	m_ctledTop.EnableWindow(m_bEnableCentering);
	m_ctledRight.EnableWindow(m_bEnableCentering);
	m_ctledBottom.EnableWindow(m_bEnableCentering);
	
	m_ctlspLeft.EnableWindow(m_bEnableCentering);
	m_ctlspTop.EnableWindow(m_bEnableCentering);
	m_ctlspRight.EnableWindow(m_bEnableCentering);
	m_ctlspBottom.EnableWindow(m_bEnableCentering);
}

void CCentering::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here

	// Do not call CDialog::OnPaint() for painting messages
}

void CCentering::OnButtonPreview() 
{
	UpdateData(TRUE);

	CPreview dlg(&m_rect);		//	Centering point preview dialog

	dlg.DoModal();
	
	m_lnedLeft = m_rect.left;
	m_lnedRight = m_rect.right;
	m_lnedTop = m_rect.top;
	m_lnedBottom = m_rect.bottom;
	
	UpdateData(FALSE);
}
