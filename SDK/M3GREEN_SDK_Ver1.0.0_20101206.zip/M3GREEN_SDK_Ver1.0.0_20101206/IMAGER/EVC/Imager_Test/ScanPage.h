#if !defined(AFX_SCANPAGE_H__10B2C526_C08F_4041_992A_0914E5833794__INCLUDED_)
#define AFX_SCANPAGE_H__10B2C526_C08F_4041_992A_0914E5833794__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ScanPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CScanPage dialog

class CScanPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CScanPage)

private: 
	BOOL m_bFirstCentering;

// Construction
public:
	CScanPage();
	~CScanPage();

// Dialog Data
	//{{AFX_DATA(CScanPage)
	enum { IDD = IDD_SCANPAGE };
	CListCtrl	m_BarcodeList;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CScanPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CScanPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnClear();
	afx_msg void OnBtnInfo();
	afx_msg void OnBtnScan();
	afx_msg void OnBtnCentering();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCANPAGE_H__10B2C526_C08F_4041_992A_0914E5833794__INCLUDED_)
