#if !defined(AFX_SYMPAGE_H__0991FA1D_E074_4656_BDC4_6117D3E1C330__INCLUDED_)
#define AFX_SYMPAGE_H__0991FA1D_E074_4656_BDC4_6117D3E1C330__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SymPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSymPage dialog

class CSymPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CSymPage)

private:
	BOOL m_Symbology[ 50 ]; // Array passed to symbology


// Construction
public:
	CSymPage();
	~CSymPage();

// Dialog Data
	//{{AFX_DATA(CSymPage)
	enum { IDD = IDD_SYMPAGE };
	CListCtrl	m_listctlSymbol;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CSymPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CSymPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnButtonAll();
	afx_msg void OnButtonDefault();
	afx_msg void OnClickListSymbology(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnNMCustomdrawListSymbology(NMHDR *pNMHDR, LRESULT *pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SYMPAGE_H__0991FA1D_E074_4656_BDC4_6117D3E1C330__INCLUDED_)
