#if !defined(AFX_CODABAR_H__C174FEB3_A390_4C48_B135_1BE0D910BFA3__INCLUDED_)
#define AFX_CODABAR_H__C174FEB3_A390_4C48_B135_1BE0D910BFA3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Codabar.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCodabar dialog

class CCodabar : public CDialog
{
// Construction
public:
	CCodabar(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCodabar)
	enum { IDD = IDD_CODABAR };
	CButton	m_chctlCheckSend;
	BOOL	m_bCheck;
	BOOL	m_bCheckSend;
	BOOL	m_bEnable;
	BOOL	m_bStartStop;
	DWORD	m_dwMaxLen;
	DWORD	m_dwMinLen;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCodabar)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCodabar)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnCheckCodabarCheck();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CODABAR_H__C174FEB3_A390_4C48_B135_1BE0D910BFA3__INCLUDED_)
