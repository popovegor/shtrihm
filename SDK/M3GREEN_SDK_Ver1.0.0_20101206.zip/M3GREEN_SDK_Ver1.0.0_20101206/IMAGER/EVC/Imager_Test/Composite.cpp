// Composite.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "Composite.h"

#include "M3MobileImager.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CComposite dialog


CComposite::CComposite(CWnd* pParent /*=NULL*/)
	: CDialog(CComposite::IDD, pParent)
{
	//{{AFX_DATA_INIT(CComposite)
	m_bEnable = FALSE;
	m_bEnableUPC = FALSE;
	m_dwMaxLen = 0;
	m_dwMinLen = 0;
	//}}AFX_DATA_INIT
}


void CComposite::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CComposite)
	DDX_Check(pDX, IDC_CHECK_COMPOSITE_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_COMPOSITE_UPC, m_bEnableUPC);
	DDX_Text(pDX, IDC_EDIT_COMPOSITE_MAX, m_dwMaxLen);
	DDX_Text(pDX, IDC_EDIT_COMPOSITE_MIN, m_dwMinLen);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CComposite, CDialog)
	//{{AFX_MSG_MAP(CComposite)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CComposite message handlers
BOOL CComposite::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	MoveWindow(-1, -1, 242, 295);						// ȭ�� ũ�� ����
	SymFlagsRange config;
	
	ReadSymbologyFlagsRangeConfig(SETUP_CURRENT, ID_COMPOSITE, &config);
	
	if(config.dwFlags & SYM_ENABLE)
		m_bEnable = TRUE;
	
	if(config.dwFlags & SYM_COMPOSITE_UPC)
		m_bEnableUPC = TRUE;
	
	m_dwMinLen = config.dwMinLen;
	m_dwMaxLen = config.dwMaxLen;
	
	UpdateData(FALSE);


	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CComposite::OnOK() 
{
	UpdateData(TRUE);
	
	SymFlagsRange config;
	
	
	CString errMessage;
	ReadSymbologyFlagsRangeConfig(SETUP_DEFAULT, ID_COMPOSITE, &config);
	
	if((m_dwMaxLen<config.dwMinLen) || (m_dwMaxLen >config.dwMaxLen) || (m_dwMaxLen<config.dwMinLen) )
	{
		errMessage.Format(L"The maximum length of the corresponding barcode is from %d to %d, maximum length should be bigger than minimum length", config.dwMinLen, config.dwMaxLen);
		MessageBox(errMessage, L"Max Length");
		return;
	}
	
	if(m_dwMinLen <config.dwMinLen)
	{
		errMessage.Format(L"The minimum length of the corresponding barcode is  from %d to %d, minimum length should be shorter than maximum lenght", config.dwMinLen, config.dwMaxLen);
		MessageBox(errMessage, L"Min Length");
		return;
	}
	
	
	
	if(m_bEnable)
		config.dwFlags = SYM_ENABLE;
	else 
		config.dwFlags = 0;

	if(m_bEnableUPC)
		config.dwFlags |= SYM_COMPOSITE_UPC;
	
	
	config.dwMinLen = m_dwMinLen;
	config.dwMaxLen = m_dwMaxLen;
	
	WriteSymbologyFlagsRangeConfig(ID_COMPOSITE, config);
	
	CDialog::OnOK();
}

