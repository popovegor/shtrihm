// UPCE.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "UPCE.h"

#include "M3MobileImager.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUPCE dialog


CUPCE::CUPCE(CWnd* pParent /*=NULL*/)
	: CDialog(CUPCE::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUPCE)
	m_bAddenda2 = FALSE;
	m_bAddenda5 = FALSE;
	m_bAddendaReq = FALSE;
	m_bAddendaSep = FALSE;
	m_bCheckSend = FALSE;
	m_bE0Enable = FALSE;
	m_bE1Enable = FALSE;
	m_bExpandeE = FALSE;
	m_bNumSysTrans = FALSE;
	//}}AFX_DATA_INIT
}

void CUPCE::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUPCE)
	DDX_Check(pDX, IDC_CHECK_UPCE_ADDENDA2, m_bAddenda2);
	DDX_Check(pDX, IDC_CHECK_UPCE_ADDENDA5, m_bAddenda5);
	DDX_Check(pDX, IDC_CHECK_UPCE_ADDENDAREQ, m_bAddendaReq);
	DDX_Check(pDX, IDC_CHECK_UPCE_ADDENDASEP, m_bAddendaSep);
	DDX_Check(pDX, IDC_CHECK_UPCE_CHECKSEND, m_bCheckSend);
	DDX_Check(pDX, IDC_CHECK_UPCE_ENABLE, m_bE0Enable);
	DDX_Check(pDX, IDC_CHECK_UPCE_ENABLEE1, m_bE1Enable);
	DDX_Check(pDX, IDC_CHECK_UPCE_EXPANDEDE, m_bExpandeE);
	DDX_Check(pDX, IDC_CHECK_UPCE_NUMSYSTRANS, m_bNumSysTrans);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUPCE, CDialog)
	//{{AFX_MSG_MAP(CUPCE)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUPCE message handlers

BOOL CUPCE::OnInitDialog() 
{
	CDialog::OnInitDialog();
	

	MoveWindow(-1, -1, 242, 295);						// ȭ�� ũ�� ����
	SymFlagsOnly config;
	
	ReadSymbologyFlagsOnlyConfig(SETUP_CURRENT, ID_UPCE0, &config);
	
	if(config.dwFlags & SYM_ENABLE)
		m_bE0Enable = TRUE;
	
	if(config.dwFlags & SYM_UPCE1_ENABLE)
		m_bE1Enable = TRUE;
	
	if(config.dwFlags & SYM_CHECK_TRANSMIT)
		m_bCheckSend = TRUE;
	
	if(config.dwFlags & SYM_EXPANDED_UPCE)
		m_bExpandeE = TRUE;
	
	if(config.dwFlags & SYM_2_DIGIT_ADDENDA)
		m_bAddenda2 = TRUE;
	
	if(config.dwFlags & SYM_5_DIGIT_ADDENDA)
		m_bAddenda5 = TRUE;
	
	if(config.dwFlags & SYM_ADDENDA_REQUIRED)
		m_bAddendaReq = TRUE;
	
	if(config.dwFlags & SYM_ADDENDA_SEPARATOR)
		m_bAddendaSep = TRUE;
	
	if(config.dwFlags & SYM_NUM_SYS_TRANSMIT)
		m_bNumSysTrans = TRUE;
	
	UpdateData(FALSE);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CUPCE::OnOK() 
{
	
	UpdateData(TRUE);
	
	SymFlagsOnly config;
	
	if(m_bE0Enable)
		config.dwFlags = SYM_ENABLE;
	else
		config.dwFlags = 0;
	
	if(m_bE1Enable)
		config.dwFlags |= SYM_UPCE1_ENABLE;
	
	if(	m_bCheckSend)
		config.dwFlags |= SYM_CHECK_TRANSMIT;
	
	if(m_bExpandeE)
		config.dwFlags |= SYM_EXPANDED_UPCE;		
	
	if(m_bAddenda2 )
		config.dwFlags |= SYM_2_DIGIT_ADDENDA;		
	
	if(m_bAddenda5)
		config.dwFlags |= SYM_5_DIGIT_ADDENDA;
	
	if(m_bAddendaReq )
		config.dwFlags |= SYM_ADDENDA_REQUIRED;		
	
	if(m_bAddendaSep)
		config.dwFlags |= SYM_ADDENDA_SEPARATOR;
	
	if(m_bNumSysTrans)
		config.dwFlags |= SYM_NUM_SYS_TRANSMIT;
	
	WriteSymbologyFlagsOnlyConfig(ID_UPCE0, config);
	
	CDialog::OnOK();
}
