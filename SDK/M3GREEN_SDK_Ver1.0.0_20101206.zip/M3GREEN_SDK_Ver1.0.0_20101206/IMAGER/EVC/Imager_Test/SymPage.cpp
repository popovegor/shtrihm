// SymPage.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "SymPage.h"


#include "M3MobileImager.h"

//////////////////////////////////////////////////////////////////////////
//		symbologies dialog header file

//#include "AztecMesa.h"
#include "FlagsRange.h"
#include "FlagsOnly.h"
#include "PlanetPostnet.h"
#include "Telepen.h"
#include "Codabar.h"
#include "Code39.h"
#include "Posicode.h"
#include "Composite.h"
#include "UPCA.h"
#include "UPCE.h"
#include "Ocr.h"
#include "Ean8Ean13.h"
#include "Msi.h"
#include "Int25.h"
#include "Code11.h"

//		symbologies dialog header file
//////////////////////////////////////////////////////////////////////////


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif




// global
typedef struct _barcode_check{
	int		num;			// HHP���� ���� �Ǿ� �ִ� ���ڵ庰 ��ȣ 
	BOOL	status;			// �ش� ���ڵ尡 Ȱ�����ִ°� �ƴѰ�?
	BOOL	ch;				// �ʱ� ���ڵ� ���� ���� ����Ǿ��°�? �ƴѰ�?
}Barcode_Check;

//	0~45	
TCHAR BARCODE_TYPE[][25]= {	
	L"Austria POST",			L"Aztec Code",
		L"Aztec Mesa",				L"British POST",
		L"Canada POST",				L"China POST",
		L"Codabar",					L"Codablock F",
		L"Code 11",					L"Code 16K",
		L"Code 128",				L"Code 32",
		L"Code 39",					L"Code 49",
		L"Code 4CB",				L"Code 93",
		L"DATA Matrix",				L"EAN-8",
		L"EAN-13",					L"EAN/UCC Composite",		// 20
		L"Interleaved 2of5",		L"ISBT 128",
		L"Japan POST",				L"KIX POST",
		L"Korea POST",				L"MATRIX 2of5",
		L"MaxiCode",					L"Micor PDF417",
		L"MSI",							L"OCR",
		L"PDF417",					L"Planet Code",				
		L"Plessey Code",			L"PosiCode",				
		L"Postnet",					L"QR Code",					
		L"Reduced Space Symbology",	L"Straight 2of5 Industrial",
		L"Straight 2of5 IATA",		L"TCIF Linked Code39",			// 40		
		L"Telepen",					L"Trioptic Code",			
		L"UPC-A",					L"UPC-A with COUPON",		
		L"UPC-E",					L"UPU ID-Tag"					// 46
};

Barcode_Check	bc[] = {	
	{ID_AUSPOST, false, false},	{ID_AZTEC, false, false},
	{ID_MESA, false, false},		{ID_BPO, false, false},
	{ID_CANPOST, false, false},	{ID_CHINAPOST, false, false},
	{ID_CODABAR, false, false},	{ID_CODABLOCK, false, false},
	{ID_CODE11, false, false},		{ID_CODE16K, false, false},
	{ID_CODE128, false, false},	{ID_CODE32, false, false},
	{ID_CODE39, false, false},		{ID_CODE49, false, false},
	{ID_USPS4CB, false, false},	{ID_CODE93, false, false},
	{ID_DATAMATRIX, false, false},	{ID_EAN8, false, false},
	{ID_EAN13, false, false},		{ID_COMPOSITE, false, false},
	{ID_INT25, false, false},		{ID_ISBT, false, false},
	{ID_JAPOST, false, false},		{ID_DUTCHPOST, false, false},
	{ID_KOREAPOST, false, false},	{ID_MATRIX25, false, false},
	{ID_MAXICODE, false, false},	{ID_MICROPDF, false, false},
	{ID_MSI, false, false},			{ID_OCR, false, false},
	{ID_PDF417, false, false},		{ID_PLANET, false, false},		
	{ID_PLESSEY, false, false},	{ID_POSICODE, false, false},	
	{ID_POSTNET, false, false},	{ID_QR, false, false},			
	{ID_RSS, false, false},		{ID_STRT25, false, false},		
	{ID_IATA25, false, false},		{ID_TLCODE39, false, false},	
	{ID_TELEPEN, false, false},	{ID_TRIOPTIC, false, false},	
	{ID_UPCA, false, false},		{ID_COUPONCODE, false, false},	
	{ID_UPCE0, false, false},		{ID_IDTAG, false, false}
};



/////////////////////////////////////////////////////////////////////////////
// CSymPage property page

IMPLEMENT_DYNCREATE(CSymPage, CPropertyPage)

CSymPage::CSymPage() : CPropertyPage(CSymPage::IDD)
{
	//{{AFX_DATA_INIT(CSymPage)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CSymPage::~CSymPage()
{
}

void CSymPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSymPage)
	DDX_Control(pDX, IDC_LIST_SYMBOLOGY, m_listctlSymbol);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSymPage, CPropertyPage)
	//{{AFX_MSG_MAP(CSymPage)
	ON_BN_CLICKED(IDC_BUTTON_ALL, OnButtonAll)
	ON_BN_CLICKED(IDC_BUTTON_DEFAULT, OnButtonDefault)
	ON_NOTIFY(NM_CLICK, IDC_LIST_SYMBOLOGY, OnClickListSymbology)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_LIST_SYMBOLOGY, OnNMCustomdrawListSymbology)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSymPage message handlers

BOOL CSymPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// TODO: Add extra initialization here
	ListView_SetExtendedListViewStyle(m_listctlSymbol.GetSafeHwnd(),LVS_EX_FULLROWSELECT);
	m_listctlSymbol.InsertColumn(0,L"Index",LVCFMT_LEFT,44);
	m_listctlSymbol.InsertColumn(1,L"BarCode Type",LVCFMT_LEFT,177);
	
	int index;
	CString				sNum;
	
	
	for(index = ID_IDTAG; index >= 0; index--)		//	1������ �����ϹǷ� -1, ocr ���� -1
	{
		GetEnableDisableSymbology(SETUP_CURRENT, index, &m_Symbology[index]);
	}
	
	
	for(index = ID_IDTAG-1 ; index >= 0; index--)		//	1������ �����ϹǷ� -1, ocr ���� -1
	{
		sNum.Format(L"%d", index + 1);
		m_listctlSymbol.InsertItem(0,sNum);
		m_listctlSymbol.SetItemText(0,1,BARCODE_TYPE[index]);
	}	
	
	while(++index<ID_IDTAG)
	{
		m_listctlSymbol.SetCheck(index, m_Symbology[bc[index].num]);
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSymPage::OnButtonAll() 
{
	if(!SetEnableDisableSymbology(ID_ALL, TRUE))
		MessageBox(L"All Enable Symbology error");
	
	int index;
	for(index = ID_IDTAG; index >= 0; index--)		//	1������ �����ϹǷ� -1, ocr ���� -1
	{
		GetEnableDisableSymbology(SETUP_CURRENT, index, &m_Symbology[index]);		//dlg->m_scanner.GetEnableDisableSymbology(SETUP_CURRENT, index, &m_Symbology[index]);
	}
	
	GetDlgItem(IDC_LIST_SYMBOLOGY)->Invalidate();
	
}

void CSymPage::OnButtonDefault() 
{
	if(!DefaultSymbology(ID_ALL))
		MessageBox(L"Default Symbology error");
	
	int index;
	
	for(index = ID_IDTAG; index >= 0; index--)		//	1������ �����ϹǷ� -1, ocr ���� -1
	{
		GetEnableDisableSymbology(SETUP_CURRENT, index, &m_Symbology[index]);
	}
	
	GetDlgItem(IDC_LIST_SYMBOLOGY)->Invalidate();
	
}

void CSymPage::OnClickListSymbology(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView =  (NM_LISTVIEW*)pNMHDR;

	//	���� ���õ� üũ �ڽ��� index�� ��´�. 
	int nSel = pNMListView->iItem;

	if(nSel == -1)				//	������ ����� Ŭ���� �ϸ� -1�� ���� �ǹǷ� 
	{							//	�ٽ� Ŭ���϶�� �޼����� �˸���. 
		MessageBox(L"Retry Select");
	}
	else
	{

		switch(bc[nSel].num)
		{
			case ID_AUSPOST:
			case ID_BPO:
			case ID_CANPOST:
			case ID_JAPOST:
			case ID_DUTCHPOST:
			case ID_TLCODE39:
			case ID_TRIOPTIC:
			case ID_CODE32:
			case ID_COUPONCODE:
			case ID_ISBT:
			case ID_USPS4CB:
			case ID_IDTAG:
				{
					CFlagsOnly dlg(BARCODE_TYPE[nSel], bc[nSel].num);
					dlg.DoModal();	
				}
				break;
			
			case ID_IATA25:
			case ID_CODABLOCK:
			case ID_AZTEC:
			case ID_CODE49:
			case ID_CODE128:
			case ID_CODE93:
			case ID_DATAMATRIX:
			case ID_MAXICODE:
			case ID_MICROPDF:
			case ID_PDF417:
			case ID_QR:
			case ID_RSS:
			case ID_STRT25:
			case ID_MATRIX25:
			case ID_PLESSEY:
			case ID_CHINAPOST:
			case ID_KOREAPOST:
			case ID_CODE16K:
				{
					CFlagsRange dlg(BARCODE_TYPE[nSel], bc[nSel].num);
					dlg.DoModal();	
				}
				break;


			case ID_MESA:
				{
					CFlagsOnly dlg(BARCODE_TYPE[nSel], bc[nSel].num);
//					CAztecMesa dlg;
					dlg.DoModal();
				}
				break;

			case ID_CODABAR:
				{
					CCodabar dlg;
					dlg.DoModal();
				}
				break;

			case ID_CODE11:
				{
					CCode11 dlg;
					dlg.DoModal();
				}
				break;

			
			case ID_CODE39:
				{
					CCode39 dlg;
					dlg.DoModal();
				}
				break;

			case ID_COMPOSITE:
				{
					CComposite	dlg;
					dlg.DoModal();	
				}
				break;

 				
			case ID_EAN8:
			case ID_EAN13:
				{
					CEan8Ean13 dlg(BARCODE_TYPE[nSel], bc[nSel].num);
					dlg.DoModal();
				}
				break;


			case ID_INT25:
				{
					CInt25 dlg;
					dlg.DoModal();
				}
				break;

			case ID_OCR:
				{
					COcr dlg;
					dlg.DoModal();
				}
				break;

			case ID_PLANET:					
			case ID_POSTNET:
				{
					CPlanetPostnet dlg(BARCODE_TYPE[nSel], bc[nSel].num);
					dlg.DoModal();
				}
				break;

			case ID_UPCA:
				{
					CUPCA dlg;
					dlg.DoModal();
				}
				break;

			case ID_UPCE0:
			case ID_UPCE1:
				{
					CUPCE dlg;
					dlg.DoModal();
				}
				break;
				
	
			
			
			case ID_MSI:
				{
					CMsi dlg;
					dlg.DoModal();
				}
				break;

			


			case ID_TELEPEN:
				{
					CTelepen dlg;
					dlg.DoModal();
				}
				break;

				
			case ID_POSICODE:
				{
					CPosicode dlg;
					dlg.DoModal();
				}
				break;

// 				ID_GS1_128,
// 				ID_GEN_CODE128,
		
		/*
		if(!m_listctlSymbol.GetCheck(nSel))
		{
			m_Symbology[bc[nSel].num] = TRUE;
			SetEnableDisableSymbology(bc[nSel].num, TRUE);
		}
		else
		{
			m_Symbology[bc[nSel].num] = FALSE;
			SetEnableDisableSymbology(bc[nSel].num, FALSE);
		}
		*/

		}
	}

	int index;
	for(index = ID_IDTAG; index >= 0; index--)		//	1������ �����ϹǷ� -1, ocr ���� -1
	{
		GetEnableDisableSymbology(SETUP_CURRENT, index, &m_Symbology[index]);		
	}

	GetDlgItem(IDC_LIST_SYMBOLOGY)->Invalidate();
	
	*pResult = 0;
}


void CSymPage::OnNMCustomdrawListSymbology(NMHDR *pNMHDR, LRESULT *pResult)
{
	//	LPNMCUSTOMDRAW pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);
	
	NMLVCUSTOMDRAW* pLVCD = reinterpret_cast<NMLVCUSTOMDRAW*>( pNMHDR );
	*pResult = 0;
	// TODO: Add your control notification handler code here
	BOOL check= false;
	
	
	if ( CDDS_PREPAINT == pLVCD->nmcd.dwDrawStage )
	{
		*pResult = CDRF_NOTIFYITEMDRAW;
	}
	else 
	{
		if ( CDDS_ITEMPREPAINT == pLVCD->nmcd.dwDrawStage )
		{
			if((m_Symbology[bc[pLVCD->nmcd.dwItemSpec].num]) ==TRUE)
			{
				pLVCD->clrText   = RGB(0, 0, 200);            
				pLVCD->clrTextBk = RGB(255,255,255);
				m_listctlSymbol.SetCheck(pLVCD->nmcd.dwItemSpec, TRUE);
			}
			else
			{
				pLVCD->clrText   = RGB(200, 0, 0);          
				pLVCD->clrTextBk = RGB(255, 255, 255);
				m_listctlSymbol.SetCheck(pLVCD->nmcd.dwItemSpec, FALSE);
			}
			
			*pResult = CDRF_DODEFAULT;
		}
	}
}
