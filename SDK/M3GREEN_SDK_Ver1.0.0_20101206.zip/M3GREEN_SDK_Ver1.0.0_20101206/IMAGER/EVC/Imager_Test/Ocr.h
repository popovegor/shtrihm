#if !defined(AFX_OCR_H__6B92C6AC_E80A_45EC_A1C6_09FDB077E990__INCLUDED_)
#define AFX_OCR_H__6B92C6AC_E80A_45EC_A1C6_09FDB077E990__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Ocr.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COcr dialog

class COcr : public CDialog
{
// Construction
public:
	COcr(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(COcr)
	enum { IDD = IDD_OCR };
	CComboBox	m_cbctlDirection;
	CComboBox	m_cbctlMode;
	CString	m_strTemplate;
	CString	m_strCheckChar;
	CString	m_strGroupG;
	CString	m_strGroupH;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COcr)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(COcr)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OCR_H__6B92C6AC_E80A_45EC_A1C6_09FDB077E990__INCLUDED_)
