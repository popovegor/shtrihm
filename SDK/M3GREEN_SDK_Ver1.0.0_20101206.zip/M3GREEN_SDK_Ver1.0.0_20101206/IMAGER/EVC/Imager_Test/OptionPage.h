#if !defined(AFX_OPTIONPAGE_H__4CF1A4B9_FB43_4394_8FB9_C07627E767FC__INCLUDED_)
#define AFX_OPTIONPAGE_H__4CF1A4B9_FB43_4394_8FB9_C07627E767FC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OptionPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COptionPage dialog

class COptionPage : public CPropertyPage
{
	DECLARE_DYNCREATE(COptionPage)

// Construction
public:
	COptionPage();
	~COptionPage();

// Dialog Data
	//{{AFX_DATA(COptionPage)
	enum { IDD = IDD_OPTIONPAGE };
	CComboBox	m_ctrlComboTimeOut;
	CComboBox	m_ctlScanningLightMode;
	BOOL	m_bMultiDecode;
	int		m_nSyncMode;
	BOOL	m_bBeep;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(COptionPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(COptionPage)
	afx_msg void OnButtonConfirm();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTIONPAGE_H__4CF1A4B9_FB43_4394_8FB9_C07627E767FC__INCLUDED_)
