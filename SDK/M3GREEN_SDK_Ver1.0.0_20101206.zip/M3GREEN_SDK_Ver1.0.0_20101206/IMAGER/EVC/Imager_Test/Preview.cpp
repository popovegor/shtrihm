// Preview.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "Preview.h"

#include "M3MobileImager.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreview dialog


CPreview::CPreview(CWnd* pParent /*=NULL*/)
	: CDialog(CPreview::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPreview)
	m_bEnableCentering = FALSE;
	m_strWarnning = _T("");
	//}}AFX_DATA_INIT
}

CPreview::CPreview(RECT *rect, CWnd* pParent /*=NULL*/)
	: CDialog(CPreview::IDD, pParent)
{
/*
	m_Rect		= rect;
	m_nLeft		= rect->left/3;
	m_nRight	= rect->right/3;
	m_nTop		= rect->top/3;
	m_nBottom	= rect->bottom/3;
*/
}

void CPreview::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreview)
	DDX_Control(pDX, IDC_STATIC_WARNNING, m_ctlWarnning);
	DDX_Control(pDX, IDC_BUTTON_SETTING, m_ctlbtnSet);
	DDX_Text(pDX, IDC_EDIT_HIGHT, m_nHight);
	DDX_Text(pDX, IDC_EDIT_WIDTH, m_nWidth);
	DDX_Check(pDX, IDC_CHECK_ENABLE_CENTERING, m_bEnableCentering);
	DDX_Text(pDX, IDC_STATIC_WARNNING, m_strWarnning);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPreview, CDialog)
	//{{AFX_MSG_MAP(CPreview)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_BN_CLICKED(IDC_BUTTON_SETTING, OnButtonSetting)
	ON_WM_MOUSEMOVE()
	ON_EN_CHANGE(IDC_EDIT_HIGHT, OnChangeEditHight)
	ON_EN_CHANGE(IDC_EDIT_WIDTH, OnChangeEditWidth)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreview message handlers
BOOL CPreview::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	::MessageBox(NULL, L"Please move the red square. You can select the decoding location", NULL, MB_TOPMOST);

	ShowWindow(SW_SHOWMAXIMIZED);
	::SetWindowPos(m_hWnd, HWND_TOPMOST, 0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);
	SetWindowLong(m_hWnd, GWL_EXSTYLE,WS_EX_CAPTIONOKBTN);
	
	MoveWindow(0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), TRUE);	

	SetForegroundWindow();
	GetDecodeCenteringWindow(SETUP_CURRENT, &m_bEnableCentering, &m_Rect);
	
//	m_bSetMode = FALSE;

	m_nLeft		= m_Rect.left/3;
	m_nRight	= m_Rect.right/3;
	m_nTop		= m_Rect.top/3;
	m_nBottom	= m_Rect.bottom/3;


	m_nWidth = m_Rect.right  - m_Rect.left;
	m_nHight = m_Rect.bottom - m_Rect.top;


	// ó�� ��ġ�� ��ǥ�� ��� ������ �Ѿ��� 
	m_PrePoint.x = m_nLeft + m_nWidth / 6 + 40;
	m_PrePoint.y = m_nTop + m_nHight / 6 + 35;

	UpdateData(FALSE);



	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPreview::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here

	CRect rect;
//	GetClientRect(rect.TopLeft());

	int width = GetSystemMetrics(SM_CXSCREEN);

	if(240 == width)	//	screen 240 * 320 size 
	{	

		if((m_nLeft >= 0) && (m_nTop >= 0) && (m_nRight <= 160) && (m_nBottom <= 752/3))
		{
			CBitmap bmp;
			if(bmp.LoadBitmap(IDB_BITMAP_CENTERING))
			{
				// Get the size of the bitmap
				BITMAP bmpInfo;
				bmp.GetBitmap(&bmpInfo);
				
				// Create an in-memory DC compatible with the
				// display DC we're using to paint
				CDC dcMemory;
				dcMemory.CreateCompatibleDC(&dc);

				// Select the bitmap into the in-memory DC
				CBitmap* pOldBitmap = dcMemory.SelectObject(&bmp);

//				dc.StretchBlt(40, 35, 160, 250, &dcMemory, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY);
				dc.StretchBlt(40, 35, 160, 220, &dcMemory, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY);
				


				// Copy the bits from the in-memory DC into the on-
				// screen DC to actually do the painting. Use the centerpoint
				// we computed for the target offset.
//				dc.BitBlt(nX, nY, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcMemory, 
//					0, 0, SRCCOPY);


			}

			CBrush nullBrush;//, *pOldBrush;
//			nullBrush.CreateSolidBrush(NULL_BRUSH);
//			pOldBrush = dc.SelectObject(&nullBrush);


			/*pOldBrush = (CBrush *)*/dc.SelectObject(GetStockObject(NULL_BRUSH));


			// create and select a thick, black pen
//			CPen penBlack;
//			penBlack.CreatePen(PS_SOLID, 1, RGB(0, 0, 0));
//			CPen* pOldPen = dc.SelectObject(&penBlack);
			
			//	Centering value x point is 0 ~ 480 convert 0 ~ 160		1 of 3
			//	Centering value y point is 0 ~ 752 convert 0 ~ 251		about 1 of 3
//			dc.RoundRect(40, 35, 200, 285, 0, 0);
			
			// put back the old objects
//			dc.SelectObject(pOldPen);


			CPen penRed;
			penRed.CreatePen(PS_SOLID, 1, RGB(255, 0, 0));
			CPen* pOldPen = dc.SelectObject(&penRed);
//			dc.RoundRect(m_nLeft+40, m_nTop+35, m_nRight+40, m_nBottom+35, 0, 0);
			dc.Rectangle(m_nLeft+40, m_nTop+35, m_nRight+40, m_nBottom+35);//, 0, 0);

			// put back the old objects
			dc.SelectObject(pOldPen);

//			dc.SelectObject(pOldBrush);

//			m_strWarnning.Format(L"");
			m_ctlWarnning.ShowWindow(SW_HIDE);
		

		}
		else
		{
//			MessageBox(L"������ �Ѿ� �����ϴ�.");
			m_strWarnning.Format(L"Out of Range!!");
			UpdateData(FALSE);
			m_ctlWarnning.ShowWindow(SW_SHOW);
		}

	}

//	GetSystemMetrics(SM_YVIRTUALSCREEN);

//	m_ctlstCoordinate.MoveWindow(rect.right)

	

	// Do not call CDialog::OnPaint() for painting messages
}

void CPreview::OnLButtonDown(UINT nFlags, CPoint point) 
{
	DrawSet(point);	
	
	if((m_nLeft >= 0) && (m_nTop >= 0) && (m_nRight <= 160) && (m_nBottom <= 752/3))
	{
		m_PrePoint = point;
	}
	else
	{
		DrawSet(m_PrePoint);
	}

	CDialog::OnLButtonDown(nFlags, point);
}

void CPreview::OnButtonSetting() 
{
/*
	if(m_bSetMode)
	{
		m_bSetMode = FALSE;
		m_ctlbtnSet.SetWindowText(L"Start Set");
	}
	else
	{
		m_bSetMode = TRUE;
		m_ctlbtnSet.SetWindowText(L"Stop Set");
	}
	*/
}


void CPreview::DrawSet(CPoint point)
{
//	if(m_bSetMode)	//	setting mode
	{
		int width = GetSystemMetrics(SM_CXSCREEN);
		
		if(240 == width)	//	screen 240 * 320 size 
		{
			
			int nWidthValue = m_nWidth / 6;
			m_nLeft = point.x - nWidthValue - 40;
			m_nRight = point.x + nWidthValue - 40;
			
			int nHightValue = m_nHight / 6;
			m_nTop = point.y - nHightValue - 35;
			m_nBottom = point.y + nHightValue - 35;

			/*
			m_nLeft = point.x - 40;
			m_nTop = point.y - 35;
			
			m_nRight = m_nLeft + m_nWidth/3;
			m_nBottom = m_nTop + m_nHight/3;
			*/
			
			RECT rect;
			rect.left	= 0;
			rect.bottom = 320;
			rect.right	= 240;
			rect.top	= 0;
			InvalidateRect(&rect, FALSE);
		}
		
	}/*
	else
	{
		
		
		m_Rect.left	= m_nLeft	* 3;
		m_Rect.top		= m_nTop	* 3;
		m_Rect.right	= m_Rect.left + m_nWidth;
		m_Rect.bottom	= m_Rect.top  + m_nHight;
		
		
		PostMessage(WM_CLOSE, 0, 0);
	}
	*/
}

void CPreview::OnOK() 
{
	UpdateData(TRUE);

	m_Rect.left		= m_nLeft	* 3;
	m_Rect.top		= m_nTop	* 3;
	m_Rect.right	= m_Rect.left + m_nWidth;
	m_Rect.bottom	= m_Rect.top  + m_nHight;

	SetDecodeCenteringWindow(m_bEnableCentering, &m_Rect);

	CDialog::OnOK();
}

void CPreview::OnMouseMove(UINT nFlags, CPoint point) 
{
	DrawSet(point);	
	
	if((m_nLeft >= 0) && (m_nTop >= 0) && (m_nRight <= 160) && (m_nBottom <= 752/3-30))
	{
		m_PrePoint = point;
	}
	else
	{
		DrawSet(m_PrePoint);
	}
	
	CDialog::OnMouseMove(nFlags, point);
}

void CPreview::OnChangeEditHight() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	int height	= GetDlgItemInt(IDC_EDIT_HIGHT, NULL, TRUE);
	
	if((0 >= height) || (height > 752))
	{
		m_strWarnning.Format(L"Height is 1 ~ 752");
		UpdateData(FALSE);
			m_ctlWarnning.ShowWindow(SW_SHOW);

		UpdateData(FALSE);
		return ;
	}
	else
	{
		m_ctlWarnning.ShowWindow(SW_HIDE);
	}
	
	
	UpdateData(TRUE);

	
}

void CPreview::OnChangeEditWidth() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	int width	= GetDlgItemInt(IDC_EDIT_WIDTH, NULL, TRUE);
	
	if((0 >= width) || (width > 480))
	{
		m_strWarnning.Format(L"Width is 1 ~ 480");
		UpdateData(FALSE);
			m_ctlWarnning.ShowWindow(SW_SHOW);

		UpdateData(FALSE);
		return ;
	}
	else
	{
		m_ctlWarnning.ShowWindow(SW_HIDE);
	}
	
	
	UpdateData(TRUE);

	
}
