#if !defined(AFX_INT25_H__8743B666_8EC1_406E_911B_821294BC4D23__INCLUDED_)
#define AFX_INT25_H__8743B666_8EC1_406E_911B_821294BC4D23__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Int25.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CInt25 dialog

class CInt25 : public CDialog
{
// Construction
public:
	CInt25(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CInt25)
	enum { IDD = IDD_INT25 };
	CButton	m_chctlCheckSend;
	BOOL	m_bCheck;
	BOOL	m_bCheckSend;
	BOOL	m_bEnable;
	DWORD	m_dwMaxLen;
	DWORD	m_dwMinLen;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInt25)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CInt25)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnCheckInt25Check();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INT25_H__8743B666_8EC1_406E_911B_821294BC4D23__INCLUDED_)
