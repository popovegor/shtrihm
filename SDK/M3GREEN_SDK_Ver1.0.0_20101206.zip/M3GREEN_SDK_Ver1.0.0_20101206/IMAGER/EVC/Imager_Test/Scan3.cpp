// Scan3.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Scan3.h"
#include "MainSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CScan3App

BEGIN_MESSAGE_MAP(CScan3App, CWinApp)
	//{{AFX_MSG_MAP(CScan3App)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScan3App construction

CScan3App::CScan3App()
	: CWinApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CScan3App object

CScan3App theApp;

/////////////////////////////////////////////////////////////////////////////
// CScan3App initialization

BOOL CScan3App::InitInstance()
{
	WNDCLASS	wc;

	//	Dialog�� Class ������ ������
	::GetClassInfo(AfxGetInstanceHandle(), L"Dialog", &wc);

	//	Ŭ������ �ٲٱ�
	wc.lpszClassName = L"M3Mobile_Imager";

	AfxRegisterClass(&wc);


	HANDLE hMutex = ::CreateMutex(NULL, TRUE, _T("CAMERA_INSTANCE"));
	HWND hFwnd;

	if(GetLastError() == ERROR_ALREADY_EXISTS)
	{
		int result;
		hFwnd = FindWindow(L"M3Mobile_Camera", L"Camera");
		ShowWindow(hFwnd, SW_HIDE);
		result = MessageBox(NULL,_T("Camera program is already running!\nDo you want to run the scanner"),_T("ERROR"),MB_YESNO|MB_ICONWARNING);

		if(IDYES == result)		// ��ĳ�� ����̹� unload
		{
			hFwnd = FindWindow(NULL, L"Camera");
			if(hFwnd)
			{
				SendMessage(hFwnd, WM_CLOSE, NULL, NULL);
			}
		}
		else 
		{
			ShowWindow(hFwnd, SW_SHOW);
			return FALSE;
		}

	}
	else
	{
		ReleaseMutex(hMutex);
		CloseHandle(hMutex);
	}
			
	hMutex = ::CreateMutex(NULL, TRUE, _T("M3Imager"));
	
	if(GetLastError() == ERROR_ALREADY_EXISTS)
	{
		MessageBox(NULL,_T("SCANNER Engine is already running!"),_T("ERROR"),MB_OK|MB_ICONWARNING);
		return FALSE;		
	}




	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

	CMainSheet dlg(L"M3ScanTest");
	m_pMainWnd = &dlg;
	
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.


	ReleaseMutex(hMutex);
	CloseHandle(hMutex);


	return FALSE;
}
