#if !defined(AFX_CODE11_H__4590E7B8_2062_4542_8463_C8E17CA3D815__INCLUDED_)
#define AFX_CODE11_H__4590E7B8_2062_4542_8463_C8E17CA3D815__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Code11.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCode11 dialog

class CCode11 : public CDialog
{
// Construction
public:
	CCode11(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCode11)
	enum { IDD = IDD_CODE11 };
	BOOL	m_bEnable;
	BOOL	m_bCheck;
	DWORD	m_dwMaxLen;
	DWORD	m_dwMinLen;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCode11)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCode11)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CODE11_H__4590E7B8_2062_4542_8463_C8E17CA3D815__INCLUDED_)
