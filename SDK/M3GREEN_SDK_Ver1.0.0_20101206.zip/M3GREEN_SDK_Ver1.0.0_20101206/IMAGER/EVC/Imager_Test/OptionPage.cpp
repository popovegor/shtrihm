// OptionPage.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "OptionPage.h"
#include "M3MobileImager.h"
#include "MainSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COptionPage property page

IMPLEMENT_DYNCREATE(COptionPage, CPropertyPage)

COptionPage::COptionPage() : CPropertyPage(COptionPage::IDD)
{
	//{{AFX_DATA_INIT(COptionPage)
	m_bMultiDecode = FALSE;
	m_nSyncMode = 1;
	m_bBeep = FALSE;
	//}}AFX_DATA_INIT
}

COptionPage::~COptionPage()
{
}

void COptionPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COptionPage)
	DDX_Control(pDX, IDC_COMBO_TIMEOUT, m_ctrlComboTimeOut);
	DDX_Control(pDX, IDC_COMBO_SCANNING_LIGHT_MODE, m_ctlScanningLightMode);
	DDX_Check(pDX, IDC_CHECK_MULTIDECODEMODE, m_bMultiDecode);
	DDX_Radio(pDX, IDC_RADIO_ASYNC, m_nSyncMode);
	DDX_Check(pDX, IDC_CHECK_BEEP, m_bBeep);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COptionPage, CPropertyPage)
	//{{AFX_MSG_MAP(COptionPage)
	ON_BN_CLICKED(IDC_BUTTON_CONFIRM, OnButtonConfirm)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptionPage message handlers

void COptionPage::OnButtonConfirm() 
{
	UpdateData(TRUE);

	SetScanningLightsMode((ScanIlluminat)m_ctlScanningLightMode.GetCurSel());
	MultiDecodeModeEnable(m_bMultiDecode);

	CMainSheet* dlg = (CMainSheet*)AfxGetMainWnd();
	dlg->m_nTimeOut = m_ctrlComboTimeOut.GetCurSel()+1;

	(CPropertySheet *)GetParent()->SendMessage(PSM_SETCURSEL, 0);
}

BOOL COptionPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

	CMainSheet* dlg = (CMainSheet*)AfxGetMainWnd();
	
	m_ctlScanningLightMode.InsertString(0, L"ILLUM_AIMER_OFF");
	m_ctlScanningLightMode.InsertString(1, L"ILLUM_ONLY_ON");
	m_ctlScanningLightMode.InsertString(2, L"AIMER_ONLY_ON");
	m_ctlScanningLightMode.InsertString(3, L"ILLUM_AIMER_ON");
	m_ctlScanningLightMode.SetCurSel(3);

	m_ctrlComboTimeOut.InsertString(0, L"1");
	m_ctrlComboTimeOut.InsertString(1, L"2");
	m_ctrlComboTimeOut.InsertString(2, L"3");
	m_ctrlComboTimeOut.InsertString(3, L"4");
	m_ctrlComboTimeOut.InsertString(4, L"5");
	m_ctrlComboTimeOut.InsertString(5, L"6");
	m_ctrlComboTimeOut.InsertString(6, L"7");
	m_ctrlComboTimeOut.InsertString(7, L"8");
	m_ctrlComboTimeOut.InsertString(8, L"9");
	m_ctrlComboTimeOut.InsertString(9, L"10");
	m_ctrlComboTimeOut.SetCurSel(dlg->m_nTimeOut - 1);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
