// Codabar.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "Codabar.h"

#include "M3MobileImager.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCodabar dialog


CCodabar::CCodabar(CWnd* pParent /*=NULL*/)
	: CDialog(CCodabar::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCodabar)
	m_bCheck = FALSE;
	m_bCheckSend = FALSE;
	m_bEnable = FALSE;
	m_bStartStop = FALSE;
	m_dwMaxLen = 0;
	m_dwMinLen = 0;
	//}}AFX_DATA_INIT
}


void CCodabar::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCodabar)
	DDX_Control(pDX, IDC_CHECK_CODABAR_CHECKSEND, m_chctlCheckSend);
	DDX_Check(pDX, IDC_CHECK_CODABAR_CHECK, m_bCheck);
	DDX_Check(pDX, IDC_CHECK_CODABAR_CHECKSEND, m_bCheckSend);
	DDX_Check(pDX, IDC_CHECK_CODABAR_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_CODABAR_STARTSTOP, m_bStartStop);
	DDX_Text(pDX, IDC_EDIT_CODABAR_MAX, m_dwMaxLen);
	DDX_Text(pDX, IDC_EDIT_CODABAR_MIN, m_dwMinLen);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCodabar, CDialog)
	//{{AFX_MSG_MAP(CCodabar)
	ON_BN_CLICKED(IDC_CHECK_CODABAR_CHECK, OnCheckCodabarCheck)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCodabar message handlers

BOOL CCodabar::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	MoveWindow(-1, -1, 242, 295);						// ȭ�� ũ�� ����
	SymFlagsRange config;
	
	ReadSymbologyFlagsRangeConfig(SETUP_CURRENT, ID_CODABAR, &config);
	
	if(config.dwFlags & SYM_ENABLE)
		m_bEnable = TRUE;
	
	if(config.dwFlags & SYM_START_STOP_XMIT)
		m_bStartStop = TRUE;
	
	if(config.dwFlags & SYM_CHECK_ENABLE)
		m_bCheck = TRUE;
	
	if(config.dwFlags & SYM_CHECK_TRANSMIT)
		m_bCheckSend = TRUE;
	
	m_dwMaxLen = config.dwMaxLen;
	m_dwMinLen = config.dwMinLen;
	
	if(m_bCheck)
		m_chctlCheckSend.EnableWindow(TRUE);
	else
		m_chctlCheckSend.EnableWindow(FALSE);
	
	UpdateData(FALSE);

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCodabar::OnOK() 
{
	// TODO: Add extra validation here

	UpdateData(TRUE);
	SymFlagsRange config;
	
	CString errMessage;
	ReadSymbologyFlagsRangeConfig(SETUP_DEFAULT, ID_CODABAR, &config);
	if((m_dwMaxLen<config.dwMinLen) || (m_dwMaxLen >config.dwMaxLen) || (m_dwMaxLen<config.dwMinLen) )
	{
		errMessage.Format(L"The maximum length of the corresponding barcode is from %d to %d, maximum length should be bigger than minimum length", config.dwMinLen, config.dwMaxLen);
		MessageBox(errMessage, L"Max Length");
		return;
	}
	
	if(m_dwMinLen <config.dwMinLen)
	{
		errMessage.Format(L"The minimum length of the corresponding barcode is  from %d to %d, minimum length should be shorter than maximum lenght", config.dwMinLen, config.dwMaxLen);
		MessageBox(errMessage, L"Min Length");
		return;
	}
	
	if(m_bEnable)
		config.dwFlags = SYM_ENABLE;
	else
		config.dwFlags = 0;
	
	if(m_bCheck)
	{
		config.dwFlags |= SYM_CHECK_ENABLE;
		
		if(m_bCheckSend)
			config.dwFlags |= SYM_CHECK_TRANSMIT;
	}
	
	if(m_bStartStop)
		config.dwFlags |= SYM_START_STOP_XMIT;
	
	config.dwMaxLen = m_dwMaxLen;
	config.dwMinLen = m_dwMinLen;
	
	WriteSymbologyFlagsRangeConfig(ID_CODABAR, config);
	
	// TODO: Add your control notification handler code here

	CDialog::OnOK();
}

void CCodabar::OnCheckCodabarCheck() 
{
	UpdateData(TRUE);
	
	if(m_bCheck)
		m_chctlCheckSend.EnableWindow(TRUE);
	else
		m_chctlCheckSend.EnableWindow(FALSE);	
}
