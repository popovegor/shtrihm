#if !defined(AFX_FLAGSRANGE_H__C46674A4_2C4A_42F0_B4B4_D328ECF3E5E8__INCLUDED_)
#define AFX_FLAGSRANGE_H__C46674A4_2C4A_42F0_B4B4_D328ECF3E5E8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FlagsRange.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFlagsRange dialog

class CFlagsRange : public CDialog
{
private:
	int m_SymID;
	CString m_strCodeName;

// Construction
public:
	CFlagsRange(CWnd* pParent = NULL);   // standard constructor
	CFlagsRange(PTCHAR title, int SymID, CWnd* pParent = NULL);   
// Dialog Data
	//{{AFX_DATA(CFlagsRange)
	enum { IDD = IDD_FLAGS_RANGE };
	BOOL	m_bEnable;
	DWORD	m_dwMaxLen;
	DWORD	m_dwMinLen;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFlagsRange)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFlagsRange)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FLAGSRANGE_H__C46674A4_2C4A_42F0_B4B4_D328ECF3E5E8__INCLUDED_)
