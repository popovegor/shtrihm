#if !defined(AFX_PREVIEW_H__5DA5E2B7_E026_4190_867F_8C77D915D21A__INCLUDED_)
#define AFX_PREVIEW_H__5DA5E2B7_E026_4190_867F_8C77D915D21A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Preview.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPreview dialog

class CPreview : public CDialog
{
private:
	long	m_nLeft;
	long	m_nRight;
	long	m_nTop;
	long	m_nBottom;
	RECT	m_Rect;

//	BOOL	m_bSetMode;

	CPoint	m_PrePoint;



// Construction
public:
 
	CPreview(CWnd* pParent = NULL);   // standard constructor
	CPreview(RECT *rect, CWnd* pParent = NULL); 


	void DrawSet(CPoint point);

// Dialog Data
	//{{AFX_DATA(CPreview)
	enum { IDD = IDD_PREVIEW };
	CStatic	m_ctlWarnning;
	CButton	m_ctlbtnSet;
	long	m_nHight;
	long	m_nWidth;
	BOOL	m_bEnableCentering;
	CString	m_strWarnning;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPreview)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPreview)
	afx_msg void OnPaint();
	virtual BOOL OnInitDialog();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnButtonSetting();
	virtual void OnOK();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnChangeEditHight();
	afx_msg void OnChangeEditWidth();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREVIEW_H__5DA5E2B7_E026_4190_867F_8C77D915D21A__INCLUDED_)
