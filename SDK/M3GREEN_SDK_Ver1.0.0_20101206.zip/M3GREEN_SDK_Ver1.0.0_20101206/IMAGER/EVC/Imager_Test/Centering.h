#if !defined(AFX_CENTERING_H__C084D17E_8AE9_4664_B31A_9C566C2728DE__INCLUDED_)
#define AFX_CENTERING_H__C084D17E_8AE9_4664_B31A_9C566C2728DE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Centering.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCentering dialog

class CCentering : public CDialog
{
private:
	RECT m_rect;

// Construction
public:
	CCentering(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCentering)
	enum { IDD = IDD_CENTERING };
	CStatic	m_ctlstBottom;
	CStatic	m_ctlstRight;
	CStatic	m_ctlstTop;
	CStatic	m_ctlstLeft;
	CButton	m_ctlgrIntersectionWindow;
	CSpinButtonCtrl	m_ctlspTop;
	CSpinButtonCtrl	m_ctlspRight;
	CSpinButtonCtrl	m_ctlspLeft;
	CSpinButtonCtrl	m_ctlspBottom;
	CEdit	m_ctledBottom;
	CEdit	m_ctledRight;
	CEdit	m_ctledTop;
	CEdit	m_ctledLeft;
	BOOL	m_bEnableCentering;
	long	m_lnedBottom;
	long	m_lnedLeft;
	long	m_lnedRight;
	long	m_lnedTop;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCentering)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCentering)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnCheckEnableCentering();
	afx_msg void OnPaint();
	afx_msg void OnButtonPreview();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CENTERING_H__C084D17E_8AE9_4664_B31A_9C566C2728DE__INCLUDED_)
