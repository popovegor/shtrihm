#if !defined(AFX_COMPOSITE_H__3DB7F355_90E6_482B_B0E4_878EFD559EA3__INCLUDED_)
#define AFX_COMPOSITE_H__3DB7F355_90E6_482B_B0E4_878EFD559EA3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Composite.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CComposite dialog

class CComposite : public CDialog
{
// Construction
public:
	CComposite(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CComposite)
	enum { IDD = IDD_COMPOSITE };
	BOOL	m_bEnable;
	BOOL	m_bEnableUPC;
	DWORD	m_dwMaxLen;
	DWORD	m_dwMinLen;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CComposite)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CComposite)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMPOSITE_H__3DB7F355_90E6_482B_B0E4_878EFD559EA3__INCLUDED_)
