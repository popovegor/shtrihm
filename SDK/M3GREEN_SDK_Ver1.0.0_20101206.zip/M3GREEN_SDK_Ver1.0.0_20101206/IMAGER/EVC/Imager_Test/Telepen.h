#if !defined(AFX_TELEPEN_H__5EBE6460_F438_417D_A59F_5552DB8A54FE__INCLUDED_)
#define AFX_TELEPEN_H__5EBE6460_F438_417D_A59F_5552DB8A54FE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Telepen.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTelepen dialog

class CTelepen : public CDialog
{
// Construction
public:
	CTelepen(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTelepen)
	enum { IDD = IDD_TELEPEN };
	BOOL	m_bEnable;
	BOOL	m_bOldStyle;
	DWORD	m_dwMaxLen;
	DWORD	m_dwMinLen;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTelepen)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTelepen)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TELEPEN_H__5EBE6460_F438_417D_A59F_5552DB8A54FE__INCLUDED_)
