// Msi.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "Msi.h"

#include "M3MobileImager.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMsi dialog


CMsi::CMsi(CWnd* pParent /*=NULL*/)
	: CDialog(CMsi::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMsi)
	m_bCheckSend = FALSE;
	m_bEnable = FALSE;
	m_dwMaxLen = 0;
	m_dwMinLen = 0;
	//}}AFX_DATA_INIT
}


void CMsi::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMsi)
	DDX_Check(pDX, IDC_CHECK_MSI_CHECK, m_bCheckSend);
	DDX_Check(pDX, IDC_CHECK_MSI_ENABLE, m_bEnable);
	DDX_Text(pDX, IDC_EDIT_MSI_MAX, m_dwMaxLen);
	DDX_Text(pDX, IDC_EDIT_MSI_MIN, m_dwMinLen);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMsi, CDialog)
	//{{AFX_MSG_MAP(CMsi)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMsi message handlers

BOOL CMsi::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	MoveWindow(-1, -1, 242, 295);						// ȭ�� ũ�� ����
	SymFlagsRange config;
	
	ReadSymbologyFlagsRangeConfig(SETUP_CURRENT, ID_MSI, &config);
	
	if(config.dwFlags & SYM_ENABLE)
		m_bEnable = TRUE;
	
	if(config.dwFlags & SYM_CHECK_TRANSMIT)
		m_bCheckSend = TRUE;
	
	m_dwMaxLen = config.dwMaxLen;
	m_dwMinLen = config.dwMinLen;
	
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CMsi::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData(TRUE);
	
	SymFlagsRange config;
	
	
	CString errMessage;
	ReadSymbologyFlagsRangeConfig(SETUP_DEFAULT, ID_MSI, &config);
	if((m_dwMaxLen<config.dwMinLen) || (m_dwMaxLen >config.dwMaxLen) || (m_dwMaxLen<config.dwMinLen) )
	{
		errMessage.Format(L"The maximum length of the corresponding barcode is from %d to %d, maximum length should be bigger than minimum length", config.dwMinLen, config.dwMaxLen);
		MessageBox(errMessage, L"Max Length");
		return;
	}
	
	if(m_dwMinLen <config.dwMinLen)
	{
		errMessage.Format(L"The minimum length of the corresponding barcode is  from %d to %d, minimum length should be shorter than maximum lenght", config.dwMinLen, config.dwMaxLen);
		MessageBox(errMessage, L"Min Length");
		return;
	}
	
	
	
	if(m_bEnable)
		config.dwFlags = SYM_ENABLE;
	else
		config.dwFlags = 0;
	
	if(	m_bCheckSend)
		config.dwFlags |= SYM_CHECK_TRANSMIT;
	
	config.dwMaxLen = m_dwMaxLen;
	config.dwMinLen = m_dwMinLen;
	
	WriteSymbologyFlagsRangeConfig(ID_MSI, config);
	
	CDialog::OnOK();
}
