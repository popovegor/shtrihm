#if !defined(AFX_FLAGSONLY_H__E36DEC50_F8BB_4514_9C0F_91C85F5EC49A__INCLUDED_)
#define AFX_FLAGSONLY_H__E36DEC50_F8BB_4514_9C0F_91C85F5EC49A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FlagsOnly.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFlagsOnly dialog

class CFlagsOnly : public CDialog
{
private:
	int m_SymID;
	CString m_strCodeName;
// Construction
public:
	CFlagsOnly(CWnd* pParent = NULL);   // standard constructor
	CFlagsOnly(PTCHAR title, int SymID, CWnd* pParent = NULL);   


// Dialog Data
	//{{AFX_DATA(CFlagsOnly)
	enum { IDD = IDD_FLAGS_ONLY };
	BOOL	m_bEnable;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFlagsOnly)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFlagsOnly)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FLAGSONLY_H__E36DEC50_F8BB_4514_9C0F_91C85F5EC49A__INCLUDED_)
