// PlanetPostnet.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "PlanetPostnet.h"

#include "M3MobileImager.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPlanetPostnet dialog


CPlanetPostnet::CPlanetPostnet(CWnd* pParent /*=NULL*/)
	: CDialog(CPlanetPostnet::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPlanetPostnet)
	m_bCheckSend = FALSE;
	m_bEnable = FALSE;
	m_strBarcodeName = _T("");
	//}}AFX_DATA_INIT
}

CPlanetPostnet::CPlanetPostnet(PTCHAR title, int SymID, CWnd* pParent /*=NULL*/)
: CDialog(CPlanetPostnet::IDD, pParent)
{
	m_bCheckSend = FALSE;
	m_bEnable = FALSE;
	m_strBarcodeName.Format(L"%s", title);
	m_SymID = SymID;
}


void CPlanetPostnet::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPlanetPostnet)
	DDX_Check(pDX, IDC_CHECK_PLANETPOSTNET_CHECKSEND, m_bCheckSend);
	DDX_Check(pDX, IDC_CHECK_PLANETPOSTNET_ENABLE, m_bEnable);
	DDX_Text(pDX, IDC_STATIC_PLANET_POSTNET, m_strBarcodeName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPlanetPostnet, CDialog)
	//{{AFX_MSG_MAP(CPlanetPostnet)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPlanetPostnet message handlers

BOOL CPlanetPostnet::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	MoveWindow(-1, -1, 242, 295);						// ȭ�� ũ�� ����
	SymFlagsOnly config;
	ReadSymbologyFlagsOnlyConfig(SETUP_CURRENT, m_SymID, &config);
	
	if(config.dwFlags & SYM_ENABLE)
		m_bEnable = TRUE;
	
	if(config.dwFlags & SYM_CHECK_TRANSMIT)
		m_bCheckSend = TRUE;
	
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPlanetPostnet::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData(TRUE);
	SymFlagsOnly config;
	
	if(m_bEnable)
		config.dwFlags = SYM_ENABLE;
	else
		config.dwFlags = 0;
	
	if(m_bCheckSend)
		config.dwFlags |= SYM_CHECK_TRANSMIT;
	
	WriteSymbologyFlagsOnlyConfig(m_SymID, config);


	CDialog::OnOK();
}
