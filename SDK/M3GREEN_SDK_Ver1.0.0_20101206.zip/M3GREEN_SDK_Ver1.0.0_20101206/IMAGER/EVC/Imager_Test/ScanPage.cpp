// ScanPage.cpp : implementation file
//

//	Centering default width, hight value ���� (150,150)										[2009/1/28 20:12:04 JU]

#include "stdafx.h"
#include "Scan3.h"
#include "ScanPage.h"

#include "MainSheet.h"

#include "M3MobileImager.h"

#include "Preview.h"
//	Centering Preview�� �̿��ϸ� Centering dialog�� �ʿ� ��� [2009/1/22 10:39:52 JU]	#include "Centering.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CScanPage property page

IMPLEMENT_DYNCREATE(CScanPage, CPropertyPage)

CScanPage::CScanPage() : CPropertyPage(CScanPage::IDD)
{
	//{{AFX_DATA_INIT(CScanPage)
		// NOTE: the ClassWizard will add member initialization here
	m_bFirstCentering = TRUE;
	//}}AFX_DATA_INIT
}

CScanPage::~CScanPage()
{
}

void CScanPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CScanPage)
	DDX_Control(pDX, IDC_LIST_BARCODE, m_BarcodeList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CScanPage, CPropertyPage)
	//{{AFX_MSG_MAP(CScanPage)
	ON_BN_CLICKED(IDC_BTN_CLEAR, OnBtnClear)
	ON_BN_CLICKED(IDC_BTN_INFO, OnBtnInfo)
	ON_BN_CLICKED(IDC_BTN_SCAN, OnBtnScan)
	ON_BN_CLICKED(IDC_BTN_CENTERING, OnBtnCentering)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScanPage message handlers

BOOL CScanPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// TODO: Add extra initialization here
	MoveWindow(0, -1, 240, 310);

	m_BarcodeList.InsertColumn(0,L"Type",LVCFMT_LEFT,80);
	m_BarcodeList.InsertColumn(1,L"Data",LVCFMT_LEFT,152);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CScanPage::OnBtnClear() 
{
	m_BarcodeList.DeleteAllItems();
}

void CScanPage::OnBtnInfo() 
{
	CMainSheet *dlg = (CMainSheet *)AfxGetMainWnd();
	dlg->GetInfo();
}

void CScanPage::OnBtnScan() 
{
	CMainSheet *dlg = (CMainSheet *)AfxGetMainWnd();
	dlg->ScanRead();

	
}

// Centering Button On Event
void CScanPage::OnBtnCentering() 
{

	if(m_bFirstCentering)
	{
		RECT rect;
		BOOL bEnableCentering;
		if(GetDecodeCenteringWindow(SETUP_CURRENT, &bEnableCentering, &rect))
		{
//	���͸� ������ �ʹ� ũ�� �ٸ����� ������ ������ �־ �⺻���� ���� �۰� ������  [2009/1/28 11:50:25 JU]
//	Width range (0 ~ 479) width = 150, 
//	Hight range (0 ~ 751) hight = 150 , 

//	left = (width max<480> - width default <150>) / 2
//	right = width max<480> - ((width max<480> - width default <150>) / 2)			
			rect.left	= 165;//90;
			rect.right	= 315;//390;
			rect.top	= 301;//276;
			rect.bottom	= 451;//476;
			if(SetDecodeCenteringWindow(bEnableCentering, &rect))
			{
				m_bFirstCentering = FALSE;
			}
		}
	}

	//	Centering Preview�� �̿��ϸ� Centering dialog�� �ʿ� ���  [2009/1/22 10:43:06 JU]	CCentering dlg;

	CPreview dlg;
	dlg.DoModal();
}
