#if !defined(AFX_PLANETPOSTNET_H__79694328_2A57_4D44_9EB7_6B7E9F9E3D38__INCLUDED_)
#define AFX_PLANETPOSTNET_H__79694328_2A57_4D44_9EB7_6B7E9F9E3D38__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PlanetPostnet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPlanetPostnet dialog

class CPlanetPostnet : public CDialog
{
private:
	int m_SymID;

// Construction
public:
	CPlanetPostnet(CWnd* pParent = NULL);   // standard constructor
	CPlanetPostnet(PTCHAR title, int SymID, CWnd* pParent = NULL);

// Dialog Data
	//{{AFX_DATA(CPlanetPostnet)
	enum { IDD = IDD_PLANET_POSTNET };
	BOOL	m_bCheckSend;
	BOOL	m_bEnable;
	CString	m_strBarcodeName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPlanetPostnet)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPlanetPostnet)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PLANETPOSTNET_H__79694328_2A57_4D44_9EB7_6B7E9F9E3D38__INCLUDED_)
