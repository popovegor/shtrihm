// FlagsOnly.cpp : implementation file
//

#include "stdafx.h"
#include "Scan3.h"
#include "FlagsOnly.h"

#include "M3MobileImager.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFlagsOnly dialog


CFlagsOnly::CFlagsOnly(CWnd* pParent /*=NULL*/)
	: CDialog(CFlagsOnly::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFlagsOnly)
	m_bEnable = FALSE;
	//}}AFX_DATA_INIT
}

CFlagsOnly::CFlagsOnly(PTCHAR title, int SymID, CWnd* pParent /*=NULL*/)
: CDialog(CFlagsOnly::IDD, pParent)
{
	m_bEnable = FALSE;
	m_SymID = SymID;
	m_strCodeName.Format(L"%s", title);
}


void CFlagsOnly::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFlagsOnly)
	DDX_Check(pDX, IDC_CHECK_FLAGS_ONLY, m_bEnable);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFlagsOnly, CDialog)
	//{{AFX_MSG_MAP(CFlagsOnly)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFlagsOnly message handlers

BOOL CFlagsOnly::OnInitDialog() 
{
	CDialog::OnInitDialog();



	MoveWindow(-1, -1, 242, 295);						// ȭ�� ũ�� ����
	SetWindowText(m_strCodeName.GetBuffer(0));

	SymFlagsOnly config;
	
	ReadSymbologyFlagsOnlyConfig(SETUP_CURRENT, m_SymID, &config);
	
	if(config.dwFlags & SYM_ENABLE)
		m_bEnable = TRUE;
	
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CFlagsOnly::OnOK() 
{
	UpdateData(TRUE);
	SymFlagsOnly config;
	
	
	if(m_bEnable)
		config.dwFlags = SYM_ENABLE;
	else
		config.dwFlags = 0;
	
	WriteSymbologyFlagsOnlyConfig(m_SymID, config);
	
	CDialog::OnOK();
}
