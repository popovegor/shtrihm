#if !defined(AFX_EAN8EAN13_H__6C84FAC5_2B4A_41AA_AB46_096B73BE17BC__INCLUDED_)
#define AFX_EAN8EAN13_H__6C84FAC5_2B4A_41AA_AB46_096B73BE17BC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Ean8Ean13.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEan8Ean13 dialog

class CEan8Ean13 : public CDialog
{
private:
	int m_SymID;
	CString m_strCodeName;

// Construction
public:
	CEan8Ean13(CWnd* pParent = NULL);   // standard constructor
	CEan8Ean13(PTCHAR title, int SymID, CWnd* pParent = NULL);

// Dialog Data
	//{{AFX_DATA(CEan8Ean13)
	enum { IDD = IDD_EAN8_13 };
	BOOL	m_bAddenda2;
	BOOL	m_bAddenda5;
	BOOL	m_bAddendaReq;
	BOOL	m_bAddendaSep;
	BOOL	m_bCheckSend;
	BOOL	m_bEnable;
	BOOL	m_bISBN;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEan8Ean13)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEan8Ean13)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EAN8EAN13_H__6C84FAC5_2B4A_41AA_AB46_096B73BE17BC__INCLUDED_)
