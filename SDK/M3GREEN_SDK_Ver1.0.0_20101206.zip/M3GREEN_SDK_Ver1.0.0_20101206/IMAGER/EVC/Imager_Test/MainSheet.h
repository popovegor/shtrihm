#if !defined(AFX_MAINSHEET_H__D7D0AF24_7873_4CE1_BD89_635B5DBFD117__INCLUDED_)
#define AFX_MAINSHEET_H__D7D0AF24_7873_4CE1_BD89_635B5DBFD117__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MainSheet.h : header file
//

#include "ScanPage.h"
#include "SymPage.h"
#include "OptionPage.h"

/////////////////////////////////////////////////////////////////////////////
// CMainSheet

class CMainSheet : public CPropertySheet
{
	DECLARE_DYNAMIC(CMainSheet)

// Construction
public:
	CMainSheet(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CMainSheet(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes
public:
	CScanPage		m_scan;
	CSymPage		m_symbol;
	COptionPage		m_option;

	BOOL			m_bKeyFlag;
	BOOL			m_bEnableISBN;

	int				m_nTimeOut;

// Operations
public:
	
	void Check_Barcode(TCHAR chId, TCHAR chSymLetter, TCHAR chSymModifier, CString szCode);	
	BOOL ScanRead();
	void GetInfo();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainSheet)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainSheet();

	// Generated message map functions
protected:
	//{{AFX_MSG(CMainSheet)
	afx_msg void OnDestroy();
	afx_msg void OnDataRead();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINSHEET_H__D7D0AF24_7873_4CE1_BD89_635B5DBFD117__INCLUDED_)
