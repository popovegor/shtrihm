// Viewer.cpp : implementation file
//

#include "stdafx.h"
#include "Cam2.h"
#include "Viewer.h"

#include "Cam2Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CViewer dialog


CViewer::CViewer(CWnd* pParent /*=NULL*/)
	: CDialog(CViewer::IDD, pParent)
{
	//{{AFX_DATA_INIT(CViewer)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CViewer::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CViewer)
	DDX_Control(pDX, IDC_STATIC_VIEWER, m_ctlView);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CViewer, CDialog)
	//{{AFX_MSG_MAP(CViewer)
	ON_BN_CLICKED(IDC_LEFT, OnLeft)
	ON_BN_CLICKED(IDC_RIGHT, OnRight)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CViewer message handlers

BOOL CViewer::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(-1, -1, 242, 295);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CViewer::OnLeft() 
{
	CCam2Dlg *dlg = (CCam2Dlg *)AfxGetMainWnd();
	dlg->ViewUp();
}

void CViewer::OnRight() 
{
	CCam2Dlg *dlg = (CCam2Dlg *)AfxGetMainWnd();
	dlg->ViewDown();	
}

void CViewer::OnLButtonDown(UINT nFlags, CPoint point) 
{
	m_pt = point;

	CDialog::OnLButtonDown(nFlags, point);
}

void CViewer::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CPoint result;
	
	result =  m_pt - point;
	
	if(result.x<-4)
		OnRight();
	
	if(result.x>4)
		OnLeft();
	
	CDialog::OnLButtonUp(nFlags, point);
}
