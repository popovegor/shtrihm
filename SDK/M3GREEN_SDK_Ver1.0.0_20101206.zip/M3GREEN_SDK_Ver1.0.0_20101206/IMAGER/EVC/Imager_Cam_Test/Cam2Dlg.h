// Cam2Dlg.h : header file
//

#if !defined(AFX_CAM2DLG_H__0ACC4CEF_744C_4FA0_9710_80B2B88D1A15__INCLUDED_)
#define AFX_CAM2DLG_H__0ACC4CEF_744C_4FA0_9710_80B2B88D1A15__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


#include "Option.h"
#include "afxtempl.h"

/////////////////////////////////////////////////////////////////////////////
// CCam2Dlg dialog

class CCam2Dlg : public CDialog
{
private:
	BOOL	m_bCapturring;

// Construction
public:
	CCam2Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CCam2Dlg)
	enum { IDD = IDD_CAM2_DIALOG };
	CButton	m_btnStart;
	CButton	m_btnStop;
	CButton	m_btnCapture;
	CStatic	m_ctlstaticImage;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCam2Dlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL


public:
	COption m_OptionDlg;

	CList<TCHAR *, TCHAR *> m_filelist;	
	POSITION				m_listpos;
	
	void ImageLoad(WCHAR *FileName, CStatic *ImageCtl=NULL);
	
	TCHAR m_tcFileFullName[MAX_PATH];
	
	
	HANDLE					m_hFind;
	WIN32_FIND_DATA	 m_fd;
	
	BOOL ImageFileLoad(PTCHAR pstrPath, BOOL bFullPath  = FALSE);
	void ViewDown() ;
	void ViewUp() ;

	CStatic	*m_ViewImageCtl;




// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCam2Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnButtonStart();
	afx_msg void OnButtonStop();
	afx_msg void OnButtonCapture();
	afx_msg void OnButtonViewer();
	afx_msg void OnButtonOption();
	afx_msg void OnButtonInfo();
	afx_msg void OnDestroy();
	afx_msg LRESULT OnImageView(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CAM2DLG_H__0ACC4CEF_744C_4FA0_9710_80B2B88D1A15__INCLUDED_)
