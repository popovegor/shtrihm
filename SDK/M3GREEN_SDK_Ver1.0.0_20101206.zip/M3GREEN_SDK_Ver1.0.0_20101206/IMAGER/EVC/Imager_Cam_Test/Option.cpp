// Option.cpp : implementation file
//

#include "stdafx.h"
#include "Cam2.h"
#include "Option.h"

#include "M3MobileImager.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COption dialog


COption::COption(CWnd* pParent /*=NULL*/)
	: CDialog(COption::IDD, pParent)
{
	//{{AFX_DATA_INIT(COption)
	m_strSaveFolder = _T("");
	m_nJpegQuality = 0;
	m_strCustomName = _T("");
	//}}AFX_DATA_INIT
}


void COption::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COption)
	DDX_Control(pDX, IDC_STATIC_CUSTOM_NAME, m_scctlNameType);
	DDX_Control(pDX, IDC_SPIN_JPEG_QUALITY, m_ctlspinJpegQuality);
	DDX_Control(pDX, IDC_NAME_TYPE_COMBO, m_cbctlNameType);
	DDX_Control(pDX, IDC_EDIT_CUSTOM_NAME, m_ebctlCustomName);
	DDX_Control(pDX, IDC_COMBO_RESOLUTION, m_cbctlResolution);
	DDX_Control(pDX, IDC_COMBO_FORMAT, m_cbctlSaveFormat);
	DDX_Text(pDX, IDC_EDIT_SAVE_FOLDER, m_strSaveFolder);
	DDX_Text(pDX, IDC_EDIT_JPEG_QUALITY, m_nJpegQuality);
	DDX_Text(pDX, IDC_EDIT_CUSTOM_NAME, m_strCustomName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COption, CDialog)
	//{{AFX_MSG_MAP(COption)
	ON_CBN_SELCHANGE(IDC_NAME_TYPE_COMBO, OnSelchangeNameTypeCombo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COption message handlers

BOOL COption::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(-1, -1, 242, 295);

	m_cbctlResolution.InsertString(0, L"640x480");
	m_cbctlResolution.InsertString(1, L"320x240");
	m_cbctlResolution.InsertString(2, L"160x120");
	
	m_cbctlSaveFormat.InsertString(0, L"BMP");
	m_cbctlSaveFormat.InsertString(1, L"JPG");
	
	m_cbctlNameType.InsertString(0, L"Custom");
	m_cbctlNameType.InsertString(1, L"Date");
	
	m_ctlspinJpegQuality.SetRange32(0, 100);
	
	//////////////////////////////////////////////////////////////////////////
	///		������ initialize
	CAM_OPTION option;
	
	CamGetOption(&option);
	
	
	m_nJpegQuality		= option.nJpegQuality;
	m_cbctlResolution.SetCurSel(option.nResolution);
	m_cbctlSaveFormat.SetCurSel(option.nSaveFormat);
	
	switch(option.nSaveFormat)
	{
	case 0:
		NKDbgPrintfW(L"app option: bmp \n");
		m_bBMTSaveFormat = TRUE;
		break;
		
	case 1:
		NKDbgPrintfW(L"app option: jpg \n");
		m_bBMTSaveFormat = FALSE;
		break;
	}
	
	
	if(m_bDateNameType)
	{
		m_cbctlNameType.SetCurSel(1);
		m_scctlNameType.EnableWindow(FALSE);
		m_ebctlCustomName.EnableWindow(FALSE);
	}
	else
	{
		m_cbctlNameType.SetCurSel(0);
		m_scctlNameType.EnableWindow(TRUE);
		m_ebctlCustomName.EnableWindow(TRUE);
	}
	
	///		������ initialize
	//////////////////////////////////////////////////////////////////////////
	
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void COption::OnOK() 
{
	UpdateData(TRUE);

	CAM_OPTION option;


	//	�ش� ������ο� ������ ������
	//	���� ������ �Ǵ��ϴ� �ڵ尡 ���⿡�� ��ȿ�����̿��� 
	//	�ش� ��ο� ������ �ִ� Ȯ������ ���� 
	
	if(MAX_PATH <m_strSaveFolder)
	{
		MessageBox(L"SaveFolder length is longer than system max path length");
		return;
	}
	else
	{
//		TCHAR path[MAX_PATH];
//		wcscpy(path, m_strSaveFolder.GetBuffer(0));

		PTCHAR pEnd = m_strSaveFolder.GetBuffer(0);
		PTCHAR pStart = pEnd;

		while(pEnd = wcschr(pEnd+1, L'\\'))
		{
			*pEnd = NULL;

			CreateDirectory(pStart, NULL);

			*pEnd = L'\\';
		}
		
		CreateDirectory(pStart, NULL);
	}
	





	
	
	if(m_cbctlNameType.GetCurSel() == 0)
		m_bDateNameType = FALSE;
	else
		m_bDateNameType = TRUE;
	
	option.nTop = 0;
	option.nLeft = 0;
	option.nRight = 640;
	option.nBottom = 480;



	option.nJpegQuality = m_nJpegQuality;
	option.nResolution  = m_cbctlResolution.GetCurSel();
	option.nSaveFormat = m_cbctlSaveFormat.GetCurSel();
	option.bInvert = FALSE;
	
	
	switch(option.nSaveFormat)
	{
	case 0:
		m_bBMTSaveFormat = TRUE;
		break;
		
	case 1:
		m_bBMTSaveFormat = FALSE;
		break;
	}
	

	

	CamSetOption(option);
	
	CDialog::OnOK();
}

void COption::OnSelchangeNameTypeCombo() 
{
	UpdateData(TRUE);
	
	if(m_cbctlNameType.GetCurSel() == 0)
	{
		m_scctlNameType.EnableWindow(TRUE);
		m_ebctlCustomName.EnableWindow(TRUE);
	}
	else
	{
		m_scctlNameType.EnableWindow(FALSE);
		m_ebctlCustomName.EnableWindow(FALSE);
	}
}
