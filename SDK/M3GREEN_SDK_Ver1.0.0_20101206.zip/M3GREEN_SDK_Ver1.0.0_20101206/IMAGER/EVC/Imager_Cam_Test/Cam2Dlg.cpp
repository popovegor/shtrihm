/********************************************************************
created		:	2008/12/03
file base	: 	TestCam.exe

file ext	:	cpp
author		:	Dong-Hyun, Eum(vision7901) - ���밳����

purpose		:	WinCE Imager 
Report		:	2008. 11. 28 [11/28/2008 ju]		 v0.9.0 - ó�� ����Ǿ ���� ����
				2008. 11. 28 [11/28/2008 ju]		 v0.9.1 - option���� top, bottom, left, right ���� �������� �ʾƼ� ������ ����� ���� ����
				2008. 11. 28 [11/28/2008 ju]		 v0.9.2 - ������ ������ �������� ������ ���� ����� �ִ� ��� 
				2008. 11. 28 [11/28/2008 ju]		 v0.9.3 - option���� jpg ����Ƽ ���� �ʵǴ� ���� ���� 
				2008. 12. 08 [12/08/2008 ju]		 v0.9.4 - PreviewStart ȣ�� ���ϰ� ī�޶� ��ư ������ 
															  capturing�� FALSE�� ���������� ���ؼ� �Կ� �Ұ����� ���°� �Ǵ� ���� ����
				2008. 12. 08 [12/08/2008 ju]		 v1.0.0 - Enter Key �߰� �� Camera �ߺ����� ���� 	
				2010. 01. 12 [01/12/2010 vision7901] v1.0.0 - Imager �μ��ΰ� 
				2010. 03. 08 [03/08/2010 vision7901] v2.0.0 - Dialog Font Tahoma�� ����/ M3Green/M3T/M3Pos ���չ���
*********************************************************************/

// Cam2Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "Cam2.h"
#include "Cam2Dlg.h"

#include "Info.h"
#include "Viewer.h"
#include "M3MobileImager.h"

///////////////////////////////
//	�̹��� ����
#include <initguid.h>

#include <imaging.h>

#pragma comment (lib, "ole32.lib")
//////////////////////////////////////


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCam2Dlg dialog

CCam2Dlg::CCam2Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCam2Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCam2Dlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCam2Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCam2Dlg)
	DDX_Control(pDX, IDC_BUTTON_START, m_btnStart);
	DDX_Control(pDX, IDC_BUTTON_STOP, m_btnStop);
	DDX_Control(pDX, IDC_BUTTON_CAPTURE, m_btnCapture);
	DDX_Control(pDX, IDC_STATIC_IMAGE, m_ctlstaticImage);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCam2Dlg, CDialog)
	//{{AFX_MSG_MAP(CCam2Dlg)
	ON_BN_CLICKED(IDC_BUTTON_START, OnButtonStart)
	ON_BN_CLICKED(IDC_BUTTON_STOP, OnButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_CAPTURE, OnButtonCapture)
	ON_BN_CLICKED(IDC_BUTTON_VIEWER, OnButtonViewer)
	ON_BN_CLICKED(IDC_BUTTON_OPTION, OnButtonOption)
	ON_BN_CLICKED(IDC_BUTTON_INFO, OnButtonInfo)
	ON_WM_DESTROY()
	ON_MESSAGE(WM_STILL_COMPLETED, OnImageView)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCam2Dlg message handlers

BOOL CCam2Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	CenterWindow(GetDesktopWindow());	// center to the hpc screen

	// TODO: Add extra initialization here
	MoveWindow(-1, -1, 242, 295);						// ȭ�� ũ�� ����
	
	if(!Connect(TRUE))
	{
		MessageBox(L"Connect... fail");
		return FALSE;
	}
	
	if(!CamInit(m_hWnd, m_ctlstaticImage))
	{
		MessageBox(L"initialize ... fail");
		return FALSE;
	}


	m_bCapturring = FALSE;

	m_OptionDlg.m_bDateNameType = TRUE;
	
//	TCHAR tcPath[MAX_PATH];
//	SHGetSpecialFolderPath(m_hWnd, tcPath, CSIDL_MYPICTURES, false);
//	m_OptionDlg.m_strSaveFolder.Format(L"%s", tcPath);
	m_OptionDlg.m_strSaveFolder.Format(L"\\Flash Disk\\Imager\\Photo");
	
	
	CAM_OPTION	config;
	
	CamGetOption(&config);
	
	if(0 == config.nSaveFormat)
	{
		m_OptionDlg.m_bBMTSaveFormat = TRUE;
	}
	else
	{
		m_OptionDlg.m_bBMTSaveFormat = FALSE;
	}

	PTCHAR pEnd = m_OptionDlg.m_strSaveFolder.GetBuffer(0);
	PTCHAR pStart = pEnd;

	while(pEnd = wcschr(pEnd+1, L'\\'))
	{
		*pEnd = NULL;

		CreateDirectory(pStart, NULL);
		
		*pEnd = L'\\';
	}
	
	CreateDirectory(pStart, NULL);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CCam2Dlg::OnButtonStart() 
{
	m_btnStart.EnableWindow(FALSE);
	
	PreviewStart();
	m_btnStop.EnableWindow(TRUE);
	m_btnCapture.EnableWindow(TRUE);
}

void CCam2Dlg::OnButtonStop() 
{
	m_btnCapture.EnableWindow(FALSE);

	PreviewStop();
	m_btnStop.EnableWindow(FALSE);
	m_btnStart.EnableWindow(TRUE);
}

void CCam2Dlg::OnButtonCapture() 
{
	if(!m_btnCapture.IsWindowEnabled())
		return;

	if(!m_bCapturring)
	{
		m_bCapturring = TRUE;
		
		m_btnCapture.EnableWindow(FALSE);
		m_btnStop.EnableWindow(FALSE);
			
		
		SYSTEMTIME st;
		
		GetLocalTime(&st);
		
		if(TRUE == m_OptionDlg.m_bDateNameType)
		{
			wsprintf(m_tcFileFullName, L"%s\\%4d%02d%02d%02d%02d%02d.", 
				LPCTSTR(m_OptionDlg.m_strSaveFolder),
				st.wYear,				//	��
				st.wMonth,				//  ��
				st.wDay,				//  ��
				st.wHour,				//	��
				st.wMinute,				//	��
				st.wSecond				//	��
				);
		}
		else
		{
			TCHAR tcFileType[4];
			
			if(m_OptionDlg.m_bBMTSaveFormat)
				wcscpy(tcFileType, L"bmp");
			else
				wcscpy(tcFileType,L"jpg");
			
			wsprintf(m_tcFileFullName, L"%s\\%s.%s", LPCTSTR(m_OptionDlg.m_strSaveFolder), LPCTSTR(m_OptionDlg.m_strCustomName), tcFileType);
			
			
			for(int filecnt=1;GetFileAttributes(m_tcFileFullName) != 0xFFFFFFFF; filecnt++)
			{
				wsprintf(m_tcFileFullName, L"%s\\%s%d.%s", LPCTSTR(m_OptionDlg.m_strSaveFolder),LPCTSTR(m_OptionDlg.m_strCustomName), filecnt, tcFileType);
			}
			
			*(wcschr(m_tcFileFullName, L'.') +1) = NULL;
			
		}
		
		if(FALSE == m_OptionDlg.m_bBMTSaveFormat)
		{
			wsprintf(m_tcFileFullName, L"%sjpg", m_tcFileFullName);
		}
		else
		{
			wsprintf(m_tcFileFullName, L"%sbmp", m_tcFileFullName);
		}
	

		if(Capture(m_tcFileFullName))
		{
			//NKDbgPrintfW(m_tcFileFullName);
		}
		else
		{
			MessageBox(L"you must start preview");				//	test
			m_bCapturring = FALSE;
			return;
		}
		
		HINSTANCE hInst = AfxGetInstanceHandle();
		PlaySound(MAKEINTRESOURCE(IDR_WAVE_SHUTTER), hInst, SND_RESOURCE|SND_ASYNC);
	}
}

void CCam2Dlg::OnButtonViewer() 
{

	CViewer Viewdlg;
	TCHAR szPath[MAX_PATH];
	
	wcscpy(szPath,m_OptionDlg.m_strSaveFolder.GetBuffer(0));
	
	/*
	
	  TCHAR szFilter[] = L"*.*||";
	  TCHAR szPath[MAX_PATH];
	  
		
		  CFileDialog dlg(TRUE, NULL, NULL, OFN_HIDEREADONLY, szFilter);
		  if(IDOK == dlg.DoModal())
		  {
		  wcscpy(szPath, dlg.GetPathName());
		  ImageFileLoad(szPath, TRUE);
		  }
	*/
	
	
	
	if(FALSE == ImageFileLoad(szPath, FALSE))
		return;
	
	m_ViewImageCtl = &(Viewdlg.m_ctlView);
	
	// 	DWORD ThreadID;
	// 	HANDLE hThread = CreateThread(NULL, 0, FirstViewThreadFunc, this, 0, &ThreadID);
	// 	CloseHandle(hThread);
	
	Viewdlg.DoModal();
}

void CCam2Dlg::OnButtonOption() 
{
	m_OptionDlg.DoModal();
}

void CCam2Dlg::OnButtonInfo() 
{
	CInfo dlg;
	dlg.DoModal();
}

void CCam2Dlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	PreviewStop();
	Connect(FALSE);

	
}



void CCam2Dlg::ImageLoad(WCHAR *FileName, CStatic *ImageCtl /*=NULL*/)
{

	RECT				rect;
	//	CDC					*hWndDC;
	//	HDC					hDCmem;

	HRESULT				hr;
	//	IImage				*pImage;
	//	IImagingFactory		*pImagingFactory;


	CDC					*m_hWndDC;
	HDC					m_hDCmem;

	IImage				*m_pImage;
	IImagingFactory		*m_pImagingFactory;


	if(ImageCtl == NULL)
	{
		m_hWndDC = m_ctlstaticImage.GetDC();
		m_ctlstaticImage.GetClientRect(&rect);
	}
	else
	{
		m_hWndDC = ImageCtl->GetDC();
		ImageCtl->GetClientRect(&rect);
	}
	m_hDCmem = CreateCompatibleDC( m_hWndDC->m_hDC );

	m_pImage = NULL;
	m_pImagingFactory = NULL;


	hr = CoCreateInstance(CLSID_ImagingFactory, NULL, CLSCTX_INPROC_SERVER, IID_IImagingFactory, (void**) &m_pImagingFactory);

	if (FAILED(hr)) 
		goto finish;

	if(FileName == NULL)
	{
		;
	//	hr = m_pImagingFactory->CreateImageFromBuffer(m_image->puchBuffer, m_image->nBufferSize, BufferDisposalFlagNone, &m_pImage);//sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER)+ sizeof(RGBQUAD)*256 + 160*216 -1 ,BufferDisposalFlagNone, &m_pImage);
	}
	else// if(m_image->fileFormat != FF_TIFF_GRAY)	/// TIFF�� ����� ���� 
		hr = m_pImagingFactory->CreateImageFromFile(FileName, &m_pImage);

	if (FAILED(hr) || m_pImage == NULL)   
		goto finish;

	hr = m_pImage->Draw(m_hWndDC->m_hDC, &rect, NULL);



	if(hr != S_OK)
		;//MessageBox(L"error");

finish:

	if (m_pImage)                 
		m_pImage->Release();

	if (m_pImagingFactory)    
		m_pImagingFactory->Release();

	DeleteDC(m_hDCmem);

	if(ImageCtl == NULL)
	{
		m_ctlstaticImage.ReleaseDC( m_hWndDC );

// 		if((bCaptureThread == FALSE) && (m_bClear == TRUE))
// 		{
// 			m_staticImage.EnableWindow(FALSE);
// 		}
	}
	else
		ImageCtl->ReleaseDC( m_hWndDC );

}

LRESULT CCam2Dlg::OnImageView(WPARAM wParam, LPARAM lParam)
{
/*
	TCHAR msg[256];

	MEMORYSTATUS memstat;



	GlobalMemoryStatus(&memstat);
	
	wsprintf(msg, L"[+OnImageView][%d] %.2f::%2f\r\n", num, memstat.dwTotalPhys/1048576.0, (memstat.dwTotalPhys - memstat.dwAvailPhys)/1048576.0);
	NKDbgPrintfW(msg);
*/
	ImageLoad(m_tcFileFullName);
	Sleep(900);

	m_btnCapture.EnableWindow(TRUE);
	m_btnStop.EnableWindow(TRUE);
	m_bCapturring = FALSE;

/*
	GlobalMemoryStatus(&memstat);

	wsprintf(msg, L"[-OnImageView][%d] %.2f::%2f\r\n", num, memstat.dwTotalPhys/1048576.0, (memstat.dwTotalPhys - memstat.dwAvailPhys)/1048576.0);
	NKDbgPrintfW(msg);

	num++;
*/
	return 0;
}


BOOL CCam2Dlg::ImageFileLoad(PTCHAR pstrPath, BOOL bFullPath /* = FALSE */)
{
	TCHAR	strFileName[MAX_PATH];
	TCHAR	strFullName[MAX_PATH];
	PTCHAR	pFileName = pstrPath;
	PTCHAR	pDirectory = NULL;

	while(!m_filelist.IsEmpty())
	{
		delete (m_filelist.RemoveTail());
	}

	//	File Full Name����  ���� �̸��� ������ �д� 
	if(TRUE == bFullPath)	
	{

		while(NULL !=(pFileName = wcschr(pFileName, L'\\')))
		{
			pDirectory = pFileName;
			++pFileName;

		}
		wcscpy(strFileName, pDirectory+1);

		pDirectory = NULL;		//	���丮 ��� : pstrPath 
		++pFileName;			//	���� �̸�
	}
	else
	{
		pDirectory = pstrPath;

		while(NULL != *pDirectory)
			pDirectory++;
	}


	//	�ش� ��ο� �ִ� ��Ʈ��(bmp)���� �� jpg���� �˻�


	wcscat(pstrPath,L"\\*.*");

	m_hFind = FindFirstFile(pstrPath,&m_fd);//L"\\Flash Disk\\Camera\\*.*", &m_fd);

	if(m_hFind == INVALID_HANDLE_VALUE)
	{
		AfxMessageBox(L"Not image file");
		return FALSE;
	}

	*pDirectory = NULL;
	////////////////////////////////////////////////////////////////////////////////////////////////
	//
	//	if
	//	1: "\\Flash Disk\\Camera\\*.*" ���� ���ϸ� �˻� 
	//  2: bmp, jpg Ȯ���� ���ϸ� �˻�
	//	 
	do
	{	
		if(!(m_fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))		// 1:
		{	
			if((wcsstr(m_fd.cFileName, L".bmp") != NULL) || (wcsstr(m_fd.cFileName, L".jpg") != NULL))	// 2:
			{	 	
				wcscpy(strFullName, pstrPath);//L"\\Flash Disk\\Camera\\");
				wcscat(strFullName, L"\\");
				wcscat(strFullName, m_fd.cFileName);

				pFileName = new TCHAR[sizeof(TCHAR) * wcslen(strFullName) + 1];
				wcscpy(pFileName, strFullName);
				m_filelist.AddTail(pFileName);
			}
		}			
	}while(FindNextFile(m_hFind, &m_fd));

	if(m_filelist.IsEmpty())
	{
		MessageBox(L"Not image file");
		return FALSE;
	}
	else
	{
		m_listpos = m_filelist.GetTailPosition();


		if(TRUE == bFullPath)
		{
			*pDirectory  = L'\\';
			m_listpos = m_filelist.GetHeadPosition();	//	������ ã�� ���ؼ� ����Ʈ�� ����� �̵��Ѵ�.


			while( (0 != wcscmp(pstrPath, m_filelist.GetAt(m_listpos))) && (m_filelist.GetTailPosition() != m_listpos))		// ���� ���� ���̾�α׿��� ������ ���ϰ� ��ġ�ϰų� ����Ʈ�� �� ��忡 ������ ������ �̵��Ѵ�.
			{
				m_filelist.GetNext(m_listpos);
			}
			if(m_filelist.GetHeadPosition() != m_listpos)	// ����� �ƴ϶�� ���� ���� �̵� �ֳ��ϸ� Viewer���� down�̹����� �Ͽ��� �̵��Ұ� �̱� �����̴�.
				m_filelist.GetPrev(m_listpos);
			else
				m_listpos  = m_filelist.GetTailPosition();
		}
		return TRUE;
	}
}


void CCam2Dlg::ViewDown() 
{	
	if(m_filelist.GetTailPosition() != m_listpos)
	{
		m_filelist.GetNext(m_listpos);
	}
	else
	{
		m_listpos = m_filelist.GetHeadPosition();
	}

	ImageLoad(m_filelist.GetAt(m_listpos), m_ViewImageCtl);
}

void CCam2Dlg::ViewUp() 
{	
	if(m_filelist.GetHeadPosition() != m_listpos)
		m_filelist.GetPrev(m_listpos);
	else
		m_listpos = m_filelist.GetTailPosition();

	ImageLoad(m_filelist.GetAt(m_listpos), m_ViewImageCtl);	
}


BOOL CCam2Dlg::PreTranslateMessage(MSG* pMsg) 
{
	if((pMsg->message == WM_KEYDOWN) && ((pMsg->wParam == VK_F23) || (pMsg->wParam == VK_RETURN)))
	{
		OnButtonCapture();

		if(pMsg->wParam == VK_RETURN)
		{
			return FALSE;
		}
	}

	if((pMsg->message == WM_SYSKEYDOWN) && ((pMsg->wParam == VK_F23) || (pMsg->wParam == VK_RETURN)))
	{
		OnButtonCapture();

		if(pMsg->wParam == VK_RETURN)
		{
			return FALSE;
		}
	}

	
	
	
	return CDialog::PreTranslateMessage(pMsg);
}
