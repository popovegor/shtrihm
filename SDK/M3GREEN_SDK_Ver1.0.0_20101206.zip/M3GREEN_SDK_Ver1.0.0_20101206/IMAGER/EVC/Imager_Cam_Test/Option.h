#if !defined(AFX_OPTION_H__8CE4F2EE_5057_4DC3_A1F2_B69560769FC5__INCLUDED_)
#define AFX_OPTION_H__8CE4F2EE_5057_4DC3_A1F2_B69560769FC5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Option.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COption dialog

class COption : public CDialog
{
public:
	BOOL m_bDateNameType;
	BOOL m_bBMTSaveFormat;


// Construction
public:
	COption(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(COption)
	enum { IDD = IDD_OPTION_DLG };
	CStatic	m_scctlNameType;
	CSpinButtonCtrl	m_ctlspinJpegQuality;
	CComboBox	m_cbctlNameType;
	CEdit	m_ebctlCustomName;
	CComboBox	m_cbctlResolution;
	CComboBox	m_cbctlSaveFormat;
	CString	m_strSaveFolder;
	UINT	m_nJpegQuality;
	CString	m_strCustomName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COption)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(COption)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnSelchangeNameTypeCombo();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTION_H__8CE4F2EE_5057_4DC3_A1F2_B69560769FC5__INCLUDED_)
