// Info.cpp : implementation file
//

#include "stdafx.h"
#include "Cam2.h"
#include "Info.h"

#include "M3MobileImager.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInfo dialog


CInfo::CInfo(CWnd* pParent /*=NULL*/)
	: CDialog(CInfo::IDD, pParent)
{
	//{{AFX_DATA_INIT(CInfo)
	m_strInfo = _T("");
	//}}AFX_DATA_INIT
}


void CInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInfo)
	DDX_Text(pDX, IDC_EDIT_INFO, m_strInfo);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CInfo, CDialog)
	//{{AFX_MSG_MAP(CInfo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInfo message handlers

BOOL CInfo::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	
	
	IMAGER_VERSION_INFO info;
	
	GetInfo(&info);
	
	CInfo dlg;
	
	m_strInfo.Format(L"%s \r\n%s \r\n%s \r\nFirmwareVersion:%d \r\nFirmwareCksum:%d \r\nEngineID:%d \r\n\r\n%s\
						  \r\n\r\nProgram Version 2.0.0 \r\nBuild Date 2010.03.08", 
						  info.tcAPIRev, info.tcDecoderRev, info.tcScanDriverRev, 
						  info.dwFirmwareVersion, info.dwFirmwareCksum, info.dwEngineId,
						  info.tcEtcInfo);
	
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
