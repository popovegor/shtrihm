#if !defined(AFX_VIEWER_H__623C3C18_9FD4_4307_8C78_7600A36C7792__INCLUDED_)
#define AFX_VIEWER_H__623C3C18_9FD4_4307_8C78_7600A36C7792__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Viewer.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CViewer dialog

class CViewer : public CDialog
{
private:
	CPoint m_pt;

// Construction
public:
	CViewer(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CViewer)
	enum { IDD = IDD_VIEWER_DLG };
	CStatic	m_ctlView;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CViewer)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CViewer)
	virtual BOOL OnInitDialog();
	afx_msg void OnLeft();
	afx_msg void OnRight();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VIEWER_H__623C3C18_9FD4_4307_8C78_7600A36C7792__INCLUDED_)
