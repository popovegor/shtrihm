//{{NO_DEPENDENCIES}}
// Microsoft eMbedded Visual C++ generated include file.
// Used by Cam2.rc
//
#define IDD_CAM2_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDR_WAVE_SHUTTER                129
#define IDD_OPTION_DLG                  129
#define IDD_INFO_DLG                    130
#define IDB_BITMAP_LOGO                 131
#define IDD_VIEWER_DLG                  131
#define IDB_BITMAP_M3LOGO               132
#define IDC_BUTTON_OPTION               1000
#define IDC_BUTTON_START                1001
#define IDC_BUTTON_STOP                 1002
#define IDC_BUTTON_CAPTURE              1003
#define IDC_BUTTON_INFO                 1004
#define IDC_EDIT_INFO                   1005
#define IDC_STATIC_IMAGE                1005
#define IDC_BUTTON_VIEWER               1006
#define IDC_EDIT_JPEG_QUALITY           1007
#define IDC_SPIN_JPEG_QUALITY           1008
#define IDC_COMBO_RESOLUTION            1009
#define IDC_COMBO_FORMAT                1010
#define IDC_EDIT_SAVE_FOLDER            1011
#define IDC_NAME_TYPE_COMBO             1012
#define IDC_EDIT_CUSTOM_NAME            1013
#define IDC_LEFT                        1014
#define IDC_RIGHT                       1015
#define IDC_STATIC_VIEWER               1016
#define IDC_STATIC_CUSTOM_NAME          1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
