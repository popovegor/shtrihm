﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using M3PSSLibNetCla;

namespace M3PlusCE5NetTest
{

   

    public partial class Form1 : Form
    {

        private M3PSSLibNetCla.ScannerControl ScanCtrl;
        private MCPScanOption McpScan;
        private MCPBarCodeType Mcpbar;
        bool bDownFlag = true;
        private string soundstr = "\\Windows\\alarm4.wav";
        
        public Form1()
        {
            InitializeComponent();
            ScanCtrl = new ScannerControl();
             McpScan = new MCPScanOption();
              Mcpbar = new MCPBarCodeType();
            ScanCtrl.ScannerDataEvent += new ScannerDataDelegate(OnScanData);
        }

        
        

        


        private void OnScanData(object sender, ScannerDataArgs e)
        {
            if (LVBarCode.Items.Count > 6)               
                LVBarCode.Items.Clear();

            ListViewItem BarcodeItem = new ListViewItem();
            BarcodeItem.Text = e.ScanType;
            BarcodeItem.SubItems.Add(e.ScanData);

            LVBarCode.Items.Add(BarcodeItem);
            Play_sound();


           

        }
        private void Play_sound()
        {
            if (McpScan.nmcp_sound == 1)
                ScanCtrl.PlaySound(true, soundstr);
            else
                ScanCtrl.PlaySound(false, soundstr);
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            if (!ScanCtrl.ScanOpen())              
                MessageBox.Show("Load fail");
            ScanCtrl.GetScan_Option(out McpScan);
            tabControl1.Focus();            
        
        }
        private void BTScan_Click(object sender, EventArgs e)
        {
            
            ScanCtrl.ScanRead();
            tabControl1.Focus();
            
        }
        private void BTScanCancel_Click(object sender, EventArgs e)
        {
            ScanCtrl.ScanReadCancel();
            tabControl1.Focus();
        }

        private void Form1_Closing(object sender, CancelEventArgs e)
        {
            if(!ScanCtrl.ScanClose())
                MessageBox.Show("close fail");
        }
            

        private void BTVersion_Click(object sender, EventArgs e)
        {
            string strver;
            strver = ScanCtrl.ScanGetRevision();
            MessageBox.Show(strver);
            tabControl1.Focus();
        }

        

        private void BTClose_Click(object sender, EventArgs e)
        {
            base.Dispose();

        }

        private void ScanOption_confirmbutton_Click(object sender, EventArgs e)
        {

            
            
            McpScan.nmcp_laser_on_time  = (int)Laser_On_TimenumericUpDown1.Value;
            McpScan.nmcp_security_levels = (int)Security_Level_numericUpDown.Value;
            McpScan.nmcp_scan_angle = Scan_Angle_comboBox.SelectedIndex;
            if (Power_Mode_checkBox.Checked == true)
                 McpScan.nmcp_power_mode = 1;
            else
                 McpScan.nmcp_power_mode = 0;
            if (ScanMode_radioButton1.Checked == true )
                 McpScan.nmcp_sync = 0;
            else
                 McpScan.nmcp_sync = 1;
             if (SoundcheckBox.Checked == true)
                 McpScan.nmcp_sound = 1;
             else
                 McpScan.nmcp_sound = 0;
            

            ScanCtrl.SetScan_Option(ref McpScan);
            tabControl1.SelectedIndex = 0;
            tabControl1.Focus();
            
        }

        private void BarCode_confirmbutton_Click(object sender, EventArgs e)
        {


            
            
             Mcpbar.bookland_ean    = BOOKLAND_EANcheckBox.Checked;
             Mcpbar.code39          = CODE39checkBox.Checked;
             Mcpbar.trioptic39      = TRIOPTIC39checkBox.Checked;
             Mcpbar.isbt_128        = ISBT_128checkBox.Checked;
             Mcpbar.ucc_ean128      = UCC_EAN128checkBox.Checked;
             Mcpbar.code128         = CODE128checkBox.Checked ;
             Mcpbar.coupon          = COUPONcheckBox.Checked;
             Mcpbar.ean13           = EAN13checkBox.Checked;
             Mcpbar.ean8            = EAN8checkBox.Checked;
             Mcpbar.upce1           = UPCE1checkBox.Checked;
             Mcpbar.upce1           = UPCEcheckBox.Checked;
             Mcpbar.upca            = UPCAcheckBox.Checked;
             Mcpbar.msi_plessey     = MSI_PLESSEYcheckBox.Checked;
             Mcpbar.codabar         = CODABARcheckBox.Checked;
             Mcpbar.dis2of5         = DIS2OF5checkBox.Checked;
             Mcpbar.i2of5           = I2OF5checkBox.Checked;
             Mcpbar.code93          = CODE93checkBox.Checked;
             Mcpbar.code11          = CODE11checkBox.Checked;
             Mcpbar.ch2of5          = CH2OF5checkBox.Checked;
             Mcpbar.gs1             = GS1checkBox.Checked;
             Mcpbar.gs1_limited     = GS1LIMITEDcheckBox.Checked;
             Mcpbar.gs1_expanded    = GS1EXPANDEDcheckBox.Checked;
             ScanCtrl.SetBarCode_Type(ref Mcpbar);
            tabControl1.SelectedIndex = 0;
            tabControl1.Focus();
        }

        private void tabControl1_KeyDown(object sender, KeyEventArgs e)
        {
            if (bDownFlag)
            {

                if (e.KeyCode == Keys.F22)
                {
                    if (McpScan.nmcp_sync == 0)
                        ScanCtrl.ScanReadCancel();
                    ScanCtrl.ScanRead();
                }
                bDownFlag = false;
            }
        }

        private void tabControl1_KeyUp(object sender, KeyEventArgs e)
        {
            if (!bDownFlag)
            {

                if (e.KeyCode == Keys.F22)
                {
                    if (McpScan.nmcp_sync == 1)
                    ScanCtrl.ScanReadCancel();
                }
                bDownFlag = true;
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (tabControl1.SelectedIndex)
            {
                case 0:

                    ScanCtrl.GetScan_Option(out McpScan);
                    tabControl1.Focus();
                    break;
                case 1:
                    ScanCtrl.ScanReadCancel();
                    ScanCtrl.GetBarCode_Type(out Mcpbar);
                    BOOKLAND_EANcheckBox.Checked    = Mcpbar.bookland_ean;
                    CODE39checkBox.Checked          = Mcpbar.code39;
                    TRIOPTIC39checkBox.Checked      = Mcpbar.trioptic39;
                    ISBT_128checkBox.Checked        = Mcpbar.isbt_128;
                    UCC_EAN128checkBox.Checked      = Mcpbar.ucc_ean128;
                    CODE128checkBox.Checked         = Mcpbar.code128;
                    COUPONcheckBox .Checked         = Mcpbar.coupon;                  
                    EAN13checkBox.Checked           = Mcpbar.ean13;
                    EAN8checkBox.Checked            = Mcpbar.ean8;
                    UPCE1checkBox.Checked           = Mcpbar.upce1;
                    UPCEcheckBox.Checked            = Mcpbar.upce1;
                    UPCAcheckBox.Checked            = Mcpbar.upca;
                    MSI_PLESSEYcheckBox.Checked     = Mcpbar.msi_plessey;
                    CODABARcheckBox.Checked         = Mcpbar.codabar;
                    DIS2OF5checkBox.Checked         = Mcpbar.dis2of5;
                    I2OF5checkBox.Checked           = Mcpbar.i2of5;
                    CODE93checkBox.Checked          = Mcpbar.code93;
                    CODE11checkBox.Checked          = Mcpbar.code11;
                    CH2OF5checkBox.Checked          = Mcpbar.ch2of5;
                    GS1checkBox.Checked             = Mcpbar.gs1;
                    GS1LIMITEDcheckBox.Checked      = Mcpbar.gs1_limited;
                    GS1EXPANDEDcheckBox.Checked     = Mcpbar.gs1_expanded;
                    break;
                case 2:
                    ScanCtrl.ScanReadCancel();
                    ScanCtrl.GetScan_Option(out McpScan);
                    Laser_On_TimenumericUpDown1.Value = McpScan.nmcp_laser_on_time;
                    Security_Level_numericUpDown.Value = McpScan.nmcp_security_levels;
                    Scan_Angle_comboBox.SelectedIndex = McpScan.nmcp_scan_angle;
                    if (McpScan.nmcp_power_mode == 1)
                        Power_Mode_checkBox.Checked = true;
                    else
                        Power_Mode_checkBox.Checked = false;
                    if (McpScan.nmcp_sync == 0)
                        ScanMode_radioButton1.Checked = true;
                    else
                        ScanMode_radioButton2.Checked = true;
                    if (McpScan.nmcp_sound == 1)
                        SoundcheckBox.Checked = true;
                    else
                        SoundcheckBox.Checked = false;

                    
                    break;
            }

        } 
        
    }
}