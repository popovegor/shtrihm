﻿namespace M3PlusCE5NetTest
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.ScanTest = new System.Windows.Forms.TabPage();
            this.AppClose = new System.Windows.Forms.Button();
            this.BUTVersion = new System.Windows.Forms.Button();
            this.BTScanCancel = new System.Windows.Forms.Button();
            this.BTScan = new System.Windows.Forms.Button();
            this.LVBarCode = new System.Windows.Forms.ListView();
            this.BarType = new System.Windows.Forms.ColumnHeader();
            this.BarData = new System.Windows.Forms.ColumnHeader();
            this.BarCode = new System.Windows.Forms.TabPage();
            this.CH2OF5checkBox = new System.Windows.Forms.CheckBox();
            this.CODE11checkBox = new System.Windows.Forms.CheckBox();
            this.BarCode_confirmbutton = new System.Windows.Forms.Button();
            this.MSI_PLESSEYcheckBox = new System.Windows.Forms.CheckBox();
            this.CODABARcheckBox = new System.Windows.Forms.CheckBox();
            this.DIS2OF5checkBox = new System.Windows.Forms.CheckBox();
            this.I2OF5checkBox = new System.Windows.Forms.CheckBox();
            this.CODE93checkBox = new System.Windows.Forms.CheckBox();
            this.CODE39checkBox = new System.Windows.Forms.CheckBox();
            this.TRIOPTIC39checkBox = new System.Windows.Forms.CheckBox();
            this.ISBT_128checkBox = new System.Windows.Forms.CheckBox();
            this.UCC_EAN128checkBox = new System.Windows.Forms.CheckBox();
            this.CODE128checkBox = new System.Windows.Forms.CheckBox();
            this.COUPONcheckBox = new System.Windows.Forms.CheckBox();
            this.BOOKLAND_EANcheckBox = new System.Windows.Forms.CheckBox();
            this.EAN13checkBox = new System.Windows.Forms.CheckBox();
            this.EAN8checkBox = new System.Windows.Forms.CheckBox();
            this.UPCE1checkBox = new System.Windows.Forms.CheckBox();
            this.UPCEcheckBox = new System.Windows.Forms.CheckBox();
            this.UPCAcheckBox = new System.Windows.Forms.CheckBox();
            this.ScanOption = new System.Windows.Forms.TabPage();
            this.SoundcheckBox = new System.Windows.Forms.CheckBox();
            this.ScanOption_confirmbutton = new System.Windows.Forms.Button();
            this.Scan_Angle_comboBox = new System.Windows.Forms.ComboBox();
            this.Power_Mode_checkBox = new System.Windows.Forms.CheckBox();
            this.ScanMode_radioButton2 = new System.Windows.Forms.RadioButton();
            this.ScanMode_radioButton1 = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Laser_On_Time = new System.Windows.Forms.Label();
            this.Security_Level_numericUpDown = new System.Windows.Forms.NumericUpDown();
            this.Laser_On_TimenumericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.GS1checkBox = new System.Windows.Forms.CheckBox();
            this.GS1LIMITEDcheckBox = new System.Windows.Forms.CheckBox();
            this.GS1EXPANDEDcheckBox = new System.Windows.Forms.CheckBox();
            this.tabControl1.SuspendLayout();
            this.ScanTest.SuspendLayout();
            this.BarCode.SuspendLayout();
            this.ScanOption.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.ScanTest);
            this.tabControl1.Controls.Add(this.BarCode);
            this.tabControl1.Controls.Add(this.ScanOption);
            this.tabControl1.Location = new System.Drawing.Point(1, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(240, 294);
            this.tabControl1.TabIndex = 2;
            this.tabControl1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.tabControl1_KeyUp);
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            this.tabControl1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tabControl1_KeyDown);
            // 
            // ScanTest
            // 
            this.ScanTest.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ScanTest.Controls.Add(this.AppClose);
            this.ScanTest.Controls.Add(this.BUTVersion);
            this.ScanTest.Controls.Add(this.BTScanCancel);
            this.ScanTest.Controls.Add(this.BTScan);
            this.ScanTest.Controls.Add(this.LVBarCode);
            this.ScanTest.Location = new System.Drawing.Point(4, 25);
            this.ScanTest.Name = "ScanTest";
            this.ScanTest.Size = new System.Drawing.Size(232, 265);
            this.ScanTest.Text = "ScanTest";
            // 
            // AppClose
            // 
            this.AppClose.Location = new System.Drawing.Point(123, 223);
            this.AppClose.Name = "AppClose";
            this.AppClose.Size = new System.Drawing.Size(98, 35);
            this.AppClose.TabIndex = 6;
            this.AppClose.Text = "Close";
            this.AppClose.Click += new System.EventHandler(this.BTClose_Click);
            // 
            // BUTVersion
            // 
            this.BUTVersion.Location = new System.Drawing.Point(8, 223);
            this.BUTVersion.Name = "BUTVersion";
            this.BUTVersion.Size = new System.Drawing.Size(98, 35);
            this.BUTVersion.TabIndex = 3;
            this.BUTVersion.Text = "version";
            this.BUTVersion.Click += new System.EventHandler(this.BTVersion_Click);
            // 
            // BTScanCancel
            // 
            this.BTScanCancel.Location = new System.Drawing.Point(123, 185);
            this.BTScanCancel.Name = "BTScanCancel";
            this.BTScanCancel.Size = new System.Drawing.Size(98, 35);
            this.BTScanCancel.TabIndex = 5;
            this.BTScanCancel.Text = "Scan Cancel";
            this.BTScanCancel.Click += new System.EventHandler(this.BTScanCancel_Click);
            // 
            // BTScan
            // 
            this.BTScan.Location = new System.Drawing.Point(8, 185);
            this.BTScan.Name = "BTScan";
            this.BTScan.Size = new System.Drawing.Size(98, 35);
            this.BTScan.TabIndex = 4;
            this.BTScan.Text = "Scan";
            this.BTScan.Click += new System.EventHandler(this.BTScan_Click);
            // 
            // LVBarCode
            // 
            this.LVBarCode.Columns.Add(this.BarType);
            this.LVBarCode.Columns.Add(this.BarData);
            this.LVBarCode.FullRowSelect = true;
            this.LVBarCode.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.LVBarCode.Location = new System.Drawing.Point(5, 3);
            this.LVBarCode.Name = "LVBarCode";
            this.LVBarCode.Size = new System.Drawing.Size(224, 176);
            this.LVBarCode.TabIndex = 3;
            this.LVBarCode.View = System.Windows.Forms.View.Details;
            // 
            // BarType
            // 
            this.BarType.Text = "Type";
            this.BarType.Width = 60;
            // 
            // BarData
            // 
            this.BarData.Text = "Data";
            this.BarData.Width = 160;
            // 
            // BarCode
            // 
            this.BarCode.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.BarCode.Controls.Add(this.GS1EXPANDEDcheckBox);
            this.BarCode.Controls.Add(this.GS1LIMITEDcheckBox);
            this.BarCode.Controls.Add(this.GS1checkBox);
            this.BarCode.Controls.Add(this.CH2OF5checkBox);
            this.BarCode.Controls.Add(this.CODE11checkBox);
            this.BarCode.Controls.Add(this.BarCode_confirmbutton);
            this.BarCode.Controls.Add(this.MSI_PLESSEYcheckBox);
            this.BarCode.Controls.Add(this.CODABARcheckBox);
            this.BarCode.Controls.Add(this.DIS2OF5checkBox);
            this.BarCode.Controls.Add(this.I2OF5checkBox);
            this.BarCode.Controls.Add(this.CODE93checkBox);
            this.BarCode.Controls.Add(this.CODE39checkBox);
            this.BarCode.Controls.Add(this.TRIOPTIC39checkBox);
            this.BarCode.Controls.Add(this.ISBT_128checkBox);
            this.BarCode.Controls.Add(this.UCC_EAN128checkBox);
            this.BarCode.Controls.Add(this.CODE128checkBox);
            this.BarCode.Controls.Add(this.COUPONcheckBox);
            this.BarCode.Controls.Add(this.BOOKLAND_EANcheckBox);
            this.BarCode.Controls.Add(this.EAN13checkBox);
            this.BarCode.Controls.Add(this.EAN8checkBox);
            this.BarCode.Controls.Add(this.UPCE1checkBox);
            this.BarCode.Controls.Add(this.UPCEcheckBox);
            this.BarCode.Controls.Add(this.UPCAcheckBox);
            this.BarCode.Location = new System.Drawing.Point(4, 25);
            this.BarCode.Name = "BarCode";
            this.BarCode.Size = new System.Drawing.Size(232, 265);
            this.BarCode.Text = "BarCode";
            // 
            // CH2OF5checkBox
            // 
            this.CH2OF5checkBox.Location = new System.Drawing.Point(120, 94);
            this.CH2OF5checkBox.Name = "CH2OF5checkBox";
            this.CH2OF5checkBox.Size = new System.Drawing.Size(100, 20);
            this.CH2OF5checkBox.TabIndex = 19;
            this.CH2OF5checkBox.Text = "CH2OF5";
            // 
            // CODE11checkBox
            // 
            this.CODE11checkBox.Location = new System.Drawing.Point(120, 40);
            this.CODE11checkBox.Name = "CODE11checkBox";
            this.CODE11checkBox.Size = new System.Drawing.Size(100, 20);
            this.CODE11checkBox.TabIndex = 18;
            this.CODE11checkBox.Text = "CODE11";
            // 
            // BarCode_confirmbutton
            // 
            this.BarCode_confirmbutton.Location = new System.Drawing.Point(120, 219);
            this.BarCode_confirmbutton.Name = "BarCode_confirmbutton";
            this.BarCode_confirmbutton.Size = new System.Drawing.Size(100, 35);
            this.BarCode_confirmbutton.TabIndex = 17;
            this.BarCode_confirmbutton.Text = "Confirm";
            this.BarCode_confirmbutton.Click += new System.EventHandler(this.BarCode_confirmbutton_Click);
            // 
            // MSI_PLESSEYcheckBox
            // 
            this.MSI_PLESSEYcheckBox.Location = new System.Drawing.Point(120, 130);
            this.MSI_PLESSEYcheckBox.Name = "MSI_PLESSEYcheckBox";
            this.MSI_PLESSEYcheckBox.Size = new System.Drawing.Size(114, 18);
            this.MSI_PLESSEYcheckBox.TabIndex = 16;
            this.MSI_PLESSEYcheckBox.Text = "MSI";
            // 
            // CODABARcheckBox
            // 
            this.CODABARcheckBox.Location = new System.Drawing.Point(120, 112);
            this.CODABARcheckBox.Name = "CODABARcheckBox";
            this.CODABARcheckBox.Size = new System.Drawing.Size(100, 18);
            this.CODABARcheckBox.TabIndex = 15;
            this.CODABARcheckBox.Text = "CODABAR";
            // 
            // DIS2OF5checkBox
            // 
            this.DIS2OF5checkBox.Location = new System.Drawing.Point(120, 76);
            this.DIS2OF5checkBox.Name = "DIS2OF5checkBox";
            this.DIS2OF5checkBox.Size = new System.Drawing.Size(100, 18);
            this.DIS2OF5checkBox.TabIndex = 14;
            this.DIS2OF5checkBox.Text = "DIS2OF5";
            // 
            // I2OF5checkBox
            // 
            this.I2OF5checkBox.Location = new System.Drawing.Point(120, 58);
            this.I2OF5checkBox.Name = "I2OF5checkBox";
            this.I2OF5checkBox.Size = new System.Drawing.Size(100, 18);
            this.I2OF5checkBox.TabIndex = 13;
            this.I2OF5checkBox.Text = "I2OF5";
            // 
            // CODE93checkBox
            // 
            this.CODE93checkBox.Location = new System.Drawing.Point(3, 184);
            this.CODE93checkBox.Name = "CODE93checkBox";
            this.CODE93checkBox.Size = new System.Drawing.Size(100, 18);
            this.CODE93checkBox.TabIndex = 12;
            this.CODE93checkBox.Text = "CODE93";
            // 
            // CODE39checkBox
            // 
            this.CODE39checkBox.Location = new System.Drawing.Point(120, 23);
            this.CODE39checkBox.Name = "CODE39checkBox";
            this.CODE39checkBox.Size = new System.Drawing.Size(100, 18);
            this.CODE39checkBox.TabIndex = 11;
            this.CODE39checkBox.Text = "CODE39";
            // 
            // TRIOPTIC39checkBox
            // 
            this.TRIOPTIC39checkBox.Location = new System.Drawing.Point(120, 4);
            this.TRIOPTIC39checkBox.Name = "TRIOPTIC39checkBox";
            this.TRIOPTIC39checkBox.Size = new System.Drawing.Size(111, 18);
            this.TRIOPTIC39checkBox.TabIndex = 10;
            this.TRIOPTIC39checkBox.Text = "TRIOPTIC39";
            // 
            // ISBT_128checkBox
            // 
            this.ISBT_128checkBox.Location = new System.Drawing.Point(3, 166);
            this.ISBT_128checkBox.Name = "ISBT_128checkBox";
            this.ISBT_128checkBox.Size = new System.Drawing.Size(100, 20);
            this.ISBT_128checkBox.TabIndex = 9;
            this.ISBT_128checkBox.Text = "ISBT_128";
            // 
            // UCC_EAN128checkBox
            // 
            this.UCC_EAN128checkBox.Location = new System.Drawing.Point(3, 148);
            this.UCC_EAN128checkBox.Name = "UCC_EAN128checkBox";
            this.UCC_EAN128checkBox.Size = new System.Drawing.Size(109, 20);
            this.UCC_EAN128checkBox.TabIndex = 8;
            this.UCC_EAN128checkBox.Text = "UCC_EAN128";
            // 
            // CODE128checkBox
            // 
            this.CODE128checkBox.Location = new System.Drawing.Point(3, 130);
            this.CODE128checkBox.Name = "CODE128checkBox";
            this.CODE128checkBox.Size = new System.Drawing.Size(100, 20);
            this.CODE128checkBox.TabIndex = 7;
            this.CODE128checkBox.Text = "CODE128";
            // 
            // COUPONcheckBox
            // 
            this.COUPONcheckBox.Location = new System.Drawing.Point(3, 112);
            this.COUPONcheckBox.Name = "COUPONcheckBox";
            this.COUPONcheckBox.Size = new System.Drawing.Size(100, 20);
            this.COUPONcheckBox.TabIndex = 6;
            this.COUPONcheckBox.Text = "COUPON";
            // 
            // BOOKLAND_EANcheckBox
            // 
            this.BOOKLAND_EANcheckBox.Location = new System.Drawing.Point(3, 94);
            this.BOOKLAND_EANcheckBox.Name = "BOOKLAND_EANcheckBox";
            this.BOOKLAND_EANcheckBox.Size = new System.Drawing.Size(130, 20);
            this.BOOKLAND_EANcheckBox.TabIndex = 5;
            this.BOOKLAND_EANcheckBox.Text = "BOOKLAND_EAN";
            // 
            // EAN13checkBox
            // 
            this.EAN13checkBox.Location = new System.Drawing.Point(3, 76);
            this.EAN13checkBox.Name = "EAN13checkBox";
            this.EAN13checkBox.Size = new System.Drawing.Size(100, 20);
            this.EAN13checkBox.TabIndex = 4;
            this.EAN13checkBox.Text = "EAN13";
            // 
            // EAN8checkBox
            // 
            this.EAN8checkBox.Location = new System.Drawing.Point(3, 58);
            this.EAN8checkBox.Name = "EAN8checkBox";
            this.EAN8checkBox.Size = new System.Drawing.Size(100, 20);
            this.EAN8checkBox.TabIndex = 3;
            this.EAN8checkBox.Text = "EAN8";
            // 
            // UPCE1checkBox
            // 
            this.UPCE1checkBox.Location = new System.Drawing.Point(3, 40);
            this.UPCE1checkBox.Name = "UPCE1checkBox";
            this.UPCE1checkBox.Size = new System.Drawing.Size(100, 20);
            this.UPCE1checkBox.TabIndex = 2;
            this.UPCE1checkBox.Text = "UPCE1";
            // 
            // UPCEcheckBox
            // 
            this.UPCEcheckBox.Location = new System.Drawing.Point(3, 22);
            this.UPCEcheckBox.Name = "UPCEcheckBox";
            this.UPCEcheckBox.Size = new System.Drawing.Size(100, 20);
            this.UPCEcheckBox.TabIndex = 1;
            this.UPCEcheckBox.Text = "UPCE";
            // 
            // UPCAcheckBox
            // 
            this.UPCAcheckBox.Location = new System.Drawing.Point(3, 4);
            this.UPCAcheckBox.Name = "UPCAcheckBox";
            this.UPCAcheckBox.Size = new System.Drawing.Size(100, 20);
            this.UPCAcheckBox.TabIndex = 0;
            this.UPCAcheckBox.Text = "UPCA";
            // 
            // ScanOption
            // 
            this.ScanOption.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ScanOption.Controls.Add(this.SoundcheckBox);
            this.ScanOption.Controls.Add(this.ScanOption_confirmbutton);
            this.ScanOption.Controls.Add(this.Scan_Angle_comboBox);
            this.ScanOption.Controls.Add(this.Power_Mode_checkBox);
            this.ScanOption.Controls.Add(this.ScanMode_radioButton2);
            this.ScanOption.Controls.Add(this.ScanMode_radioButton1);
            this.ScanOption.Controls.Add(this.label4);
            this.ScanOption.Controls.Add(this.label3);
            this.ScanOption.Controls.Add(this.label2);
            this.ScanOption.Controls.Add(this.Laser_On_Time);
            this.ScanOption.Controls.Add(this.Security_Level_numericUpDown);
            this.ScanOption.Controls.Add(this.Laser_On_TimenumericUpDown1);
            this.ScanOption.Location = new System.Drawing.Point(4, 25);
            this.ScanOption.Name = "ScanOption";
            this.ScanOption.Size = new System.Drawing.Size(232, 265);
            this.ScanOption.Text = "ScanOption";
            // 
            // SoundcheckBox
            // 
            this.SoundcheckBox.Location = new System.Drawing.Point(122, 187);
            this.SoundcheckBox.Name = "SoundcheckBox";
            this.SoundcheckBox.Size = new System.Drawing.Size(100, 20);
            this.SoundcheckBox.TabIndex = 17;
            this.SoundcheckBox.Text = "No Sound";
            // 
            // ScanOption_confirmbutton
            // 
            this.ScanOption_confirmbutton.Location = new System.Drawing.Point(122, 219);
            this.ScanOption_confirmbutton.Name = "ScanOption_confirmbutton";
            this.ScanOption_confirmbutton.Size = new System.Drawing.Size(98, 35);
            this.ScanOption_confirmbutton.TabIndex = 12;
            this.ScanOption_confirmbutton.Text = "Confirm";
            this.ScanOption_confirmbutton.Click += new System.EventHandler(this.ScanOption_confirmbutton_Click);
            // 
            // Scan_Angle_comboBox
            // 
            this.Scan_Angle_comboBox.Items.Add("NARROW");
            this.Scan_Angle_comboBox.Items.Add("WIDE");
            this.Scan_Angle_comboBox.Location = new System.Drawing.Point(106, 96);
            this.Scan_Angle_comboBox.Name = "Scan_Angle_comboBox";
            this.Scan_Angle_comboBox.Size = new System.Drawing.Size(109, 23);
            this.Scan_Angle_comboBox.TabIndex = 11;
            this.Scan_Angle_comboBox.Visible = false;
            // 
            // Power_Mode_checkBox
            // 
            this.Power_Mode_checkBox.Checked = true;
            this.Power_Mode_checkBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Power_Mode_checkBox.Location = new System.Drawing.Point(10, 187);
            this.Power_Mode_checkBox.Name = "Power_Mode_checkBox";
            this.Power_Mode_checkBox.Size = new System.Drawing.Size(103, 20);
            this.Power_Mode_checkBox.TabIndex = 10;
            this.Power_Mode_checkBox.Text = "Power Mode";
            // 
            // ScanMode_radioButton2
            // 
            this.ScanMode_radioButton2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ScanMode_radioButton2.Checked = true;
            this.ScanMode_radioButton2.Location = new System.Drawing.Point(115, 144);
            this.ScanMode_radioButton2.Name = "ScanMode_radioButton2";
            this.ScanMode_radioButton2.Size = new System.Drawing.Size(100, 20);
            this.ScanMode_radioButton2.TabIndex = 9;
            this.ScanMode_radioButton2.Text = "ASync";
            // 
            // ScanMode_radioButton1
            // 
            this.ScanMode_radioButton1.Location = new System.Drawing.Point(9, 144);
            this.ScanMode_radioButton1.Name = "ScanMode_radioButton1";
            this.ScanMode_radioButton1.Size = new System.Drawing.Size(100, 20);
            this.ScanMode_radioButton1.TabIndex = 8;
            this.ScanMode_radioButton1.TabStop = false;
            this.ScanMode_radioButton1.Text = "Sync";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(13, 121);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 20);
            this.label4.Text = "Scan Mode";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(13, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 23);
            this.label3.Text = "Scan Angle";
            this.label3.Visible = false;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(9, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 24);
            this.label2.Text = "Security Level";
            // 
            // Laser_On_Time
            // 
            this.Laser_On_Time.Location = new System.Drawing.Point(9, 23);
            this.Laser_On_Time.Name = "Laser_On_Time";
            this.Laser_On_Time.Size = new System.Drawing.Size(107, 22);
            this.Laser_On_Time.Text = "Laser_On_Time";
            // 
            // Security_Level_numericUpDown
            // 
            this.Security_Level_numericUpDown.Location = new System.Drawing.Point(131, 65);
            this.Security_Level_numericUpDown.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.Security_Level_numericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.Security_Level_numericUpDown.Name = "Security_Level_numericUpDown";
            this.Security_Level_numericUpDown.Size = new System.Drawing.Size(65, 24);
            this.Security_Level_numericUpDown.TabIndex = 1;
            this.Security_Level_numericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // Laser_On_TimenumericUpDown1
            // 
            this.Laser_On_TimenumericUpDown1.Location = new System.Drawing.Point(131, 21);
            this.Laser_On_TimenumericUpDown1.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.Laser_On_TimenumericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.Laser_On_TimenumericUpDown1.Name = "Laser_On_TimenumericUpDown1";
            this.Laser_On_TimenumericUpDown1.Size = new System.Drawing.Size(65, 24);
            this.Laser_On_TimenumericUpDown1.TabIndex = 0;
            this.Laser_On_TimenumericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 20);
            this.label1.Text = "label1";
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(0, 0);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new System.Drawing.Size(178, 155);
            this.monthCalendar1.TabIndex = 0;
            // 
            // GS1checkBox
            // 
            this.GS1checkBox.Location = new System.Drawing.Point(120, 148);
            this.GS1checkBox.Name = "GS1checkBox";
            this.GS1checkBox.Size = new System.Drawing.Size(100, 20);
            this.GS1checkBox.TabIndex = 20;
            this.GS1checkBox.Text = "GS1";
            // 
            // GS1LIMITEDcheckBox
            // 
            this.GS1LIMITEDcheckBox.Location = new System.Drawing.Point(120, 166);
            this.GS1LIMITEDcheckBox.Name = "GS1LIMITEDcheckBox";
            this.GS1LIMITEDcheckBox.Size = new System.Drawing.Size(111, 20);
            this.GS1LIMITEDcheckBox.TabIndex = 21;
            this.GS1LIMITEDcheckBox.Text = "GS1 LIMITED";
            // 
            // GS1EXPANDEDcheckBox
            // 
            this.GS1EXPANDEDcheckBox.Location = new System.Drawing.Point(120, 184);
            this.GS1EXPANDEDcheckBox.Name = "GS1EXPANDEDcheckBox";
            this.GS1EXPANDEDcheckBox.Size = new System.Drawing.Size(109, 20);
            this.GS1EXPANDEDcheckBox.TabIndex = 22;
            this.GS1EXPANDEDcheckBox.Text = "GS1 EXPANDED";
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(241, 296);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "ScanTest";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Closing += new System.ComponentModel.CancelEventHandler(this.Form1_Closing);
            this.tabControl1.ResumeLayout(false);
            this.ScanTest.ResumeLayout(false);
            this.BarCode.ResumeLayout(false);
            this.ScanOption.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage ScanTest;
        private System.Windows.Forms.TabPage BarCode;
        private System.Windows.Forms.ListView LVBarCode;
        private System.Windows.Forms.ColumnHeader BarType;
        private System.Windows.Forms.ColumnHeader BarData;
        private System.Windows.Forms.Button BTScanCancel;
        private System.Windows.Forms.Button BTScan;
        private System.Windows.Forms.Button BUTVersion;
        private System.Windows.Forms.Button AppClose;
        private System.Windows.Forms.TabPage ScanOption;
        private System.Windows.Forms.CheckBox CODE39checkBox;
        private System.Windows.Forms.CheckBox TRIOPTIC39checkBox;
        private System.Windows.Forms.CheckBox ISBT_128checkBox;
        private System.Windows.Forms.CheckBox UCC_EAN128checkBox;
        private System.Windows.Forms.CheckBox CODE128checkBox;
        private System.Windows.Forms.CheckBox COUPONcheckBox;
        private System.Windows.Forms.CheckBox BOOKLAND_EANcheckBox;
        private System.Windows.Forms.CheckBox EAN13checkBox;
        private System.Windows.Forms.CheckBox EAN8checkBox;
        private System.Windows.Forms.CheckBox UPCE1checkBox;
        private System.Windows.Forms.CheckBox UPCEcheckBox;
        private System.Windows.Forms.CheckBox UPCAcheckBox;
        private System.Windows.Forms.CheckBox MSI_PLESSEYcheckBox;
        private System.Windows.Forms.CheckBox CODABARcheckBox;
        private System.Windows.Forms.CheckBox DIS2OF5checkBox;
        private System.Windows.Forms.CheckBox I2OF5checkBox;
        private System.Windows.Forms.CheckBox CODE93checkBox;
        private System.Windows.Forms.Button BarCode_confirmbutton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Laser_On_Time;
        private System.Windows.Forms.NumericUpDown Security_Level_numericUpDown;
        private System.Windows.Forms.NumericUpDown Laser_On_TimenumericUpDown1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox Power_Mode_checkBox;
        private System.Windows.Forms.RadioButton ScanMode_radioButton2;
        private System.Windows.Forms.RadioButton ScanMode_radioButton1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button ScanOption_confirmbutton;
        private System.Windows.Forms.ComboBox Scan_Angle_comboBox;
        private System.Windows.Forms.CheckBox SoundcheckBox;
        private System.Windows.Forms.CheckBox CODE11checkBox;
        private System.Windows.Forms.CheckBox CH2OF5checkBox;
        private System.Windows.Forms.CheckBox GS1EXPANDEDcheckBox;
        private System.Windows.Forms.CheckBox GS1LIMITEDcheckBox;
        private System.Windows.Forms.CheckBox GS1checkBox;
    }
}

