<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Tab_Scanner = New System.Windows.Forms.TabControl
        Me.Tab_Main = New System.Windows.Forms.TabPage
        Me.Label1 = New System.Windows.Forms.Label
        Me.BTN_CLOSE = New System.Windows.Forms.Button
        Me.BTN_INFO = New System.Windows.Forms.Button
        Me.BTN_SCANCANCEL = New System.Windows.Forms.Button
        Me.BTN_SCAN = New System.Windows.Forms.Button
        Me.LV_SCANDATA = New System.Windows.Forms.ListView
        Me.BarType = New System.Windows.Forms.ColumnHeader
        Me.BarData = New System.Windows.Forms.ColumnHeader
        Me.Tab_Sym = New System.Windows.Forms.TabPage
        Me.BTN_SYM_CONFIRM = New System.Windows.Forms.Button
        Me.CB_GS1EXP = New System.Windows.Forms.CheckBox
        Me.CB_GS1LIM = New System.Windows.Forms.CheckBox
        Me.CB_GS1 = New System.Windows.Forms.CheckBox
        Me.CB_MSI = New System.Windows.Forms.CheckBox
        Me.CB_CODABAR = New System.Windows.Forms.CheckBox
        Me.CB_CH2OF5 = New System.Windows.Forms.CheckBox
        Me.CB_DIS2OF5 = New System.Windows.Forms.CheckBox
        Me.CB_I2OF5 = New System.Windows.Forms.CheckBox
        Me.CB_CODE11 = New System.Windows.Forms.CheckBox
        Me.CB_CODE39 = New System.Windows.Forms.CheckBox
        Me.CB_TRIOPTIC39 = New System.Windows.Forms.CheckBox
        Me.CB_CODE93 = New System.Windows.Forms.CheckBox
        Me.CB_ISBT128 = New System.Windows.Forms.CheckBox
        Me.CB_UCCEAN128 = New System.Windows.Forms.CheckBox
        Me.CB_CODE128 = New System.Windows.Forms.CheckBox
        Me.CB_COUPON = New System.Windows.Forms.CheckBox
        Me.CB_BOOKLAND = New System.Windows.Forms.CheckBox
        Me.CB_EAN13 = New System.Windows.Forms.CheckBox
        Me.CB_EAN8 = New System.Windows.Forms.CheckBox
        Me.CB_UPCE1 = New System.Windows.Forms.CheckBox
        Me.CB_UPCE = New System.Windows.Forms.CheckBox
        Me.CB_UPCA = New System.Windows.Forms.CheckBox
        Me.Tab_Option = New System.Windows.Forms.TabPage
        Me.BTN_OP_CONFIRM = New System.Windows.Forms.Button
        Me.CB_POWERMODE = New System.Windows.Forms.CheckBox
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.RD_SYNC = New System.Windows.Forms.RadioButton
        Me.RD_ASYNC = New System.Windows.Forms.RadioButton
        Me.Label4 = New System.Windows.Forms.Label
        Me.CB_SECURITYLEVEL = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.CB_TIMEOUT = New System.Windows.Forms.ComboBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Tab_Scanner.SuspendLayout()
        Me.Tab_Main.SuspendLayout()
        Me.Tab_Sym.SuspendLayout()
        Me.Tab_Option.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Tab_Scanner
        '
        Me.Tab_Scanner.Controls.Add(Me.Tab_Main)
        Me.Tab_Scanner.Controls.Add(Me.Tab_Sym)
        Me.Tab_Scanner.Controls.Add(Me.Tab_Option)
        Me.Tab_Scanner.Location = New System.Drawing.Point(0, 3)
        Me.Tab_Scanner.Name = "Tab_Scanner"
        Me.Tab_Scanner.SelectedIndex = 0
        Me.Tab_Scanner.Size = New System.Drawing.Size(242, 273)
        Me.Tab_Scanner.TabIndex = 2
        '
        'Tab_Main
        '
        Me.Tab_Main.BackColor = System.Drawing.SystemColors.Window
        Me.Tab_Main.Controls.Add(Me.Label1)
        Me.Tab_Main.Controls.Add(Me.BTN_CLOSE)
        Me.Tab_Main.Controls.Add(Me.BTN_INFO)
        Me.Tab_Main.Controls.Add(Me.BTN_SCANCANCEL)
        Me.Tab_Main.Controls.Add(Me.BTN_SCAN)
        Me.Tab_Main.Controls.Add(Me.LV_SCANDATA)
        Me.Tab_Main.Location = New System.Drawing.Point(4, 25)
        Me.Tab_Main.Name = "Tab_Main"
        Me.Tab_Main.Size = New System.Drawing.Size(234, 244)
        Me.Tab_Main.Text = "Main"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(103, 220)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(135, 20)
        Me.Label1.Text = "Ver 1.0.0 (20101124)"
        '
        'BTN_CLOSE
        '
        Me.BTN_CLOSE.Location = New System.Drawing.Point(122, 188)
        Me.BTN_CLOSE.Name = "BTN_CLOSE"
        Me.BTN_CLOSE.Size = New System.Drawing.Size(108, 31)
        Me.BTN_CLOSE.TabIndex = 4
        Me.BTN_CLOSE.Text = "CLOSE"
        '
        'BTN_INFO
        '
        Me.BTN_INFO.Location = New System.Drawing.Point(3, 188)
        Me.BTN_INFO.Name = "BTN_INFO"
        Me.BTN_INFO.Size = New System.Drawing.Size(108, 31)
        Me.BTN_INFO.TabIndex = 3
        Me.BTN_INFO.Text = "INFORMATION"
        '
        'BTN_SCANCANCEL
        '
        Me.BTN_SCANCANCEL.Location = New System.Drawing.Point(122, 151)
        Me.BTN_SCANCANCEL.Name = "BTN_SCANCANCEL"
        Me.BTN_SCANCANCEL.Size = New System.Drawing.Size(108, 31)
        Me.BTN_SCANCANCEL.TabIndex = 2
        Me.BTN_SCANCANCEL.Text = "SCAN CANCEL"
        '
        'BTN_SCAN
        '
        Me.BTN_SCAN.Location = New System.Drawing.Point(3, 151)
        Me.BTN_SCAN.Name = "BTN_SCAN"
        Me.BTN_SCAN.Size = New System.Drawing.Size(108, 31)
        Me.BTN_SCAN.TabIndex = 1
        Me.BTN_SCAN.Text = "SCAN"
        '
        'LV_SCANDATA
        '
        Me.LV_SCANDATA.Columns.Add(Me.BarType)
        Me.LV_SCANDATA.Columns.Add(Me.BarData)
        Me.LV_SCANDATA.Location = New System.Drawing.Point(3, 3)
        Me.LV_SCANDATA.Name = "LV_SCANDATA"
        Me.LV_SCANDATA.Size = New System.Drawing.Size(227, 142)
        Me.LV_SCANDATA.TabIndex = 0
        Me.LV_SCANDATA.View = System.Windows.Forms.View.Details
        '
        'BarType
        '
        Me.BarType.Text = "Type"
        Me.BarType.Width = 70
        '
        'BarData
        '
        Me.BarData.Text = "Data"
        Me.BarData.Width = 150
        '
        'Tab_Sym
        '
        Me.Tab_Sym.BackColor = System.Drawing.SystemColors.Window
        Me.Tab_Sym.Controls.Add(Me.BTN_SYM_CONFIRM)
        Me.Tab_Sym.Controls.Add(Me.CB_GS1EXP)
        Me.Tab_Sym.Controls.Add(Me.CB_GS1LIM)
        Me.Tab_Sym.Controls.Add(Me.CB_GS1)
        Me.Tab_Sym.Controls.Add(Me.CB_MSI)
        Me.Tab_Sym.Controls.Add(Me.CB_CODABAR)
        Me.Tab_Sym.Controls.Add(Me.CB_CH2OF5)
        Me.Tab_Sym.Controls.Add(Me.CB_DIS2OF5)
        Me.Tab_Sym.Controls.Add(Me.CB_I2OF5)
        Me.Tab_Sym.Controls.Add(Me.CB_CODE11)
        Me.Tab_Sym.Controls.Add(Me.CB_CODE39)
        Me.Tab_Sym.Controls.Add(Me.CB_TRIOPTIC39)
        Me.Tab_Sym.Controls.Add(Me.CB_CODE93)
        Me.Tab_Sym.Controls.Add(Me.CB_ISBT128)
        Me.Tab_Sym.Controls.Add(Me.CB_UCCEAN128)
        Me.Tab_Sym.Controls.Add(Me.CB_CODE128)
        Me.Tab_Sym.Controls.Add(Me.CB_COUPON)
        Me.Tab_Sym.Controls.Add(Me.CB_BOOKLAND)
        Me.Tab_Sym.Controls.Add(Me.CB_EAN13)
        Me.Tab_Sym.Controls.Add(Me.CB_EAN8)
        Me.Tab_Sym.Controls.Add(Me.CB_UPCE1)
        Me.Tab_Sym.Controls.Add(Me.CB_UPCE)
        Me.Tab_Sym.Controls.Add(Me.CB_UPCA)
        Me.Tab_Sym.Location = New System.Drawing.Point(4, 25)
        Me.Tab_Sym.Name = "Tab_Sym"
        Me.Tab_Sym.Size = New System.Drawing.Size(234, 244)
        Me.Tab_Sym.Text = "Symbology"
        '
        'BTN_SYM_CONFIRM
        '
        Me.BTN_SYM_CONFIRM.Location = New System.Drawing.Point(121, 205)
        Me.BTN_SYM_CONFIRM.Name = "BTN_SYM_CONFIRM"
        Me.BTN_SYM_CONFIRM.Size = New System.Drawing.Size(100, 32)
        Me.BTN_SYM_CONFIRM.TabIndex = 22
        Me.BTN_SYM_CONFIRM.Text = "CONFIRM"
        '
        'CB_GS1EXP
        '
        Me.CB_GS1EXP.Location = New System.Drawing.Point(121, 183)
        Me.CB_GS1EXP.Name = "CB_GS1EXP"
        Me.CB_GS1EXP.Size = New System.Drawing.Size(110, 20)
        Me.CB_GS1EXP.TabIndex = 21
        Me.CB_GS1EXP.Text = "GS1 EXPAND"
        '
        'CB_GS1LIM
        '
        Me.CB_GS1LIM.Location = New System.Drawing.Point(121, 165)
        Me.CB_GS1LIM.Name = "CB_GS1LIM"
        Me.CB_GS1LIM.Size = New System.Drawing.Size(110, 20)
        Me.CB_GS1LIM.TabIndex = 20
        Me.CB_GS1LIM.Text = "GS1 LIMITED"
        '
        'CB_GS1
        '
        Me.CB_GS1.Location = New System.Drawing.Point(121, 147)
        Me.CB_GS1.Name = "CB_GS1"
        Me.CB_GS1.Size = New System.Drawing.Size(100, 20)
        Me.CB_GS1.TabIndex = 19
        Me.CB_GS1.Text = "GS1"
        '
        'CB_MSI
        '
        Me.CB_MSI.Location = New System.Drawing.Point(121, 129)
        Me.CB_MSI.Name = "CB_MSI"
        Me.CB_MSI.Size = New System.Drawing.Size(100, 20)
        Me.CB_MSI.TabIndex = 18
        Me.CB_MSI.Text = "MSI"
        '
        'CB_CODABAR
        '
        Me.CB_CODABAR.Location = New System.Drawing.Point(121, 111)
        Me.CB_CODABAR.Name = "CB_CODABAR"
        Me.CB_CODABAR.Size = New System.Drawing.Size(100, 20)
        Me.CB_CODABAR.TabIndex = 17
        Me.CB_CODABAR.Text = "CODABAR"
        '
        'CB_CH2OF5
        '
        Me.CB_CH2OF5.Location = New System.Drawing.Point(121, 93)
        Me.CB_CH2OF5.Name = "CB_CH2OF5"
        Me.CB_CH2OF5.Size = New System.Drawing.Size(100, 20)
        Me.CB_CH2OF5.TabIndex = 16
        Me.CB_CH2OF5.Text = "CH2OF5"
        '
        'CB_DIS2OF5
        '
        Me.CB_DIS2OF5.Location = New System.Drawing.Point(121, 75)
        Me.CB_DIS2OF5.Name = "CB_DIS2OF5"
        Me.CB_DIS2OF5.Size = New System.Drawing.Size(100, 20)
        Me.CB_DIS2OF5.TabIndex = 15
        Me.CB_DIS2OF5.Text = "DIS2OF5"
        '
        'CB_I2OF5
        '
        Me.CB_I2OF5.Location = New System.Drawing.Point(121, 57)
        Me.CB_I2OF5.Name = "CB_I2OF5"
        Me.CB_I2OF5.Size = New System.Drawing.Size(100, 20)
        Me.CB_I2OF5.TabIndex = 14
        Me.CB_I2OF5.Text = "I2OF5"
        '
        'CB_CODE11
        '
        Me.CB_CODE11.Location = New System.Drawing.Point(121, 39)
        Me.CB_CODE11.Name = "CB_CODE11"
        Me.CB_CODE11.Size = New System.Drawing.Size(100, 20)
        Me.CB_CODE11.TabIndex = 13
        Me.CB_CODE11.Text = "CODE11"
        '
        'CB_CODE39
        '
        Me.CB_CODE39.Location = New System.Drawing.Point(121, 21)
        Me.CB_CODE39.Name = "CB_CODE39"
        Me.CB_CODE39.Size = New System.Drawing.Size(100, 20)
        Me.CB_CODE39.TabIndex = 12
        Me.CB_CODE39.Text = "CODE39"
        '
        'CB_TRIOPTIC39
        '
        Me.CB_TRIOPTIC39.Location = New System.Drawing.Point(121, 3)
        Me.CB_TRIOPTIC39.Name = "CB_TRIOPTIC39"
        Me.CB_TRIOPTIC39.Size = New System.Drawing.Size(110, 20)
        Me.CB_TRIOPTIC39.TabIndex = 11
        Me.CB_TRIOPTIC39.Text = "TRIOPTIC39"
        '
        'CB_CODE93
        '
        Me.CB_CODE93.Location = New System.Drawing.Point(3, 183)
        Me.CB_CODE93.Name = "CB_CODE93"
        Me.CB_CODE93.Size = New System.Drawing.Size(100, 20)
        Me.CB_CODE93.TabIndex = 10
        Me.CB_CODE93.Text = "CODE93"
        '
        'CB_ISBT128
        '
        Me.CB_ISBT128.Location = New System.Drawing.Point(3, 165)
        Me.CB_ISBT128.Name = "CB_ISBT128"
        Me.CB_ISBT128.Size = New System.Drawing.Size(100, 20)
        Me.CB_ISBT128.TabIndex = 9
        Me.CB_ISBT128.Text = "ISBT128"
        '
        'CB_UCCEAN128
        '
        Me.CB_UCCEAN128.Location = New System.Drawing.Point(3, 147)
        Me.CB_UCCEAN128.Name = "CB_UCCEAN128"
        Me.CB_UCCEAN128.Size = New System.Drawing.Size(112, 20)
        Me.CB_UCCEAN128.TabIndex = 8
        Me.CB_UCCEAN128.Text = "UCC/EAN-128"
        '
        'CB_CODE128
        '
        Me.CB_CODE128.Location = New System.Drawing.Point(3, 129)
        Me.CB_CODE128.Name = "CB_CODE128"
        Me.CB_CODE128.Size = New System.Drawing.Size(100, 20)
        Me.CB_CODE128.TabIndex = 7
        Me.CB_CODE128.Text = "CODE128"
        '
        'CB_COUPON
        '
        Me.CB_COUPON.Location = New System.Drawing.Point(3, 111)
        Me.CB_COUPON.Name = "CB_COUPON"
        Me.CB_COUPON.Size = New System.Drawing.Size(100, 20)
        Me.CB_COUPON.TabIndex = 6
        Me.CB_COUPON.Text = "COUPON"
        '
        'CB_BOOKLAND
        '
        Me.CB_BOOKLAND.Location = New System.Drawing.Point(3, 93)
        Me.CB_BOOKLAND.Name = "CB_BOOKLAND"
        Me.CB_BOOKLAND.Size = New System.Drawing.Size(100, 20)
        Me.CB_BOOKLAND.TabIndex = 5
        Me.CB_BOOKLAND.Text = "BOOKLAND"
        '
        'CB_EAN13
        '
        Me.CB_EAN13.Location = New System.Drawing.Point(3, 75)
        Me.CB_EAN13.Name = "CB_EAN13"
        Me.CB_EAN13.Size = New System.Drawing.Size(100, 20)
        Me.CB_EAN13.TabIndex = 4
        Me.CB_EAN13.Text = "EAN-13"
        '
        'CB_EAN8
        '
        Me.CB_EAN8.Location = New System.Drawing.Point(3, 57)
        Me.CB_EAN8.Name = "CB_EAN8"
        Me.CB_EAN8.Size = New System.Drawing.Size(100, 20)
        Me.CB_EAN8.TabIndex = 3
        Me.CB_EAN8.Text = "EAN-8"
        '
        'CB_UPCE1
        '
        Me.CB_UPCE1.Location = New System.Drawing.Point(3, 39)
        Me.CB_UPCE1.Name = "CB_UPCE1"
        Me.CB_UPCE1.Size = New System.Drawing.Size(100, 20)
        Me.CB_UPCE1.TabIndex = 2
        Me.CB_UPCE1.Text = "UPC-E1"
        '
        'CB_UPCE
        '
        Me.CB_UPCE.Location = New System.Drawing.Point(3, 21)
        Me.CB_UPCE.Name = "CB_UPCE"
        Me.CB_UPCE.Size = New System.Drawing.Size(100, 20)
        Me.CB_UPCE.TabIndex = 1
        Me.CB_UPCE.Text = "UPC-E"
        '
        'CB_UPCA
        '
        Me.CB_UPCA.Location = New System.Drawing.Point(3, 3)
        Me.CB_UPCA.Name = "CB_UPCA"
        Me.CB_UPCA.Size = New System.Drawing.Size(100, 20)
        Me.CB_UPCA.TabIndex = 0
        Me.CB_UPCA.Text = "UPC-A"
        '
        'Tab_Option
        '
        Me.Tab_Option.BackColor = System.Drawing.SystemColors.Window
        Me.Tab_Option.Controls.Add(Me.BTN_OP_CONFIRM)
        Me.Tab_Option.Controls.Add(Me.CB_POWERMODE)
        Me.Tab_Option.Controls.Add(Me.Panel1)
        Me.Tab_Option.Controls.Add(Me.CB_SECURITYLEVEL)
        Me.Tab_Option.Controls.Add(Me.Label3)
        Me.Tab_Option.Controls.Add(Me.CB_TIMEOUT)
        Me.Tab_Option.Controls.Add(Me.Label2)
        Me.Tab_Option.Location = New System.Drawing.Point(4, 25)
        Me.Tab_Option.Name = "Tab_Option"
        Me.Tab_Option.Size = New System.Drawing.Size(234, 244)
        Me.Tab_Option.Text = "Option"
        '
        'BTN_OP_CONFIRM
        '
        Me.BTN_OP_CONFIRM.Location = New System.Drawing.Point(126, 183)
        Me.BTN_OP_CONFIRM.Name = "BTN_OP_CONFIRM"
        Me.BTN_OP_CONFIRM.Size = New System.Drawing.Size(101, 40)
        Me.BTN_OP_CONFIRM.TabIndex = 6
        Me.BTN_OP_CONFIRM.Text = "CONFIRM"
        '
        'CB_POWERMODE
        '
        Me.CB_POWERMODE.Location = New System.Drawing.Point(120, 142)
        Me.CB_POWERMODE.Name = "CB_POWERMODE"
        Me.CB_POWERMODE.Size = New System.Drawing.Size(117, 20)
        Me.CB_POWERMODE.TabIndex = 5
        Me.CB_POWERMODE.Text = "POWER MODE"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.RD_SYNC)
        Me.Panel1.Controls.Add(Me.RD_ASYNC)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Location = New System.Drawing.Point(7, 8)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(220, 50)
        '
        'RD_SYNC
        '
        Me.RD_SYNC.Location = New System.Drawing.Point(113, 26)
        Me.RD_SYNC.Name = "RD_SYNC"
        Me.RD_SYNC.Size = New System.Drawing.Size(100, 20)
        Me.RD_SYNC.TabIndex = 2
        Me.RD_SYNC.Text = "Sync Mode"
        '
        'RD_ASYNC
        '
        Me.RD_ASYNC.Location = New System.Drawing.Point(7, 27)
        Me.RD_ASYNC.Name = "RD_ASYNC"
        Me.RD_ASYNC.Size = New System.Drawing.Size(100, 20)
        Me.RD_ASYNC.TabIndex = 1
        Me.RD_ASYNC.Text = "ASync Mode"
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label4.Location = New System.Drawing.Point(70, 3)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(81, 20)
        Me.Label4.Text = "Sync Mode"
        '
        'CB_SECURITYLEVEL
        '
        Me.CB_SECURITYLEVEL.Items.Add("1")
        Me.CB_SECURITYLEVEL.Items.Add("2")
        Me.CB_SECURITYLEVEL.Items.Add("3")
        Me.CB_SECURITYLEVEL.Items.Add("4")
        Me.CB_SECURITYLEVEL.Location = New System.Drawing.Point(127, 100)
        Me.CB_SECURITYLEVEL.Name = "CB_SECURITYLEVEL"
        Me.CB_SECURITYLEVEL.Size = New System.Drawing.Size(100, 23)
        Me.CB_SECURITYLEVEL.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label3.Location = New System.Drawing.Point(7, 100)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(107, 20)
        Me.Label3.Text = "Security Level"
        '
        'CB_TIMEOUT
        '
        Me.CB_TIMEOUT.Items.Add("1")
        Me.CB_TIMEOUT.Items.Add("2")
        Me.CB_TIMEOUT.Items.Add("3")
        Me.CB_TIMEOUT.Items.Add("4")
        Me.CB_TIMEOUT.Items.Add("5")
        Me.CB_TIMEOUT.Items.Add("6")
        Me.CB_TIMEOUT.Items.Add("7")
        Me.CB_TIMEOUT.Items.Add("8")
        Me.CB_TIMEOUT.Items.Add("9")
        Me.CB_TIMEOUT.Items.Add("10")
        Me.CB_TIMEOUT.Location = New System.Drawing.Point(127, 72)
        Me.CB_TIMEOUT.Name = "CB_TIMEOUT"
        Me.CB_TIMEOUT.Size = New System.Drawing.Size(100, 23)
        Me.CB_TIMEOUT.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label2.Location = New System.Drawing.Point(7, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 20)
        Me.Label2.Text = "Time Out"
        '
        'Form1
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(242, 279)
        Me.Controls.Add(Me.Tab_Scanner)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Text = "M3PlusScanTest_VB"
        Me.Tab_Scanner.ResumeLayout(False)
        Me.Tab_Main.ResumeLayout(False)
        Me.Tab_Sym.ResumeLayout(False)
        Me.Tab_Option.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Tab_Scanner As System.Windows.Forms.TabControl
    Friend WithEvents Tab_Main As System.Windows.Forms.TabPage
    Friend WithEvents Tab_Sym As System.Windows.Forms.TabPage
    Friend WithEvents BTN_CLOSE As System.Windows.Forms.Button
    Friend WithEvents BTN_INFO As System.Windows.Forms.Button
    Friend WithEvents BTN_SCANCANCEL As System.Windows.Forms.Button
    Friend WithEvents BTN_SCAN As System.Windows.Forms.Button
    Friend WithEvents LV_SCANDATA As System.Windows.Forms.ListView
    Friend WithEvents BarType As System.Windows.Forms.ColumnHeader
    Friend WithEvents BarData As System.Windows.Forms.ColumnHeader
    Friend WithEvents Tab_Option As System.Windows.Forms.TabPage
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CB_CODE93 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_ISBT128 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_UCCEAN128 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_CODE128 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_COUPON As System.Windows.Forms.CheckBox
    Friend WithEvents CB_BOOKLAND As System.Windows.Forms.CheckBox
    Friend WithEvents CB_EAN13 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_EAN8 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_UPCE1 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_UPCE As System.Windows.Forms.CheckBox
    Friend WithEvents CB_UPCA As System.Windows.Forms.CheckBox
    Friend WithEvents CB_GS1EXP As System.Windows.Forms.CheckBox
    Friend WithEvents CB_GS1LIM As System.Windows.Forms.CheckBox
    Friend WithEvents CB_GS1 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_MSI As System.Windows.Forms.CheckBox
    Friend WithEvents CB_CODABAR As System.Windows.Forms.CheckBox
    Friend WithEvents CB_CH2OF5 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_DIS2OF5 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_I2OF5 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_CODE11 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_CODE39 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_TRIOPTIC39 As System.Windows.Forms.CheckBox
    Friend WithEvents BTN_SYM_CONFIRM As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents RD_SYNC As System.Windows.Forms.RadioButton
    Friend WithEvents RD_ASYNC As System.Windows.Forms.RadioButton
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents CB_SECURITYLEVEL As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents CB_TIMEOUT As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents CB_POWERMODE As System.Windows.Forms.CheckBox
    Friend WithEvents BTN_OP_CONFIRM As System.Windows.Forms.Button

End Class
