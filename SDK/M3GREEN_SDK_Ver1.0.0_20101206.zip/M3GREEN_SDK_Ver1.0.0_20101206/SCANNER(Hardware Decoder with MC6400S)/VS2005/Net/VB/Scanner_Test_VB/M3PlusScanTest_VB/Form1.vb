Imports System
Imports Microsoft.Win32
Imports System.Threading
Imports System.Runtime.InteropServices
Imports M3PSSLibNetCla

Public Class Form1
    Private ScanCtrl As New M3PSSLibNetCla.ScannerControl
    Private McpOption As New M3PSSLibNetCla.MCPScanOption
    Private McpBarType As New M3PSSLibNetCla.MCPBarCodeType

    Public m_bKeyFlag As Boolean = False

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        AddHandler ScanCtrl.ScannerDataEvent, AddressOf Me.OnScanData

        If ScanCtrl.ScanOpen() = False Then
            MessageBox.Show("Error : ScanOpen Failed")
        End If

        ScanCtrl.GetScan_Option(McpOption)
    End Sub

    Private Sub OnScanData(ByVal sender As System.Object, ByVal e As M3PSSLibNetCla.ScannerDataArgs)
        If (LV_SCANDATA.Items.Count > 5) Then
            LV_SCANDATA.Items.Clear()
        End If

        Dim ScanData As New ListViewItem()

        If e.ScanData <> "" Then
            ScanData.Text = e.ScanType
            ScanData.SubItems.Add(e.ScanData)

            LV_SCANDATA.Items.Add(ScanData)
            Call Beep()
        End If

    End Sub

    Private Sub Tab_Scanner_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Tab_Scanner.KeyDown
        If (e.KeyCode = System.Windows.Forms.Keys.F22) Then
            If m_bKeyFlag = False Then
                m_bKeyFlag = True
                ScanCtrl.ScanRead()
            End If
        End If
    End Sub

    Private Sub Tab_Scanner_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Tab_Scanner.KeyUp
        If (e.KeyCode = System.Windows.Forms.Keys.F22) Then
            If m_bKeyFlag = True Then
                m_bKeyFlag = False
                If McpOption.nmcp_sync = 1 Then
                    ScanCtrl.ScanReadCancel()
                End If
            End If
        End If
    End Sub

    Private Sub Form1_Closing(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Dim i As Integer
        Dim bResult As Boolean

        For i = 0 To 3
            bResult = ScanCtrl.ScanClose()
            Thread.Sleep(300)
            If bResult = True Then
                Exit For
            End If

            i = i + 1
        Next

        Application.Exit()
    End Sub

    Private Sub BTN_SCAN_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_SCAN.Click
        ScanCtrl.ScanRead()

        Tab_Scanner.Focus()
    End Sub

    Private Sub BTN_SCANCANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_SCANCANCEL.Click
        ScanCtrl.ScanReadCancel()

        Tab_Scanner.Focus()
    End Sub

    Private Sub BTN_INFO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_INFO.Click
        Dim strInfo As String = ScanCtrl.ScanGetRevision()
        MessageBox.Show(strInfo)

        Tab_Scanner.Focus()
    End Sub

    Private Sub BTN_CLOSE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CLOSE.Click
        Dim i As Integer
        Dim bResult As Boolean

        For i = 0 To 3
            bResult = ScanCtrl.ScanClose()
            Thread.Sleep(300)
            If bResult = True Then
                Exit For
            End If

            i = i + 1
        Next

        Application.Exit()
    End Sub


    Private Sub Tab_Scanner_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tab_Scanner.SelectedIndexChanged

        Select Case Tab_Scanner.SelectedIndex
            Case 0  'Main Page
                Tab_Scanner.Focus()
            Case 1  'Symbology Page
                ScanCtrl.ScanReadCancel()
                ScanCtrl.GetBarCode_Type(McpBarType)

                CB_UPCA.Checked = McpBarType.upca
                CB_UPCE.Checked = McpBarType.upce
                CB_UPCE1.Checked = McpBarType.upce1
                CB_EAN8.Checked = McpBarType.ean8
                CB_EAN13.Checked = McpBarType.ean13
                CB_BOOKLAND.Checked = McpBarType.bookland_ean
                CB_COUPON.Checked = McpBarType.coupon
                CB_CODE128.Checked = McpBarType.code128
                CB_UCCEAN128.Checked = McpBarType.ucc_ean128
                CB_ISBT128.Checked = McpBarType.isbt_128
                CB_CODE93.Checked = McpBarType.code93
                CB_TRIOPTIC39.Checked = McpBarType.trioptic39
                CB_CODE39.Checked = McpBarType.code39
                CB_CODE11.Checked = McpBarType.code11
                CB_I2OF5.Checked = McpBarType.i2of5
                CB_DIS2OF5.Checked = McpBarType.dis2of5
                CB_CH2OF5.Checked = McpBarType.ch2of5
                CB_CODABAR.Checked = McpBarType.codabar
                CB_MSI.Checked = McpBarType.msi_plessey
                CB_GS1.Checked = McpBarType.gs1
                CB_GS1LIM.Checked = McpBarType.gs1_limited
                CB_GS1EXP.Checked = McpBarType.gs1_expanded

            Case 2  'Option Page
                ScanCtrl.ScanReadCancel()
                ScanCtrl.GetScan_Option(McpOption)

                If McpOption.nmcp_sync = 0 Then
                    RD_SYNC.Checked = True
                Else
                    RD_ASYNC.Checked = True
                End If

                Select Case McpOption.nmcp_laser_on_time
                    Case 1
                        CB_TIMEOUT.Text = "1"
                    Case 2
                        CB_TIMEOUT.Text = "2"
                    Case 3
                        CB_TIMEOUT.Text = "3"
                    Case 4
                        CB_TIMEOUT.Text = "4"
                    Case 5
                        CB_TIMEOUT.Text = "5"
                    Case 6
                        CB_TIMEOUT.Text = "6"
                    Case 7
                        CB_TIMEOUT.Text = "7"
                    Case 8
                        CB_TIMEOUT.Text = "8"
                    Case 9
                        CB_TIMEOUT.Text = "9"
                    Case 10
                        CB_TIMEOUT.Text = "10"
                End Select

                Select Case McpOption.nmcp_security_levels
                    Case 1
                        CB_SECURITYLEVEL.Text = "1"
                    Case 2
                        CB_SECURITYLEVEL.Text = "2"
                    Case 3
                        CB_SECURITYLEVEL.Text = "3"
                    Case 4
                        CB_SECURITYLEVEL.Text = "4"
                End Select

                If McpOption.nmcp_power_mode = 0 Then
                    CB_POWERMODE.Checked = False
                Else
                    CB_POWERMODE.Checked = True
                End If

        End Select

    End Sub

    Private Sub BTN_SYM_CONFIRM_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_SYM_CONFIRM.Click
        McpBarType.upca = CB_UPCA.Checked
        McpBarType.upce = CB_UPCE.Checked
        McpBarType.upce1 = CB_UPCE1.Checked
        McpBarType.ean8 = CB_EAN8.Checked
        McpBarType.ean13 = CB_EAN13.Checked
        McpBarType.bookland_ean = CB_BOOKLAND.Checked
        McpBarType.coupon = CB_COUPON.Checked
        McpBarType.code128 = CB_CODE128.Checked
        McpBarType.ucc_ean128 = CB_UCCEAN128.Checked
        McpBarType.isbt_128 = CB_ISBT128.Checked
        McpBarType.code93 = CB_CODE93.Checked
        McpBarType.trioptic39 = CB_TRIOPTIC39.Checked
        McpBarType.code39 = CB_CODE39.Checked
        McpBarType.code11 = CB_CODE11.Checked
        McpBarType.i2of5 = CB_I2OF5.Checked
        McpBarType.dis2of5 = CB_DIS2OF5.Checked
        McpBarType.ch2of5 = CB_CH2OF5.Checked
        McpBarType.codabar = CB_CODABAR.Checked
        McpBarType.msi_plessey = CB_MSI.Checked
        McpBarType.gs1 = CB_GS1.Checked
        McpBarType.gs1_limited = CB_GS1LIM.Checked
        McpBarType.gs1_expanded = CB_GS1EXP.Checked

        ScanCtrl.SetBarCode_Type(McpBarType)
        Tab_Scanner.SelectedIndex = 0
        Tab_Scanner.Focus()

    End Sub

    Private Sub BTN_OP_CONFIRM_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OP_CONFIRM.Click

        If RD_SYNC.Checked = True Then
            McpOption.nmcp_sync = 0
        Else
            McpOption.nmcp_sync = 1
        End If

        McpOption.nmcp_laser_on_time = CB_TIMEOUT.SelectedIndex + 1
        McpOption.nmcp_security_levels = CB_SECURITYLEVEL.SelectedIndex + 1

        If CB_POWERMODE.Checked = True Then
            McpOption.nmcp_power_mode = 0
        Else
            McpOption.nmcp_power_mode = 1
        End If

        ScanCtrl.SetScan_Option(McpOption)
        Tab_Scanner.SelectedIndex = 0
        Tab_Scanner.Focus()
    End Sub
End Class
