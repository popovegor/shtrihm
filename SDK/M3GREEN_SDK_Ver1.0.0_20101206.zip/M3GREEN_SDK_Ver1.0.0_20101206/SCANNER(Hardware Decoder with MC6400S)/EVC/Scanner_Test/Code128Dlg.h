#if !defined(AFX_CODE128DLG_H__1DF5ACB8_B65A_4684_A2D5_20C1063D66E0__INCLUDED_)
#define AFX_CODE128DLG_H__1DF5ACB8_B65A_4684_A2D5_20C1063D66E0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Code128Dlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCode128Dlg dialog

class CCode128Dlg : public CDialog
{
// Construction
public:
	void SetOption();
	void GetOption();
	CCode128Dlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCode128Dlg)
	enum { IDD = IDD_CODE128_DLG };
	BOOL	m_bEnableCode128;
	BOOL	m_bEnableIsbt128;
	BOOL	m_bEnableUccean128;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCode128Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCode128Dlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CODE128DLG_H__1DF5ACB8_B65A_4684_A2D5_20C1063D66E0__INCLUDED_)
