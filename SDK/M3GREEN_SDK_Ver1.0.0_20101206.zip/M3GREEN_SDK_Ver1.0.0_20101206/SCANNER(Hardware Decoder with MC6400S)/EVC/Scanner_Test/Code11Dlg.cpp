// Code11Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3PlusScanTest.h"
#include "Code11Dlg.h"
#include "M3PlusScanTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCode11Dlg dialog


CCode11Dlg::CCode11Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCode11Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCode11Dlg)
	m_bEnableCode11 = FALSE;
	m_bCode11Xcd = FALSE;
	m_nCode11Cdv = -1;
	//}}AFX_DATA_INIT
}


void CCode11Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCode11Dlg)
	DDX_Check(pDX, IDC_CHECK_CODE11, m_bEnableCode11);
	DDX_Check(pDX, IDC_CHECK_CODE11_XCD, m_bCode11Xcd);
	DDX_Radio(pDX, IDC_RADIO_DISCDV, m_nCode11Cdv);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCode11Dlg, CDialog)
	//{{AFX_MSG_MAP(CCode11Dlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCode11Dlg message handlers

BOOL CCode11Dlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);

	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCode11Dlg::GetOption()
{
	CM3PlusScanTestDlg* dlg = (CM3PlusScanTestDlg*)AfxGetMainWnd();

	// Enable
	int nCheck = 0;
	nCheck = dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"VER");
	if( nCheck == -1 || nCheck != M3PLUSSCANVER)
	{
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE11",(DWORD)dlg->KScan.GetBarCodeType(CODE11));
	}

	m_bEnableCode11	= (BOOL)dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE11");

	// CheckDigit
	m_bCode11Xcd	= (BOOL)dlg->KScan.GetTransmitCheckDigit(TRANCODE11CD);
	m_nCode11Cdv	= (DWORD)dlg->KScan.GetCode11CheckDigitVerification();

	UpdateData(FALSE);
}

void CCode11Dlg::SetOption()
{
	UpdateData(TRUE);
	CM3PlusScanTestDlg* dlg = (CM3PlusScanTestDlg*)AfxGetMainWnd();

	// Enable
	if((DWORD)m_bEnableCode11 != dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE11"))
	{
		dlg->KScan.SetBarCodeType(CODE11	, m_bEnableCode11);	
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE11", m_bEnableCode11);
	}

	// CheckDigit
	dlg->KScan.SetTransmitCheckDigit(TRANCODE11CD, (unsigned char)m_bCode11Xcd);
	dlg->KScan.SetCode11CheckDigitVerification((unsigned char)m_nCode11Cdv);
}

void CCode11Dlg::OnOK() 
{
	SetOption();
	
	CDialog::OnOK();
}
