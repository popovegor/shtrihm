// MCPScan.h: interface for the CMCPScan class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MCPSCAN_H__4D0298C8_E9B3_4DFE_8211_41048056B8DF__INCLUDED_)
#define AFX_MCPSCAN_H__4D0298C8_E9B3_4DFE_8211_41048056B8DF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

typedef struct _BARCODETYPE
{
	BOOL Upca;	
	BOOL Upce;	
	BOOL Upce1;	
	BOOL Ean8;	
	BOOL Ean13;	
	BOOL Bookland_ean;
	BOOL Coupon;	
	BOOL Code128;	
	BOOL Ucc_ean128;
	BOOL Isbt_128;
	BOOL Code39;	
	BOOL Trioptic39 ;
	BOOL Code93;	
	BOOL Code11;
	BOOL I2of5;	
	BOOL Dis2of5;	
	BOOL Ch2of5;
	BOOL Codabar;	
	BOOL Msi;
	BOOL Gs1;
	BOOL Gs1_Limited;
	BOOL Gs1_Expanded;
}MCPBarCodeType, *PMCBarCodeType;

typedef struct _MCPScanOption
{
	DWORD nHotKey1;
	DWORD nHotKey2;
	DWORD nHotKey3;
	DWORD nReturn;
	DWORD nSync;
	DWORD nSound;
	DWORD nOutput;
	DWORD nSecurity;
	DWORD nAngle;
	DWORD nTimeOut;
	DWORD nPowerMode;
	DWORD nTransmitCodeID;
	TCHAR szPrefix[50];
	TCHAR szSuffix[50];
	TCHAR szSoundPath[MAX_PATH];
	
}MCPScanOption,* PMCPScanOption;


#define M3PLUSSCANVER		1
#define M3PLUSEMULVER		2
#define M3PLUSLIBVER		3
#define M3PSCANDLLVER		L"Version: 2.1.0 "
#define M3PSCANBUILD		L"Build(091231)"
#define REG_ADDRESS			L"Software\\M3Mobile\\M3PScanner"
#define ANY					0x00
#define ONE_DISCRETE		0x01
#define TWO_DISCRETE		0x02
#define WITHIN_RANGE		0x03

#define NO_PREAMBLE		0x00
#define SYSTEM_CHAR		0x01
#define SYSTEM_CHAR_COUNTRY_CODE 0x02


#define ENABLE			0x01
#define DISABLE			0x00
#define USS_CHECK		0x01
#define OPCC_CHECK		0x02

#define ONE_CHECK		0x00
#define TWO_CHECK		0x01

#define MOD10_11		0x00
#define MOD10_10		0x01


#define PARAM_ERROR		0xFFFF


#define TRANS_CHECK_DIGIT 		0x01
#define NOT_TRANS_CHECK_DIGIT 	0x00


#define DECODE_SUP				0x01
#define IGNORE_SUP				0x00
#define AUTODISCRIMINATE_SUP	0x02


#define LEVEL0	0x00
#define LEVEL1	0x01
#define LEVEL2	0x02
#define LEVEL3	0x03

#define ONE_SECOND		0x0A
#define TWO_SECOND		0x14
#define THREE_SECOND	0x1E
#define FOUR_SECOND		0x28
#define FIVE_SECOND		0x32
#define SIX_SECOND		0x3C
#define SEVEN_SECOND	0x46
#define EIGHT_SECOND	0x50
#define NINE_SECOND		0x5A
#define TEN_SECOND  	0x63

#define ONE_LEVEL		0x01
#define	TWO_LEVEL		0x02
#define	THREE_LEVEL		0x03
#define	FOUR_LEVEL		0x04

#define	CONTINUOUS		0x00
#define	LOW				0x01


#define LASER_ON_TIME_01			0x00000001L
#define LASER_ON_TIME_02			0x00000002L
#define LASER_ON_TIME_03			0x00000004L
#define LASER_ON_TIME_04			0x00000008L
#define LASER_ON_TIME_05			0x00000010L
#define LASER_ON_TIME_06			0x00000020L
#define LASER_ON_TIME_07			0x00000040L
#define LASER_ON_TIME_08			0x00000080L
#define LASER_ON_TIME_09			0x00000100L
#define LASER_ON_TIME_10			0x00000200L
#define SCAN_ANGLE_NARROW			0x00000400L
#define SCAN_ANGLE_MEDIUM			0x00000800L
#define	SCAN_ANGLE_WIDE				0x00001000L
#define TIME_OUT_BETWEEN_SAMES_SYMBOL_01	0x00002000L
#define TIME_OUT_BETWEEN_SAMES_SYMBOL_02	0x00004000L
#define TIME_OUT_BETWEEN_SAMES_SYMBOL_03	0x00008000L
#define TIME_OUT_BETWEEN_SAMES_SYMBOL_04	0x00010000L
#define TIME_OUT_BETWEEN_SAMES_SYMBOL_05	0x00020000L
#define TIME_OUT_BETWEEN_SAMES_SYMBOL_06	0x00040000L
#define TIME_OUT_BETWEEN_SAMES_SYMBOL_07	0x00080000L
#define TIME_OUT_BETWEEN_SAMES_SYMBOL_08	0x00100000L
#define TIME_OUT_BETWEEN_SAMES_SYMBOL_09	0x00200000L
#define TIME_OUT_BETWEEN_SAMES_SYMBOL_10	0x00400000L
#define	LINEAR_CODE_TYPE_SECURITY_LEVELS_01	0x00800000L
#define	LINEAR_CODE_TYPE_SECURITY_LEVELS_02	0x01000000L
#define	LINEAR_CODE_TYPE_SECURITY_LEVELS_03	0x02000000L
#define	LINEAR_CODE_TYPE_SECURITY_LEVELS_04	0x04000000L
#define POWER_MODE_CONTINUOUS				0x08000000L
#define	POWER_MODE_LOW						0x10000000L
						

#define DATA_AS_IS					0x00
#define DATA_SUFFIX1				0x01
#define DATA_SUFFIX2				0x02
#define DATA_SUFFIX1_SUFFIX2		0x03
#define PREFIX_DATA					0x04
#define PREFIX_DATA_SUFFIX1			0x05
#define PREFIX_DATA_SUFFIX2			0x06
#define PREFIX_DATA_SUFFIX1_SUFFIX2	0x07


#define NORMALCLI			0x64
#define MINIMUMCLI			0x4B
#define MEDIUMCLI			0x3C
#define MAXIMUMCLI			0x2D

#define NARROW				0xB5			//(35)
#define	MEDIUM				0xB6			//(46)
#define WIDE				0xB7			//(53)

#define	CODE39CDV			0x30
#define	CODE39FA			0x11
#define	CODABARCLSI			0x36
#define	CODABARNOTIS				0x37
#define	SCANDATATRANSMISSIONFORMAT	0xEB
#define	DECODEUPCEANSUPPLEMENTALS	0x10
#define	EANZEROEXTEND			0x27
#define	I2OF5CDV				0x31
#define	MSIPLESSEYCD			0x32
#define	MSIPLESSEYCDA			0x33
#define	SCANANGLE				0xBF
#define	NRMESSAGE				0x5E
#define	UPCEANSL				0x4D
#define	CODE32PREFIXENABLE		0xE7
#define CODE11CDV				0x34

#define	PREFIXVALUES			0x69
#define	SUFFIX1VALUES			0x68
#define	SUFFIX2VALUES			0x6A

#define TRANUPCACD			0x28
#define	TRANUPCECD			0x29
#define	TRANUPCE1CD			0x2A
#define	TRANCODE39CD		0x2B
#define TRANCODE11CD		0x2F
#define	TRANI2OF5CD			0x2C
#define	TRANMSIPLESSEYCD	0x2E

// Transmit CodeID
#define TRANCODEID			0x2D

#define	UPCAPRE				0x22
#define	UPCEPRE				0x23
#define	UPCE1PRE			0x24
// Serial Interface
#define	SIBAUDRATE			0x9C
#define	SIPARITY			0x9E
#define	SISOFTHANDSHAKING	0x9F
#define	SIDDPF				0xEE
#define	SIHSRTIMEOUT		0x9B	// Host Serial Response Time-out
#define	SISTOPBITSELECT		0x9D	// Stop Bit Select
#define	SIIDELAY			0x6E	// Intercharacter Delay
#define	SIHCTIMEOUT			0xEF	// Host Character Time-out

// Host, Decoder
#define SOURCE_HOST			0x04
#define	SOURCE_DECODER		0x00

// STATUS
// Bit 0	1D, 2D
#define	STATUS_INIT			0x00
#define	STATUS_RETRANSMIT	0x01
// Bit 1	2D
#define	STATUS_LAST			0x00		// Multipacket Transmission
#define	STATUS_NEXT			0x02
// Bit 3	1D, 2D
#define	STATUS_PERMANENT		0x04
#define	STATUS_TEMPORARY		0x00

// OPCODE
#define	OPCODE_AIM_OFF			0xC4
#define	OPCODE_AIM_ON			0xC5
#define	OPCODE_BEEP				0xE6
#define	OPCODE_CMD_ACK			0xD0
#define	OPCODE_CMD_NAK			0xD1
#define	OPCODE_DECODE_DATA		0xF3
#define	OPCODE_EVENT			0xF6
#define	OPCODE_LED_OFF			0xE8
#define	OPCODE_LED_ON			0xE7
#define	OPCODE_PARAM_DEFAULTS	0xC8
#define	OPCODE_PARAM_REQUEST	0xC7
#define	OPCODE_PARAM_SEND		0xC6
#define	OPCODE_REPLY_REVISION	0xA4
#define	OPCODE_REQUEST_REVISION	0xA3
#define	OPCODE_SCAN_DISABLE		0xEA
#define	OPCODE_SCAN_ENABLE		0xE9
#define	OPCODE_SLEEP			0xEB
#define	OPCODE_START_DECODE		0xE4
#define	OPCODE_STOP_DECODE		0xE5

#define	str_Enable			("Enable")
#define	str_Disable			("Disable")

// UPC/EAN
#define	str_UPCA			("UPC-A")
#define	str_UPCE			("UPC-E")
#define	str_UPCE1			("UPC-E1")
#define	str_EAN8			("EAN-8")
#define	str_EAN13			("EAN-13")
#define	str_BOOKLANDEAN		("Bookland EAN")
#define	str_COUPONCODE		("Coupon Code")

//#define	str_UPCEANCoupon	("UPC/EAN Coupon") //����??
//#define	str_UPC_E0					("UPC E0");

#define	str_UPC_A_with_2_Supps		("UPC-A with 2 Supps")
#define	str_UPC_A_with_5_Supps		("UPC-A with 5 Supps")
#define	str_UPC_E_with_2_Supps		("UPC-E with 2 Supps")
#define	str_UPC_E_with_5_Supps		("UPC-E with 5 Supps")
#define	str_UPC_E1_with_2_Supps		("UPC-E1 with 2 Supps")
#define	str_UPC_E1_with_5_Supps		("UPC-E1 with 5 Supps")
#define	str_EAN_8_with_2_Supps		("EAN 8 with 2 Supps")
#define	str_EAN_8_with_5_Supps		("EAN 8 with 5 Supps")
#define	str_EAN_13_with_2_Supps		("EAN 13 with 2 Supps")
#define	str_EAN_13_with_5_Supps		("EAN 13 with 5 Supps")
#define	str_EAN128					("EAN 128")



// CODE 128
#define	str_CODE128			("CODE 128")
#define	str_UCCEAN128		("UCC/EAN-128")
#define	str_ISBT128			("ISBT 128")

// CODE 39
#define	str_CODE39			("CODE 39")
#define	str_TRIOPTICCODE39	("Trioptic CODE 39")
#define str_CODE32			("CODE 32")

// CODE 93
#define	str_CODE93			("CODE 93")

// CODE11
#define str_Code11			("CODE 11")

// Interleaved 2 of 5
#define	str_INTERLEAVED2OF5	("Interleaved 2of5")

// Discrete 2 of 5
#define	str_DISCRETE2OF5	("Discreate 2of5")

// Chinese 2 of 5
#define str_CHINESE2of5			("Chinese 2of5")

// CODABAR
#define	str_CODABAR			("CODABAR")

// MSI
#define	str_MSI				("MSI")

// GS1
#define	str_GS1					("GS1")
#define	str_GS1_LIMITED			("GS1 LIMITED")
#define	str_GS1_EXPANDED		("GS1 EXPANDED")

#define	str_Not_Applicable		("Not Applicable")		

// Length
#define	str_OneDiscreateLength		("ONE DISCREATE LENGTH")
#define	str_TwoDiscreateLength		("TWO DISCREATE LENGTH")
#define	str_LengthWithinRange		("LENGTH WITHIN RANGE")
#define	str_AnyLength			("ANY LENGTH")

// Scan Data Transmission Format
#define	str_DataAsIs			("DATA AS IS")
#define	str_DataSuffix1			("DATA SUFFIX 1")
#define	str_DataSuffix2			("DATA SUFFIX 2")
#define	str_DataSuffix1Suffix2		("DATA SUFFIX 1 SUFFIX 2")
#define str_PrefixData			("PREFIX DATA")
#define	str_PrefixDataSuffix1		("PREFIX DATA SUFFIX 1")
#define	str_PrefixDataSuffix2		("PREFIX DATA SUFFIX 2")
#define	str_PrefixDataSuffix1Suffix2	("PREFIX DATA SUFFIX 1 SUFFIX 2")

// Decode UPC/EAN Supplementals
#define	str_DecodeUpcEanwithSupp	("Decode UPC/EAN With Supplementals")
#define	str_IgnoreUpcEanwithSupp	("Ignore UPC/EAN With Supplementals")
#define	str_AutodiscriminateUpcEanSupp	("Autodiscriminat UPC/EAN Supplementals")

// I 2 of 5 Check Digit Verification
#define	str_USSCheckDigit		("USS Check Digit")
#define	str_OPCCCheckDigit		("OPCC Check Digit")

// MSI Plessey Check Digit Algorithm
#define	str_MOD10MOD11			("MOD 10/MOD 11")
#define	str_MOD10MOD10			("MOD 10/MOD 10")

// SCAN Angle	
#define	str_NoClipping			("No Clipping")
#define	str_MinimumClipping		("Minimum Clipping")
#define	str_MediumClipping		("Medium Clipping")
#define	str_MaximumClipping		("Maximum Clipping")



typedef enum tagConvertType
{
	UPCEtoA			= 0x25,	// Convert UPC-E to A
	UPCE1toA		= 0x26,	// Convert UPC-E1 to A
	EAN8toEAN13		= 0xE0,	// Convert EAN-8 to EAN-13 
	Code39to32		= 0x56,	// Convert Code 39 to Code 32
	I2OF5toEAN13	= 0x52	// Convert I 2 of 5 to EAN 13
} ConvertType;



typedef enum tagScannerOption
{
	LASER_ON_TIME			= 0x88,
	SCAN_ANGLE			= 0xBF,
	POWER_MODE			= 0x80,
	TIME_OUT_BETWEEN_SAME_SYMBOL	= 0x89,
	LINEAR_CODE_TYPE_SECURITY_LEVELS = 0x4e

}ScannerOption;

typedef struct{
	char	swRevision[MAX_PATH];
	unsigned char	BoardType;
	unsigned char	ScannerID;
	char	ScannerEngineDescription[MAX_PATH];
}REVISIONStruct;


typedef enum tagBarCodeType
{
	// UPC/EAN
	UPCA			= 0x01,
	UPCE 			= 0x02,
	UPCE1			= 0x0C,
	EAN8			= 0x04,
	EAN13			= 0x03,
	BOOKLAND_EAN	= 0x53,	
	COUPON			= 0x55,	

	// CODE 128
	CODE128			= 0x08,
	UCC_EAN128		= 0x0E,
	ISBT_128		= 0x54,

	// CODE 39
	CODE39			= 0x00,
	TRIOPTIC39 		= 0x0D,

	// CODE 93
	CODE93			= 0x09,

	// CODE11
	CODE11			= 0x0A,

	// Interleaved 2 of 5
	I2OF5			= 0x06,

	// Discreate 2 of 5
	DIS2OF5			= 0x05,	

	// CHINESS 2of 5
	CH2OF5			= 0x98,

	// CODABAR
	CODABAR			= 0x07,

	// MSI Plessey
	MSI			 	= 0x0B,

	// GS1
	GS1				= 0x52,
	GS1_LIMITED		= 0x53,
	GS1_EXPANDED	= 0x54,

	CH2OF5_GS1_BASE	= 0xF0		// CH2OF5�� GS1�� ����� ���ɾ� �׻� Enable ��ų ��



} BarCodeType;

class CMCPScan  
{
protected:
	void		BarCodeTypeCheck(unsigned char BarCodeType, char * BarCodeTypeName);
	void		ScanRead(char *BarCodeData,unsigned char *BarCodeTypeName);
	void		SetInit();
	void		Init();	
	BOOL		ParamSend(unsigned char SendParam, unsigned char Value);
	BOOL		TwoSendCheck();
	void		CommandWrite(unsigned char BarCommand);
	void		AimOff();
	void		AimOn();
	void		LEDOn();	
	void		LEDOff();	
	void		ScanSleep();
	void		SetAimStatus(BOOL	aim_status);	
	BOOL		GetAimStatus();	
	void		SetBarCodeType(unsigned long type);	
	unsigned char	GetParamRequest(unsigned char codeType);
	void		ParamRequest(unsigned char	RequestData);
	
	void		SetCodabarCLSIEditing(BOOL bEnable);	
	BOOL		GetCodabarCLSIEditing();
	
	void		SetScanAngle(unsigned char angle);
	unsigned char	GetScanAngle();
	void		SetNREnabled(BOOL bEnable);
	BOOL		GetNREnabled();
	void		SetUPCEANSecurityLevel(unsigned char security_level);
	unsigned char	GetUPCEANSecurityLevel();
	
	
	////////////////////////----------Serial Interface-----------///////////////////////	
	void		SetBaudRate(unsigned char baud_rate);
	unsigned char	GetBaudRate();
	void		SetParity(unsigned char parity);
	unsigned char	GetParity();
	void		SetSoftwareHandshaking(BOOL bEnable);
	BOOL		GetSoftwareHandshaking();
	void		SetDecodeDataPacketFormat(BOOL bEnable);
	BOOL		GetDecodeDataPacketFormat();
	void		SetHostSerialResponseTimeout(unsigned char sec);
	unsigned char	GetHostSerialResponseTimeout();
	void		SetStopBitSelect(unsigned char stopbit);
	unsigned char	GetStopBitSelect();
	void		SetIntercharacterDelay(unsigned char sec);
	unsigned char	GetIntercharacterDelay();
	void		SetHostCharacterTimeout(unsigned char msec);
	unsigned char	GetHostCharacterTimeout();



	void		SetTriggerModes(unsigned char para);
	unsigned char	GetTriggerModes();
	void		SendAck();
	void		SendNak();
	

public:
	CMCPScan();
	virtual ~CMCPScan();

	// Add Func [12/22/2009 vision7901]
	void			SetTransmitCheckDigit(unsigned char codeType,unsigned char check_digit);
	unsigned char	GetTransmitCheckDigit(unsigned char codeType);
	void			SetUPCPreamble(unsigned char codeType,unsigned char preamble);
	unsigned char	GetUPCPreamble(unsigned char codeType);
	void			SetBarCodeConvert(ConvertType codeType, BOOL bEnable);	
	BOOL			GetBarCodeConvert(ConvertType codeType);
	void			SetEANZeroExtend(BOOL bEnable);
	BOOL			GetEANZeroExtend();
	void			SetDecUPCEANSupplementals(unsigned char supplementals);
	unsigned char	GetDecUPCEANSupplementals();
	void			SetCode39CheckDigitVerification(BOOL bEnable);	
	BOOL			GetCode39CheckDigitVerification();	
	void			SetCode32PrefixEnabled(BOOL	bEnable);
	BOOL			GetCode32PrefixEnabled();
	void			SetCode39FullAscii(BOOL	bEnable);	
	BOOL			GetCode39FullAscii();
	void			SetCode11CheckDigitVerification(unsigned char check_digit);
	unsigned char	GetCode11CheckDigitVerification();
	void			SetI2of5CheckDigitVerification(unsigned char check_digit);
	unsigned char	GetI2of5CheckDigitVerification();
	void			SetCodabarNOTISEditing(BOOL bEnable);	
	BOOL			GetCodabarNOTISEditing();
	void			SetMSIPlesseyCheckDigit(unsigned char check_digit);
	unsigned char	GetMSIPlesseyCheckDigit();
	void			SetMSIPlesseyCheckDigitAlgorithm(unsigned char check_digit);
	unsigned char	GetMSIPlesseyCheckDigitAlgorithm();
	void			SetTransmitCodeID(unsigned char codeID);
	unsigned char	GetTransmitCodeID();
	//////////////////////////////////////////////////////////////////////////

	BOOL		ReadCancel();
	BOOL		Read(PKSCANREAD pRead);
	BOOL		Close();
	BOOL		Open(int CommNumber, BOOL CommDetect, DWORD BaudRate, BOOL BaudDetect, DWORD ExFlags);
	void		ScanReadDatatoPort();
	BOOL		SetBarCodeEnabled(unsigned char codeType,BOOL bEnable);
	BOOL		GetBarCodeEnabled(unsigned char codeType);
	BOOL		SetCh2of5_Gs1_Enable(unsigned char SendParam, unsigned char Value);	// CH2OF5/ GS1 Setting
	void		GetRevision(REVISIONStruct*	Revision);
	void		GetRevision(BYTE* byRevision);
	////////////////////////----------Data Options-----------///////////////////////		
	void		SetPreSuffixValues(unsigned char prefix, unsigned char suffix1, unsigned char suffix2);
	unsigned char	GetPreSuffixValues(unsigned char* pPrefix,unsigned char* pSuffix1, unsigned char* pSuffix2);
	void		SetDataTransmissionFormat(unsigned char data);
	unsigned char	GetDataTransmissionFormat();
protected:
	unsigned char	WriteData[256];
	BOOL		bAimStatus;
	BOOL		CommWriteFirst;
	BOOL		TwoSendFlag;
	BOOL		bOneExcuteThread;	
	SYSTEMTIME	m_LastDateTime;	
	KS_FN_CALLBACK  fnCallBack;
	LPVOID		pUserData;
	MCPScanOption	m_mcpoption;
	MCPBarCodeType  m_mcpbarcodetype;


public:
	HANDLE		m_hComm;	// port file handle
	HWND		m_hWin;		// parent window handle
	BOOL		fConnected;
	BOOL		fRead;
	BOOL		fReding;
	BOOL		fCTS;
	unsigned char	ReadScanData[2048];
	BOOL		m_bDecodeStart;
	BOOL		m_bAlarm;
	int		bReadFlag;



protected:	
	BOOL		OpenComPort(LPTSTR	lpszPortName, DWORD*	pdwError, DWORD BoundRate);
	BOOL		WriteComPort(unsigned char*	lpData,int	dwBytesToWrite);
	
	BOOL		CloseComPort();
	BOOL		ClearComPort();
	BOOL		GetAlarm();
	void		SetAlarm(BOOL bAlarm);
	HWND		GetNotifyWndHandle();
	BOOL		SetNotifyWndHandle(HWND hWnd);
	BOOL		GetBarCodeLengths(BarCodeType codeType,unsigned char* pL1,unsigned char* pL2);
	void		SetBarCodeLengths(BarCodeType codeType, unsigned char L1, unsigned char L2);
	DWORD		ReadComPort(BYTE *pBuff, DWORD nToRead);
	
	
public:
	
	void		ScanReadPower();
	unsigned long	Get_Scan_Option();
	void		GetScanOptionAll(PKSCANREAD pRead);
	unsigned long	GetBarCodeType();
	unsigned long	GetTimeOut_BSS();
	unsigned int	GetLaserOnTime();
	unsigned long	GetSecurityLevel();
	void		SetTimeOut_BSS(unsigned long time);
	void		Set_Scan_Option(unsigned long option);
	void		SetLaserOnTime(unsigned int time);
	void		SetSecurityLevel(unsigned long level);
	void		SetScanOptionAll(PKSCANREAD pRead);
	unsigned long	GetScanOption();
	BOOL		SetScanOption(unsigned long option);
	BOOL		ReadCheckSum(unsigned char*Data,int Len);

	
	void		SetPreSufReg(PMCPScanOption mcpoption);
	void		SetButKeyReg(PMCPScanOption mcpoption);
	void		InitReg(PMCPScanOption mcpoption,PMCBarCodeType mcpbarcodetype);
	void		SetDefaultReg();
	void		SetBarCodeReg(PMCBarCodeType mcpbarcodetype);
	void		SetOptionReg(PMCPScanOption mcpoption);	
	
	
};
class CReg  
{
public:
	
	CReg::CReg()
	{
		HKEY hKey;
		DWORD dwDisp;
		RegCreateKeyEx(HKEY_CURRENT_USER , L"Software\\M3Mobile", 0, NULL, REG_OPTION_NON_VOLATILE, KEY_READ|KEY_WRITE, NULL, &hKey, &dwDisp);
		
		RegCloseKey(hKey);
	}
	
	CReg::~CReg()
	{
		
	}
	
	
	BOOL CReg::GetRegStr(HKEY hKeyRoot, WCHAR *wszRegPath, WCHAR *wsaValue, TCHAR *wsGetData)
	{
		HKEY hKey;
		int nRet;
		//	DWORD dwDisp;
		DWORD size = 0;
		
		
		memset(wsGetData, 0, 50);
		
		nRet = RegOpenKeyEx(hKeyRoot, wszRegPath, 0, KEY_QUERY_VALUE, &hKey);
		if(nRet != ERROR_SUCCESS)
		{
			return NULL;
		}
		
		
		size = RegQueryValueEx (hKey, wsaValue, NULL, NULL, (LPBYTE)wsGetData, NULL);
		if(size == 0)
		{
			RegCloseKey(hKey);
			return NULL;
		}
		
		nRet = RegQueryValueEx (hKey, wsaValue, NULL, NULL, (LPBYTE)wsGetData, &size);
		if(nRet != ERROR_SUCCESS)
		{
			RegCloseKey(hKey);
			return NULL;
		}
		
		if(hKey) RegCloseKey(hKey);
		
		
		return 0;	
	}
	
	BOOL CReg::SetRegStr(HKEY hKeyRoot, WCHAR *wszRegPath, WCHAR *wszValue, WCHAR *wszData)
	{
		HKEY hKey;
		int nRet;
		DWORD dwDisp;
		
		nRet = RegCreateKeyEx(hKeyRoot, wszRegPath, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, &dwDisp);
		if(nRet != ERROR_SUCCESS)
		{
			return -1;
		}
		
		nRet = RegSetValueEx(hKey, wszValue, 0, REG_SZ, (LPBYTE)wszData, (wcslen(wszData)*sizeof(TCHAR) )+1 );
		if(nRet != ERROR_SUCCESS)
		{
			return -1;
		}
		RegCloseKey(hKey);
		return TRUE;
	}
	
	DWORD CReg::GetRegValue(HKEY hKeyRoot, WCHAR *wszRegPath, WCHAR *wszValue)
	{
		HKEY key;
		DWORD dwDisp;
		DWORD Size;
		if(RegCreateKeyEx(hKeyRoot, wszRegPath, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_READ, NULL, &key, &dwDisp) != ERROR_SUCCESS)
		{
			return -1;
		}
		Size = sizeof(LONG);
		if(RegQueryValueEx(key, wszValue, 0, NULL, (LPBYTE)&m_nRegValue, &Size) != ERROR_SUCCESS)
		{
			return -1;
		}
		
		RegCloseKey(key);
		return m_nRegValue;
	}
	
	BOOL CReg::SetRegValue(HKEY hKeyRoot, WCHAR *wszRegPath, WCHAR * wszValue, DWORD wszData)
	{
		HKEY hKey;
		int nRet;
		DWORD dwDisp;
		
		nRet = RegCreateKeyEx(hKeyRoot, wszRegPath, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, &dwDisp);
		if(nRet != ERROR_SUCCESS)
		{
			MessageBox(NULL, L"Reg Create Error", L"Registry", MB_OK);
			return -1;
		}
		
		nRet = RegSetValueEx(hKey, wszValue, 0, REG_DWORD, (LPBYTE)&wszData, sizeof(DWORD));
		if(nRet != ERROR_SUCCESS)
		{
			return -1;
		}
		RegCloseKey(hKey);
		return m_nRegValue;
	}
//	WCHAR m_wszRegString[512];
	int   m_nRegValue;
};
#endif // !defined(AFX_MCPSCAN_H__4D0298C8_E9B3_4DFE_8211_41048056B8DF__INCLUDED_)
