// MsiDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3PlusScanTest.h"
#include "MsiDlg.h"
#include "M3PlusScanTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMsiDlg dialog


CMsiDlg::CMsiDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMsiDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMsiDlg)
	m_bEnableMsi = FALSE;
	m_bMsiCdv = FALSE;
	m_bMsiXcd = FALSE;
	m_nMsiCdvAlg = -1;
	//}}AFX_DATA_INIT
}


void CMsiDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMsiDlg)
	DDX_Check(pDX, IDC_CHECK_MSI, m_bEnableMsi);
	DDX_Check(pDX, IDC_CHECK_MSI_CDV, m_bMsiCdv);
	DDX_Check(pDX, IDC_CHECK_MSI_XCD, m_bMsiXcd);
	DDX_Radio(pDX, IDC_RADIO_MOD10_10, m_nMsiCdvAlg);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMsiDlg, CDialog)
	//{{AFX_MSG_MAP(CMsiDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMsiDlg message handlers

BOOL CMsiDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);

	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CMsiDlg::GetOption()
{
	CM3PlusScanTestDlg* dlg = (CM3PlusScanTestDlg*)AfxGetMainWnd();

	// Enable
	int nCheck = 0;
	nCheck = dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"VER");
	if( nCheck == -1 || nCheck != M3PLUSSCANVER)
	{
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"MSI",(DWORD)dlg->KScan.GetBarCodeType(MSI));
	}

	m_bEnableMsi = (BOOL)dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"MSI");

	// CheckDigit
	m_bMsiXcd	= (BOOL)dlg->KScan.GetTransmitCheckDigit(TRANMSIPLESSEYCD);
	m_bMsiCdv	= (BOOL)dlg->KScan.GetMSIPlesseyCheckDigit();
	m_nMsiCdvAlg= (DWORD)dlg->KScan.GetMSIPlesseyCheckDigitAlgorithm();

	UpdateData(FALSE);
}

void CMsiDlg::SetOption()
{
	UpdateData(TRUE);
	
	CM3PlusScanTestDlg* dlg = (CM3PlusScanTestDlg*)AfxGetMainWnd();

	// Enable
	if((DWORD)m_bEnableMsi != dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"MSI"))
	{
		dlg->KScan.SetBarCodeType(MSI, m_bEnableMsi);	
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"MSI", m_bEnableMsi);
	}

	// Transmit CheckDigit
	dlg->KScan.SetTransmitCheckDigit(TRANMSIPLESSEYCD, (unsigned char)m_bMsiXcd);
	dlg->KScan.SetMSIPlesseyCheckDigit((unsigned char)m_bMsiCdv);
	dlg->KScan.SetMSIPlesseyCheckDigitAlgorithm((unsigned char)m_nMsiCdvAlg);
}

void CMsiDlg::OnOK() 
{
	SetOption();
	
	CDialog::OnOK();
}
