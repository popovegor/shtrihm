#if !defined(AFX_MSIDLG_H__FC31AAB0_1D5E_4FC6_BFD1_D4C8053E928E__INCLUDED_)
#define AFX_MSIDLG_H__FC31AAB0_1D5E_4FC6_BFD1_D4C8053E928E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MsiDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMsiDlg dialog

class CMsiDlg : public CDialog
{
// Construction
public:
	void SetOption();
	void GetOption();
	CMsiDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMsiDlg)
	enum { IDD = IDD_MSI_DLG };
	BOOL	m_bEnableMsi;
	BOOL	m_bMsiCdv;
	BOOL	m_bMsiXcd;
	int		m_nMsiCdvAlg;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMsiDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMsiDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MSIDLG_H__FC31AAB0_1D5E_4FC6_BFD1_D4C8053E928E__INCLUDED_)
