// M3PlusScanTestDlg.h : header file
//

#if !defined(AFX_M3PLUSSCANTESTDLG_H__8DEF6EA5_4C51_415B_9FF1_D3D919E1EA65__INCLUDED_)
#define AFX_M3PLUSSCANTESTDLG_H__8DEF6EA5_4C51_415B_9FF1_D3D919E1EA65__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CM3PlusScanTestDlg dialog
#include "kscanbar.h"
#include "MCPScan.h"
#include "OptionDlg.h"
#include "DetailDlg.h"

class CM3PlusScanTestDlg : public CDialog
{
// Construction
public:
	CM3PlusScanTestDlg(CWnd* pParent = NULL);	// standard constructor
public:
	void SetDefaultReg();
	void SetScanOption(CDetailDlg  *dlg);
	void GetScanOption(CDetailDlg *dlg);
	void SetBarCodeType(COptionDlg  *dlg);
	void GetBarCodeType(COptionDlg *dlg);
	void BarCodeTypeCheck(unsigned char BarCodeType, CString BarCodeTypeName,CString BarCodeValue);
	void LoadResSound();	
	void MCP_ScanReadNB();
	BOOL MCP_ScanOpen(int PortNumber);
	CKScan	KScan;
	BOOL		m_bReading;
	BOOL		m_bKeyFlag;
	BOOL		m_bSycnMode;
	BOOL		m_bScanFlag;
	CReg		m_reg;
	MCPBarCodeType  m_mcpbarcodetype;
	MCPScanOption	m_mcpscanoption;
// Dialog Data
	//{{AFX_DATA(CM3PlusScanTestDlg)
	enum { IDD = IDD_M3PLUSSCANTEST_DIALOG };
	CListCtrl	m_ctrl_listctrl_scandata;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CM3PlusScanTestDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CM3PlusScanTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnButScan();
	afx_msg void OnButCancel();
	afx_msg void OnButOption();
	afx_msg void OnClose();
	afx_msg void OnBtnDetail();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_M3PLUSSCANTESTDLG_H__8DEF6EA5_4C51_415B_9FF1_D3D919E1EA65__INCLUDED_)
