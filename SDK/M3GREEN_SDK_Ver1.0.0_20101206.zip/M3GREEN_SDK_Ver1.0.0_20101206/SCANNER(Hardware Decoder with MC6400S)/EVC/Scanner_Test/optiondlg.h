#if !defined(AFX_OPTION_H__B01512B9_5402_4855_AC62_D95CCE9FBEFA__INCLUDED_)
#define AFX_OPTION_H__B01512B9_5402_4855_AC62_D95CCE9FBEFA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Option.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COption dialog

class COptionDlg : public CDialog
{
// Construction
public:

//	void SetScanOption();
	COptionDlg(CWnd* pParent = NULL);   // standard constructor
public:
// Dialog Data
	//{{AFX_DATA(COption)
	enum { IDD = IDD_OPTION_DLG };
	BOOL	m_bBookLand_Ean;
	BOOL	m_bCodabar;
	BOOL	m_bCode128;
	BOOL	m_bCode39;
	BOOL	m_bCode93;
	BOOL	m_bCoupon;
	BOOL	m_bDis2of5;
	BOOL	m_bEan13;
	BOOL	m_bEan8;
	BOOL	m_bI2of5;
	BOOL	m_bMsi_plessey;
	BOOL	m_bTrioptic39;
	BOOL	m_bUcc_ean128;
	BOOL	m_bUpca;
	BOOL	m_bUpce;
	BOOL	m_bUpce1;
	BOOL	m_bIsbt_128;
	BOOL	m_bCode11;
	BOOL	m_bCh2of5;
	BOOL	m_bGs1;
	BOOL	m_bGs1Expanded;
	BOOL	m_bGs1Limited;
	BOOL	m_bALL;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COption)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(COption)
	afx_msg void OnCheckAll();
	afx_msg void OnTimer(UINT nIDEvent);
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTION_H__B01512B9_5402_4855_AC62_D95CCE9FBEFA__INCLUDED_)
