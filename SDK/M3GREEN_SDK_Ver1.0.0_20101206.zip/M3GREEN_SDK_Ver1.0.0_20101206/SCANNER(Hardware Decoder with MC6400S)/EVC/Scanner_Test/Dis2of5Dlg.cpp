// Dis2of5Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3PlusScanTest.h"
#include "Dis2of5Dlg.h"
#include "M3PlusScanTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDis2of5Dlg dialog


CDis2of5Dlg::CDis2of5Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDis2of5Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDis2of5Dlg)
	m_bEnableDis2of5 = FALSE;
	//}}AFX_DATA_INIT
}


void CDis2of5Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDis2of5Dlg)
	DDX_Check(pDX, IDC_CHECK_DIS2OF5, m_bEnableDis2of5);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDis2of5Dlg, CDialog)
	//{{AFX_MSG_MAP(CDis2of5Dlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDis2of5Dlg message handlers

BOOL CDis2of5Dlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);

	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDis2of5Dlg::GetOption()
{
	CM3PlusScanTestDlg* dlg = (CM3PlusScanTestDlg*)AfxGetMainWnd();

	int nCheck = 0;
	nCheck = dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"VER");
	if( nCheck == -1 || nCheck != M3PLUSSCANVER)
	{
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"DIS2OF5",(DWORD)dlg->KScan.GetBarCodeType(DIS2OF5));		
	}

	m_bEnableDis2of5	= (BOOL)dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"DIS2OF5");

	UpdateData(FALSE);
}

void CDis2of5Dlg::SetOption()
{
	UpdateData(TRUE);

	CM3PlusScanTestDlg* dlg = (CM3PlusScanTestDlg*)AfxGetMainWnd();

	if((DWORD)m_bEnableDis2of5 != dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"DIS2OF5"))
	{
		dlg->KScan.SetBarCodeType(DIS2OF5 , m_bEnableDis2of5);
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"DIS2OF5", m_bEnableDis2of5);
		
	}
}

void CDis2of5Dlg::OnOK() 
{
	SetOption();
	
	CDialog::OnOK();
}
