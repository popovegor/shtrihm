#if !defined(AFX_UPCEANDLG_H__89901DC4_E146_4114_982A_B86822231A08__INCLUDED_)
#define AFX_UPCEANDLG_H__89901DC4_E146_4114_982A_B86822231A08__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UpceanDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CUpceanDlg dialog
// #include "kscanbar.h"
// #include "MCPScan.h"

class CUpceanDlg : public CDialog
{
// Construction
public:
	void SetOption();
	void GetOption();
	CUpceanDlg(CWnd* pParent = NULL);   // standard constructor

// 	CKScan	m_KScan;
// 	CReg	m_Reg;

// Dialog Data
	//{{AFX_DATA(CUpceanDlg)
	enum { IDD = IDD_UPCEAN_DLG };
	BOOL	m_bEnableBookland;
	BOOL	m_bEnableEan13;
	BOOL	m_bEnableEan8;
	BOOL	m_bConvertEan8toEan13;
	BOOL	m_bSupp;
	BOOL	m_bEnableUpca;
	BOOL	m_bUpcaXcd;
	BOOL	m_bEnableUpce;
	BOOL	m_bConvertUpcetoA;
	BOOL	m_bUpceXcd;
	BOOL	m_bEnableUpce1;
	BOOL	m_bConvertUpce1toA;
	BOOL	m_bUpce1Xcd;
	int		m_nUpcaPream;
	int		m_nUpcePream;
	int		m_nUpce1Pream;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUpceanDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CUpceanDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UPCEANDLG_H__89901DC4_E146_4114_982A_B86822231A08__INCLUDED_)
