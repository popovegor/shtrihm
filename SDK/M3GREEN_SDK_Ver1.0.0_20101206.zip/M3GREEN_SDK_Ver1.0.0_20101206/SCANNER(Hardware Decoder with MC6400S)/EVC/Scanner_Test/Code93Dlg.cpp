// Code93Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3PlusScanTest.h"
#include "Code93Dlg.h"
#include "M3PlusScanTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCode93Dlg dialog


CCode93Dlg::CCode93Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCode93Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCode93Dlg)
	m_bEnableCode93 = FALSE;
	//}}AFX_DATA_INIT
}


void CCode93Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCode93Dlg)
	DDX_Check(pDX, IDC_CHECK_CODE93, m_bEnableCode93);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCode93Dlg, CDialog)
	//{{AFX_MSG_MAP(CCode93Dlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCode93Dlg message handlers

BOOL CCode93Dlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);

	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCode93Dlg::GetOption()
{
	CM3PlusScanTestDlg* dlg = (CM3PlusScanTestDlg*)AfxGetMainWnd();

	int nCheck = 0;
	nCheck = dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"VER");
	if( nCheck == -1 || nCheck != M3PLUSSCANVER)
	{
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE93",(DWORD)dlg->KScan.GetBarCodeType(CODE93));		
	}

	m_bEnableCode93		= (BOOL)dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE93");


	UpdateData(FALSE);
}

void CCode93Dlg::SetOption()
{
	UpdateData(TRUE);
	
	CM3PlusScanTestDlg* dlg = (CM3PlusScanTestDlg*)AfxGetMainWnd();

	if((DWORD)m_bEnableCode93 != dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE93"))
	{
		dlg->KScan.SetBarCodeType(CODE93	, m_bEnableCode93);
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE93", m_bEnableCode93);		
	}
}

void CCode93Dlg::OnOK() 
{
	SetOption();
	
	CDialog::OnOK();
}
