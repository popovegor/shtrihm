// UpceanDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3PlusScanTest.h"
#include "UpceanDlg.h"
#include "M3PlusScanTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUpceanDlg dialog


CUpceanDlg::CUpceanDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUpceanDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUpceanDlg)
	m_bEnableBookland = FALSE;
	m_bEnableEan13 = FALSE;
	m_bEnableEan8 = FALSE;
	m_bConvertEan8toEan13 = FALSE;
	m_bSupp = FALSE;
	m_bEnableUpca = FALSE;
	m_bUpcaXcd = FALSE;
	m_bEnableUpce = FALSE;
	m_bConvertUpcetoA = FALSE;
	m_bUpceXcd = FALSE;
	m_bEnableUpce1 = FALSE;
	m_bConvertUpce1toA = FALSE;
	m_bUpce1Xcd = FALSE;
	m_nUpcaPream = 1;
	m_nUpcePream = 1;
	m_nUpce1Pream = 1;
	//}}AFX_DATA_INIT
}


void CUpceanDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUpceanDlg)
	DDX_Check(pDX, IDC_CHECK_BOOKLAND, m_bEnableBookland);
	DDX_Check(pDX, IDC_CHECK_EAN13, m_bEnableEan13);
	DDX_Check(pDX, IDC_CHECK_EAN8, m_bEnableEan8);
	DDX_Check(pDX, IDC_CHECK_EAN8_TO_EAN13, m_bConvertEan8toEan13);
	DDX_Check(pDX, IDC_CHECK_SUPP, m_bSupp);
	DDX_Check(pDX, IDC_CHECK_UPCA, m_bEnableUpca);
	DDX_Check(pDX, IDC_CHECK_UPCA_XCD, m_bUpcaXcd);
	DDX_Check(pDX, IDC_CHECK_UPCE, m_bEnableUpce);
	DDX_Check(pDX, IDC_CHECK_UPCE_TO_A, m_bConvertUpcetoA);
	DDX_Check(pDX, IDC_CHECK_UPCE_XCD, m_bUpceXcd);
	DDX_Check(pDX, IDC_CHECK_UPCE1, m_bEnableUpce1);
	DDX_Check(pDX, IDC_CHECK_UPCE1_TO_A, m_bConvertUpce1toA);
	DDX_Check(pDX, IDC_CHECK_UPCE1_XCD, m_bUpce1Xcd);
	DDX_Radio(pDX, IDC_RADIO_UPCA_NO, m_nUpcaPream);
	DDX_Radio(pDX, IDC_RADIO_UPCE_NO, m_nUpcePream);
	DDX_Radio(pDX, IDC_RADIO_UPCE1_NO, m_nUpce1Pream);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUpceanDlg, CDialog)
	//{{AFX_MSG_MAP(CUpceanDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUpceanDlg message handlers

BOOL CUpceanDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);

	GetOption();
		
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CUpceanDlg::GetOption()
{
	CM3PlusScanTestDlg* dlg = (CM3PlusScanTestDlg*)AfxGetMainWnd();

	// Enable
	int nCheck = dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"VER");
	if( nCheck == -1 || nCheck != M3PLUSSCANVER)
	{
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCA", (DWORD)dlg->KScan.GetBarCodeType(UPCA));
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCE", (DWORD)dlg->KScan.GetBarCodeType(UPCE));
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCE1", (DWORD)dlg->KScan.GetBarCodeType(UPCE1));
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"EAN8", (DWORD)dlg->KScan.GetBarCodeType(EAN8));
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"EAN13", (DWORD)dlg->KScan.GetBarCodeType(EAN13));
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"BOOKLAND_EAN", (DWORD)dlg->KScan.GetBarCodeType(BOOKLAND_EAN));
	}

	m_bEnableUpca		= (BOOL)dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCA");
	m_bEnableUpce		= (BOOL)dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCE");
	m_bEnableUpce1		= (BOOL)dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCE1");
	m_bEnableEan8		= (BOOL)dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"EAN8");
	m_bEnableEan13		= (BOOL)dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"EAN13");
	m_bEnableBookland	= (BOOL)dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"BOOKLAND_EAN");

	// Transmit CheckDigit
	m_bUpcaXcd	= (BOOL)dlg->KScan.GetTransmitCheckDigit(TRANUPCACD);
	m_bUpceXcd	= (BOOL)dlg->KScan.GetTransmitCheckDigit(TRANUPCECD);
	m_bUpce1Xcd = (BOOL)dlg->KScan.GetTransmitCheckDigit(TRANUPCE1CD);

	// Preamble
	m_nUpcaPream	= (DWORD)dlg->KScan.GetUPCPreamble(UPCAPRE);
	m_nUpcePream	= (DWORD)dlg->KScan.GetUPCPreamble(UPCEPRE);
	m_nUpce1Pream	= (DWORD)dlg->KScan.GetUPCPreamble(UPCE1PRE);

	// Convert
	m_bConvertUpcetoA		= dlg->KScan.GetBarCodeConvert(UPCEtoA);
	m_bConvertUpce1toA		= dlg->KScan.GetBarCodeConvert(UPCE1toA);
	m_bConvertEan8toEan13	= dlg->KScan.GetEANZeroExtend();

	// Supplemental
	m_bSupp		= (BOOL)dlg->KScan.GetDecUPCEANSupplementals();

	UpdateData(FALSE);
}

void CUpceanDlg::SetOption()
{
	UpdateData(TRUE);

	CM3PlusScanTestDlg* dlg = (CM3PlusScanTestDlg*)AfxGetMainWnd();

	// Enable
	if((DWORD)m_bEnableUpca != dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCA"))
	{
		dlg->KScan.SetBarCodeType(UPCA, m_bEnableUpca);
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCA", m_bEnableUpca);
		
	}
	if((DWORD)m_bEnableUpce != dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCE"))
	{
		dlg->KScan.SetBarCodeType(UPCE, m_bEnableUpce);
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCE", m_bEnableUpce);
		
	}
	if((DWORD)m_bEnableUpce1 != dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCE1"))
	{
		dlg->KScan.SetBarCodeType(UPCE1, m_bEnableUpce1);
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCE1", m_bEnableUpce1);
		
	}
	if((DWORD)m_bEnableEan8 != dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"EAN8"))
	{
		dlg->KScan.SetBarCodeType(EAN8, m_bEnableEan8);
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"EAN8", m_bEnableEan8);
		
	}
	if((DWORD)m_bEnableEan13 != dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"EAN13"))
	{
		dlg->KScan.SetBarCodeType(EAN13, m_bEnableEan13);
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"EAN13", m_bEnableEan13);
		
	}
	if((DWORD)m_bEnableBookland != dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"BOOKLAND_EAN"))
	{
		dlg->KScan.SetBarCodeType(BOOKLAND_EAN, m_bEnableBookland);
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"BOOKLAND_EAN", m_bEnableBookland);		
	}

	// Transmit CheckDigit
	dlg->KScan.SetTransmitCheckDigit(TRANUPCACD, (unsigned char)m_bUpcaXcd);
	dlg->KScan.SetTransmitCheckDigit(TRANUPCECD, (unsigned char)m_bUpceXcd);
	dlg->KScan.SetTransmitCheckDigit(TRANUPCE1CD, (unsigned char)m_bUpce1Xcd);

	// Preamble
	dlg->KScan.SetUPCPreamble(UPCAPRE, (unsigned char)m_nUpcaPream);
	dlg->KScan.SetUPCPreamble(UPCEPRE, (unsigned char)m_nUpcePream);
	dlg->KScan.SetUPCPreamble(UPCE1PRE, (unsigned char)m_nUpce1Pream);

	// Convert
	dlg->KScan.SetBarCodeConvert(UPCEtoA, m_bConvertUpcetoA);
	dlg->KScan.SetBarCodeConvert(UPCE1toA, m_bConvertUpce1toA);
	dlg->KScan.SetEANZeroExtend(m_bConvertEan8toEan13);

	// Supplemental	
	dlg->KScan.SetDecUPCEANSupplementals((unsigned char)m_bSupp);
}

void CUpceanDlg::OnOK() 
{
	SetOption();
	
	CDialog::OnOK();
}
