/********************************************************************
created		:	2009/09/11
file base	: 	M3PlusScanTest.exe

file ext	:	cpp
author		:	Dong-Hyun, Eum(Vision7901) - SW2
  
purpose		:	MC6400S
Report		:	2009. 09. 11 [09/11/2009 vision7901] v2.0.0 - �������� ����. BarCode Update
				2009. 12. 31 [12/31/2009 vision7901] v2.1.0 - ���ڵ庰 ���οɼǱ�� �߰�
				2010. 11. 24 [11/24/2010 vision7901] v2.2.0 - UPC/EAN Supp ��� ����
*********************************************************************/
// M3PlusScanTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3PlusScanTest.h"
#include "M3PlusScanTestDlg.h"

#include "Msgqueue.h"		// �޽��� ť ����
#include "pm.h"				// �������� ����
#include "pkfuncs.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CM3PlusScanTestDlg dialog

#define QUEUE_ENTRIES   3
#define MAX_NAMELEN     200
#define QUEUE_SIZE      (QUEUE_ENTRIES * (sizeof(POWER_BROADCAST) + MAX_NAMELEN))
int          bOneExcuteThread = FALSE;

DWORD		 KSCANAPI KScanReadCallBack(LPVOID pRead);

KSCANREAD	 kRead;


CM3PlusScanTestDlg::CM3PlusScanTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CM3PlusScanTestDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_bReading  = FALSE;
	m_bKeyFlag  = FALSE;
	m_bSycnMode = TRUE;
	m_bScanFlag = FALSE;
	
}

void CM3PlusScanTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CM3PlusScanTestDlg)
	DDX_Control(pDX, IDC_LIST_SCAN_DATA, m_ctrl_listctrl_scandata);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CM3PlusScanTestDlg, CDialog)
	//{{AFX_MSG_MAP(CM3PlusScanTestDlg)
	ON_BN_CLICKED(IDC_BUT_SCAN, OnButScan)
	ON_BN_CLICKED(IDC_BUT_CANCEL, OnButCancel)
	ON_BN_CLICKED(IDC_BUT_OPTION, OnButOption)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BTN_DETAIL, OnBtnDetail)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CM3PlusScanTestDlg message handlers

BOOL CM3PlusScanTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	CenterWindow(GetDesktopWindow());	// center to the hpc screen

	CRect   lprect;
	GetClientRect(lprect);
	
	MoveWindow(0,-1,lprect.right,lprect.bottom+25);
	CM3PlusScanTestApp * app = (CM3PlusScanTestApp *)AfxGetApp();
	app->InitDlg->ShowWindow(SW_SHOW);
	MCP_ScanOpen(6);
	app->InitDlg->ShowWindow(SW_HIDE);


	ListView_SetExtendedListViewStyle(m_ctrl_listctrl_scandata.GetSafeHwnd(),LVS_EX_FULLROWSELECT);
	m_ctrl_listctrl_scandata.InsertColumn(0,L"BarCode Type",LVCFMT_LEFT,90);
	m_ctrl_listctrl_scandata.InsertColumn(1,L"BarCode Number",LVCFMT_LEFT,140);

	return TRUE;
}

BOOL CM3PlusScanTestDlg::MCP_ScanOpen(int PortNumber)
{
	BOOL	bResult = FALSE;
	BOOL	bRet = FALSE;
	int	ncount=0;
	
	for(int i=0;i < 3 ; i++)
	{
		bRet = KernelIoControl(IOCTL_HAL_SCAN_POWER_EN, NULL, NULL, NULL, NULL, NULL);		
		if(bRet)break;
		Sleep(100);		
	}

	bResult = KScan.Open(6,FALSE,CBR_9600,FALSE,NULL);
	if(!bResult)
	{		
		SetDlgItemText(IDC_STATIC_BARCODE,L"Scan Module open Failed");
		KScan.Close();		
		Sleep(100);	
		return FALSE;		
	}
	else
	{
		SetDlgItemText(IDC_STATIC_BARCODE,L"Scan Module opened");	
		
		return TRUE;		
	}	
	
	return TRUE;
}
void CM3PlusScanTestDlg::OnClose() 
{
	BOOL bResult = FALSE;
	
	bResult = KScan.Close();
	if(!bResult)
	{
		::MessageBox(NULL, L"Scan Close Error", NULL, MB_TOPMOST);
		Sleep(100);
		
	}

	for(int i=0;i < 3 ; i++)
	{
		bResult = KernelIoControl(IOCTL_HAL_SCAN_POWER_DIS, NULL, NULL, NULL, NULL, NULL);		
		if(bResult)break;
		Sleep(100);		
	}
		
	CDialog::OnClose();
}

DWORD KSCANAPI KScanReadCallBack(LPVOID pRead)
{
	CString  data = _T("SCAN DATA");
	CString	 strtype;
	char BarCodeName[128]={0,};
	unsigned long type= 0;
	CM3PlusScanTestDlg * lpCls = (CM3PlusScanTestDlg *)((PKSCANREAD)pRead)->pUserData;
	lpCls->SetDlgItemText(IDC_STATIC_BARCODE, data);
	data = ((PKSCANREAD)pRead)->out_Barcode;	
	type = ((PKSCANREAD)pRead)->out_Type;
	lpCls->BarCodeTypeCheck((unsigned char)type,strtype,data);
	lpCls->LoadResSound();
	return TRUE;

}

void CM3PlusScanTestDlg::MCP_ScanReadNB()
{
	CString		Str;
	BOOL		bResult;
	

	kRead.fnCallBack = KScanReadCallBack;
	kRead.pUserData = this;
	while(TRUE)
	{
		if(m_bSycnMode == FALSE)
		{
			bResult = KScan.ReadCancel();
			if(bResult)
			{
				m_bReading = FALSE;
			}
			else
			{
				SetDlgItemText(IDC_STATIC_BARCODE,L"ReadCancel Error");
			}
			break;
		}
		break;

	}	
	m_bReading = TRUE;
	bResult =	KScan.Read(&kRead);	

	if (!bResult) {
		
		SetDlgItemText(IDC_STATIC_BARCODE,L"Read Error");
		m_bReading = FALSE;
		return;
	}
	m_bReading = TRUE;
}

BOOL CM3PlusScanTestDlg::PreTranslateMessage(MSG* pMsg) 
{
	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_F22 )		
	{
			if(m_bKeyFlag == FALSE)
			{
				
				m_bKeyFlag = TRUE;			
				MCP_ScanReadNB();				
			}

			return TRUE;		
	}
	else if(pMsg->message == WM_KEYUP && pMsg->wParam == VK_F22)
	{				
			if(m_bKeyFlag == TRUE)
			{
				m_bKeyFlag = FALSE;
				
				if(m_bSycnMode == TRUE)
				{					
					KScan.ReadCancel();
					m_bReading = FALSE;						
				}				
			}
			
			return	TRUE;		
	}
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CM3PlusScanTestDlg::OnButScan() 
{	
	MCP_ScanReadNB();
}

void CM3PlusScanTestDlg::OnButCancel() 
{
	KScan.ReadCancel();	
}

void CM3PlusScanTestDlg::OnButOption() 
{
	COptionDlg   dlg;
	
	GetBarCodeType(&dlg);
//	GetScanOption(&dlg);
	
	if(dlg.DoModal() == IDOK)
	{
		SetBarCodeType(&dlg);
//		SetScanOption(&dlg);
	}	
}

void CM3PlusScanTestDlg::OnBtnDetail() 
{
	CDetailDlg dlg;

	GetScanOption(&dlg);
	
	if(dlg.DoModal() == IDOK)
	{
		SetScanOption(&dlg);
	}
}

void CM3PlusScanTestDlg::LoadResSound()
{
	HINSTANCE hInst = AfxGetInstanceHandle();
	PlaySound(MAKEINTRESOURCE(IDR_SCAN_WAVE), hInst, SND_RESOURCE|SND_ASYNC);		
}

void CM3PlusScanTestDlg::GetBarCodeType(COptionDlg *dlg)
{
	int nCheck = 0;
	nCheck = m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"VER");
	if( nCheck == -1 || nCheck != M3PLUSSCANVER)
	{
		SetDefaultReg();		
	}

//	dlg->m_nSyncMode	= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"SYNC");
	dlg->m_bUpca		= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCA");
	dlg->m_bUpce		= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCE");
	dlg->m_bUpce1		= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCE1");
	dlg->m_bEan8		= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"EAN8");
	dlg->m_bEan13		= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"EAN13");
	dlg->m_bBookLand_Ean= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"BOOKLAND_EAN");
	dlg->m_bCoupon		= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"COUPON");
	dlg->m_bCode128		= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE128");
	dlg->m_bUcc_ean128	= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UCC_EAN128");
	dlg->m_bIsbt_128	= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"ISBT_128");
	dlg->m_bCode39		= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE39");
	dlg->m_bTrioptic39	= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"TRIOPTIC39");
	dlg->m_bCode93		= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE93");
	dlg->m_bCode11		= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE11");
	dlg->m_bI2of5		= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"I2OF5");
	dlg->m_bDis2of5		= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"DIS2OF5");
	dlg->m_bCh2of5		= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CH2OF5");
	dlg->m_bCodabar		= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODABAR");
	dlg->m_bMsi_plessey = (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"MSI");
	dlg->m_bGs1			= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1");
	dlg->m_bGs1Limited	= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1_LIMITED");
	dlg->m_bGs1Expanded	= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1_EXPANDED");
}

void CM3PlusScanTestDlg::SetBarCodeType(COptionDlg *dlg)
{
	if((DWORD)dlg->m_bUpca != m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCA"))
	{
		KScan.SetBarCodeType(UPCA		,dlg->m_bUpca	);
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCA",dlg->m_bUpca);
		
	}
	if((DWORD)dlg->m_bUpce!= m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCE"))
	{
		KScan.SetBarCodeType(UPCE		,dlg->m_bUpce	);
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCE",dlg->m_bUpce);
		
	}
	if((DWORD)dlg->m_bUpce1!= m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCE1"))
	{
		KScan.SetBarCodeType(UPCE1		,dlg->m_bUpce1	);
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCE1",dlg->m_bUpce1);
		
	}
	if((DWORD)dlg->m_bEan8!= m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"EAN8"))
	{
		KScan.SetBarCodeType(EAN8		,dlg->m_bEan8	);
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"EAN8",dlg->m_bEan8);
		
	}
	if((DWORD)dlg->m_bEan13!= m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"EAN13"))
	{
		KScan.SetBarCodeType(EAN13		,dlg->m_bEan13	);
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"EAN13",dlg->m_bEan13);
		
	}
	if((DWORD)dlg->m_bBookLand_Ean!= m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"BOOKLAND_EAN"))
	{
		KScan.SetBarCodeType(BOOKLAND_EAN       ,dlg->m_bBookLand_Ean);
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"BOOKLAND_EAN",dlg->m_bBookLand_Ean);
		
	}
	if((DWORD)dlg->m_bCoupon!= m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"COUPON"))
	{
		KScan.SetBarCodeType(COUPON		,dlg->m_bCoupon	);
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"COUPON",dlg->m_bCoupon	);
		
	}
	if((DWORD)dlg->m_bCode128!= m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE128"))
	{
		KScan.SetBarCodeType(CODE128		,dlg->m_bCode128	);
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE128",dlg->m_bCode128);
		
	}
	if((DWORD)dlg->m_bIsbt_128!= m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS,L"ISBT_128" ))
	{
		KScan.SetBarCodeType(ISBT_128		,dlg->m_bIsbt_128);		
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"ISBT_128",dlg->m_bIsbt_128);
	}
	if((DWORD)dlg->m_bUcc_ean128!= m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UCC_EAN128"))
	{
		KScan.SetBarCodeType(UCC_EAN128		,dlg->m_bUcc_ean128);
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UCC_EAN128",dlg->m_bUcc_ean128);
		
	}
	if((DWORD)dlg->m_bCode39!= m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE39"))
	{
		KScan.SetBarCodeType(CODE39		,dlg->m_bCode39	);
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE39",dlg->m_bCode39);
		
	}
	if((DWORD)dlg->m_bTrioptic39!= m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"TRIOPTIC39"))
	{
		KScan.SetBarCodeType(TRIOPTIC39		,dlg->m_bTrioptic39);
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"TRIOPTIC39",dlg->m_bTrioptic39);
		
	}
	if((DWORD)dlg->m_bCode93!= m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE93"))
	{
		KScan.SetBarCodeType(CODE93		,dlg->m_bCode93	);
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE93",dlg->m_bCode93);
		
	}
	if((DWORD)dlg->m_bI2of5!= m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"I2OF5"))
	{
		KScan.SetBarCodeType(I2OF5		,dlg->m_bI2of5	);
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"I2OF5",dlg->m_bI2of5);
		
	}
	if((DWORD)dlg->m_bCode11!= m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE11"))
	{
		KScan.SetBarCodeType(CODE11	,dlg->m_bCode11);	
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE11",dlg->m_bCode11);
	}
	if((DWORD)dlg->m_bDis2of5!= m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"DIS2OF5"))
	{
		KScan.SetBarCodeType(DIS2OF5		,dlg->m_bDis2of5	);
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"DIS2OF5",dlg->m_bDis2of5);
		
	}
	if((DWORD)dlg->m_bCh2of5 != m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CH2OF5"))
	{
		KScan.SetCh2of5_Gs1_Enable(CH2OF5, dlg->m_bCh2of5	);
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CH2OF5",dlg->m_bCh2of5);
		
	}
	if((DWORD)dlg->m_bCodabar!= m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODABAR"))
	{
		KScan.SetBarCodeType(CODABAR		,dlg->m_bCodabar	);
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODABAR",dlg->m_bCodabar);
		
	}
	if((DWORD)dlg->m_bMsi_plessey!= m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"MSI"))
	{
		KScan.SetBarCodeType(MSI	,dlg->m_bMsi_plessey);	
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"MSI",dlg->m_bMsi_plessey);
	}
	if((DWORD)dlg->m_bGs1!= m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1"))
	{
		KScan.SetCh2of5_Gs1_Enable(GS1	,dlg->m_bGs1);	
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1",dlg->m_bGs1);
	}
	if((DWORD)dlg->m_bGs1Limited!= m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1_LIMITED"))
	{
		KScan.SetCh2of5_Gs1_Enable(GS1_LIMITED	,dlg->m_bGs1Limited);	
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1_LIMITED",dlg->m_bGs1Limited);
	}
	if((DWORD)dlg->m_bGs1Expanded != m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1_EXPANDED"))
	{
		KScan.SetCh2of5_Gs1_Enable(GS1_EXPANDED	,dlg->m_bGs1Expanded);		
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1_EXPANDED",dlg->m_bGs1Expanded);
	}

}

void CM3PlusScanTestDlg::GetScanOption(CDetailDlg *dlg)
{
	int nCheck = 0;
	nCheck = m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"VER");
	if( nCheck == -1 || nCheck != M3PLUSSCANVER)
	{
		SetDefaultReg();		
	}

	// SyncMode
	dlg->m_nSyncMode	= (BOOL)m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"SYNC");

	unsigned long option = KScan.GetScanOption();
	
	// Security Level
	if(option & LINEAR_CODE_TYPE_SECURITY_LEVELS_01)
	{
		dlg->m_nSecurityLevel = 0;
	}
	if(option & LINEAR_CODE_TYPE_SECURITY_LEVELS_02)
	{
		dlg->m_nSecurityLevel = 1;
	}
	if(option & LINEAR_CODE_TYPE_SECURITY_LEVELS_03)
	{
		dlg->m_nSecurityLevel = 2;
	}
	if(option & LINEAR_CODE_TYPE_SECURITY_LEVELS_04)
	{
		dlg->m_nSecurityLevel = 3;
	}
	
	// TimeOut
	if(option & LASER_ON_TIME_01)
	{
		dlg->m_nTimeOut = 0;
	}
	if(option & LASER_ON_TIME_02)
	{
		dlg->m_nTimeOut = 1;
	}
	if(option & LASER_ON_TIME_03)
	{
		dlg->m_nTimeOut = 2;
	}
	if(option & LASER_ON_TIME_04)
	{
		dlg->m_nTimeOut = 3;
	}
	if(option & LASER_ON_TIME_05)
	{
		dlg->m_nTimeOut = 4;
	}
	if(option & LASER_ON_TIME_06)
	{
		dlg->m_nTimeOut = 5;
	}
	if(option & LASER_ON_TIME_07)
	{
		dlg->m_nTimeOut = 6;
	}
	if(option & LASER_ON_TIME_08)
	{
		dlg->m_nTimeOut = 7;
	}
	if(option & LASER_ON_TIME_09)
	{
		dlg->m_nTimeOut = 8;
	}
	if(option & LASER_ON_TIME_10)
	{
		dlg->m_nTimeOut = 9;
	}
	
	// PowerMode
	if(option & POWER_MODE_CONTINUOUS)
	{
		dlg->m_bPowerMode = FALSE;
	}
	else
	{
		dlg->m_bPowerMode = TRUE;
	}

	// Transmit CodeID
	dlg->m_nTransCodeID = (DWORD)KScan.GetTransmitCodeID();
}

void CM3PlusScanTestDlg::SetScanOption(CDetailDlg *dlg)
{
	UpdateData(TRUE);

	// SyncMode
	if((DWORD)dlg->m_nSyncMode !=  m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"SYNC"))
	{
		m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"SYNC", dlg->m_nSyncMode);
		m_bSycnMode = dlg->m_nSyncMode;
	}
	
	unsigned long option = 0;

	// Security Level
	switch(dlg->m_nSecurityLevel)
	{
	case 0:
		option |= LINEAR_CODE_TYPE_SECURITY_LEVELS_01;
		break;
	case 1:
		option |= LINEAR_CODE_TYPE_SECURITY_LEVELS_02;
		break;
	case 2:
		option |= LINEAR_CODE_TYPE_SECURITY_LEVELS_03;
		break;
	case 3:
		option |= LINEAR_CODE_TYPE_SECURITY_LEVELS_04;
		break;
	}

	// TimeOut
	switch(dlg->m_nTimeOut)
	{
		case 0:
			option |= LASER_ON_TIME_01;
			break;
		case 1:
			option |= LASER_ON_TIME_02;
			break;
		case 2:
			option |= LASER_ON_TIME_03;
			break;
		case 3:
			option |= LASER_ON_TIME_04;
			break;
		case 4:
			option |= LASER_ON_TIME_05;
			break;
		case 5:
			option |= LASER_ON_TIME_06;
			break;
		case 6:
			option |= LASER_ON_TIME_07;
			break;
		case 7:
			option |= LASER_ON_TIME_08;
			break;
		case 8:
			option |= LASER_ON_TIME_09;
			break;
		case 9:
			option |= LASER_ON_TIME_10;
			break;
	}

	// Power MOde
	if(dlg->m_bPowerMode == FALSE)
	{
		option |= POWER_MODE_CONTINUOUS;
	}else{
		option |= POWER_MODE_LOW;
	}

	// Transmit Code ID
	KScan.SetTransmitCodeID((unsigned char)dlg->m_nTransCodeID);

	KScan.SetScanOption(option);
}
	

void CM3PlusScanTestDlg::BarCodeTypeCheck(unsigned char BarCodeType, CString BarCodeTypeName,CString BarCodeValue)
{
	switch(BarCodeType)
	{
		case OUT_TYPE_Not_Applicable:
			BarCodeTypeName = str_Not_Applicable;
			break;
		case OUT_TYPE_UPCA:
			BarCodeTypeName = str_UPCA;
			break;
		case OUT_TYPE_UPCE:
			BarCodeTypeName = str_UPCE;
			break;
		case OUT_TYPE_UPCE1:
			BarCodeTypeName = str_UPCE1;
			break;
		case OUT_TYPE_EAN8:
			BarCodeTypeName = str_EAN8;
			break;
		case OUT_TYPE_EAN13:
			BarCodeTypeName = str_EAN13;
			break;
		case OUT_TYPE_BOOKLAND:
			BarCodeTypeName = str_BOOKLANDEAN;
			break;
		case OUT_TYPE_COUPON_CODE:
			BarCodeTypeName = str_COUPONCODE;
			break;
		case OUT_TYPE_UPC_A_with_2_Supps:
			BarCodeTypeName = str_UPC_A_with_2_Supps;
			break;
		case OUT_TYPE_UPC_A_with_5_Supps:
			BarCodeTypeName = str_UPC_A_with_5_Supps;
			break;
		case OUT_TYPE_UPC_E_with_2_Supps:
			BarCodeTypeName = str_UPC_E_with_2_Supps;
			break;
		case OUT_TYPE_UPC_E_with_5_Supps:
			BarCodeTypeName = str_UPC_E_with_5_Supps;
			break;
		case OUT_TYPE_UPC_E1_with_2_Supps:
			BarCodeTypeName = str_UPC_E1_with_2_Supps;
			break;
		case OUT_TYPE_UPC_E1_with_5_Supps:
			BarCodeTypeName = str_UPC_E1_with_5_Supps;
			break;
		case OUT_TYPE_EAN_8_with_2_Supps:
			BarCodeTypeName = str_EAN_8_with_2_Supps;
			break;
		case OUT_TYPE_EAN_8_with_5_Supps:
			BarCodeTypeName = str_EAN_8_with_5_Supps;
			break;
		case OUT_TYPE_EAN_13_with_2_Supps:
			BarCodeTypeName = str_EAN_13_with_2_Supps;
			break;
		case OUT_TYPE_EAN_13_with_5_Supps:
			BarCodeTypeName = str_EAN_13_with_5_Supps;
			break;
		case OUT_TYPE_CODE128:
			BarCodeTypeName = str_CODE128;
			break;
		case OUT_TYPE_UCCEAN128:
			BarCodeTypeName = str_UCCEAN128;
			break;
		case OUT_TYPE_ISBT128:
			BarCodeTypeName = str_ISBT128;
			break;
		case OUT_TYPE_CODE39:
			BarCodeTypeName = str_CODE39;
			break;
		case OUT_TYPE_TRIOPTICCODE39:
			BarCodeTypeName = str_TRIOPTICCODE39;
			break;
		case OUT_TYPE_CODE32:
			BarCodeTypeName = str_CODE32;
			break;
		case 0x13:		// Code39 Full ASCII
			BarCodeTypeName = str_CODE39;
			break;
		case OUT_TYPE_CODE93:
			BarCodeTypeName = str_CODE93;
			break;
		case OUT_TYPE_CODE11:
			BarCodeTypeName = str_Code11;
			break;
		case OUT_TYPE_INTERLEAVED2OF5:
			BarCodeTypeName = str_INTERLEAVED2OF5;
			break;
		case OUT_TYPE_INTERLEAVED2OF5_1:
			BarCodeTypeName = str_INTERLEAVED2OF5;
			break;
		case OUT_TYPE_DISCRETE2OF5:
			BarCodeTypeName = str_DISCRETE2OF5;
			break;
		case OUT_TYPE_CHINESE2OF5:
			BarCodeTypeName = str_CHINESE2of5;
			break;
		case OUT_TYPE_CODABAR:
			BarCodeTypeName = str_CODABAR;
			break;
		case OUT_TYPE_MSI:
			BarCodeTypeName = str_MSI;
			break;
		case OUT_TYPE_GS1:
			BarCodeTypeName = str_GS1;
			break;
		case OUT_TYPE_GS1_LIMITED:
			BarCodeTypeName = str_GS1_LIMITED;
			break;
		case OUT_TYPE_GS1_EXPANDED:
			BarCodeTypeName = str_GS1_EXPANDED;
			break;		
		default:
			BarCodeTypeName = L"Unknown Barcode Type";
			break;	

		

	}
	m_ctrl_listctrl_scandata.InsertItem(0, BarCodeTypeName,0);
	m_ctrl_listctrl_scandata.SetItemText(0, 1, BarCodeValue);
	SetDlgItemText(IDC_STATIC_BARCODE,L"SCAN_BARCODE");
	
}

void CM3PlusScanTestDlg::SetDefaultReg()
{
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"VER", M3PLUSSCANVER);	
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"SYNC", 1);
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCA",(DWORD)KScan.GetBarCodeType(UPCA));
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCE",(DWORD)KScan.GetBarCodeType(UPCE));
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UPCE1",(DWORD)KScan.GetBarCodeType(UPCE1));
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"EAN8",(DWORD)KScan.GetBarCodeType(EAN8));
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"EAN13",(DWORD)KScan.GetBarCodeType(EAN13));
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"BOOKLAND_EAN",(DWORD)KScan.GetBarCodeType(BOOKLAND_EAN));
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"COUPON",(DWORD)KScan.GetBarCodeType(COUPON));
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE128",(DWORD)KScan.GetBarCodeType(CODE128));
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UCC_EAN128",(DWORD)KScan.GetBarCodeType(UCC_EAN128));
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"ISBT_128",(DWORD)KScan.GetBarCodeType(ISBT_128));
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE39",(DWORD)KScan.GetBarCodeType(CODE39));
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"TRIOPTIC39",(DWORD)KScan.GetBarCodeType(TRIOPTIC39));
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE93",(DWORD)KScan.GetBarCodeType(CODE93));
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE11",(DWORD)KScan.GetBarCodeType(CODE11));
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"I2OF5",(DWORD)KScan.GetBarCodeType(I2OF5));
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"DIS2OF5",(DWORD)KScan.GetBarCodeType(DIS2OF5));
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CH2OF5",(DWORD)KScan.GetBarCodeType(CH2OF5));
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODABAR",(DWORD)KScan.GetBarCodeType(CODABAR));
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"MSI",(DWORD)KScan.GetBarCodeType(MSI));
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1",(DWORD)KScan.GetBarCodeType(GS1));
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1_LIMITED",(DWORD)KScan.GetBarCodeType(GS1_LIMITED));
	m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1_EXPANDED",(DWORD)KScan.GetBarCodeType(GS1_EXPANDED));
}

