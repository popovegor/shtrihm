// M3PlusScanTest.h : main header file for the M3PLUSSCANTEST application
//

#if !defined(AFX_M3PLUSSCANTEST_H__382E00F8_DB2B_433D_816A_380B1BA31B7D__INCLUDED_)
#define AFX_M3PLUSSCANTEST_H__382E00F8_DB2B_433D_816A_380B1BA31B7D__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "MessageDlg.h"
/////////////////////////////////////////////////////////////////////////////
// CM3PlusScanTestApp:
// See M3PlusScanTest.cpp for the implementation of this class
//

class CM3PlusScanTestApp : public CWinApp
{
public:
	CM3PlusScanTestApp();
public:
	CMessageDlg    *InitDlg;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CM3PlusScanTestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CM3PlusScanTestApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_M3PLUSSCANTEST_H__382E00F8_DB2B_433D_816A_380B1BA31B7D__INCLUDED_)
