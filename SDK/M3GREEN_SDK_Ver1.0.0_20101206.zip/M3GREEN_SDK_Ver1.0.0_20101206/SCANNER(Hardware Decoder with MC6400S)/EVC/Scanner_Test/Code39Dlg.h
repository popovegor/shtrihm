#if !defined(AFX_CODE39DLG_H__EF0A292C_FAF0_4039_AF6B_5C61D7FB7D4F__INCLUDED_)
#define AFX_CODE39DLG_H__EF0A292C_FAF0_4039_AF6B_5C61D7FB7D4F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Code39Dlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCode39Dlg dialog

class CCode39Dlg : public CDialog
{
// Construction
public:
	void SetOption();
	void GetOption();
	CCode39Dlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCode39Dlg)
	enum { IDD = IDD_CODE39_DLG };
	BOOL	m_bCode32Pre;
	BOOL	m_bEnableCode39;
	BOOL	m_bCode39Cdv;
	BOOL	m_bConvertCode39to32;
	BOOL	m_bCode39Xcd;
	BOOL	m_bFullASCII;
	BOOL	m_bEnableTrioptic39;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCode39Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCode39Dlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CODE39DLG_H__EF0A292C_FAF0_4039_AF6B_5C61D7FB7D4F__INCLUDED_)
