// Code128Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3PlusScanTest.h"
#include "Code128Dlg.h"
#include "M3PlusScanTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCode128Dlg dialog


CCode128Dlg::CCode128Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCode128Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCode128Dlg)
	m_bEnableCode128 = FALSE;
	m_bEnableIsbt128 = FALSE;
	m_bEnableUccean128 = FALSE;
	//}}AFX_DATA_INIT
}


void CCode128Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCode128Dlg)
	DDX_Check(pDX, IDC_CHECK_CODE128, m_bEnableCode128);
	DDX_Check(pDX, IDC_CHECK_ISBT128, m_bEnableIsbt128);
	DDX_Check(pDX, IDC_CHECK_UCCEAN128, m_bEnableUccean128);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCode128Dlg, CDialog)
	//{{AFX_MSG_MAP(CCode128Dlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCode128Dlg message handlers

BOOL CCode128Dlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);

	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCode128Dlg::GetOption()
{
	CM3PlusScanTestDlg* dlg = (CM3PlusScanTestDlg*)AfxGetMainWnd();
	int nCheck = 0;
	nCheck = dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"VER");
	if( nCheck == -1 || nCheck != M3PLUSSCANVER)
	{
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE128",(DWORD)dlg->KScan.GetBarCodeType(CODE128));
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UCC_EAN128",(DWORD)dlg->KScan.GetBarCodeType(UCC_EAN128));
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"ISBT_128",(DWORD)dlg->KScan.GetBarCodeType(ISBT_128));
	}

	m_bEnableCode128	= (BOOL)dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE128");
	m_bEnableIsbt128	= (BOOL)dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UCC_EAN128");
	m_bEnableUccean128	= (BOOL)dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"ISBT_128");

	UpdateData(FALSE);

}

void CCode128Dlg::SetOption()
{
	UpdateData(TRUE);
	CM3PlusScanTestDlg* dlg = (CM3PlusScanTestDlg*)AfxGetMainWnd();

	if((DWORD)m_bEnableCode128 != dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE128"))
	{
		dlg->KScan.SetBarCodeType(CODE128, m_bEnableCode128);
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE128", m_bEnableCode128);
		
	}
	if((DWORD)m_bEnableIsbt128 != dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS,L"ISBT_128" ))
	{
		dlg->KScan.SetBarCodeType(ISBT_128, m_bEnableIsbt128);		
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"ISBT_128", m_bEnableIsbt128);
	}
	if((DWORD)m_bEnableUccean128 != dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UCC_EAN128"))
	{
		dlg->KScan.SetBarCodeType(UCC_EAN128, m_bEnableUccean128);
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"UCC_EAN128", m_bEnableUccean128);		
	}

}

void CCode128Dlg::OnOK() 
{
	SetOption();
	
	CDialog::OnOK();
}
