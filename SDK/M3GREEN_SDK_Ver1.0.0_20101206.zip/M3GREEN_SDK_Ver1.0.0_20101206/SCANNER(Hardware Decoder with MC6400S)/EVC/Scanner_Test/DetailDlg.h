#if !defined(AFX_DETAILDLG_H__CF217CA4_6EE4_46C7_955E_4D2E0D511CE3__INCLUDED_)
#define AFX_DETAILDLG_H__CF217CA4_6EE4_46C7_955E_4D2E0D511CE3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DetailDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDetailDlg dialog

class CDetailDlg : public CDialog
{
// Construction
public:
	int m_nSecurityLevel;
	int m_nTimeOut;

	CDetailDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDetailDlg)
	enum { IDD = IDD_DETAIL_DLG };
	CComboBox	m_ctrlComboTimeOut;
	CComboBox	m_ctrlComboSecurityLevel;
	BOOL	m_bPowerMode;
	int		m_nSyncMode;
	int		m_nTransCodeID;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDetailDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDetailDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnBtnCh2of5();
	afx_msg void OnBtnCodabar();
	afx_msg void OnBtnCode11();
	afx_msg void OnBtnCode128();
	afx_msg void OnBtnCode39();
	afx_msg void OnBtnCode93();
	afx_msg void OnBtnDis2of5();
	afx_msg void OnBtnGs1();
	afx_msg void OnBtnI2of5();
	afx_msg void OnBtnMsi();
	afx_msg void OnBtnUpcean();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DETAILDLG_H__CF217CA4_6EE4_46C7_955E_4D2E0D511CE3__INCLUDED_)
