// Code39Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3PlusScanTest.h"
#include "Code39Dlg.h"
#include "M3PlusScanTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCode39Dlg dialog


CCode39Dlg::CCode39Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCode39Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCode39Dlg)
	m_bCode32Pre = FALSE;
	m_bEnableCode39 = FALSE;
	m_bCode39Cdv = FALSE;
	m_bConvertCode39to32 = FALSE;
	m_bCode39Xcd = FALSE;
	m_bFullASCII = FALSE;
	m_bEnableTrioptic39 = FALSE;
	//}}AFX_DATA_INIT
}


void CCode39Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCode39Dlg)
	DDX_Check(pDX, IDC_CHECK_CODE32_PREFIX, m_bCode32Pre);
	DDX_Check(pDX, IDC_CHECK_CODE39, m_bEnableCode39);
	DDX_Check(pDX, IDC_CHECK_CODE39_CDV, m_bCode39Cdv);
	DDX_Check(pDX, IDC_CHECK_CODE39_TO_CODE32, m_bConvertCode39to32);
	DDX_Check(pDX, IDC_CHECK_CODE39_XCD, m_bCode39Xcd);
	DDX_Check(pDX, IDC_CHECK_FULLASCII, m_bFullASCII);
	DDX_Check(pDX, IDC_CHECK_TRIOPTIC39, m_bEnableTrioptic39);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCode39Dlg, CDialog)
	//{{AFX_MSG_MAP(CCode39Dlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCode39Dlg message handlers

BOOL CCode39Dlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);

	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCode39Dlg::GetOption()
{
	CM3PlusScanTestDlg* dlg = (CM3PlusScanTestDlg*)AfxGetMainWnd();

	// Enable
	int nCheck = 0;
	nCheck = dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"VER");
	if( nCheck == -1 || nCheck != M3PLUSSCANVER)
	{
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE39",(DWORD)dlg->KScan.GetBarCodeType(CODE39));
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"TRIOPTIC39",(DWORD)dlg->KScan.GetBarCodeType(TRIOPTIC39));
	}

	m_bEnableCode39		= (BOOL)dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE39");
	m_bEnableTrioptic39	= (BOOL)dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"TRIOPTIC39");

	// CheckDigit
	m_bCode39Xcd	= (BOOL)dlg->KScan.GetTransmitCheckDigit(TRANCODE39CD);
	m_bCode39Cdv	= dlg->KScan.GetCode39CheckDigitVerification();

	// Option
	m_bConvertCode39to32	= dlg->KScan.GetBarCodeConvert(Code39to32);
	m_bCode32Pre			= dlg->KScan.GetCode32PrefixEnabled();
	m_bFullASCII			= dlg->KScan.GetCode39FullAscii();

	UpdateData(FALSE);
}

void CCode39Dlg::SetOption()
{
	UpdateData(TRUE);
	CM3PlusScanTestDlg* dlg = (CM3PlusScanTestDlg*)AfxGetMainWnd();

	// Enable
	if((DWORD)m_bEnableCode39 != dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE39"))
	{
		dlg->KScan.SetBarCodeType(CODE39, m_bEnableCode39);
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODE39", m_bEnableCode39);
		
	}
	if((DWORD)m_bEnableTrioptic39 != dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"TRIOPTIC39"))
	{
		dlg->KScan.SetBarCodeType(TRIOPTIC39, m_bEnableTrioptic39);
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"TRIOPTIC39", m_bEnableTrioptic39);	
	}

	// CheckDigit
	dlg->KScan.SetTransmitCheckDigit(TRANCODE39CD, (unsigned char)m_bCode39Xcd);
	dlg->KScan.SetCode39CheckDigitVerification(m_bCode39Cdv);
	
	// Option
	dlg->KScan.SetBarCodeConvert(Code39to32, m_bConvertCode39to32);
	dlg->KScan.SetCode32PrefixEnabled(m_bCode32Pre);
	dlg->KScan.SetCode39FullAscii(m_bFullASCII);
}

void CCode39Dlg::OnOK() 
{
	SetOption();
	
	CDialog::OnOK();
}
