#if !defined(AFX_DIS2OF5DLG_H__CD0A6917_4E96_4217_A426_AE83C9DAD288__INCLUDED_)
#define AFX_DIS2OF5DLG_H__CD0A6917_4E96_4217_A426_AE83C9DAD288__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Dis2of5Dlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDis2of5Dlg dialog

class CDis2of5Dlg : public CDialog
{
// Construction
public:
	void SetOption();
	void GetOption();
	CDis2of5Dlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDis2of5Dlg)
	enum { IDD = IDD_DIS2OF5_DLG };
	BOOL	m_bEnableDis2of5;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDis2of5Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDis2of5Dlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIS2OF5DLG_H__CD0A6917_4E96_4217_A426_AE83C9DAD288__INCLUDED_)
