// I2of5Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3PlusScanTest.h"
#include "I2of5Dlg.h"
#include "M3PlusScanTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CI2of5Dlg dialog


CI2of5Dlg::CI2of5Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CI2of5Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CI2of5Dlg)
	m_bEnableI2of5 = FALSE;
	m_bI2of5Xcd = FALSE;
	m_nI2of5Cdv = -1;
	//}}AFX_DATA_INIT
}


void CI2of5Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CI2of5Dlg)
	DDX_Check(pDX, IDC_CHECK_I2OF5, m_bEnableI2of5);
	DDX_Check(pDX, IDC_CHECK_I2OF5_XCD, m_bI2of5Xcd);
	DDX_Radio(pDX, IDC_RADIO_DIS, m_nI2of5Cdv);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CI2of5Dlg, CDialog)
	//{{AFX_MSG_MAP(CI2of5Dlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CI2of5Dlg message handlers

BOOL CI2of5Dlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);

	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CI2of5Dlg::GetOption()
{
	CM3PlusScanTestDlg* dlg = (CM3PlusScanTestDlg*)AfxGetMainWnd();

	// Enable
	int nCheck = 0;
	nCheck = dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"VER");
	if( nCheck == -1 || nCheck != M3PLUSSCANVER)
	{
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"I2OF5",(DWORD)dlg->KScan.GetBarCodeType(I2OF5));
	}

	m_bEnableI2of5		= (BOOL)dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"I2OF5");

	// CheckDigit
	m_bI2of5Xcd	= (BOOL)dlg->KScan.GetTransmitCheckDigit(TRANI2OF5CD);
	m_nI2of5Cdv = (DWORD)dlg->KScan.GetI2of5CheckDigitVerification();

	UpdateData(FALSE);
}

void CI2of5Dlg::SetOption()
{
	UpdateData(TRUE);
	
	CM3PlusScanTestDlg* dlg = (CM3PlusScanTestDlg*)AfxGetMainWnd();

	// Enable
	if((DWORD)m_bEnableI2of5 != dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"I2OF5"))
	{
		dlg->KScan.SetBarCodeType(I2OF5, m_bEnableI2of5);
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"I2OF5", m_bEnableI2of5);		
	}

	// CheckDigit
	dlg->KScan.SetTransmitCheckDigit(TRANI2OF5CD, (unsigned char)m_bI2of5Xcd);
	dlg->KScan.SetI2of5CheckDigitVerification((unsigned char)m_nI2of5Cdv);
}

void CI2of5Dlg::OnOK() 
{
	SetOption();
	
	CDialog::OnOK();
}
