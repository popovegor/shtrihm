#if !defined(AFX_I2OF5DLG_H__38B9676E_C4D2_4012_A580_2B392776AE67__INCLUDED_)
#define AFX_I2OF5DLG_H__38B9676E_C4D2_4012_A580_2B392776AE67__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// I2of5Dlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CI2of5Dlg dialog

class CI2of5Dlg : public CDialog
{
// Construction
public:
	void SetOption();
	void GetOption();
	CI2of5Dlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CI2of5Dlg)
	enum { IDD = IDD_I2OF5_DLG };
	BOOL	m_bEnableI2of5;
	BOOL	m_bConvertI2of5toEan13;
	BOOL	m_bI2of5Xcd;
	int		m_nI2of5Cdv;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CI2of5Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CI2of5Dlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_I2OF5DLG_H__38B9676E_C4D2_4012_A580_2B392776AE67__INCLUDED_)
