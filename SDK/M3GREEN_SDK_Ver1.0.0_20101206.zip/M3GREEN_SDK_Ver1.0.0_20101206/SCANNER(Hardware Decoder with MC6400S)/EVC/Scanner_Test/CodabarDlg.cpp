// CodabarDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3PlusScanTest.h"
#include "CodabarDlg.h"
#include "M3PlusScanTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCodabarDlg dialog


CCodabarDlg::CCodabarDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCodabarDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCodabarDlg)
	m_bEnableCodabar = FALSE;
	m_bCodabaXss = FALSE;
	//}}AFX_DATA_INIT
}


void CCodabarDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCodabarDlg)
	DDX_Check(pDX, IDC_CHECK_CODABAR, m_bEnableCodabar);
	DDX_Check(pDX, IDC_CHECK_CODABAR_XSS, m_bCodabaXss);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCodabarDlg, CDialog)
	//{{AFX_MSG_MAP(CCodabarDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCodabarDlg message handlers

BOOL CCodabarDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);

	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCodabarDlg::GetOption()
{
	CM3PlusScanTestDlg* dlg = (CM3PlusScanTestDlg*)AfxGetMainWnd();

	// Enable
	int nCheck = 0;
	nCheck = dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"VER");
	if( nCheck == -1 || nCheck != M3PLUSSCANVER)
	{
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODABAR",(DWORD)dlg->KScan.GetBarCodeType(CODABAR));
	}

	m_bEnableCodabar	= (BOOL)dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODABAR");

	// Start-Stop Bit
	m_bCodabaXss = dlg->KScan.GetCodabarNOTISEditing();

	UpdateData(FALSE);
}

void CCodabarDlg::SetOption()
{
	UpdateData(TRUE);
	
	CM3PlusScanTestDlg* dlg = (CM3PlusScanTestDlg*)AfxGetMainWnd();

	// Enable
	if((DWORD)m_bEnableCodabar != dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODABAR"))
	{
		dlg->KScan.SetBarCodeType(CODABAR, m_bEnableCodabar);
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"CODABAR", m_bEnableCodabar);		
	}

	// Start-Stop Bit
	dlg->KScan.SetCodabarNOTISEditing(m_bCodabaXss);	
}

void CCodabarDlg::OnOK() 
{
	SetOption();
	
	CDialog::OnOK();
}
