// Option.cpp : implementation file
//

#include "stdafx.h"
#include "M3PlusScanTest.h"
#include "OptionDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COption dialog


COptionDlg::COptionDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COptionDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(COption)

	// BarCode 22��
	m_bUpca			= FALSE;
	m_bUpce			= FALSE;
	m_bUpce1		= FALSE;
	m_bEan8			= FALSE;
	m_bEan13		= FALSE;
	m_bBookLand_Ean = FALSE;
	m_bCoupon		= FALSE;
	m_bCode128		= FALSE;
	m_bUcc_ean128	= FALSE;
	m_bIsbt_128		= FALSE;
	m_bCode39		= FALSE;
	m_bTrioptic39	= FALSE;
	m_bCode93		= FALSE;
	m_bCode11		= FALSE;
	m_bI2of5		= FALSE;
	m_bDis2of5		= FALSE;
	m_bCh2of5		= FALSE;
	m_bCodabar		= FALSE;	
	m_bMsi_plessey	= FALSE;
	m_bGs1			= FALSE;
	m_bGs1Expanded	= FALSE;
	m_bGs1Limited	= FALSE;	
	m_bALL			= FALSE;

	//}}AFX_DATA_INIT
}


void COptionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COption)

	DDX_Check(pDX, IDC_CHECK_BOOKLAND_EAN, m_bBookLand_Ean);
	DDX_Check(pDX, IDC_CHECK_CODABAR, m_bCodabar);
	DDX_Check(pDX, IDC_CHECK_CODE128, m_bCode128);
	DDX_Check(pDX, IDC_CHECK_CODE39, m_bCode39);
	DDX_Check(pDX, IDC_CHECK_CODE93, m_bCode93);
	DDX_Check(pDX, IDC_CHECK_COUPON, m_bCoupon);
	DDX_Check(pDX, IDC_CHECK_DIS2OF5, m_bDis2of5);
	DDX_Check(pDX, IDC_CHECK_EAN13, m_bEan13);
	DDX_Check(pDX, IDC_CHECK_EAN8, m_bEan8);
	DDX_Check(pDX, IDC_CHECK_I2OF5, m_bI2of5);
	DDX_Check(pDX, IDC_CHECK_MSI_PLESSEY, m_bMsi_plessey);
	DDX_Check(pDX, IDC_CHECK_TRIOPTIC39, m_bTrioptic39);
	DDX_Check(pDX, IDC_CHECK_UCC_EAN128, m_bUcc_ean128);
	DDX_Check(pDX, IDC_CHECK_UPCA, m_bUpca);
	DDX_Check(pDX, IDC_CHECK_UPCE, m_bUpce);
	DDX_Check(pDX, IDC_CHECK_UPCE1, m_bUpce1);
	DDX_Check(pDX, IDC_CHECK1_ISBT_128, m_bIsbt_128);	
	DDX_Check(pDX, IDC_CHECK_ALL, m_bALL);
	DDX_Check(pDX, IDC_CHECK_CODE11, m_bCode11);
	DDX_Check(pDX, IDC_CHECK_CH2OF5, m_bCh2of5);
	DDX_Check(pDX, IDC_CHECK_GS1, m_bGs1);
	DDX_Check(pDX, IDC_CHECK_GS1_EXPANDED, m_bGs1Expanded);
	DDX_Check(pDX, IDC_CHECK_GS1_LIMITED, m_bGs1Limited);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COptionDlg, CDialog)
	//{{AFX_MSG_MAP(COption)
	ON_BN_CLICKED(IDC_CHECK_ALL, OnCheckAll)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COption message handlers

void COptionDlg::OnCheckAll() 
{
	SetTimer(9000,100,NULL);
	UpdateData();
	if(m_bALL == TRUE)
	{
		m_bUpca			= TRUE;
		m_bUpce			= TRUE;
		m_bUpce1		= TRUE;
		m_bEan8			= TRUE;
		m_bEan13		= TRUE;
		m_bBookLand_Ean = TRUE;
		m_bCoupon		= TRUE;
		m_bCode128		= TRUE;
		m_bUcc_ean128	= TRUE;
		m_bIsbt_128		= TRUE;
		m_bCode39		= TRUE;
		m_bTrioptic39	= TRUE;
		m_bCode93		= TRUE;
		m_bCode11		= TRUE;
		m_bI2of5		= TRUE;
		m_bDis2of5		= TRUE;
		m_bCh2of5		= TRUE;
		m_bCodabar		= TRUE;	
		m_bMsi_plessey	= TRUE;
		m_bGs1			= TRUE;
		m_bGs1Expanded	= TRUE;
		m_bGs1Limited	= TRUE;	
		m_bALL			= TRUE;		
	}
	else
	{
		m_bUpca			= FALSE;
		m_bUpce			= FALSE;
		m_bUpce1		= FALSE;
		m_bEan8			= FALSE;
		m_bEan13		= FALSE;
		m_bBookLand_Ean = FALSE;
		m_bCoupon		= FALSE;
		m_bCode128		= FALSE;
		m_bUcc_ean128	= FALSE;
		m_bIsbt_128		= FALSE;
		m_bCode39		= FALSE;
		m_bTrioptic39	= FALSE;
		m_bCode93		= FALSE;
		m_bCode11		= FALSE;
		m_bI2of5		= FALSE;
		m_bDis2of5		= FALSE;
		m_bCh2of5		= FALSE;
		m_bCodabar		= FALSE;	
		m_bMsi_plessey	= FALSE;
		m_bGs1			= FALSE;
		m_bGs1Expanded	= FALSE;
		m_bGs1Limited	= FALSE;	
		m_bALL			= FALSE;		
	}
	
}

void COptionDlg::OnTimer(UINT nIDEvent) 
{
	switch(nIDEvent)
	{
	case 9000:
		UpdateData(FALSE);
		KillTimer(9000);
		break;

	}
	CDialog::OnTimer(nIDEvent);
}

BOOL COptionDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	CRect   lprect;
	GetClientRect(lprect);	
	MoveWindow(0,-1,lprect.right,lprect.bottom+25);	
	return TRUE;  
	              
}

