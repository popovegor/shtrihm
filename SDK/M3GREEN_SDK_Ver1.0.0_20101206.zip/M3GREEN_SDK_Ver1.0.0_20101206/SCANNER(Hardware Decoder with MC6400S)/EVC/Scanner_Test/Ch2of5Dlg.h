#if !defined(AFX_CH2OF5DLG_H__936A0DD1_B132_496E_ACE5_8ACCF00D4DBB__INCLUDED_)
#define AFX_CH2OF5DLG_H__936A0DD1_B132_496E_ACE5_8ACCF00D4DBB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Ch2of5Dlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCh2of5Dlg dialog

class CCh2of5Dlg : public CDialog
{
// Construction
public:
	void SetOption();
	void GetOption();
	CCh2of5Dlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCh2of5Dlg)
	enum { IDD = IDD_CH2OF5_DLG };
	BOOL	m_bEnableCh2of5;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCh2of5Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCh2of5Dlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CH2OF5DLG_H__936A0DD1_B132_496E_ACE5_8ACCF00D4DBB__INCLUDED_)
