// Gs1Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3PlusScanTest.h"
#include "Gs1Dlg.h"
#include "M3PlusScanTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGs1Dlg dialog


CGs1Dlg::CGs1Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGs1Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGs1Dlg)
	m_bEnableGs1 = FALSE;
	m_bEnableGs1Expanded = FALSE;
	m_bEnableGs1Limited = FALSE;
	//}}AFX_DATA_INIT
}

void CGs1Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGs1Dlg)
	DDX_Check(pDX, IDC_CHECK_GS1, m_bEnableGs1);
	DDX_Check(pDX, IDC_CHECK_GS1_EXPANDED, m_bEnableGs1Expanded);
	DDX_Check(pDX, IDC_CHECK_GS1_LIMITED, m_bEnableGs1Limited);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGs1Dlg, CDialog)
	//{{AFX_MSG_MAP(CGs1Dlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGs1Dlg message handlers

BOOL CGs1Dlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);

	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CGs1Dlg::GetOption()
{
	CM3PlusScanTestDlg* dlg = (CM3PlusScanTestDlg*)AfxGetMainWnd();

	int nCheck = 0;
	nCheck = dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"VER");
	if( nCheck == -1 || nCheck != M3PLUSSCANVER)
	{
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1",(DWORD)dlg->KScan.GetBarCodeType(GS1));
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1_LIMITED",(DWORD)dlg->KScan.GetBarCodeType(GS1_LIMITED));
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1_EXPANDED",(DWORD)dlg->KScan.GetBarCodeType(GS1_EXPANDED));
	}

	m_bEnableGs1			= (BOOL)dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1");
	m_bEnableGs1Limited		= (BOOL)dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1_LIMITED");
	m_bEnableGs1Expanded	= (BOOL)dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1_EXPANDED");

	UpdateData(FALSE);
}

void CGs1Dlg::SetOption()
{
	UpdateData(TRUE);

	CM3PlusScanTestDlg* dlg = (CM3PlusScanTestDlg*)AfxGetMainWnd();

	if((DWORD)m_bEnableGs1 != dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1"))
	{
		dlg->KScan.SetCh2of5_Gs1_Enable(GS1, m_bEnableGs1);	
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1", m_bEnableGs1);
	}
	if((DWORD)m_bEnableGs1Limited != dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1_LIMITED"))
	{
		dlg->KScan.SetCh2of5_Gs1_Enable(GS1_LIMITED	, m_bEnableGs1Limited);	
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1_LIMITED", m_bEnableGs1Limited);
	}
	if((DWORD)m_bEnableGs1Expanded != dlg->m_reg.GetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1_EXPANDED"))
	{
		dlg->KScan.SetCh2of5_Gs1_Enable(GS1_EXPANDED	, m_bEnableGs1Expanded);	
		dlg->m_reg.SetRegValue(HKEY_CURRENT_USER, REG_ADDRESS, L"GS1_EXPANDED", m_bEnableGs1Expanded);
	}
}

void CGs1Dlg::OnOK() 
{
	SetOption();
	
	CDialog::OnOK();
}
