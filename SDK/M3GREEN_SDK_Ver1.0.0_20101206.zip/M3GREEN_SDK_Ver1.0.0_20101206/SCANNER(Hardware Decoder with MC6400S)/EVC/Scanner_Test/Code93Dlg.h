#if !defined(AFX_CODE93DLG_H__2AC0B3E0_0151_4C3A_B93B_E6910F83A1A3__INCLUDED_)
#define AFX_CODE93DLG_H__2AC0B3E0_0151_4C3A_B93B_E6910F83A1A3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Code93Dlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCode93Dlg dialog

class CCode93Dlg : public CDialog
{
// Construction
public:
	void SetOption();
	void GetOption();
	CCode93Dlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCode93Dlg)
	enum { IDD = IDD_CODE93_DLG };
	BOOL	m_bEnableCode93;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCode93Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCode93Dlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CODE93DLG_H__2AC0B3E0_0151_4C3A_B93B_E6910F83A1A3__INCLUDED_)
