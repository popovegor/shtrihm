// DetailDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3PlusScanTest.h"
#include "DetailDlg.h"

// BarCode Option
#include "UpceanDlg.h"
#include "Code128Dlg.h"
#include "Code39Dlg.h"
#include "Code93Dlg.h"
#include "Code11Dlg.h"
#include "I2of5Dlg.h"
#include "Dis2of5Dlg.h"
#include "Ch2of5Dlg.h"
#include "CodabarDlg.h"
#include "MsiDlg.h"
#include "Gs1Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDetailDlg dialog


CDetailDlg::CDetailDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDetailDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDetailDlg)
	m_bPowerMode = FALSE;
	m_nSyncMode = -1;
	m_nTransCodeID = -1;
	//}}AFX_DATA_INIT
}


void CDetailDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDetailDlg)
	DDX_Control(pDX, IDC_COMBO_TIMEOUT, m_ctrlComboTimeOut);
	DDX_Control(pDX, IDC_COMBO_SECURITYLEVEL, m_ctrlComboSecurityLevel);
	DDX_Check(pDX, IDC_CHECK_POWERMODE, m_bPowerMode);
	DDX_Radio(pDX, IDC_RADIO_SYNC, m_nSyncMode);
	DDX_Radio(pDX, IDC_RADIO_NONE, m_nTransCodeID);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDetailDlg, CDialog)
	//{{AFX_MSG_MAP(CDetailDlg)
	ON_BN_CLICKED(IDC_BTN_CH2OF5, OnBtnCh2of5)
	ON_BN_CLICKED(IDC_BTN_CODABAR, OnBtnCodabar)
	ON_BN_CLICKED(IDC_BTN_CODE11, OnBtnCode11)
	ON_BN_CLICKED(IDC_BTN_CODE128, OnBtnCode128)
	ON_BN_CLICKED(IDC_BTN_CODE39, OnBtnCode39)
	ON_BN_CLICKED(IDC_BTN_CODE93, OnBtnCode93)
	ON_BN_CLICKED(IDC_BTN_DIS2OF5, OnBtnDis2of5)
	ON_BN_CLICKED(IDC_BTN_GS1, OnBtnGs1)
	ON_BN_CLICKED(IDC_BTN_I2OF5, OnBtnI2of5)
	ON_BN_CLICKED(IDC_BTN_MSI, OnBtnMsi)
	ON_BN_CLICKED(IDC_BTN_UPCEAN, OnBtnUpcean)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDetailDlg message handlers

BOOL CDetailDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);
	
	// Security Level
	m_ctrlComboSecurityLevel.InsertString(0, L"1");
	m_ctrlComboSecurityLevel.InsertString(1, L"2");
	m_ctrlComboSecurityLevel.InsertString(2, L"3");
	m_ctrlComboSecurityLevel.InsertString(3, L"4");
	m_ctrlComboSecurityLevel.SetCurSel(m_nSecurityLevel);

	// TimeOut
	m_ctrlComboTimeOut.InsertString(0, L"1");
	m_ctrlComboTimeOut.InsertString(1, L"2");
	m_ctrlComboTimeOut.InsertString(2, L"3");
	m_ctrlComboTimeOut.InsertString(3, L"4");
	m_ctrlComboTimeOut.InsertString(4, L"5");
	m_ctrlComboTimeOut.InsertString(5, L"6");
	m_ctrlComboTimeOut.InsertString(6, L"7");
	m_ctrlComboTimeOut.InsertString(7, L"8");
	m_ctrlComboTimeOut.InsertString(8, L"9");
	m_ctrlComboTimeOut.InsertString(9, L"10");
	m_ctrlComboTimeOut.SetCurSel(m_nTimeOut);

	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDetailDlg::OnOK() 
{
	UpdateData(TRUE);
	m_nSecurityLevel = m_ctrlComboSecurityLevel.GetCurSel();
	m_nTimeOut = m_ctrlComboTimeOut.GetCurSel();
	
	CDialog::OnOK();
}

void CDetailDlg::OnBtnUpcean() 
{
	CUpceanDlg dlg;

	dlg.DoModal();
	
}

void CDetailDlg::OnBtnCode128() 
{
	CCode128Dlg dlg;
	
	dlg.DoModal();
	
}

void CDetailDlg::OnBtnCode39() 
{
	CCode39Dlg dlg;
	
	dlg.DoModal();
	
}

void CDetailDlg::OnBtnCode93() 
{
	CCode93Dlg dlg;
	
	dlg.DoModal();	
}

void CDetailDlg::OnBtnCode11() 
{
	CCode11Dlg dlg;
	
	dlg.DoModal();	
}

void CDetailDlg::OnBtnI2of5() 
{
	CI2of5Dlg dlg;
	
	dlg.DoModal();	
}

void CDetailDlg::OnBtnDis2of5() 
{
	CDis2of5Dlg dlg;
	
	dlg.DoModal();	
}

void CDetailDlg::OnBtnCh2of5() 
{
	CCh2of5Dlg dlg;
	
	dlg.DoModal();	
}

void CDetailDlg::OnBtnCodabar() 
{
	CCodabarDlg dlg;
	
	dlg.DoModal();	
}

void CDetailDlg::OnBtnMsi() 
{
	CMsiDlg dlg;
	
	dlg.DoModal();	
}

void CDetailDlg::OnBtnGs1() 
{
	CGs1Dlg dlg;
	
	dlg.DoModal();	
}






