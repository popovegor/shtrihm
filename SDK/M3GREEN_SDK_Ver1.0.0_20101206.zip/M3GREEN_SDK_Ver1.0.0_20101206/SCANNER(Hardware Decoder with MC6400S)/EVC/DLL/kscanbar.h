
// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the KSCANBAR_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// KSCANBAR_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#ifdef KSCANBAR_EXPORTS
#define KSCANBAR_API __declspec(dllexport)
#else
#define KSCANBAR_API __declspec(dllimport)
#endif

#if !defined( PASCAL )
#define PASCAL  __pascal
#endif
#if !defined( WINAPI )
#define WINAPI	PASCAL
#endif
#if !defined( KSCANAPI )
#define KSCANAPI	WINAPI
#endif

typedef DWORD (KSCANAPI * KS_FN_CALLBACK)(LPVOID);

typedef struct tagKSCANREAD 
{
	int              nSize;
	unsigned         nTimeInSeconds;
	unsigned long    dwFlags;
	unsigned long    dwReadType;
	int              nMinLength;
	int              nSecurity;
	KS_FN_CALLBACK   fnCallBack;		// Different from DLL - should require no chages in the Application code.
	LPVOID           pUserData;
	LPVOID           pReadEx;	
	int              out_Type;
	char             out_Barcode[2711];
} KSCANREAD;
typedef KSCANREAD *PKSCANREAD;

// TOTAL 22
#define KSCAN_READ_TYPE_UPCA			0x00000001L     //= 0x01,
#define KSCAN_READ_TYPE_UPCE 			0x00000002L		//= 0x02,
#define KSCAN_READ_TYPE_UPCE1			0x00000004L		//= 0x0C,
#define KSCAN_READ_TYPE_EAN8			0x00000008L		//= 0x04,
#define KSCAN_READ_TYPE_EAN13			0x00000010L		//= 0x03,
#define KSCAN_READ_TYPE_BOOKLAND_EAN	0x00000020L		//= 0x53,
#define KSCAN_READ_TYPE_COUPON			0x00000040L		//= 0x55,
#define KSCAN_READ_TYPE_CODE128			0x00000080L		//= 0x08,
#define KSCAN_READ_TYPE_UCC_EAN128		0x00000100L		//= 0x0E,
#define KSCAN_READ_TYPE_ISBT_128		0x00000200L		//= 0x54,
#define KSCAN_READ_TYPE_CODE39			0x00000400L		//= 0x00,
#define KSCAN_READ_TYPE_TRIOPTIC39 		0x00000800L		//= 0x0D,
#define KSCAN_READ_TYPE_CODE93			0x00001000L		//= 0x09,
#define KSCAN_READ_TYPE_CODE11	 		0x00002000L		//= 0x0A,
#define KSCAN_READ_TYPE_I2OF5			0x00004000L		//= 0x06,
#define KSCAN_READ_TYPE_DIS2OF5			0x00008000L		//= 0x05,
#define KSCAN_READ_TYPE_CH2OF5	 		0x00010000L		//= 0xF0/0x98,
#define KSCAN_READ_TYPE_CODABAR			0x00020000L		//= 0x07,
#define KSCAN_READ_TYPE_MSI			 	0x00040000L		//= 0x0B,
#define KSCAN_READ_TYPE_GS1			 	0x00080000L		//= 0xF0/0x52,
#define KSCAN_READ_TYPE_GS1_LIMITED 	0x00100000L		//= 0xF0/0x53,
#define KSCAN_READ_TYPE_GS1_EXPANDED 	0x00200000L		//= 0xF0/0x54,

#define KSCAN_READ_TYPE_ALL				0xFFFFFFFFL


#define KSCAN_RET_TYPE_UPCA				0
#define KSCAN_RET_TYPE_UPCE 			1
#define KSCAN_RET_TYPE_UPCE1			2
#define KSCAN_RET_TYPE_EAN8				3
#define KSCAN_RET_TYPE_EAN13			4
#define KSCAN_RET_TYPE_BOOKLAND_EAN		5
#define KSCAN_RET_TYPE_COUPON			6
#define KSCAN_RET_TYPE_CODE128			7
#define KSCAN_RET_TYPE_UCC_EAN128		8
#define KSCAN_RET_TYPE_ISBT_128			9
#define KSCAN_RET_TYPE_CODE39			10
#define KSCAN_RET_TYPE_TRIOPTIC39 		11
#define KSCAN_RET_TYPE_CODE93			12
#define KSCAN_RET_TYPE_CODE11	 		13
#define KSCAN_RET_TYPE_I2OF5			14
#define KSCAN_RET_TYPE_DIS2OF5			15
#define KSCAN_RET_TYPE_CH2OF5	 		16
#define KSCAN_RET_TYPE_CODABAR			17
#define KSCAN_RET_TYPE_MSI		 		18
#define KSCAN_RET_TYPE_GS1				19
#define KSCAN_RET_TYPE_GS1_LIMITED 		20
#define KSCAN_RET_TYPE_GS1_EXPANDED 	21


#define OUT_TYPE_Not_Applicable	        0x00
#define OUT_TYPE_UPCA					0x08
#define OUT_TYPE_UPCE					0x09
#define OUT_TYPE_UPCE1					0x10
#define OUT_TYPE_EAN8					0x0A
#define OUT_TYPE_EAN13					0x0B
#define OUT_TYPE_BOOKLAND				0x16
#define OUT_TYPE_COUPON_CODE			0x17
#define OUT_TYPE_UPC_A_with_2_Supps		0x48
#define OUT_TYPE_UPC_A_with_5_Supps		0x88
#define OUT_TYPE_UPC_E_with_2_Supps		0x49
#define OUT_TYPE_UPC_E_with_5_Supps		0x89
#define OUT_TYPE_UPC_E1_with_2_Supps	0x50
#define OUT_TYPE_UPC_E1_with_5_Supps	0x90
#define OUT_TYPE_EAN_8_with_2_Supps		0x4A
#define OUT_TYPE_EAN_8_with_5_Supps		0x8A
#define OUT_TYPE_EAN_13_with_2_Supps	0x4B
#define OUT_TYPE_EAN_13_with_5_Supps	0x8B
#define OUT_TYPE_CODE128				0x03
#define OUT_TYPE_UCCEAN128				0x0F
#define OUT_TYPE_ISBT128				0x19
#define OUT_TYPE_CODE39					0x01
#define OUT_TYPE_TRIOPTICCODE39			0x15
#define OUT_TYPE_CODE32					0x20
#define OUT_TYPE_CODE93					0x07
#define OUT_TYPE_CODE11					0x0C
#define OUT_TYPE_INTERLEAVED2OF5		0x05
#define OUT_TYPE_INTERLEAVED2OF5_1		0x06
#define OUT_TYPE_DISCRETE2OF5			0x04
#define OUT_TYPE_CHINESE2OF5			0x72 
#define OUT_TYPE_CODABAR				0x02
#define OUT_TYPE_MSI					0x0E
#define OUT_TYPE_GS1					0x30
#define OUT_TYPE_GS1_LIMITED			0x31
#define OUT_TYPE_GS1_EXPANDED			0x32


// This class is exported from the kscanbar.dll
#include "MCPScan.h"
class KSCANBAR_API CKScan {
public:
	//////////////////////////////////////////////////////////////////////////
	// Add Func [12/22/2009 vision7901]
	unsigned char GetTransmitCodeID();
	void SetTransmitCodeID(unsigned char codeID);
	unsigned char GetMSIPlesseyCheckDigitAlgorithm();
	void SetMSIPlesseyCheckDigitAlgorithm(unsigned char check_digit);
	unsigned char GetMSIPlesseyCheckDigit();
	void SetMSIPlesseyCheckDigit(unsigned char check_digit);
	BOOL GetCodabarNOTISEditing();
	void SetCodabarNOTISEditing(BOOL bEnable);
	unsigned char GetI2of5CheckDigitVerification();
	void SetI2of5CheckDigitVerification(unsigned char check_digit);
	unsigned char GetCode11CheckDigitVerification();
	void SetCode11CheckDigitVerification(unsigned char check_digit);
	BOOL GetCode39FullAscii();
	void SetCode39FullAscii(BOOL bEnable);
	BOOL GetCode32PrefixEnabled();
	void SetCode32PrefixEnabled(BOOL bEnable);
	BOOL GetCode39CheckDigitVerification();
	void SetCode39CheckDigitVerification(BOOL bEnable);
	unsigned char GetDecUPCEANSupplementals();
	void SetDecUPCEANSupplementals(unsigned char supplementals);
	BOOL GetEANZeroExtend();
	void SetEANZeroExtend(BOOL bEnable);
	BOOL GetBarCodeConvert(ConvertType codeType);
	void SetBarCodeConvert(ConvertType codeType, BOOL bEnable);
	unsigned char GetUPCPreamble(unsigned char codeType);
	void SetUPCPreamble(unsigned char codeType,unsigned char preamble);
	unsigned char GetTransmitCheckDigit(unsigned char codeType);
	void SetTransmitCheckDigit(unsigned char codeType,unsigned char check_digit);
	//////////////////////////////////////////////////////////////////////////
	void SetScanOptionNBarCode(PMCPScanOption mcpoption,PMCBarCodeType mcpbarcodetype);
	void GetScanOptionNBarCode(PMCPScanOption mcpoption,PMCBarCodeType mcpbarcodetype);
	CKScan(void);
	~CKScan();
	void GetRevision(REVISIONStruct  *Revision);
	unsigned long GetScanOption();
	BOOL SetScanOption(unsigned long option);
	BOOL GetBarCodeType(unsigned char codeType);
	BOOL SetBarCodeType(unsigned char codeType, BOOL bEnable);
	BOOL SetCh2of5_Gs1_Enable(unsigned char codeType, BOOL bEnable);
	
	BOOL Open(int CommNumber, BOOL CommDetect, DWORD BaudRate, BOOL BaudDetect, DWORD ExFlags);
	BOOL Close();	
	BOOL Read(PKSCANREAD pRead);
	BOOL ReadCancel();
protected:
	CMCPScan	m_mcpscan;

};

EXTERN_C KSCANBAR_API BOOL KScanOpen(int CommNumber, BOOL CommDetect, DWORD BaudRate, BOOL BaudDetect, DWORD ExFlags);
EXTERN_C KSCANBAR_API BOOL KScanClose();
EXTERN_C KSCANBAR_API BOOL KScanRead(PKSCANREAD pRead);
EXTERN_C KSCANBAR_API BOOL KScanReadCancel();
EXTERN_C KSCANBAR_API BOOL KScanGetBarCodeType(unsigned char codeType);
EXTERN_C KSCANBAR_API BOOL KScanSetBarCodeType(unsigned char codeType, BOOL bEnable);
EXTERN_C KSCANBAR_API BOOL KScanSetScanOption(unsigned long option);
EXTERN_C KSCANBAR_API unsigned long KScanGetScanOption();
EXTERN_C KSCANBAR_API void KScanGetRevision(REVISIONStruct  *Revision);
EXTERN_C KSCANBAR_API void KScanSetScanOptionNBarCode(PMCPScanOption mcpoption,PMCBarCodeType mcpbarcodetype);
EXTERN_C KSCANBAR_API void KScanGetScanOptionNBarCode(PMCPScanOption mcpoption,PMCBarCodeType mcpbarcodetype);
//////////////////////////////////////////////////////////////////////////
// Add Func [12/22/2009 vision7901]
EXTERN_C KSCANBAR_API void KScanSetTransmitCheckDigit(unsigned char codeType,unsigned char check_digit);
EXTERN_C KSCANBAR_API unsigned char	KScanGetTransmitCheckDigit(unsigned char codeType);
EXTERN_C KSCANBAR_API void KScanSetUPCPreamble(unsigned char codeType,unsigned char preamble);
EXTERN_C KSCANBAR_API unsigned char	KScanGetUPCPreamble(unsigned char codeType);
EXTERN_C KSCANBAR_API void KScanSetBarCodeConvert(ConvertType codeType, BOOL bEnable);	
EXTERN_C KSCANBAR_API BOOL KScanGetBarCodeConvert(ConvertType codeType);
EXTERN_C KSCANBAR_API void KScanSetEANZeroExtend(BOOL bEnable);
EXTERN_C KSCANBAR_API BOOL KScanGetEANZeroExtend();
EXTERN_C KSCANBAR_API void KScanSetDecUPCEANSupplementals(unsigned char supplementals);
EXTERN_C KSCANBAR_API unsigned char	KScanGetDecUPCEANSupplementals();
EXTERN_C KSCANBAR_API void	KScanSetCode39CheckDigitVerification(BOOL bEnable);	
EXTERN_C KSCANBAR_API BOOL	KScanGetCode39CheckDigitVerification();	
EXTERN_C KSCANBAR_API void	KScanSetCode32PrefixEnabled(BOOL	bEnable);
EXTERN_C KSCANBAR_API BOOL	KScanGetCode32PrefixEnabled();
EXTERN_C KSCANBAR_API void	KScanSetCode39FullAscii(BOOL	bEnable);	
EXTERN_C KSCANBAR_API BOOL	KScanGetCode39FullAscii();
EXTERN_C KSCANBAR_API void	KScanSetCode11CheckDigitVerification(unsigned char check_digit);
EXTERN_C KSCANBAR_API unsigned char	KScanGetCode11CheckDigitVerification();
EXTERN_C KSCANBAR_API void	KScanSetI2of5CheckDigitVerification(unsigned char check_digit);
EXTERN_C KSCANBAR_API unsigned char	KScanGetI2of5CheckDigitVerification();
EXTERN_C KSCANBAR_API void	KScanSetCodabarNOTISEditing(BOOL bEnable);	
EXTERN_C KSCANBAR_API BOOL	KScanGetCodabarNOTISEditing();
EXTERN_C KSCANBAR_API void	KScanSetMSIPlesseyCheckDigit(unsigned char check_digit);
EXTERN_C KSCANBAR_API unsigned char	KScanGetMSIPlesseyCheckDigit();
EXTERN_C KSCANBAR_API void	KScanSetMSIPlesseyCheckDigitAlgorithm(unsigned char check_digit);
EXTERN_C KSCANBAR_API unsigned char	KScanGetMSIPlesseyCheckDigitAlgorithm();
EXTERN_C KSCANBAR_API void	KScanSetTransmitCodeID(unsigned char codeID);
EXTERN_C KSCANBAR_API unsigned char	KScanGetTransmitCodeID();
//////////////////////////////////////////////////////////////////////////