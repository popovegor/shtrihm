//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GpsParseDemo.rc
//
#define IDD_GPSPARSEDEMO_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDC_STATIC1                     1002
#define IDC_STATIC2                     1003
#define IDC_STATIC3                     1004
#define IDC_STATIC_TIME                 1005
#define IDC_STATIC_LATITUDE             1006
#define IDC_STATIC_LONGITUDE            1007
#define IDC_STATIC_ALTITUDE             1008
#define IDC_BUTTON_CONNECT              1009
#define IDC_BUTTON_DISCONNECT           1010
#define IDC_STATIC4                     1011
#define IDC_STATIC_SATELLITE            1012
#define IDC_STATIC5                     1013
#define IDC_LABEL_VELO                  1014
#define IDC_STATIC6                     1015
#define IDC_STATIC_HEADING              1016
#define IDC_STATIC7                     1017
#define IDC_STATIC_SATELLITE_SNR        1018
#define IDC_STATIC_STATUS               1019
#define IDC_CHECK_WRITE                 1020
#define IDC_COMBO1                      1022
#define IDC_COMBO_COM                   1022
#define IDC_BUTTON1                     1023
#define IDC_BUTTON_RESTART              1023
#define IDC_COMBO2                      1024
#define IDC_COMBO_STATIC                1024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
