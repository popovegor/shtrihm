// GpsParseDemoDlg.cpp : implementation file
//
#include "stdafx.h"
#include "GpsParseDemo.h"
#include "GpsParseDemoDlg.h"

#define LOG_DIRECTORY L"\\flash Disk"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CGpsParseDemoDlg dialog


CGpsParseDemoDlg::CGpsParseDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGpsParseDemoDlg::IDD, pParent)
	, m_strTime(_T(""))
	, m_strLatitude(_T(""))
	, m_strLongitude(_T(""))
	, m_strAltitude(_T(""))
	, m_strSatellite(_T("")) 
	, m_strVelocity(_T(""))
	, m_strHeading(_T(""))
	, m_strSNR(_T(""))
	, m_strGpsStatus(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_bOpenGps = FALSE;
}

void CGpsParseDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_STATIC_TIME, m_strTime);
	DDX_Text(pDX, IDC_STATIC_LATITUDE, m_strLatitude);
	DDX_Text(pDX, IDC_STATIC_LONGITUDE, m_strLongitude);
	DDX_Text(pDX, IDC_STATIC_ALTITUDE, m_strAltitude);
	DDX_Text(pDX, IDC_STATIC_SATELLITE, m_strSatellite);
	DDX_Text(pDX, IDC_LABEL_VELO, m_strVelocity);
	DDX_Text(pDX, IDC_STATIC_HEADING, m_strHeading);
	DDX_Text(pDX, IDC_STATIC_SATELLITE_SNR, m_strSNR);
	DDX_Text(pDX, IDC_STATIC_STATUS, m_strGpsStatus);
	DDX_Control(pDX, IDC_CHECK_WRITE, m_chkFileWrite);
	DDX_Control(pDX, IDC_COMBO_COM, m_cmbComPort);
	DDX_Control(pDX, IDC_COMBO_STATIC, m_cmbStaticMode);
}

BEGIN_MESSAGE_MAP(CGpsParseDemoDlg, CDialog)
#if defined(_DEVICE_RESOLUTION_AWARE) && !defined(WIN32_PLATFORM_WFSP)
	ON_WM_SIZE()
#endif
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_CONNECT, &CGpsParseDemoDlg::OnBnClickedButtonConnect)
	ON_BN_CLICKED(IDC_BUTTON_DISCONNECT, &CGpsParseDemoDlg::OnBnClickedButtonDisconnect)
	ON_MESSAGE(WM_USER_RECVDATA, OnRecvGPSData)
	ON_BN_CLICKED(IDC_BUTTON_RESTART, &CGpsParseDemoDlg::OnBnClickedButtonRestart)
	ON_CBN_SELCHANGE(IDC_COMBO_STATIC, &CGpsParseDemoDlg::OnCbnSelchangeComboStatic)
END_MESSAGE_MAP()


// CGpsParseDemoDlg message handlers

BOOL CGpsParseDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_cmbComPort.InsertString(0, L"COM0:");
	m_cmbComPort.InsertString(1, L"COM1:");
	m_cmbComPort.InsertString(2, L"COM2:");
	m_cmbComPort.InsertString(3, L"COM3:");
	m_cmbComPort.InsertString(4, L"COM4:");
	m_cmbComPort.InsertString(5, L"COM5:");
	m_cmbComPort.InsertString(6, L"COM6:");
	m_cmbComPort.InsertString(7, L"COM7:");
	m_cmbComPort.InsertString(8, L"COM8:");
	m_cmbComPort.InsertString(9, L"COM9:");
	m_cmbComPort.SetCurSel(0);

	m_cmbStaticMode.InsertString(0, L"Enable");
	m_cmbStaticMode.InsertString(1, L"disable");
	m_cmbStaticMode.SetCurSel(0);



	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	::EnableWindow(::GetDlgItem(m_hWnd, IDC_BUTTON_CONNECT), TRUE);
	::EnableWindow(::GetDlgItem(m_hWnd, IDC_BUTTON_DISCONNECT), FALSE);
	::EnableWindow(::GetDlgItem(m_hWnd, IDC_BUTTON_RESTART), FALSE);
	m_cmbStaticMode.EnableWindow(FALSE);

	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

#if defined(_DEVICE_RESOLUTION_AWARE) && !defined(WIN32_PLATFORM_WFSP)
void CGpsParseDemoDlg::OnSize(UINT /*nType*/, int /*cx*/, int /*cy*/)
{
	if (AfxIsDRAEnabled())
	{
		DRA::RelayoutDialog(
			AfxGetResourceHandle(), 
			this->m_hWnd, 
			DRA::GetDisplayMode() != DRA::Portrait ? 
			MAKEINTRESOURCE(IDD_GPSPARSEDEMO_DIALOG_WIDE) : 
			MAKEINTRESOURCE(IDD_GPSPARSEDEMO_DIALOG));
	}
}
#endif


void CGpsParseDemoDlg::OnBnClickedButtonConnect()
{
	if(m_bOpenGps == FALSE)
	{	

		TCHAR tzCom[16] = {0x00};
		m_cmbComPort.GetLBText(m_cmbComPort.GetCurSel(), tzCom);

		if(M3GPS_Open(m_hWnd, tzCom, 9600, fnParseGps))
		{
			::EnableWindow(::GetDlgItem(m_hWnd, IDC_BUTTON_CONNECT), FALSE);
			::EnableWindow(::GetDlgItem(m_hWnd, IDC_BUTTON_DISCONNECT), TRUE);
			::EnableWindow(::GetDlgItem(m_hWnd, IDC_BUTTON_RESTART), TRUE);
			m_cmbStaticMode.EnableWindow(TRUE);
			m_bOpenGps = TRUE;

		}
		else
		{
			AfxMessageBox(L"Open Fail");

		}


	}
}
void CGpsParseDemoDlg::fnParseGps(GPSParseInfo info)
{
	// almost Same with OnRecvGPSData
}

void CGpsParseDemoDlg::OnBnClickedButtonDisconnect()
{
	if(m_bOpenGps == TRUE)
	{		
		if(M3GPS_Close())
		{
			m_bOpenGps = FALSE;

			::EnableWindow(::GetDlgItem(m_hWnd, IDC_BUTTON_CONNECT), TRUE);
			::EnableWindow(::GetDlgItem(m_hWnd, IDC_BUTTON_DISCONNECT), FALSE);
			::EnableWindow(::GetDlgItem(m_hWnd, IDC_BUTTON_RESTART), FALSE);
			m_cmbStaticMode.EnableWindow(FALSE);


		}
		else
		{
			AfxMessageBox(L"Close Fail");
		}
	}
}

long CGpsParseDemoDlg::OnRecvGPSData(WPARAM wParam, LPARAM lParam)
{
	GPSParseInfo *pInf = (GPSParseInfo*)wParam;

	// GPS Information
	ParseGPSMsg(pInf);
	//

	return 0;
}

void CGpsParseDemoDlg::OnOK()
{
	if(m_bOpenGps == TRUE)
	{
		M3GPS_Close();
		m_bOpenGps = FALSE;
	}
	CDialog::OnOK();
}

void CGpsParseDemoDlg::OnCancel()
{
	if(m_bOpenGps == TRUE)
	{
		M3GPS_Close();
		m_bOpenGps = FALSE;
	}

	CDialog::OnCancel();
}

void CGpsParseDemoDlg::ParseGPSMsg(GPSParseInfo *pInf)
{
	CString mTemp;
	long nUTChour, nUTCmin, nUTCsec;
	int deg = 0, min = 0, sec = 0;

	// Status
	if(pInf->nPosFix > 0)
		m_strGpsStatus.Format(L"GPS On");
	else
		m_strGpsStatus.Format(L"Waiting...");

	// Time
	nUTChour = (long)(pInf->dUTCTime / 10000);
	nUTCmin = (long)(pInf->dUTCTime / 100) - nUTChour * 100;
	nUTCsec = (long)(pInf->dUTCTime / 1) - nUTChour * 10000 - nUTCmin * 100;
	nUTChour += 9;
	if(nUTChour > 24) nUTChour -= 24;
	m_strTime.Format(_T("%02d:%02d:%02d"), nUTChour, nUTCmin, nUTCsec);

	// Latituded
	deg = (int)(pInf->dLatitude / 100);
	min = (int)(pInf->dLatitude / 1) - deg * 100;
	sec = (int)((pInf->dLatitude - deg * 100 - min) * 60);
	if(pInf->bNorthLatitude) m_strLatitude.Format(_T("N %2d, %2d, %2d"), deg, min, sec);
	else m_strLatitude.Format(_T("S %2d, %2d, %2d"), deg, min, sec);

	// Longitude
	deg = (int)(pInf->dLongitude / 100);
	min = (int)(pInf->dLongitude / 1) - deg * 100;
	sec = (int)((pInf->dLongitude - deg * 100 - min ) * 60);
	if(pInf->bEastLongitude) m_strLongitude.Format(_T("E %2d, %2d, %2d"), deg, min, sec);
	else m_strLongitude.Format(_T("W %2d, %2d, %2d"), deg, min, sec);

	// Altitude
	m_strAltitude.Format(_T("%.3f m"), pInf->dAltitude);

	// Satellite
	int nSumSNR = 0;
	int nSatCount = 0;
	int nAvrSNR = 0;
	CString szSNR;

	for(int i = 0; i < pInf->nSatNum; i++)
	{
		if(pInf->mSat[i].nSNR > 0)
		{
			nSatCount++;
			nSumSNR += pInf->mSat[i].nSNR;
		}
		
		szSNR.Format(L"[%02d:%02d]  %s", pInf->mSat[i].nID, pInf->mSat[i].nSNR, szSNR);
	}
	
	if(nSatCount != 0)	nAvrSNR = nSumSNR / nSatCount;

	m_strSatellite.Format(_T("%d / %d"), pInf->nSatInUse, pInf->nSatNum);
	// m_strSNR.Format(L"%d", nAvrSNR);
	m_strSNR = szSNR;

	// Velocity
	m_strVelocity.Format(_T("%.2f km"), pInf->dVelocity);

	// Heading
	m_strHeading.Format(_T("%.2f"), pInf->dHeading);

	// DumpFile
	if(m_chkFileWrite.GetCheck() == BST_CHECKED)
	{
		CString szFilePath;
		szFilePath.Format(L"%s\\LogNMEA.txt", LOG_DIRECTORY);
		WriteToFile((LPCTSTR)szFilePath, pInf->mNMEAMsg);
	}

	UpdateData(FALSE);
}


BOOL CGpsParseDemoDlg::WriteToFile(const TCHAR* tszFilePath, CString cstrMsg)
{

	const int	MAX_MSG = 1024;
	char		msg[MAX_MSG];
	HANDLE		hFile = INVALID_HANDLE_VALUE;
	DWORD		dwWritten;

	memset(msg, 0x00, MAX_MSG);


	hFile = CreateFile(tszFilePath,GENERIC_WRITE,0,NULL, OPEN_EXISTING, 0, NULL);	// ���� �����ϱ� ������ ����

	if(hFile == INVALID_HANDLE_VALUE)	// ������ ���� ���
	{
		CreateDirectory(LOG_DIRECTORY,NULL);

		hFile = CreateFile(tszFilePath,GENERIC_WRITE,0,NULL, CREATE_NEW, 0, NULL);	// ���� ���� ����� 

		if(hFile == INVALID_HANDLE_VALUE){
			AfxMessageBox(L"File create error");
			return 0;
		}

		// unicode�� ansi��
		WideCharToMultiByte(CP_ACP, 0, cstrMsg, cstrMsg.GetLength(), msg, MAX_MSG ,NULL, NULL );

		if(0xFFFFFFFF == SetFilePointer(hFile, 0, NULL, FILE_END))
			AfxMessageBox(L"move file pointer  fail");

		// ����� ��Ʈ���� ����
		WriteFile(hFile, msg, strlen(msg), &dwWritten, NULL);

	}	

	memset(msg, 0x00, MAX_MSG);

	if(hFile != INVALID_HANDLE_VALUE)	// ����� �����ϰų� ������ ���
	{
		// unicode�� ansi��
		WideCharToMultiByte(CP_ACP, 0, cstrMsg, cstrMsg.GetLength(), msg, MAX_MSG ,NULL, NULL );

		if(0xFFFFFFFF == SetFilePointer(hFile, 0, NULL, FILE_END))
			AfxMessageBox(L"move file pointer  fail");

		// ����� ��Ʈ���� ����
		WriteFile(hFile, msg, strlen(msg), &dwWritten, NULL);
	}
	else
	{
		return FALSE;
	}

	CloseHandle(hFile);

	return 1;
}
void CGpsParseDemoDlg::OnBnClickedButtonRestart()
{
	if(!M3GPS_ModuleRestart(GPS_COLD_START))
		AfxMessageBox(L"Fail");
}

void CGpsParseDemoDlg::OnCbnSelchangeComboStatic()
{
	int nMode = m_cmbStaticMode.GetCurSel();
	M3GPS_EnableStaticMode(nMode);
	RETAILMSG(RT_MSG, (L"Static mode :[%d]\r\n", nMode));
}
