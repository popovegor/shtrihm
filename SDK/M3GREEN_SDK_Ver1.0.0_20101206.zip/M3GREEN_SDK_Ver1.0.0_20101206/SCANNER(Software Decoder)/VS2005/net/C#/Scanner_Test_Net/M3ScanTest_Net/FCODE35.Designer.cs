﻿namespace M3ScanTest_Net
{
    partial class FCODE35
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.CB_CODE35_ENABLE = new System.Windows.Forms.CheckBox();
            this.BTN_CANCEL = new System.Windows.Forms.Button();
            this.BTN_OK = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // CB_CODE35_ENABLE
            // 
            this.CB_CODE35_ENABLE.Location = new System.Drawing.Point(69, 103);
            this.CB_CODE35_ENABLE.Name = "CB_CODE35_ENABLE";
            this.CB_CODE35_ENABLE.Size = new System.Drawing.Size(100, 20);
            this.CB_CODE35_ENABLE.TabIndex = 16;
            this.CB_CODE35_ENABLE.Text = "Enable";
            // 
            // BTN_CANCEL
            // 
            this.BTN_CANCEL.Location = new System.Drawing.Point(127, 215);
            this.BTN_CANCEL.Name = "BTN_CANCEL";
            this.BTN_CANCEL.Size = new System.Drawing.Size(93, 35);
            this.BTN_CANCEL.TabIndex = 15;
            this.BTN_CANCEL.Text = "CANCEL";
            this.BTN_CANCEL.Click += new System.EventHandler(this.BTN_CANCEL_Click);
            // 
            // BTN_OK
            // 
            this.BTN_OK.Location = new System.Drawing.Point(18, 215);
            this.BTN_OK.Name = "BTN_OK";
            this.BTN_OK.Size = new System.Drawing.Size(93, 35);
            this.BTN_OK.TabIndex = 14;
            this.BTN_OK.Text = "OK";
            this.BTN_OK.Click += new System.EventHandler(this.BTN_OK_Click);
            // 
            // FCODE35
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(238, 275);
            this.Controls.Add(this.CB_CODE35_ENABLE);
            this.Controls.Add(this.BTN_CANCEL);
            this.Controls.Add(this.BTN_OK);
            this.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular);
            this.Menu = this.mainMenu1;
            this.Name = "FCODE35";
            this.Text = "CODE35";
            this.Load += new System.EventHandler(this.FCODE35_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckBox CB_CODE35_ENABLE;
        private System.Windows.Forms.Button BTN_CANCEL;
        private System.Windows.Forms.Button BTN_OK;
    }
}