﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace M3ScanTest_Net
{
    public partial class FI2OF5 : Form
    {
        public bool m_bEnable;
        public bool m_bItf14;
        public bool m_bMatrix2of5;
        public bool m_bDlogic;
        public bool m_bIndustry;
        public bool m_bIata;
        public bool m_bCDV;
        public bool m_bXCD;
        public int m_nMinLen;
        public int m_nMaxLen;

        public FI2OF5()
        {
            InitializeComponent();
        }

        private void FI2OF5_Load(object sender, EventArgs e)
        {
            CB_I2OF5_ENABLE.Checked = m_bEnable;
            CB_ITF14_ENABLE.Checked = m_bItf14;
            CB_MATRIX2OF5_ENABLE.Checked = m_bMatrix2of5;
            CB_DLOGIC_ENABLE.Checked = m_bDlogic;
            CB_INDUSTRY_ENABLE.Checked = m_bIndustry;
            CB_IATA_ENABLE.Checked = m_bIata;
            CB_I2OF5_CDV.Checked = m_bCDV;
            CB_I2OF5_XCD.Checked = m_bXCD;

            TEXT_MINLEN.Text = m_nMinLen.ToString();
            TEXT_MAXLEN.Text = m_nMaxLen.ToString(); 
        }

        private void BTN_OK_Click(object sender, EventArgs e)
        {
            m_bEnable = CB_I2OF5_ENABLE.Checked;
            m_bItf14 = CB_ITF14_ENABLE.Checked;
            m_bMatrix2of5 = CB_MATRIX2OF5_ENABLE.Checked;
            m_bDlogic = CB_DLOGIC_ENABLE.Checked;
            m_bIndustry = CB_INDUSTRY_ENABLE.Checked;
            m_bIata = CB_IATA_ENABLE.Checked;
            m_bCDV = CB_I2OF5_CDV.Checked;
            m_bXCD = CB_I2OF5_XCD.Checked;

            m_nMinLen = Int32.Parse(TEXT_MINLEN.Text);
            m_nMaxLen = Int32.Parse(TEXT_MAXLEN.Text);


            this.DialogResult = DialogResult.OK;
        }

        private void BTN_CANCEL_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}