﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace M3ScanTest_Net
{
    public partial class FGS1 : Form
    {
        public bool m_bEnable;
        public bool m_bGs1Lim;
        public bool m_bGs1Exp;  

        public FGS1()
        {
            InitializeComponent();
        }

        private void FGS1_Load(object sender, EventArgs e)
        {
            CB_GS1_ENABLE.Checked = m_bEnable;
            CB_GS1LIM_ENABLE.Checked = m_bGs1Lim;
            CB_GS1EXP_ENABLE.Checked = m_bGs1Exp;
        }

        private void BTN_OK_Click(object sender, EventArgs e)
        {
            m_bEnable = CB_GS1_ENABLE.Checked;
            m_bGs1Lim = CB_GS1LIM_ENABLE.Checked;
            m_bGs1Exp = CB_GS1EXP_ENABLE.Checked;

            this.DialogResult = DialogResult.OK;
        }

        private void BTN_CANCEL_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}