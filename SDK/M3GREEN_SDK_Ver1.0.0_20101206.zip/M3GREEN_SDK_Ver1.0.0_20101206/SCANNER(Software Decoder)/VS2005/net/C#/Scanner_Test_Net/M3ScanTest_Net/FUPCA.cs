﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace M3ScanTest_Net
{
    public partial class FUPCA : Form
    {
        public bool m_bEnable;
        public bool m_bXNum;
        public bool m_bXCD;
        public bool m_bUPCAasEAN13;
        public bool m_bAddOn;
        public FUPCA()
        {
            InitializeComponent();
        }

        private void FUPCA_Load(object sender, EventArgs e)
        {
            CB_UPCA_ENABLE.Checked = m_bEnable;
            CB_UPCA_XNUM.Checked = m_bXNum;
            CB_UPCA_XCD.Checked = m_bXCD;
            CB_UPCA_AS_EAN13.Checked = m_bUPCAasEAN13;
            CB_UPCA_ADDON.Checked = m_bAddOn;
        }

        private void BTN_OK_Click(object sender, EventArgs e)
        {
            m_bEnable = CB_UPCA_ENABLE.Checked;
            m_bXNum = CB_UPCA_XNUM.Checked;
            m_bXCD = CB_UPCA_XCD.Checked;
            m_bUPCAasEAN13 = CB_UPCA_AS_EAN13.Checked;
            m_bAddOn = CB_UPCA_ADDON.Checked;

            this.DialogResult = DialogResult.OK;
        }

        private void BTN_CANCEL_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}