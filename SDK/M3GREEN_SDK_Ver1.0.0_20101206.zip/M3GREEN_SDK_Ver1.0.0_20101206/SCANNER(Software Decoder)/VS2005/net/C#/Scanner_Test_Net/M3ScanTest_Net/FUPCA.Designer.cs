﻿namespace M3ScanTest_Net
{
    partial class FUPCA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.BTN_CANCEL = new System.Windows.Forms.Button();
            this.BTN_OK = new System.Windows.Forms.Button();
            this.CB_UPCA_ADDON = new System.Windows.Forms.CheckBox();
            this.CB_UPCA_AS_EAN13 = new System.Windows.Forms.CheckBox();
            this.CB_UPCA_XCD = new System.Windows.Forms.CheckBox();
            this.CB_UPCA_XNUM = new System.Windows.Forms.CheckBox();
            this.CB_UPCA_ENABLE = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // BTN_CANCEL
            // 
            this.BTN_CANCEL.Location = new System.Drawing.Point(127, 215);
            this.BTN_CANCEL.Name = "BTN_CANCEL";
            this.BTN_CANCEL.Size = new System.Drawing.Size(93, 35);
            this.BTN_CANCEL.TabIndex = 13;
            this.BTN_CANCEL.Text = "CANCEL";
            this.BTN_CANCEL.Click += new System.EventHandler(this.BTN_CANCEL_Click);
            // 
            // BTN_OK
            // 
            this.BTN_OK.Location = new System.Drawing.Point(19, 215);
            this.BTN_OK.Name = "BTN_OK";
            this.BTN_OK.Size = new System.Drawing.Size(93, 35);
            this.BTN_OK.TabIndex = 12;
            this.BTN_OK.Text = "OK";
            this.BTN_OK.Click += new System.EventHandler(this.BTN_OK_Click);
            // 
            // CB_UPCA_ADDON
            // 
            this.CB_UPCA_ADDON.Location = new System.Drawing.Point(32, 141);
            this.CB_UPCA_ADDON.Name = "CB_UPCA_ADDON";
            this.CB_UPCA_ADDON.Size = new System.Drawing.Size(176, 20);
            this.CB_UPCA_ADDON.TabIndex = 11;
            this.CB_UPCA_ADDON.Text = "Add On 2/5";
            // 
            // CB_UPCA_AS_EAN13
            // 
            this.CB_UPCA_AS_EAN13.Location = new System.Drawing.Point(32, 115);
            this.CB_UPCA_AS_EAN13.Name = "CB_UPCA_AS_EAN13";
            this.CB_UPCA_AS_EAN13.Size = new System.Drawing.Size(188, 20);
            this.CB_UPCA_AS_EAN13.TabIndex = 10;
            this.CB_UPCA_AS_EAN13.Text = "Convert UPC-A as EAN-13";
            // 
            // CB_UPCA_XCD
            // 
            this.CB_UPCA_XCD.Location = new System.Drawing.Point(32, 89);
            this.CB_UPCA_XCD.Name = "CB_UPCA_XCD";
            this.CB_UPCA_XCD.Size = new System.Drawing.Size(176, 20);
            this.CB_UPCA_XCD.TabIndex = 9;
            this.CB_UPCA_XCD.Text = "Transmit Check Digit";
            // 
            // CB_UPCA_XNUM
            // 
            this.CB_UPCA_XNUM.Location = new System.Drawing.Point(32, 63);
            this.CB_UPCA_XNUM.Name = "CB_UPCA_XNUM";
            this.CB_UPCA_XNUM.Size = new System.Drawing.Size(188, 20);
            this.CB_UPCA_XNUM.TabIndex = 8;
            this.CB_UPCA_XNUM.Text = "Transmit Number System";
            // 
            // CB_UPCA_ENABLE
            // 
            this.CB_UPCA_ENABLE.Location = new System.Drawing.Point(32, 37);
            this.CB_UPCA_ENABLE.Name = "CB_UPCA_ENABLE";
            this.CB_UPCA_ENABLE.Size = new System.Drawing.Size(176, 20);
            this.CB_UPCA_ENABLE.TabIndex = 7;
            this.CB_UPCA_ENABLE.Text = "Enable";
            // 
            // FUPCA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(238, 275);
            this.Controls.Add(this.BTN_CANCEL);
            this.Controls.Add(this.BTN_OK);
            this.Controls.Add(this.CB_UPCA_ADDON);
            this.Controls.Add(this.CB_UPCA_AS_EAN13);
            this.Controls.Add(this.CB_UPCA_XCD);
            this.Controls.Add(this.CB_UPCA_XNUM);
            this.Controls.Add(this.CB_UPCA_ENABLE);
            this.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular);
            this.Menu = this.mainMenu1;
            this.Name = "FUPCA";
            this.Text = "UPC-A";
            this.Load += new System.EventHandler(this.FUPCA_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BTN_CANCEL;
        private System.Windows.Forms.Button BTN_OK;
        private System.Windows.Forms.CheckBox CB_UPCA_ADDON;
        private System.Windows.Forms.CheckBox CB_UPCA_AS_EAN13;
        private System.Windows.Forms.CheckBox CB_UPCA_XCD;
        private System.Windows.Forms.CheckBox CB_UPCA_XNUM;
        private System.Windows.Forms.CheckBox CB_UPCA_ENABLE;
    }
}