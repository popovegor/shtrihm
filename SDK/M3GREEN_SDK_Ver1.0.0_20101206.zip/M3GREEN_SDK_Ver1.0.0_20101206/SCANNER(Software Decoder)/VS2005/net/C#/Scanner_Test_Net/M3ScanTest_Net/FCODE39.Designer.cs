﻿namespace M3ScanTest_Net
{
    partial class FCODE39
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.TEXT_MAXLEN = new System.Windows.Forms.TextBox();
            this.TEXT_MINLEN = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.BTN_CANCEL = new System.Windows.Forms.Button();
            this.BTN_OK = new System.Windows.Forms.Button();
            this.CB_CODE39_FULLASCII = new System.Windows.Forms.CheckBox();
            this.CB_CODE39_XCD = new System.Windows.Forms.CheckBox();
            this.CB_CODE39_CDV = new System.Windows.Forms.CheckBox();
            this.CB_PZN_ENABLE = new System.Windows.Forms.CheckBox();
            this.CB_CODE32_ENABLE = new System.Windows.Forms.CheckBox();
            this.CB_CODE39_ENABLE = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // TEXT_MAXLEN
            // 
            this.TEXT_MAXLEN.Location = new System.Drawing.Point(187, 185);
            this.TEXT_MAXLEN.Name = "TEXT_MAXLEN";
            this.TEXT_MAXLEN.Size = new System.Drawing.Size(35, 23);
            this.TEXT_MAXLEN.TabIndex = 26;
            // 
            // TEXT_MINLEN
            // 
            this.TEXT_MINLEN.Location = new System.Drawing.Point(77, 185);
            this.TEXT_MINLEN.Name = "TEXT_MINLEN";
            this.TEXT_MINLEN.Size = new System.Drawing.Size(35, 23);
            this.TEXT_MINLEN.TabIndex = 25;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(125, 188);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 20);
            this.label2.Text = "Max.Len";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(16, 188);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 20);
            this.label1.Text = "Min.Len";
            // 
            // BTN_CANCEL
            // 
            this.BTN_CANCEL.Location = new System.Drawing.Point(127, 215);
            this.BTN_CANCEL.Name = "BTN_CANCEL";
            this.BTN_CANCEL.Size = new System.Drawing.Size(93, 35);
            this.BTN_CANCEL.TabIndex = 24;
            this.BTN_CANCEL.Text = "CANCEL";
            this.BTN_CANCEL.Click += new System.EventHandler(this.BTN_CANCEL_Click);
            // 
            // BTN_OK
            // 
            this.BTN_OK.Location = new System.Drawing.Point(18, 215);
            this.BTN_OK.Name = "BTN_OK";
            this.BTN_OK.Size = new System.Drawing.Size(93, 35);
            this.BTN_OK.TabIndex = 23;
            this.BTN_OK.Text = "OK";
            this.BTN_OK.Click += new System.EventHandler(this.BTN_OK_Click);
            // 
            // CB_CODE39_FULLASCII
            // 
            this.CB_CODE39_FULLASCII.Location = new System.Drawing.Point(40, 146);
            this.CB_CODE39_FULLASCII.Name = "CB_CODE39_FULLASCII";
            this.CB_CODE39_FULLASCII.Size = new System.Drawing.Size(158, 20);
            this.CB_CODE39_FULLASCII.TabIndex = 22;
            this.CB_CODE39_FULLASCII.Text = "Full ASCII Conversion";
            // 
            // CB_CODE39_XCD
            // 
            this.CB_CODE39_XCD.Location = new System.Drawing.Point(40, 123);
            this.CB_CODE39_XCD.Name = "CB_CODE39_XCD";
            this.CB_CODE39_XCD.Size = new System.Drawing.Size(158, 20);
            this.CB_CODE39_XCD.TabIndex = 21;
            this.CB_CODE39_XCD.Text = "Transmit Check Digit";
            // 
            // CB_CODE39_CDV
            // 
            this.CB_CODE39_CDV.Location = new System.Drawing.Point(40, 100);
            this.CB_CODE39_CDV.Name = "CB_CODE39_CDV";
            this.CB_CODE39_CDV.Size = new System.Drawing.Size(158, 20);
            this.CB_CODE39_CDV.TabIndex = 20;
            this.CB_CODE39_CDV.Text = "Check Digit Verification";
            // 
            // CB_PZN_ENABLE
            // 
            this.CB_PZN_ENABLE.Location = new System.Drawing.Point(40, 77);
            this.CB_PZN_ENABLE.Name = "CB_PZN_ENABLE";
            this.CB_PZN_ENABLE.Size = new System.Drawing.Size(158, 20);
            this.CB_PZN_ENABLE.TabIndex = 19;
            this.CB_PZN_ENABLE.Text = "Enable PZN";
            // 
            // CB_CODE32_ENABLE
            // 
            this.CB_CODE32_ENABLE.Location = new System.Drawing.Point(40, 54);
            this.CB_CODE32_ENABLE.Name = "CB_CODE32_ENABLE";
            this.CB_CODE32_ENABLE.Size = new System.Drawing.Size(158, 20);
            this.CB_CODE32_ENABLE.TabIndex = 18;
            this.CB_CODE32_ENABLE.Text = "Enable CODE32";
            // 
            // CB_CODE39_ENABLE
            // 
            this.CB_CODE39_ENABLE.Location = new System.Drawing.Point(40, 31);
            this.CB_CODE39_ENABLE.Name = "CB_CODE39_ENABLE";
            this.CB_CODE39_ENABLE.Size = new System.Drawing.Size(158, 20);
            this.CB_CODE39_ENABLE.TabIndex = 17;
            this.CB_CODE39_ENABLE.Text = "Enable";
            // 
            // FCODE39
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(238, 275);
            this.Controls.Add(this.TEXT_MAXLEN);
            this.Controls.Add(this.TEXT_MINLEN);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BTN_CANCEL);
            this.Controls.Add(this.BTN_OK);
            this.Controls.Add(this.CB_CODE39_FULLASCII);
            this.Controls.Add(this.CB_CODE39_XCD);
            this.Controls.Add(this.CB_CODE39_CDV);
            this.Controls.Add(this.CB_PZN_ENABLE);
            this.Controls.Add(this.CB_CODE32_ENABLE);
            this.Controls.Add(this.CB_CODE39_ENABLE);
            this.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular);
            this.Menu = this.mainMenu1;
            this.Name = "FCODE39";
            this.Text = "CODE39";
            this.Load += new System.EventHandler(this.FCODE39_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox TEXT_MAXLEN;
        private System.Windows.Forms.TextBox TEXT_MINLEN;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BTN_CANCEL;
        private System.Windows.Forms.Button BTN_OK;
        private System.Windows.Forms.CheckBox CB_CODE39_FULLASCII;
        private System.Windows.Forms.CheckBox CB_CODE39_XCD;
        private System.Windows.Forms.CheckBox CB_CODE39_CDV;
        private System.Windows.Forms.CheckBox CB_PZN_ENABLE;
        private System.Windows.Forms.CheckBox CB_CODE32_ENABLE;
        private System.Windows.Forms.CheckBox CB_CODE39_ENABLE;
    }
}