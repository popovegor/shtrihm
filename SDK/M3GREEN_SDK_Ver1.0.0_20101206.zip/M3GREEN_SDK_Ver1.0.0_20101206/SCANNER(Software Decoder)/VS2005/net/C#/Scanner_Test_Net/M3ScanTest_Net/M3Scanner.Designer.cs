﻿namespace M3ScanTest_Net
{
    partial class M3Scanner
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(M3Scanner));
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.Tab_M3Scanner = new System.Windows.Forms.TabControl();
            this.Tab_Main = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.Btn_Close = new System.Windows.Forms.Button();
            this.Btn_Info = new System.Windows.Forms.Button();
            this.Btn_ScanCancel = new System.Windows.Forms.Button();
            this.Btn_Scan = new System.Windows.Forms.Button();
            this.LV_SCANDATA = new System.Windows.Forms.ListView();
            this.BarType = new System.Windows.Forms.ColumnHeader();
            this.BarData = new System.Windows.Forms.ColumnHeader();
            this.Tab_Sym = new System.Windows.Forms.TabPage();
            this.Btn_SymCancel = new System.Windows.Forms.Button();
            this.Btn_SymConfirm = new System.Windows.Forms.Button();
            this.CB_GS1EXP = new System.Windows.Forms.CheckBox();
            this.CB_GS1LIM = new System.Windows.Forms.CheckBox();
            this.CB_GS1 = new System.Windows.Forms.CheckBox();
            this.CB_CODABAR = new System.Windows.Forms.CheckBox();
            this.CB_PLESSEY = new System.Windows.Forms.CheckBox();
            this.CB_MSI = new System.Windows.Forms.CheckBox();
            this.CB_I2OF5 = new System.Windows.Forms.CheckBox();
            this.CB_CODE11 = new System.Windows.Forms.CheckBox();
            this.CB_CODE35 = new System.Windows.Forms.CheckBox();
            this.CB_CODE93 = new System.Windows.Forms.CheckBox();
            this.CB_UCCEAN128 = new System.Windows.Forms.CheckBox();
            this.CB_CODE128 = new System.Windows.Forms.CheckBox();
            this.CB_PZN = new System.Windows.Forms.CheckBox();
            this.CB_CODE32 = new System.Windows.Forms.CheckBox();
            this.CB_CODE39 = new System.Windows.Forms.CheckBox();
            this.CB_EAN8 = new System.Windows.Forms.CheckBox();
            this.CB_BOOKLAND = new System.Windows.Forms.CheckBox();
            this.CB_EAN13 = new System.Windows.Forms.CheckBox();
            this.CB_UPCE = new System.Windows.Forms.CheckBox();
            this.CB_UPCA = new System.Windows.Forms.CheckBox();
            this.Tab_Option = new System.Windows.Forms.TabPage();
            this.Btn_OpCancel = new System.Windows.Forms.Button();
            this.Btn_OpConfirm = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.CB_AIMID = new System.Windows.Forms.CheckBox();
            this.CB_HIGHFILTER = new System.Windows.Forms.CheckBox();
            this.CB_WIDESCAN = new System.Windows.Forms.CheckBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.CB_SECLEVEL = new System.Windows.Forms.ComboBox();
            this.CB_TIMEOUT = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.RD_SYNC = new System.Windows.Forms.RadioButton();
            this.RD_ASYNC = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.Tab_Detail = new System.Windows.Forms.TabPage();
            this.BTN_DECANCEL = new System.Windows.Forms.Button();
            this.BTN_TELEPEN = new System.Windows.Forms.Button();
            this.BTN_GS1 = new System.Windows.Forms.Button();
            this.BTN_PLESSEY = new System.Windows.Forms.Button();
            this.BTN_MSI = new System.Windows.Forms.Button();
            this.BTN_CODABAR = new System.Windows.Forms.Button();
            this.BTN_I2OF5 = new System.Windows.Forms.Button();
            this.BTN_CODE11 = new System.Windows.Forms.Button();
            this.BTN_CODE35 = new System.Windows.Forms.Button();
            this.BTN_CODE93 = new System.Windows.Forms.Button();
            this.BTN_CODE128 = new System.Windows.Forms.Button();
            this.BTN_CODE39 = new System.Windows.Forms.Button();
            this.BTN_EAN8 = new System.Windows.Forms.Button();
            this.BTN_EAN13 = new System.Windows.Forms.Button();
            this.BTN_UPCE = new System.Windows.Forms.Button();
            this.BTN_UPCA = new System.Windows.Forms.Button();
            this.Tab_M3Scanner.SuspendLayout();
            this.Tab_Main.SuspendLayout();
            this.Tab_Sym.SuspendLayout();
            this.Tab_Option.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.Tab_Detail.SuspendLayout();
            this.SuspendLayout();
            // 
            // Tab_M3Scanner
            // 
            this.Tab_M3Scanner.Controls.Add(this.Tab_Main);
            this.Tab_M3Scanner.Controls.Add(this.Tab_Sym);
            this.Tab_M3Scanner.Controls.Add(this.Tab_Option);
            this.Tab_M3Scanner.Controls.Add(this.Tab_Detail);
            this.Tab_M3Scanner.Location = new System.Drawing.Point(0, 0);
            this.Tab_M3Scanner.Name = "Tab_M3Scanner";
            this.Tab_M3Scanner.SelectedIndex = 0;
            this.Tab_M3Scanner.Size = new System.Drawing.Size(240, 279);
            this.Tab_M3Scanner.TabIndex = 0;
            this.Tab_M3Scanner.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Tab_M3Scanner_KeyUp);
            this.Tab_M3Scanner.SelectedIndexChanged += new System.EventHandler(this.Tab_M3Scanner_SelectedIndexChanged);
            this.Tab_M3Scanner.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Tab_M3Scanner_KeyDown);
            // 
            // Tab_Main
            // 
            this.Tab_Main.BackColor = System.Drawing.SystemColors.Window;
            this.Tab_Main.Controls.Add(this.label1);
            this.Tab_Main.Controls.Add(this.Btn_Close);
            this.Tab_Main.Controls.Add(this.Btn_Info);
            this.Tab_Main.Controls.Add(this.Btn_ScanCancel);
            this.Tab_Main.Controls.Add(this.Btn_Scan);
            this.Tab_Main.Controls.Add(this.LV_SCANDATA);
            this.Tab_Main.Location = new System.Drawing.Point(4, 25);
            this.Tab_Main.Name = "Tab_Main";
            this.Tab_Main.Size = new System.Drawing.Size(232, 250);
            this.Tab_Main.Text = "Main";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(91, 227);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 15);
            this.label1.Text = "Ver 3.1.0 (20101027)";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // Btn_Close
            // 
            this.Btn_Close.Location = new System.Drawing.Point(121, 196);
            this.Btn_Close.Name = "Btn_Close";
            this.Btn_Close.Size = new System.Drawing.Size(106, 29);
            this.Btn_Close.TabIndex = 4;
            this.Btn_Close.Text = "Close";
            this.Btn_Close.Click += new System.EventHandler(this.Btn_Close_Click);
            // 
            // Btn_Info
            // 
            this.Btn_Info.Location = new System.Drawing.Point(5, 196);
            this.Btn_Info.Name = "Btn_Info";
            this.Btn_Info.Size = new System.Drawing.Size(106, 29);
            this.Btn_Info.TabIndex = 3;
            this.Btn_Info.Text = "Information";
            this.Btn_Info.Click += new System.EventHandler(this.Btn_Info_Click);
            // 
            // Btn_ScanCancel
            // 
            this.Btn_ScanCancel.Location = new System.Drawing.Point(121, 161);
            this.Btn_ScanCancel.Name = "Btn_ScanCancel";
            this.Btn_ScanCancel.Size = new System.Drawing.Size(106, 29);
            this.Btn_ScanCancel.TabIndex = 2;
            this.Btn_ScanCancel.Text = "Scan Cancel";
            this.Btn_ScanCancel.Click += new System.EventHandler(this.Btn_ScanCancel_Click);
            // 
            // Btn_Scan
            // 
            this.Btn_Scan.Location = new System.Drawing.Point(5, 161);
            this.Btn_Scan.Name = "Btn_Scan";
            this.Btn_Scan.Size = new System.Drawing.Size(106, 29);
            this.Btn_Scan.TabIndex = 1;
            this.Btn_Scan.Text = "Scan";
            this.Btn_Scan.Click += new System.EventHandler(this.Btn_Scan_Click);
            // 
            // LV_SCANDATA
            // 
            this.LV_SCANDATA.Columns.Add(this.BarType);
            this.LV_SCANDATA.Columns.Add(this.BarData);
            this.LV_SCANDATA.Location = new System.Drawing.Point(3, 3);
            this.LV_SCANDATA.Name = "LV_SCANDATA";
            this.LV_SCANDATA.Size = new System.Drawing.Size(226, 152);
            this.LV_SCANDATA.TabIndex = 0;
            this.LV_SCANDATA.View = System.Windows.Forms.View.Details;
            // 
            // BarType
            // 
            this.BarType.Text = "Type";
            this.BarType.Width = 83;
            // 
            // BarData
            // 
            this.BarData.Text = "Data";
            this.BarData.Width = 140;
            // 
            // Tab_Sym
            // 
            this.Tab_Sym.BackColor = System.Drawing.SystemColors.Window;
            this.Tab_Sym.Controls.Add(this.Btn_SymCancel);
            this.Tab_Sym.Controls.Add(this.Btn_SymConfirm);
            this.Tab_Sym.Controls.Add(this.CB_GS1EXP);
            this.Tab_Sym.Controls.Add(this.CB_GS1LIM);
            this.Tab_Sym.Controls.Add(this.CB_GS1);
            this.Tab_Sym.Controls.Add(this.CB_CODABAR);
            this.Tab_Sym.Controls.Add(this.CB_PLESSEY);
            this.Tab_Sym.Controls.Add(this.CB_MSI);
            this.Tab_Sym.Controls.Add(this.CB_I2OF5);
            this.Tab_Sym.Controls.Add(this.CB_CODE11);
            this.Tab_Sym.Controls.Add(this.CB_CODE35);
            this.Tab_Sym.Controls.Add(this.CB_CODE93);
            this.Tab_Sym.Controls.Add(this.CB_UCCEAN128);
            this.Tab_Sym.Controls.Add(this.CB_CODE128);
            this.Tab_Sym.Controls.Add(this.CB_PZN);
            this.Tab_Sym.Controls.Add(this.CB_CODE32);
            this.Tab_Sym.Controls.Add(this.CB_CODE39);
            this.Tab_Sym.Controls.Add(this.CB_EAN8);
            this.Tab_Sym.Controls.Add(this.CB_BOOKLAND);
            this.Tab_Sym.Controls.Add(this.CB_EAN13);
            this.Tab_Sym.Controls.Add(this.CB_UPCE);
            this.Tab_Sym.Controls.Add(this.CB_UPCA);
            this.Tab_Sym.Location = new System.Drawing.Point(4, 25);
            this.Tab_Sym.Name = "Tab_Sym";
            this.Tab_Sym.Size = new System.Drawing.Size(232, 250);
            this.Tab_Sym.Text = "Symbology";
            // 
            // Btn_SymCancel
            // 
            this.Btn_SymCancel.Location = new System.Drawing.Point(122, 204);
            this.Btn_SymCancel.Name = "Btn_SymCancel";
            this.Btn_SymCancel.Size = new System.Drawing.Size(99, 28);
            this.Btn_SymCancel.TabIndex = 21;
            this.Btn_SymCancel.Text = "Cancel";
            this.Btn_SymCancel.Click += new System.EventHandler(this.Btn_SymCancel_Click);
            // 
            // Btn_SymConfirm
            // 
            this.Btn_SymConfirm.Location = new System.Drawing.Point(6, 204);
            this.Btn_SymConfirm.Name = "Btn_SymConfirm";
            this.Btn_SymConfirm.Size = new System.Drawing.Size(99, 29);
            this.Btn_SymConfirm.TabIndex = 20;
            this.Btn_SymConfirm.Text = "Confirm";
            this.Btn_SymConfirm.Click += new System.EventHandler(this.Btn_SymConfirm_Click);
            // 
            // CB_GS1EXP
            // 
            this.CB_GS1EXP.Location = new System.Drawing.Point(122, 174);
            this.CB_GS1EXP.Name = "CB_GS1EXP";
            this.CB_GS1EXP.Size = new System.Drawing.Size(100, 20);
            this.CB_GS1EXP.TabIndex = 19;
            this.CB_GS1EXP.Text = "GS1_EXP";
            // 
            // CB_GS1LIM
            // 
            this.CB_GS1LIM.Location = new System.Drawing.Point(122, 155);
            this.CB_GS1LIM.Name = "CB_GS1LIM";
            this.CB_GS1LIM.Size = new System.Drawing.Size(100, 20);
            this.CB_GS1LIM.TabIndex = 18;
            this.CB_GS1LIM.Text = "GS1_LIM";
            // 
            // CB_GS1
            // 
            this.CB_GS1.Location = new System.Drawing.Point(122, 136);
            this.CB_GS1.Name = "CB_GS1";
            this.CB_GS1.Size = new System.Drawing.Size(100, 20);
            this.CB_GS1.TabIndex = 17;
            this.CB_GS1.Text = "GS1";
            // 
            // CB_CODABAR
            // 
            this.CB_CODABAR.Location = new System.Drawing.Point(122, 117);
            this.CB_CODABAR.Name = "CB_CODABAR";
            this.CB_CODABAR.Size = new System.Drawing.Size(100, 20);
            this.CB_CODABAR.TabIndex = 16;
            this.CB_CODABAR.Text = "CODABAR";
            // 
            // CB_PLESSEY
            // 
            this.CB_PLESSEY.Location = new System.Drawing.Point(122, 98);
            this.CB_PLESSEY.Name = "CB_PLESSEY";
            this.CB_PLESSEY.Size = new System.Drawing.Size(100, 20);
            this.CB_PLESSEY.TabIndex = 15;
            this.CB_PLESSEY.Text = "PLESSEY";
            // 
            // CB_MSI
            // 
            this.CB_MSI.Location = new System.Drawing.Point(122, 79);
            this.CB_MSI.Name = "CB_MSI";
            this.CB_MSI.Size = new System.Drawing.Size(100, 20);
            this.CB_MSI.TabIndex = 14;
            this.CB_MSI.Text = "MSI";
            // 
            // CB_I2OF5
            // 
            this.CB_I2OF5.Location = new System.Drawing.Point(122, 60);
            this.CB_I2OF5.Name = "CB_I2OF5";
            this.CB_I2OF5.Size = new System.Drawing.Size(100, 20);
            this.CB_I2OF5.TabIndex = 13;
            this.CB_I2OF5.Text = "I2OF5";
            // 
            // CB_CODE11
            // 
            this.CB_CODE11.Location = new System.Drawing.Point(122, 41);
            this.CB_CODE11.Name = "CB_CODE11";
            this.CB_CODE11.Size = new System.Drawing.Size(100, 20);
            this.CB_CODE11.TabIndex = 12;
            this.CB_CODE11.Text = "CODE11";
            // 
            // CB_CODE35
            // 
            this.CB_CODE35.Location = new System.Drawing.Point(122, 22);
            this.CB_CODE35.Name = "CB_CODE35";
            this.CB_CODE35.Size = new System.Drawing.Size(100, 20);
            this.CB_CODE35.TabIndex = 11;
            this.CB_CODE35.Text = "CODE35";
            // 
            // CB_CODE93
            // 
            this.CB_CODE93.Location = new System.Drawing.Point(122, 3);
            this.CB_CODE93.Name = "CB_CODE93";
            this.CB_CODE93.Size = new System.Drawing.Size(100, 20);
            this.CB_CODE93.TabIndex = 10;
            this.CB_CODE93.Text = "CODE93";
            // 
            // CB_UCCEAN128
            // 
            this.CB_UCCEAN128.Location = new System.Drawing.Point(6, 174);
            this.CB_UCCEAN128.Name = "CB_UCCEAN128";
            this.CB_UCCEAN128.Size = new System.Drawing.Size(118, 20);
            this.CB_UCCEAN128.TabIndex = 9;
            this.CB_UCCEAN128.Text = "UCC/EAN-128";
            // 
            // CB_CODE128
            // 
            this.CB_CODE128.Location = new System.Drawing.Point(6, 155);
            this.CB_CODE128.Name = "CB_CODE128";
            this.CB_CODE128.Size = new System.Drawing.Size(100, 20);
            this.CB_CODE128.TabIndex = 8;
            this.CB_CODE128.Text = "CODE128";
            // 
            // CB_PZN
            // 
            this.CB_PZN.Location = new System.Drawing.Point(6, 136);
            this.CB_PZN.Name = "CB_PZN";
            this.CB_PZN.Size = new System.Drawing.Size(100, 20);
            this.CB_PZN.TabIndex = 7;
            this.CB_PZN.Text = "PZN";
            // 
            // CB_CODE32
            // 
            this.CB_CODE32.Location = new System.Drawing.Point(6, 117);
            this.CB_CODE32.Name = "CB_CODE32";
            this.CB_CODE32.Size = new System.Drawing.Size(100, 20);
            this.CB_CODE32.TabIndex = 6;
            this.CB_CODE32.Text = "CODE32";
            // 
            // CB_CODE39
            // 
            this.CB_CODE39.Location = new System.Drawing.Point(6, 98);
            this.CB_CODE39.Name = "CB_CODE39";
            this.CB_CODE39.Size = new System.Drawing.Size(100, 20);
            this.CB_CODE39.TabIndex = 5;
            this.CB_CODE39.Text = "CODE39";
            // 
            // CB_EAN8
            // 
            this.CB_EAN8.Location = new System.Drawing.Point(6, 79);
            this.CB_EAN8.Name = "CB_EAN8";
            this.CB_EAN8.Size = new System.Drawing.Size(100, 20);
            this.CB_EAN8.TabIndex = 4;
            this.CB_EAN8.Text = "EAN-8";
            // 
            // CB_BOOKLAND
            // 
            this.CB_BOOKLAND.Location = new System.Drawing.Point(6, 60);
            this.CB_BOOKLAND.Name = "CB_BOOKLAND";
            this.CB_BOOKLAND.Size = new System.Drawing.Size(100, 20);
            this.CB_BOOKLAND.TabIndex = 3;
            this.CB_BOOKLAND.Text = "BOOKLAND";
            // 
            // CB_EAN13
            // 
            this.CB_EAN13.Location = new System.Drawing.Point(6, 41);
            this.CB_EAN13.Name = "CB_EAN13";
            this.CB_EAN13.Size = new System.Drawing.Size(100, 20);
            this.CB_EAN13.TabIndex = 2;
            this.CB_EAN13.Text = "EAN-13";
            // 
            // CB_UPCE
            // 
            this.CB_UPCE.Location = new System.Drawing.Point(6, 22);
            this.CB_UPCE.Name = "CB_UPCE";
            this.CB_UPCE.Size = new System.Drawing.Size(100, 20);
            this.CB_UPCE.TabIndex = 1;
            this.CB_UPCE.Text = "UPC-E";
            // 
            // CB_UPCA
            // 
            this.CB_UPCA.Location = new System.Drawing.Point(6, 3);
            this.CB_UPCA.Name = "CB_UPCA";
            this.CB_UPCA.Size = new System.Drawing.Size(100, 20);
            this.CB_UPCA.TabIndex = 0;
            this.CB_UPCA.Text = "UPC-A";
            // 
            // Tab_Option
            // 
            this.Tab_Option.BackColor = System.Drawing.SystemColors.Window;
            this.Tab_Option.Controls.Add(this.Btn_OpCancel);
            this.Tab_Option.Controls.Add(this.Btn_OpConfirm);
            this.Tab_Option.Controls.Add(this.panel3);
            this.Tab_Option.Controls.Add(this.panel2);
            this.Tab_Option.Controls.Add(this.panel1);
            this.Tab_Option.Location = new System.Drawing.Point(4, 25);
            this.Tab_Option.Name = "Tab_Option";
            this.Tab_Option.Size = new System.Drawing.Size(232, 250);
            this.Tab_Option.Text = "Option";
            // 
            // Btn_OpCancel
            // 
            this.Btn_OpCancel.Location = new System.Drawing.Point(123, 199);
            this.Btn_OpCancel.Name = "Btn_OpCancel";
            this.Btn_OpCancel.Size = new System.Drawing.Size(99, 38);
            this.Btn_OpCancel.TabIndex = 4;
            this.Btn_OpCancel.Text = "Cancel";
            this.Btn_OpCancel.Click += new System.EventHandler(this.Btn_OpCancel_Click);
            // 
            // Btn_OpConfirm
            // 
            this.Btn_OpConfirm.Location = new System.Drawing.Point(9, 199);
            this.Btn_OpConfirm.Name = "Btn_OpConfirm";
            this.Btn_OpConfirm.Size = new System.Drawing.Size(99, 38);
            this.Btn_OpConfirm.TabIndex = 3;
            this.Btn_OpConfirm.Text = "Confirm";
            this.Btn_OpConfirm.Click += new System.EventHandler(this.Btn_OpConfirm_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Window;
            this.panel3.Controls.Add(this.CB_AIMID);
            this.panel3.Controls.Add(this.CB_HIGHFILTER);
            this.panel3.Controls.Add(this.CB_WIDESCAN);
            this.panel3.Location = new System.Drawing.Point(6, 124);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(219, 55);
            // 
            // CB_AIMID
            // 
            this.CB_AIMID.Location = new System.Drawing.Point(8, 30);
            this.CB_AIMID.Name = "CB_AIMID";
            this.CB_AIMID.Size = new System.Drawing.Size(157, 20);
            this.CB_AIMID.TabIndex = 2;
            this.CB_AIMID.Text = "Transmit AimID";
            // 
            // CB_HIGHFILTER
            // 
            this.CB_HIGHFILTER.Location = new System.Drawing.Point(114, 6);
            this.CB_HIGHFILTER.Name = "CB_HIGHFILTER";
            this.CB_HIGHFILTER.Size = new System.Drawing.Size(100, 20);
            this.CB_HIGHFILTER.TabIndex = 1;
            this.CB_HIGHFILTER.Text = "HighFilter";
            // 
            // CB_WIDESCAN
            // 
            this.CB_WIDESCAN.Location = new System.Drawing.Point(8, 6);
            this.CB_WIDESCAN.Name = "CB_WIDESCAN";
            this.CB_WIDESCAN.Size = new System.Drawing.Size(100, 20);
            this.CB_WIDESCAN.TabIndex = 0;
            this.CB_WIDESCAN.Text = "WideScan";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Window;
            this.panel2.Controls.Add(this.CB_SECLEVEL);
            this.panel2.Controls.Add(this.CB_TIMEOUT);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(6, 43);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(220, 72);
            // 
            // CB_SECLEVEL
            // 
            this.CB_SECLEVEL.Items.Add("1");
            this.CB_SECLEVEL.Items.Add("2");
            this.CB_SECLEVEL.Items.Add("3");
            this.CB_SECLEVEL.Items.Add("4");
            this.CB_SECLEVEL.Location = new System.Drawing.Point(102, 37);
            this.CB_SECLEVEL.Name = "CB_SECLEVEL";
            this.CB_SECLEVEL.Size = new System.Drawing.Size(103, 23);
            this.CB_SECLEVEL.TabIndex = 3;
            // 
            // CB_TIMEOUT
            // 
            this.CB_TIMEOUT.Items.Add("1");
            this.CB_TIMEOUT.Items.Add("2");
            this.CB_TIMEOUT.Items.Add("3");
            this.CB_TIMEOUT.Items.Add("4");
            this.CB_TIMEOUT.Items.Add("5");
            this.CB_TIMEOUT.Items.Add("6");
            this.CB_TIMEOUT.Items.Add("7");
            this.CB_TIMEOUT.Items.Add("8");
            this.CB_TIMEOUT.Items.Add("9");
            this.CB_TIMEOUT.Items.Add("10");
            this.CB_TIMEOUT.Location = new System.Drawing.Point(102, 8);
            this.CB_TIMEOUT.Name = "CB_TIMEOUT";
            this.CB_TIMEOUT.Size = new System.Drawing.Size(103, 23);
            this.CB_TIMEOUT.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(8, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 20);
            this.label4.Text = "Security Level";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(8, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 18);
            this.label3.Text = "TimeOut";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Window;
            this.panel1.Controls.Add(this.RD_SYNC);
            this.panel1.Controls.Add(this.RD_ASYNC);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(6, 8);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(221, 26);
            // 
            // RD_SYNC
            // 
            this.RD_SYNC.Location = new System.Drawing.Point(152, 5);
            this.RD_SYNC.Name = "RD_SYNC";
            this.RD_SYNC.Size = new System.Drawing.Size(57, 20);
            this.RD_SYNC.TabIndex = 2;
            this.RD_SYNC.Text = "Sync";
            // 
            // RD_ASYNC
            // 
            this.RD_ASYNC.Location = new System.Drawing.Point(83, 5);
            this.RD_ASYNC.Name = "RD_ASYNC";
            this.RD_ASYNC.Size = new System.Drawing.Size(63, 20);
            this.RD_ASYNC.TabIndex = 1;
            this.RD_ASYNC.Text = "ASync";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(8, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 17);
            this.label2.Text = "Sync Mode";
            // 
            // Tab_Detail
            // 
            this.Tab_Detail.BackColor = System.Drawing.Color.White;
            this.Tab_Detail.Controls.Add(this.BTN_DECANCEL);
            this.Tab_Detail.Controls.Add(this.BTN_TELEPEN);
            this.Tab_Detail.Controls.Add(this.BTN_GS1);
            this.Tab_Detail.Controls.Add(this.BTN_PLESSEY);
            this.Tab_Detail.Controls.Add(this.BTN_MSI);
            this.Tab_Detail.Controls.Add(this.BTN_CODABAR);
            this.Tab_Detail.Controls.Add(this.BTN_I2OF5);
            this.Tab_Detail.Controls.Add(this.BTN_CODE11);
            this.Tab_Detail.Controls.Add(this.BTN_CODE35);
            this.Tab_Detail.Controls.Add(this.BTN_CODE93);
            this.Tab_Detail.Controls.Add(this.BTN_CODE128);
            this.Tab_Detail.Controls.Add(this.BTN_CODE39);
            this.Tab_Detail.Controls.Add(this.BTN_EAN8);
            this.Tab_Detail.Controls.Add(this.BTN_EAN13);
            this.Tab_Detail.Controls.Add(this.BTN_UPCE);
            this.Tab_Detail.Controls.Add(this.BTN_UPCA);
            this.Tab_Detail.Location = new System.Drawing.Point(4, 25);
            this.Tab_Detail.Name = "Tab_Detail";
            this.Tab_Detail.Size = new System.Drawing.Size(232, 250);
            this.Tab_Detail.Text = "Detail";
            // 
            // BTN_DECANCEL
            // 
            this.BTN_DECANCEL.Location = new System.Drawing.Point(64, 194);
            this.BTN_DECANCEL.Name = "BTN_DECANCEL";
            this.BTN_DECANCEL.Size = new System.Drawing.Size(104, 36);
            this.BTN_DECANCEL.TabIndex = 16;
            this.BTN_DECANCEL.Text = "GO MAIN PAGE";
            this.BTN_DECANCEL.Click += new System.EventHandler(this.BTN_DECANCEL_Click);
            // 
            // BTN_TELEPEN
            // 
            this.BTN_TELEPEN.Location = new System.Drawing.Point(156, 150);
            this.BTN_TELEPEN.Name = "BTN_TELEPEN";
            this.BTN_TELEPEN.Size = new System.Drawing.Size(69, 30);
            this.BTN_TELEPEN.TabIndex = 14;
            this.BTN_TELEPEN.Text = "TELEPEN";
            this.BTN_TELEPEN.Click += new System.EventHandler(this.BTN_TELEPEN_Click);
            // 
            // BTN_GS1
            // 
            this.BTN_GS1.Location = new System.Drawing.Point(81, 150);
            this.BTN_GS1.Name = "BTN_GS1";
            this.BTN_GS1.Size = new System.Drawing.Size(69, 30);
            this.BTN_GS1.TabIndex = 13;
            this.BTN_GS1.Text = "GS1";
            this.BTN_GS1.Click += new System.EventHandler(this.BTN_GS1_Click);
            // 
            // BTN_PLESSEY
            // 
            this.BTN_PLESSEY.Location = new System.Drawing.Point(6, 150);
            this.BTN_PLESSEY.Name = "BTN_PLESSEY";
            this.BTN_PLESSEY.Size = new System.Drawing.Size(69, 30);
            this.BTN_PLESSEY.TabIndex = 12;
            this.BTN_PLESSEY.Text = "PLESSEY";
            this.BTN_PLESSEY.Click += new System.EventHandler(this.BTN_PLESSEY_Click);
            // 
            // BTN_MSI
            // 
            this.BTN_MSI.Location = new System.Drawing.Point(156, 114);
            this.BTN_MSI.Name = "BTN_MSI";
            this.BTN_MSI.Size = new System.Drawing.Size(69, 30);
            this.BTN_MSI.TabIndex = 11;
            this.BTN_MSI.Text = "MSI";
            this.BTN_MSI.Click += new System.EventHandler(this.BTN_MSI_Click);
            // 
            // BTN_CODABAR
            // 
            this.BTN_CODABAR.Location = new System.Drawing.Point(81, 114);
            this.BTN_CODABAR.Name = "BTN_CODABAR";
            this.BTN_CODABAR.Size = new System.Drawing.Size(69, 30);
            this.BTN_CODABAR.TabIndex = 10;
            this.BTN_CODABAR.Text = "CODABAR";
            this.BTN_CODABAR.Click += new System.EventHandler(this.BTN_CODABAR_Click);
            // 
            // BTN_I2OF5
            // 
            this.BTN_I2OF5.Location = new System.Drawing.Point(6, 114);
            this.BTN_I2OF5.Name = "BTN_I2OF5";
            this.BTN_I2OF5.Size = new System.Drawing.Size(69, 30);
            this.BTN_I2OF5.TabIndex = 9;
            this.BTN_I2OF5.Text = "I2OF5";
            this.BTN_I2OF5.Click += new System.EventHandler(this.BTN_I2OF5_Click);
            // 
            // BTN_CODE11
            // 
            this.BTN_CODE11.Location = new System.Drawing.Point(156, 78);
            this.BTN_CODE11.Name = "BTN_CODE11";
            this.BTN_CODE11.Size = new System.Drawing.Size(69, 30);
            this.BTN_CODE11.TabIndex = 8;
            this.BTN_CODE11.Text = "CODE11";
            this.BTN_CODE11.Click += new System.EventHandler(this.BTN_CODE11_Click);
            // 
            // BTN_CODE35
            // 
            this.BTN_CODE35.Location = new System.Drawing.Point(81, 78);
            this.BTN_CODE35.Name = "BTN_CODE35";
            this.BTN_CODE35.Size = new System.Drawing.Size(69, 30);
            this.BTN_CODE35.TabIndex = 7;
            this.BTN_CODE35.Text = "CODE35";
            this.BTN_CODE35.Click += new System.EventHandler(this.BTN_CODE35_Click);
            // 
            // BTN_CODE93
            // 
            this.BTN_CODE93.Location = new System.Drawing.Point(6, 78);
            this.BTN_CODE93.Name = "BTN_CODE93";
            this.BTN_CODE93.Size = new System.Drawing.Size(69, 30);
            this.BTN_CODE93.TabIndex = 6;
            this.BTN_CODE93.Text = "CODE93";
            this.BTN_CODE93.Click += new System.EventHandler(this.BTN_CODE93_Click);
            // 
            // BTN_CODE128
            // 
            this.BTN_CODE128.Location = new System.Drawing.Point(156, 42);
            this.BTN_CODE128.Name = "BTN_CODE128";
            this.BTN_CODE128.Size = new System.Drawing.Size(69, 30);
            this.BTN_CODE128.TabIndex = 5;
            this.BTN_CODE128.Text = "CODE128";
            this.BTN_CODE128.Click += new System.EventHandler(this.BTN_CODE128_Click);
            // 
            // BTN_CODE39
            // 
            this.BTN_CODE39.Location = new System.Drawing.Point(81, 42);
            this.BTN_CODE39.Name = "BTN_CODE39";
            this.BTN_CODE39.Size = new System.Drawing.Size(69, 30);
            this.BTN_CODE39.TabIndex = 4;
            this.BTN_CODE39.Text = "CODE39";
            this.BTN_CODE39.Click += new System.EventHandler(this.BTN_CODE39_Click);
            // 
            // BTN_EAN8
            // 
            this.BTN_EAN8.Location = new System.Drawing.Point(6, 42);
            this.BTN_EAN8.Name = "BTN_EAN8";
            this.BTN_EAN8.Size = new System.Drawing.Size(69, 30);
            this.BTN_EAN8.TabIndex = 3;
            this.BTN_EAN8.Text = "EAN-8";
            this.BTN_EAN8.Click += new System.EventHandler(this.BTN_EAN8_Click);
            // 
            // BTN_EAN13
            // 
            this.BTN_EAN13.Location = new System.Drawing.Point(156, 6);
            this.BTN_EAN13.Name = "BTN_EAN13";
            this.BTN_EAN13.Size = new System.Drawing.Size(69, 30);
            this.BTN_EAN13.TabIndex = 2;
            this.BTN_EAN13.Text = "EAN-13";
            this.BTN_EAN13.Click += new System.EventHandler(this.BTN_EAN13_Click);
            // 
            // BTN_UPCE
            // 
            this.BTN_UPCE.Location = new System.Drawing.Point(81, 6);
            this.BTN_UPCE.Name = "BTN_UPCE";
            this.BTN_UPCE.Size = new System.Drawing.Size(69, 30);
            this.BTN_UPCE.TabIndex = 1;
            this.BTN_UPCE.Text = "UPC-E";
            this.BTN_UPCE.Click += new System.EventHandler(this.BTN_UPCE_Click);
            // 
            // BTN_UPCA
            // 
            this.BTN_UPCA.Location = new System.Drawing.Point(6, 6);
            this.BTN_UPCA.Name = "BTN_UPCA";
            this.BTN_UPCA.Size = new System.Drawing.Size(69, 30);
            this.BTN_UPCA.TabIndex = 0;
            this.BTN_UPCA.Text = "UPC-A";
            this.BTN_UPCA.Click += new System.EventHandler(this.BTN_UPCA_Click);
            // 
            // M3Scanner
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.ClientSize = new System.Drawing.Size(638, 455);
            this.Controls.Add(this.Tab_M3Scanner);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "M3Scanner";
            this.Text = "M3ScanTest_Net";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.M3Scanner_Load);
            this.Closing += new System.ComponentModel.CancelEventHandler(this.M3Scanner_Closing);
            this.Tab_M3Scanner.ResumeLayout(false);
            this.Tab_Main.ResumeLayout(false);
            this.Tab_Sym.ResumeLayout(false);
            this.Tab_Option.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.Tab_Detail.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl Tab_M3Scanner;
        private System.Windows.Forms.TabPage Tab_Main;
        private System.Windows.Forms.TabPage Tab_Sym;
        private System.Windows.Forms.ListView LV_SCANDATA;
        private System.Windows.Forms.Button Btn_Close;
        private System.Windows.Forms.Button Btn_Info;
        private System.Windows.Forms.Button Btn_ScanCancel;
        private System.Windows.Forms.Button Btn_Scan;
        private System.Windows.Forms.TabPage Tab_Option;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ColumnHeader BarType;
        private System.Windows.Forms.ColumnHeader BarData;
        private System.Windows.Forms.CheckBox CB_CODE128;
        private System.Windows.Forms.CheckBox CB_PZN;
        private System.Windows.Forms.CheckBox CB_CODE32;
        private System.Windows.Forms.CheckBox CB_CODE39;
        private System.Windows.Forms.CheckBox CB_EAN8;
        private System.Windows.Forms.CheckBox CB_BOOKLAND;
        private System.Windows.Forms.CheckBox CB_EAN13;
        private System.Windows.Forms.CheckBox CB_UPCE;
        private System.Windows.Forms.CheckBox CB_UPCA;
        private System.Windows.Forms.Button Btn_SymCancel;
        private System.Windows.Forms.Button Btn_SymConfirm;
        private System.Windows.Forms.CheckBox CB_GS1EXP;
        private System.Windows.Forms.CheckBox CB_GS1LIM;
        private System.Windows.Forms.CheckBox CB_GS1;
        private System.Windows.Forms.CheckBox CB_CODABAR;
        private System.Windows.Forms.CheckBox CB_PLESSEY;
        private System.Windows.Forms.CheckBox CB_MSI;
        private System.Windows.Forms.CheckBox CB_I2OF5;
        private System.Windows.Forms.CheckBox CB_CODE11;
        private System.Windows.Forms.CheckBox CB_CODE35;
        private System.Windows.Forms.CheckBox CB_CODE93;
        private System.Windows.Forms.CheckBox CB_UCCEAN128;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton RD_SYNC;
        private System.Windows.Forms.RadioButton RD_ASYNC;
        private System.Windows.Forms.Button Btn_OpCancel;
        private System.Windows.Forms.Button Btn_OpConfirm;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.CheckBox CB_HIGHFILTER;
        private System.Windows.Forms.CheckBox CB_WIDESCAN;
        private System.Windows.Forms.ComboBox CB_SECLEVEL;
        private System.Windows.Forms.ComboBox CB_TIMEOUT;
        private System.Windows.Forms.TabPage Tab_Detail;
        private System.Windows.Forms.CheckBox CB_AIMID;
        private System.Windows.Forms.Button BTN_TELEPEN;
        private System.Windows.Forms.Button BTN_GS1;
        private System.Windows.Forms.Button BTN_PLESSEY;
        private System.Windows.Forms.Button BTN_MSI;
        private System.Windows.Forms.Button BTN_CODABAR;
        private System.Windows.Forms.Button BTN_I2OF5;
        private System.Windows.Forms.Button BTN_CODE11;
        private System.Windows.Forms.Button BTN_CODE35;
        private System.Windows.Forms.Button BTN_CODE93;
        private System.Windows.Forms.Button BTN_CODE128;
        private System.Windows.Forms.Button BTN_CODE39;
        private System.Windows.Forms.Button BTN_EAN8;
        private System.Windows.Forms.Button BTN_EAN13;
        private System.Windows.Forms.Button BTN_UPCE;
        private System.Windows.Forms.Button BTN_UPCA;
        private System.Windows.Forms.Button BTN_DECANCEL;
    }
}

