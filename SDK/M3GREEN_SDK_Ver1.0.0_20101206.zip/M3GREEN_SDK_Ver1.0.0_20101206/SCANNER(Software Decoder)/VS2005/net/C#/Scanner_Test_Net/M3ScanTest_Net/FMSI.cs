﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace M3ScanTest_Net
{
    public partial class FMSI : Form
    {
        public bool m_bEnable;
        public bool m_bCDV;
        public bool m_bXCD;
        public int m_nMinLen;
        public int m_nMaxLen;

        public FMSI()
        {
            InitializeComponent();
        }

        private void FMSI_Load(object sender, EventArgs e)
        {
            CB_MSI_ENABLE.Checked = m_bEnable;
            CB_MSI_CDV.Checked = m_bCDV;
            CB_MSI_XCD.Checked = m_bXCD;

            TEXT_MINLEN.Text = m_nMinLen.ToString();
            TEXT_MAXLEN.Text = m_nMaxLen.ToString(); 
        }

        private void BTN_OK_Click(object sender, EventArgs e)
        {
            m_bEnable = CB_MSI_ENABLE.Checked;
            m_bCDV = CB_MSI_CDV.Checked;
            m_bXCD = CB_MSI_XCD.Checked;

            m_nMinLen = Int32.Parse(TEXT_MINLEN.Text);
            m_nMaxLen = Int32.Parse(TEXT_MAXLEN.Text);

            this.DialogResult = DialogResult.OK;
        }

        private void BTN_CANCEL_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}