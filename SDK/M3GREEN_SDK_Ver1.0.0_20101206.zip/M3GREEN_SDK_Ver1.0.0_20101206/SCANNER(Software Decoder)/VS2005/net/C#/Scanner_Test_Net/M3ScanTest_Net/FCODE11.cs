﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace M3ScanTest_Net
{
    public partial class FCODE11 : Form
    {
        public bool m_bEnable;
        public bool m_bXCD;
        public int m_nCDV;
        public int m_nMinLen;
        public int m_nMaxLen;

        public FCODE11()
        {
            InitializeComponent();
        }

        private void FCODE11_Load(object sender, EventArgs e)
        {
            CB_CODE11_ENABLE.Checked = m_bEnable;
            CB_CODE11_XCD.Checked = m_bXCD;
            if (m_nCDV == 0)
                RD_CODE11_NOCDV.Checked = true;
            else if (m_nCDV == 2)
                RD_CODE11_2CDV.Checked = true;
            else
                RD_CODE11_1CDV.Checked = true;

            TEXT_MINLEN.Text = m_nMinLen.ToString();
            TEXT_MAXLEN.Text = m_nMaxLen.ToString();
        }

        private void BTN_OK_Click(object sender, EventArgs e)
        {
            m_bEnable = CB_CODE11_ENABLE.Checked;
            m_bXCD = CB_CODE11_XCD.Checked;
            if (RD_CODE11_NOCDV.Checked)
                m_nCDV = 0;
            else if (RD_CODE11_2CDV.Checked)
                m_nCDV = 2;
            else
                m_nCDV = 1;

            m_nMinLen = Int32.Parse(TEXT_MINLEN.Text);
            m_nMaxLen = Int32.Parse(TEXT_MAXLEN.Text);


            this.DialogResult = DialogResult.OK;
        }

        private void BTN_CANCEL_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}