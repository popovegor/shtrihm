﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace M3ScanTest_Net
{
    public partial class FUPCE : Form
    {
        public bool m_bEnable;
        public bool m_bXNum;
        public bool m_bXCD;
        public int m_nConvert;

        public FUPCE()
        {
            InitializeComponent();
        }

        private void FUPCE_Load(object sender, EventArgs e)
        {
            CB_UPCE_ENABLE.Checked = m_bEnable;
            CB_UPCE_XNUM.Checked = m_bXNum;
            CB_UPCE_XCD.Checked = m_bXCD;

            if (m_nConvert == 1)
                RD_UPCE_AS_UPCA.Checked = true;
            else if (m_nConvert == 2)
                RD_UPCE_AS_EAN13.Checked = true;
            else
                RD_UPCE_NOTCON.Checked = true;       
        }

        private void BTN_OK_Click(object sender, EventArgs e)
        {
            m_bEnable = CB_UPCE_ENABLE.Checked;
            m_bXNum = CB_UPCE_XNUM.Checked;
            m_bXCD = CB_UPCE_XCD.Checked;

            if (RD_UPCE_AS_UPCA.Checked)
                m_nConvert = 1;
            else if (RD_UPCE_AS_EAN13.Checked)
                m_nConvert = 2;
            else
                m_nConvert = 0;

            this.DialogResult = DialogResult.OK;
        }

        private void BTN_CANCEL_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

    }
}