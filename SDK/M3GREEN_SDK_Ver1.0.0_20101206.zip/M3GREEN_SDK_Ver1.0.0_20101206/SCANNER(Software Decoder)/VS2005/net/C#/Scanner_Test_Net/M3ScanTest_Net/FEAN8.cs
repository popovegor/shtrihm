﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace M3ScanTest_Net
{
    public partial class FEAN8 : Form
    {
        public bool m_bEnable;
        public bool m_bXCD;
        public bool m_bEAN8asEAN13;

        public FEAN8()
        {
            InitializeComponent();
        }

        private void FEAN8_Load(object sender, EventArgs e)
        {
            CB_EAN8_ENABLE.Checked = m_bEnable;
            CB_EAN8_XCD.Checked = m_bXCD;
            CB_EAN8_AS_EAN13.Checked = m_bEAN8asEAN13;
        }

        private void BTN_OK_Click(object sender, EventArgs e)
        {
            m_bEnable = CB_EAN8_ENABLE.Checked;
            m_bXCD = CB_EAN8_XCD.Checked;
            m_bEAN8asEAN13 = CB_EAN8_AS_EAN13.Checked;

            this.DialogResult = DialogResult.OK;
        }

        private void BTN_CANCEL_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

    }
}