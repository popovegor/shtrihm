﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace M3ScanTest_Net
{
    public partial class FCODE39 : Form
    {
        public bool m_bEnable;
        public bool m_bCode32;
        public bool m_bPzn;
        public bool m_bCDV;
        public bool m_bXCD;
        public bool m_bFullASCII;
        public int m_nMinLen;
        public int m_nMaxLen;

        public FCODE39()
        {
            InitializeComponent();
        }

        private void FCODE39_Load(object sender, EventArgs e)
        {
            CB_CODE39_ENABLE.Checked = m_bEnable;
            CB_CODE32_ENABLE.Checked = m_bCode32;
            CB_PZN_ENABLE.Checked = m_bPzn;
            CB_CODE39_CDV.Checked = m_bCDV;
            CB_CODE39_XCD.Checked = m_bXCD;
            CB_CODE39_FULLASCII.Checked = m_bFullASCII;

            TEXT_MINLEN.Text = m_nMinLen.ToString();
            TEXT_MAXLEN.Text = m_nMaxLen.ToString();      
        }

        private void BTN_OK_Click(object sender, EventArgs e)
        {
            m_bEnable = CB_CODE39_ENABLE.Checked;
            m_bCode32 = CB_CODE32_ENABLE.Checked;
            m_bPzn = CB_PZN_ENABLE.Checked;
            m_bCDV = CB_CODE39_CDV.Checked;
            m_bXCD = CB_CODE39_XCD.Checked;
            m_bFullASCII = CB_CODE39_FULLASCII.Checked;

            m_nMinLen = Int32.Parse(TEXT_MINLEN.Text);
            m_nMaxLen = Int32.Parse(TEXT_MAXLEN.Text);

            this.DialogResult = DialogResult.OK;
        }

        private void BTN_CANCEL_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}