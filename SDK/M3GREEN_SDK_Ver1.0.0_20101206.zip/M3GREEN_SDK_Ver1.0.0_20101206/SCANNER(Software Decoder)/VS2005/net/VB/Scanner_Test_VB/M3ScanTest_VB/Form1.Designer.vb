<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class M3Scanner
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Private mainMenu1 As System.Windows.Forms.MainMenu

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.Tab_M3Scanner = New System.Windows.Forms.TabControl
        Me.Tab_Main = New System.Windows.Forms.TabPage
        Me.Label1 = New System.Windows.Forms.Label
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Info = New System.Windows.Forms.Button
        Me.Btn_ScanCancel = New System.Windows.Forms.Button
        Me.Btn_Scan = New System.Windows.Forms.Button
        Me.LV_SCANDATA = New System.Windows.Forms.ListView
        Me.BarType = New System.Windows.Forms.ColumnHeader
        Me.BarData = New System.Windows.Forms.ColumnHeader
        Me.Tab_Sym = New System.Windows.Forms.TabPage
        Me.Btn_SymCancel = New System.Windows.Forms.Button
        Me.Btn_SymConfirm = New System.Windows.Forms.Button
        Me.CB_GS1EXP = New System.Windows.Forms.CheckBox
        Me.CB_GS1LIM = New System.Windows.Forms.CheckBox
        Me.CB_GS1 = New System.Windows.Forms.CheckBox
        Me.CB_CODABAR = New System.Windows.Forms.CheckBox
        Me.CB_PLESSEY = New System.Windows.Forms.CheckBox
        Me.CB_MSI = New System.Windows.Forms.CheckBox
        Me.CB_I2OF5 = New System.Windows.Forms.CheckBox
        Me.CB_CODE11 = New System.Windows.Forms.CheckBox
        Me.CB_CODE35 = New System.Windows.Forms.CheckBox
        Me.CB_CODE93 = New System.Windows.Forms.CheckBox
        Me.CB_UCCEAN128 = New System.Windows.Forms.CheckBox
        Me.CB_CODE128 = New System.Windows.Forms.CheckBox
        Me.CB_PZN = New System.Windows.Forms.CheckBox
        Me.CB_CODE32 = New System.Windows.Forms.CheckBox
        Me.CB_CODE39 = New System.Windows.Forms.CheckBox
        Me.CB_EAN8 = New System.Windows.Forms.CheckBox
        Me.CB_BOOKLAND = New System.Windows.Forms.CheckBox
        Me.CB_EAN13 = New System.Windows.Forms.CheckBox
        Me.CB_UPCE = New System.Windows.Forms.CheckBox
        Me.CB_UPCA = New System.Windows.Forms.CheckBox
        Me.Tab_Option = New System.Windows.Forms.TabPage
        Me.Btn_OpCancel = New System.Windows.Forms.Button
        Me.Btn_OpConfirm = New System.Windows.Forms.Button
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.CB_XCD = New System.Windows.Forms.CheckBox
        Me.CB_HIGHFILTER = New System.Windows.Forms.CheckBox
        Me.CB_WIDESCAN = New System.Windows.Forms.CheckBox
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.CB_SECLEVEL = New System.Windows.Forms.ComboBox
        Me.CB_TIMEOUT = New System.Windows.Forms.ComboBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.RD_SYNC = New System.Windows.Forms.RadioButton
        Me.RD_ASYNC = New System.Windows.Forms.RadioButton
        Me.Label2 = New System.Windows.Forms.Label
        Me.Tab_M3Scanner.SuspendLayout()
        Me.Tab_Main.SuspendLayout()
        Me.Tab_Sym.SuspendLayout()
        Me.Tab_Option.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Tab_M3Scanner
        '
        Me.Tab_M3Scanner.Controls.Add(Me.Tab_Main)
        Me.Tab_M3Scanner.Controls.Add(Me.Tab_Sym)
        Me.Tab_M3Scanner.Controls.Add(Me.Tab_Option)
        Me.Tab_M3Scanner.Location = New System.Drawing.Point(0, 0)
        Me.Tab_M3Scanner.Name = "Tab_M3Scanner"
        Me.Tab_M3Scanner.SelectedIndex = 0
        Me.Tab_M3Scanner.Size = New System.Drawing.Size(239, 272)
        Me.Tab_M3Scanner.TabIndex = 0
        '
        'Tab_Main
        '
        Me.Tab_Main.BackColor = System.Drawing.SystemColors.Window
        Me.Tab_Main.Controls.Add(Me.Label1)
        Me.Tab_Main.Controls.Add(Me.Btn_Close)
        Me.Tab_Main.Controls.Add(Me.Btn_Info)
        Me.Tab_Main.Controls.Add(Me.Btn_ScanCancel)
        Me.Tab_Main.Controls.Add(Me.Btn_Scan)
        Me.Tab_Main.Controls.Add(Me.LV_SCANDATA)
        Me.Tab_Main.Location = New System.Drawing.Point(4, 25)
        Me.Tab_Main.Name = "Tab_Main"
        Me.Tab_Main.Size = New System.Drawing.Size(231, 243)
        Me.Tab_Main.Text = "Main"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(92, 225)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(135, 18)
        Me.Label1.Text = "Ver 2.1.0 (20101027)"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Btn_Close
        '
        Me.Btn_Close.Location = New System.Drawing.Point(118, 200)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(108, 24)
        Me.Btn_Close.TabIndex = 4
        Me.Btn_Close.Text = "Close"
        '
        'Btn_Info
        '
        Me.Btn_Info.Location = New System.Drawing.Point(4, 200)
        Me.Btn_Info.Name = "Btn_Info"
        Me.Btn_Info.Size = New System.Drawing.Size(108, 24)
        Me.Btn_Info.TabIndex = 3
        Me.Btn_Info.Text = "Infomation"
        '
        'Btn_ScanCancel
        '
        Me.Btn_ScanCancel.Location = New System.Drawing.Point(118, 170)
        Me.Btn_ScanCancel.Name = "Btn_ScanCancel"
        Me.Btn_ScanCancel.Size = New System.Drawing.Size(108, 24)
        Me.Btn_ScanCancel.TabIndex = 2
        Me.Btn_ScanCancel.Text = "Scan Cancel"
        '
        'Btn_Scan
        '
        Me.Btn_Scan.Location = New System.Drawing.Point(4, 170)
        Me.Btn_Scan.Name = "Btn_Scan"
        Me.Btn_Scan.Size = New System.Drawing.Size(108, 24)
        Me.Btn_Scan.TabIndex = 1
        Me.Btn_Scan.Text = "Scan"
        '
        'LV_SCANDATA
        '
        Me.LV_SCANDATA.Columns.Add(Me.BarType)
        Me.LV_SCANDATA.Columns.Add(Me.BarData)
        Me.LV_SCANDATA.Location = New System.Drawing.Point(4, 7)
        Me.LV_SCANDATA.Name = "LV_SCANDATA"
        Me.LV_SCANDATA.Size = New System.Drawing.Size(222, 157)
        Me.LV_SCANDATA.TabIndex = 0
        Me.LV_SCANDATA.View = System.Windows.Forms.View.Details
        '
        'BarType
        '
        Me.BarType.Text = "Type"
        Me.BarType.Width = 80
        '
        'BarData
        '
        Me.BarData.Text = "Data"
        Me.BarData.Width = 138
        '
        'Tab_Sym
        '
        Me.Tab_Sym.BackColor = System.Drawing.SystemColors.Window
        Me.Tab_Sym.Controls.Add(Me.Btn_SymCancel)
        Me.Tab_Sym.Controls.Add(Me.Btn_SymConfirm)
        Me.Tab_Sym.Controls.Add(Me.CB_GS1EXP)
        Me.Tab_Sym.Controls.Add(Me.CB_GS1LIM)
        Me.Tab_Sym.Controls.Add(Me.CB_GS1)
        Me.Tab_Sym.Controls.Add(Me.CB_CODABAR)
        Me.Tab_Sym.Controls.Add(Me.CB_PLESSEY)
        Me.Tab_Sym.Controls.Add(Me.CB_MSI)
        Me.Tab_Sym.Controls.Add(Me.CB_I2OF5)
        Me.Tab_Sym.Controls.Add(Me.CB_CODE11)
        Me.Tab_Sym.Controls.Add(Me.CB_CODE35)
        Me.Tab_Sym.Controls.Add(Me.CB_CODE93)
        Me.Tab_Sym.Controls.Add(Me.CB_UCCEAN128)
        Me.Tab_Sym.Controls.Add(Me.CB_CODE128)
        Me.Tab_Sym.Controls.Add(Me.CB_PZN)
        Me.Tab_Sym.Controls.Add(Me.CB_CODE32)
        Me.Tab_Sym.Controls.Add(Me.CB_CODE39)
        Me.Tab_Sym.Controls.Add(Me.CB_EAN8)
        Me.Tab_Sym.Controls.Add(Me.CB_BOOKLAND)
        Me.Tab_Sym.Controls.Add(Me.CB_EAN13)
        Me.Tab_Sym.Controls.Add(Me.CB_UPCE)
        Me.Tab_Sym.Controls.Add(Me.CB_UPCA)
        Me.Tab_Sym.Location = New System.Drawing.Point(4, 25)
        Me.Tab_Sym.Name = "Tab_Sym"
        Me.Tab_Sym.Size = New System.Drawing.Size(231, 243)
        Me.Tab_Sym.Text = "Symbology"
        '
        'Btn_SymCancel
        '
        Me.Btn_SymCancel.Location = New System.Drawing.Point(118, 202)
        Me.Btn_SymCancel.Name = "Btn_SymCancel"
        Me.Btn_SymCancel.Size = New System.Drawing.Size(99, 30)
        Me.Btn_SymCancel.TabIndex = 21
        Me.Btn_SymCancel.Text = "Cancel"
        '
        'Btn_SymConfirm
        '
        Me.Btn_SymConfirm.Location = New System.Drawing.Point(3, 202)
        Me.Btn_SymConfirm.Name = "Btn_SymConfirm"
        Me.Btn_SymConfirm.Size = New System.Drawing.Size(99, 31)
        Me.Btn_SymConfirm.TabIndex = 20
        Me.Btn_SymConfirm.Text = "Confirm"
        '
        'CB_GS1EXP
        '
        Me.CB_GS1EXP.Location = New System.Drawing.Point(118, 174)
        Me.CB_GS1EXP.Name = "CB_GS1EXP"
        Me.CB_GS1EXP.Size = New System.Drawing.Size(100, 20)
        Me.CB_GS1EXP.TabIndex = 19
        Me.CB_GS1EXP.Text = "GS1_EXP"
        '
        'CB_GS1LIM
        '
        Me.CB_GS1LIM.Location = New System.Drawing.Point(118, 155)
        Me.CB_GS1LIM.Name = "CB_GS1LIM"
        Me.CB_GS1LIM.Size = New System.Drawing.Size(100, 20)
        Me.CB_GS1LIM.TabIndex = 18
        Me.CB_GS1LIM.Text = "GS1_LIM"
        '
        'CB_GS1
        '
        Me.CB_GS1.Location = New System.Drawing.Point(118, 136)
        Me.CB_GS1.Name = "CB_GS1"
        Me.CB_GS1.Size = New System.Drawing.Size(100, 20)
        Me.CB_GS1.TabIndex = 17
        Me.CB_GS1.Text = "GS1"
        '
        'CB_CODABAR
        '
        Me.CB_CODABAR.Location = New System.Drawing.Point(118, 117)
        Me.CB_CODABAR.Name = "CB_CODABAR"
        Me.CB_CODABAR.Size = New System.Drawing.Size(100, 20)
        Me.CB_CODABAR.TabIndex = 16
        Me.CB_CODABAR.Text = "CODABAR"
        '
        'CB_PLESSEY
        '
        Me.CB_PLESSEY.Location = New System.Drawing.Point(118, 98)
        Me.CB_PLESSEY.Name = "CB_PLESSEY"
        Me.CB_PLESSEY.Size = New System.Drawing.Size(100, 20)
        Me.CB_PLESSEY.TabIndex = 15
        Me.CB_PLESSEY.Text = "PLESSEY"
        '
        'CB_MSI
        '
        Me.CB_MSI.Location = New System.Drawing.Point(118, 79)
        Me.CB_MSI.Name = "CB_MSI"
        Me.CB_MSI.Size = New System.Drawing.Size(100, 20)
        Me.CB_MSI.TabIndex = 14
        Me.CB_MSI.Text = "MSI"
        '
        'CB_I2OF5
        '
        Me.CB_I2OF5.Location = New System.Drawing.Point(118, 60)
        Me.CB_I2OF5.Name = "CB_I2OF5"
        Me.CB_I2OF5.Size = New System.Drawing.Size(100, 20)
        Me.CB_I2OF5.TabIndex = 13
        Me.CB_I2OF5.Text = "I2OF5"
        '
        'CB_CODE11
        '
        Me.CB_CODE11.Location = New System.Drawing.Point(118, 41)
        Me.CB_CODE11.Name = "CB_CODE11"
        Me.CB_CODE11.Size = New System.Drawing.Size(100, 20)
        Me.CB_CODE11.TabIndex = 12
        Me.CB_CODE11.Text = "CODE11"
        '
        'CB_CODE35
        '
        Me.CB_CODE35.Location = New System.Drawing.Point(118, 22)
        Me.CB_CODE35.Name = "CB_CODE35"
        Me.CB_CODE35.Size = New System.Drawing.Size(100, 20)
        Me.CB_CODE35.TabIndex = 11
        Me.CB_CODE35.Text = "CODE35"
        '
        'CB_CODE93
        '
        Me.CB_CODE93.Location = New System.Drawing.Point(118, 3)
        Me.CB_CODE93.Name = "CB_CODE93"
        Me.CB_CODE93.Size = New System.Drawing.Size(100, 20)
        Me.CB_CODE93.TabIndex = 10
        Me.CB_CODE93.Text = "CODE93"
        '
        'CB_UCCEAN128
        '
        Me.CB_UCCEAN128.Location = New System.Drawing.Point(3, 174)
        Me.CB_UCCEAN128.Name = "CB_UCCEAN128"
        Me.CB_UCCEAN128.Size = New System.Drawing.Size(118, 20)
        Me.CB_UCCEAN128.TabIndex = 9
        Me.CB_UCCEAN128.Text = "UCC/EAN-128"
        '
        'CB_CODE128
        '
        Me.CB_CODE128.Location = New System.Drawing.Point(3, 155)
        Me.CB_CODE128.Name = "CB_CODE128"
        Me.CB_CODE128.Size = New System.Drawing.Size(100, 20)
        Me.CB_CODE128.TabIndex = 8
        Me.CB_CODE128.Text = "CODE128"
        '
        'CB_PZN
        '
        Me.CB_PZN.Location = New System.Drawing.Point(3, 136)
        Me.CB_PZN.Name = "CB_PZN"
        Me.CB_PZN.Size = New System.Drawing.Size(100, 20)
        Me.CB_PZN.TabIndex = 7
        Me.CB_PZN.Text = "PZN"
        '
        'CB_CODE32
        '
        Me.CB_CODE32.Location = New System.Drawing.Point(3, 117)
        Me.CB_CODE32.Name = "CB_CODE32"
        Me.CB_CODE32.Size = New System.Drawing.Size(100, 20)
        Me.CB_CODE32.TabIndex = 6
        Me.CB_CODE32.Text = "CODE32"
        '
        'CB_CODE39
        '
        Me.CB_CODE39.Location = New System.Drawing.Point(3, 98)
        Me.CB_CODE39.Name = "CB_CODE39"
        Me.CB_CODE39.Size = New System.Drawing.Size(100, 20)
        Me.CB_CODE39.TabIndex = 5
        Me.CB_CODE39.Text = "CODE39"
        '
        'CB_EAN8
        '
        Me.CB_EAN8.Location = New System.Drawing.Point(3, 79)
        Me.CB_EAN8.Name = "CB_EAN8"
        Me.CB_EAN8.Size = New System.Drawing.Size(100, 20)
        Me.CB_EAN8.TabIndex = 4
        Me.CB_EAN8.Text = "EAN-8"
        '
        'CB_BOOKLAND
        '
        Me.CB_BOOKLAND.Location = New System.Drawing.Point(3, 60)
        Me.CB_BOOKLAND.Name = "CB_BOOKLAND"
        Me.CB_BOOKLAND.Size = New System.Drawing.Size(100, 20)
        Me.CB_BOOKLAND.TabIndex = 3
        Me.CB_BOOKLAND.Text = "BOOKLAND"
        '
        'CB_EAN13
        '
        Me.CB_EAN13.Location = New System.Drawing.Point(3, 41)
        Me.CB_EAN13.Name = "CB_EAN13"
        Me.CB_EAN13.Size = New System.Drawing.Size(100, 20)
        Me.CB_EAN13.TabIndex = 2
        Me.CB_EAN13.Text = "EAN-13"
        '
        'CB_UPCE
        '
        Me.CB_UPCE.Location = New System.Drawing.Point(3, 22)
        Me.CB_UPCE.Name = "CB_UPCE"
        Me.CB_UPCE.Size = New System.Drawing.Size(100, 20)
        Me.CB_UPCE.TabIndex = 1
        Me.CB_UPCE.Text = "UPC-E"
        '
        'CB_UPCA
        '
        Me.CB_UPCA.Location = New System.Drawing.Point(3, 3)
        Me.CB_UPCA.Name = "CB_UPCA"
        Me.CB_UPCA.Size = New System.Drawing.Size(100, 20)
        Me.CB_UPCA.TabIndex = 0
        Me.CB_UPCA.Text = "UPC-A"
        '
        'Tab_Option
        '
        Me.Tab_Option.BackColor = System.Drawing.SystemColors.Window
        Me.Tab_Option.Controls.Add(Me.Btn_OpCancel)
        Me.Tab_Option.Controls.Add(Me.Btn_OpConfirm)
        Me.Tab_Option.Controls.Add(Me.Panel3)
        Me.Tab_Option.Controls.Add(Me.Panel2)
        Me.Tab_Option.Controls.Add(Me.Panel1)
        Me.Tab_Option.Location = New System.Drawing.Point(4, 25)
        Me.Tab_Option.Name = "Tab_Option"
        Me.Tab_Option.Size = New System.Drawing.Size(231, 243)
        Me.Tab_Option.Text = "Option"
        '
        'Btn_OpCancel
        '
        Me.Btn_OpCancel.Location = New System.Drawing.Point(119, 195)
        Me.Btn_OpCancel.Name = "Btn_OpCancel"
        Me.Btn_OpCancel.Size = New System.Drawing.Size(99, 31)
        Me.Btn_OpCancel.TabIndex = 4
        Me.Btn_OpCancel.Text = "Cancel"
        '
        'Btn_OpConfirm
        '
        Me.Btn_OpConfirm.Location = New System.Drawing.Point(10, 195)
        Me.Btn_OpConfirm.Name = "Btn_OpConfirm"
        Me.Btn_OpConfirm.Size = New System.Drawing.Size(99, 31)
        Me.Btn_OpConfirm.TabIndex = 3
        Me.Btn_OpConfirm.Text = "Confirm"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.Window
        Me.Panel3.Controls.Add(Me.CB_XCD)
        Me.Panel3.Controls.Add(Me.CB_HIGHFILTER)
        Me.Panel3.Controls.Add(Me.CB_WIDESCAN)
        Me.Panel3.Location = New System.Drawing.Point(8, 123)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(212, 54)
        '
        'CB_XCD
        '
        Me.CB_XCD.Location = New System.Drawing.Point(7, 30)
        Me.CB_XCD.Name = "CB_XCD"
        Me.CB_XCD.Size = New System.Drawing.Size(160, 20)
        Me.CB_XCD.TabIndex = 2
        Me.CB_XCD.Text = "Transmit Check Digit"
        '
        'CB_HIGHFILTER
        '
        Me.CB_HIGHFILTER.Location = New System.Drawing.Point(109, 7)
        Me.CB_HIGHFILTER.Name = "CB_HIGHFILTER"
        Me.CB_HIGHFILTER.Size = New System.Drawing.Size(100, 20)
        Me.CB_HIGHFILTER.TabIndex = 1
        Me.CB_HIGHFILTER.Text = "HighFilter"
        '
        'CB_WIDESCAN
        '
        Me.CB_WIDESCAN.Location = New System.Drawing.Point(7, 7)
        Me.CB_WIDESCAN.Name = "CB_WIDESCAN"
        Me.CB_WIDESCAN.Size = New System.Drawing.Size(100, 20)
        Me.CB_WIDESCAN.TabIndex = 0
        Me.CB_WIDESCAN.Text = "WideScan"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.Window
        Me.Panel2.Controls.Add(Me.CB_SECLEVEL)
        Me.Panel2.Controls.Add(Me.CB_TIMEOUT)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Location = New System.Drawing.Point(8, 46)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(212, 71)
        '
        'CB_SECLEVEL
        '
        Me.CB_SECLEVEL.Items.Add("1")
        Me.CB_SECLEVEL.Items.Add("2")
        Me.CB_SECLEVEL.Items.Add("3")
        Me.CB_SECLEVEL.Items.Add("4")
        Me.CB_SECLEVEL.Location = New System.Drawing.Point(100, 37)
        Me.CB_SECLEVEL.Name = "CB_SECLEVEL"
        Me.CB_SECLEVEL.Size = New System.Drawing.Size(105, 23)
        Me.CB_SECLEVEL.TabIndex = 3
        '
        'CB_TIMEOUT
        '
        Me.CB_TIMEOUT.Items.Add("1")
        Me.CB_TIMEOUT.Items.Add("2")
        Me.CB_TIMEOUT.Items.Add("3")
        Me.CB_TIMEOUT.Items.Add("4")
        Me.CB_TIMEOUT.Items.Add("5")
        Me.CB_TIMEOUT.Items.Add("6")
        Me.CB_TIMEOUT.Items.Add("7")
        Me.CB_TIMEOUT.Items.Add("8")
        Me.CB_TIMEOUT.Items.Add("9")
        Me.CB_TIMEOUT.Items.Add("10")
        Me.CB_TIMEOUT.Location = New System.Drawing.Point(100, 8)
        Me.CB_TIMEOUT.Name = "CB_TIMEOUT"
        Me.CB_TIMEOUT.Size = New System.Drawing.Size(105, 23)
        Me.CB_TIMEOUT.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(5, 42)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 16)
        Me.Label4.Text = "Security Level"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(7, 13)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 18)
        Me.Label3.Text = "TimeOut"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Window
        Me.Panel1.Controls.Add(Me.RD_SYNC)
        Me.Panel1.Controls.Add(Me.RD_ASYNC)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Location = New System.Drawing.Point(8, 9)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(213, 31)
        '
        'RD_SYNC
        '
        Me.RD_SYNC.Location = New System.Drawing.Point(146, 7)
        Me.RD_SYNC.Name = "RD_SYNC"
        Me.RD_SYNC.Size = New System.Drawing.Size(59, 20)
        Me.RD_SYNC.TabIndex = 2
        Me.RD_SYNC.Text = "Sync"
        '
        'RD_ASYNC
        '
        Me.RD_ASYNC.Location = New System.Drawing.Point(81, 7)
        Me.RD_ASYNC.Name = "RD_ASYNC"
        Me.RD_ASYNC.Size = New System.Drawing.Size(64, 20)
        Me.RD_ASYNC.TabIndex = 1
        Me.RD_ASYNC.Text = "ASync"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(7, 7)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 20)
        Me.Label2.Text = "Sync Mode"
        '
        'M3Scanner
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit
        Me.ClientSize = New System.Drawing.Size(638, 455)
        Me.Controls.Add(Me.Tab_M3Scanner)
        Me.Name = "M3Scanner"
        Me.Text = "M3ScanTest_VB"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Tab_M3Scanner.ResumeLayout(False)
        Me.Tab_Main.ResumeLayout(False)
        Me.Tab_Sym.ResumeLayout(False)
        Me.Tab_Option.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Tab_Main As System.Windows.Forms.TabPage
    Friend WithEvents Tab_Sym As System.Windows.Forms.TabPage
    Friend WithEvents Tab_Option As System.Windows.Forms.TabPage
    Private WithEvents Tab_M3Scanner As System.Windows.Forms.TabControl
    Friend WithEvents LV_SCANDATA As System.Windows.Forms.ListView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Info As System.Windows.Forms.Button
    Friend WithEvents Btn_ScanCancel As System.Windows.Forms.Button
    Friend WithEvents Btn_Scan As System.Windows.Forms.Button
    Friend WithEvents BarType As System.Windows.Forms.ColumnHeader
    Friend WithEvents BarData As System.Windows.Forms.ColumnHeader
    Friend WithEvents CB_PZN As System.Windows.Forms.CheckBox
    Friend WithEvents CB_CODE32 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_CODE39 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_EAN8 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_BOOKLAND As System.Windows.Forms.CheckBox
    Friend WithEvents CB_EAN13 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_UPCE As System.Windows.Forms.CheckBox
    Friend WithEvents CB_UPCA As System.Windows.Forms.CheckBox
    Friend WithEvents Btn_SymCancel As System.Windows.Forms.Button
    Friend WithEvents Btn_SymConfirm As System.Windows.Forms.Button
    Friend WithEvents CB_GS1EXP As System.Windows.Forms.CheckBox
    Friend WithEvents CB_GS1LIM As System.Windows.Forms.CheckBox
    Friend WithEvents CB_GS1 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_CODABAR As System.Windows.Forms.CheckBox
    Friend WithEvents CB_PLESSEY As System.Windows.Forms.CheckBox
    Friend WithEvents CB_MSI As System.Windows.Forms.CheckBox
    Friend WithEvents CB_I2OF5 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_CODE11 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_CODE35 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_CODE93 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_UCCEAN128 As System.Windows.Forms.CheckBox
    Friend WithEvents CB_CODE128 As System.Windows.Forms.CheckBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents RD_SYNC As System.Windows.Forms.RadioButton
    Friend WithEvents RD_ASYNC As System.Windows.Forms.RadioButton
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Btn_OpCancel As System.Windows.Forms.Button
    Friend WithEvents Btn_OpConfirm As System.Windows.Forms.Button
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents CB_XCD As System.Windows.Forms.CheckBox
    Friend WithEvents CB_HIGHFILTER As System.Windows.Forms.CheckBox
    Friend WithEvents CB_WIDESCAN As System.Windows.Forms.CheckBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents CB_SECLEVEL As System.Windows.Forms.ComboBox
    Friend WithEvents CB_TIMEOUT As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label

End Class
