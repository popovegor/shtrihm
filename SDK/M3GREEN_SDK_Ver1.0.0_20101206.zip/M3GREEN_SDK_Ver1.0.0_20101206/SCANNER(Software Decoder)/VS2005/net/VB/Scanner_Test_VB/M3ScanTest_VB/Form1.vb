Imports System
Imports Microsoft.Win32
Imports System.Threading
Imports System.Runtime.InteropServices
Imports MCSSLibNet

Public Class M3Scanner

    Private ScanCtrl As MCSSLibNet.ScannerControl
    Private M3BarCodeType As New MCSSLibNet.MCBarCodeType
    Private M3ModuleOption As New MCSSLibNet.MCModuleOption
    Private M3ReadOption As New MCSSLibNet.MCReadOption

    Public m_bKeyFlag As Boolean = False
    Public m_bReading As Boolean = False
    Public m_bSyncMode As Boolean = False

    Private Sub M3Scanner_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ScanCtrl = New MCSSLibNet.ScannerControl
        M3BarCodeType = New MCSSLibNet.MCBarCodeType
        M3ModuleOption = New MCSSLibNet.MCModuleOption
        M3ReadOption = New MCSSLibNet.MCReadOption

        AddHandler ScanCtrl.ScannerDataEvent, AddressOf Me.OnScanData

        ScanCtrl.ScanInit()

    End Sub

    Private Sub ScanRead()
        If m_bReading = True Then
            m_bReading = False
            ScanCtrl.ScanReadCancel()
        Else
            m_bReading = True
            ScanCtrl.ScanRead()
        End If

    End Sub

    Private Sub OnScanData(ByVal sender As System.Object, ByVal e As MCSSLibNet.ScannerDataArgs)
        If (LV_SCANDATA.Items.Count > 6) Then
            LV_SCANDATA.Items.Clear()
        End If

        Dim ScanData As New ListViewItem()

        If e.ScanData <> "" Then
            ScanData.Text = e.ScanType
            ScanData.SubItems.Add(e.ScanData)

            LV_SCANDATA.Items.Add(ScanData)
            Call Beep()
        End If

    End Sub

    Private Sub Tab_M3Scanner_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Tab_M3Scanner.KeyDown
        If (e.KeyCode = System.Windows.Forms.Keys.F22) Then
            If m_bKeyFlag = False Then
                m_bKeyFlag = True
                ScanCtrl.ScanRead()
            End If
        End If
    End Sub

    Private Sub Tab_M3Scanner_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Tab_M3Scanner.KeyUp
        If (e.KeyCode = System.Windows.Forms.Keys.F22) Then
            If m_bKeyFlag = True Then
                m_bKeyFlag = False
                If m_bSyncMode = False Then
                    ScanCtrl.ScanReadCancel()
                End If
            End If
        End If
    End Sub

    Private Sub M3Scanner_Closing(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        ScanCtrl.ScanClose()
    End Sub

    Private Sub Btn_Scan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Scan.Click
        ScanCtrl.ScanRead()
        Tab_M3Scanner.Focus()
    End Sub

    Private Sub Btn_ScanCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ScanCancel.Click
        ScanCtrl.ScanReadCancel()
        Tab_M3Scanner.Focus()
    End Sub

    Private Sub Btn_Info_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Info.Click
        Dim strInfo As String = ScanCtrl.GetVersionInfo()
        MessageBox.Show(strInfo)

        Tab_M3Scanner.Focus()
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Dim i As Integer
        Dim bResult As Boolean

        For i = 0 To 3
            bResult = ScanCtrl.ScanClose()
            Thread.Sleep(300)
            If bResult = True Then
                Exit For
            End If

            i = i + 1
        Next

        Application.Exit()
    End Sub


    Private Sub Tab_M3Scanner_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tab_M3Scanner.SelectedIndexChanged
        Select Case Tab_M3Scanner.SelectedIndex
            Case 0  'Main Page
                Tab_M3Scanner.Focus()
            Case 1  'Symbology Page
                ScanCtrl.ScanReadCancel()
                ScanCtrl.GetBarCodeType(M3BarCodeType)
                CB_UPCA.Checked = M3BarCodeType.bMC_UPCA
                CB_UPCE.Checked = M3BarCodeType.bMC_UPCE
                CB_EAN13.Checked = M3BarCodeType.bMC_EAN13
                CB_BOOKLAND.Checked = M3BarCodeType.bMC_BOOKLAND
                CB_EAN8.Checked = M3BarCodeType.bMC_EAN8
                CB_CODE39.Checked = M3BarCodeType.bMC_CODE39
                CB_CODE32.Checked = M3BarCodeType.bMC_CODE32
                CB_PZN.Checked = M3BarCodeType.bMC_PZN
                CB_CODE128.Checked = M3BarCodeType.bMC_CODE128
                CB_UCCEAN128.Checked = M3BarCodeType.bMC_UCCEAN128
                CB_CODE93.Checked = M3BarCodeType.bMC_CODE93
                CB_CODE35.Checked = M3BarCodeType.bMC_CODE35
                CB_CODE11.Checked = M3BarCodeType.bMC_CODE11
                CB_I2OF5.Checked = M3BarCodeType.bMC_I2OF5
                CB_MSI.Checked = M3BarCodeType.bMC_MSI
                CB_PLESSEY.Checked = M3BarCodeType.bMC_PLESSEY
                CB_CODABAR.Checked = M3BarCodeType.bMC_CODABAR
                CB_GS1.Checked = M3BarCodeType.bMC_GS1
                CB_GS1LIM.Checked = M3BarCodeType.bMC_GS1_LIMITED
                CB_GS1EXP.Checked = M3BarCodeType.bMC_GS1_EXPANDED
            Case 2  'Option Page
                ScanCtrl.ScanReadCancel()
                ScanCtrl.GetReadOption(M3ReadOption)
                ScanCtrl.GetModuleOption(M3ModuleOption)

                If m_bSyncMode = False Then
                    RD_ASYNC.Checked = True
                Else
                    RD_SYNC.Checked = True
                End If

                Select Case M3ModuleOption.nMC_TimeOutSec
                    Case 1
                        CB_TIMEOUT.Text = "1"
                    Case 2
                        CB_TIMEOUT.Text = "2"
                    Case 3
                        CB_TIMEOUT.Text = "3"
                    Case 4
                        CB_TIMEOUT.Text = "4"
                    Case 5
                        CB_TIMEOUT.Text = "5"
                    Case 6
                        CB_TIMEOUT.Text = "6"
                    Case 7
                        CB_TIMEOUT.Text = "7"
                    Case 8
                        CB_TIMEOUT.Text = "8"
                    Case 9
                        CB_TIMEOUT.Text = "9"
                    Case 10
                        CB_TIMEOUT.Text = "10"
                End Select

                Select Case M3ModuleOption.nMC_SecurityLevel
                    Case 1
                        CB_SECLEVEL.Text = "1"
                    Case 2
                        CB_SECLEVEL.Text = "2"
                    Case 3
                        CB_SECLEVEL.Text = "3"
                    Case 4
                        CB_SECLEVEL.Text = "4"
                End Select

                CB_WIDESCAN.Checked = M3ReadOption.bMC_WIDESCANANGLE
                CB_HIGHFILTER.Checked = M3ReadOption.bMC_HIGHFILTERMODE
                CB_XCD.Checked = M3ReadOption.bMC_RETURNCHECK

        End Select

    End Sub

    Private Sub Btn_SymConfirm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_SymConfirm.Click
        M3BarCodeType.bMC_UPCA = CB_UPCA.Checked
        M3BarCodeType.bMC_UPCE = CB_UPCE.Checked
        M3BarCodeType.bMC_EAN13 = CB_EAN13.Checked
        M3BarCodeType.bMC_BOOKLAND = CB_BOOKLAND.Checked
        M3BarCodeType.bMC_EAN8 = CB_EAN8.Checked
        M3BarCodeType.bMC_CODE39 = CB_CODE39.Checked
        M3BarCodeType.bMC_CODE32 = CB_CODE32.Checked
        M3BarCodeType.bMC_PZN = CB_PZN.Checked
        M3BarCodeType.bMC_CODE128 = CB_CODE128.Checked
        M3BarCodeType.bMC_UCCEAN128 = CB_UCCEAN128.Checked
        M3BarCodeType.bMC_CODE93 = CB_CODE93.Checked
        M3BarCodeType.bMC_CODE35 = CB_CODE35.Checked
        M3BarCodeType.bMC_CODE11 = CB_CODE11.Checked
        M3BarCodeType.bMC_I2OF5 = CB_I2OF5.Checked
        M3BarCodeType.bMC_MSI = CB_MSI.Checked
        M3BarCodeType.bMC_PLESSEY = CB_PLESSEY.Checked
        M3BarCodeType.bMC_CODABAR = CB_CODABAR.Checked
        M3BarCodeType.bMC_GS1 = CB_GS1.Checked
        M3BarCodeType.bMC_GS1_LIMITED = CB_GS1LIM.Checked
        M3BarCodeType.bMC_GS1_EXPANDED = CB_GS1EXP.Checked

        ScanCtrl.SetBarCodeType(M3BarCodeType)
        Tab_M3Scanner.SelectedIndex = 0
        Tab_M3Scanner.Focus()
    End Sub

    Private Sub Btn_SymCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_SymCancel.Click
        Tab_M3Scanner.SelectedIndex = 0
        Tab_M3Scanner.Focus()
    End Sub

    Private Sub Btn_OpConfirm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_OpConfirm.Click
        If RD_SYNC.Checked = True Then
            m_bSyncMode = True
        Else
            m_bSyncMode = False
        End If

        M3ModuleOption.nMC_TimeOutSec = CB_TIMEOUT.SelectedIndex + 1
        M3ModuleOption.nMC_SecurityLevel = CB_SECLEVEL.SelectedIndex + 1

        M3ReadOption.bMC_WIDESCANANGLE = CB_WIDESCAN.Checked
        M3ReadOption.bMC_HIGHFILTERMODE = CB_HIGHFILTER.Checked
        M3ReadOption.bMC_RETURNCHECK = CB_XCD.Checked

        ScanCtrl.SetModuleOption(M3ModuleOption)
        ScanCtrl.SetReadOption(M3ReadOption)

        Tab_M3Scanner.SelectedIndex = 0
        Tab_M3Scanner.Focus()
    End Sub

    Private Sub Btn_OpCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_OpCancel.Click
        Tab_M3Scanner.SelectedIndex = 0
        Tab_M3Scanner.Focus()
    End Sub
End Class
