#if !defined(AFX_TELEPENDLG_H__D95760D1_87D4_4B3E_BB2E_8368FDE712FE__INCLUDED_)
#define AFX_TELEPENDLG_H__D95760D1_87D4_4B3E_BB2E_8368FDE712FE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TelepenDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTelepenDlg dialog

class CTelepenDlg : public CDialog
{
// Construction
public:
	void SetOption();
	void GetOption();
	CTelepenDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTelepenDlg)
	enum { IDD = IDD_TELEPEN_DLG };
	BOOL	m_bEnable;
	BOOL	m_bOldStyle;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTelepenDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTelepenDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnConfirm();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TELEPENDLG_H__D95760D1_87D4_4B3E_BB2E_8368FDE712FE__INCLUDED_)
