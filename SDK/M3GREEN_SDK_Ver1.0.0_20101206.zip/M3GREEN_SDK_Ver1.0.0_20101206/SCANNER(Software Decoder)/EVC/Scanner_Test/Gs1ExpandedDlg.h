#if !defined(AFX_GS1EXPANDEDDLG_H__6C89C9DB_9049_4F52_BC3F_48021E688D14__INCLUDED_)
#define AFX_GS1EXPANDEDDLG_H__6C89C9DB_9049_4F52_BC3F_48021E688D14__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Gs1ExpandedDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGs1ExpandedDlg dialog

class CGs1ExpandedDlg : public CDialog
{
// Construction
public:
	void SetOption();
	void GetOption();
	CGs1ExpandedDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CGs1ExpandedDlg)
	enum { IDD = IDD_GS1EXPANDED_DLG };
	BOOL	m_bEnable;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGs1ExpandedDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CGs1ExpandedDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GS1EXPANDEDDLG_H__6C89C9DB_9049_4F52_BC3F_48021E688D14__INCLUDED_)
