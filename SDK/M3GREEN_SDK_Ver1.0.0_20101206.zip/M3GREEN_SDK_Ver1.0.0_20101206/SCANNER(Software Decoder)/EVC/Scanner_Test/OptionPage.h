#if !defined(AFX_OPTIONPAGE_H__14E9AD78_20F2_4962_89F4_04D0D0916604__INCLUDED_)
#define AFX_OPTIONPAGE_H__14E9AD78_20F2_4962_89F4_04D0D0916604__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OptionPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COptionPage dialog

class COptionPage : public CPropertyPage
{
	DECLARE_DYNCREATE(COptionPage)

// Construction
public:
	void SetOption();
	void GetOption();
	// UPCA
	COptionPage();
	~COptionPage();

// Dialog Data
	//{{AFX_DATA(COptionPage)
	enum { IDD = IDD_OPTION_DLG };
	BOOL	m_bHighFilter;
	BOOL	m_bWideScan;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(COptionPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(COptionPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	afx_msg void OnCodabar();
	afx_msg void OnCode11();
	afx_msg void OnCode128();
	afx_msg void OnCode35();
	afx_msg void OnCode39();
	afx_msg void OnCode93();
	afx_msg void OnGs1();
	afx_msg void OnGs1expanded();
	afx_msg void OnGs1limited();
	afx_msg void OnI2of5();
	afx_msg void OnMsi();
	afx_msg void OnPlessey();
	afx_msg void OnUpca();
	afx_msg void OnUpce();
	afx_msg void OnEan13();
	afx_msg void OnEan8();
	afx_msg void OnTelepen();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTIONPAGE_H__14E9AD78_20F2_4962_89F4_04D0D0916604__INCLUDED_)
