// TelepenDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "TelepenDlg.h"
#include "MainSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;
/////////////////////////////////////////////////////////////////////////////
// CTelepenDlg dialog


CTelepenDlg::CTelepenDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTelepenDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTelepenDlg)
	m_bEnable = FALSE;
	m_bOldStyle = FALSE;
	//}}AFX_DATA_INIT
}


void CTelepenDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTelepenDlg)
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_OLDSTYLE, m_bOldStyle);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTelepenDlg, CDialog)
	//{{AFX_MSG_MAP(CTelepenDlg)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, OnBtnConfirm)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTelepenDlg message handlers

BOOL CTelepenDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);

	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CTelepenDlg::OnBtnConfirm() 
{
	SetOption();
	
	CMainSheet* dlg = (CMainSheet*)AfxGetMainWnd();
	
	dlg->SetReadOption();

	CDialog::OnOK();
	
}

void CTelepenDlg::GetOption()
{
	if(kReadEx2.Telepen.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;
	
	if(kReadEx2.Telepen.OldStyle == ENABLE)
		m_bOldStyle = TRUE;
	else
		m_bOldStyle = FALSE;

	UpdateData(FALSE);
}

void CTelepenDlg::SetOption()
{
	UpdateData(TRUE);
	
	if(m_bEnable == TRUE)
		kReadEx2.Telepen.Enable = ENABLE;
	else
		kReadEx2.Telepen.Enable = DISABLE;
	
	if(m_bOldStyle == TRUE)
		kReadEx2.Telepen.OldStyle = ENABLE;
	else
		kReadEx2.Telepen.OldStyle = DISABLE;
}
