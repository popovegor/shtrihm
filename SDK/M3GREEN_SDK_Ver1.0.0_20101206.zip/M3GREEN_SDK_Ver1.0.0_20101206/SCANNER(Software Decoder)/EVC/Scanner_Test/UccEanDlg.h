#if !defined(AFX_UCCEANDLG_H__A2B98646_20E7_4526_8472_6B5862DCB03C__INCLUDED_)
#define AFX_UCCEANDLG_H__A2B98646_20E7_4526_8472_6B5862DCB03C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UccEanDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CUccEanDlg dialog

class CUccEanDlg : public CDialog
{
// Construction
public:
	void SetOption();
	void GetOption();
	CUccEanDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CUccEanDlg)
	enum { IDD = IDD_UPCEAN_DLG };
	BOOL	m_bUpcaAsEan13;
	BOOL	m_bEnable;
	BOOL	m_bXCD;
	BOOL	m_bXmitNum;
	BOOL	m_bSupp;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUccEanDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CUccEanDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UCCEANDLG_H__A2B98646_20E7_4526_8472_6B5862DCB03C__INCLUDED_)
