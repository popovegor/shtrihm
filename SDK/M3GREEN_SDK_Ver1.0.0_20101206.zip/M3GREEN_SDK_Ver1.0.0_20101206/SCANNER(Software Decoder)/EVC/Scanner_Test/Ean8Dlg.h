#if !defined(AFX_EAN8DLG_H__2D2E3DE8_08A3_4852_BF06_199E02C4AFCC__INCLUDED_)
#define AFX_EAN8DLG_H__2D2E3DE8_08A3_4852_BF06_199E02C4AFCC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Ean8Dlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEan8Dlg dialog

class CEan8Dlg : public CDialog
{
// Construction
public:
	void SetOption();
	void GetOption();
	CEan8Dlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CEan8Dlg)
	enum { IDD = IDD_EAN8_DLG };
	BOOL	m_bEnable;
	BOOL	m_bEan8AsEan13;
	BOOL	m_bXCD;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEan8Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEan8Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EAN8DLG_H__2D2E3DE8_08A3_4852_BF06_199E02C4AFCC__INCLUDED_)
