// OptionPage.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "OptionPage.h"
#include "MainSheet.h"

// BarCode Dialog
#include "UccEanDlg.h"
#include "UpceDlg.h"
#include "Ean13Dlg.h"
#include "Ean8Dlg.h"
#include "Code39Dlg.h"
#include "Code128Dlg.h"
#include "Code93Dlg.h"
#include "Code35Dlg.h"
#include "Code11Dlg.h"
#include "I2of5Dlg.h"
#include "CodabarDlg.h"
#include "MsiDlg.h"
#include "PlesseyDlg.h"
#include "Gs1Dlg.h"
#include "Gs1LimitedDlg.h"
#include "Gs1ExpandedDlg.h"
#include "TelepenDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;

/////////////////////////////////////////////////////////////////////////////
// COptionPage property page

IMPLEMENT_DYNCREATE(COptionPage, CPropertyPage)

COptionPage::COptionPage() : CPropertyPage(COptionPage::IDD)
{
	//{{AFX_DATA_INIT(COptionPage)
	m_bHighFilter = FALSE;
	m_bWideScan = FALSE;
	//}}AFX_DATA_INIT
}

COptionPage::~COptionPage()
{
}

void COptionPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COptionPage)
	DDX_Check(pDX, IDC_CHECK_HIGHFILTER, m_bHighFilter);
	DDX_Check(pDX, IDC_CHECK_WIDESCAN, m_bWideScan);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COptionPage, CPropertyPage)
	//{{AFX_MSG_MAP(COptionPage)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, OnConfirm)
	ON_BN_CLICKED(IDC_BTN_CODABAR, OnCodabar)
	ON_BN_CLICKED(IDC_BTN_CODE11, OnCode11)
	ON_BN_CLICKED(IDC_BTN_CODE128, OnCode128)
	ON_BN_CLICKED(IDC_BTN_CODE35, OnCode35)
	ON_BN_CLICKED(IDC_BTN_CODE39, OnCode39)
	ON_BN_CLICKED(IDC_BTN_CODE93, OnCode93)
	ON_BN_CLICKED(IDC_BTN_GS1, OnGs1)
	ON_BN_CLICKED(IDC_BTN_GS1EXPANDED, OnGs1expanded)
	ON_BN_CLICKED(IDC_BTN_GS1LIMITED, OnGs1limited)
	ON_BN_CLICKED(IDC_BTN_I2OF5, OnI2of5)
	ON_BN_CLICKED(IDC_BTN_MSI, OnMsi)
	ON_BN_CLICKED(IDC_BTN_PLESSEY, OnPlessey)
	ON_BN_CLICKED(IDC_BTN_UPCEAN, OnUpca)
	ON_BN_CLICKED(IDC_BTN_UPCE, OnUpce)
	ON_BN_CLICKED(IDC_BTN_EAN13, OnEan13)
	ON_BN_CLICKED(IDC_BTN_EAN8, OnEan8)
	ON_BN_CLICKED(IDC_BTN_TELEPEN, OnTelepen)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptionPage message handlers

BOOL COptionPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void COptionPage::OnConfirm() 
{
	SetOption();

	CMainSheet* dlg = (CMainSheet*)AfxGetMainWnd();

	dlg->SetReadOption();

	(CPropertySheet *)GetParent()->SendMessage(PSM_SETCURSEL, 0);	
}

void COptionPage::GetOption()
{
	if(kRead.dwFlags & KSCAN_FLAG_HIGHFILTERMODE)
		m_bHighFilter = TRUE;
	else
		m_bHighFilter = FALSE;
	
	if(kRead.dwFlags & KSCAN_FLAG_WIDESCANANGLE)
		m_bWideScan=TRUE;
	else
		m_bWideScan=FALSE;
	
	UpdateData(FALSE);
}

void COptionPage::SetOption()
{
	UpdateData(TRUE);

	kRead.dwFlags = 0;

	if(m_bHighFilter == TRUE)
		kRead.dwFlags |= KSCAN_FLAG_HIGHFILTERMODE;


	if(m_bWideScan == TRUE)
		kRead.dwFlags |= KSCAN_FLAG_WIDESCANANGLE;

}

void COptionPage::OnUpca()	// UPCA
{
	CUccEanDlg	dlg;
	dlg.DoModal();
}

void COptionPage::OnUpce() 
{
	CUpceDlg dlg;
	dlg.DoModal();	
}

void COptionPage::OnEan13() 
{
	CEan13Dlg dlg;
	dlg.DoModal();		
}

void COptionPage::OnEan8() 
{
	CEan8Dlg dlg;
	dlg.DoModal();		
}

void COptionPage::OnCode39() 
{
	CCode39Dlg dlg;
	dlg.DoModal();	
}

void COptionPage::OnCode128() 
{
	CCode128Dlg dlg;
	dlg.DoModal();	
}

void COptionPage::OnCode93() 
{
	CCode93Dlg dlg;
	dlg.DoModal();	
}

void COptionPage::OnCode35() 
{
	CCode35Dlg dlg;
	dlg.DoModal();		
}

void COptionPage::OnCode11() 
{
	CCode11Dlg dlg;
	dlg.DoModal();		
}

void COptionPage::OnI2of5() 
{
	CI2of5Dlg dlg;
	dlg.DoModal();		
}

void COptionPage::OnCodabar() 
{
	CCodabarDlg dlg;
	dlg.DoModal();		
}

void COptionPage::OnMsi() 
{
	CMsiDlg dlg;
	dlg.DoModal();		
}

void COptionPage::OnPlessey() 
{
	CPlesseyDlg dlg;
	dlg.DoModal();		
}

void COptionPage::OnGs1() 
{
	CGs1Dlg dlg;
	dlg.DoModal();		
}

void COptionPage::OnGs1limited() 
{
	CGs1LimitedDlg dlg;
	dlg.DoModal();		
}

void COptionPage::OnGs1expanded() 
{
	CGs1ExpandedDlg dlg;
	dlg.DoModal();		
}

void COptionPage::OnTelepen() 
{
	CTelepenDlg dlg;
	dlg.DoModal();	
	
}
