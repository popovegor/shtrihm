#if !defined(AFX_MAINSHEET_H__B74EA329_2145_4557_A811_217394A5B59F__INCLUDED_)
#define AFX_MAINSHEET_H__B74EA329_2145_4557_A811_217394A5B59F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MainSheet.h : header file
//

// Property Page
#include "ScanPage.h"
#include "SymbologyPage.h"
#include "OptionPage.h"

// Scanner
#include "KScanBar.h"

#define	WM_DATA_READ	WM_USER+10

//////////////////////////////////////////////////////////////////////////
// Scanner Info
typedef struct _stScanInfo
{
	_stScanInfo(){
		gstrCodeTypeName = L"";
		gstrBarCodeValue = L"";
	}
	CString gstrCodeTypeName;
	CString gstrBarCodeValue;
}ScanInfo;
/////////////////////////////////////////////////////////////////////////////
// CMainSheet
class CMainSheet : public CPropertySheet
{
	DECLARE_DYNAMIC(CMainSheet)

// Construction
public:
	CMainSheet(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CMainSheet(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes
public:
	CM3ScanTestApp* m_pApp;
	CScanPage		m_ScanPage;
	CSymbologyPage	m_SymbologyPage;
	COptionPage		m_OptionPage;

	CKScan			m_KScan;
	BOOL			m_bReading;		// Scan Reading
	BOOL			m_bKeyFlag;		// Key Up/Down
	int				m_nStatus;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainSheet)
	public:
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetReadOption();
	void ResumeProcess();
	void DefaultSetting();
	void LoadResourceSound();
	BOOL SetBarCodeString(int nType);
	void M3_ScanRead();
	BOOL M3_ScanClose();
	BOOL M3_ScanOpen(int nPortNumber);
	void M3_ScanInit(int nPortNumber);
	virtual ~CMainSheet();

	// Generated message map functions
protected:
	//{{AFX_MSG(CMainSheet)
	afx_msg LRESULT OnScanRead(WPARAM wParam,LPARAM lParam);
	afx_msg void OnDestroy();
	//}}AFX_MSG	
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINSHEET_H__B74EA329_2145_4557_A811_217394A5B59F__INCLUDED_)
