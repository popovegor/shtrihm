#if !defined(AFX_UPCEDLG_H__472D7C9E_9654_4E25_B1F2_1B0B8ECC7FC3__INCLUDED_)
#define AFX_UPCEDLG_H__472D7C9E_9654_4E25_B1F2_1B0B8ECC7FC3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UpceDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CUpceDlg dialog

class CUpceDlg : public CDialog
{
// Construction
public:
	void SetOption();
	void GetOption();
	CUpceDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CUpceDlg)
	enum { IDD = IDD_UPCE_DLG };
	BOOL	m_bEnable;
	BOOL	m_bXCD;
	BOOL	m_bXmitNum;
	int		m_nConvert;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUpceDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CUpceDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UPCEDLG_H__472D7C9E_9654_4E25_B1F2_1B0B8ECC7FC3__INCLUDED_)
