// Code93Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "Code93Dlg.h"
#include "MainSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;

/////////////////////////////////////////////////////////////////////////////
// CCode93Dlg dialog


CCode93Dlg::CCode93Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCode93Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCode93Dlg)
	m_bEnable = FALSE;
	m_nMaxLen = 0;
	m_nMinLen = 0;
	//}}AFX_DATA_INIT
}


void CCode93Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCode93Dlg)
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Text(pDX, IDC_EDIT_MAXLEN, m_nMaxLen);
	DDX_Text(pDX, IDC_EDIT_MINLEN, m_nMinLen);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCode93Dlg, CDialog)
	//{{AFX_MSG_MAP(CCode93Dlg)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, OnConfirm)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCode93Dlg message handlers

BOOL CCode93Dlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
		
	MoveWindow(0, -1, 240, 310);

	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CCode93Dlg::OnConfirm() 
{
	SetOption();

	CMainSheet* dlg = (CMainSheet*)AfxGetMainWnd();
	
	dlg->SetReadOption();
	
	CDialog::OnOK();
	
}

void CCode93Dlg::GetOption()
{
	if(kReadEx2.Code93.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;

	m_nMaxLen = kReadEx2.Code93.MaxLength;
	m_nMinLen = kReadEx2.Code93.MinLength;

	UpdateData(FALSE);
}

void CCode93Dlg::SetOption()
{
	UpdateData(TRUE);
	
	if(m_bEnable == TRUE)
		kReadEx2.Code93.Enable = ENABLE;
	else
		kReadEx2.Code93.Enable = DISABLE;

	
	kReadEx2.Code93.MaxLength = m_nMaxLen;
	kReadEx2.Code93.MinLength = m_nMinLen;
}


