#if !defined(AFX_SYMBOLOGYPAGE_H__6D087220_5074_4474_9D66_41C4F7542595__INCLUDED_)
#define AFX_SYMBOLOGYPAGE_H__6D087220_5074_4474_9D66_41C4F7542595__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SymbologyPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSymbologyPage dialog

class CSymbologyPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CSymbologyPage)

// Construction
public:
	void SetOption();
	void GetOption();
	CSymbologyPage();
	~CSymbologyPage();

// Dialog Data
	//{{AFX_DATA(CSymbologyPage)
	enum { IDD = IDD_SYM_DLG };
	CComboBox	m_ctrlComboTimeOut;
	CComboBox	m_ctrlComboSecurityLevel;
	BOOL	m_bCodabar;
	BOOL	m_bCode11;
	BOOL	m_bCode128;
	BOOL	m_bCode35;
	BOOL	m_bCode39;
	BOOL	m_bCode93;
	BOOL	m_bEan13;
	BOOL	m_bEan8;
	BOOL	m_bGs1;
	BOOL	m_bGs1Expanded;
	BOOL	m_bGs1Limited;
	BOOL	m_bI2of5;
	BOOL	m_bMsi;
	BOOL	m_bPlessey;
	BOOL	m_bUpca;
	BOOL	m_bUpce;
	BOOL	m_bBookLand;
	BOOL	m_bCode32;
	BOOL	m_bPzn;
	BOOL	m_bUccean128;
	BOOL	m_bXmitAIMID;
	BOOL	m_bTelepen;
	int		m_nSyncMode;
	int		m_nSound;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CSymbologyPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CSymbologyPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SYMBOLOGYPAGE_H__6D087220_5074_4474_9D66_41C4F7542595__INCLUDED_)
