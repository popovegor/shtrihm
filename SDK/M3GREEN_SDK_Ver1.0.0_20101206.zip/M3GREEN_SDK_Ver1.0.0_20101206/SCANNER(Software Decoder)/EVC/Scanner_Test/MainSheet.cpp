/********************************************************************
created		:	2009/09/20
file base	: 	M3ScanTest.exe

file ext	:	cpp
author		:	Dong-Hyun, Eum(vision7901) - Applied Development Team

purpose		:	M3 Green
Report		:	2009. 03. 25 [03/25/2009 vision7901] v1.9.0 - �������� ����
				2009. 07. 03 [07/03/2009 vision7901] v2.0.0 - Option2Page �߰�(���ڵ庰 Check Digit�� Convert)
				2009. 09. 20 [09/20/2009 vision7901] v2.0.0 - GS1 ���ڵ� �߰� �� ���ڵ庰 ���οɼ� ����, M3Green/M3T/M3Pos ���չ���
				2009. 10. 08 [10/08/2009 vision7901] v2.0.0 - UCC/EAN128 FNC1 ASCII����, AIM ID�߰�, I2of5 CDV, EAN13/UPCA �и�
				2009. 10. 28 [10/28/2009 JU		   ] v2.0.0 - �ߺ� ����� "aleady" ��Ÿ ���� => already
				2009. 11. 02 [11/02/2009 vision7901] v2.0.0 - I2OF5 ���� Enable ���� ����
				2009. 11. 06 [11/06/2009 vision7901] v2.0.0 - EAN-8 Enable ���� ����
				2010. 01. 06 [01/06/2010 vision7901] v2.0.0 - WideScan �� ��Ÿ ���� ����/ Beep Sound �߰�
				2010. 02. 26 [02/26/2010 vision7901] v2.1.0 - Telepen �߰�
				2010. 03. 17 [03/17/2010 vision7901] v2.2.0 - Code11/Code39/MSI ����/ Sound���� ����/ ��� ���ڵ� Enable/ 
															  Min,Max Length 6-30���� �ʱ�ȭ 
				2010. 04. 22 [04/22/2010 vision7901] v2.3.0 - Min,Max Length 4-50���� �ʱ�ȭ. TimeOut �ɼ� �޺��ڽ��� ����/ Device���� ��� ��� ����
				2010. 06. 21 [06/21/2010 vision7901] v3.0.0 - WinCE, WM ���� ����(WinCE Ȧ��, WM ¦��)
*********************************************************************/
// MainSheet.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "MainSheet.h"

#include <keybd.h>
#include "Msgqueue.h"		// �޽��� ť ����
#include "pm.h"				// �������� ����
#include <pkfuncs.h>		// ��������
#include "MC9000_IoCtl.h"	// M3Pos ��������
#include "Reg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////////////////////////////////////////////////////////////

#define QUEUE_ENTRIES   3
#define MAX_NAMELEN     200
#define QUEUE_SIZE      (QUEUE_ENTRIES * (sizeof(POWER_BROADCAST) + MAX_NAMELEN))

#define DEVICE_M3GREEN	1
#define DEVICE_M3T		2
#define DEVICE_M3POS	3

int			KSCANAPI KScanReadCallBack(LPVOID pRead);
DWORD		ThreadFunc(LPVOID pParam);
void		PumpMessage();
void		DumpToFile(char* pBuf, int nLen);

KSCANREAD	 kRead;
KSCANREADEX	 kReadEx;
KSCANREADEX2 kReadEx2;

BYTE         FNC1_Ascii[]=""; 

ScanInfo	 info;
int          bOneExcuteThread = FALSE;	// Thread Function ��ø���� ����

// Type - 0:MC6300S, 1:MC6400S, 2:MC6500S, 3:MC6100S, 4:MC6700S, 5:MC9000S
CReg	g_Reg;
int		g_nDeviceType = 0;	

/////////////////////////////////////////////////////////////////////////////
// CMainSheet

IMPLEMENT_DYNAMIC(CMainSheet, CPropertySheet)

CMainSheet::CMainSheet(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
	m_pApp		= (CM3ScanTestApp *)AfxGetApp();
	m_nStatus	= 0;
	m_bReading	= FALSE;
	m_bKeyFlag	= FALSE;

	AddPage(&m_ScanPage);
	AddPage(&m_SymbologyPage);
	AddPage(&m_OptionPage);
}

CMainSheet::CMainSheet(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	m_pApp		= (CM3ScanTestApp *)AfxGetApp();
	m_nStatus	= 0;
	m_bReading	= FALSE;
	m_bKeyFlag	= FALSE;

	AddPage(&m_ScanPage);
	AddPage(&m_SymbologyPage);
	AddPage(&m_OptionPage);
}

CMainSheet::~CMainSheet()
{
	RemovePage(&m_ScanPage);
	RemovePage(&m_SymbologyPage);
	RemovePage(&m_OptionPage);
}


BEGIN_MESSAGE_MAP(CMainSheet, CPropertySheet)
	//{{AFX_MSG_MAP(CMainSheet)
	ON_WM_DESTROY()
	ON_MESSAGE(WM_DATA_READ,OnScanRead)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainSheet message handlers

BOOL CMainSheet::OnInitDialog() 
{
	BOOL bResult = CPropertySheet::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);
	SetWindowText(_T("M3ScanTest"));
	
	//////////////////////////////////////////////////////////////////////////
	// Device
	TCHAR szModel[1024] = {0, };
	TCHAR szM3T[1024] = L"M3-T(MC-6700S)";
	TCHAR szM3Pos[1024] = L"M3 POS";
	
	g_Reg.GetRegStr(HKEY_LOCAL_MACHINE, L"System\\MobileCompia\\OSVersion", L"Model", szModel);

	if(wcscmp(szModel, szM3T) == 0)
	{		
		g_nDeviceType = DEVICE_M3T;
	}
	else if(wcscmp(szModel, szM3Pos) == 0)
	{			
		g_nDeviceType = DEVICE_M3POS;
	}
	else
	{			
		g_nDeviceType = DEVICE_M3GREEN;
	}

	//////////////////////////////////////////////////////////////////////////
	
	return bResult;
}

BOOL CMainSheet::PreTranslateMessage(MSG* pMsg) 
{
	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_F22)
	{		
		if(m_bKeyFlag == FALSE)
		{
			m_bKeyFlag = TRUE;				
			M3_ScanRead();			
		}

		return	TRUE;		
	}
	else if(pMsg->message == WM_KEYUP && pMsg->wParam == VK_F22)
	{				
		if(m_bKeyFlag == TRUE)
		{
			m_bKeyFlag = FALSE;
			
			if(m_SymbologyPage.m_nSyncMode == 0)
			{		
				m_KScan.ReadCancel();
				m_bReading = FALSE;				
			}
		}
		
		return	TRUE;
	}
	
	return CPropertySheet::PreTranslateMessage(pMsg);
}

void CMainSheet::OnDestroy() 
{
	CPropertySheet::OnDestroy();
	
	M3_ScanClose();
}

void CMainSheet::M3_ScanInit(int nPortNumber)
{
	CString	Str;
	BOOL	bRet		= TRUE;
	int		i			= 0;
	DWORD	dwCpldID	= CPLD_ID_SCAN_ON;
	DWORD	dwOut		= 0;
	
	// Power On
	if(g_nDeviceType != DEVICE_M3T)	// M3T�� ����
	{
		if(g_nDeviceType == DEVICE_M3POS)
		{		
			for(i=0; i < 3; i++)
			{
				dwOut		= 1;	
				bRet = KernelIoControl(IOCTL_CPLD_WRITE, &dwCpldID, sizeof(DWORD), &dwOut, sizeof(DWORD), NULL);
				if(bRet)break;
				::Sleep(100);
			}
		}
		else
		{
			for(i=0;i < 3 ; i++)
			{				
				bRet = KernelIoControl(IOCTL_HAL_SCAN_POWER_EN, NULL, NULL, NULL, NULL, NULL);		
				if(bRet)break;
				Sleep(100);
			}
		}		
	}
	
	Sleep (200);
	if(!bRet)
	{
		::MessageBox(NULL, L"Scanner Power ON Failed", NULL, MB_TOPMOST);
	}
	
	m_bKeyFlag = FALSE; 
	
	bRet = M3_ScanOpen(nPortNumber);
	
	if(bRet)
	{
		// Thread �ߺ� ���� ����
		if (!bOneExcuteThread) 
		{
			DWORD ThreadID;
			HANDLE hThread = CreateThread(NULL, 0, ThreadFunc, this, 0, &ThreadID);
			CloseHandle(hThread);
			
			bOneExcuteThread = TRUE;
		} 
	}
	else
	{
		::MessageBox(NULL, L"Scanner Open Failed", NULL, MB_TOPMOST);
	}	
}

BOOL CMainSheet::M3_ScanOpen(int nPortNumber)
{
	BOOL	bRet;
	int		nPort;
	
	nPort = nPortNumber;
	
	bRet = m_KScan.Open(6, FALSE,	CBR_115200,	FALSE, NULL);
	if(!bRet)
	{
		CString Str;
		Str.Format(_T("Scanner Open Error: %s"), KScanGetLastErrorMsg());		
		AfxMessageBox(Str);
	}

	// KSCANREAD Default Setting
	DefaultSetting();

	return bRet;
}

BOOL CMainSheet::M3_ScanClose()
{
	BOOL	bRet		= FALSE;
	int		i			= 0;
	DWORD	dwCpldID	= CPLD_ID_SCAN_ON;
	DWORD	dwOut		= 0;
	
	for(i=0;i<3;i++)
	{		
		if(m_KScan.Close())
			break;
		Sleep(100);
	}

	if(g_nDeviceType != DEVICE_M3T)	// M3T�� ����
	{
		if(g_nDeviceType == DEVICE_M3POS)
		{
			for(i=0; i < 3; i++)
			{
				dwOut		= 0;	
				bRet = KernelIoControl(IOCTL_CPLD_WRITE, &dwCpldID, sizeof(DWORD), &dwOut, sizeof(DWORD), NULL);
				if(bRet)break;
				::Sleep(100);
			}
		}
		else
		{
			for(i=0;i < 3 ; i++)
			{
				bRet =KernelIoControl(IOCTL_HAL_SCAN_POWER_DIS, NULL, NULL, NULL, NULL, NULL);		
				if(bRet)break;
				Sleep(100);
			}
		}		
	}	
	
	return 0;
}

void CMainSheet::M3_ScanRead()
{
	CString		Str;
	BOOL		bRet;	
	m_bReading = TRUE;
	
	if (m_bReading) 
	{	// Reading already in progress, now cancel it.
		bRet = m_KScan.ReadCancel();
		
		if (bRet) 
		{
			m_bReading = FALSE;
		} 
		else 
		{
			Str = _T("Error ReadCancel\r\n");
			Str += KScanGetLastErrorMsg();
		}
	}
	
	m_bReading = TRUE;	
	bRet =	m_KScan.Read(&kRead);	
	if (!bRet) {
		Str.Format(_T("Error Read \r\n%d\r\n%s"), kRead.out_Status, KScanGetLastErrorMsg());
		m_bReading = FALSE;
	}
}

LRESULT CMainSheet::OnScanRead(WPARAM wParam,LPARAM lParam)
{
	m_ScanPage.Write_ScanData(info.gstrCodeTypeName, info.gstrBarCodeValue);
	return TRUE;
}

int KSCANAPI KScanReadCallBack(LPVOID pRead)
{
	int			Status;
	int			Type;
	
	CMainSheet* lpCls = (CMainSheet*)((PKSCANREAD)pRead)->pUserData;
	Status = ((PKSCANREAD)pRead)->out_Status;
	
	switch(Status) {
	case KSCAN_RET_TIMEOUT:			// Timed out.
		Status = 0;
		break;
	case KSCAN_RET_USER_CANCEL:		// User called stop
		Status = 0;
		break;
		
	case KSCAN_RET_NORMAL:		// Barcode was read
	case KSCAN_RET_TYPE_UNKNOWN: 
		Status = 0;
		if(((PKSCANREAD)pRead)->out_Type == -1)
			break;
		if(((PKSCANREAD)pRead)->out_Status == KSCAN_RET_NORMAL)
		{
			if(!lpCls->m_bReading)return 0;
			
			Type = ((PKSCANREAD)pRead)->out_Type;
			info.gstrCodeTypeName = _T("");
			lpCls->SetBarCodeString(Type);
			info.gstrBarCodeValue = _T("");
			info.gstrBarCodeValue = ((PKSCANREAD)pRead)->out_Barcode;
			::PostMessage(lpCls->m_hWnd, WM_DATA_READ, 0, 0);
			
			lpCls->LoadResourceSound();

		}		
		lpCls->m_bReading = FALSE;
		break;
		
	case KSCAN_RET_BAR_NOTFOUND:	// Not yet found - Continue.
	case KSCAN_RET_NORMAL_SWEEP:	// barcode was read, and security criteria was not met yet
		Status = 1;
		break;
		
	default:	// Other error.
		Status = 0;					// just continue reading until barcode was read with security criteria met
		break;
	}	
	return Status;
}

DWORD ThreadFunc(LPVOID pParam)
{
	CMainSheet*	m_pbar = (CMainSheet*) pParam;

	MSGQUEUEOPTIONS	lm_Options;
	HANDLE			lm_hPMMQ, lm_hPMNoti;
	DWORD			lm_dwErrCode, lm_dwPri = 251, lm_dwCount = 0;
	CString			lm_szErr;
	UCHAR			lm_ucBuf[QUEUE_SIZE];
	DWORD			lm_dwReadSize = 0, lm_dwFlags;
	BOOL			lm_bResult;
	DWORD			lm_dwWaitReturn = 0;

	lm_Options.dwSize			= sizeof (MSGQUEUEOPTIONS);
	lm_Options.dwFlags			= MSGQUEUE_ALLOW_BROKEN;
	lm_Options.dwMaxMessages	= 10;							// �޽���ť�� ���� �ִ� �޽��� ����
	lm_Options.cbMaxMessage		= QUEUE_SIZE;					// �޽��� �ϳ��� �ִ� ������
	lm_Options.bReadAccess		= TRUE;

	lm_hPMMQ = CreateMsgQueue (NULL, &lm_Options);				// �޽��� ť ����
	if (lm_hPMMQ == NULL)
	{
		lm_dwErrCode = GetLastError();
		lm_szErr.Format (TEXT("CreateMsgQueue ERROR:%d\n"), lm_dwErrCode);
        AfxMessageBox (lm_szErr);
		goto _Exit;
	}

	//RESUME�ÿ� �˸� ��û�� ����մϴ�.
	lm_hPMNoti = RequestPowerNotifications (lm_hPMMQ, PBT_RESUME);//PBT_TRANSITION);
	if (lm_hPMNoti == NULL)
	{
		lm_dwErrCode = GetLastError();
		lm_szErr.Format (TEXT("RequestPowerNotifications ERROR:%d\n"), lm_dwErrCode);
        AfxMessageBox (lm_szErr);
		goto _Exit;
	}

	while (1)
	{
		memset (&lm_ucBuf, 0, QUEUE_SIZE);

		lm_dwWaitReturn = WaitForSingleObject (lm_hPMMQ, 100);

		if (lm_dwWaitReturn == WAIT_TIMEOUT)
		{
			continue;
		}

		lm_bResult = ReadMsgQueue (lm_hPMMQ, &lm_ucBuf, sizeof (POWER_BROADCAST), &lm_dwReadSize, INFINITE, &lm_dwFlags);

		if(lm_bResult)
		{
			if (lm_dwReadSize >= sizeof(POWER_BROADCAST))
			{
				PPOWER_BROADCAST	pB = (PPOWER_BROADCAST)&lm_ucBuf;
				if(pB->Message == PBT_RESUME)
				{
					
					CM3ScanTestApp * app = (CM3ScanTestApp *)AfxGetApp();	

					app->InitialDlg->ShowWindow(SW_SHOW);		

					//**** Scanner�� �� �ʱ�ȭ ��ŵ�ϴ�. ****										
				//	m_pbar->MC6000s_ScanClose();
				//	m_pbar->MC6000s_ScanInit(6);
					m_pbar->ResumeProcess();
					//***************************************************************
					app->InitialDlg->ShowWindow(SW_HIDE);

				}
			}
		}
		else
		{
			lm_dwErrCode = GetLastError ();
			lm_szErr.Format (_T("ReadMsgQueue : %d"), lm_dwErrCode);
			AfxMessageBox (lm_szErr);
			goto _Exit;
		}
	}

_Exit:
	StopPowerNotifications (lm_hPMNoti);
	CloseMsgQueue (lm_hPMMQ);

	//*** ������ : Thread Function�� ��ø ������ ���ɼ��� �־� �ѹ��� �����Ű�� ����� ���� Flag �߰� ������׽��ϴ�.
	bOneExcuteThread = FALSE;

	return 0;
}

void CMainSheet::ResumeProcess()
{
	int i;
	for(i=0;i<3;i++)
	{		
		if(m_KScan.Close())
			break;
		Sleep(100);
	}
	
	M3_ScanInit(6);
}

void DumpToFile(char* pBuf, int nLen)
{
	HANDLE hFile;
	int		nCnt = 0;
	int		i;
	DWORD	dwWritten;
	char	pTemp[256] = {0, };
	hFile = CreateFile(_T("Dump.txt"), GENERIC_WRITE | GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		hFile = CreateFile(_T("Dump.txt"), GENERIC_WRITE | GENERIC_READ, 0, NULL, CREATE_ALWAYS, 0, NULL);
	}

	for(i=0; i<nLen; i++)
	{
		if		(pBuf[i] == 0x0D) 
		{
			strcat(pTemp, "<cr>");
			nCnt += 4;
		}
		else if (pBuf[i] == 0x0A)
		{
			 strcat(pTemp, "<lf>");
			 nCnt += 4;
		}
		else
		{
			pTemp[nCnt] = pBuf[i];
			nCnt++;
		}
	}

	pTemp[nCnt] = 0x0A; nCnt++;
	SetFilePointer(hFile, 0, NULL, FILE_END);
	WriteFile(hFile, pTemp, nCnt, &dwWritten, NULL);

	CloseHandle(hFile);
}

void PumpMessage()
{	
	INT n = 5;
	MSG msg;
	while(--n)
	{
		if (PeekMessage(&msg,FindWindow(NULL, _T("M3 Scanner Test")),0,0,PM_REMOVE)) 
		{
			::TranslateMessage(&msg); 
			::DispatchMessage(&msg); 
		}
	}
}



BOOL CMainSheet::SetBarCodeString(int nType)
{
	switch(nType)
	{
	case KSCAN_RET_TYPE_EAN_13:		//0
		info.gstrCodeTypeName += "EAN-13";
		break;
	case KSCAN_RET_TYPE_EAN_8:		//1
		info.gstrCodeTypeName += "EAN-8";
		break;
	case KSCAN_RET_TYPE_UPCA:		//2
		info.gstrCodeTypeName += "UPC-A";
		break;
	case KSCAN_RET_TYPE_UPCE:		//3
		info.gstrCodeTypeName += "UPC-E";
		break;
	case KSCAN_RET_TYPE_CODE_39:	//4
		info.gstrCodeTypeName += "CODE 39";
		break;
	case KSCAN_RET_TYPE_ITF_14:		//5
		info.gstrCodeTypeName += "ITF 14";
		break;
	case KSCAN_RET_TYPE_CODE_128:	//6
		info.gstrCodeTypeName += "CODE 128";
		break;
	case KSCAN_RET_TYPE_CODE_I25:	//7
		info.gstrCodeTypeName += "Interleaved 2of5";
		break;
	case KSCAN_RET_TYPE_CODA_BAR:	//8
		info.gstrCodeTypeName += "CODABAR";
		break;
	case KSCAN_RET_TYPE_UCCEAN_128:	//9
		info.gstrCodeTypeName += "UCC/EAN-128";
		break;
	case KSCAN_RET_TYPE_CODE_93:	//10
		info.gstrCodeTypeName += "CODE 93";
		break;
	case KSCAN_RET_TYPE_CODE_35:	//11
		info.gstrCodeTypeName += "CODE 35";
		break;
	case KSCAN_RET_TYPE_PDF417:		//12	- Not Supported
		info.gstrCodeTypeName += "PDF417";
		break;
	case KSCAN_RET_TYPE_MACRO_PDF417://13	- Not Supported
		info.gstrCodeTypeName += "Micro PDF417";
		break;
	case KSCAN_RET_TYPE_BOOKLAND:	//14
		info.gstrCodeTypeName += "BOOKLAND_EAN";
		break;
	case KSCAN_RET_TYPE_MSI:		//15
		info.gstrCodeTypeName += "MSI";
		break;
	case KSCAN_RET_TYPE_PZN:		//16
		info.gstrCodeTypeName += "PZN";
		break;
	case KSCAN_RET_TYPE_PLESSEY:		//17
		info.gstrCodeTypeName += "PLESSEY";
		break;
	case KSCAN_RET_TYPE_MACRO_PDF417_INC:	//18 - Not Supported
		info.gstrCodeTypeName += "PDF417_INC";
		break;
	case KSCAN_RET_TYPE_MACRO_PDF417_ERROR://19 - Not Supported
		info.gstrCodeTypeName += "PDF417_ERROR";
		break;
	case KSCAN_RET_TYPE_CODE25_MATRIX:	//20
		info.gstrCodeTypeName += "CODE25_MATRIX";
		break;
	case KSCAN_RET_TYPE_CODE25_DLOGIC:	//21
		info.gstrCodeTypeName += "CODE25_DLOGIC";
		break;
	case KSCAN_RET_TYPE_CODE25_INDUSTRY://22
		info.gstrCodeTypeName += "CODE25_INDUSTRY";
		break;
	case KSCAN_RET_TYPE_CODE25_IATA:	//23
		info.gstrCodeTypeName += "CODE25_IATA";
		break;
	case KSCAN_RET_TYPE_CODE25_GTIN14:	//24
		info.gstrCodeTypeName += "CODE25_GTIN14";
		break;
	case KSCAN_RET_TYPE_CODE25_DPL:		//25
		info.gstrCodeTypeName += "CODE25_DPL";
		break;
	case KSCAN_RET_TYPE_CODE25_DPI:		//26
		info.gstrCodeTypeName += "CODE25_DPI";
		break;
	case KSCAN_RET_TYPE_CODE11:			//27
		info.gstrCodeTypeName += "CODE 11";
		break;
	case KSCAN_RET_TYPE_CODE32:			//28
		info.gstrCodeTypeName += "CODE 32";
		break;
	case KSCAN_RET_TYPE_COUPONCODE:		//29
		info.gstrCodeTypeName += "COUPONCODE";
		break;
	case KSCAN_RET_TYPE_CODABLOCK_A:	//30
		info.gstrCodeTypeName += "CODABLOCK_A";
		break;
	case KSCAN_RET_TYPE_CODABLOCK_F:	//31
		info.gstrCodeTypeName += "CODABLOCK_F";
		break;
	case KSCAN_RET_TYPE_GS1:			//32
		info.gstrCodeTypeName += "GS1";
		break;
	case KSCAN_RET_TYPE_GS1_LIMITED:	//33
		info.gstrCodeTypeName += "GS1_LIMITED";
		break;
	case KSCAN_RET_TYPE_GS1_EXPANDED:	//34
		info.gstrCodeTypeName += "GS1_EXPANDED";
		break;
	case KSCAN_RET_TYPE_STANDARD2OF5:	//35
		info.gstrCodeTypeName += "STANDARD 2OF5";
		break;
	case KSCAN_RET_TYPE_TELEPEN:		//36
		info.gstrCodeTypeName += "TELEPEN";
		break;
	case KSCAN_RET_TYPE_UNKNOWN:
		info.gstrCodeTypeName += "UNKNOWN TYPE";
		break;	
		
	}

	return 0;
}

void CMainSheet::LoadResourceSound()
{
	HINSTANCE hInst = AfxGetInstanceHandle();
	if(m_SymbologyPage.m_nSound == 0)
		PlaySound(MAKEINTRESOURCE(IDR_WAVE_SCAN), hInst, SND_RESOURCE|SND_ASYNC);
	else if(m_SymbologyPage.m_nSound == 1)
		PlaySound(MAKEINTRESOURCE(IDR_WAVE_BEEP), hInst, SND_RESOURCE|SND_ASYNC);
}

void CMainSheet::DefaultSetting()
{
	////////////////////////////////////////////////////////
	// KSCANREAD kRead �ʱ�ȭ
    memset(&kRead, 0, sizeof(kRead));
	kRead.nSize = sizeof(kRead);

	// KSCANREADEX2 kReadEx2 �ʱ�ȭ
	memset(&kReadEx2, 0, sizeof(kReadEx2));
	strcat(kReadEx2.Signature, "KSCANEX2");

	kRead.nTimeInSeconds	= 10;	// time out
	kRead.nMinLength		= 2;	// minimum data length
	kRead.nSecurity			= 1;    // security
	kReadEx2.XmitAIMID		= DISABLE;

	// KScanReadCallBack
 	kRead.pUserData		= this;	
 	kRead.fnCallBack	= KScanReadCallBack;
	
	kRead.dwFlags |= KSCAN_FLAG_WIDESCANANGLE;


	//UPCA
	kReadEx2.UpcA.Enable		= ENABLE;
	kReadEx2.UpcA.Format		= AS_UPCA;
	kReadEx2.UpcA.XmitNumber	= XMIT_NUMBER;
	kReadEx2.UpcA.XmitCheckDigit= XMIT_CHECK_DIGIT;
	kReadEx2.UpcA.Supp			= NO_Supp;  

	//UPCE
	kReadEx2.UpcE.Enable		= ENABLE;
	kReadEx2.UpcE.Format		= AS_UPCE;
	kReadEx2.UpcE.XmitNumber	= XMIT_NUMBER;
	kReadEx2.UpcE.XmitCheckDigit= XMIT_CHECK_DIGIT;
    kReadEx2.UpcE.Supp			= NO_Supp;	// Not Supported

	//EAN13
	kReadEx2.Ean13.Enable		= ENABLE;
	kReadEx2.Ean13.Format		= AS_BOOKLAND;		// Including AS_EAN13;
	kReadEx2.Ean13.XmitNumber	= NO_XMIT_NUMBER;
	kReadEx2.Ean13.XmitCheckDigit= XMIT_CHECK_DIGIT;
    kReadEx2.Ean13.Supp			= NO_Supp;			

	//EAN8
	kReadEx2.Ean8.Enable		= ENABLE;
	kReadEx2.Ean8.Format		= AS_EAN8;
	kReadEx2.Ean8.XmitNumber	= NO_XMIT_NUMBER;
	kReadEx2.Ean8.XmitCheckDigit= XMIT_CHECK_DIGIT;   
	kReadEx2.Ean8.Supp			= NO_Supp;	// Not Supported

    //Code39
	kReadEx2.Code39.Enable		= ENABLE;
	kReadEx2.Code39.MinLength	= 4;
    kReadEx2.Code39.MaxLength	= 30;
    kReadEx2.Code39.SetAscii	= STD_ASCII;
    kReadEx2.Code39.CDV			= DISABLE;      
	kReadEx2.Code39.XmitCheckDigit= NO_XMIT_CHECK_DIGIT;
	kReadEx2.Code39.AsCode32	= ENABLE;
    kReadEx2.Code39.AsPZN		= ENABLE;

	//Code128
	kReadEx2.Code128.Enable		= ENABLE;
    kReadEx2.Code128.AsUCCEAN128= ENABLE;
	kReadEx2.Code128.FNC1_ASCII = FNC1_Ascii; //NULL: No FNC1 conversion
    kReadEx2.Code128.MinLength	= 4;
    kReadEx2.Code128.MaxLength	= 30;

	//Code93
	kReadEx2.Code93.Enable		= ENABLE;
    kReadEx2.Code93.MinLength	= 4;
    kReadEx2.Code93.MaxLength	= 30;

    //Code35
	kReadEx2.Code35.Enable		= ENABLE;

	//Code11
    kReadEx2.Code11.Enable		= ENABLE;
	kReadEx2.Code11.MinLength	= 4;
    kReadEx2.Code11.MaxLength	= 30;
	kReadEx2.Code11.CheckDigit	= DIGIT1;                          
    kReadEx2.Code11.XmitCheckDigit= NO_XMIT_CHECK_DIGIT; 
 
	//Interleaved 2of5
	kReadEx2.Code25.Enable		= ENABLE;
    kReadEx2.Code25.MinLength	= 4;
    kReadEx2.Code25.MaxLength	= 30;
    kReadEx2.Code25.CDV			= DISABLE;       
    kReadEx2.Code25.XmitCheckDigit= NO_XMIT_CHECK_DIGIT; 
	kReadEx2.Code25.KindofDecode = (CODE25KIND_INTER | CODE25KIND_ITF14|CODE25KIND_MATRIX | CODE25KIND_INDUSTRY | CODE25KIND_DLOGIC | CODE25KIND_IATA); 
//	kReadEx2.Code25.KindofDecode |= (CODE25KIND_MATRIX | CODE25KIND_INDUSTRY | CODE25KIND_DLOGIC | CODE25KIND_IATA); 

    //Codabar
    kReadEx2.Codabar.Enable			= ENABLE;
    kReadEx2.Codabar.XmitStartStop	= NO_XMIT;
    kReadEx2.Codabar.MinLength		= 4;
    kReadEx2.Codabar.MaxLength		= 30;
   
	//MSI
	kReadEx2.Msi.Enable			= ENABLE;
    kReadEx2.Msi.CDV			= ENABLE;                         
    kReadEx2.Msi.XmitCheckDigit	= NO_XMIT_CHECK_DIGIT; 
    kReadEx2.Msi.MinLength		= 4;
    kReadEx2.Msi.MaxLength		= 30;

	//Plessey
    kReadEx2.Plessey.Enable		= ENABLE;
    kReadEx2.Plessey.CDV		= ENABLE;                          
    kReadEx2.Plessey.XmitCheckDigit= NO_XMIT_CHECK_DIGIT;  
    kReadEx2.Plessey.MinLength	= 4;
    kReadEx2.Plessey.MaxLength	= 30;

	//GS1
    kReadEx2.Gs1.Enable			= ENABLE;

	//GS1 Limited
	kReadEx2.Gs1Limited.Enable	= ENABLE;

	//GS1 Expanded
	kReadEx2.Gs1Expanded.Enable	= ENABLE;

	// Telepen
	kReadEx2.Telepen.Enable		= ENABLE;
	kReadEx2.Telepen.OldStyle	= DISABLE;

	//////////////////////////////////////////////////////////////////////////

	// Koamtak���� ȣȯ������ ���� �߰�
	kRead.dwReadType |= KSCAN_READ_TYPE_EAN_13;
	kRead.dwReadType |= KSCAN_READ_TYPE_EAN_8;
	kRead.dwReadType |= KSCAN_READ_TYPE_UPCA;
	kRead.dwReadType |= KSCAN_READ_TYPE_UPCE;
	kRead.dwReadType |= KSCAN_READ_TYPE_CODE_39;
	kRead.dwReadType |= KSCAN_READ_TYPE_ITF_14;
	kRead.dwReadType |= KSCAN_READ_TYPE_CODE_128;
	kRead.dwReadType |= KSCAN_READ_TYPE_CODE_I25;
	kRead.dwReadType |= KSCAN_READ_TYPE_CODA_BAR;
	kRead.dwReadType |= KSCAN_READ_TYPE_UCCEAN_128;
	kRead.dwReadType |= KSCAN_READ_TYPE_CODE_93;
	kRead.dwReadType |= KSCAN_READ_TYPE_CODE_35;
	kRead.dwReadType |= KSCAN_READ_TYPE_BOOKLAND;
	kRead.dwReadType |= KSCAN_READ_TYPE_EAN_13_ADDON;
	kRead.dwReadType |= KSCAN_READ_TYPE_EAN_8_ADDON;
	kRead.dwReadType |= KSCAN_READ_TYPE_UPCA_ADDON;
	kRead.dwReadType |= KSCAN_READ_TYPE_UPCE_ADDON;
	kRead.dwReadType |= KSCAN_READ_TYPE_MSI;
	kRead.dwReadType |= KSCAN_READ_TYPE_PZN;
	kRead.dwReadType |= KSCAN_READ_TYPE_CODE25_MATRIX;
	kRead.dwReadType |= KSCAN_READ_TYPE_CODE25_DLOGIC;
	kRead.dwReadType |= KSCAN_READ_TYPE_CODE25_INDUSTRY;
	kRead.dwReadType |= KSCAN_READ_TYPE_CODE25_IATA;
	kRead.dwReadType |= KSCAN_READ_TYPE_PLESSEY;
	kRead.dwReadType |= KSCAN_READ_TYPE_CODE11;
	kRead.dwReadType |= KSCAN_READ_TYPE_CODE32;
	kRead.dwReadType |= KSCAN_READ_TYPE_COUPONCODE;
	kRead.dwReadType |= KSCAN_READ_TYPE_GTIN14;
	kRead.dwReadType |= KSCAN_READ_TYPE_GS1;
	kRead.dwReadType |= KSCAN_READ_TYPE_GS1_LIMITED;
	kRead.dwReadType |= KSCAN_READ_TYPE_GS1_EXPANDED;

	kRead.pReadEx=&kReadEx2;
}


void CMainSheet::SetReadOption()
{
	if(kReadEx2.UpcA.Enable == FALSE)
	{
		m_SymbologyPage.m_bUpca = FALSE;
	}
	else
	{
		m_SymbologyPage.m_bUpca = TRUE;
	}
	
	m_SymbologyPage.m_bUpce			= kReadEx2.UpcE.Enable;
	m_SymbologyPage.m_bEan13		= kReadEx2.Ean13.Enable;
	m_SymbologyPage.m_bEan8			= kReadEx2.Ean8.Enable;
	m_SymbologyPage.m_bCode39		= kReadEx2.Code39.Enable;
	m_SymbologyPage.m_bCode128		= kReadEx2.Code128.Enable;
	m_SymbologyPage.m_bCode93		= kReadEx2.Code93.Enable;
	m_SymbologyPage.m_bCode35		= kReadEx2.Code35.Enable;
	m_SymbologyPage.m_bCode11		= kReadEx2.Code11.Enable;
	m_SymbologyPage.m_bI2of5		= kReadEx2.Code25.Enable;
	m_SymbologyPage.m_bCodabar		= kReadEx2.Codabar.Enable;
	m_SymbologyPage.m_bMsi			= kReadEx2.Msi.Enable;
	m_SymbologyPage.m_bPlessey		= kReadEx2.Plessey.Enable;
	m_SymbologyPage.m_bGs1			= kReadEx2.Gs1.Enable;
	m_SymbologyPage.m_bGs1Expanded	= kReadEx2.Gs1Expanded.Enable;
	m_SymbologyPage.m_bGs1Limited	= kReadEx2.Gs1Limited.Enable;
	m_SymbologyPage.m_bUccean128	= kReadEx2.Code128.AsUCCEAN128;
	m_SymbologyPage.m_bCode32		= kReadEx2.Code39.AsCode32;
	m_SymbologyPage.m_bPzn			= kReadEx2.Code39.AsPZN;
	
	if(kReadEx2.Ean13.Format == AS_BOOKLAND)
		m_SymbologyPage.m_bBookLand = TRUE;
	else
		m_SymbologyPage.m_bBookLand = FALSE;

	m_SymbologyPage.m_ctrlComboTimeOut.SetCurSel(kRead.nTimeInSeconds-1);
	m_SymbologyPage.m_ctrlComboSecurityLevel.SetCurSel(kRead.nSecurity-1);
	m_SymbologyPage.m_bXmitAIMID	= kReadEx2.XmitAIMID;
	
	UpdateData(FALSE);
}
