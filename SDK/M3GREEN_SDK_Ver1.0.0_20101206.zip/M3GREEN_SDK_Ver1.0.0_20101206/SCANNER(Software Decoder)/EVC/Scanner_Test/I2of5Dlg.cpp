// I2of5Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "I2of5Dlg.h"
#include "MainSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CI2of5Dlg dialog

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;

CI2of5Dlg::CI2of5Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CI2of5Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CI2of5Dlg)
	m_bCDV = FALSE;
	m_bEnable = FALSE;
	m_bEnableDlogic = FALSE;
	m_bEnableIata = FALSE;
	m_bEnableIndustry = FALSE;
	m_bEnableItf14 = FALSE;
	m_bEnableMatrix = FALSE;
	m_bXCD = FALSE;
	m_nMaxLen = 0;
	m_nMinLen = 0;
	//}}AFX_DATA_INIT
}


void CI2of5Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CI2of5Dlg)
	DDX_Check(pDX, IDC_CHECK_CDV, m_bCDV);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_DLOGIC, m_bEnableDlogic);
	DDX_Check(pDX, IDC_CHECK_IATA, m_bEnableIata);
	DDX_Check(pDX, IDC_CHECK_INDUSTRY, m_bEnableIndustry);
	DDX_Check(pDX, IDC_CHECK_ITF14, m_bEnableItf14);
	DDX_Check(pDX, IDC_CHECK_MATRIX, m_bEnableMatrix);
	DDX_Check(pDX, IDC_CHECK_XMITCD, m_bXCD);
	DDX_Text(pDX, IDC_EDIT_MAXLEN, m_nMaxLen);
	DDX_Text(pDX, IDC_EDIT_MINLEN, m_nMinLen);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CI2of5Dlg, CDialog)
	//{{AFX_MSG_MAP(CI2of5Dlg)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, OnConfirm)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CI2of5Dlg message handlers

BOOL CI2of5Dlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);
	
	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CI2of5Dlg::OnConfirm() 
{
	SetOption();

	CMainSheet* dlg = (CMainSheet*)AfxGetMainWnd();
	
	dlg->SetReadOption();
	
	CDialog::OnOK();
	
}

void CI2of5Dlg::GetOption()
{
	if(kReadEx2.Code25.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;
	
	if(kReadEx2.Code25.CDV == ENABLE)
		m_bCDV = TRUE;
	else
		m_bCDV = FALSE;
	
	if(kReadEx2.Code25.XmitCheckDigit == XMIT_CHECK_DIGIT)
		m_bXCD = TRUE;
	else
		m_bXCD = FALSE;

	if((kReadEx2.Code25.KindofDecode & CODE25KIND_ITF14) && (kReadEx2.Code25.Enable == ENABLE))
		m_bEnableItf14 = TRUE;
	else
		m_bEnableItf14 = FALSE;

	if((kReadEx2.Code25.KindofDecode & CODE25KIND_MATRIX) && (kReadEx2.Code25.Enable == ENABLE))
		m_bEnableMatrix = TRUE;
	else
		m_bEnableMatrix = FALSE;

	if((kReadEx2.Code25.KindofDecode & CODE25KIND_DLOGIC) && (kReadEx2.Code25.Enable == ENABLE))
		m_bEnableDlogic = TRUE;
	else
		m_bEnableDlogic = FALSE;

	if((kReadEx2.Code25.KindofDecode & CODE25KIND_INDUSTRY) && (kReadEx2.Code25.Enable == ENABLE))
		m_bEnableIndustry = TRUE;
	else
		m_bEnableIndustry = FALSE;

	if((kReadEx2.Code25.KindofDecode & CODE25KIND_IATA) && (kReadEx2.Code25.Enable == ENABLE))
		m_bEnableIata = TRUE;
	else
		m_bEnableIata = FALSE;

	
	m_nMaxLen = kReadEx2.Code25.MaxLength;
	m_nMinLen = kReadEx2.Code25.MinLength;
	
	UpdateData(FALSE);
}

void CI2of5Dlg::SetOption()
{
	UpdateData(TRUE);
	
	if(m_bEnable == TRUE)
		kReadEx2.Code25.Enable = ENABLE;
	else
		kReadEx2.Code25.Enable = DISABLE;
	
	if(m_bCDV == TRUE)
		kReadEx2.Code25.CDV = ENABLE;
	else
		kReadEx2.Code25.CDV = DISABLE;
	
	if(m_bXCD == TRUE)
		kReadEx2.Code25.XmitCheckDigit = XMIT_CHECK_DIGIT;
	else
		kReadEx2.Code25.XmitCheckDigit = NO_XMIT_CHECK_DIGIT;

	kReadEx2.Code25.KindofDecode = CODE25KIND_INTER;

	if(m_bEnableItf14 == TRUE)
	{
		kReadEx2.Code25.Enable = ENABLE;
		kReadEx2.Code25.KindofDecode |= CODE25KIND_ITF14;
	}

	if(m_bEnableMatrix == TRUE)
	{
		kReadEx2.Code25.Enable = ENABLE;
		kReadEx2.Code25.KindofDecode |= CODE25KIND_MATRIX;
	}

	if(m_bEnableDlogic == TRUE)
	{
		kReadEx2.Code25.Enable = ENABLE;
		kReadEx2.Code25.KindofDecode |= CODE25KIND_DLOGIC;
	}

	if(m_bEnableIndustry == TRUE)
	{
		kReadEx2.Code25.Enable = ENABLE;
		kReadEx2.Code25.KindofDecode |= CODE25KIND_INDUSTRY;
	}

	if(m_bEnableIata == TRUE)
	{
		kReadEx2.Code25.Enable = ENABLE;
		kReadEx2.Code25.KindofDecode |= CODE25KIND_IATA;
	}
		
	kReadEx2.Code25.MaxLength = m_nMaxLen;
	kReadEx2.Code25.MinLength = m_nMinLen;
}


