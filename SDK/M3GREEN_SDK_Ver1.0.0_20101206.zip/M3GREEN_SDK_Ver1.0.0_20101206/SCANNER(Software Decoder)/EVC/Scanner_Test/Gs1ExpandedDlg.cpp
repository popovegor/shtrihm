// Gs1ExpandedDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "Gs1ExpandedDlg.h"
#include "MainSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGs1ExpandedDlg dialog

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;

CGs1ExpandedDlg::CGs1ExpandedDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGs1ExpandedDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGs1ExpandedDlg)
	m_bEnable = FALSE;
	//}}AFX_DATA_INIT
}


void CGs1ExpandedDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGs1ExpandedDlg)
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGs1ExpandedDlg, CDialog)
	//{{AFX_MSG_MAP(CGs1ExpandedDlg)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, OnConfirm)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGs1ExpandedDlg message handlers

BOOL CGs1ExpandedDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);
	
	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CGs1ExpandedDlg::OnConfirm() 
{
	SetOption();

	CMainSheet* dlg = (CMainSheet*)AfxGetMainWnd();
	
	dlg->SetReadOption();
	
	CDialog::OnOK();	
}

void CGs1ExpandedDlg::GetOption()
{
	if(kReadEx2.Gs1Expanded.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;
	
	UpdateData(FALSE);
}

void CGs1ExpandedDlg::SetOption()
{
	UpdateData(TRUE);
	
	if(m_bEnable == TRUE)
		kReadEx2.Gs1Expanded.Enable = ENABLE;
	else
		kReadEx2.Gs1Expanded.Enable = DISABLE;
}


