#if !defined(AFX_PLESSEYDLG_H__294968AF_B5B0_4897_8BD0_345003DE3A09__INCLUDED_)
#define AFX_PLESSEYDLG_H__294968AF_B5B0_4897_8BD0_345003DE3A09__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PlesseyDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPlesseyDlg dialog

class CPlesseyDlg : public CDialog
{
// Construction
public:
	void SetOption();
	void GetOption();
	CPlesseyDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPlesseyDlg)
	enum { IDD = IDD_PLESSEY_DLG };
	BOOL	m_bCDV;
	BOOL	m_bEnable;
	BOOL	m_bXCD;
	int		m_nMaxLen;
	int		m_nMinLen;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPlesseyDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPlesseyDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PLESSEYDLG_H__294968AF_B5B0_4897_8BD0_345003DE3A09__INCLUDED_)
