#if !defined(AFX_SCANPAGE_H__D22CC4F2_7F0F_4FA9_8DBE_D53257D1525F__INCLUDED_)
#define AFX_SCANPAGE_H__D22CC4F2_7F0F_4FA9_8DBE_D53257D1525F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ScanPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CScanPage dialog

class CScanPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CScanPage)

// Construction
public:
	void Write_ScanData(CString& BarType, CString& BarValue);
	CScanPage();
	~CScanPage();

// Dialog Data
	//{{AFX_DATA(CScanPage)
	enum { IDD = IDD_SCAN_DLG };
	CListCtrl	m_ctrlListctrlScanData;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CScanPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CScanPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnClose();
	afx_msg void OnScan();
	afx_msg void OnInfo();
	afx_msg void OnBtnScancancel();
	afx_msg void OnClear();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCANPAGE_H__D22CC4F2_7F0F_4FA9_8DBE_D53257D1525F__INCLUDED_)
