#if !defined(AFX_GS1LIMITEDDLG_H__7DE49B0B_19BA_4039_8C30_859EC8F06566__INCLUDED_)
#define AFX_GS1LIMITEDDLG_H__7DE49B0B_19BA_4039_8C30_859EC8F06566__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Gs1LimitedDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGs1LimitedDlg dialog

class CGs1LimitedDlg : public CDialog
{
// Construction
public:
	void SetOption();
	void GetOption();
	CGs1LimitedDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CGs1LimitedDlg)
	enum { IDD = IDD_GS1LIMITED_DLG };
	BOOL	m_bEnable;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGs1LimitedDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CGs1LimitedDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GS1LIMITEDDLG_H__7DE49B0B_19BA_4039_8C30_859EC8F06566__INCLUDED_)
