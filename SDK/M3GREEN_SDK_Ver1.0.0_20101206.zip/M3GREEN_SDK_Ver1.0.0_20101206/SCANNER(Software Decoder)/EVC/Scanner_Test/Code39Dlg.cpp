// Code39Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "Code39Dlg.h"
#include "MainSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCode39Dlg dialog

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;

CCode39Dlg::CCode39Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCode39Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCode39Dlg)
	m_bCDV = FALSE;
	m_bCode39AsCode32 = FALSE;
	m_bCode39AsPzn = FALSE;
	m_bEnable = FALSE;
	m_bFullASCII = FALSE;
	m_bXCD = FALSE;
	m_nMaxLen = 0;
	m_nMinLen = 0;
	//}}AFX_DATA_INIT
}


void CCode39Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCode39Dlg)
	DDX_Check(pDX, IDC_CHECK_CDV, m_bCDV);
	DDX_Check(pDX, IDC_CHECK_CODE39ASCOE32, m_bCode39AsCode32);
	DDX_Check(pDX, IDC_CHECK_CODE39ASPZN, m_bCode39AsPzn);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_FULLASCII, m_bFullASCII);
	DDX_Check(pDX, IDC_CHECK_XMITCD, m_bXCD);
	DDX_Text(pDX, IDC_EDIT_MAXLEN, m_nMaxLen);
	DDX_Text(pDX, IDC_EDIT_MINLEN, m_nMinLen);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCode39Dlg, CDialog)
	//{{AFX_MSG_MAP(CCode39Dlg)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, OnConfirm)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCode39Dlg message handlers

BOOL CCode39Dlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);
	
	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CCode39Dlg::OnConfirm() 
{
	SetOption();

	CMainSheet* dlg = (CMainSheet*)AfxGetMainWnd();
	
	dlg->SetReadOption();
	
	CDialog::OnOK();
	
}

void CCode39Dlg::GetOption()
{
	if(kReadEx2.Code39.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;

	if(kReadEx2.Code39.SetAscii == FULL_ASCII)
		m_bFullASCII = TRUE;
	else
		m_bFullASCII = FALSE;

	if(kReadEx2.Code39.CDV == ENABLE)
		m_bCDV = TRUE;
	else
		m_bCDV = FALSE;
	
	if(kReadEx2.Code39.XmitCheckDigit == XMIT_CHECK_DIGIT)
		m_bXCD = TRUE;
	else
		m_bXCD = FALSE;

	if((kReadEx2.Code39.AsCode32 == ENABLE) && (kReadEx2.Code39.Enable == ENABLE))
		m_bCode39AsCode32 = TRUE;
	else
		m_bCode39AsCode32 = FALSE;

	if((kReadEx2.Code39.AsPZN == ENABLE) && (kReadEx2.Code39.Enable == ENABLE))
		m_bCode39AsPzn = TRUE;
	else
		m_bCode39AsPzn = FALSE;
	
	m_nMaxLen = kReadEx2.Code39.MaxLength;
	m_nMinLen = kReadEx2.Code39.MinLength;
	
	UpdateData(FALSE);
}

void CCode39Dlg::SetOption()
{
	UpdateData(TRUE);
	
	if(m_bEnable == TRUE)
		kReadEx2.Code39.Enable = ENABLE;
	else
		kReadEx2.Code39.Enable = DISABLE;

	if(m_bFullASCII == TRUE)
		kReadEx2.Code39.SetAscii = FULL_ASCII;
	else
		kReadEx2.Code39.SetAscii = STD_ASCII;
	
	if(m_bCDV == TRUE)
		kReadEx2.Code39.CDV = ENABLE;
	else
		kReadEx2.Code39.CDV = DISABLE;
	
	if(m_bXCD == TRUE)
		kReadEx2.Code39.XmitCheckDigit = XMIT_CHECK_DIGIT;
	else
		kReadEx2.Code39.XmitCheckDigit = NO_XMIT_CHECK_DIGIT;
	
	if(m_bCode39AsCode32 == TRUE)
	{
		kReadEx2.Code39.Enable		= ENABLE;
		kReadEx2.Code39.AsCode32	= ENABLE;
	}
	else
	{
		kReadEx2.Code39.AsCode32	= DISABLE;
	}

	if(m_bCode39AsPzn == TRUE)
	{
		kReadEx2.Code39.Enable	= ENABLE;
		kReadEx2.Code39.AsPZN	= ENABLE;
	}
	else
	{
		kReadEx2.Code39.AsPZN = DISABLE;
	}

	kReadEx2.Code39.MaxLength = m_nMaxLen;
	kReadEx2.Code39.MinLength = m_nMinLen;

}

