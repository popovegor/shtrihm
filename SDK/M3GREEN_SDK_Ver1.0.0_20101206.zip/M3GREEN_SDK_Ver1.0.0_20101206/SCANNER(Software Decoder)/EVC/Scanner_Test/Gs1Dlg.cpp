// Gs1Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "Gs1Dlg.h"
#include "MainSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGs1Dlg dialog

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;


CGs1Dlg::CGs1Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGs1Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGs1Dlg)
	m_bEnable = FALSE;
	//}}AFX_DATA_INIT
}


void CGs1Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGs1Dlg)
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGs1Dlg, CDialog)
	//{{AFX_MSG_MAP(CGs1Dlg)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, OnConfirm)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGs1Dlg message handlers

BOOL CGs1Dlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);
	
	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CGs1Dlg::OnConfirm() 
{
	SetOption();

	CMainSheet* dlg = (CMainSheet*)AfxGetMainWnd();
	
	dlg->SetReadOption();
	
	CDialog::OnOK();
	
}

void CGs1Dlg::GetOption()
{
	if(kReadEx2.Gs1.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;

	UpdateData(FALSE);
}

void CGs1Dlg::SetOption()
{
	UpdateData(TRUE);
	
	if(m_bEnable == TRUE)
		kReadEx2.Gs1.Enable = ENABLE;
	else
		kReadEx2.Gs1.Enable = DISABLE;
}


