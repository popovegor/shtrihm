// UpceDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "UpceDlg.h"

#include "MainSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUpceDlg dialog

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;

CUpceDlg::CUpceDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUpceDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUpceDlg)
	m_bEnable = FALSE;
	m_bXCD = FALSE;
	m_bXmitNum = FALSE;
	m_nConvert = 0;
	//}}AFX_DATA_INIT
}


void CUpceDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUpceDlg)
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_XMITCHECKCH, m_bXCD);
	DDX_Check(pDX, IDC_CHECK_XMITNUM, m_bXmitNum);
	DDX_Radio(pDX, IDC_RADIO_NOTCONVERT, m_nConvert);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUpceDlg, CDialog)
	//{{AFX_MSG_MAP(CUpceDlg)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, OnConfirm)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUpceDlg message handlers

BOOL CUpceDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);
	
	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CUpceDlg::OnConfirm() 
{
	SetOption();

	CMainSheet* dlg = (CMainSheet*)AfxGetMainWnd();
	
	dlg->SetReadOption();
	
	CDialog::OnOK();	
}

void CUpceDlg::GetOption()
{
	if(kReadEx2.UpcE.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;
	
	if(kReadEx2.UpcE.XmitNumber == XMIT_NUMBER)
		m_bXmitNum = TRUE;
	else
		m_bXmitNum = FALSE;
	
	if(kReadEx2.UpcE.XmitCheckDigit == XMIT_CHECK_DIGIT)
		m_bXCD = TRUE;
	else
		m_bXCD = FALSE;
	
	if(kReadEx2.UpcE.Format == AS_UPCA)
	{
		m_nConvert = 1;
	}
	else if(kReadEx2.UpcE.Format == AS_EAN13)
	{
		m_nConvert = 2;
	}
	else
	{
		m_nConvert = 0;
	}
	UpdateData(FALSE);
}

void CUpceDlg::SetOption()
{
	UpdateData(TRUE);
	
	if(m_bEnable == TRUE)
		kReadEx2.UpcE.Enable = ENABLE;
	else
		kReadEx2.UpcE.Enable = DISABLE;
	
	if(m_bXmitNum == TRUE)
		kReadEx2.UpcE.XmitNumber = XMIT_NUMBER;
	else
		kReadEx2.UpcE.XmitNumber = NO_XMIT_NUMBER;
	
	if(m_bXCD == TRUE)
		kReadEx2.UpcE.XmitCheckDigit = XMIT_CHECK_DIGIT;
	else
		kReadEx2.UpcE.XmitCheckDigit = NO_XMIT_CHECK_DIGIT;
	
	if(m_nConvert == 1)
		kReadEx2.UpcE.Format = AS_UPCA;
	else if(m_nConvert == 2)
		kReadEx2.UpcE.Format = AS_EAN13;
	else
		kReadEx2.UpcE.Format = AS_UPCE;

}
