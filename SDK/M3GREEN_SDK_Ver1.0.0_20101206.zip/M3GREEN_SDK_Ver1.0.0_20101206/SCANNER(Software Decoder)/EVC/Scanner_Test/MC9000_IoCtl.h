#ifndef _MC9000_IOCTL_H_
#define _MC9000_IOCTL_H_

//IoCtl_cfg.h
#define CPLD_FUNC						4010

#define IOCTL_CPLD_WRITE        	CTL_CODE(FILE_DEVICE_HAL, CPLD_FUNC, 	 METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_CPLD_READ          	CTL_CODE(FILE_DEVICE_HAL, CPLD_FUNC + 1, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_CPLD_WORDREAD   	CTL_CODE(FILE_DEVICE_HAL, CPLD_FUNC + 2, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_CPLD_WORDWRITE	CTL_CODE(FILE_DEVICE_HAL, CPLD_FUNC + 3, METHOD_BUFFERED, FILE_ANY_ACCESS)
// CPLD ID
// Printer Interface. Now Not Use
#define CPLD_ID_PRT_PH1				0x0
#define CPLD_ID_PRT_PH2				0x1
#define CPLD_ID_PRT_PH3				0x2
#define CPLD_ID_PRT_PH4				0x3
#define CPLD_ID_PRT_DCLK				0x4
#define CPLD_ID_PRT_DIN					0x5

#define CPLD_ID_PRT_N_LATCH			0x6
#define CPLD_ID_PRT_ON					0x7
#define CPLD_ID_PRT_MTR_ON				0x8
#define CPLD_ID_KEYLIGHT_ON			0x9
#define CPLD_ID_WLAN_ON				0xA
#define CPLD_ID_MSR_ON					0xB

//Printer Interface. Now Not Use
#define CPLD_ID_PRT_STB1				0xC
#define CPLD_ID_PRT_STB2				0xD
#define CPLD_ID_PRT_STB3				0xE
#define CPLD_ID_PRT_STB4				0xF
#define CPLD_ID_PRT_STB5				0x10
#define CPLD_ID_PRT_STB6				0x11

#ifdef MC9000_ES_3TH_BUILD
#define CPLD_ID_AUDIO_ON				0x12
#define CPLD_ID_CDMA_ON				0x13
#define CPLD_ID_RFID_ON				0x14		//RFID PWR �߰�
#define CPLD_ID_XUART_ON				0x15
#define CPLD_ID_XUART_RST				0x16
#define CPLD_ID_SCAN_ON				0x17

#define CPLD_ID_BT_ON					0x18
#define CPLD_ID_BATT_REMOVED_EN		0x19
#define CPLD_ID_WLAN_RESET			0x1A		//MMC WLAN
#define CPLD_ID_EX232C_ON				0x1B
#define CPLD_ID_SD_ON					0x1C
#define CPLD_ID_BT_RST					0x1D

#define CPLD_ID_ICCARD_RST				0x1E
#define CPLD_ID_ICCARD_ON				0x1F
#define CPLD_ID_CAM_RST				0x20
#define CPLD_ID_CAM_FLASH_ON			0x21
#define CPLD_ID_CAM_ON					0x22
#define CPLD_ID_CAM_AIM_ON			0x23

#define CPLD_ID_CIF_ILL_ON				0x24
#define CPLD_ID_EX232C_EN				0x25
#define CPLD_ID_XUART2_RST				0x26
#define CPLD_ID_FEED_SW				0x27
#define CPLD_ID_CDMA_LED				0x28
//#define CPLD_ID_AUDIO_ON				0x29

// 2A 2B 2C �� �ϳ��� �����ؾ� ��
#define CPLD_ID_EXT_UART				0x2A	
#define CPLD_ID_PRINT_DEBUG			0x2B
#define CPLD_ID_CDMA_DM				0x2C
#define CPLD_ID_WAKEUP_CLEAR			0x2D
#define CPLD_ID_SCAN_LED_ON			0x2E
#define CPLD_ID_SCAN_PWR_EN			0x2F

// MSR
#define CPLD_ID_MSR_RDDA				0x30
#define CPLD_ID_MSR_RCPA				0x31
#define CPLD_ID_MSR_RDDB				0x32
#define CPLD_ID_MSR_RCPB				0x33
#define CPLD_ID_MSR_RDDC				0x34
#define CPLD_ID_MSR_RCPC				0x35

#define CPLD_ID_MSR_RDD_JIS			0x36
#define CPLD_ID_MSR_RCP_JIS			0x37
//
#define CPLD_ID_EAR_DET				0x39
#define CPLD_ID_SD_DET					0x3A
#define CPLD_ID_CALL_KEY				0x3B

#else

#define CPLD_ID_AUDIO_AMP_EN			0x12
#define CPLD_ID_CDMA_ON				0x13
#define CPLD_ID_BT_RST					0x14		//CDMA_RESET -> BT RESET. CDMA_RESET ��� ���ϹǷ�.
#define CPLD_ID_XUART_ON				0x15
#define CPLD_ID_XUART_RST				0x16
#define CPLD_ID_SCAN_ON				0x17

#define CPLD_ID_BT_ON					0x18
#define CPLD_ID_USB_TRANS_ON			0x19
#define CPLD_ID_USIM_ON				0x1A		//China CDMA USIM Power On
#define CPLD_ID_EX232C_ON				0x1B
#define CPLD_ID_SD_ON					0x1C
#define CPLD_ID_SD_WP					0x1D

#define CPLD_ID_ICCARD_RST				0x1E
#define CPLD_ID_ICCARD_ON				0x1F
#define CPLD_ID_CAM_RST				0x20
#define CPLD_ID_CAM_FLASH_ON			0x21
#define CPLD_ID_CAM_ON					0x22
#define CPLD_ID_CAM_AIM_ON			0x23

#define CPLD_ID_CIF_ILL_ON				0x24
#define CPLD_ID_EX232C_EN				0x25
#define CPLD_ID_XUART2_RST				0x26
#define CPLD_ID_FEED_SW				0x27
#define CPLD_ID_CDMA_LED				0x28
#define CPLD_ID_AUDIO_ON				0x29

// 2A 2B 2C �� �ϳ��� �����ؾ� ��
#define CPLD_ID_EXT_UART				0x2A	
#define CPLD_ID_PRINT_DEBUG			0x2B
#define CPLD_ID_CDMA_DM				0x2C
//#define CPLD_ID_SPK_ON					0x2D
#define CPLD_ID_SCAN_LED_ON			0x2E
#define CPLD_ID_SCAN_PWR_EN			0x2F

#define CPLD_ID_CDMA_WAKEUP			0x30	// R/W ���� Addr Differ
#define CPLD_ID_nEAR_DET				0x31	//	''
#define CPLD_ID_nSD_DET				0x32	//	''
#define CPLD_ID_nCALL_KEY				0x33	//	''
#define CPLD_ID_EAR_OR_HP				0x34	//HIGH:Modem LOW:9713 HP
#define CPLD_ID_nPRT_RESET				0x35

// MSR
#define CPLD_ID_MSR_RDDA				0x36
#define CPLD_ID_MSR_RCPA				0x37
#define CPLD_ID_MSR_RDDB				0x38
#define CPLD_ID_MSR_RCPB				0x39
#define CPLD_ID_MSR_RDDC				0x3A
#define CPLD_ID_MSR_RCPC				0x3B

#define CPLD_ID_MSR_RDD_JIS			0x3C
#define CPLD_ID_MSR_RCP_JIS			0x3D
#endif

#define CPLD_ID_CTRL_ALL				0xFE

#define CPLD_ID_MIN						CPLD_ID_PRT_PH1

#ifdef MC9000_ES_3TH_BUILD
#define CPLD_ID_MAX						CPLD_ID_CALL_KEY
#else
#define CPLD_ID_MAX						CPLD_ID_MSR_RCP_JIS
#endif

#define CPLD_ERR_READ_NONE			0xFFFF

#endif // #ifndef _MC9000_IOCTL_H_
