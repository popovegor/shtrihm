// UccEanDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "UccEanDlg.h"
#include "MainSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUccEanDlg dialog

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;

CUccEanDlg::CUccEanDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUccEanDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUccEanDlg)
	m_bUpcaAsEan13 = FALSE;
	m_bEnable = FALSE;
	m_bXCD = FALSE;
	m_bXmitNum = FALSE;
	m_bSupp = FALSE;
	//}}AFX_DATA_INIT
}


void CUccEanDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUccEanDlg)
	DDX_Check(pDX, IDC_CHECK_CONVERT, m_bUpcaAsEan13);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_XMITCHECKCH, m_bXCD);
	DDX_Check(pDX, IDC_CHECK_XMITNUM, m_bXmitNum);
	DDX_Check(pDX, IDC_CHECK_SUPP, m_bSupp);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUccEanDlg, CDialog)
	//{{AFX_MSG_MAP(CUccEanDlg)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, OnConfirm)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUccEanDlg message handlers

BOOL CUccEanDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);

	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CUccEanDlg::OnConfirm() 
{
	SetOption();

	CMainSheet* dlg = (CMainSheet*)AfxGetMainWnd();
	
	dlg->SetReadOption();

	CDialog::OnOK();	
}

void CUccEanDlg::GetOption()
{
	if(kReadEx2.UpcA.Enable == DISABLE )
		m_bEnable = FALSE;
	else
		m_bEnable = TRUE;

	if(kReadEx2.UpcA.XmitNumber == XMIT_NUMBER)
		m_bXmitNum = TRUE;
	else
		m_bXmitNum = FALSE;
	
	if(kReadEx2.UpcA.XmitCheckDigit == XMIT_CHECK_DIGIT)
		m_bXCD = TRUE;
	else
		m_bXCD = FALSE;

	if(kReadEx2.UpcA.Format == AS_EAN13)
		m_bUpcaAsEan13 = TRUE;
	else
		m_bUpcaAsEan13 = FALSE;

	if(kReadEx2.UpcA.Supp == WITH_OR_WITHOUT)
		m_bSupp = TRUE;
	else
		m_bSupp = FALSE;

	UpdateData(FALSE);
}

void CUccEanDlg::SetOption()
{
	UpdateData(TRUE);

	if(m_bEnable == TRUE)
		kReadEx2.UpcA.Enable = ENABLE;
	else
		kReadEx2.UpcA.Enable = DISABLE;

	if(m_bXmitNum == TRUE)
		kReadEx2.UpcA.XmitNumber = XMIT_NUMBER;
	else
		kReadEx2.UpcA.XmitNumber = NO_XMIT_NUMBER;

	if(m_bXCD == TRUE)
		kReadEx2.UpcA.XmitCheckDigit = XMIT_CHECK_DIGIT;
	else
		kReadEx2.UpcA.XmitCheckDigit = NO_XMIT_CHECK_DIGIT;

	if(m_bUpcaAsEan13 == TRUE)
		kReadEx2.UpcA.Format = AS_EAN13;
	else
		kReadEx2.UpcA.Format = AS_UPCA;

	if(m_bSupp == TRUE)
		kReadEx2.UpcA.Supp = WITH_OR_WITHOUT;
	else
		kReadEx2.UpcA.Supp = NO_Supp;

}


