#if !defined(AFX_CODE11DLG_H__82266961_FD4C_4357_9730_6E2B35FDC729__INCLUDED_)
#define AFX_CODE11DLG_H__82266961_FD4C_4357_9730_6E2B35FDC729__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Code11Dlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCode11Dlg dialog

class CCode11Dlg : public CDialog
{
// Construction
public:
	void SetOption();
	void GetOption();
	CCode11Dlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCode11Dlg)
	enum { IDD = IDD_CODE11_DLG };
	BOOL	m_bEnable;
	BOOL	m_bXCD;
	int		m_nMaxLen;
	int		m_nMinLen;
	int		m_nCDV;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCode11Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCode11Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CODE11DLG_H__82266961_FD4C_4357_9730_6E2B35FDC729__INCLUDED_)
