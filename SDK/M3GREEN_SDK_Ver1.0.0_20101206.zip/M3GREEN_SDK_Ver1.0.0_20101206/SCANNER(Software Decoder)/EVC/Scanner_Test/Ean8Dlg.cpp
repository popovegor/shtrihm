// Ean8Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "Ean8Dlg.h"
#include "MainSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;

/////////////////////////////////////////////////////////////////////////////
// CEan8Dlg dialog


CEan8Dlg::CEan8Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEan8Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEan8Dlg)
	m_bEnable = FALSE;
	m_bEan8AsEan13 = FALSE;
	m_bXCD = FALSE;
	//}}AFX_DATA_INIT
}


void CEan8Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEan8Dlg)
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_CONVERT, m_bEan8AsEan13);
	DDX_Check(pDX, IDC_CHECK_XMITCHECKCH, m_bXCD);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEan8Dlg, CDialog)
	//{{AFX_MSG_MAP(CEan8Dlg)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, OnConfirm)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEan8Dlg message handlers

BOOL CEan8Dlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);
	
	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CEan8Dlg::OnConfirm() 
{
	SetOption();

	CMainSheet* dlg = (CMainSheet*)AfxGetMainWnd();
	
	dlg->SetReadOption();
	
	CDialog::OnOK();
	
}

void CEan8Dlg::GetOption()
{
	if(kReadEx2.Ean8.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;
	
	if(kReadEx2.Ean8.XmitCheckDigit == XMIT_CHECK_DIGIT)
		m_bXCD = TRUE;
	else
		m_bXCD = FALSE;
	
	if(kReadEx2.Ean8.Format == AS_EAN13)
		m_bEan8AsEan13 = TRUE;
	else
		m_bEan8AsEan13 = FALSE;
	
	UpdateData(FALSE);
}

void CEan8Dlg::SetOption()
{
	UpdateData(TRUE);
	
	if(m_bEnable == TRUE)
		kReadEx2.Ean8.Enable = ENABLE;
	else
		kReadEx2.Ean8.Enable = DISABLE;
	
	if(m_bXCD == TRUE)
		kReadEx2.Ean8.XmitCheckDigit = XMIT_CHECK_DIGIT;
	else
		kReadEx2.Ean8.XmitCheckDigit = NO_XMIT_CHECK_DIGIT;
	
	if(m_bEan8AsEan13 == TRUE)
		kReadEx2.Ean8.Format = AS_EAN13;
	else
		kReadEx2.Ean8.Format = AS_EAN8;
}


