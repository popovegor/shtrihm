// Ean13Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "Ean13Dlg.h"
#include "MainSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEan13Dlg dialog


extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;

CEan13Dlg::CEan13Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEan13Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEan13Dlg)
	m_bEnable = FALSE;
	m_bXCD = FALSE;
	m_bEnableBookland = FALSE;
	m_bSupp = FALSE;
	//}}AFX_DATA_INIT
}


void CEan13Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEan13Dlg)
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_XMITCHECKCH, m_bXCD);
	DDX_Check(pDX, IDC_CHECK_BOOKLAND, m_bEnableBookland);
	DDX_Check(pDX, IDC_CHECK_SUPP, m_bSupp);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEan13Dlg, CDialog)
	//{{AFX_MSG_MAP(CEan13Dlg)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, OnConfirm)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEan13Dlg message handlers

BOOL CEan13Dlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);
	
	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CEan13Dlg::OnConfirm() 
{
	SetOption();

	CMainSheet* dlg = (CMainSheet*)AfxGetMainWnd();
	
	dlg->SetReadOption();
	
	CDialog::OnOK();
	
}

void CEan13Dlg::GetOption()
{
	if(kReadEx2.Ean13.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;

	if((kReadEx2.Ean13.Format == AS_BOOKLAND) && (kReadEx2.Ean13.Enable == ENABLE))
		m_bEnableBookland = TRUE;
	else
		m_bEnableBookland = FALSE;

	if(kReadEx2.Ean13.XmitCheckDigit == XMIT_CHECK_DIGIT)
		m_bXCD = TRUE;
	else
		m_bXCD = FALSE;

	if(kReadEx2.Ean13.Supp == WITH_OR_WITHOUT)
		m_bSupp = TRUE;
	else
		m_bSupp = FALSE;

	UpdateData(FALSE);
}

void CEan13Dlg::SetOption()
{
	UpdateData(TRUE);
	
	if(m_bEnable == TRUE)
		kReadEx2.Ean13.Enable = ENABLE;
	else
		kReadEx2.Ean13.Enable = DISABLE;

	if(m_bEnableBookland == TRUE)
	{
		kReadEx2.Ean13.Enable = ENABLE;
		kReadEx2.Ean13.Format = AS_BOOKLAND;
	}
	else
		kReadEx2.Ean13.Format = AS_EAN13;
	
	if(m_bXCD == TRUE)
		kReadEx2.Ean13.XmitCheckDigit = XMIT_CHECK_DIGIT;
	else
		kReadEx2.Ean13.XmitCheckDigit = NO_XMIT_CHECK_DIGIT;

	if(m_bSupp == TRUE)
		kReadEx2.Ean13.Supp = WITH_OR_WITHOUT;
	else
		kReadEx2.Ean13.Supp = NO_Supp;

}
