// PlesseyDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "PlesseyDlg.h"
#include "MainSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPlesseyDlg dialog

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;

CPlesseyDlg::CPlesseyDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPlesseyDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPlesseyDlg)
	m_bCDV = FALSE;
	m_bEnable = FALSE;
	m_bXCD = FALSE;
	m_nMaxLen = 0;
	m_nMinLen = 0;
	//}}AFX_DATA_INIT
}


void CPlesseyDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPlesseyDlg)
	DDX_Check(pDX, IDC_CHECK_CDV, m_bCDV);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_XMITCD, m_bXCD);
	DDX_Text(pDX, IDC_EDIT_MAXLEN, m_nMaxLen);
	DDX_Text(pDX, IDC_EDIT_MINLEN, m_nMinLen);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPlesseyDlg, CDialog)
	//{{AFX_MSG_MAP(CPlesseyDlg)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, OnConfirm)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPlesseyDlg message handlers

BOOL CPlesseyDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);
	
	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CPlesseyDlg::OnConfirm() 
{
	SetOption();

	CMainSheet* dlg = (CMainSheet*)AfxGetMainWnd();
	
	dlg->SetReadOption();
	
	CDialog::OnOK();	
}

void CPlesseyDlg::GetOption()
{
	if(kReadEx2.Plessey.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;
	
	if(kReadEx2.Plessey.CDV == ENABLE)
		m_bCDV = TRUE;
	else
		m_bCDV = FALSE;
	
	if(kReadEx2.Plessey.XmitCheckDigit == XMIT_CHECK_DIGIT)
		m_bXCD = TRUE;
	else
		m_bXCD = FALSE;
	
	m_nMaxLen = kReadEx2.Plessey.MaxLength;
	m_nMinLen = kReadEx2.Plessey.MinLength;
	
	UpdateData(FALSE);
}

void CPlesseyDlg::SetOption()
{
	UpdateData(TRUE);
	
	if(m_bEnable == TRUE)
		kReadEx2.Plessey.Enable = ENABLE;
	else
		kReadEx2.Plessey.Enable = DISABLE;
	
	if(m_bCDV == TRUE)
		kReadEx2.Plessey.CDV = ENABLE;
	else
		kReadEx2.Plessey.CDV = DISABLE;
	
	if(m_bXCD == TRUE)
		kReadEx2.Plessey.XmitCheckDigit = XMIT_CHECK_DIGIT;
	else
		kReadEx2.Plessey.XmitCheckDigit = NO_XMIT_CHECK_DIGIT;
	
	kReadEx2.Plessey.MaxLength = m_nMaxLen;
	kReadEx2.Plessey.MinLength = m_nMinLen;
}


