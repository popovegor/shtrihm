#if !defined(AFX_EAN13DLG_H__47FF36E1_3DE6_4B1E_9AFF_D434FC9717ED__INCLUDED_)
#define AFX_EAN13DLG_H__47FF36E1_3DE6_4B1E_9AFF_D434FC9717ED__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Ean13Dlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEan13Dlg dialog

class CEan13Dlg : public CDialog
{
// Construction
public:
	void SetOption();
	void GetOption();
	CEan13Dlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CEan13Dlg)
	enum { IDD = IDD_EAN13_DLG };
	BOOL	m_bEnable;
	BOOL	m_bXCD;
	BOOL	m_bEnableBookland;
	BOOL	m_bSupp;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEan13Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEan13Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EAN13DLG_H__47FF36E1_3DE6_4B1E_9AFF_D434FC9717ED__INCLUDED_)
