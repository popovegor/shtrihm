// CodabarDlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "CodabarDlg.h"
#include "MainSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCodabarDlg dialog

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;


CCodabarDlg::CCodabarDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCodabarDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCodabarDlg)
	m_bEnable = FALSE;
	m_bXSS = FALSE;
	m_nMaxLen = 0;
	m_nMinLen = 0;
	//}}AFX_DATA_INIT
}


void CCodabarDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCodabarDlg)
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_XMITSS, m_bXSS);
	DDX_Text(pDX, IDC_EDIT_MAXLEN, m_nMaxLen);
	DDX_Text(pDX, IDC_EDIT_MINLEN, m_nMinLen);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCodabarDlg, CDialog)
	//{{AFX_MSG_MAP(CCodabarDlg)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, OnConfirm)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCodabarDlg message handlers

BOOL CCodabarDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);
	
	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CCodabarDlg::OnConfirm() 
{
	SetOption();

	CMainSheet* dlg = (CMainSheet*)AfxGetMainWnd();
	
	dlg->SetReadOption();
	
	CDialog::OnOK();	
}

void CCodabarDlg::GetOption()
{
	if(kReadEx2.Codabar.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;
	
	if(kReadEx2.Codabar.XmitStartStop == XMIT)
		m_bXSS = TRUE;
	else
		m_bXSS = FALSE;
	
	m_nMaxLen = kReadEx2.Codabar.MaxLength;
	m_nMinLen = kReadEx2.Codabar.MinLength;
	
	UpdateData(FALSE);
}

void CCodabarDlg::SetOption()
{
	UpdateData(TRUE);
	
	if(m_bEnable == TRUE)
		kReadEx2.Codabar.Enable = ENABLE;
	else
		kReadEx2.Codabar.Enable = DISABLE;
	
	if(m_bXSS == TRUE)
		kReadEx2.Codabar.XmitStartStop = XMIT;
	else
		kReadEx2.Codabar.XmitStartStop = NO_XMIT;	
	
	kReadEx2.Codabar.MaxLength = m_nMaxLen;
	kReadEx2.Codabar.MinLength = m_nMinLen;

}


