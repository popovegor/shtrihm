// ScanPage.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "ScanPage.h"

#include "KScanBar.h"
#include "MainSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CScanPage property page

IMPLEMENT_DYNCREATE(CScanPage, CPropertyPage)

CScanPage::CScanPage() : CPropertyPage(CScanPage::IDD)
{
	//{{AFX_DATA_INIT(CScanPage)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CScanPage::~CScanPage()
{
}

void CScanPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CScanPage)
	DDX_Control(pDX, IDC_LIST_SCANDATA, m_ctrlListctrlScanData);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CScanPage, CPropertyPage)
	//{{AFX_MSG_MAP(CScanPage)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BTN_SCAN, OnScan)
	ON_BN_CLICKED(IDC_BTN_INFO, OnInfo)
	ON_BN_CLICKED(IDC_BTN_SCANCANCEL, OnBtnScancancel)
	ON_BN_CLICKED(IDC_BTN_CLEAR, OnClear)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScanPage message handlers

BOOL CScanPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	CM3ScanTestApp* app = (CM3ScanTestApp*)AfxGetApp();
	CMainSheet* dlg		= (CMainSheet*)AfxGetMainWnd();	

	app->InitialDlg->ShowWindow(SW_SHOW);
	dlg->M3_ScanInit(6);
	app->InitialDlg->ShowWindow(SW_HIDE);
	
	ListView_SetExtendedListViewStyle(m_ctrlListctrlScanData.GetSafeHwnd(),LVS_EX_FULLROWSELECT);
	m_ctrlListctrlScanData.InsertColumn(0,L"BarCode Type",LVCFMT_LEFT,90);
	m_ctrlListctrlScanData.InsertColumn(1,L"BarCode Number",LVCFMT_LEFT,140);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CScanPage::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	
	CPropertyPage::OnClose();
}

void CScanPage::OnScan() 
{
	CMainSheet* dlg = (CMainSheet*)AfxGetMainWnd();
	dlg->M3_ScanRead();
}

void CScanPage::OnBtnScancancel() 
{
	CMainSheet* dlg = (CMainSheet*)AfxGetMainWnd();
	dlg->m_KScan.ReadCancel();
	
}

void CScanPage::OnClear() 
{
	m_ctrlListctrlScanData.DeleteAllItems();
}

void CScanPage::OnInfo() 
{
	CString szTmp = KScanGetVersionInfo();
	AfxMessageBox(szTmp);	
}

void CScanPage::Write_ScanData(CString& BarType, CString& BarValue)
{
	m_ctrlListctrlScanData.InsertItem(0, BarType,0);
	m_ctrlListctrlScanData.SetItemText(0, 1, BarValue);
}



