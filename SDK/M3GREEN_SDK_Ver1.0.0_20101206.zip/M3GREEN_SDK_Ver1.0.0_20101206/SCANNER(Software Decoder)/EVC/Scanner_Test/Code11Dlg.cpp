// Code11Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "Code11Dlg.h"
#include "MainSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCode11Dlg dialog

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;

CCode11Dlg::CCode11Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCode11Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCode11Dlg)
	m_bEnable = FALSE;
	m_bXCD = FALSE;
	m_nMaxLen = 0;
	m_nMinLen = 0;
	m_nCDV = 0;
	//}}AFX_DATA_INIT
}


void CCode11Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCode11Dlg)
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_XMITCD, m_bXCD);
	DDX_Text(pDX, IDC_EDIT_MAXLEN, m_nMaxLen);
	DDX_Text(pDX, IDC_EDIT_MINLEN, m_nMinLen);
	DDX_Radio(pDX, IDC_RADIO_NOCDV, m_nCDV);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCode11Dlg, CDialog)
	//{{AFX_MSG_MAP(CCode11Dlg)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, OnConfirm)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCode11Dlg message handlers

BOOL CCode11Dlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);
	
	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CCode11Dlg::OnConfirm() 
{
	SetOption();

	CMainSheet* dlg = (CMainSheet*)AfxGetMainWnd();
	
	dlg->SetReadOption();
	
	CDialog::OnOK();	
}

void CCode11Dlg::GetOption()
{
	if(kReadEx2.Code11.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;

	m_nCDV = (int)kReadEx2.Code11.CheckDigit;
		
	if(kReadEx2.Code11.XmitCheckDigit == XMIT_CHECK_DIGIT)
		m_bXCD = TRUE;
	else
		m_bXCD = FALSE;
	
	m_nMaxLen = kReadEx2.Code11.MaxLength;
	m_nMinLen = kReadEx2.Code11.MinLength;
	
	UpdateData(FALSE);
}

void CCode11Dlg::SetOption()
{
	UpdateData(TRUE);
	
	if(m_bEnable == TRUE)
		kReadEx2.Code11.Enable = ENABLE;
	else
		kReadEx2.Code11.Enable = DISABLE;

	kReadEx2.Code11.CheckDigit = (CHECK_DIGIT)m_nCDV;
			
	if(m_bXCD == TRUE)
		kReadEx2.Code11.XmitCheckDigit = XMIT_CHECK_DIGIT;
	else
		kReadEx2.Code11.XmitCheckDigit = NO_XMIT_CHECK_DIGIT;
		
	kReadEx2.Code11.MaxLength = m_nMaxLen;
	kReadEx2.Code11.MinLength = m_nMinLen;
}


