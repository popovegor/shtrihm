// M3ScanTest.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "M3ScanTestDlg.h"
#include "MainSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CM3ScanTestApp

BEGIN_MESSAGE_MAP(CM3ScanTestApp, CWinApp)
	//{{AFX_MSG_MAP(CM3ScanTestApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CM3ScanTestApp construction

CM3ScanTestApp::CM3ScanTestApp()
	: CWinApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CM3ScanTestApp object

CM3ScanTestApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CM3ScanTestApp initialization

HANDLE g_hMutex = NULL;

BOOL CM3ScanTestApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

	//M3ScanTest��� �̸��� �����찡 �����ϴ����� Ȯ���� �Ŀ� ����Ǿ������� ShowWindow���� ������ �����մϴ�.
	g_hMutex = ::CreateMutex(NULL, TRUE, _T("MC_SCANNER"));
	if(GetLastError() == ERROR_ALREADY_EXISTS)
	{
		HWND hWnd =NULL;
		hWnd = FindWindow(NULL,_T("M3 Scanner Test"));
		if(hWnd == NULL)
		{
			MessageBox(NULL,_T("SCANNER Engine is already running!"),_T("ERROR"),MB_OK|MB_ICONWARNING);
			return FALSE;			
		}
		ShowWindow(hWnd,SW_SHOW);
		SetForegroundWindow(hWnd);
		
		return FALSE;
	}	
	
	CWnd	*pWnd;
	if(pWnd = CWnd::FindWindow(NULL,_T("M3 Scanner Test")))
	{
		pWnd->ShowWindow(SW_SHOW);
		pWnd->SetForegroundWindow();
		return	FALSE;
	}
	
	InitialDlg = new CMessageDlg;
	InitialDlg->Create(IDD_MESSAGE_DLG);
	
	//	CM3ScanTestDlg dlg;
	CMainSheet dlg(L"M3 Scanner Test");
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
