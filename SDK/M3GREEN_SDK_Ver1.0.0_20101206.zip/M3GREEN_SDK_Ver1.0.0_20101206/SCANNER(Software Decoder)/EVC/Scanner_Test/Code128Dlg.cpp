// Code128Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "M3ScanTest.h"
#include "Code128Dlg.h"
#include "MainSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern KSCANREAD    kRead;
extern KSCANREADEX  kReadEx;
extern KSCANREADEX2 kReadEx2;

BYTE temp[] = "";

/////////////////////////////////////////////////////////////////////////////
// CCode128Dlg dialog


CCode128Dlg::CCode128Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCode128Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCode128Dlg)
	m_bEnable = FALSE;
	m_bEnableUccEan128 = FALSE;
	m_nMaxLen = 0;
	m_nMinLen = 0;
	m_strFNC_ASCII = _T("");
	//}}AFX_DATA_INIT
}


void CCode128Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCode128Dlg)
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_UCCEAN128, m_bEnableUccEan128);
	DDX_Text(pDX, IDC_EDIT_MAXLEN, m_nMaxLen);
	DDX_Text(pDX, IDC_EDIT_MINLEN, m_nMinLen);
	DDX_Text(pDX, IDC_EDIT_FNCASCII, m_strFNC_ASCII);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCode128Dlg, CDialog)
	//{{AFX_MSG_MAP(CCode128Dlg)
	ON_BN_CLICKED(IDC_BTN_CONFIRM, OnConfirm)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCode128Dlg message handlers

BOOL CCode128Dlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	MoveWindow(0, -1, 240, 310);
	
	GetOption();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CCode128Dlg::OnConfirm() 
{
	SetOption();

	CMainSheet* dlg = (CMainSheet*)AfxGetMainWnd();
	
	dlg->SetReadOption();
	
	CDialog::OnOK();	
}

void CCode128Dlg::GetOption()
{
	if(kReadEx2.Code128.Enable == ENABLE)
		m_bEnable = TRUE;
	else
		m_bEnable = FALSE;
	
	if((kReadEx2.Code128.AsUCCEAN128 == ENABLE) && (kReadEx2.Code128.Enable == ENABLE))
		m_bEnableUccEan128 = TRUE;
	else
		m_bEnableUccEan128 = FALSE;	

	
	m_nMaxLen	= kReadEx2.Code128.MaxLength;
	m_nMinLen	= kReadEx2.Code128.MinLength;

	mbstowcs(m_strFNC_ASCII.GetBuffer(0), (char*)kReadEx2.Code128.FNC1_ASCII, 1024);	
			
	UpdateData(FALSE);
}

void CCode128Dlg::SetOption()
{
	UpdateData(TRUE);
	
	if(m_bEnable == TRUE)
		kReadEx2.Code128.Enable = ENABLE;
	else
		kReadEx2.Code128.Enable = DISABLE;
	
	if(m_bEnableUccEan128 == TRUE)
	{
		kReadEx2.Code128.Enable			= ENABLE;
		kReadEx2.Code128.AsUCCEAN128	= ENABLE;
	}
	else
		kReadEx2.Code128.AsUCCEAN128 = DISABLE;	
	
	kReadEx2.Code128.MaxLength = m_nMaxLen;
	kReadEx2.Code128.MinLength = m_nMinLen;

	wcstombs((char*)temp, m_strFNC_ASCII.GetBuffer(0), 1024);
	kReadEx2.Code128.FNC1_ASCII = temp;



}

