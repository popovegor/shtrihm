#if !defined(AFX_MSIDLG_H__3A0A7E78_2640_47B1_B290_0C53053C6423__INCLUDED_)
#define AFX_MSIDLG_H__3A0A7E78_2640_47B1_B290_0C53053C6423__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MsiDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMsiDlg dialog

class CMsiDlg : public CDialog
{
// Construction
public:
	void SetOption();
	void GetOption();
	CMsiDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMsiDlg)
	enum { IDD = IDD_MSI_DLG };
	BOOL	m_bCDV;
	BOOL	m_bEnable;
	BOOL	m_bXCD;
	int		m_nMaxLen;
	int		m_nMinLen;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMsiDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMsiDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MSIDLG_H__3A0A7E78_2640_47B1_B290_0C53053C6423__INCLUDED_)
