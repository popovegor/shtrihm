﻿namespace LRScanTestNet
{
    partial class FCODABAR
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.BTN_CANCEL = new System.Windows.Forms.Button();
            this.BTN_OK = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.CB_XCD = new System.Windows.Forms.CheckBox();
            this.CB_CDV = new System.Windows.Forms.CheckBox();
            this.CB_XMITSS = new System.Windows.Forms.CheckBox();
            this.CB_ENABLE = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // BTN_CANCEL
            // 
            this.BTN_CANCEL.Location = new System.Drawing.Point(124, 230);
            this.BTN_CANCEL.Name = "BTN_CANCEL";
            this.BTN_CANCEL.Size = new System.Drawing.Size(107, 33);
            this.BTN_CANCEL.TabIndex = 23;
            this.BTN_CANCEL.Text = "Cancel";
            this.BTN_CANCEL.Click += new System.EventHandler(this.BTN_CANCEL_Click);
            // 
            // BTN_OK
            // 
            this.BTN_OK.Location = new System.Drawing.Point(10, 230);
            this.BTN_OK.Name = "BTN_OK";
            this.BTN_OK.Size = new System.Drawing.Size(107, 33);
            this.BTN_OK.TabIndex = 22;
            this.BTN_OK.Text = "OK";
            this.BTN_OK.Click += new System.EventHandler(this.BTN_OK_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.CB_XCD);
            this.panel2.Controls.Add(this.CB_CDV);
            this.panel2.Controls.Add(this.CB_XMITSS);
            this.panel2.Controls.Add(this.CB_ENABLE);
            this.panel2.Location = new System.Drawing.Point(10, 36);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(221, 188);
            // 
            // CB_XCD
            // 
            this.CB_XCD.Location = new System.Drawing.Point(24, 102);
            this.CB_XCD.Name = "CB_XCD";
            this.CB_XCD.Size = new System.Drawing.Size(149, 20);
            this.CB_XCD.TabIndex = 20;
            this.CB_XCD.Text = "Transmit Check Digit";
            // 
            // CB_CDV
            // 
            this.CB_CDV.Location = new System.Drawing.Point(24, 64);
            this.CB_CDV.Name = "CB_CDV";
            this.CB_CDV.Size = new System.Drawing.Size(162, 20);
            this.CB_CDV.TabIndex = 19;
            this.CB_CDV.Text = "Check Digit Verification";
            // 
            // CB_XMITSS
            // 
            this.CB_XMITSS.Location = new System.Drawing.Point(24, 140);
            this.CB_XMITSS.Name = "CB_XMITSS";
            this.CB_XMITSS.Size = new System.Drawing.Size(149, 20);
            this.CB_XMITSS.TabIndex = 1;
            this.CB_XMITSS.Text = "Transmit Start-Stop";
            // 
            // CB_ENABLE
            // 
            this.CB_ENABLE.Location = new System.Drawing.Point(24, 26);
            this.CB_ENABLE.Name = "CB_ENABLE";
            this.CB_ENABLE.Size = new System.Drawing.Size(100, 20);
            this.CB_ENABLE.TabIndex = 0;
            this.CB_ENABLE.Text = "Enable";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(74, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(90, 25);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(14, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 14);
            this.label1.Text = "CODABAR";
            // 
            // FCODABAR
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.BTN_CANCEL);
            this.Controls.Add(this.BTN_OK);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Menu = this.mainMenu1;
            this.MinimizeBox = false;
            this.Name = "FCODABAR";
            this.Text = "CODABAR";
            this.Load += new System.EventHandler(this.FCODABAR_Load);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BTN_CANCEL;
        private System.Windows.Forms.Button BTN_OK;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox CB_XCD;
        private System.Windows.Forms.CheckBox CB_CDV;
        private System.Windows.Forms.CheckBox CB_XMITSS;
        private System.Windows.Forms.CheckBox CB_ENABLE;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
    }
}