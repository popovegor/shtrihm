﻿/********************************************************************
created		:	2011/09/05
file base	: 	LRScanTestNet.exe

file ext	:	cs
author		:	Dong-Hyun Eum & Eun-Taek Lee

purpose		:	Long-Range Scanner C# Demo Program
Report		:	2011. 09. 05 [09/05/2011 vision7901] v1.0.0 - MM3 Long-Range Scanner 2차 Release 버전
*********************************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using LRScannerNet;

namespace LRScanTestNet
{
    public partial class LRScanTestNet : Form
    {
        private LRScanner m_LRScanner;
        public DECODER_PARAMS m_DecoderParams;

        public bool m_bResult = false;
        public bool m_bReading = false;
        public bool m_bSyncMode = false;
        public bool m_bContinueMode = false;

        public string m_strVerInfo;

        public const int m_nHotKeyWM = 125;    // VK_F14(WM)        

        public LRScanTestNet()
        {
            InitializeComponent();

            m_LRScanner = new LRScanner();
            m_LRScanner.LRScannerDataEvent += new LRScannerNet.LRScannerDataDelegate(OnScanRead);

            //Scanner Open
            m_LRScanner.Open();

            m_LRScanner.RegHotKey(1, m_nHotKeyWM, m_bSyncMode);
        }

        private void BN_SCAN_Click(object sender, EventArgs e)
        {
            m_LRScanner.Read();
        }

        private void BN_SCANCANCEL_Click(object  sender, EventArgs e)
        {
            m_LRScanner.ReadCancel();
        }

        public void OnScanRead(object sender, LRScannerDataArgs e)
        {
            if (e.ScanData != "")
            {
                LB_TYPE.Text = e.ScanType;
                TB_DATA.Text = e.ScanData;
            }

            if (m_bContinueMode == false)
                m_bReading = false;
        }

        private void BN_CLOSE_Click(object sender, EventArgs e)
        {
            Close();

            Application.Exit();
        }

        private void BN_SYM_Click(object sender, EventArgs e)
        {
            FSYMBOLOGY Symbology = new FSYMBOLOGY();

            // Disable Scan Key
            m_LRScanner.ReadCancel();
            m_LRScanner.UnRegHotKey(1);

            Symbology.ShowDialog();

            // Enable Scan Key
            m_LRScanner.RegHotKey(1, m_nHotKeyWM, m_bSyncMode);
        }

        private void BN_NEW_Click(object sender, EventArgs e)
        {
            FTEST NewForm = new FTEST();

            m_LRScanner.ReadCancel();

            m_LRScanner.LRScannerDataEvent -= new LRScannerNet.LRScannerDataDelegate(OnScanRead);

            NewForm.ShowDialog();

            m_LRScanner.LRScannerDataEvent += new LRScannerNet.LRScannerDataDelegate(OnScanRead);
        }

        private void BN_SCANOPTION_Click(object sender, EventArgs e)
        {
            FSCANOPTION ScanOption = new FSCANOPTION();

            ScanOption.m_bSyncMode = m_bSyncMode;

            // Disable Scan Key
            m_LRScanner.ReadCancel();
            m_LRScanner.UnRegHotKey(1);

            if (ScanOption.ShowDialog() == DialogResult.OK)
                m_bSyncMode = ScanOption.m_bSyncMode;

            m_LRScanner.RegHotKey(1, m_nHotKeyWM, m_bSyncMode);
        }

        private void BN_INFO_Click(object sender, EventArgs e)
        {
            FABOUT AboutDlg = new FABOUT();

            AboutDlg.m_strVersion = m_LRScanner.GetVersionInfo();

            // Disable Scan Key
            m_LRScanner.ReadCancel();
            m_LRScanner.UnRegHotKey(1);

            AboutDlg.ShowDialog();

            m_LRScanner.RegHotKey(1, m_nHotKeyWM, m_bSyncMode);
        }

        

    }
}