﻿namespace LRScanTestNet
{
    partial class FSYMBOLOGY
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.BTN_CANCEL = new System.Windows.Forms.Button();
            this.OK = new System.Windows.Forms.Button();
            this.BTN_DAFAULT = new System.Windows.Forms.Button();
            this.BTN_PARAM = new System.Windows.Forms.Button();
            this.BTN_ALL = new System.Windows.Forms.Button();
            this.LV_SYMLIST = new System.Windows.Forms.ListView();
            this.LV_ENABLE = new System.Windows.Forms.ColumnHeader();
            this.LV_SYMBOLOGY = new System.Windows.Forms.ColumnHeader();
            this.SuspendLayout();
            // 
            // BTN_CANCEL
            // 
            this.BTN_CANCEL.Location = new System.Drawing.Point(123, 239);
            this.BTN_CANCEL.Name = "BTN_CANCEL";
            this.BTN_CANCEL.Size = new System.Drawing.Size(114, 25);
            this.BTN_CANCEL.TabIndex = 22;
            this.BTN_CANCEL.Text = "Cancel";
            this.BTN_CANCEL.Click += new System.EventHandler(this.BTN_CANCEL_Click);
            // 
            // OK
            // 
            this.OK.Location = new System.Drawing.Point(3, 239);
            this.OK.Name = "OK";
            this.OK.Size = new System.Drawing.Size(114, 25);
            this.OK.TabIndex = 21;
            this.OK.Text = "OK";
            this.OK.Click += new System.EventHandler(this.OK_Click);
            // 
            // BTN_DAFAULT
            // 
            this.BTN_DAFAULT.Location = new System.Drawing.Point(165, 211);
            this.BTN_DAFAULT.Name = "BTN_DAFAULT";
            this.BTN_DAFAULT.Size = new System.Drawing.Size(72, 25);
            this.BTN_DAFAULT.TabIndex = 20;
            this.BTN_DAFAULT.Text = "Default";
            this.BTN_DAFAULT.Click += new System.EventHandler(this.BTN_DAFAULT_Click);
            // 
            // BTN_PARAM
            // 
            this.BTN_PARAM.Location = new System.Drawing.Point(85, 211);
            this.BTN_PARAM.Name = "BTN_PARAM";
            this.BTN_PARAM.Size = new System.Drawing.Size(72, 25);
            this.BTN_PARAM.TabIndex = 19;
            this.BTN_PARAM.Text = "Param";
            this.BTN_PARAM.Click += new System.EventHandler(this.BTN_PARAM_Click);
            // 
            // BTN_ALL
            // 
            this.BTN_ALL.Location = new System.Drawing.Point(3, 211);
            this.BTN_ALL.Name = "BTN_ALL";
            this.BTN_ALL.Size = new System.Drawing.Size(72, 25);
            this.BTN_ALL.TabIndex = 18;
            this.BTN_ALL.Text = "All";
            this.BTN_ALL.Click += new System.EventHandler(this.BTN_ALL_Click);
            // 
            // LV_SYMLIST
            // 
            this.LV_SYMLIST.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.LV_SYMLIST.CheckBoxes = true;
            this.LV_SYMLIST.Columns.Add(this.LV_ENABLE);
            this.LV_SYMLIST.Columns.Add(this.LV_SYMBOLOGY);
            this.LV_SYMLIST.FullRowSelect = true;
            this.LV_SYMLIST.Location = new System.Drawing.Point(3, 3);
            this.LV_SYMLIST.Name = "LV_SYMLIST";
            this.LV_SYMLIST.Size = new System.Drawing.Size(234, 202);
            this.LV_SYMLIST.TabIndex = 14;
            this.LV_SYMLIST.View = System.Windows.Forms.View.Details;
            this.LV_SYMLIST.ItemActivate += new System.EventHandler(this.LV_SYMLIST_ItemActivate);
            // 
            // LV_ENABLE
            // 
            this.LV_ENABLE.Text = "Enable";
            this.LV_ENABLE.Width = 60;
            // 
            // LV_SYMBOLOGY
            // 
            this.LV_SYMBOLOGY.Text = "Symbology";
            this.LV_SYMBOLOGY.Width = 150;
            // 
            // FSYMBOLOGY
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.BTN_CANCEL);
            this.Controls.Add(this.OK);
            this.Controls.Add(this.BTN_DAFAULT);
            this.Controls.Add(this.BTN_PARAM);
            this.Controls.Add(this.BTN_ALL);
            this.Controls.Add(this.LV_SYMLIST);
            this.Menu = this.mainMenu1;
            this.MinimizeBox = false;
            this.Name = "FSYMBOLOGY";
            this.Text = "SYMBOLOGY";
            this.Load += new System.EventHandler(this.FSYMBOLOGY_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BTN_CANCEL;
        private System.Windows.Forms.Button OK;
        private System.Windows.Forms.Button BTN_DAFAULT;
        private System.Windows.Forms.Button BTN_PARAM;
        private System.Windows.Forms.Button BTN_ALL;
        private System.Windows.Forms.ListView LV_SYMLIST;
        private System.Windows.Forms.ColumnHeader LV_ENABLE;
        private System.Windows.Forms.ColumnHeader LV_SYMBOLOGY;
    }
}