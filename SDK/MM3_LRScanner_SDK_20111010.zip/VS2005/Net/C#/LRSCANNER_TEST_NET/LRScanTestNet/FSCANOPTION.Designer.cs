﻿namespace LRScanTestNet
{
    partial class FSCANOPTION
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.BTN_CANCEL = new System.Windows.Forms.Button();
            this.BTN_OK = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.RD_NOSOUND = new System.Windows.Forms.RadioButton();
            this.RD_BEEP = new System.Windows.Forms.RadioButton();
            this.RD_SOUNDDEFAULT = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.RD_SYNC = new System.Windows.Forms.RadioButton();
            this.RD_ASYNC = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.CB_TIMEOUT = new System.Windows.Forms.ComboBox();
            this.CB_VIBRATE = new System.Windows.Forms.CheckBox();
            this.CB_AIMID = new System.Windows.Forms.CheckBox();
            this.CB_CONTINUE = new System.Windows.Forms.CheckBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.CB_SECURITY = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.CB_CENTERDECODER = new System.Windows.Forms.CheckBox();
            this.CB_1DDECODER = new System.Windows.Forms.CheckBox();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // BTN_CANCEL
            // 
            this.BTN_CANCEL.Location = new System.Drawing.Point(122, 230);
            this.BTN_CANCEL.Name = "BTN_CANCEL";
            this.BTN_CANCEL.Size = new System.Drawing.Size(115, 35);
            this.BTN_CANCEL.TabIndex = 17;
            this.BTN_CANCEL.Text = "Cancel";
            this.BTN_CANCEL.Click += new System.EventHandler(this.BTN_CANCEL_Click);
            // 
            // BTN_OK
            // 
            this.BTN_OK.Location = new System.Drawing.Point(3, 230);
            this.BTN_OK.Name = "BTN_OK";
            this.BTN_OK.Size = new System.Drawing.Size(115, 35);
            this.BTN_OK.TabIndex = 16;
            this.BTN_OK.Text = "OK";
            this.BTN_OK.Click += new System.EventHandler(this.BTN_OK_Click);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(3, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 14);
            this.label3.Text = "READ OPTION";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Control;
            this.panel3.Controls.Add(this.RD_NOSOUND);
            this.panel3.Controls.Add(this.RD_BEEP);
            this.panel3.Controls.Add(this.RD_SOUNDDEFAULT);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Location = new System.Drawing.Point(3, 56);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(234, 45);
            // 
            // RD_NOSOUND
            // 
            this.RD_NOSOUND.Location = new System.Drawing.Point(143, 22);
            this.RD_NOSOUND.Name = "RD_NOSOUND";
            this.RD_NOSOUND.Size = new System.Drawing.Size(82, 20);
            this.RD_NOSOUND.TabIndex = 2;
            this.RD_NOSOUND.Text = "No Sound";
            // 
            // RD_BEEP
            // 
            this.RD_BEEP.Location = new System.Drawing.Point(80, 22);
            this.RD_BEEP.Name = "RD_BEEP";
            this.RD_BEEP.Size = new System.Drawing.Size(63, 20);
            this.RD_BEEP.TabIndex = 1;
            this.RD_BEEP.Text = "Beep";
            // 
            // RD_SOUNDDEFAULT
            // 
            this.RD_SOUNDDEFAULT.Location = new System.Drawing.Point(3, 22);
            this.RD_SOUNDDEFAULT.Name = "RD_SOUNDDEFAULT";
            this.RD_SOUNDDEFAULT.Size = new System.Drawing.Size(70, 20);
            this.RD_SOUNDDEFAULT.TabIndex = 0;
            this.RD_SOUNDDEFAULT.Text = "Default";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(3, 1);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 14);
            this.label2.Text = "SOUND";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(3, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 18);
            this.label1.Text = "SYNC MODE";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.RD_SYNC);
            this.panel1.Controls.Add(this.RD_ASYNC);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(3, 18);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(234, 25);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.radioButton1);
            this.panel2.Controls.Add(this.radioButton2);
            this.panel2.Location = new System.Drawing.Point(7, 48);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(234, 25);
            // 
            // radioButton1
            // 
            this.radioButton1.Location = new System.Drawing.Point(118, 2);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(100, 20);
            this.radioButton1.TabIndex = 1;
            this.radioButton1.Text = "Sync Mode";
            // 
            // radioButton2
            // 
            this.radioButton2.Location = new System.Drawing.Point(12, 2);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(100, 20);
            this.radioButton2.TabIndex = 0;
            this.radioButton2.Text = "ASync Mode";
            // 
            // RD_SYNC
            // 
            this.RD_SYNC.Location = new System.Drawing.Point(170, 2);
            this.RD_SYNC.Name = "RD_SYNC";
            this.RD_SYNC.Size = new System.Drawing.Size(57, 20);
            this.RD_SYNC.TabIndex = 1;
            this.RD_SYNC.Text = "Sync";
            // 
            // RD_ASYNC
            // 
            this.RD_ASYNC.Location = new System.Drawing.Point(102, 2);
            this.RD_ASYNC.Name = "RD_ASYNC";
            this.RD_ASYNC.Size = new System.Drawing.Size(61, 20);
            this.RD_ASYNC.TabIndex = 0;
            this.RD_ASYNC.Text = "ASync";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(5, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 16);
            this.label4.Text = "Timeout";
            // 
            // CB_TIMEOUT
            // 
            this.CB_TIMEOUT.Items.Add("1");
            this.CB_TIMEOUT.Items.Add("2");
            this.CB_TIMEOUT.Items.Add("3");
            this.CB_TIMEOUT.Items.Add("4");
            this.CB_TIMEOUT.Items.Add("5");
            this.CB_TIMEOUT.Items.Add("6");
            this.CB_TIMEOUT.Items.Add("7");
            this.CB_TIMEOUT.Items.Add("8");
            this.CB_TIMEOUT.Items.Add("9");
            this.CB_TIMEOUT.Items.Add("10");
            this.CB_TIMEOUT.Location = new System.Drawing.Point(60, 23);
            this.CB_TIMEOUT.Name = "CB_TIMEOUT";
            this.CB_TIMEOUT.Size = new System.Drawing.Size(35, 22);
            this.CB_TIMEOUT.TabIndex = 1;
            // 
            // CB_VIBRATE
            // 
            this.CB_VIBRATE.Location = new System.Drawing.Point(3, 68);
            this.CB_VIBRATE.Name = "CB_VIBRATE";
            this.CB_VIBRATE.Size = new System.Drawing.Size(75, 20);
            this.CB_VIBRATE.TabIndex = 4;
            this.CB_VIBRATE.Text = "Vibrate";
            // 
            // CB_AIMID
            // 
            this.CB_AIMID.Location = new System.Drawing.Point(114, 48);
            this.CB_AIMID.Name = "CB_AIMID";
            this.CB_AIMID.Size = new System.Drawing.Size(114, 20);
            this.CB_AIMID.TabIndex = 5;
            this.CB_AIMID.Text = "Transmit AIMID";
            // 
            // CB_CONTINUE
            // 
            this.CB_CONTINUE.Location = new System.Drawing.Point(3, 48);
            this.CB_CONTINUE.Name = "CB_CONTINUE";
            this.CB_CONTINUE.Size = new System.Drawing.Size(111, 20);
            this.CB_CONTINUE.TabIndex = 6;
            this.CB_CONTINUE.Text = "Continue Mode";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.Control;
            this.panel5.Controls.Add(this.CB_SECURITY);
            this.panel5.Controls.Add(this.label5);
            this.panel5.Controls.Add(this.label3);
            this.panel5.Controls.Add(this.CB_CENTERDECODER);
            this.panel5.Controls.Add(this.CB_1DDECODER);
            this.panel5.Controls.Add(this.CB_CONTINUE);
            this.panel5.Controls.Add(this.CB_AIMID);
            this.panel5.Controls.Add(this.CB_VIBRATE);
            this.panel5.Controls.Add(this.CB_TIMEOUT);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Location = new System.Drawing.Point(3, 114);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(234, 112);
            // 
            // CB_SECURITY
            // 
            this.CB_SECURITY.Items.Add("1");
            this.CB_SECURITY.Items.Add("2");
            this.CB_SECURITY.Items.Add("3");
            this.CB_SECURITY.Items.Add("4");
            this.CB_SECURITY.Items.Add("5");
            this.CB_SECURITY.Items.Add("6");
            this.CB_SECURITY.Items.Add("7");
            this.CB_SECURITY.Items.Add("8");
            this.CB_SECURITY.Items.Add("9");
            this.CB_SECURITY.Items.Add("10");
            this.CB_SECURITY.Location = new System.Drawing.Point(191, 22);
            this.CB_SECURITY.Name = "CB_SECURITY";
            this.CB_SECURITY.Size = new System.Drawing.Size(35, 22);
            this.CB_SECURITY.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(105, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 16);
            this.label5.Text = "Security Level";
            // 
            // CB_CENTERDECODER
            // 
            this.CB_CENTERDECODER.Location = new System.Drawing.Point(3, 88);
            this.CB_CENTERDECODER.Name = "CB_CENTERDECODER";
            this.CB_CENTERDECODER.Size = new System.Drawing.Size(154, 20);
            this.CB_CENTERDECODER.TabIndex = 10;
            this.CB_CENTERDECODER.Text = "Center Decode Mode";
            // 
            // CB_1DDECODER
            // 
            this.CB_1DDECODER.Location = new System.Drawing.Point(114, 68);
            this.CB_1DDECODER.Name = "CB_1DDECODER";
            this.CB_1DDECODER.Size = new System.Drawing.Size(117, 20);
            this.CB_1DDECODER.TabIndex = 9;
            this.CB_1DDECODER.Text = "1D Decode Mode";
            // 
            // FSCANOPTION
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.BTN_CANCEL);
            this.Controls.Add(this.BTN_OK);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Menu = this.mainMenu1;
            this.MinimizeBox = false;
            this.Name = "FSCANOPTION";
            this.Text = "SCAN OPTION";
            this.Load += new System.EventHandler(this.FSCANOPTION_Load);
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BTN_CANCEL;
        private System.Windows.Forms.Button BTN_OK;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton RD_NOSOUND;
        private System.Windows.Forms.RadioButton RD_BEEP;
        private System.Windows.Forms.RadioButton RD_SOUNDDEFAULT;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton RD_SYNC;
        private System.Windows.Forms.RadioButton RD_ASYNC;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox CB_TIMEOUT;
        private System.Windows.Forms.CheckBox CB_VIBRATE;
        private System.Windows.Forms.CheckBox CB_AIMID;
        private System.Windows.Forms.CheckBox CB_CONTINUE;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.CheckBox CB_CENTERDECODER;
        private System.Windows.Forms.CheckBox CB_1DDECODER;
        private System.Windows.Forms.ComboBox CB_SECURITY;
        private System.Windows.Forms.Label label5;
    }
}