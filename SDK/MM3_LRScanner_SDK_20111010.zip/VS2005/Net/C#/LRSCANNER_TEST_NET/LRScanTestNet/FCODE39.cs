﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using LRScannerNet;

namespace LRScanTestNet
{
    public partial class FCODE39 : Form
    {
        private LRScanner m_LRScanner;
        private CODE39_PARAMS m_Code39;

        public FCODE39()
        {
            InitializeComponent();

            m_LRScanner = new LRScanner();
            m_Code39 = new CODE39_PARAMS();
        }

        private void FCODE39_Load(object sender, EventArgs e)
        {
            m_LRScanner.GetCODE39(out m_Code39);

            CB_ENABLE.Checked = m_Code39.bEnable;
            CB_CDV.Checked = m_Code39.bCDV;
            CB_XCD.Checked = m_Code39.bXCD;
            CB_FULLASCII.Checked = m_Code39.bFullASCII;
        }

        private void BTN_OK_Click(object sender, EventArgs e)
        {
            m_Code39.bEnable = CB_ENABLE.Checked;
            m_Code39.bCDV = CB_CDV.Checked;
            m_Code39.bXCD = CB_XCD.Checked;
            m_Code39.bFullASCII = CB_FULLASCII.Checked;

            m_LRScanner.SetCODE39(ref m_Code39);

            this.DialogResult = DialogResult.OK;
        }

        private void BTN_CANCEL_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}