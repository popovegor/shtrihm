﻿namespace LRScanTestNet
{
    partial class LRScanTestNet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.label1 = new System.Windows.Forms.Label();
            this.BN_CLOSE = new System.Windows.Forms.Button();
            this.BN_SCANOPTION = new System.Windows.Forms.Button();
            this.BN_SYM = new System.Windows.Forms.Button();
            this.BN_NEW = new System.Windows.Forms.Button();
            this.BN_INFO = new System.Windows.Forms.Button();
            this.BN_SCANCANCEL = new System.Windows.Forms.Button();
            this.BN_SCAN = new System.Windows.Forms.Button();
            this.TB_DATA = new System.Windows.Forms.TextBox();
            this.LB_TYPE = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(68, 247);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 20);
            this.label1.Text = "Ver 1.0.0 (201109005)";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // BN_CLOSE
            // 
            this.BN_CLOSE.Location = new System.Drawing.Point(17, 224);
            this.BN_CLOSE.Name = "BN_CLOSE";
            this.BN_CLOSE.Size = new System.Drawing.Size(207, 20);
            this.BN_CLOSE.TabIndex = 20;
            this.BN_CLOSE.Text = "CLOSE";
            this.BN_CLOSE.Click += new System.EventHandler(this.BN_CLOSE_Click);
            // 
            // BN_SCANOPTION
            // 
            this.BN_SCANOPTION.Location = new System.Drawing.Point(130, 172);
            this.BN_SCANOPTION.Name = "BN_SCANOPTION";
            this.BN_SCANOPTION.Size = new System.Drawing.Size(94, 20);
            this.BN_SCANOPTION.TabIndex = 19;
            this.BN_SCANOPTION.Text = "SCAN OPTION";
            this.BN_SCANOPTION.Click += new System.EventHandler(this.BN_SCANOPTION_Click);
            // 
            // BN_SYM
            // 
            this.BN_SYM.Location = new System.Drawing.Point(17, 172);
            this.BN_SYM.Name = "BN_SYM";
            this.BN_SYM.Size = new System.Drawing.Size(94, 20);
            this.BN_SYM.TabIndex = 17;
            this.BN_SYM.Text = "SYMBOLOGY";
            this.BN_SYM.Click += new System.EventHandler(this.BN_SYM_Click);
            // 
            // BN_NEW
            // 
            this.BN_NEW.Location = new System.Drawing.Point(17, 198);
            this.BN_NEW.Name = "BN_NEW";
            this.BN_NEW.Size = new System.Drawing.Size(94, 20);
            this.BN_NEW.TabIndex = 16;
            this.BN_NEW.Text = "NEW FORM";
            this.BN_NEW.Click += new System.EventHandler(this.BN_NEW_Click);
            // 
            // BN_INFO
            // 
            this.BN_INFO.Location = new System.Drawing.Point(130, 198);
            this.BN_INFO.Name = "BN_INFO";
            this.BN_INFO.Size = new System.Drawing.Size(94, 20);
            this.BN_INFO.TabIndex = 15;
            this.BN_INFO.Text = "INFO";
            this.BN_INFO.Click += new System.EventHandler(this.BN_INFO_Click);
            // 
            // BN_SCANCANCEL
            // 
            this.BN_SCANCANCEL.Location = new System.Drawing.Point(130, 146);
            this.BN_SCANCANCEL.Name = "BN_SCANCANCEL";
            this.BN_SCANCANCEL.Size = new System.Drawing.Size(94, 20);
            this.BN_SCANCANCEL.TabIndex = 14;
            this.BN_SCANCANCEL.Text = "SCAN CANCEL";
            this.BN_SCANCANCEL.Click += new System.EventHandler(this.BN_SCANCANCEL_Click);
            // 
            // BN_SCAN
            // 
            this.BN_SCAN.Location = new System.Drawing.Point(17, 146);
            this.BN_SCAN.Name = "BN_SCAN";
            this.BN_SCAN.Size = new System.Drawing.Size(94, 20);
            this.BN_SCAN.TabIndex = 13;
            this.BN_SCAN.Text = "SCAN";
            this.BN_SCAN.Click += new System.EventHandler(this.BN_SCAN_Click);
            // 
            // TB_DATA
            // 
            this.TB_DATA.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.TB_DATA.Location = new System.Drawing.Point(17, 50);
            this.TB_DATA.Multiline = true;
            this.TB_DATA.Name = "TB_DATA";
            this.TB_DATA.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TB_DATA.Size = new System.Drawing.Size(205, 89);
            this.TB_DATA.TabIndex = 12;
            this.TB_DATA.Text = "DATA";
            // 
            // LB_TYPE
            // 
            this.LB_TYPE.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.LB_TYPE.Location = new System.Drawing.Point(32, 24);
            this.LB_TYPE.Name = "LB_TYPE";
            this.LB_TYPE.Size = new System.Drawing.Size(175, 20);
            this.LB_TYPE.Text = "TYPE";
            this.LB_TYPE.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // LRScanTestNet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BN_CLOSE);
            this.Controls.Add(this.BN_SCANOPTION);
            this.Controls.Add(this.BN_SYM);
            this.Controls.Add(this.BN_NEW);
            this.Controls.Add(this.BN_INFO);
            this.Controls.Add(this.BN_SCANCANCEL);
            this.Controls.Add(this.BN_SCAN);
            this.Controls.Add(this.TB_DATA);
            this.Controls.Add(this.LB_TYPE);
            this.Menu = this.mainMenu1;
            this.MinimizeBox = false;
            this.Name = "LRScanTestNet";
            this.Text = "LRScanTestNet";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BN_CLOSE;
        private System.Windows.Forms.Button BN_SCANOPTION;
        private System.Windows.Forms.Button BN_SYM;
        private System.Windows.Forms.Button BN_NEW;
        private System.Windows.Forms.Button BN_INFO;
        private System.Windows.Forms.Button BN_SCANCANCEL;
        private System.Windows.Forms.Button BN_SCAN;
        private System.Windows.Forms.TextBox TB_DATA;
        private System.Windows.Forms.Label LB_TYPE;
    }
}

