﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace LRScanTestNet
{
    public partial class FABOUT : Form
    {

        public String m_strVersion;

        public FABOUT()
        {
            InitializeComponent();
        }

        private void FABOUT_Load(object sender, EventArgs e)
        {
            TB_INFOMATION.Text = m_strVersion;
        }

        private void BTN_OK_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }
    }
}