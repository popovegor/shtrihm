﻿namespace LRScanTestNet
{
    partial class FTEST
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.TB_DATA = new System.Windows.Forms.TextBox();
            this.LB_TYPE = new System.Windows.Forms.Label();
            this.BTN_CLOSE = new System.Windows.Forms.Button();
            this.BTN_CANCEL = new System.Windows.Forms.Button();
            this.BTN_SCAN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TB_DATA
            // 
            this.TB_DATA.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.TB_DATA.Location = new System.Drawing.Point(18, 47);
            this.TB_DATA.Multiline = true;
            this.TB_DATA.Name = "TB_DATA";
            this.TB_DATA.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TB_DATA.Size = new System.Drawing.Size(205, 89);
            this.TB_DATA.TabIndex = 25;
            this.TB_DATA.Text = "DATA";
            // 
            // LB_TYPE
            // 
            this.LB_TYPE.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.LB_TYPE.Location = new System.Drawing.Point(33, 21);
            this.LB_TYPE.Name = "LB_TYPE";
            this.LB_TYPE.Size = new System.Drawing.Size(175, 20);
            this.LB_TYPE.Text = "TYPE";
            this.LB_TYPE.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // BTN_CLOSE
            // 
            this.BTN_CLOSE.Location = new System.Drawing.Point(65, 223);
            this.BTN_CLOSE.Name = "BTN_CLOSE";
            this.BTN_CLOSE.Size = new System.Drawing.Size(114, 30);
            this.BTN_CLOSE.TabIndex = 24;
            this.BTN_CLOSE.Text = "CLOSE";
            this.BTN_CLOSE.Click += new System.EventHandler(this.BTN_CLOSE_Click);
            // 
            // BTN_CANCEL
            // 
            this.BTN_CANCEL.Location = new System.Drawing.Point(65, 185);
            this.BTN_CANCEL.Name = "BTN_CANCEL";
            this.BTN_CANCEL.Size = new System.Drawing.Size(114, 30);
            this.BTN_CANCEL.TabIndex = 23;
            this.BTN_CANCEL.Text = "SCAN CANCEL";
            this.BTN_CANCEL.Click += new System.EventHandler(this.BTN_CANCEL_Click);
            // 
            // BTN_SCAN
            // 
            this.BTN_SCAN.Location = new System.Drawing.Point(65, 146);
            this.BTN_SCAN.Name = "BTN_SCAN";
            this.BTN_SCAN.Size = new System.Drawing.Size(114, 30);
            this.BTN_SCAN.TabIndex = 22;
            this.BTN_SCAN.Text = "SCAN";
            this.BTN_SCAN.Click += new System.EventHandler(this.BTN_SCAN_Click);
            // 
            // FTEST
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.TB_DATA);
            this.Controls.Add(this.LB_TYPE);
            this.Controls.Add(this.BTN_CLOSE);
            this.Controls.Add(this.BTN_CANCEL);
            this.Controls.Add(this.BTN_SCAN);
            this.Menu = this.mainMenu1;
            this.MinimizeBox = false;
            this.Name = "FTEST";
            this.Text = "NEW FORM TEST";
            this.Closing += new System.ComponentModel.CancelEventHandler(this.FTEST_Closing);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox TB_DATA;
        private System.Windows.Forms.Label LB_TYPE;
        private System.Windows.Forms.Button BTN_CLOSE;
        private System.Windows.Forms.Button BTN_CANCEL;
        private System.Windows.Forms.Button BTN_SCAN;
    }
}