'********************************************************************
'created	:	2011/09/05
'file base	: 	LRScanTestVB.exe
'
'file ext	:	vb
'author		:	Dong-Hyun Eum & Eun-Taek Lee
'
'purpose	:	Long-Range Scanner VB Demo Program
'Report		:	2011. 09. 05 [09/05/2011 vision7901] v1.0.0 - MM3 Long-Range Scanner 2�� Release ����
'*********************************************************************/
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports System.Runtime.InteropServices
Imports Microsoft.Win32
Imports System.Threading
Imports System.Reflection
Imports System.IO
Imports LRScannerNet


Public Class LRScanTestVB

    Private m_LRScanner As LRScanner
    Private m_DecoderParams As DECODER_PARAMS

    Public m_bResult As Boolean = False
    Public m_bReading As Boolean = False
    Public m_bSyncMode As Boolean = False
    Public m_bContinueMode As Boolean = False

    Public m_strVerInfo As String

    Public Const VK_F14 As Long = &H7D 'F14(WM)
    Private m_nHotKeyWM As UInt32

    Private Sub LRScanTestVB_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        m_LRScanner = New LRScanner()
        AddHandler m_LRScanner.LRScannerDataEvent, AddressOf Me.OnScanRead

        REM Scanner Open
        m_LRScanner.Open()

        m_nHotKeyWM = UInt32.Parse(VK_F14)
        m_LRScanner.RegHotKey(1, m_nHotKeyWM, m_bSyncMode)

    End Sub

    Private Sub OnScanRead(ByVal sender As System.Object, ByVal e As LRScannerDataArgs)
        If e.ScanData <> "" Then
            LB_TYPE.Text = e.ScanType
            TB_DATA.Text = e.ScanData
        End If

        If m_bContinueMode = False Then
            m_bReading = False
        End If

    End Sub

    Private Sub BN_SCAN_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_SCAN.Click
        m_LRScanner.Read()
    End Sub

    Private Sub BN_SCANCANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_SCANCANCEL.Click
        m_LRScanner.ReadCancel()
    End Sub

    Private Sub BN_SYM_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_SYM.Click
        Dim Symbology As New FSYMBOLOGY()

        m_LRScanner.ReadCancel()
        m_LRScanner.UnRegHotKey(1)

        Symbology.ShowDialog()

        m_LRScanner.RegHotKey(1, m_nHotKeyWM, m_bSyncMode)
    End Sub

    Private Sub BN_SCANOPTION_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_SCANOPTION.Click
        Dim ScanOption As New FSCANOPTION()

        ScanOption.m_bSyncMode = m_bSyncMode

        REM Disable Scan Key
        m_LRScanner.ReadCancel()
        m_LRScanner.UnRegHotKey(1)

        If ScanOption.ShowDialog() = DialogResult.OK Then
            m_bSyncMode = ScanOption.m_bSyncMode

            REM Enable Scan Key
            m_LRScanner.RegHotKey(1, m_nHotKeyWM, m_bSyncMode)
        End If

    End Sub

    Private Sub BN_NEW_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_NEW.Click

        Dim NewForm As New FTEST()

        m_LRScanner.ReadCancel()

        RemoveHandler m_LRScanner.LRScannerDataEvent, AddressOf Me.OnScanRead

        NewForm.ShowDialog()

        AddHandler m_LRScanner.LRScannerDataEvent, AddressOf Me.OnScanRead

    End Sub

    Private Sub BN_INFO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_INFO.Click

        Dim AboutDlg As New FABOUT()

        AboutDlg.m_strVersion = m_LRScanner.GetVersionInfo()

        m_LRScanner.ReadCancel()
        m_LRScanner.UnRegHotKey(1)

        AboutDlg.ShowDialog()

        m_LRScanner.RegHotKey(1, m_nHotKeyWM, m_bSyncMode)

    End Sub

    Private Sub BN_CLOSE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_CLOSE.Click
        Close()

        Application.Exit()
    End Sub

End Class
