﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports LRScannerNet


Public Class FUPCE

    Private m_LRScanner As LRScanner
    Private m_Upce As UPCE_PARAMS

    Private Sub FUPCE_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        m_LRScanner = New LRScanner()
        m_Upce = New UPCE_PARAMS()

        m_LRScanner.GetUPCE(m_Upce)

        CB_ENABLE.Checked = m_Upce.bEnable
        CB_XNUM.Checked = m_Upce.bXNum
        CB_XCD.Checked = m_Upce.bXCD
        CB_UPCATOUPCE.Checked = m_Upce.bUPCE_AS_UPCA

    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click
        m_Upce.bEnable = CB_ENABLE.Checked
        m_Upce.bXNum = CB_XNUM.Checked
        m_Upce.bXCD = CB_XCD.Checked
        m_Upce.bUPCE_AS_UPCA = CB_UPCATOUPCE.Checked

        m_LRScanner.SetUPCE(m_Upce)

        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class