﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports LRScannerNet

Public Class FEAN8

    Private m_LRScanner As LRScanner
    Private m_Ean8 As EAN8_PARAMS

    Private Sub FEAN8_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        m_LRScanner = New LRScanner()
        m_Ean8 = New EAN8_PARAMS()

        m_LRScanner.GetEAN8(m_Ean8)

        CB_ENABLE.Checked = m_Ean8.bEnable
        CB_XCD.Checked = m_Ean8.bXCD
        CB_EAN8TOEAN13.Checked = m_Ean8.bEAN8_AS_EAN13

    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click

        m_Ean8.bEnable = CB_ENABLE.Checked
        m_Ean8.bXCD = CB_XCD.Checked
        m_Ean8.bEAN8_AS_EAN13 = CB_EAN8TOEAN13.Checked

        m_LRScanner.SetEAN8(m_Ean8)

        Me.DialogResult = Windows.Forms.DialogResult.OK

    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel

    End Sub
End Class