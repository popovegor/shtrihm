﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports LRScannerNet

Public Class FSTANDARD2OF5

    Private m_LRScanner As LRScanner
    Private m_Standard2of5 As STANDARD2OF5_PARAMS

    Private Sub FSTANDARD2OF5_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        m_LRScanner = New LRScanner()
        m_Standard2of5 = New STANDARD2OF5_PARAMS()

        m_LRScanner.GetSTANDARD2OF5(m_Standard2of5)

        CB_ENABLE.Checked = m_Standard2of5.bEnable
        CB_CDV.Checked = m_Standard2of5.bCDV
        CB_XCD.Checked = m_Standard2of5.bXCD
    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click

        m_Standard2of5.bEnable = CB_ENABLE.Checked
        m_Standard2of5.bCDV = CB_CDV.Checked
        m_Standard2of5.bXCD = CB_XCD.Checked

        m_LRScanner.SetSTANDARD2OF5(m_Standard2of5)

        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class