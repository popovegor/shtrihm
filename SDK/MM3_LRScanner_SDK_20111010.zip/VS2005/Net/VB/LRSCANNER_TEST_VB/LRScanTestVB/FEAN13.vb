﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports LRScannerNet

Public Class FEAN13

    Private m_LRScanner As LRScanner
    Private m_Ean13 As EAN13_PARAMS

    Private Sub FEAN13_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        m_LRScanner = New LRScanner()
        m_Ean13 = New EAN13_PARAMS()

        m_LRScanner.GetEAN13(m_Ean13)

        CB_ENABLE.Checked = m_Ean13.bEnable
        CB_ISXN.Checked = m_Ean13.bISxN
        CB_XCD.Checked = m_Ean13.bXCD
        CB_ADDON.Checked = m_Ean13.bAddOn

    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click
        m_Ean13.bEnable = CB_ENABLE.Checked
        m_Ean13.bISxN = CB_ISXN.Checked
        m_Ean13.bXCD = CB_XCD.Checked
        m_Ean13.bAddOn = CB_ADDON.Checked

        m_LRScanner.SetEAN13(m_Ean13)

        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class