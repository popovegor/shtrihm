﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports LRScannerNet

Public Class FSCANOPTION

    Private m_LRScanner As LRScanner
    Private m_DecoderParams As DECODER_PARAMS

    Public m_bSyncMode As Boolean

    Private Sub FSCANOPTION_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        m_LRScanner = New LRScanner()
        m_DecoderParams = New DECODER_PARAMS()

        m_LRScanner.GetOption(m_DecoderParams)

        If m_bSyncMode Then
            RD_SYNC.Checked = True
        Else
            RD_ASYNC.Checked = True
        End If

        If m_DecoderParams.nSound = 0 Then
            RD_SOUNDDEFAULT.Checked = True
        ElseIf m_DecoderParams.nSound = 1 Then
            RD_BEEP.Checked = True
        Else
            RD_NOSOUND.Checked = True
        End If

        CB_TIMEOUT.SelectedIndex = m_DecoderParams.nTimeOut - 1
        CB_SECURITY.SelectedIndex = m_DecoderParams.nSecurityLevel - 1

        If m_DecoderParams.bContinueMode = True Then
            CB_CONTINUE.Checked = True
        Else
            CB_CONTINUE.Checked = False
        End If

        If m_DecoderParams.bXmitAimID = True Then
            CB_AIMID.Checked = True
        Else
            CB_AIMID.Checked = False
        End If

        If m_DecoderParams.bVibrate = True Then
            CB_VIBRATE.Checked = True
        Else
            CB_VIBRATE.Checked = False
        End If

        If m_DecoderParams.b1DDecodeMode = True Then
            CB_1DDECODER.Checked = True
        Else
            CB_1DDECODER.Checked = False
        End If

        If m_DecoderParams.bCenterDecode = True Then
            CB_CENTERDECODER.Checked = True
        Else
            CB_CENTERDECODER.Checked = False
        End If

    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click
        m_LRScanner.GetOption(m_DecoderParams)

        If RD_SYNC.Checked Then
            m_bSyncMode = True
        Else
            m_bSyncMode = False
        End If

        If RD_SOUNDDEFAULT.Checked Then
            m_DecoderParams.nSound = 0
        ElseIf RD_BEEP.Checked Then
            m_DecoderParams.nSound = 1
        Else
            m_DecoderParams.nSound = 2
        End If

        m_DecoderParams.nTimeOut = CB_TIMEOUT.SelectedIndex + 1
        m_DecoderParams.nSecurityLevel = CB_SECURITY.SelectedIndex + 1

        If CB_CONTINUE.Checked Then
            m_DecoderParams.bContinueMode = True
        Else
            m_DecoderParams.bContinueMode = False
        End If

        If CB_AIMID.Checked Then
            m_DecoderParams.bXmitAimID = True
        Else
            m_DecoderParams.bXmitAimID = False
        End If

        If CB_VIBRATE.Checked Then
            m_DecoderParams.bVibrate = True
        Else
            m_DecoderParams.bVibrate = False
        End If

        If CB_1DDECODER.Checked Then
            m_DecoderParams.b1DDecodeMode = True
        Else
            m_DecoderParams.b1DDecodeMode = False
        End If

        If CB_CENTERDECODER.Checked Then
            m_DecoderParams.bCenterDecode = True
        Else
            m_DecoderParams.bCenterDecode = False
        End If

        m_LRScanner.SetOption(m_DecoderParams)

        Me.DialogResult = Windows.Forms.DialogResult.OK

    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class