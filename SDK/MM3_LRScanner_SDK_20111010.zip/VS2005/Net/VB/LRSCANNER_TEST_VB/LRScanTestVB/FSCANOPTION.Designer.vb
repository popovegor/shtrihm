﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class FSCANOPTION
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Private mainMenu1 As System.Windows.Forms.MainMenu

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.BTN_CANCEL = New System.Windows.Forms.Button
        Me.BTN_OK = New System.Windows.Forms.Button
        Me.label3 = New System.Windows.Forms.Label
        Me.panel5 = New System.Windows.Forms.Panel
        Me.CB_SECURITY = New System.Windows.Forms.ComboBox
        Me.label5 = New System.Windows.Forms.Label
        Me.CB_CENTERDECODER = New System.Windows.Forms.CheckBox
        Me.CB_1DDECODER = New System.Windows.Forms.CheckBox
        Me.CB_CONTINUE = New System.Windows.Forms.CheckBox
        Me.CB_AIMID = New System.Windows.Forms.CheckBox
        Me.CB_VIBRATE = New System.Windows.Forms.CheckBox
        Me.CB_TIMEOUT = New System.Windows.Forms.ComboBox
        Me.label4 = New System.Windows.Forms.Label
        Me.panel3 = New System.Windows.Forms.Panel
        Me.RD_NOSOUND = New System.Windows.Forms.RadioButton
        Me.RD_BEEP = New System.Windows.Forms.RadioButton
        Me.RD_SOUNDDEFAULT = New System.Windows.Forms.RadioButton
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.panel1 = New System.Windows.Forms.Panel
        Me.panel2 = New System.Windows.Forms.Panel
        Me.radioButton1 = New System.Windows.Forms.RadioButton
        Me.radioButton2 = New System.Windows.Forms.RadioButton
        Me.RD_SYNC = New System.Windows.Forms.RadioButton
        Me.RD_ASYNC = New System.Windows.Forms.RadioButton
        Me.panel5.SuspendLayout()
        Me.panel3.SuspendLayout()
        Me.panel1.SuspendLayout()
        Me.panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'BTN_CANCEL
        '
        Me.BTN_CANCEL.Location = New System.Drawing.Point(122, 230)
        Me.BTN_CANCEL.Name = "BTN_CANCEL"
        Me.BTN_CANCEL.Size = New System.Drawing.Size(115, 35)
        Me.BTN_CANCEL.TabIndex = 25
        Me.BTN_CANCEL.Text = "Cancel"
        '
        'BTN_OK
        '
        Me.BTN_OK.Location = New System.Drawing.Point(3, 230)
        Me.BTN_OK.Name = "BTN_OK"
        Me.BTN_OK.Size = New System.Drawing.Size(115, 35)
        Me.BTN_OK.TabIndex = 24
        Me.BTN_OK.Text = "OK"
        '
        'label3
        '
        Me.label3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
        Me.label3.Location = New System.Drawing.Point(3, 3)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(111, 14)
        Me.label3.Text = "READ OPTION"
        '
        'panel5
        '
        Me.panel5.BackColor = System.Drawing.SystemColors.Control
        Me.panel5.Controls.Add(Me.CB_SECURITY)
        Me.panel5.Controls.Add(Me.label5)
        Me.panel5.Controls.Add(Me.label3)
        Me.panel5.Controls.Add(Me.CB_CENTERDECODER)
        Me.panel5.Controls.Add(Me.CB_1DDECODER)
        Me.panel5.Controls.Add(Me.CB_CONTINUE)
        Me.panel5.Controls.Add(Me.CB_AIMID)
        Me.panel5.Controls.Add(Me.CB_VIBRATE)
        Me.panel5.Controls.Add(Me.CB_TIMEOUT)
        Me.panel5.Controls.Add(Me.label4)
        Me.panel5.Location = New System.Drawing.Point(3, 114)
        Me.panel5.Name = "panel5"
        Me.panel5.Size = New System.Drawing.Size(234, 112)
        '
        'CB_SECURITY
        '
        Me.CB_SECURITY.Items.Add("1")
        Me.CB_SECURITY.Items.Add("2")
        Me.CB_SECURITY.Items.Add("3")
        Me.CB_SECURITY.Items.Add("4")
        Me.CB_SECURITY.Items.Add("5")
        Me.CB_SECURITY.Items.Add("6")
        Me.CB_SECURITY.Items.Add("7")
        Me.CB_SECURITY.Items.Add("8")
        Me.CB_SECURITY.Items.Add("9")
        Me.CB_SECURITY.Items.Add("10")
        Me.CB_SECURITY.Location = New System.Drawing.Point(191, 22)
        Me.CB_SECURITY.Name = "CB_SECURITY"
        Me.CB_SECURITY.Size = New System.Drawing.Size(35, 22)
        Me.CB_SECURITY.TabIndex = 12
        '
        'label5
        '
        Me.label5.Location = New System.Drawing.Point(105, 25)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(81, 16)
        Me.label5.Text = "Security Level"
        '
        'CB_CENTERDECODER
        '
        Me.CB_CENTERDECODER.Location = New System.Drawing.Point(3, 88)
        Me.CB_CENTERDECODER.Name = "CB_CENTERDECODER"
        Me.CB_CENTERDECODER.Size = New System.Drawing.Size(154, 20)
        Me.CB_CENTERDECODER.TabIndex = 10
        Me.CB_CENTERDECODER.Text = "Center Decode Mode"
        '
        'CB_1DDECODER
        '
        Me.CB_1DDECODER.Location = New System.Drawing.Point(114, 68)
        Me.CB_1DDECODER.Name = "CB_1DDECODER"
        Me.CB_1DDECODER.Size = New System.Drawing.Size(117, 20)
        Me.CB_1DDECODER.TabIndex = 9
        Me.CB_1DDECODER.Text = "1D Decode Mode"
        '
        'CB_CONTINUE
        '
        Me.CB_CONTINUE.Location = New System.Drawing.Point(3, 48)
        Me.CB_CONTINUE.Name = "CB_CONTINUE"
        Me.CB_CONTINUE.Size = New System.Drawing.Size(111, 20)
        Me.CB_CONTINUE.TabIndex = 6
        Me.CB_CONTINUE.Text = "Continue Mode"
        '
        'CB_AIMID
        '
        Me.CB_AIMID.Location = New System.Drawing.Point(114, 48)
        Me.CB_AIMID.Name = "CB_AIMID"
        Me.CB_AIMID.Size = New System.Drawing.Size(114, 20)
        Me.CB_AIMID.TabIndex = 5
        Me.CB_AIMID.Text = "Transmit AIMID"
        '
        'CB_VIBRATE
        '
        Me.CB_VIBRATE.Location = New System.Drawing.Point(3, 68)
        Me.CB_VIBRATE.Name = "CB_VIBRATE"
        Me.CB_VIBRATE.Size = New System.Drawing.Size(75, 20)
        Me.CB_VIBRATE.TabIndex = 4
        Me.CB_VIBRATE.Text = "Vibrate"
        '
        'CB_TIMEOUT
        '
        Me.CB_TIMEOUT.Items.Add("1")
        Me.CB_TIMEOUT.Items.Add("2")
        Me.CB_TIMEOUT.Items.Add("3")
        Me.CB_TIMEOUT.Items.Add("4")
        Me.CB_TIMEOUT.Items.Add("5")
        Me.CB_TIMEOUT.Items.Add("6")
        Me.CB_TIMEOUT.Items.Add("7")
        Me.CB_TIMEOUT.Items.Add("8")
        Me.CB_TIMEOUT.Items.Add("9")
        Me.CB_TIMEOUT.Items.Add("10")
        Me.CB_TIMEOUT.Location = New System.Drawing.Point(60, 23)
        Me.CB_TIMEOUT.Name = "CB_TIMEOUT"
        Me.CB_TIMEOUT.Size = New System.Drawing.Size(35, 22)
        Me.CB_TIMEOUT.TabIndex = 1
        '
        'label4
        '
        Me.label4.Location = New System.Drawing.Point(5, 25)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(51, 16)
        Me.label4.Text = "Timeout"
        '
        'panel3
        '
        Me.panel3.BackColor = System.Drawing.SystemColors.Control
        Me.panel3.Controls.Add(Me.RD_NOSOUND)
        Me.panel3.Controls.Add(Me.RD_BEEP)
        Me.panel3.Controls.Add(Me.RD_SOUNDDEFAULT)
        Me.panel3.Controls.Add(Me.label2)
        Me.panel3.Location = New System.Drawing.Point(3, 56)
        Me.panel3.Name = "panel3"
        Me.panel3.Size = New System.Drawing.Size(234, 45)
        '
        'RD_NOSOUND
        '
        Me.RD_NOSOUND.Location = New System.Drawing.Point(143, 22)
        Me.RD_NOSOUND.Name = "RD_NOSOUND"
        Me.RD_NOSOUND.Size = New System.Drawing.Size(82, 20)
        Me.RD_NOSOUND.TabIndex = 2
        Me.RD_NOSOUND.Text = "No Sound"
        '
        'RD_BEEP
        '
        Me.RD_BEEP.Location = New System.Drawing.Point(80, 22)
        Me.RD_BEEP.Name = "RD_BEEP"
        Me.RD_BEEP.Size = New System.Drawing.Size(63, 20)
        Me.RD_BEEP.TabIndex = 1
        Me.RD_BEEP.Text = "Beep"
        '
        'RD_SOUNDDEFAULT
        '
        Me.RD_SOUNDDEFAULT.Location = New System.Drawing.Point(3, 22)
        Me.RD_SOUNDDEFAULT.Name = "RD_SOUNDDEFAULT"
        Me.RD_SOUNDDEFAULT.Size = New System.Drawing.Size(70, 20)
        Me.RD_SOUNDDEFAULT.TabIndex = 0
        Me.RD_SOUNDDEFAULT.Text = "Default"
        '
        'label2
        '
        Me.label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
        Me.label2.Location = New System.Drawing.Point(3, 1)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(81, 14)
        Me.label2.Text = "SOUND"
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
        Me.label1.Location = New System.Drawing.Point(3, 4)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(81, 18)
        Me.label1.Text = "SYNC MODE"
        '
        'panel1
        '
        Me.panel1.BackColor = System.Drawing.SystemColors.Control
        Me.panel1.Controls.Add(Me.panel2)
        Me.panel1.Controls.Add(Me.RD_SYNC)
        Me.panel1.Controls.Add(Me.RD_ASYNC)
        Me.panel1.Controls.Add(Me.label1)
        Me.panel1.Location = New System.Drawing.Point(3, 18)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(234, 25)
        '
        'panel2
        '
        Me.panel2.BackColor = System.Drawing.SystemColors.Control
        Me.panel2.Controls.Add(Me.radioButton1)
        Me.panel2.Controls.Add(Me.radioButton2)
        Me.panel2.Location = New System.Drawing.Point(7, 48)
        Me.panel2.Name = "panel2"
        Me.panel2.Size = New System.Drawing.Size(234, 25)
        '
        'radioButton1
        '
        Me.radioButton1.Location = New System.Drawing.Point(118, 2)
        Me.radioButton1.Name = "radioButton1"
        Me.radioButton1.Size = New System.Drawing.Size(100, 20)
        Me.radioButton1.TabIndex = 1
        Me.radioButton1.Text = "Sync Mode"
        '
        'radioButton2
        '
        Me.radioButton2.Location = New System.Drawing.Point(12, 2)
        Me.radioButton2.Name = "radioButton2"
        Me.radioButton2.Size = New System.Drawing.Size(100, 20)
        Me.radioButton2.TabIndex = 0
        Me.radioButton2.Text = "ASync Mode"
        '
        'RD_SYNC
        '
        Me.RD_SYNC.Location = New System.Drawing.Point(170, 2)
        Me.RD_SYNC.Name = "RD_SYNC"
        Me.RD_SYNC.Size = New System.Drawing.Size(57, 20)
        Me.RD_SYNC.TabIndex = 1
        Me.RD_SYNC.Text = "Sync"
        '
        'RD_ASYNC
        '
        Me.RD_ASYNC.Location = New System.Drawing.Point(102, 2)
        Me.RD_ASYNC.Name = "RD_ASYNC"
        Me.RD_ASYNC.Size = New System.Drawing.Size(61, 20)
        Me.RD_ASYNC.TabIndex = 0
        Me.RD_ASYNC.Text = "ASync"
        '
        'FSCANOPTION
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(240, 268)
        Me.Controls.Add(Me.BTN_CANCEL)
        Me.Controls.Add(Me.BTN_OK)
        Me.Controls.Add(Me.panel5)
        Me.Controls.Add(Me.panel3)
        Me.Controls.Add(Me.panel1)
        Me.Menu = Me.mainMenu1
        Me.MinimizeBox = False
        Me.Name = "FSCANOPTION"
        Me.Text = "SCANOPTION"
        Me.panel5.ResumeLayout(False)
        Me.panel3.ResumeLayout(False)
        Me.panel1.ResumeLayout(False)
        Me.panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents BTN_CANCEL As System.Windows.Forms.Button
    Private WithEvents BTN_OK As System.Windows.Forms.Button
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents panel5 As System.Windows.Forms.Panel
    Private WithEvents CB_SECURITY As System.Windows.Forms.ComboBox
    Private WithEvents label5 As System.Windows.Forms.Label
    Private WithEvents CB_CENTERDECODER As System.Windows.Forms.CheckBox
    Private WithEvents CB_1DDECODER As System.Windows.Forms.CheckBox
    Private WithEvents CB_CONTINUE As System.Windows.Forms.CheckBox
    Private WithEvents CB_AIMID As System.Windows.Forms.CheckBox
    Private WithEvents CB_VIBRATE As System.Windows.Forms.CheckBox
    Private WithEvents CB_TIMEOUT As System.Windows.Forms.ComboBox
    Private WithEvents label4 As System.Windows.Forms.Label
    Private WithEvents panel3 As System.Windows.Forms.Panel
    Private WithEvents RD_NOSOUND As System.Windows.Forms.RadioButton
    Private WithEvents RD_BEEP As System.Windows.Forms.RadioButton
    Private WithEvents RD_SOUNDDEFAULT As System.Windows.Forms.RadioButton
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents panel1 As System.Windows.Forms.Panel
    Private WithEvents panel2 As System.Windows.Forms.Panel
    Private WithEvents radioButton1 As System.Windows.Forms.RadioButton
    Private WithEvents radioButton2 As System.Windows.Forms.RadioButton
    Private WithEvents RD_SYNC As System.Windows.Forms.RadioButton
    Private WithEvents RD_ASYNC As System.Windows.Forms.RadioButton
End Class
