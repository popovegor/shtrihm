﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports LRScannerNet


Public Class FTEST

    Private m_LRScanner As LRScanner
    Private m_DecoderParams As DECODER_PARAMS

    Private Sub FTEST_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        m_LRScanner = New LRScanner()
        AddHandler m_LRScanner.LRScannerDataEvent, AddressOf Me.OnScanRead

    End Sub

    Private Sub BTN_SCAN_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_SCAN.Click
        m_LRScanner.Read()
    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        m_LRScanner.ReadCancel()
    End Sub

    Private Sub BTN_CLOSE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CLOSE.Click
        Close()
    End Sub

    Private Sub OnScanRead(ByVal sender As System.Object, ByVal e As LRScannerDataArgs)
        If e.ScanData <> "" Then
            LB_TYPE.Text = e.ScanType
            TB_DATA.Text = e.ScanData
        End If

    End Sub


    Private Sub FTEST_Closing(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        RemoveHandler m_LRScanner.LRScannerDataEvent, AddressOf Me.OnScanRead
        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub
End Class