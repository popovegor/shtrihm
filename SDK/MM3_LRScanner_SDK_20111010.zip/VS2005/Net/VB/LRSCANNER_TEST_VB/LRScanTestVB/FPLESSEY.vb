﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports LRScannerNet


Public Class FPLESSEY

    Private m_LRScanner As LRScanner
    Private m_Plessey As PLESSEY_PARAMS

    Private Sub FPLESSEY_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        m_LRScanner = New LRScanner()
        m_Plessey = New PLESSEY_PARAMS()

        m_LRScanner.GetPLESSEY(m_Plessey)

        CB_ENABLE.Checked = m_Plessey.bEnable
        CB_CDV.Checked = m_Plessey.bCDV
    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click
        m_Plessey.bEnable = CB_ENABLE.Checked
        m_Plessey.bCDV = CB_CDV.Checked

        m_LRScanner.SetPLESSEY(m_Plessey)

        Me.DialogResult = Windows.Forms.DialogResult.OK

    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class