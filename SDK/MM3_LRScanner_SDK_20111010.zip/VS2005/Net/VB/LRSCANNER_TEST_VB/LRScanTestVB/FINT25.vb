﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports LRScannerNet

Public Class FINT25

    Private m_LRScanner As LRScanner
    Private m_Int25 As INT25_PARAMS

    Private Sub FINT25_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        m_LRScanner = New LRScanner()
        m_Int25 = New INT25_PARAMS()

        m_LRScanner.GetINT25(m_Int25)

        CB_ENABLE.Checked = m_Int25.bEnable
        CB_CDV.Checked = m_Int25.bCDV
        CB_XCD.Checked = m_Int25.bXCD
    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click
        m_Int25.bEnable = CB_ENABLE.Checked
        m_Int25.bCDV = CB_CDV.Checked
        m_Int25.bXCD = CB_XCD.Checked

        m_LRScanner.SetINT25(m_Int25)

        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class