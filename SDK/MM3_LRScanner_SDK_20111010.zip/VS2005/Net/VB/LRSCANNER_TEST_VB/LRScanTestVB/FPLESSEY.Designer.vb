﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class FPLESSEY
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Private mainMenu1 As System.Windows.Forms.MainMenu

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.BTN_CANCEL = New System.Windows.Forms.Button
        Me.BTN_OK = New System.Windows.Forms.Button
        Me.panel2 = New System.Windows.Forms.Panel
        Me.CB_CDV = New System.Windows.Forms.CheckBox
        Me.CB_ENABLE = New System.Windows.Forms.CheckBox
        Me.panel1 = New System.Windows.Forms.Panel
        Me.label1 = New System.Windows.Forms.Label
        Me.panel2.SuspendLayout()
        Me.panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'BTN_CANCEL
        '
        Me.BTN_CANCEL.Location = New System.Drawing.Point(124, 230)
        Me.BTN_CANCEL.Name = "BTN_CANCEL"
        Me.BTN_CANCEL.Size = New System.Drawing.Size(107, 33)
        Me.BTN_CANCEL.TabIndex = 35
        Me.BTN_CANCEL.Text = "Cancel"
        '
        'BTN_OK
        '
        Me.BTN_OK.Location = New System.Drawing.Point(10, 230)
        Me.BTN_OK.Name = "BTN_OK"
        Me.BTN_OK.Size = New System.Drawing.Size(107, 33)
        Me.BTN_OK.TabIndex = 34
        Me.BTN_OK.Text = "OK"
        '
        'panel2
        '
        Me.panel2.BackColor = System.Drawing.SystemColors.Control
        Me.panel2.Controls.Add(Me.CB_CDV)
        Me.panel2.Controls.Add(Me.CB_ENABLE)
        Me.panel2.Location = New System.Drawing.Point(10, 36)
        Me.panel2.Name = "panel2"
        Me.panel2.Size = New System.Drawing.Size(221, 188)
        '
        'CB_CDV
        '
        Me.CB_CDV.Location = New System.Drawing.Point(24, 118)
        Me.CB_CDV.Name = "CB_CDV"
        Me.CB_CDV.Size = New System.Drawing.Size(162, 20)
        Me.CB_CDV.TabIndex = 19
        Me.CB_CDV.Text = "Transmit Check Digit"
        '
        'CB_ENABLE
        '
        Me.CB_ENABLE.Location = New System.Drawing.Point(24, 50)
        Me.CB_ENABLE.Name = "CB_ENABLE"
        Me.CB_ENABLE.Size = New System.Drawing.Size(100, 20)
        Me.CB_ENABLE.TabIndex = 0
        Me.CB_ENABLE.Text = "Enable"
        '
        'panel1
        '
        Me.panel1.BackColor = System.Drawing.SystemColors.Control
        Me.panel1.Controls.Add(Me.label1)
        Me.panel1.Location = New System.Drawing.Point(74, 5)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(90, 25)
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
        Me.label1.Location = New System.Drawing.Point(14, 5)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(67, 14)
        Me.label1.Text = "PLESSEY"
        '
        'FPLESSEY
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(240, 268)
        Me.Controls.Add(Me.BTN_CANCEL)
        Me.Controls.Add(Me.BTN_OK)
        Me.Controls.Add(Me.panel2)
        Me.Controls.Add(Me.panel1)
        Me.Menu = Me.mainMenu1
        Me.MinimizeBox = False
        Me.Name = "FPLESSEY"
        Me.Text = "PLESSEY"
        Me.panel2.ResumeLayout(False)
        Me.panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents BTN_CANCEL As System.Windows.Forms.Button
    Private WithEvents BTN_OK As System.Windows.Forms.Button
    Private WithEvents panel2 As System.Windows.Forms.Panel
    Private WithEvents CB_CDV As System.Windows.Forms.CheckBox
    Private WithEvents CB_ENABLE As System.Windows.Forms.CheckBox
    Private WithEvents panel1 As System.Windows.Forms.Panel
    Private WithEvents label1 As System.Windows.Forms.Label
End Class
