﻿Public Class FABOUT

    Public m_strVersion As String

    Private Sub FABOUT_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TB_INFOMATION.Text = m_strVersion
    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click
        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub
End Class