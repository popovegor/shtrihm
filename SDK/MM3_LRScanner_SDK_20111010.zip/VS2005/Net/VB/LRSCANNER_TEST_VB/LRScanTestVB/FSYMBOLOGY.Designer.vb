﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class FSYMBOLOGY
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Private mainMenu1 As System.Windows.Forms.MainMenu

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.BTN_CANCEL = New System.Windows.Forms.Button
        Me.OK = New System.Windows.Forms.Button
        Me.BTN_DAFAULT = New System.Windows.Forms.Button
        Me.BTN_PARAM = New System.Windows.Forms.Button
        Me.BTN_ALL = New System.Windows.Forms.Button
        Me.LV_SYMLIST = New System.Windows.Forms.ListView
        Me.LV_ENABLE = New System.Windows.Forms.ColumnHeader
        Me.LV_SYMBOLOGY = New System.Windows.Forms.ColumnHeader
        Me.SuspendLayout()
        '
        'BTN_CANCEL
        '
        Me.BTN_CANCEL.Location = New System.Drawing.Point(123, 239)
        Me.BTN_CANCEL.Name = "BTN_CANCEL"
        Me.BTN_CANCEL.Size = New System.Drawing.Size(114, 25)
        Me.BTN_CANCEL.TabIndex = 28
        Me.BTN_CANCEL.Text = "Cancel"
        '
        'OK
        '
        Me.OK.Location = New System.Drawing.Point(3, 239)
        Me.OK.Name = "OK"
        Me.OK.Size = New System.Drawing.Size(114, 25)
        Me.OK.TabIndex = 27
        Me.OK.Text = "OK"
        '
        'BTN_DAFAULT
        '
        Me.BTN_DAFAULT.Location = New System.Drawing.Point(165, 211)
        Me.BTN_DAFAULT.Name = "BTN_DAFAULT"
        Me.BTN_DAFAULT.Size = New System.Drawing.Size(72, 25)
        Me.BTN_DAFAULT.TabIndex = 26
        Me.BTN_DAFAULT.Text = "Default"
        '
        'BTN_PARAM
        '
        Me.BTN_PARAM.Location = New System.Drawing.Point(85, 211)
        Me.BTN_PARAM.Name = "BTN_PARAM"
        Me.BTN_PARAM.Size = New System.Drawing.Size(72, 25)
        Me.BTN_PARAM.TabIndex = 25
        Me.BTN_PARAM.Text = "Param"
        '
        'BTN_ALL
        '
        Me.BTN_ALL.Location = New System.Drawing.Point(3, 211)
        Me.BTN_ALL.Name = "BTN_ALL"
        Me.BTN_ALL.Size = New System.Drawing.Size(72, 25)
        Me.BTN_ALL.TabIndex = 24
        Me.BTN_ALL.Text = "All"
        '
        'LV_SYMLIST
        '
        Me.LV_SYMLIST.Activation = System.Windows.Forms.ItemActivation.OneClick
        Me.LV_SYMLIST.CheckBoxes = True
        Me.LV_SYMLIST.Columns.Add(Me.LV_ENABLE)
        Me.LV_SYMLIST.Columns.Add(Me.LV_SYMBOLOGY)
        Me.LV_SYMLIST.FullRowSelect = True
        Me.LV_SYMLIST.Location = New System.Drawing.Point(3, 3)
        Me.LV_SYMLIST.Name = "LV_SYMLIST"
        Me.LV_SYMLIST.Size = New System.Drawing.Size(234, 202)
        Me.LV_SYMLIST.TabIndex = 23
        Me.LV_SYMLIST.View = System.Windows.Forms.View.Details
        '
        'LV_ENABLE
        '
        Me.LV_ENABLE.Text = "Enable"
        Me.LV_ENABLE.Width = 60
        '
        'LV_SYMBOLOGY
        '
        Me.LV_SYMBOLOGY.Text = "Symbology"
        Me.LV_SYMBOLOGY.Width = 150
        '
        'FSYMBOLOGY
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(240, 268)
        Me.Controls.Add(Me.BTN_CANCEL)
        Me.Controls.Add(Me.OK)
        Me.Controls.Add(Me.BTN_DAFAULT)
        Me.Controls.Add(Me.BTN_PARAM)
        Me.Controls.Add(Me.BTN_ALL)
        Me.Controls.Add(Me.LV_SYMLIST)
        Me.Menu = Me.mainMenu1
        Me.MinimizeBox = False
        Me.Name = "FSYMBOLOGY"
        Me.Text = "SYMBOLOGY"
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents BTN_CANCEL As System.Windows.Forms.Button
    Private WithEvents OK As System.Windows.Forms.Button
    Private WithEvents BTN_DAFAULT As System.Windows.Forms.Button
    Private WithEvents BTN_PARAM As System.Windows.Forms.Button
    Private WithEvents BTN_ALL As System.Windows.Forms.Button
    Private WithEvents LV_SYMLIST As System.Windows.Forms.ListView
    Private WithEvents LV_ENABLE As System.Windows.Forms.ColumnHeader
    Private WithEvents LV_SYMBOLOGY As System.Windows.Forms.ColumnHeader
End Class
