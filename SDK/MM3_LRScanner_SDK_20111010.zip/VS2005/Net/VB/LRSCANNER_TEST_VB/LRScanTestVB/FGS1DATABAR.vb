﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports LRScannerNet

Public Class FGS1DATABAR

    Private m_LRScanner As LRScanner
    Private m_Gs1databar As GS1DATABAR_PARAMS

    Private Sub FGS1DATABAR_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        m_LRScanner = New LRScanner()
        m_Gs1databar = New GS1DATABAR_PARAMS()

        m_LRScanner.GetGS1DATABAR(m_Gs1databar)

        CB_ENABLE.Checked = m_Gs1databar.bEnable
        CB_GS1LIM.Checked = m_Gs1databar.bGS1LIM
        CB_GS1EXP.Checked = m_Gs1databar.bGS1EXP


    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click
        m_Gs1databar.bEnable = CB_ENABLE.Checked
        m_Gs1databar.bGS1LIM = CB_GS1LIM.Checked
        m_Gs1databar.bGS1EXP = CB_GS1EXP.Checked

        m_LRScanner.SetGS1DATABAR(m_Gs1databar)

        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class