﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports LRScannerNet


Public Class FCODE128

    Private m_LRScanner As LRScanner
    Private m_Code128 As CODE128_PARAMS

    Private Sub FCODE128_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        m_LRScanner = New LRScanner()
        m_Code128 = New CODE128_PARAMS()

        m_LRScanner.GetCODE128(m_Code128)

        CB_ENABLE.Checked = m_Code128.bEnable
        CB_GS1128.Checked = m_Code128.bGs1_128
        CB_ISBT128.Checked = m_Code128.bIsbt128

    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click

        m_Code128.bEnable = CB_ENABLE.Checked
        m_Code128.bGs1_128 = CB_GS1128.Checked
        m_Code128.bIsbt128 = CB_ISBT128.Checked

        m_LRScanner.SetCODE128(m_Code128)

        Me.DialogResult = Windows.Forms.DialogResult.OK


    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class