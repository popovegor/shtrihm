﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports LRScannerNet


Public Class FGS1COMPOSITE

    Private m_LRScanner As LRScanner
    Private m_Gs1composite As GS1COMPOSITE_PARAMS

    Private Sub FGS1COMPOSITE_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        m_LRScanner = New LRScanner()
        m_Gs1composite = New GS1COMPOSITE_PARAMS()

        m_LRScanner.GetGS1COMPOSITE(m_Gs1composite)

        CB_ENABLE.Checked = m_Gs1composite.bEnable
        CB_ENABLE_CC.Checked = m_Gs1composite.bCC_C

    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click

        m_Gs1composite.bEnable = CB_ENABLE.Checked
        m_Gs1composite.bCC_C = CB_ENABLE_CC.Checked

        m_LRScanner.SetGS1COMPOSITE(m_Gs1composite)

        Me.DialogResult = Windows.Forms.DialogResult.OK

    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click

        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class