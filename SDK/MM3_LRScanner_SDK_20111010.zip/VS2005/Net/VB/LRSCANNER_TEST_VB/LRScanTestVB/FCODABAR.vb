﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports LRScannerNet


Public Class FCODABAR

    Private m_LRScanner As LRScanner
    Private m_Codabar As CODABAR_PARAMS

    Private Sub FCODABAR_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        m_LRScanner = New LRScanner()
        m_Codabar = New CODABAR_PARAMS()

        m_LRScanner.GetCODABAR(m_Codabar)

        CB_ENABLE.Checked = m_Codabar.bEnable
        CB_CDV.Checked = m_Codabar.bCDV
        CB_XCD.Checked = m_Codabar.bXCD
        CB_XMITSS.Checked = m_Codabar.bXSS
    End Sub


    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click

        m_Codabar.bEnable = CB_ENABLE.Checked
        m_Codabar.bCDV = CB_CDV.Checked
        m_Codabar.bXCD = CB_XCD.Checked
        m_Codabar.bXSS = CB_XMITSS.Checked

        m_LRScanner.SetCODABAR(m_Codabar)

        Me.DialogResult = Windows.Forms.DialogResult.OK

    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class