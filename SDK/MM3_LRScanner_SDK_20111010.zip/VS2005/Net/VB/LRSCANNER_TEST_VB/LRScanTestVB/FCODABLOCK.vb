﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports LRScannerNet


Public Class FCODABLOCK

    Private m_LRScanner As LRScanner
    Private m_Codablock As CODABLOCK_PARAMS

    Private Sub FCODABLOCK_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        m_LRScanner = New LRScanner()
        m_Codablock = New CODABLOCK_PARAMS()

        m_LRScanner.GetCODABLOCK(m_Codablock)

        CB_ENABLE_CODABLOCKA.Checked = m_Codablock.bEnable
        CB_ENABLE_CODABLOCKF.Checked = m_Codablock.bCodaBlock_F
    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click

        m_Codablock.bEnable = CB_ENABLE_CODABLOCKA.Checked
        m_Codablock.bCodaBlock_F = CB_ENABLE_CODABLOCKF.Checked

        m_LRScanner.SetCODABLOCK(m_Codablock)

        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class