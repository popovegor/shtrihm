﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports LRScannerNet


Public Class FMSI

    Private m_LRScanner As LRScanner
    Private m_Msi As MSI_PARAMS

    Private Sub FMSI_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        m_LRScanner = New LRScanner()
        m_Msi = New MSI_PARAMS()

        m_LRScanner.GetMSI(m_Msi)

        CB_ENABLE.Checked = m_Msi.bEnable
        CB_CDV.Checked = m_Msi.bCDV

        If m_Msi.bXCD = False Then
            RD_MOD10.Checked = True
        ElseIf m_Msi.bXCD = True Then
            RD_MOD10_10.Checked = True
        End If
    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click
        m_Msi.bEnable = CB_ENABLE.Checked
        m_Msi.bCDV = CB_CDV.Checked

        If RD_MOD10.Checked Then
            m_Msi.bXCD = False
        ElseIf RD_MOD10_10.Checked Then
            m_Msi.bXCD = True
        End If

        m_LRScanner.SetMSI(m_Msi)

        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class