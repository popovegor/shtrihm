﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class FTEST
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Private mainMenu1 As System.Windows.Forms.MainMenu

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.TB_DATA = New System.Windows.Forms.TextBox
        Me.LB_TYPE = New System.Windows.Forms.Label
        Me.BTN_CLOSE = New System.Windows.Forms.Button
        Me.BTN_CANCEL = New System.Windows.Forms.Button
        Me.BTN_SCAN = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'TB_DATA
        '
        Me.TB_DATA.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold)
        Me.TB_DATA.Location = New System.Drawing.Point(18, 44)
        Me.TB_DATA.Multiline = True
        Me.TB_DATA.Name = "TB_DATA"
        Me.TB_DATA.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TB_DATA.Size = New System.Drawing.Size(205, 89)
        Me.TB_DATA.TabIndex = 30
        Me.TB_DATA.Text = "DATA"
        '
        'LB_TYPE
        '
        Me.LB_TYPE.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold)
        Me.LB_TYPE.Location = New System.Drawing.Point(33, 18)
        Me.LB_TYPE.Name = "LB_TYPE"
        Me.LB_TYPE.Size = New System.Drawing.Size(175, 20)
        Me.LB_TYPE.Text = "TYPE"
        Me.LB_TYPE.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'BTN_CLOSE
        '
        Me.BTN_CLOSE.Location = New System.Drawing.Point(65, 220)
        Me.BTN_CLOSE.Name = "BTN_CLOSE"
        Me.BTN_CLOSE.Size = New System.Drawing.Size(114, 30)
        Me.BTN_CLOSE.TabIndex = 29
        Me.BTN_CLOSE.Text = "CLOSE"
        '
        'BTN_CANCEL
        '
        Me.BTN_CANCEL.Location = New System.Drawing.Point(65, 182)
        Me.BTN_CANCEL.Name = "BTN_CANCEL"
        Me.BTN_CANCEL.Size = New System.Drawing.Size(114, 30)
        Me.BTN_CANCEL.TabIndex = 28
        Me.BTN_CANCEL.Text = "SCAN CANCEL"
        '
        'BTN_SCAN
        '
        Me.BTN_SCAN.Location = New System.Drawing.Point(65, 143)
        Me.BTN_SCAN.Name = "BTN_SCAN"
        Me.BTN_SCAN.Size = New System.Drawing.Size(114, 30)
        Me.BTN_SCAN.TabIndex = 27
        Me.BTN_SCAN.Text = "SCAN"
        '
        'FTEST
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(240, 268)
        Me.Controls.Add(Me.TB_DATA)
        Me.Controls.Add(Me.LB_TYPE)
        Me.Controls.Add(Me.BTN_CLOSE)
        Me.Controls.Add(Me.BTN_CANCEL)
        Me.Controls.Add(Me.BTN_SCAN)
        Me.Menu = Me.mainMenu1
        Me.MinimizeBox = False
        Me.Name = "FTEST"
        Me.Text = "NEW FORM TEST"
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents TB_DATA As System.Windows.Forms.TextBox
    Private WithEvents LB_TYPE As System.Windows.Forms.Label
    Private WithEvents BTN_CLOSE As System.Windows.Forms.Button
    Private WithEvents BTN_CANCEL As System.Windows.Forms.Button
    Private WithEvents BTN_SCAN As System.Windows.Forms.Button
End Class
