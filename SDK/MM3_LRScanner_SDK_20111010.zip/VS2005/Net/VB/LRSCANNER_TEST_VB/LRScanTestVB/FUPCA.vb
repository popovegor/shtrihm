﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports LRScannerNet


Public Class FUPCA

    Private m_LRScanner As LRScanner
    Private m_Upca As UPCA_PARAMS

    Private Sub FUPCA_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        m_LRScanner = New LRScanner()
        m_Upca = New UPCA_PARAMS()

        m_LRScanner.GetUPCA(m_Upca)

        CB_ENABLE.Checked = m_Upca.bEnable
        CB_XNUM.Checked = m_Upca.bXNum
        CB_XCD.Checked = m_Upca.bXCD
        CB_UPCATOEAN13.Checked = m_Upca.bUPCA_AS_EAN13
        CB_ADDON.Checked = m_Upca.bAddOn

    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click

        m_Upca.bEnable = CB_ENABLE.Checked
        m_Upca.bXNum = CB_XNUM.Checked
        m_Upca.bXCD = CB_XCD.Checked
        m_Upca.bUPCA_AS_EAN13 = CB_UPCATOEAN13.Checked
        m_Upca.bAddOn = CB_ADDON.Checked

        m_LRScanner.SetUPCA(m_Upca)

        Me.DialogResult = Windows.Forms.DialogResult.OK

    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class