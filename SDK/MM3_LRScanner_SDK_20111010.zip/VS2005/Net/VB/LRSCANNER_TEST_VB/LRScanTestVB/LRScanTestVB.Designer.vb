<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class LRScanTestVB
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Private mainMenu1 As System.Windows.Forms.MainMenu

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.label1 = New System.Windows.Forms.Label
        Me.BN_CLOSE = New System.Windows.Forms.Button
        Me.BN_SCANOPTION = New System.Windows.Forms.Button
        Me.BN_SYM = New System.Windows.Forms.Button
        Me.BN_NEW = New System.Windows.Forms.Button
        Me.BN_INFO = New System.Windows.Forms.Button
        Me.BN_SCANCANCEL = New System.Windows.Forms.Button
        Me.BN_SCAN = New System.Windows.Forms.Button
        Me.TB_DATA = New System.Windows.Forms.TextBox
        Me.LB_TYPE = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
        Me.label1.Location = New System.Drawing.Point(68, 247)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(156, 20)
        Me.label1.Text = "Ver 1.0.0 (20110905)"
        Me.label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'BN_CLOSE
        '
        Me.BN_CLOSE.Location = New System.Drawing.Point(17, 224)
        Me.BN_CLOSE.Name = "BN_CLOSE"
        Me.BN_CLOSE.Size = New System.Drawing.Size(207, 20)
        Me.BN_CLOSE.TabIndex = 30
        Me.BN_CLOSE.Text = "CLOSE"
        '
        'BN_SCANOPTION
        '
        Me.BN_SCANOPTION.Location = New System.Drawing.Point(130, 172)
        Me.BN_SCANOPTION.Name = "BN_SCANOPTION"
        Me.BN_SCANOPTION.Size = New System.Drawing.Size(94, 20)
        Me.BN_SCANOPTION.TabIndex = 29
        Me.BN_SCANOPTION.Text = "SCAN OPTION"
        '
        'BN_SYM
        '
        Me.BN_SYM.Location = New System.Drawing.Point(17, 172)
        Me.BN_SYM.Name = "BN_SYM"
        Me.BN_SYM.Size = New System.Drawing.Size(94, 20)
        Me.BN_SYM.TabIndex = 28
        Me.BN_SYM.Text = "SYMBOLOGY"
        '
        'BN_NEW
        '
        Me.BN_NEW.Location = New System.Drawing.Point(17, 198)
        Me.BN_NEW.Name = "BN_NEW"
        Me.BN_NEW.Size = New System.Drawing.Size(94, 20)
        Me.BN_NEW.TabIndex = 27
        Me.BN_NEW.Text = "NEW FORM"
        '
        'BN_INFO
        '
        Me.BN_INFO.Location = New System.Drawing.Point(130, 198)
        Me.BN_INFO.Name = "BN_INFO"
        Me.BN_INFO.Size = New System.Drawing.Size(94, 20)
        Me.BN_INFO.TabIndex = 26
        Me.BN_INFO.Text = "INFO"
        '
        'BN_SCANCANCEL
        '
        Me.BN_SCANCANCEL.Location = New System.Drawing.Point(130, 146)
        Me.BN_SCANCANCEL.Name = "BN_SCANCANCEL"
        Me.BN_SCANCANCEL.Size = New System.Drawing.Size(94, 20)
        Me.BN_SCANCANCEL.TabIndex = 25
        Me.BN_SCANCANCEL.Text = "SCAN CANCEL"
        '
        'BN_SCAN
        '
        Me.BN_SCAN.Location = New System.Drawing.Point(17, 146)
        Me.BN_SCAN.Name = "BN_SCAN"
        Me.BN_SCAN.Size = New System.Drawing.Size(94, 20)
        Me.BN_SCAN.TabIndex = 24
        Me.BN_SCAN.Text = "SCAN"
        '
        'TB_DATA
        '
        Me.TB_DATA.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold)
        Me.TB_DATA.Location = New System.Drawing.Point(17, 50)
        Me.TB_DATA.Multiline = True
        Me.TB_DATA.Name = "TB_DATA"
        Me.TB_DATA.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TB_DATA.Size = New System.Drawing.Size(205, 89)
        Me.TB_DATA.TabIndex = 23
        Me.TB_DATA.Text = "DATA"
        '
        'LB_TYPE
        '
        Me.LB_TYPE.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold)
        Me.LB_TYPE.Location = New System.Drawing.Point(32, 24)
        Me.LB_TYPE.Name = "LB_TYPE"
        Me.LB_TYPE.Size = New System.Drawing.Size(175, 20)
        Me.LB_TYPE.Text = "TYPE"
        Me.LB_TYPE.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'LRScanTestVB
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(240, 268)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.BN_CLOSE)
        Me.Controls.Add(Me.BN_SCANOPTION)
        Me.Controls.Add(Me.BN_SYM)
        Me.Controls.Add(Me.BN_NEW)
        Me.Controls.Add(Me.BN_INFO)
        Me.Controls.Add(Me.BN_SCANCANCEL)
        Me.Controls.Add(Me.BN_SCAN)
        Me.Controls.Add(Me.TB_DATA)
        Me.Controls.Add(Me.LB_TYPE)
        Me.Menu = Me.mainMenu1
        Me.MinimizeBox = False
        Me.Name = "LRScanTestVB"
        Me.Text = "LRScanTestVB"
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents BN_CLOSE As System.Windows.Forms.Button
    Private WithEvents BN_SCANOPTION As System.Windows.Forms.Button
    Private WithEvents BN_SYM As System.Windows.Forms.Button
    Private WithEvents BN_NEW As System.Windows.Forms.Button
    Private WithEvents BN_INFO As System.Windows.Forms.Button
    Private WithEvents BN_SCANCANCEL As System.Windows.Forms.Button
    Private WithEvents BN_SCAN As System.Windows.Forms.Button
    Private WithEvents TB_DATA As System.Windows.Forms.TextBox
    Private WithEvents LB_TYPE As System.Windows.Forms.Label

End Class
