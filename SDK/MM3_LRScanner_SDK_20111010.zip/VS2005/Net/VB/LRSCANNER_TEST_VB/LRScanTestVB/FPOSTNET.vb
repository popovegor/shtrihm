﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports LRScannerNet

Public Class FPOSTNET

    Private m_LRScanner As LRScanner
    Private m_Postnet As POSTNET_PARAMS

    Private Sub FPOSTNET_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        m_LRScanner = New LRScanner()
        m_Postnet = New POSTNET_PARAMS()

        m_LRScanner.GetPOSTNET(m_Postnet)

        CB_ENABLE.Checked = m_Postnet.bEnable
        CB_XCD.Checked = m_Postnet.bXCD
    End Sub

    Private Sub BTN_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_OK.Click
        m_Postnet.bEnable = CB_ENABLE.Checked
        m_Postnet.bXCD = CB_XCD.Checked

        m_LRScanner.SetPOSTNET(m_Postnet)

        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub

    Private Sub BTN_CANCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_CANCEL.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class