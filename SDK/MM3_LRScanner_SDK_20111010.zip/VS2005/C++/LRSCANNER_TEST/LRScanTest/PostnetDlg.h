#pragma once


// CPostnetDlg dialog

class CPostnetDlg : public CDialog
{
	DECLARE_DYNAMIC(CPostnetDlg)

public:
	CPostnetDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CPostnetDlg();

// Dialog Data
	enum { IDD = IDD_POSTNET_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
	BOOL m_bEnable;
	BOOL m_bXCD;
};
