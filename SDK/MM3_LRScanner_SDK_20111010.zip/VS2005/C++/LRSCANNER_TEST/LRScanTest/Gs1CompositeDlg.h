#pragma once


// CGs1CompositeDlg dialog

class CGs1CompositeDlg : public CDialog
{
	DECLARE_DYNAMIC(CGs1CompositeDlg)

public:
	CGs1CompositeDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CGs1CompositeDlg();

// Dialog Data
	enum { IDD = IDD_GS1COMPOSITE_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
	BOOL m_bEnable;
	BOOL m_bCC_C;
};
