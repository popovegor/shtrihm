#pragma once


// CTelepenDlg dialog

class CTelepenDlg : public CDialog
{
	DECLARE_DYNAMIC(CTelepenDlg)

public:
	CTelepenDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CTelepenDlg();

// Dialog Data
	enum { IDD = IDD_TELEPEN_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
	BOOL m_bEnable;
	BOOL m_bNumeric;
};
