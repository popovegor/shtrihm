//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by LRScanTestppc.rc
//
#define IDD_LRSCANTEST_DIALOG           102
#define IDD_SYMBOLOGY_DLG               103
#define IDD_CODABAR_DLG                 104
#define IDD_GS1COMPOSITE_DLG            105
#define IDD_EAN13_DLG                   106
#define IDD_CODE39_DLG                  107
#define IDD_CODE11_DLG                  108
#define IDD_INT25_DLG                   109
#define IDD_EAN8_DLG                    110
#define IDD_POSTNET_DLG                 111
#define IDD_GS1DATABAR_DLG              112
#define IDD_UPCA_DLG                    113
#define IDD_UPCE_DLG                    114
#define IDD_CODE128_DLG                 115
#define IDD_MSI_DLG                     116
#define IDD_TELEPEN_DLG                 117
#define IDD_ABOUT_DLG                   119
#define IDR_MAINFRAME                   128
#define IDB_M3LOGO                      130
#define IDD_TEST_DLG                    131
#define IDD_CODABLOCK_DLG               132
#define IDD_PLESSEY_DLG                 133
#define IDD_STANDARD2OF5_DLG            134
#define IDD_SCANOPTION_DLG              135
#define IDC_STATIC_1                    200
#define IDC_LIST_SYMBOLOGY              1000
#define IDC_RADIO_CDV1                  1000
#define IDC_STATIC_TYPE                 1001
#define IDC_RADIO_CDV2                  1001
#define IDC_BTN_SCAN                    1002
#define IDC_BTN_ALL                     1002
#define IDC_CHECK_GS1_128               1002
#define IDC_BTN_SCANCANCEL              1003
#define IDC_BTN_PARAM                   1003
#define IDC_CHECK1                      1003
#define IDC_CHECK_UPCA_AS_EAN13         1003
#define IDC_BTN_INFO                    1004
#define IDC_BTN_DEFAULT                 1004
#define IDC_CHECK_UPCE_AS_UPCA          1004
#define IDC_BTN_SCANOPTION              1005
#define IDC_CHECK_EAN8_AS_EAN13         1005
#define IDC_BTN_SYMBOLOGY               1006
#define IDC_RADIO_MOD10                 1006
#define IDC_BTN_SYMOPTION               1007
#define IDC_RADIO_MOD10_10              1007
#define IDC_RADIO_ASYNC                 1008
#define IDC_RADIO2                      1009
#define IDC_CHECK_1DDECODE              1010
#define IDC_CHECK_CODABLOCKF            1011
#define IDC_BTN_NEW                     1014
#define IDC_COMBO_TIMEOUT               1014
#define IDC_BTN_CLOSE                   1015
#define IDC_CHECK_FULLASCII             1015
#define IDC_COMBO3                      1015
#define IDC_COMBO_SECURITYLEVEL         1015
#define IDC_CHECK_ENABLE                1016
#define IDC_CHECK_VIBRATE               1016
#define IDC_CHECK_CDV                   1017
#define IDC_CHECK_XCD                   1018
#define IDC_CHECK_XSS                   1019
#define IDC_CHECK_ISBT128               1019
#define IDC_CHECK_CC_C                  1020
#define IDC_CHECK_AIMID                 1020
#define IDC_CHECK_ADDON                 1021
#define IDC_CHECK_CONTINUE              1021
#define IDC_CHECK_GS1_LIM               1022
#define IDC_EDIT_DATA                   1023
#define IDC_CHECK_GS1_EXP               1023
#define IDC_CHECK_XNUM                  1024
#define IDC_CHECK_NUMERIC               1025
#define IDC_BTN_APPLY                   1028
#define IDC_CHECK_HEX                   1030
#define IDC_CHECK_CENTERDECODE          1031
#define IDC_STATIC2                     1032
#define IDC_RADIO_DEFAULT               1034
#define IDC_RADIO_BEEP                  1035
#define IDC_RADIO_NONE                  1036
#define IDC_STATIC_INFO                 1039

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
