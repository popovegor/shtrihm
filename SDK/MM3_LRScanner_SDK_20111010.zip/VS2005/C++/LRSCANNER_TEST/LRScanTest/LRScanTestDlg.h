// LRScanTestDlg.h : header file
//

#pragma once

#include "LRScanner.h"

#define HOTKEY_ONE		0x0111
#define HOTKEY_TWO		0x0112
#define HOTKEY_THREE	0x0113

// CLRScanTestDlg dialog
class CLRScanTestDlg : public CDialog
{
// Construction
public:
	CLRScanTestDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_LRSCANTEST_DIALOG };


	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
public:

	BOOL	m_bKeyFlag;	
	BOOL	m_bSyncMode;
	BOOL	m_bContinueMode;
	BOOL	m_bContinueFlag;
	BOOL	m_bNewForm;

	CString m_strStaticType;
	CString m_strEditData;

	afx_msg void OnDestroy();
	afx_msg LRESULT OnScanRead(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnHotKey(WPARAM wParam, LPARAM lParam);
	afx_msg void OnBnClickedBtnScan();
	afx_msg void OnBnClickedBtnScancancel();
	afx_msg void OnBnClickedBtnSymbology();
	afx_msg void OnBnClickedBtnScanoption();
	afx_msg void OnBnClickedBtnNew();
	afx_msg void OnBnClickedBtnInfo();
	afx_msg void OnBnClickedBtnClose();
};
