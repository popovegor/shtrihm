#pragma once


// CCode39Dlg dialog

class CCode39Dlg : public CDialog
{
	DECLARE_DYNAMIC(CCode39Dlg)

public:
	CCode39Dlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCode39Dlg();

// Dialog Data
	enum { IDD = IDD_CODE39_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	BOOL m_bEnable;
	BOOL m_bCDV;
	BOOL m_bXCD;
	BOOL m_bFullASCII;
	afx_msg void OnBnClickedOk();
};
