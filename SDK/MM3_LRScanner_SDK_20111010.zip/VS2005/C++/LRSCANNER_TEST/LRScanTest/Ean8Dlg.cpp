// Ean8Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "LRScanTest.h"
#include "Ean8Dlg.h"
#include "LRScanTestDlg.h"


// CEan8Dlg dialog

IMPLEMENT_DYNAMIC(CEan8Dlg, CDialog)

CEan8Dlg::CEan8Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEan8Dlg::IDD, pParent)
	, m_bEnable(FALSE)
	, m_bXCD(FALSE)
	, m_bEan8AsEan13(FALSE)
{

}

CEan8Dlg::~CEan8Dlg()
{
}

void CEan8Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHECK_XCD, m_bXCD);
	DDX_Check(pDX, IDC_CHECK_EAN8_AS_EAN13, m_bEan8AsEan13);
}


BEGIN_MESSAGE_MAP(CEan8Dlg, CDialog)
	ON_BN_CLICKED(IDOK, &CEan8Dlg::OnBnClickedOk)
END_MESSAGE_MAP()


// CEan8Dlg message handlers

BOOL CEan8Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	PEAN8_PARAMS pEan8 = new EAN8_PARAMS();

	if(LRSCAN_GetEAN8(pEan8) == FALSE)
		::MessageBox(NULL, L"Error : LRSCAN_GetEAN8()", NULL, MB_TOPMOST);

	m_bEnable		= pEan8->bEnable;
	m_bXCD			= pEan8->bXCD;
	m_bEan8AsEan13	= pEan8->bEAN8_AS_EAN13;

	delete pEan8;

	UpdateData(FALSE);

	return TRUE;  
}

void CEan8Dlg::OnBnClickedOk()
{
	UpdateData(TRUE);

	PEAN8_PARAMS pEan8 = new EAN8_PARAMS();

	pEan8->bEnable			= m_bEnable;
	pEan8->bXCD				= m_bXCD;
	pEan8->bEAN8_AS_EAN13	= m_bEan8AsEan13;

	if(LRSCAN_SetEAN8(pEan8) == FALSE)
		::MessageBox(NULL, L"Error : LRSCAN_SetEAN8()", NULL, MB_TOPMOST);

	delete pEan8;

	OnOK();
}
