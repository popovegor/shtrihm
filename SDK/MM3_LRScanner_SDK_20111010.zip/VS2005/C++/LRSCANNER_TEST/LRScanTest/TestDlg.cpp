// TestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LRScanTest.h"
#include "TestDlg.h"
#include "LRScanTestDlg.h"


// CTestDlg dialog

IMPLEMENT_DYNAMIC(CTestDlg, CDialog)

CTestDlg::CTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestDlg::IDD, pParent)
	, m_strStaticType(_T(""))
	, m_strEditData(_T(""))
{

}

CTestDlg::~CTestDlg()
{
}

void CTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_STATIC_TYPE, m_strStaticType);
	DDX_Text(pDX, IDC_EDIT_DATA, m_strEditData);
}


BEGIN_MESSAGE_MAP(CTestDlg, CDialog)
	ON_MESSAGE(WM_SCAN_DATA, OnScanRead)
	ON_BN_CLICKED(IDC_BTN_SCAN, &CTestDlg::OnBnClickedBtnScan)
	ON_BN_CLICKED(IDC_BTN_SCANCANCEL, &CTestDlg::OnBnClickedBtnScancancel)
END_MESSAGE_MAP()


// CTestDlg message handlers

BOOL CTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	static CFont fFont;
	LOGFONT LogFont;

	GetDlgItem(IDC_STATIC_TYPE)->GetFont()->GetLogFont(&LogFont);

	LogFont.lfWeight = 1400;
	LogFont.lfHeight = 40;

	fFont.CreateFontIndirect(&LogFont);

	GetDlgItem(IDC_STATIC_TYPE)->SetFont(&fFont);

	GetDlgItem(IDC_EDIT_DATA)->GetFont()->GetLogFont(&LogFont);

	LogFont.lfWeight = 1400;
	LogFont.lfHeight = 40;

	fFont.CreateFontIndirect(&LogFont);

	GetDlgItem(IDC_EDIT_DATA)->SetFont(&fFont);

	m_strStaticType = L"TYPE";
	m_strEditData = L"DATA";

	UpdateData(FALSE);

	return TRUE;  
}

void CTestDlg::OnBnClickedBtnScan()
{
	LRSCAN_Read();
}

void CTestDlg::OnBnClickedBtnScancancel()
{
	LRSCAN_ReadCancel();
}

LRESULT CTestDlg::OnScanRead(WPARAM wParam, LPARAM lParam)
{
	return LRESULT();
}
