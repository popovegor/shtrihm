#pragma once
#include "afxwin.h"


// CScanOptionDlg dialog

class CScanOptionDlg : public CDialog
{
	DECLARE_DYNAMIC(CScanOptionDlg)

public:
	CScanOptionDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CScanOptionDlg();

// Dialog Data
	enum { IDD = IDD_SCANOPTION_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	int m_nSyncMode;
	int m_nSound;
	CComboBox m_ctrlComboTimeOut;
	CComboBox m_ctrlComboSecurityLevel;
	BOOL m_bContinueMode;
	BOOL m_bAimID;
	BOOL m_bVibrate;
	BOOL m_b1DDecode;
	BOOL m_bCenterDecode;
	afx_msg void OnBnClickedOk();
	virtual BOOL OnInitDialog();
	BOOL GetOption(void);
	BOOL SetOption(void);
};
