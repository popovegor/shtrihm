
#pragma once
#include "afxcmn.h"
#include "afxwin.h"


// CSymbologyDlg dialog

class CSymbologyDlg : public CDialog
{
	DECLARE_DYNAMIC(CSymbologyDlg)

public:
	CSymbologyDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CSymbologyDlg();

// Dialog Data
	enum { IDD = IDD_SYMBOLOGY_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedBtnAll();
	afx_msg void OnBnClickedBtnParam();
	afx_msg void OnBnClickedBtnDefault();
	afx_msg void OnBnClickedOk();
	CListCtrl m_ctrlListSymbology;
	CButton m_ctrlBtnParam;
	void SetSymbologyList(void);
	afx_msg void OnNMClickListSymbology(NMHDR *pNMHDR, LRESULT *pResult);
};
