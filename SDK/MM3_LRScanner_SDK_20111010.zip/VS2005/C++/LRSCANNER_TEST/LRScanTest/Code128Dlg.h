#pragma once


// CCode128Dlg dialog

class CCode128Dlg : public CDialog
{
	DECLARE_DYNAMIC(CCode128Dlg)

public:
	CCode128Dlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCode128Dlg();

// Dialog Data
	enum { IDD = IDD_CODE128_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
	BOOL m_bEnable;
	BOOL m_bGs1128;
	BOOL m_bIsbt128;
};
