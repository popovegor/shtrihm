#pragma once


// CTestDlg dialog

class CTestDlg : public CDialog
{
	DECLARE_DYNAMIC(CTestDlg)

public:
	CTestDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CTestDlg();

// Dialog Data
	enum { IDD = IDD_TEST_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedBtnScan();
	afx_msg void OnBnClickedBtnScancancel();
	afx_msg LRESULT OnScanRead(WPARAM wParam, LPARAM lParam);
	CString m_strStaticType;
	CString m_strEditData;
};
