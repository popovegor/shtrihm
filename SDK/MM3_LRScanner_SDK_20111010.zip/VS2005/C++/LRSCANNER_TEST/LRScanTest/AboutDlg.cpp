// AboutDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LRScanTest.h"
#include "AboutDlg.h"
#include "LRScanTestDlg.h"


// CAboutDlg dialog

IMPLEMENT_DYNAMIC(CAboutDlg, CDialog)

CAboutDlg::CAboutDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAboutDlg::IDD, pParent)
	, m_strStaticInfo(_T(""))
{

}

CAboutDlg::~CAboutDlg()
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_STATIC_INFO, m_strStaticInfo);
}


BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CAboutDlg message handlers

BOOL CAboutDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	TCHAR szVersionInfo[1024];
	LRSCAN_GetVersionInfo(szVersionInfo);
	m_strStaticInfo = szVersionInfo;

	UpdateData(FALSE);

	return TRUE;  
}
