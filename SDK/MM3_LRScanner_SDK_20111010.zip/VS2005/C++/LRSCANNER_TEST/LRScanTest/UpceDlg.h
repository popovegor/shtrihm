#pragma once


// CUpceDlg dialog

class CUpceDlg : public CDialog
{
	DECLARE_DYNAMIC(CUpceDlg)

public:
	CUpceDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CUpceDlg();

// Dialog Data
	enum { IDD = IDD_UPCE_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
	BOOL m_bEnable;
	BOOL m_bXNum;
	BOOL m_bXCD;
	BOOL m_bUpceAsUpca;
};
