#pragma once


// CGs1DatabarDlg dialog

class CGs1DatabarDlg : public CDialog
{
	DECLARE_DYNAMIC(CGs1DatabarDlg)

public:
	CGs1DatabarDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CGs1DatabarDlg();

// Dialog Data
	enum { IDD = IDD_GS1DATABAR_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
	BOOL m_bEnable;
	BOOL m_bGs1Lim;
	BOOL m_bGs1Exp;
};
