#pragma once


// CEan13Dlg dialog

class CEan13Dlg : public CDialog
{
	DECLARE_DYNAMIC(CEan13Dlg)

public:
	CEan13Dlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CEan13Dlg();

// Dialog Data
	enum { IDD = IDD_EAN13_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
	BOOL m_bEnable;
	BOOL m_bIsxn;
	BOOL m_bXCD;
	BOOL m_bAddOn;
};
